cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "sv",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 day": [
  null,
  "$0 dag",
  "$0 dagar"
 ],
 "$0 documentation": [
  null,
  "$0 dokumentation"
 ],
 "$0 exited with code $1": [
  null,
  "$0 avslutade med kod $1"
 ],
 "$0 failed": [
  null,
  "$0 misslyckades"
 ],
 "$0 hour": [
  null,
  "$0 timme",
  "$0 timmar"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 är inte tillgängligt från något förråd."
 ],
 "$0 key changed": [
  null,
  "$0 nyckel ändrad"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 dödad med signal $1"
 ],
 "$0 minute": [
  null,
  "$0 minut",
  "$0 minuter"
 ],
 "$0 month": [
  null,
  "$0 månad",
  "$0 månader"
 ],
 "$0 week": [
  null,
  "$0 vecka",
  "$0 veckor"
 ],
 "$0 will be installed.": [
  null,
  "$0 kommer att installeras."
 ],
 "$0 year": [
  null,
  "$0 år",
  "$0 år"
 ],
 "1 day": [
  null,
  "1 dag"
 ],
 "1 hour": [
  null,
  "1 timme"
 ],
 "1 minute": [
  null,
  "1 minut"
 ],
 "1 week": [
  null,
  "1 vecka"
 ],
 "20 minutes": [
  null,
  "20 minuter"
 ],
 "40 minutes": [
  null,
  "40 minuter"
 ],
 "5 minutes": [
  null,
  "5 minuter"
 ],
 "6 hours": [
  null,
  "6 timmar"
 ],
 "60 minutes": [
  null,
  "60 minuter"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Ingen kompatibel version av Cockpit är installerad på $0."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "En ny SSH-nyckel på $0 kommer att skapas för $1 på $2 och den kommer att läggas till $3-filen på $4 på $5."
 ],
 "About Web Console": [
  null,
  "Om webkonsolen"
 ],
 "Absent": [
  null,
  "Frånvarande"
 ],
 "Acceptable password": [
  null,
  "Acceptabelt lösenord"
 ],
 "Active pages": [
  null,
  "Aktiva sidor"
 ],
 "Add": [
  null,
  "Lägg till"
 ],
 "Add $0": [
  null,
  "Lägg till $0"
 ],
 "Add key": [
  null,
  "Lägg till nyckel"
 ],
 "Add new host": [
  null,
  "Lägg till ny värd"
 ],
 "Additional packages:": [
  null,
  "Ytterligare paket:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Administration med Cockpits webbkonsol"
 ],
 "Administrative access": [
  null,
  "Administrativ tillgång"
 ],
 "Advanced TCA": [
  null,
  "Avancerad TCA"
 ],
 "All-in-one": [
  null,
  "Allt i ett"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Dokumentation för Ansibleroller"
 ],
 "Apps": [
  null,
  "Program"
 ],
 "Authenticate": [
  null,
  "Autentisera"
 ],
 "Authentication": [
  null,
  "Autentisering"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Autentisering krävs för att utföra privilegierade uppgifter med Cockpits webbkonsol"
 ],
 "Authorize SSH key": [
  null,
  "Auktorisera SSH-nyckel"
 ],
 "Automatic login": [
  null,
  "Automatisk inloggning"
 ],
 "Automatically using NTP": [
  null,
  "Använder automatiskt NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Använder automatiskt ytterligare NTP-servrar"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Använder automatiskt specifika NTP-servrar"
 ],
 "Automation script": [
  null,
  "Automatiseringsskript"
 ],
 "Blade": [
  null,
  "Blad"
 ],
 "Blade enclosure": [
  null,
  "Bladhölje"
 ],
 "Bus expansion chassis": [
  null,
  "Bussexpansionschassi"
 ],
 "By changing the password of the SSH key $0 to the login password of $1 on $2, the key will be automatically made available and you can log in to $3 without password in the future.": [
  null,
  "Genom att ändra lösenordet för SSH-nyckeln $0 till inloggningslösenordet $1 på $2, kommer nyckeln automatiskt att göras tillgänglig och du kan logga in på $3 utan lösenord i framtiden."
 ],
 "Can be a hostname, IP address, alias name, or ssh:// URI": [
  null,
  "Kan vara ett värdnamn, IP-adress, aliasnamn eller ssh:// URI"
 ],
 "Cancel": [
  null,
  "Avbryt"
 ],
 "Cannot connect to an unknown host": [
  null,
  "Kan inte ansluta till en okänd maskin"
 ],
 "Cannot forward login credentials": [
  null,
  "Kan inte vidarebefordra inloggningsuppgifterna"
 ],
 "Cannot schedule event in the past": [
  null,
  "Kan inte schemalägga händelser som redan hänt"
 ],
 "Change": [
  null,
  "Ändra"
 ],
 "Change password": [
  null,
  "Ändra lösenord"
 ],
 "Change system time": [
  null,
  "Ändra systemtid"
 ],
 "Change the password of $0": [
  null,
  "Ändra lösenord av $0"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Ändrade nycklar är ofta resultatet av en ominstallation av operativsystemet. En oväntad förändring kan dock indikera ett försök från tredje part att avlyssna din anslutning."
 ],
 "Checking installed software": [
  null,
  "Kontrollerar installerad programvara"
 ],
 "Choose the language to be used in the application": [
  null,
  "Välj språk som skall användas i programmet"
 ],
 "Clear input value": [
  null,
  "Rensa inmatningsvärde"
 ],
 "Clear search": [
  null,
  "Nollställ sökning"
 ],
 "Close": [
  null,
  "Stäng"
 ],
 "Close selected pages": [
  null,
  "Stäng valda sidor"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Cockpit konfiguration av NetworkManager och Firewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit kunde inte kontakta den angivna värden."
 ],
 "Cockpit had an unexpected internal error.": [
  null,
  "Cockpit hade ett oväntat internt fel."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit är en serverhanterare som gör det lätt att administrera dina Linuxservrar via en webbläsare. Att hoppa mellan terminalen och webbverktyget är inget problem. En tjänst som startas via Cockpit kan stoppas via terminalen. Likaledes, om ett fel uppstår i terminalen kan det ses i Cockpits journalgränssnitt."
 ],
 "Cockpit is an interactive Linux server admin interface.": [
  null,
  "Cockpit är ett interaktivt administratörsgränssnitt för Linuxservrar."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit är inte kompatibelt med programvaran på systemet."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit är inte installerat"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit är inte installerat på systemet."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit är perfekt för nya systemadministratörer, låter dem lätt utföra enkla uppgifter såsom lagringsadministration, inspektion av journaler och att starta och stoppa tjänster. Du kan övervaka och administrera flera servrar på samma gång. Lägg bara till dem med ett enda klick och dina maskiner kommer se efter sina kompisar."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Samla och paketera diagnostik och support data"
 ],
 "Collect kernel crash dumps": [
  null,
  "Samla kärnkraschdumpar"
 ],
 "Color": [
  null,
  "Färg"
 ],
 "Comment": [
  null,
  "Kommentar"
 ],
 "Compact PCI": [
  null,
  "Kompakt PCI"
 ],
 "Confirm key password": [
  null,
  "Bekräfta lösenord för nyckel"
 ],
 "Confirm new key password": [
  null,
  "Bekräfta nytt lösenord för nyckel"
 ],
 "Confirm password": [
  null,
  "Bekräfta lösenord"
 ],
 "Connect": [
  null,
  "Anslut"
 ],
 "Connect to $0?": [
  null,
  "Anslut till $0?"
 ],
 "Connected hosts can fully control each other. This includes running programs that could harm your system or steal data. Only connect to trusted machines.": [
  null,
  "Anslutna värdar kan styra varandra helt. Detta inkluderar att köra program som kan skada ditt system eller stjäla data. Anslut endast till betrodda maskiner."
 ],
 "Connecting to the machine": [
  null,
  "Ansluter till maskinen"
 ],
 "Connection error": [
  null,
  "Anslutningsfel"
 ],
 "Connection failed": [
  null,
  "Anslutningen misslyckades"
 ],
 "Connection has timed out.": [
  null,
  "Anslutningens tidsgräns överskreds."
 ],
 "Contains:": [
  null,
  "Innehåller:"
 ],
 "Continue session": [
  null,
  "Fortsätt session"
 ],
 "Convertible": [
  null,
  "Konvertibel"
 ],
 "Copied": [
  null,
  "Kopierade"
 ],
 "Copy": [
  null,
  "Kopiera"
 ],
 "Copy to clipboard": [
  null,
  "Kopiera till urklipp"
 ],
 "Could not contact $0": [
  null,
  "Kunde inte kontakta $0"
 ],
 "Create $0": [
  null,
  "Skapa $0"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Skapa en ny SSH-nyckel och auktorisera den"
 ],
 "Create new task file with this content.": [
  null,
  "Skapa en ny uppgiftsfil med detta innehåll."
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Ctrl-Shift-I": [
  null,
  "Ctrl-Skift-J"
 ],
 "Dark": [
  null,
  "Mörk"
 ],
 "Default": [
  null,
  "Standard"
 ],
 "Delay": [
  null,
  "Fördröjning"
 ],
 "Desktop": [
  null,
  "Skrivbord"
 ],
 "Detachable": [
  null,
  "Frånkopplingsbar"
 ],
 "Details": [
  null,
  "Detaljer"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostikrapporter"
 ],
 "Disconnected": [
  null,
  "Frånkopplad"
 ],
 "Display language": [
  null,
  "Visningsspråk"
 ],
 "Docking station": [
  null,
  "Dockningsstation"
 ],
 "Downloading $0": [
  null,
  "Hämtar $0"
 ],
 "Dual rank": [
  null,
  "Dubbelrad"
 ],
 "Edit": [
  null,
  "Redigera"
 ],
 "Edit host": [
  null,
  "Redigera värd"
 ],
 "Edit hosts": [
  null,
  "Redigera värdar"
 ],
 "Embedded PC": [
  null,
  "Inbäddad PC"
 ],
 "Excellent password": [
  null,
  "Utmärkt lösenord"
 ],
 "Expansion chassis": [
  null,
  "Expansionschassin"
 ],
 "Failed to add machine: $0": [
  null,
  "Misslyckades att lägga till en maskin: $0"
 ],
 "Failed to change password": [
  null,
  "Misslyckades att ändra lösenord"
 ],
 "Failed to edit machine: $0": [
  null,
  "Misslyckades att redigera en maskin: $0"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Misslyckades med att aktivera $0 i firewalld"
 ],
 "Filter menu items": [
  null,
  "Filtrera menyalternativ"
 ],
 "Fingerprint": [
  null,
  "Fingeravtryck"
 ],
 "Go to now": [
  null,
  "Gå till nu"
 ],
 "Handheld": [
  null,
  "Handhållen"
 ],
 "Help": [
  null,
  "Hjälp"
 ],
 "Hide confirmation password": [
  null,
  "Dölj bekräftelselösenord"
 ],
 "Hide password": [
  null,
  "Dölj lösenord"
 ],
 "Host": [
  null,
  "Värd"
 ],
 "Host key is incorrect": [
  null,
  "Värdnyckeln är felaktig"
 ],
 "Hosts": [
  null,
  "Värdar"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Om fingeravtrycket stämmer, klicka på \"Lita på och lägg till värd\". Annars, anslut inte och kontakta din administratör."
 ],
 "In order to allow log in to $0 as $1 without password in the future, use the login password of $2 on $3 as the key password, or leave the key password blank.": [
  null,
  "För att tillåta inloggning till $0 som $1 utan lösenord i framtiden, använd inloggningslösenordet $2 på $3 som nyckellösenord, eller lämna nyckellösenordet tomt."
 ],
 "Install": [
  null,
  "Installera"
 ],
 "Install software": [
  null,
  "Installera programvara"
 ],
 "Installing $0": [
  null,
  "Installerar $0"
 ],
 "Internal error": [
  null,
  "Internt fel"
 ],
 "Invalid date format": [
  null,
  "Felaktigt datumformat"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Felaktigt datumformat och felaktigt tidsformat"
 ],
 "Invalid file permissions": [
  null,
  "Felaktiga filrättigheter"
 ],
 "Invalid time format": [
  null,
  "Felaktigt tidsformat"
 ],
 "Invalid timezone": [
  null,
  "Felaktig tidszon"
 ],
 "IoT gateway": [
  null,
  "IoT-gateway"
 ],
 "Is sshd running on a different port?": [
  null,
  "Kör sshd på en annan port?"
 ],
 "Kernel dump": [
  null,
  "Kärndump"
 ],
 "Key password": [
  null,
  "Nyckellösenord"
 ],
 "Laptop": [
  null,
  "Bärbar dator"
 ],
 "Learn more": [
  null,
  "Mer information"
 ],
 "Licensed under GNU LGPL version 2.1": [
  null,
  "Licensierad under GNU LGPL version 2.1"
 ],
 "Light": [
  null,
  "Ljust"
 ],
 "Limit access": [
  null,
  "Begränsa tillgång"
 ],
 "Limited access": [
  null,
  "Begränsad tillgång"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Begränsat läge begränsar administratörsprivilegier och tar bort funktionalitet i delar av webbkonsolen."
 ],
 "Loading packages...": [
  null,
  "Läser in paket..."
 ],
 "Loading system modifications...": [
  null,
  "Läser in anpassningar till systemet..."
 ],
 "Log in": [
  null,
  "Logga in"
 ],
 "Log in to $0": [
  null,
  "Logga in till $0"
 ],
 "Log messages": [
  null,
  "Loggmeddelanden"
 ],
 "Log out": [
  null,
  "Logga ut"
 ],
 "Login failed": [
  null,
  "Inloggningen misslyckades"
 ],
 "Low profile desktop": [
  null,
  "Lågprofilskrivbord"
 ],
 "Lunch box": [
  null,
  "Lunchlåda"
 ],
 "Main server chassis": [
  null,
  "Huvudserverchassi"
 ],
 "Malicious pages on a remote machine may affect other connected hosts": [
  null,
  "Skadliga sidor på en fjärrdator kan påverka andra anslutna värdar"
 ],
 "Manage storage": [
  null,
  "Hantera lagring"
 ],
 "Manually": [
  null,
  "Manuellt"
 ],
 "Message to logged in users": [
  null,
  "Meddelande till inloggade användare"
 ],
 "Messages related to the failure might be found in the journal:": [
  null,
  "Meddelanden angående detta fel kan finnas i journalen:"
 ],
 "Method": [
  null,
  "Metod"
 ],
 "Mini PC": [
  null,
  "Mini-PC"
 ],
 "Mini tower": [
  null,
  "Minitorn"
 ],
 "Multi-system chassis": [
  null,
  "Multisystemschassi"
 ],
 "NTP server": [
  null,
  "NTP-server"
 ],
 "Name": [
  null,
  "Namn"
 ],
 "Need at least one NTP server": [
  null,
  "Behöver åtminstone en NTP-server"
 ],
 "Networking": [
  null,
  "Nätverk"
 ],
 "New host: $0": [
  null,
  "Ny värd: $0"
 ],
 "New key password": [
  null,
  "Nytt nyckellösenord"
 ],
 "New password": [
  null,
  "Nytt lösenord"
 ],
 "New password was not accepted": [
  null,
  "Det nya lösenordet godtogs inte"
 ],
 "No delay": [
  null,
  "Ingen fördröjning"
 ],
 "No languages match": [
  null,
  "Inga språk matchar"
 ],
 "No results found": [
  null,
  "Inga resultat funna"
 ],
 "No such file or directory": [
  null,
  "Filen eller katalogen finns inte"
 ],
 "No system modifications": [
  null,
  "Inga systemändringar"
 ],
 "Not a valid private key": [
  null,
  "Inte en giltig privat nyckel"
 ],
 "Not connected to host": [
  null,
  "Inte ansluten till värd"
 ],
 "Not permitted to perform this action.": [
  null,
  "Inte tillåtet att utföra denna åtgärd."
 ],
 "Not synchronized": [
  null,
  "Inte synkroniserad"
 ],
 "Notebook": [
  null,
  "Bärbar (notebook)"
 ],
 "Occurrences": [
  null,
  "Förekomster"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Old password not accepted": [
  null,
  "Det gamla lösenordet accepterades inte"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "När Cockpit är installerat, aktivera det med ”systemctl enable --now cockpit.socket”."
 ],
 "Ooops!": [
  null,
  "Hoppsan!"
 ],
 "Other": [
  null,
  "Annan"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit kraschade"
 ],
 "Page name": [
  null,
  "Sidnamn"
 ],
 "Password": [
  null,
  "Lösenord"
 ],
 "Password changed successfully": [
  null,
  "Lösenordet har ändrats"
 ],
 "Password is not acceptable": [
  null,
  "Lösenordet är inte godtagbart"
 ],
 "Password is too weak": [
  null,
  "Lösenordet är för svagt"
 ],
 "Password not accepted": [
  null,
  "Lösenordet accepterades inte"
 ],
 "Password tip": [
  null,
  "Lösenordstips"
 ],
 "Paste": [
  null,
  "Klistra in"
 ],
 "Paste error": [
  null,
  "Klistra in fel"
 ],
 "Path to file": [
  null,
  "Sökväg till filen"
 ],
 "Peripheral chassis": [
  null,
  "Periferichassi"
 ],
 "Pick date": [
  null,
  "Välj datum"
 ],
 "Pizza box": [
  null,
  "Pizzalåda"
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Autentisera för att få administrativ åtkomst"
 ],
 "Port": [
  null,
  "Port"
 ],
 "Portable": [
  null,
  "Bärbar"
 ],
 "Present": [
  null,
  "Närvarande"
 ],
 "Problem becoming administrator": [
  null,
  "Problem med att bli administratör"
 ],
 "Project website": [
  null,
  "Projektwebbsajt"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Tidsgränsen överskreds vid fråga via ssh-add"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Tidsgränsen överskreds vid fråga via ssh-keygen"
 ],
 "Public key": [
  null,
  "Publik nyckel"
 ],
 "RAID chassis": [
  null,
  "RAID-chassi"
 ],
 "Rack mount chassis": [
  null,
  "Rackmonteringschassi"
 ],
 "Read more": [
  null,
  "Läs mer"
 ],
 "Reboot": [
  null,
  "Starta om"
 ],
 "Reconnect": [
  null,
  "Återanslut"
 ],
 "Removals:": [
  null,
  "Borttagningar:"
 ],
 "Remove": [
  null,
  "Avlägsna"
 ],
 "Removing $0": [
  null,
  "Tar bort $0"
 ],
 "Row expansion": [
  null,
  "Radexpansion"
 ],
 "Row select": [
  null,
  "Radval"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Kör det här kommandot över ett pålitligt nätverk eller fysiskt på fjärrdatorn:"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "SSH-nyckel"
 ],
 "SSH key login": [
  null,
  "SSH-nyckel inloggning"
 ],
 "SSH keys": [
  null,
  "SSH-nycklar"
 ],
 "Safari users need to import and trust the certificate of the self-signing CA:": [
  null,
  "Safari-användare måste importera och lita på certifikatet för den självsignerande CA:"
 ],
 "Sealed-case PC": [
  null,
  "PC med slutet hölje"
 ],
 "Search": [
  null,
  "Sök"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Säkerhetsförbättrad Linux-konfiguration och felsökning"
 ],
 "Select": [
  null,
  "Välj"
 ],
 "Select an option": [
  null,
  "Välj ett alternativ"
 ],
 "Server has closed the connection.": [
  null,
  "Servern har stängt förbindelsen."
 ],
 "Session": [
  null,
  "Session"
 ],
 "Session is about to expire": [
  null,
  "Sessionen är på väg att löpa ut"
 ],
 "Set": [
  null,
  "Sätt"
 ],
 "Set time": [
  null,
  "Ställ in tiden"
 ],
 "Shell script": [
  null,
  "Skalskript"
 ],
 "Shift+Insert": [
  null,
  "Skift+Insert"
 ],
 "Show confirmation password": [
  null,
  "Visa bekräftelselösenord"
 ],
 "Show password": [
  null,
  "Visa lösenord"
 ],
 "Shut down": [
  null,
  "Stäng av"
 ],
 "Single rank": [
  null,
  "Ensam ordning"
 ],
 "Skip main navigation": [
  null,
  "Hoppa över huvudnavigationen"
 ],
 "Skip to content": [
  null,
  "Hoppa till innehållet"
 ],
 "Space-saving computer": [
  null,
  "Utrymmessparande dator"
 ],
 "Specific time": [
  null,
  "Specifik tid"
 ],
 "Stick PC": [
  null,
  "Pinndator"
 ],
 "Stop editing hosts": [
  null,
  "Sluta redigera värdar"
 ],
 "Storage": [
  null,
  "Lagring"
 ],
 "Strong password": [
  null,
  "Starkt lösenord"
 ],
 "Style": [
  null,
  "Stil"
 ],
 "Sub-Chassis": [
  null,
  "Under-chassi"
 ],
 "Sub-Notebook": [
  null,
  "ULPC"
 ],
 "Switch to administrative access": [
  null,
  "Byt till administrativ åtkomst"
 ],
 "Switch to limited access": [
  null,
  "Byt till begränsad åtkomst"
 ],
 "Synchronized": [
  null,
  "Synkroniserad"
 ],
 "Synchronized with $0": [
  null,
  "Synkroniserad med $0"
 ],
 "Synchronizing": [
  null,
  "Synkroniserar"
 ],
 "System": [
  null,
  "System"
 ],
 "Tablet": [
  null,
  "Platta"
 ],
 "The IP address or hostname cannot contain whitespace.": [
  null,
  "IP-adressen eller värdnamnet får inte innehålla blanktecken."
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "SSH-nyckeln $0 av $1 på $2 kommer att läggas till $3-filen på $4 på $5."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH-nyckeln $0 kommer att göras tillgänglig för resten av sessionen och kommer att vara tillgänglig för inloggning även för andra värdar."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "SSH-nyckeln för att logga in på $0 är skyddad av ett lösenord, och värden tillåter inte inloggning med ett lösenord. Vänligen ange lösenordet för nyckeln på $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "SSH-nyckeln för att logga in på $0 är skyddad. Du kan logga in med antingen ditt inloggningslösenord eller genom att ange lösenordet för nyckeln för $1."
 ],
 "The fingerprint should match:": [
  null,
  "Fingeravtrycket ska matcha:"
 ],
 "The key password can not be empty": [
  null,
  "Nyckellösenordet får inte vara tomt"
 ],
 "The key passwords do not match": [
  null,
  "Nyckellösenorden stämmer inte överens"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Den inloggade användaren har inte tillåtelse att se systemändringar"
 ],
 "The machine is rebooting": [
  null,
  "Maskinen startar om"
 ],
 "The new key password can not be empty": [
  null,
  "Det nya nyckellösenordet får inte vara tomt"
 ],
 "The password can not be empty": [
  null,
  "Lösenordet får inte vara tomt"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Det resulterande fingeravtrycket går bra att dela via offentliga metoder, inklusive e-post."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Det resulterande fingeravtrycket är okej att dela via offentliga metoder, inklusive e-post. Om du ber någon annan att göra verifieringen åt dig kan de skicka resultaten med vilken metod som helst."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Servern vägrade att autentisera med några stödda metoder."
 ],
 "There are currently no active pages": [
  null,
  "Det finns för närvarande inga aktiva sidor"
 ],
 "There was an unexpected error while connecting to the machine.": [
  null,
  "Det uppstod ett oväntat fel vid anslutning till maskinen."
 ],
 "This machine has already been added.": [
  null,
  "Denna maskin har redan lagts till."
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Det här verktyget konfigurerar SELinux-policyn och kan hjälpa till med att förstå och lösa policy överträdelser."
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Det här verktyget konfigurerar systemet till att kunna skriva kärnkraschdumpar till disken. Det stödjer \"lokala\" (disk), \"ssh\" och \"nfs\" dumpmål."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Detta verktyg genererar ett arkiv med konfiguration och diagnostisk information från det körande systemet. Arkivet kan förvaras lokalt eller centralt för inspelning eller spårningsändamål eller kan skickas till tekniska supportrepresentanter, utvecklare eller systemadministratörer för att hjälpa till med teknisk felspårning och felsökning."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Detta verktyg hanterar lokal lagring, såsom filsystem, LVM2-volymgrupper och NFS-monteringar."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Detta verktyg hanterar nätverk som bindningar, broar, team, VLAN och brandväggar med NetworkManager och Firewalld. NetworkManager är inkompatibelt med Ubuntus standard systemd-networkd och Debians ifupdown skript."
 ],
 "This will allow you to log in without password in the future.": [
  null,
  "Detta gör att du kan logga in utan lösenord i framtiden."
 ],
 "Time zone": [
  null,
  "Tidszon"
 ],
 "Tip: Make your key password match your login password to automatically authenticate against other systems.": [
  null,
  "Tips: gör så att ditt nyckellösenord stämmer med ditt inloggningslösenord för att automatiskt autentisera mot andra system."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "För att säkerställa att din anslutning inte fångas upp av en skadlig tredje part, vänligen verifiera värdnyckelns fingeravtryck:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "För att verifiera ett fingeravtryck, kör följande på $0 medan du fysiskt sitter vid maskinen eller genom ett pålitligt nätverk:"
 ],
 "Toggle": [
  null,
  "Växla"
 ],
 "Toggle date picker": [
  null,
  "Växla datumväljare"
 ],
 "Too much data": [
  null,
  "För mycket data"
 ],
 "Tools": [
  null,
  "Verktyg"
 ],
 "Total size: $0": [
  null,
  "Total storlek: $0"
 ],
 "Tower": [
  null,
  "Torn"
 ],
 "Trust and add host": [
  null,
  "Lita på och lägg till värd"
 ],
 "Trying to synchronize with $0": [
  null,
  "Försök att synkronisera med $0"
 ],
 "Turn on administrative access": [
  null,
  "Aktivera administrativ åtkomst"
 ],
 "Type": [
  null,
  "Typ"
 ],
 "Unable to contact $0.": [
  null,
  "Det går inte att kontakta $0."
 ],
 "Unable to contact the given host $0. Make sure it has ssh running on port $1, or specify another port in the address.": [
  null,
  "Det går inte att kontakta den givna värden $0. Se till att ssh körs på port $1, eller ange en annan port i adressen."
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Det går inte att logga in på $0 med SSH-nyckelautentisering. Ange lösenordet."
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password. You may want to set up your SSH keys for automatic login.": [
  null,
  "Det går inte att logga in på $0 med SSH-nyckelautentisering. Ange lösenordet. Du kanske vill ställa in dina SSH-nycklar för automatisk inloggning."
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Det går inte att logga in på $0. Värden accepterar inte lösenordsinloggning eller någon av dina SSH-nycklar."
 ],
 "Unexpected error": [
  null,
  "Oväntat fel"
 ],
 "Unknown": [
  null,
  "Okänd"
 ],
 "Unknown host: $0": [
  null,
  "Okänd värd: $0"
 ],
 "Unlock": [
  null,
  "Lås upp"
 ],
 "Unlock key $0": [
  null,
  "Lås upp nyckel $0"
 ],
 "Untrusted host": [
  null,
  "Ej betrodd värd"
 ],
 "Update": [
  null,
  "Uppdatera"
 ],
 "Use key": [
  null,
  "Använd nyckel"
 ],
 "Use the following keys to authenticate against other systems": [
  null,
  "Använd följande nycklar för att autentisera mot andra system"
 ],
 "User name": [
  null,
  "Användarnamn"
 ],
 "Verify fingerprint": [
  null,
  "Verifiera fingeravtryck"
 ],
 "View all logs": [
  null,
  "Visa alla loggar"
 ],
 "View automation script": [
  null,
  "Visa automatiseringsskript"
 ],
 "Visit firewall": [
  null,
  "Besök brandvägg"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Väntar på att andra programvaruhanteringsåtgärder skall bli klara"
 ],
 "Weak password": [
  null,
  "Svagt lösenord"
 ],
 "Web Console": [
  null,
  "Webbkonsol"
 ],
 "Web Console for Linux servers": [
  null,
  "Webbkonsol för Linuxservrar"
 ],
 "Web console logo": [
  null,
  "Webbkonsolens logotyp"
 ],
 "When empty, connect with the current user": [
  null,
  "När tomt, anslut med den aktuella användaren"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Du ansluter till $0 för första gången."
 ],
 "You have been logged out due to inactivity.": [
  null,
  "Du har blivit utloggad på grund av inaktivitet."
 ],
 "You may want to change the password of the key for automatic login.": [
  null,
  "Du kanske vill ändra lösenordet för nyckeln för automatisk inloggning."
 ],
 "You now have administrative access.": [
  null,
  "Du har nu administrativ åtkomst."
 ],
 "You will be logged out in $0 seconds.": [
  null,
  "Du kommer att loggas ut om $0 sekunder."
 ],
 "You will be reminded once per session.": [
  null,
  "Du kommer att bli påmind en gång per session."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Din webbläsare tillåter inte att klistra in från sammanhangsmenyn. Du kan använda Skift+Insert."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Din webbläsare kommer ihåg din åtkomstnivå över sessioner."
 ],
 "Your session has been terminated.": [
  null,
  "Din session har avslutats."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Din session har gått ut. Logga in igen."
 ],
 "Zone": [
  null,
  "Zon"
 ],
 "[binary data]": [
  null,
  "[binärdata]"
 ],
 "[no data]": [
  null,
  "[inga data]"
 ],
 "active": [
  null,
  "aktiv"
 ],
 "in less than a minute": [
  null,
  "i mindre än en minut"
 ],
 "in most browsers": [
  null,
  "i de flesta webbläsare"
 ],
 "less than a minute ago": [
  null,
  "mindre än en minut sedan"
 ],
 "password quality": [
  null,
  "lösenordskvalitet"
 ],
 "show less": [
  null,
  "visa mindre"
 ],
 "show more": [
  null,
  "visa mer"
 ]
});
