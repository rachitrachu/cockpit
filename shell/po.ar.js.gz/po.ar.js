cockpit.locale({
 "": {
  "plural-forms": (n) => n==0 ? 0 : n==1 ? 1 : n==2 ? 2 : n%100>=3 && n%100<=10 ? 3 : n%100>=11 ? 4 : 5,
  "language": "ar",
  "language-direction": "rtl"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 day": [
  null,
  "$0 ولا يوم",
  "$0 يوم واحد",
  "$0 يومان",
  "$0 أيام",
  "$0 يوما",
  "$0 يوم"
 ],
 "$0 documentation": [
  null,
  "$0 وثائق"
 ],
 "$0 exited with code $1": [
  null,
  "$0 خرج مع الرمز $1"
 ],
 "$0 failed": [
  null,
  "$0 فشل"
 ],
 "$0 hour": [
  null,
  "$0 ولا ساعة",
  "$0 ساعة واحدة",
  "$0 ساعتان",
  "$0 ساعات",
  "$0 ساعة",
  "$0 ساعة"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 غير متوفر في أي مستودع."
 ],
 "$0 key changed": [
  null,
  "$0 مفتاح قد تغير"
 ],
 "$0 killed with signal $1": [
  null,
  "تم إيقاف $0 بالإشارة $1"
 ],
 "$0 minute": [
  null,
  "0 دقيقة",
  "دقيقة واحدة",
  "دقيقتان",
  "$0 دقائق",
  "$0 دقيقة",
  "$0 دقيقة"
 ],
 "$0 month": [
  null,
  "$0 شهر",
  "شهر واحد",
  "شهران",
  "$0 أشهر",
  "$0 شهراً",
  "$0 شهراً"
 ],
 "$0 week": [
  null,
  "$0 لا أسابيع",
  "$0 اسبوع واحد",
  "$0 اسبوعان",
  "$0 اسابيع",
  "$0 اسبوعا",
  "$0 اسبوع"
 ],
 "$0 will be installed.": [
  null,
  "$0 سيُثبت."
 ],
 "$0 year": [
  null,
  "$0 ولا سنة",
  "$0 سنة واحدة",
  "$0 سنتان",
  "$0 سنوات",
  "$0 سنة",
  "$0 سنة"
 ],
 "1 day": [
  null,
  "يوم واحد"
 ],
 "1 hour": [
  null,
  "ساعة واحدة"
 ],
 "1 minute": [
  null,
  "دقيقة واحدة"
 ],
 "1 week": [
  null,
  "أسبوع واحد"
 ],
 "20 minutes": [
  null,
  "٢٠ دقيقة"
 ],
 "40 minutes": [
  null,
  "٤٠ دقيقة"
 ],
 "5 minutes": [
  null,
  "٥ دقائق"
 ],
 "6 hours": [
  null,
  "٦ ساعات"
 ],
 "60 minutes": [
  null,
  "٦٠ دقيقة"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "لم يتم تثبيت إصدار متوافق من Cockpit على $0."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "سيتم إنشاء مفتاح SSH جديد في $0 لـ $1 بتاريخ $2 ، وإضافته إلى الملف $3 الخاص بـ $4 على $5."
 ],
 "About Web Console": [
  null,
  "حول وحدة تحكم الويب"
 ],
 "Absent": [
  null,
  "غائب"
 ],
 "Acceptable password": [
  null,
  "كلمة السر صالحة"
 ],
 "Active pages": [
  null,
  "الصفحات النشطة"
 ],
 "Add": [
  null,
  "إضافة"
 ],
 "Add $0": [
  null,
  "أضف $0"
 ],
 "Add key": [
  null,
  "إضافة مفتاح"
 ],
 "Add new host": [
  null,
  "إضافة مضيف جديد"
 ],
 "Additional packages:": [
  null,
  "حزم إضافية:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "الإدارة عبر وحدة تحكم الويب Cockpit"
 ],
 "Administrative access": [
  null,
  "صلاحيات المسؤول"
 ],
 "Advanced TCA": [
  null,
  "TCA متقدم"
 ],
 "All-in-one": [
  null,
  "الكل في واحد"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "توثيق الأدوار في Ansible"
 ],
 "Apps": [
  null,
  "التَطبيقات"
 ],
 "Authenticate": [
  null,
  "مصادقة"
 ],
 "Authentication": [
  null,
  "المصادقة"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "المصادقة مطلوبة لأداء المهام المميّزة في وحدة تحكم Cockpit على الويب"
 ],
 "Authorize SSH key": [
  null,
  "اعتماد مفاتيح SSH"
 ],
 "Automatic login": [
  null,
  "تسجيل دخول تلقائي"
 ],
 "Automatically using NTP": [
  null,
  "استخدام NTP بشكل تلقائي"
 ],
 "Automatically using additional NTP servers": [
  null,
  "استخدام خادم NTP إضافي بشكل تلقائي"
 ],
 "Automatically using specific NTP servers": [
  null,
  "استخدام خادم NTP محدد بشكل تلقائي"
 ],
 "Automation script": [
  null,
  "البرنامج النصي للتشغيل الآلي"
 ],
 "Blade": [
  null,
  "شفرة"
 ],
 "Blade enclosure": [
  null,
  "حاوية الشفرة"
 ],
 "Bus expansion chassis": [
  null,
  "هيكل توسيع الناقل"
 ],
 "By changing the password of the SSH key $0 to the login password of $1 on $2, the key will be automatically made available and you can log in to $3 without password in the future.": [
  null,
  "عبر تغيير كلمة سر مفتاح SSH $0 إلى كلمة سر تسجيل الدخول لـ $1 على $2، سيتم توفير المفتاح تلقائيًا ويمكنك تسجيل الدخول إلى $3 بدون كلمة سر في المستقبل."
 ],
 "Can be a hostname, IP address, alias name, or ssh:// URI": [
  null,
  "يمكن أن يكون اسم استضافة، عنوان IP، اسم مستعار، أو ssh:// URI"
 ],
 "Cancel": [
  null,
  "إلغاء"
 ],
 "Cannot connect to an unknown host": [
  null,
  "يتعذر الاتصال بمضيف غير معروف"
 ],
 "Cannot forward login credentials": [
  null,
  "لا يمكن إعادة توجيه بيانات اعتماد تسجيل الدخول"
 ],
 "Cannot schedule event in the past": [
  null,
  "لا يمكن جدولة الحدث في الماضي"
 ],
 "Change": [
  null,
  "تغيير"
 ],
 "Change password": [
  null,
  "تغيير كلمة السر"
 ],
 "Change system time": [
  null,
  "تغيير توقيت النظام"
 ],
 "Change the password of $0": [
  null,
  "تغيير كلمة سر $0"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "غالباً تكون المفاتيح المتغيرة نتيجة إعادة تثبيت نظام التشغيل. رغم ذلك، قد يشير التغيير غير المتوقع إلى محاولة طرف ثالث اعتراض اتصالك."
 ],
 "Checking installed software": [
  null,
  "التحقق من البرامج المثبتة"
 ],
 "Choose the language to be used in the application": [
  null,
  "اختر اللغة التي سيتم استخدامها في التطبيق"
 ],
 "Clear input value": [
  null,
  "مسح قيمة المدخلات"
 ],
 "Clear search": [
  null,
  "مسح البحث"
 ],
 "Close": [
  null,
  "أغلق"
 ],
 "Close selected pages": [
  null,
  "إغلاق الصفحات المحددة"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "تكوين Cockpit الخاص بـ NetworkManager وFirewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "لم يتمكن Cockpit بالاتصال بالمضيف المحدد."
 ],
 "Cockpit had an unexpected internal error.": [
  null,
  "حدث خطأ داخلي غير متوقع في Cockpit."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit هو أداة لإدارة الخوادم تُسهّل عليك الإشراف على خوادم Linux عبر متصفّح الويب. التنقّل بين الطرفية (الترمينال) والأداة على الويب سلس تمامًا؛ فمثلاً يمكنك إيقاف خدمة تمّ تشغيلها عبر Cockpit من داخل الطرفية، وبالمثل إذا ظهر خطأ في الطرفية ستجده معروضًا في واجهة سجلات Journal الخاصة بـ Cockpit."
 ],
 "Cockpit is an interactive Linux server admin interface.": [
  null,
  "Cockpit هي واجهة تفاعلية لإدارة خوادم Linux."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit غير متوافق مع البرنامج على النظام."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit غير مثبت"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit غير مثبت على النظام."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "تُعد Cockpit مثالية لمديري النظام الجدد، حيث تتيح لهم أداء مهام بسيطة بسهولة مثل إدارة التخزين وفحص السجلات وبدء تشغيل الخدمات وإيقافها. يمكنك مراقبة وإدارة عدة خوادم في نفس الوقت. ما عليك سوى إضافتها بنقرة واحدة وستعتني أجهزتك بالباقي."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "جمع بيانات التشخيص والدعم وتجميعها"
 ],
 "Collect kernel crash dumps": [
  null,
  "جمع تفريغات أعطال نواة النظام"
 ],
 "Color": [
  null,
  "اللون"
 ],
 "Comment": [
  null,
  "تعليق"
 ],
 "Compact PCI": [
  null,
  "PCI مدمج"
 ],
 "Confirm key password": [
  null,
  "تأكيد مفتاح كلمة السر"
 ],
 "Confirm new key password": [
  null,
  "تأكيد مفتاح كلمة سر جديد"
 ],
 "Confirm password": [
  null,
  "أكِّد كلمة المرور"
 ],
 "Connect": [
  null,
  "اتصال"
 ],
 "Connect to $0?": [
  null,
  "الاتصال بـ $0؟"
 ],
 "Connected hosts can fully control each other. This includes running programs that could harm your system or steal data. Only connect to trusted machines.": [
  null,
  "يمكن للأجهزة المتصلة التحكم الكامل ببعضها البعض، بما في ذلك تشغيل برامج قد تضر بنظامك أو تسرق بياناتك. لا تتصل إلا بأجهزة موثوقة."
 ],
 "Connecting to the machine": [
  null,
  "جارٍ الاتصال بالجهاز"
 ],
 "Connection error": [
  null,
  "خطأ في الاتصال"
 ],
 "Connection failed": [
  null,
  "فشل الاتصال"
 ],
 "Connection has timed out.": [
  null,
  "انتهت مدة الاتصال."
 ],
 "Contains:": [
  null,
  "يحتوي:"
 ],
 "Continue session": [
  null,
  "متابعة الجلسة"
 ],
 "Convertible": [
  null,
  "قابل للتحويل"
 ],
 "Copied": [
  null,
  "نُسخ"
 ],
 "Copy": [
  null,
  "نسخ"
 ],
 "Copy to clipboard": [
  null,
  "نسخ للحافظة"
 ],
 "Could not contact $0": [
  null,
  "تعذر الوصول إلى $0"
 ],
 "Create $0": [
  null,
  "أنشئ $0"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "إنشاء مفتاح SSH جديد وتفويضه"
 ],
 "Create new task file with this content.": [
  null,
  "إنشاء ملف مهمة جديدة بهذا المحتوى."
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Ctrl-Shift-I": [
  null,
  "Ctrl-Shift-I"
 ],
 "Dark": [
  null,
  "داكن"
 ],
 "Default": [
  null,
  "افتراضي"
 ],
 "Delay": [
  null,
  "التأخير"
 ],
 "Desktop": [
  null,
  "سطح المكتب"
 ],
 "Detachable": [
  null,
  "قابل للفصل"
 ],
 "Details": [
  null,
  "التفاصيل"
 ],
 "Diagnostic reports": [
  null,
  "تقارير التشخيص"
 ],
 "Disconnected": [
  null,
  "مفصول"
 ],
 "Display language": [
  null,
  "لغة العرض"
 ],
 "Docking station": [
  null,
  "محطة إرساء"
 ],
 "Downloading $0": [
  null,
  "جاري تنزيل $0"
 ],
 "Dual rank": [
  null,
  "رتبة مزدوجة"
 ],
 "Edit": [
  null,
  "عدِّل"
 ],
 "Edit host": [
  null,
  "تعديل المضيف"
 ],
 "Edit hosts": [
  null,
  "تعديل المضيفين"
 ],
 "Embedded PC": [
  null,
  "حاسوب مدمج"
 ],
 "Excellent password": [
  null,
  "كلمة سر ممتازة"
 ],
 "Expansion chassis": [
  null,
  "هيكل التوسعة"
 ],
 "Failed to add machine: $0": [
  null,
  "فشل في إضافة الآلة: $0"
 ],
 "Failed to change password": [
  null,
  "فشل في تغيير كلمة السر"
 ],
 "Failed to edit machine: $0": [
  null,
  "فشل في تعديل الجهاز: $0"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "فشل بتمكين $0 في الجدار الناري"
 ],
 "Filter menu items": [
  null,
  "عناصر قائمة التصفية"
 ],
 "Fingerprint": [
  null,
  "البصمة"
 ],
 "Go to now": [
  null,
  "انتقل الآن"
 ],
 "Handheld": [
  null,
  "محمول باليد"
 ],
 "Help": [
  null,
  "مساعدة"
 ],
 "Hide confirmation password": [
  null,
  "أخفِ تأكيد كلمة السر"
 ],
 "Hide password": [
  null,
  "أخفِ كلمة السر"
 ],
 "Host": [
  null,
  "المضيف"
 ],
 "Host key is incorrect": [
  null,
  "مفتاح الاستضافة غير صحيح"
 ],
 "Hosts": [
  null,
  "المستضيفين"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "إذا كانت البصمة متطابقة، انقر فوق ”توثيق وإضافة مضيف“. وإلا فلا تتصل ، وتواصل مع مسؤول النظام."
 ],
 "In order to allow log in to $0 as $1 without password in the future, use the login password of $2 on $3 as the key password, or leave the key password blank.": [
  null,
  "للسماح بتسجيل الدخول إلى$0 كـ$1 بدون كلمة سر في المستقبل، استخدم كلمة سر تسجيل الدخول $2 على $3 ككلمة مرور المفتاح، أو اترك كلمة المرور الرئيسية فارغة."
 ],
 "Install": [
  null,
  "تثبيت"
 ],
 "Install software": [
  null,
  "ثبت التطبيق"
 ],
 "Installing $0": [
  null,
  "يثبت $0"
 ],
 "Internal error": [
  null,
  "خطأ داخلي"
 ],
 "Invalid date format": [
  null,
  "تنسيق التاريخ خاطئ"
 ],
 "Invalid date format and invalid time format": [
  null,
  "صيغة البيانات والوقت غير صالحتان"
 ],
 "Invalid file permissions": [
  null,
  "صلاحيات ملف غير صالحة"
 ],
 "Invalid time format": [
  null,
  "تنسيق الوقت خاطئ"
 ],
 "Invalid timezone": [
  null,
  "منطقة زمنية غير صالحة"
 ],
 "IoT gateway": [
  null,
  "بوابة IoT"
 ],
 "Is sshd running on a different port?": [
  null,
  "هل يعمل sshd على منفذ مختلف؟"
 ],
 "Kernel dump": [
  null,
  "عطب نواة النظام"
 ],
 "Key password": [
  null,
  "مفتاح كلمة السر"
 ],
 "Laptop": [
  null,
  "لابتوب"
 ],
 "Learn more": [
  null,
  "اعرف المزيد"
 ],
 "Licensed under GNU LGPL version 2.1": [
  null,
  "‎مرخص بموجب GNU LGPL الإصدار 2.1"
 ],
 "Light": [
  null,
  "فاتح"
 ],
 "Limit access": [
  null,
  "تقييد الوصول"
 ],
 "Limited access": [
  null,
  "وصول مقيَّد"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "يُقيّد وضع الوصول المقيد الصلاحيات الإدارية. ستكون بعض أجزاء لوحة التحكم عبر الويب محدودة الوظائف."
 ],
 "Loading packages...": [
  null,
  "تحميل الحزم..."
 ],
 "Loading system modifications...": [
  null,
  "تحميل تعديلات النظام..."
 ],
 "Log in": [
  null,
  "تسجيل الدخول"
 ],
 "Log in to $0": [
  null,
  "تسجيل الدخول إلى $0"
 ],
 "Log messages": [
  null,
  "رسالة طويلة"
 ],
 "Log out": [
  null,
  "تسجيل خروج"
 ],
 "Login failed": [
  null,
  "فشل تسجيل الدخول"
 ],
 "Low profile desktop": [
  null,
  "ملف سطح مكتب منخفض"
 ],
 "Lunch box": [
  null,
  "صندوق التشغيل"
 ],
 "Main server chassis": [
  null,
  "هيكل الخادم الرئيسي"
 ],
 "Malicious pages on a remote machine may affect other connected hosts": [
  null,
  "قد تؤثر الصفحات الضارة في جهاز بعيد على أي مضيف متصل به"
 ],
 "Manage storage": [
  null,
  "إدارة التخزين"
 ],
 "Manually": [
  null,
  "يدوياً"
 ],
 "Message to logged in users": [
  null,
  "رسالة للمستخدمين النشطين"
 ],
 "Messages related to the failure might be found in the journal:": [
  null,
  "قد توجد رسائل متعلقة بالعطل في سجل النظام:"
 ],
 "Method": [
  null,
  "الطريقة"
 ],
 "Mini PC": [
  null,
  "حاسب آلي صغير"
 ],
 "Mini tower": [
  null,
  "برج صغير"
 ],
 "Multi-system chassis": [
  null,
  "هيكل متعدد الأنظمة"
 ],
 "NTP server": [
  null,
  "خادم NTP"
 ],
 "Name": [
  null,
  "الاسم"
 ],
 "Need at least one NTP server": [
  null,
  "يحتاج خادم NTP واحداً على الأقل"
 ],
 "Networking": [
  null,
  "التشبيك"
 ],
 "New host: $0": [
  null,
  "مضيف جديد: $0"
 ],
 "New key password": [
  null,
  "مقتاح كلمة سر جديد"
 ],
 "New password": [
  null,
  "كلمة السر الجديدة"
 ],
 "New password was not accepted": [
  null,
  "كلمة السر الجديدة لم تقبل"
 ],
 "No delay": [
  null,
  "لا تأخير"
 ],
 "No languages match": [
  null,
  "لا لغات متطابقة"
 ],
 "No results found": [
  null,
  "لم يعثر على نتائج"
 ],
 "No such file or directory": [
  null,
  "لا ملف أو مجلد من هذا النوع"
 ],
 "No system modifications": [
  null,
  "لا يوجد تعديلات على النظام"
 ],
 "Not a valid private key": [
  null,
  "مفتاح خاص غير صالح"
 ],
 "Not connected to host": [
  null,
  "غير متصل بالمضيف"
 ],
 "Not permitted to perform this action.": [
  null,
  "غير مصرح لك بهذا الإجراء."
 ],
 "Not synchronized": [
  null,
  "غير مزامن"
 ],
 "Notebook": [
  null,
  "محرر النصوص"
 ],
 "Occurrences": [
  null,
  "الحوادث"
 ],
 "Ok": [
  null,
  "موافق"
 ],
 "Old password not accepted": [
  null,
  "كلمة السر القديمة غير مطابقة"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "بمجرد تثبيت Cockpit، قم بتمكينه باستخدام ”systemctl enable --now cockpit.socket“."
 ],
 "Ooops!": [
  null,
  "عفواً!"
 ],
 "Other": [
  null,
  "أُخرى"
 ],
 "PackageKit crashed": [
  null,
  "تعطيل PackageKit"
 ],
 "Page name": [
  null,
  "اسم الصفحة"
 ],
 "Password": [
  null,
  "كلمة السر"
 ],
 "Password changed successfully": [
  null,
  "تم تغيير كلمة السر بنجاح"
 ],
 "Password is not acceptable": [
  null,
  "كلمة السر غير مقبولة"
 ],
 "Password is too weak": [
  null,
  "كلمة السر ضعيفة جداً"
 ],
 "Password not accepted": [
  null,
  "كلمة السر مرفوضة"
 ],
 "Password tip": [
  null,
  "تلميح كلمة السر"
 ],
 "Paste": [
  null,
  "لصق"
 ],
 "Paste error": [
  null,
  "خطأ في اللصق"
 ],
 "Path to file": [
  null,
  "المسار إلى الملف"
 ],
 "Peripheral chassis": [
  null,
  "هيكل الأجهزة الطرفية"
 ],
 "Pick date": [
  null,
  "اختيار التاريخ والوقت"
 ],
 "Pizza box": [
  null,
  "صندوق البيتزا"
 ],
 "Please authenticate to gain administrative access": [
  null,
  "الرجاء المصادقة للحصول على صلاحيات إدارية"
 ],
 "Port": [
  null,
  "منفذ"
 ],
 "Portable": [
  null,
  "متنقل"
 ],
 "Present": [
  null,
  "موجود"
 ],
 "Problem becoming administrator": [
  null,
  "مشكلة في الحصول على صلاحيات المسؤول"
 ],
 "Project website": [
  null,
  "موقع المشروع الإلكتروني"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "انتهت مهلة الطلب عبر ssh-add"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "انتهت مهلة الطلب عبر ssh-keygen"
 ],
 "Public key": [
  null,
  "مفتاح عام"
 ],
 "RAID chassis": [
  null,
  "هيكل RAID"
 ],
 "Rack mount chassis": [
  null,
  "هيكل مثبت على حامل"
 ],
 "Read more": [
  null,
  "اقرأ المزيد"
 ],
 "Reboot": [
  null,
  "إعادة تشغيل"
 ],
 "Reconnect": [
  null,
  "إعادة الاتصال"
 ],
 "Removals:": [
  null,
  "عمليات الإزالة:"
 ],
 "Remove": [
  null,
  "إزالة"
 ],
 "Removing $0": [
  null,
  "قيد إزالة $0"
 ],
 "Row expansion": [
  null,
  "توسعة الصف"
 ],
 "Row select": [
  null,
  "حدد الصف"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "قم بتشغيل هذا الأمر عبر شبكة موثوقة أوا مادياً على الجهاز البعيد:"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "مفتاح SSH"
 ],
 "SSH key login": [
  null,
  "تسجيل دخول عبر مفتاح SSH"
 ],
 "SSH keys": [
  null,
  "مفاتيح SSH"
 ],
 "Safari users need to import and trust the certificate of the self-signing CA:": [
  null,
  "يحتاج مستخدمو Safari إلى استيراد شهادة المرجع المصدق المرجعي المصدق (CA) ذاتي التوقيع والثقة بها:"
 ],
 "Sealed-case PC": [
  null,
  "حاسوب شخصي مغلق"
 ],
 "Search": [
  null,
  "ابحث"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "إعداد نظام Linux المحسّن للأمان واستكشاف الأخطاء وإصلاحها"
 ],
 "Select": [
  null,
  "تحديد"
 ],
 "Select an option": [
  null,
  "تحديد خيار"
 ],
 "Server has closed the connection.": [
  null,
  "قام الخادم بإغلاق الاتصال."
 ],
 "Session": [
  null,
  "الجلسة"
 ],
 "Session is about to expire": [
  null,
  "الجلسة قاربت على الانتهاء"
 ],
 "Set": [
  null,
  "تعيين"
 ],
 "Set time": [
  null,
  "تعيين الوقت"
 ],
 "Shell script": [
  null,
  "سكريبت شِل"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show confirmation password": [
  null,
  "إظهار تأكيد كلمة السر"
 ],
 "Show password": [
  null,
  "أظهر كلمة السر"
 ],
 "Shut down": [
  null,
  "أوقف التشغيل"
 ],
 "Single rank": [
  null,
  "رتبة واحدة"
 ],
 "Skip main navigation": [
  null,
  "تخطي التنقل الرئيسي"
 ],
 "Skip to content": [
  null,
  "التخطي إلى المحتوى"
 ],
 "Space-saving computer": [
  null,
  "حاسوب موفر للمساحة"
 ],
 "Specific time": [
  null,
  "الوقت المحدد"
 ],
 "Stick PC": [
  null,
  "حاسوب عصا"
 ],
 "Stop editing hosts": [
  null,
  "إيقاف تعديل المضيفين"
 ],
 "Storage": [
  null,
  "التخزين"
 ],
 "Strong password": [
  null,
  "كلمة سر قوية"
 ],
 "Style": [
  null,
  "مظهر"
 ],
 "Sub-Chassis": [
  null,
  "الهيكل الفرعي"
 ],
 "Sub-Notebook": [
  null,
  "دفتر ملاحظات فرعي"
 ],
 "Switch to administrative access": [
  null,
  "التبديل إلى الوصول الإداري"
 ],
 "Switch to limited access": [
  null,
  "التبديل إلى الوصول محدود الصلاحيات"
 ],
 "Synchronized": [
  null,
  "متزامن"
 ],
 "Synchronized with $0": [
  null,
  "متزامن مع $0"
 ],
 "Synchronizing": [
  null,
  "جار المزامنة"
 ],
 "System": [
  null,
  "النظام"
 ],
 "Tablet": [
  null,
  "جهاز لوحي"
 ],
 "The IP address or hostname cannot contain whitespace.": [
  null,
  "لا يمكن أن يحتوي عنوان IP أو اسم المضيف على مسافات بيضاء."
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "سيتم إضافة مفتاح SSH $0 الخاص بـ $1 على $2 إلى ملف $3 الخاص بـ $4 على $5."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "سيكون مفتاح SSH $0 متاحًا لبقية الجلسة وسيكون متاحًا لتسجيل الدخول إلى مضيفين آخرين أيضًا."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "مفتاح SSH لتسجيل الدخول إلى $0 محمي بكلمة سر، ولا يسمح المضيف بتسجيل الدخول بكلمة سر. يرجى تقديم كلمة سر المفتاح في $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "مفتاح SSH لتسجيل الدخول إلى $0 محمي. يمكنك تسجيل الدخول إما باستخدام كلمة سر تسجيل الدخول الخاصة بك أو عن طريق توفير كلمة سر المفتاح في $1."
 ],
 "The fingerprint should match:": [
  null,
  "ينبغي أن تتطابق البصمة:"
 ],
 "The key password can not be empty": [
  null,
  "مفتاح كلمة السر لا يمكن أن يكون فارغاً"
 ],
 "The key passwords do not match": [
  null,
  "كلمات المرور الرئيسية غير متطابقة"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "لا يُسمح للمستخدم الذي قام بتسجيل الدخول بعرض تعديلات النظام"
 ],
 "The machine is rebooting": [
  null,
  "تتم إعادة تشغيل الجهاز"
 ],
 "The new key password can not be empty": [
  null,
  "مفتاح كلمة السر الجديد لا ينكن أن يكون فارغاً"
 ],
 "The password can not be empty": [
  null,
  "كلمة السر لا بمكن أن تكون فارغة"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "لا بأس بمشاركة البصمة الناتجة عبر الطرق العامة، بما في ذلك البريد الإلكتروني."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "بصمة المفتاح الناتجة آمنة للمشاركة عبر قنوات عامة، بما في ذلك البريد الإلكتروني."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "رفض الخادم المصادقة بأي طريقة مدعومة."
 ],
 "There are currently no active pages": [
  null,
  "لا توجد صفحات نشطة حاليًا"
 ],
 "There was an unexpected error while connecting to the machine.": [
  null,
  "حدث خطأ غير متوقع أثناء الاتصال بالجهاز."
 ],
 "This machine has already been added.": [
  null,
  "تمت إضافة هذه الآلة بالفعل."
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "تقوم هذه الأداة بتكوين سياسة SELinux ويمكن أن تساعد في فهم انتهاكاتها وحلها."
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "تُهيئ هذه الأداة النظام لكتابة تفريغ أعطاب نواة النظام. وهي تدعم أهداف التفريغ التالية: \"محلي\" (على القرص)، و\"ssh\"، و\"nfs\"."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "تقوم هذه الأداة بإنشاء أرشيف يحتوي على معلومات الإعدادات والتشخيص من نظام التشغيل الذي يكون قيد العمل. قد يتم تخزين الأرشيف محليًا أو مركزيًا لأغراض التسجيل أو التتبع، أو إرساله إلى ممثلي الدعم الفني أو المطورين أو مسؤولي النظام اعدة في تحديد الأعطال ‌الفنية ، وتصحيح الأخطاء."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "تُدير هذه الأداة التخزين المحلي، بما في ذلك أنظمة الملفات، ومجموعات وحدات التخزين LVM2، ونقاط تركيب NFS."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "تُدير هذه الأداة الشبكات بما في ذلك الوصلات المجمعة (Bonds)، والجسور (Bridges)، وفرق الشبكات (Teams)، وشبكات VLAN، والجدران النارية، باستخدام NetworkManager وFirewalld. يُذكر أن NetworkManager غير متوافق مع نظام systemd-networkd الافتراضي في أوبونتو ونصوص ifupdown في دبيان."
 ],
 "This will allow you to log in without password in the future.": [
  null,
  "سيسمح لك ذلك بتسجيل الدخول بدون كلمة سر في المستقبل."
 ],
 "Time zone": [
  null,
  "المنطقة الزمنية"
 ],
 "Tip: Make your key password match your login password to automatically authenticate against other systems.": [
  null,
  "نصيحة: اجعل كلمة سر المفتاح تتطابق وكلمة سر تسجيل الدخول للمصادقة تلقائياً على الأنظمة الأخرى."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "لضمان عدم اعتراض اتصالك من قِبَل طرف ثالث ضار، يُرجى التحقق من بَصمة مفتاح الخادم:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "للتحقق من البصمة ، قم بتشغيل ما يلي على $0 أثناء تشغيل الجهاز أو من خلال شبكة موثوقة:"
 ],
 "Toggle": [
  null,
  "تبديل"
 ],
 "Toggle date picker": [
  null,
  "إخفاء منتقي التاريخ و الوقت"
 ],
 "Too much data": [
  null,
  "الكثير من البيانات"
 ],
 "Tools": [
  null,
  "الأدوات"
 ],
 "Total size: $0": [
  null,
  "الحجم الإجمالي: $0"
 ],
 "Tower": [
  null,
  "برج"
 ],
 "Trust and add host": [
  null,
  "الثقة بالمضيف وإضافته"
 ],
 "Trying to synchronize with $0": [
  null,
  "محاولة المزامنة مع $0"
 ],
 "Turn on administrative access": [
  null,
  "فعّل الوصول الإداري"
 ],
 "Type": [
  null,
  "النوع"
 ],
 "Unable to contact $0.": [
  null,
  "تعذر الاتصال بـ $0."
 ],
 "Unable to contact the given host $0. Make sure it has ssh running on port $1, or specify another port in the address.": [
  null,
  "تعذر الاتصال بالمضيف المحدد $0. تأكد من تشغيل ssh على المنفذ $1، أو حدد منفذًا آخر في العنوان."
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "تعذّر تسجيل الدخول إلى $0 باستخدام مصادقة مفتاح SSH. يرجى إدخال كلمة السر."
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password. You may want to set up your SSH keys for automatic login.": [
  null,
  "تعذر تسجيل الدخول إلى $0 باستخدام مصادقة مفتاح SSH. يرجى تقديم كلمة السر. قد ترغب في إعداد مفاتيح SSH لتسجيل الدخول التلقائي."
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "تعذّر تسجيل الدهول إلى $0. لا يقبل المضيف تسجيل الدخول بكلمة سر ، أو أي من مفاتيح SSH الخاصة بك."
 ],
 "Unexpected error": [
  null,
  "خطأ غير متوقع"
 ],
 "Unknown": [
  null,
  "غير معروف"
 ],
 "Unknown host: $0": [
  null,
  "مضيف غير معروف: $0"
 ],
 "Unlock": [
  null,
  "ألغِ القفل"
 ],
 "Unlock key $0": [
  null,
  "إلغِ قفل المتفاح $0"
 ],
 "Untrusted host": [
  null,
  "مضيف غير موثوق به"
 ],
 "Update": [
  null,
  "تحديث"
 ],
 "Use key": [
  null,
  "استخدام مفتاحاَ"
 ],
 "Use the following keys to authenticate against other systems": [
  null,
  "استخدم المفاتيح التالية للمصادقة مع الأنظمة الأُخرى"
 ],
 "User name": [
  null,
  "اسم المستخدِم"
 ],
 "Verify fingerprint": [
  null,
  "أكّد البصمة"
 ],
 "View all logs": [
  null,
  "عرض جميع السجلات"
 ],
 "View automation script": [
  null,
  "عرض سكربت الأتمتة"
 ],
 "Visit firewall": [
  null,
  "زر الجدار الناري"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "ينتظر انتهاء عمليات مدير البرامج الآخر"
 ],
 "Weak password": [
  null,
  "كلمة سر ضعيفة"
 ],
 "Web Console": [
  null,
  "وحدة تحكم الويب"
 ],
 "Web Console for Linux servers": [
  null,
  "وحدة تحكم الويب لخوادم Linux"
 ],
 "Web console logo": [
  null,
  "شعار وحدة تحكم الويب"
 ],
 "When empty, connect with the current user": [
  null,
  "عندما تكون فارغة، اتصل بالمستخدم الحالي"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "انت تتصل بـ $0 لأول مرة."
 ],
 "You have been logged out due to inactivity.": [
  null,
  "لقد تم تسجيل خروجك بسبب عدم النشاط."
 ],
 "You may want to change the password of the key for automatic login.": [
  null,
  "قد ترغب في تغيير كلمة سر المفتاح لتسجيل الدخول التلقائي."
 ],
 "You now have administrative access.": [
  null,
  "لديك الآن حق الوصول الإداري."
 ],
 "You will be logged out in $0 seconds.": [
  null,
  "سيتم تسجيل خروجك خلال $0 ثانية."
 ],
 "You will be reminded once per session.": [
  null,
  "سيتم تذكيرك مرة واحدة في كل جلسة."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "لا يسمح متصفحك باللصق من قائمة السياق. يمكنك استخدام Shift+Insert."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "سيتذكر متصفحك مستوى وصولك عبر الجلسات."
 ],
 "Your session has been terminated.": [
  null,
  "تم إنهاء جلستك."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "انتهت صلاحية جلستك , يرجى تسجيل الدخول مرة أخرى."
 ],
 "Zone": [
  null,
  "المنطقة"
 ],
 "[binary data]": [
  null,
  "[بيانات ثنائية]"
 ],
 "[no data]": [
  null,
  "[لا بيانات]"
 ],
 "active": [
  null,
  "نشِط"
 ],
 "in less than a minute": [
  null,
  "في أقل من دقيقة"
 ],
 "in most browsers": [
  null,
  "في أغلب المتصفحات"
 ],
 "less than a minute ago": [
  null,
  "منذ أقل من دقيقة"
 ],
 "password quality": [
  null,
  "جودة كلمة السر"
 ],
 "show less": [
  null,
  "عرض أقل"
 ],
 "show more": [
  null,
  "عرض أكثر"
 ]
});
