cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "ko",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 day": [
  null,
  "$0 일"
 ],
 "$0 documentation": [
  null,
  "$0 문서"
 ],
 "$0 exited with code $1": [
  null,
  "$0가 코드 $1로 종료됨"
 ],
 "$0 failed": [
  null,
  "$0 실패"
 ],
 "$0 hour": [
  null,
  "$0 시"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 는 저장소에서 사용 할 수 없습니다."
 ],
 "$0 key changed": [
  null,
  "$0 키 변경됩니다"
 ],
 "$0 killed with signal $1": [
  null,
  "$1 시그널에 의해 $0 가 종료되었습니다"
 ],
 "$0 minute": [
  null,
  "$0 분"
 ],
 "$0 month": [
  null,
  "$0 달"
 ],
 "$0 week": [
  null,
  "$0 주"
 ],
 "$0 will be installed.": [
  null,
  "$0 가 설치됩니다."
 ],
 "$0 year": [
  null,
  "$0 년"
 ],
 "1 day": [
  null,
  "1 일"
 ],
 "1 hour": [
  null,
  "1시간"
 ],
 "1 minute": [
  null,
  "1 분"
 ],
 "1 week": [
  null,
  "1 주"
 ],
 "20 minutes": [
  null,
  "20분"
 ],
 "40 minutes": [
  null,
  "40 분"
 ],
 "5 minutes": [
  null,
  "5분"
 ],
 "6 hours": [
  null,
  "6 시간"
 ],
 "60 minutes": [
  null,
  "60 분"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "호환 가능한 Cockpit 버전이 $0 에서 설치되지 않았습니다."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "$0 에서 신규 SSH 키는 $1 에서($2 에 대해) 생성되고 $3 파일($4 의($5 에 대한))에 추가됩니다."
 ],
 "About Web Console": [
  null,
  "웹 콘솔 정보"
 ],
 "Absent": [
  null,
  "부재"
 ],
 "Acceptable password": [
  null,
  "허용되는 비밀번호"
 ],
 "Active pages": [
  null,
  "활성 페이지"
 ],
 "Add": [
  null,
  "추가"
 ],
 "Add $0": [
  null,
  "$0 추가"
 ],
 "Add key": [
  null,
  "키 추가"
 ],
 "Add new host": [
  null,
  "신규 호스트 추가"
 ],
 "Additional packages:": [
  null,
  "추가 꾸러미 :"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Cockpit 웹 콘솔로 관리"
 ],
 "Administrative access": [
  null,
  "관리 접근"
 ],
 "Advanced TCA": [
  null,
  "고급 TCA"
 ],
 "All-in-one": [
  null,
  "일체형"
 ],
 "Ansible": [
  null,
  "앤서블"
 ],
 "Ansible roles documentation": [
  null,
  "Ansible 역할 문서"
 ],
 "Apps": [
  null,
  "앱"
 ],
 "Authenticate": [
  null,
  "인증"
 ],
 "Authentication": [
  null,
  "인증"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Cockpit 웹 콘솔의 권한 작업을 수행하려면 인증이 필요합니다"
 ],
 "Authorize SSH key": [
  null,
  "SSH 키 승인"
 ],
 "Automatic login": [
  null,
  "자동 로그인"
 ],
 "Automatically using NTP": [
  null,
  "자동으로 NTP 사용"
 ],
 "Automatically using additional NTP servers": [
  null,
  "추가 NTP 서버를 자동으로 사용"
 ],
 "Automatically using specific NTP servers": [
  null,
  "특정 NTP 서버를 자동으로 사용"
 ],
 "Automation script": [
  null,
  "자동 스크립트"
 ],
 "Blade": [
  null,
  "블레이드"
 ],
 "Blade enclosure": [
  null,
  "블레이드 인클로저"
 ],
 "Bus expansion chassis": [
  null,
  "버스 확장 섀시"
 ],
 "By changing the password of the SSH key $0 to the login password of $1 on $2, the key will be automatically made available and you can log in to $3 without password in the future.": [
  null,
  "SSH 키 $0 의 비밀번호를 $1 의 ($2 에서) 로그인 비밀번호로 변경하면, 키가 자동으로 제공되며 추후 비밀번호 없이 $3 에 로그인 할 수 있습니다."
 ],
 "Can be a hostname, IP address, alias name, or ssh:// URI": [
  null,
  "호스트 이름, IP 주소, 별칭 이름 또는 ssh:// URI일 수 있습니다"
 ],
 "Cancel": [
  null,
  "취소"
 ],
 "Cannot connect to an unknown host": [
  null,
  "알 수 없는 호스트에 연결 할 수 없습니다"
 ],
 "Cannot forward login credentials": [
  null,
  "로그인 정보를 전송할 수 없습니다"
 ],
 "Cannot schedule event in the past": [
  null,
  "이전 이벤트를 예약할 수 없습니다"
 ],
 "Change": [
  null,
  "변경"
 ],
 "Change password": [
  null,
  "비밀번호 변경"
 ],
 "Change system time": [
  null,
  "시스템 시간 변경"
 ],
 "Change the password of $0": [
  null,
  "$0 의 비밀번호 변경"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "때때로 운영 체제 재설치로 인해 키가 변경될 수 있습니다. 그러나 예기치 않은 변경은 연결을 가로채는 타사의 시도를 나타낼 수도 있습니다."
 ],
 "Checking installed software": [
  null,
  "설치된 소프트웨어 확인 중"
 ],
 "Choose the language to be used in the application": [
  null,
  "응용프로그램에 사용 할 언어를 선택하세요"
 ],
 "Clear input value": [
  null,
  "입력 값 초기화"
 ],
 "Clear search": [
  null,
  "검색 지우기"
 ],
 "Close": [
  null,
  "닫기"
 ],
 "Close selected pages": [
  null,
  "선택한 페이지 닫기"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "NetworkManager 및 Firewalld의 Cockpit 구성"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit을 지정된 호스트에 연결 할 수 없습니다."
 ],
 "Cockpit had an unexpected internal error.": [
  null,
  "Cockpit에서 예기치 않은 내부 오류가 발생했습니다."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit은 웹 브라우저에서 리눅스 서버를 쉽게 관리 할 수 있는 서버 관리자입니다. 터미널과 웹 도구을 구분하지 않고 사용할 수 있습니다. Cockpit에서 시작된 서비스는 터미널을 통해 중지할 수 있습니다. 마찬가지로 터미널에서 오류가 발생한 경우 해당 오류를 Cockpit 저널 연결장치에서 확인 할 수 있습니다."
 ],
 "Cockpit is an interactive Linux server admin interface.": [
  null,
  "Cockpit은 대화형 리눅스 서버 관리 연결장치입니다."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit은 시스템의 소프트웨어와 호환성이 없습니다."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit이 설치되어 있지 않습니다"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "시스템에 Cockpit이 설치되어 있지 않습니다."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit은 경험이 적은 시스템 관리자에게 적합합니다. 시스템 관리자는 저장장치 관리, 저널 검사, 서비스 시작 및 중지 등의 간단한 작업을 쉽게 수행할 수 있으며 여러 서버를 동시에 모니터링 및 관리 할 수 있습니다. 간단하게 장비를 추가하여 서버를 추가할 수 있으며 추가 후 다른 기기를 관리할 수 있습니다."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "진단 및 지원 자료 수집 및 꾸러미"
 ],
 "Collect kernel crash dumps": [
  null,
  "커널 충돌 덤프 수집"
 ],
 "Color": [
  null,
  "색"
 ],
 "Comment": [
  null,
  "설명"
 ],
 "Compact PCI": [
  null,
  "PCI 압축"
 ],
 "Confirm key password": [
  null,
  "키 비밀빈호 확인"
 ],
 "Confirm new key password": [
  null,
  "신규 키 비밀번호 확인"
 ],
 "Confirm password": [
  null,
  "비밀번호 확인"
 ],
 "Connect": [
  null,
  "연결"
 ],
 "Connect to $0?": [
  null,
  "$0 에 연결?"
 ],
 "Connected hosts can fully control each other. This includes running programs that could harm your system or steal data. Only connect to trusted machines.": [
  null,
  "연결된 호스트는 완전히 각각 제어 할 수 있습니다. 이는 자신의 시스템에게 해가 되거나 자료를 훔치도록 동작 중인 프로그램을 포함합니다. 신뢰 할 수 있는 장비로만 연결하세요."
 ],
 "Connecting to the machine": [
  null,
  "장치에 연결 중입니다"
 ],
 "Connection error": [
  null,
  "연결 오류"
 ],
 "Connection failed": [
  null,
  "연결 실패"
 ],
 "Connection has timed out.": [
  null,
  "연결 시간 초과."
 ],
 "Contains:": [
  null,
  "포함:"
 ],
 "Continue session": [
  null,
  "세션 계속 진행"
 ],
 "Convertible": [
  null,
  "변환 가능"
 ],
 "Copied": [
  null,
  "복사됨"
 ],
 "Copy": [
  null,
  "복사"
 ],
 "Copy to clipboard": [
  null,
  "클립보드로 복사"
 ],
 "Could not contact $0": [
  null,
  "$0 에 연락 할 수 없습니다"
 ],
 "Create $0": [
  null,
  "$0 생성"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "신규 SSH 키를 생성하고 승인합니다"
 ],
 "Create new task file with this content.": [
  null,
  "이 컨텐츠로 신규 작업 파일을 만듭니다."
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Ctrl-Shift-I": [
  null,
  "Ctrl-Shift-I"
 ],
 "Dark": [
  null,
  "어둡게"
 ],
 "Default": [
  null,
  "기본"
 ],
 "Delay": [
  null,
  "지연"
 ],
 "Desktop": [
  null,
  "데스크탑"
 ],
 "Detachable": [
  null,
  "분리 가능"
 ],
 "Details": [
  null,
  "상세정보"
 ],
 "Diagnostic reports": [
  null,
  "진단 보고서"
 ],
 "Disconnected": [
  null,
  "연결 해제됩니다"
 ],
 "Display language": [
  null,
  "표시 언어"
 ],
 "Docking station": [
  null,
  "도킹 스테이션"
 ],
 "Downloading $0": [
  null,
  "$0 내려받기 중"
 ],
 "Dual rank": [
  null,
  "듀얼 랭크"
 ],
 "Edit": [
  null,
  "편집"
 ],
 "Edit host": [
  null,
  "호스트 편집"
 ],
 "Edit hosts": [
  null,
  "호스트 편집"
 ],
 "Embedded PC": [
  null,
  "임베디드 PC"
 ],
 "Excellent password": [
  null,
  "우수한 비밀번호"
 ],
 "Expansion chassis": [
  null,
  "확장 섀시"
 ],
 "Failed to add machine: $0": [
  null,
  "컴퓨터를 추가하지 못했습니다: $0"
 ],
 "Failed to change password": [
  null,
  "비밀번호 변경 실패"
 ],
 "Failed to edit machine: $0": [
  null,
  "컴퓨터를 편집하지 못했습니다: $0"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "방화벽에서 $0 활성화에 실패"
 ],
 "Filter menu items": [
  null,
  "필터 메뉴 항목"
 ],
 "Fingerprint": [
  null,
  "지문"
 ],
 "Go to now": [
  null,
  "지금 바로 가기"
 ],
 "Handheld": [
  null,
  "휴대용"
 ],
 "Help": [
  null,
  "도움말"
 ],
 "Hide confirmation password": [
  null,
  "확인 비밀번호 숨기기"
 ],
 "Hide password": [
  null,
  "비밀번호 숨기기"
 ],
 "Host": [
  null,
  "호스트"
 ],
 "Host key is incorrect": [
  null,
  "호스트 키가 잘못되었습니다"
 ],
 "Hosts": [
  null,
  "호스트"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "만약 지문이 일치하면, '키 ' 호스트 신뢰 및 추가'를 눌러주세요. 그렇지 않다면, 연결하지 않고 관리자에게 문의하세요."
 ],
 "In order to allow log in to $0 as $1 without password in the future, use the login password of $2 on $3 as the key password, or leave the key password blank.": [
  null,
  "추후 암호 없이 $0 에 $1 으로 로그인하려면, $2 의 $3 로그인 비밀번호를 키 암호로 사용하거나 키 비밀번호를 비워 두세요."
 ],
 "Install": [
  null,
  "설치"
 ],
 "Install software": [
  null,
  "소프트웨어 설치"
 ],
 "Installing $0": [
  null,
  "$0 설치 중"
 ],
 "Internal error": [
  null,
  "내부 오류"
 ],
 "Invalid date format": [
  null,
  "잘못된 날짜 형식"
 ],
 "Invalid date format and invalid time format": [
  null,
  "잘못된 날짜 형식 및 잘못된 시간 형식"
 ],
 "Invalid file permissions": [
  null,
  "잘못된 파일 권한"
 ],
 "Invalid time format": [
  null,
  "잘못된 시간 형식"
 ],
 "Invalid timezone": [
  null,
  "잘못된 시간대"
 ],
 "IoT gateway": [
  null,
  "IoT 게이트웨이"
 ],
 "Is sshd running on a different port?": [
  null,
  "다른 포트에서 sshd가 실행되고 있습니까?"
 ],
 "Kernel dump": [
  null,
  "커널 덤프"
 ],
 "Key password": [
  null,
  "키 비밀번호"
 ],
 "Laptop": [
  null,
  "랩탑"
 ],
 "Learn more": [
  null,
  "더 알아보기"
 ],
 "Licensed under GNU LGPL version 2.1": [
  null,
  "GNU LGPL 버전 2.1 하에서 인가됨"
 ],
 "Light": [
  null,
  "밝게"
 ],
 "Limit access": [
  null,
  "접근 제한"
 ],
 "Limited access": [
  null,
  "제한된 접근"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "제한된 접근 방식은 관리 권한을 제한합니다. 웹 콘솔의 일부 부분은 기능이 축소됩니다."
 ],
 "Loading packages...": [
  null,
  "꾸러미 적재 중..."
 ],
 "Loading system modifications...": [
  null,
  "시스템 수정 적재 중..."
 ],
 "Log in": [
  null,
  "로그인"
 ],
 "Log in to $0": [
  null,
  "$0 로 로그인"
 ],
 "Log messages": [
  null,
  "로그 메세지"
 ],
 "Log out": [
  null,
  "로그아웃"
 ],
 "Login failed": [
  null,
  "로그인 실패"
 ],
 "Low profile desktop": [
  null,
  "낮은 프로파일 데스크탑"
 ],
 "Lunch box": [
  null,
  "Lunch Box"
 ],
 "Main server chassis": [
  null,
  "메인 서버 섀시"
 ],
 "Malicious pages on a remote machine may affect other connected hosts": [
  null,
  "원격 장비에서 악성 부분은 다른 연결된 호스트에 영향을 미칠 수 있습니다"
 ],
 "Manage storage": [
  null,
  "관리 저장소"
 ],
 "Manually": [
  null,
  "수동"
 ],
 "Message to logged in users": [
  null,
  "로그인한 사용자에게 보내는 메세지"
 ],
 "Messages related to the failure might be found in the journal:": [
  null,
  "실행 실패와 관련된 메시지는 저널에서 찾을 수 있습니다:"
 ],
 "Method": [
  null,
  "방식"
 ],
 "Mini PC": [
  null,
  "미니 PC"
 ],
 "Mini tower": [
  null,
  "미니 타워"
 ],
 "Multi-system chassis": [
  null,
  "멀티 시스템 섀시"
 ],
 "NTP server": [
  null,
  "NTP 서버"
 ],
 "Name": [
  null,
  "이름"
 ],
 "Need at least one NTP server": [
  null,
  "최소 하나의 NTP 서버가 필요합니다"
 ],
 "Networking": [
  null,
  "네트워킹"
 ],
 "New host: $0": [
  null,
  "신규 호스트: $0"
 ],
 "New key password": [
  null,
  "신규 키 비밀번호"
 ],
 "New password": [
  null,
  "신규 비밀번호"
 ],
 "New password was not accepted": [
  null,
  "신규 비밀번호가 허용되지 않습니다"
 ],
 "No delay": [
  null,
  "지연 없음"
 ],
 "No languages match": [
  null,
  "일치하는 언어가 없습니다"
 ],
 "No results found": [
  null,
  "결과를 찾을 수 없습니다"
 ],
 "No such file or directory": [
  null,
  "이러한 파일 또는 디렉토리가 없습니다"
 ],
 "No system modifications": [
  null,
  "시스템 수정 없음"
 ],
 "Not a valid private key": [
  null,
  "유효한 개인 키가 없습니다"
 ],
 "Not connected to host": [
  null,
  "호스트에 연결되어 있지 않음"
 ],
 "Not permitted to perform this action.": [
  null,
  "이 작업을 실행할 수 있는 권한이 없습니다."
 ],
 "Not synchronized": [
  null,
  "동기화 되어 있지 않습니다"
 ],
 "Notebook": [
  null,
  "노트북"
 ],
 "Occurrences": [
  null,
  "발생"
 ],
 "Ok": [
  null,
  "확인"
 ],
 "Old password not accepted": [
  null,
  "이전 비밀번호가 허용되지 않습니다"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Cockpit이 설치되면 \"systemctl enable --now cockpit.socket\"을 사용하여 이를 활성화합니다."
 ],
 "Ooops!": [
  null,
  "어머나!"
 ],
 "Other": [
  null,
  "기타"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit가 충돌했습니다"
 ],
 "Page name": [
  null,
  "분야 이름"
 ],
 "Password": [
  null,
  "비밀번호"
 ],
 "Password changed successfully": [
  null,
  "비밀번호가 성공적으로 변경되었습니다"
 ],
 "Password is not acceptable": [
  null,
  "비밀번호가 허용되지 않습니다"
 ],
 "Password is too weak": [
  null,
  "비밀번호가 너무 취약합니다"
 ],
 "Password not accepted": [
  null,
  "비밀번호가 허용되지 않습니다"
 ],
 "Password tip": [
  null,
  "비밀번호 팁"
 ],
 "Paste": [
  null,
  "붙여넣기"
 ],
 "Paste error": [
  null,
  "붙임 오류"
 ],
 "Path to file": [
  null,
  "파일의 경로"
 ],
 "Peripheral chassis": [
  null,
  "주변 장치 섀시"
 ],
 "Pick date": [
  null,
  "날짜 선택"
 ],
 "Pizza box": [
  null,
  "피자 박스"
 ],
 "Please authenticate to gain administrative access": [
  null,
  "관리 접근 권한을 얻으려면 인증하세요"
 ],
 "Port": [
  null,
  "포트"
 ],
 "Portable": [
  null,
  "이동식"
 ],
 "Present": [
  null,
  "존재"
 ],
 "Problem becoming administrator": [
  null,
  "관리자에게서 발생한 문제"
 ],
 "Project website": [
  null,
  "프로젝트 웹사이트"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "ssh-add를 통한 메세지 제공 시간이 초과되었습니다"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "ssh-keygen을 통한 메세지 제공시간이 초과되었습니다"
 ],
 "Public key": [
  null,
  "공개 키"
 ],
 "RAID chassis": [
  null,
  "레이드 섀시"
 ],
 "Rack mount chassis": [
  null,
  "랙 적재 구조"
 ],
 "Read more": [
  null,
  "더 알아보기"
 ],
 "Reboot": [
  null,
  "재시작"
 ],
 "Reconnect": [
  null,
  "재연결"
 ],
 "Removals:": [
  null,
  "삭제:"
 ],
 "Remove": [
  null,
  "제거"
 ],
 "Removing $0": [
  null,
  "$0 삭제 중"
 ],
 "Row expansion": [
  null,
  "행 확장"
 ],
 "Row select": [
  null,
  "행 선택"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "신뢰하는 네트워크 또는 원격 장비에서 물리적으로 이와 같은 명령을 실행합니다:"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "SSH 키"
 ],
 "SSH key login": [
  null,
  "SSH 키 로그인"
 ],
 "SSH keys": [
  null,
  "SSH 키"
 ],
 "Safari users need to import and trust the certificate of the self-signing CA:": [
  null,
  "Safari 사용자는 자체 서명 CA 인증서를 가져와서 인증서를 신뢰해야 합니다:"
 ],
 "Sealed-case PC": [
  null,
  "쉴드 케이스 PC"
 ],
 "Search": [
  null,
  "검색"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "보안이 향상된 리눅스 구성과 문제해결"
 ],
 "Select": [
  null,
  "선택"
 ],
 "Select an option": [
  null,
  "옵션을 선택합니다"
 ],
 "Server has closed the connection.": [
  null,
  "서버 연결이 종료되었습니다."
 ],
 "Session": [
  null,
  "세션"
 ],
 "Session is about to expire": [
  null,
  "세션이 곧 만료됩니다"
 ],
 "Set": [
  null,
  "설정"
 ],
 "Set time": [
  null,
  "시간 설정"
 ],
 "Shell script": [
  null,
  "쉘 스크립트"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show confirmation password": [
  null,
  "비밀번호 확인을 표시합니다"
 ],
 "Show password": [
  null,
  "비밀번호 표시"
 ],
 "Shut down": [
  null,
  "종료"
 ],
 "Single rank": [
  null,
  "단일 등급"
 ],
 "Skip main navigation": [
  null,
  "기본 탐색 건너뛰기"
 ],
 "Skip to content": [
  null,
  "내용으로 건너뛰기"
 ],
 "Space-saving computer": [
  null,
  "공간-절약형 컴퓨터"
 ],
 "Specific time": [
  null,
  "특정 시간"
 ],
 "Stick PC": [
  null,
  "스틱 PC"
 ],
 "Stop editing hosts": [
  null,
  "호스트 편집 중지"
 ],
 "Storage": [
  null,
  "저장소"
 ],
 "Strong password": [
  null,
  "강력한 비밀번호"
 ],
 "Style": [
  null,
  "유형"
 ],
 "Sub-Chassis": [
  null,
  "서브 섀시"
 ],
 "Sub-Notebook": [
  null,
  "서브 노트북"
 ],
 "Switch to administrative access": [
  null,
  "관리자 접근으로 전환"
 ],
 "Switch to limited access": [
  null,
  "제한된 접근으로 전환"
 ],
 "Synchronized": [
  null,
  "동기화됩니다"
 ],
 "Synchronized with $0": [
  null,
  "$0 와 동기화됩니다"
 ],
 "Synchronizing": [
  null,
  "동기화 중"
 ],
 "System": [
  null,
  "시스템"
 ],
 "Tablet": [
  null,
  "테블릿"
 ],
 "The IP address or hostname cannot contain whitespace.": [
  null,
  "IP 주소 또는 호스트 이름에는 공백을 포함할 수 없습니다."
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "$1 의 SSH 키 $0 ($2 에서)는 $4 의 $3 ($5 에서)파일로 추가됩니다."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH 키 $0 는 세션의 나머지 부분에서 사용 할 수 있고 다른 호스트에 로그인 할 때에도 사용 할 수 있습니다."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "$0 에 로그인하기 위한 SSH 키가 비밀번호에 의해 보호되고 있으며, 그리고 호스트는 비밀번호로 로그인을 허용 하지 않습니다. $1 에서 키의 비밀번호를 제공하세요."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "$0 에 로그인하기 위해 SSH 키가 보호되고 있습니다. 당신은 $1 에서 자신의 로그인 비밀번호에 의하거나 키의 비밀번호 제공을 통해 로그인 할 수 있습니다.."
 ],
 "The fingerprint should match:": [
  null,
  "지문 표시가 일치해야 합니다:"
 ],
 "The key password can not be empty": [
  null,
  "키 비밀번호를 비워둘 수 없습니다"
 ],
 "The key passwords do not match": [
  null,
  "키 비밀번호가 일치하지 않습니다"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "로그인한 사용자는 시스템 수정 사항을 볼 수 없습니다"
 ],
 "The machine is rebooting": [
  null,
  "장치가 재시작되고 있습니다"
 ],
 "The new key password can not be empty": [
  null,
  "신규 키 비밀번호는 비워둘 수 없습니다"
 ],
 "The password can not be empty": [
  null,
  "비밀번호를 비워둘 수 없습니다"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "최종 지문을 전자우편을 포함한 공개적인 방법을 통해 공유 할 수 있습니다."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "결과 지문은 전자우편을 포함하는 공개 방식을 통해 공유되어도 해도 좋습니다. 만약 누군가 당신을 위해 인증하도록 요청하는 경우, 어떤 방식을 사용하든 결과를 전송 할 수 있습니다."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "서버가 지원되는 방법을 사용하여 인증을 거부했습니다."
 ],
 "There are currently no active pages": [
  null,
  "현재 활성화된 페이지가 없습니다"
 ],
 "There was an unexpected error while connecting to the machine.": [
  null,
  "기기에 연결하는 동안 예기치 않은 오류가 발생했습니다."
 ],
 "This machine has already been added.": [
  null,
  "이 컴퓨터는 이미 추가되어 있습니다."
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "이와 같은 도구는 SELinux 정책을 구성하고 정책 위반을 이해하고 해결하는데 도움을 줄 수 있습니다."
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "이와 같은 도구는 커널 충돌 덤프를 작성하도록 시스템을 구성합니다. 이는 \"로컬\" (디스크), \"ssh\" 및 \"nfs\" 덤프 대상을 지원합니다."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "이와 같은 도구는 동작 중인 시스템에서 구성 및 진단 정보의 아카이브를 생성합니다. 아카이브는 기록 또는 추적 목적으로 로컬 또는 집중적으로 저장되거나 기술적 오류-찾기와 디버깅을 지원하기 위해 기술 지원 담당자, 개발자 또는 시스템 관리자에게 보낼 수 있습니다."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "이와 같은 도구는 파일시스템, LVM2 볼륨 그룹, 그리고 NFS 적재와 같은 로컬 저장소를 관리합니다."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "이와 같은 도구는 NetworkManager 및 Firewalld를 사용하여 bonds, bridges, teams, VLAN과 방화벽과 같은 네트워킹을 관리합니다. NetworkManager는 우분투 기본 systemd-netowrkd 및 데비안의 ifupdown 스크립트와는 호환되지 않습니다."
 ],
 "This will allow you to log in without password in the future.": [
  null,
  "이를 통해 나중에 비밀번호 없이 로그인 할 수 있습니다."
 ],
 "Time zone": [
  null,
  "시간대"
 ],
 "Tip: Make your key password match your login password to automatically authenticate against other systems.": [
  null,
  "도움말: 다른 시스템에 자동으로 인증하려면 키 비밀번호가 로그인 비밀번호와 일치해야 합니다."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "악성의 제3자가 귀하의 연결을 가로채지 않도록 하려면 호스트 키 지문을 확인하십시오:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "지문을 확인하려면 물리적인 장치 또는 신뢰할 수 있는 네트워크를 통해 $0 에서 다음을 실행합니다:"
 ],
 "Toggle": [
  null,
  "전환"
 ],
 "Toggle date picker": [
  null,
  "날짜 선택기 전환"
 ],
 "Too much data": [
  null,
  "데이터가 너무 많습니다"
 ],
 "Tools": [
  null,
  "도구"
 ],
 "Total size: $0": [
  null,
  "전체 크기: $0"
 ],
 "Tower": [
  null,
  "타워"
 ],
 "Trust and add host": [
  null,
  "호스트 신뢰 및 추가"
 ],
 "Trying to synchronize with $0": [
  null,
  "$0 와 동기화를 시도 중입니다"
 ],
 "Turn on administrative access": [
  null,
  "관리자 접근 설정"
 ],
 "Type": [
  null,
  "유형"
 ],
 "Unable to contact $0.": [
  null,
  "$0 를 연락 할 수 없음."
 ],
 "Unable to contact the given host $0. Make sure it has ssh running on port $1, or specify another port in the address.": [
  null,
  "지정된 호스트 $0 에 연결할 수 없습니다. 포트 $1 에서 ssh가 실행되고 있는지 확인하거나 주소에서 다른 포트를 지정합니다."
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "SSH 키 인증을 사용하여 $0 에 로그인 할 수 없습니다. 비밀번호를 입력하세요."
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password. You may want to set up your SSH keys for automatic login.": [
  null,
  "SSH 키 인증을 사용하여 $0 에 로그인 할 수 없습니다. 비밀번호를 입력하세요. 자동 로그인을 위해 자신의 SSH 키를 설정 할 수 있습니다."
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "$0 에 로그인 할 수 없습니다. 호스트는 비밀번호 로그인 또는 자신의 SSH 키를 허용하지 않습니다."
 ],
 "Unexpected error": [
  null,
  "예상치 못한 오류"
 ],
 "Unknown": [
  null,
  "알 수 없음"
 ],
 "Unknown host: $0": [
  null,
  "알 수 없는 호스트: $0"
 ],
 "Unlock": [
  null,
  "잠금 해제"
 ],
 "Unlock key $0": [
  null,
  "키 $0 잠금 해제"
 ],
 "Untrusted host": [
  null,
  "지원되지 않는 호스트"
 ],
 "Update": [
  null,
  "최신화"
 ],
 "Use key": [
  null,
  "키 사용"
 ],
 "Use the following keys to authenticate against other systems": [
  null,
  "다른 시스템에 대해 인증하려면 다음 키를 사용합니다"
 ],
 "User name": [
  null,
  "사용자 이름"
 ],
 "Verify fingerprint": [
  null,
  "지문 검증"
 ],
 "View all logs": [
  null,
  "모든 기록 보기"
 ],
 "View automation script": [
  null,
  "자동 스크립트 보기"
 ],
 "Visit firewall": [
  null,
  "방화벽 방문"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "다른 소프트웨어 관리 작업이 완료될 때 까지 대기 중"
 ],
 "Weak password": [
  null,
  "취약한 비밀번호"
 ],
 "Web Console": [
  null,
  "웹 콘솔"
 ],
 "Web Console for Linux servers": [
  null,
  "리눅스 서버를 위한 웹콘솔"
 ],
 "Web console logo": [
  null,
  "웹 콘솔 로고"
 ],
 "When empty, connect with the current user": [
  null,
  "비어 있는 경우 현재 사용자와 연결합니다"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "처음으로 $0 에 연결됩니다."
 ],
 "You have been logged out due to inactivity.": [
  null,
  "비활성 상태로 인해 로그 아웃되었습니다."
 ],
 "You may want to change the password of the key for automatic login.": [
  null,
  "자동 로그인을 위해 키 비밀번호를 변경 할 수 있습니다."
 ],
 "You now have administrative access.": [
  null,
  "이제 관리자 접근 권한이 있습니다."
 ],
 "You will be logged out in $0 seconds.": [
  null,
  "$0 초 후에 로그 아웃됩니다."
 ],
 "You will be reminded once per session.": [
  null,
  "세션당 한 번씩 알림을 받습니다."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "당신의 검색기는 내용 메뉴에서 붙여넣기를 허용하지 않습니다. Shift+Insert를 사용 할 수 있습니다."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "당신의 검색기는 세션을 통해 자신의 접근 수준을 기억합니다."
 ],
 "Your session has been terminated.": [
  null,
  "세션이 종료되었습니다."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "세션이 만료되었습니다. 다시 로그인하십시오."
 ],
 "Zone": [
  null,
  "영역"
 ],
 "[binary data]": [
  null,
  "[바이너리 데이터]"
 ],
 "[no data]": [
  null,
  "[데이터 없음]"
 ],
 "active": [
  null,
  "활성"
 ],
 "in less than a minute": [
  null,
  "1분도 안되어"
 ],
 "in most browsers": [
  null,
  "대부분의 브라우저에서"
 ],
 "less than a minute ago": [
  null,
  "1분도 채 지나지 않아"
 ],
 "password quality": [
  null,
  "비밀번호 수준"
 ],
 "show less": [
  null,
  "덜 보기"
 ],
 "show more": [
  null,
  "더 보기"
 ]
});
