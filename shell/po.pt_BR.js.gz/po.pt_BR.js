cockpit.locale({
 "": {
  "plural-forms": (n) => (n != 1),
  "language": "pt_BR",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 day": [
  null,
  "$0 dia",
  "$0 dias"
 ],
 "$0 documentation": [
  null,
  "Documentação de $0"
 ],
 "$0 exited with code $1": [
  null,
  "$0 foi encerrado com o código $1"
 ],
 "$0 failed": [
  null,
  "$0 falhou"
 ],
 "$0 hour": [
  null,
  "$0 hora",
  "$0 horas"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 não está disponível em nenhum repositório."
 ],
 "$0 key changed": [
  null,
  "$0 chave alterada"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 morto com sinal $1"
 ],
 "$0 minute": [
  null,
  "$0 minuto",
  "$0 minutos"
 ],
 "$0 month": [
  null,
  "$0 mês",
  "$0 meses"
 ],
 "$0 week": [
  null,
  "$0 semana",
  "$0 semanas"
 ],
 "$0 will be installed.": [
  null,
  "$0 será instalado."
 ],
 "$0 year": [
  null,
  "$0 ano",
  "$0 anos"
 ],
 "1 day": [
  null,
  "1 dia"
 ],
 "1 hour": [
  null,
  "1 hora"
 ],
 "1 minute": [
  null,
  "1 minuto"
 ],
 "1 week": [
  null,
  "1 semana"
 ],
 "20 minutes": [
  null,
  "20 minutos"
 ],
 "40 minutes": [
  null,
  "40 minutos"
 ],
 "5 minutes": [
  null,
  "5 minutos"
 ],
 "6 hours": [
  null,
  "6 horas"
 ],
 "60 minutes": [
  null,
  "60 minutos"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Uma versão compatível do Cockpit não está instalada em $0."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Uma nova chave SSH em $0 será criada por $1 em $2 e será adicionada ao arquivo $3 de $4 em $5."
 ],
 "About Web Console": [
  null,
  "Sobre o console web"
 ],
 "Absent": [
  null,
  "Ausente"
 ],
 "Acceptable password": [
  null,
  "Senha aceitável"
 ],
 "Active pages": [
  null,
  "Páginas ativas"
 ],
 "Add": [
  null,
  "Adicionar"
 ],
 "Add $0": [
  null,
  "Adicionar $0"
 ],
 "Add key": [
  null,
  "Adicionar chave"
 ],
 "Add new host": [
  null,
  "Adicionar novo host"
 ],
 "Additional packages:": [
  null,
  "Pacotes adicionais:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Administração com o Console Web do Cockpit"
 ],
 "Administrative access": [
  null,
  "Acesso administrativo"
 ],
 "Advanced TCA": [
  null,
  "TCA avançado"
 ],
 "All-in-one": [
  null,
  "All-in-one"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Documentação de papéis do Ansible"
 ],
 "Apps": [
  null,
  "Apps"
 ],
 "Authenticate": [
  null,
  "Autenticar"
 ],
 "Authentication": [
  null,
  "Autenticação"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Autenticação é necessária para executar ações privilegiadas no Console Web do Cockpit"
 ],
 "Authorize SSH key": [
  null,
  "Autorizar chave SSH"
 ],
 "Automatic login": [
  null,
  "Login automático"
 ],
 "Automatically using NTP": [
  null,
  "Usando automaticamente o NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Usando automaticamente servidores NTP adicionais"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Usando automaticamente servidores NTP específicos"
 ],
 "Automation script": [
  null,
  "Script de automação"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Invólucro da lâmina"
 ],
 "Bus expansion chassis": [
  null,
  "Chassi de Expansão de Barramento"
 ],
 "By changing the password of the SSH key $0 to the login password of $1 on $2, the key will be automatically made available and you can log in to $3 without password in the future.": [
  null,
  "Ao alterar a senha da chave SSH $0 para a senha de login de $1 em $2, a chave será automaticamente disponibilizada e você poderá fazer login em $3 sem senha no futuro."
 ],
 "Can be a hostname, IP address, alias name, or ssh:// URI": [
  null,
  "Pode ser um nome de host, endereço IP, nome de alias ou URI ssh://"
 ],
 "Cancel": [
  null,
  "Cancelar"
 ],
 "Cannot connect to an unknown host": [
  null,
  "Não é possível conectar a um host desconhecido"
 ],
 "Cannot forward login credentials": [
  null,
  "Não é possível prosseguir com as credenciais de login"
 ],
 "Cannot schedule event in the past": [
  null,
  "Não é possível agendar eventos no passado"
 ],
 "Change": [
  null,
  "Alterar"
 ],
 "Change password": [
  null,
  "Alterar Senha"
 ],
 "Change system time": [
  null,
  "Alterar Horário do Sistema"
 ],
 "Change the password of $0": [
  null,
  "Altere a senha de $0"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "As chaves alteradas frequentemente são resultado de uma reinstalação do sistema operacional. No entanto, uma alteração inesperada pode indicar uma tentativa de terceiros de interceptar sua conexão."
 ],
 "Checking installed software": [
  null,
  "Verificando o software instalado"
 ],
 "Choose the language to be used in the application": [
  null,
  "Escolha o idioma a ser usado no aplicativo"
 ],
 "Clear input value": [
  null,
  "Limpar valor inserido"
 ],
 "Clear search": [
  null,
  "Limpar pesquisa"
 ],
 "Close": [
  null,
  "Fechar"
 ],
 "Close selected pages": [
  null,
  "Fechar Páginas Selecionadas"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Configuração do cockpit do NetworkManager e Firewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "O Cockpit não poderia entrar em contato com o host fornecido."
 ],
 "Cockpit had an unexpected internal error.": [
  null,
  "Cockpit teve um erro interno inesperado."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit é um gerenciador de Servidores que facilita a tarefa de administrar seu servidor Linux via navegador web. Alternar entre o terminal e a ferramenta web, não é dif[icil. Um serviço pode ser iniciado pelo Cockpit e finalizado pelo Terminal. Da mesma forma, se um erro ocorrer no terminal, este pode ser detectado via interface do Cockpit."
 ],
 "Cockpit is an interactive Linux server admin interface.": [
  null,
  "Cockpit é uma interface interativa de administração de servidor Linux."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "O Cockpit não é compatível com o software no sistema."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit não está instalado"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit não está instalado no sistema."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit é perfeito para novos administradores de sistemas, permitindo-lhes facilmente realizar tarefas simples, como a administração de armazenamento, inspecionando logs e iniciar/parar serviços. É possível monitorar e administrar vários servidores ao mesmo tempo. Basta adicioná-los com um único clique e suas máquinas vão cuidar de seus companheiros."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Coletar e empacotar dados de diagnóstico e suporte"
 ],
 "Collect kernel crash dumps": [
  null,
  "Coletar despejos de travamento de kernel"
 ],
 "Color": [
  null,
  "Cor"
 ],
 "Comment": [
  null,
  "Comentário"
 ],
 "Compact PCI": [
  null,
  "Compacto PCI"
 ],
 "Confirm key password": [
  null,
  "Confirme a senha da chave"
 ],
 "Confirm new key password": [
  null,
  "Confirme a nova senha da chave"
 ],
 "Confirm password": [
  null,
  "Confirme a senha"
 ],
 "Connect": [
  null,
  "Conectar"
 ],
 "Connect to $0?": [
  null,
  "Conectar à $0?"
 ],
 "Connected hosts can fully control each other. This includes running programs that could harm your system or steal data. Only connect to trusted machines.": [
  null,
  "Os hosts conectados podem controlar totalmente uns aos outros. Isso inclui a execução de programas que podem danificar seu sistema ou roubar dados. Conecte-se apenas a computadores confiáveis."
 ],
 "Connecting to the machine": [
  null,
  "Conectando a máquina"
 ],
 "Connection error": [
  null,
  "Erro de Conexão"
 ],
 "Connection failed": [
  null,
  "Conexão falhou"
 ],
 "Connection has timed out.": [
  null,
  "A conexão expirou."
 ],
 "Contains:": [
  null,
  "Contém:"
 ],
 "Continue session": [
  null,
  "Continuar sessão"
 ],
 "Convertible": [
  null,
  "Conversível"
 ],
 "Copied": [
  null,
  "Copiado"
 ],
 "Copy": [
  null,
  "Copiar"
 ],
 "Copy to clipboard": [
  null,
  "Copiar para área de transferência"
 ],
 "Could not contact $0": [
  null,
  "Não foi possível contatar $0"
 ],
 "Create $0": [
  null,
  "Criar $0"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Criar uma nova chave SSH e autorizá-la"
 ],
 "Create new task file with this content.": [
  null,
  "Crie um novo arquivo de tarefa com esse conteúdo."
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Ctrl-Shift-I": [
  null,
  "Ctrl-Shift-I"
 ],
 "Dark": [
  null,
  "Escuro"
 ],
 "Default": [
  null,
  "Padrão"
 ],
 "Delay": [
  null,
  "Atraso"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Detachable": [
  null,
  "Destacável"
 ],
 "Details": [
  null,
  "Detalhes"
 ],
 "Diagnostic reports": [
  null,
  "Relatório de diagnostico"
 ],
 "Disconnected": [
  null,
  "Desconectado"
 ],
 "Display language": [
  null,
  "Idioma de exibição"
 ],
 "Docking station": [
  null,
  "Estação de ancoragem"
 ],
 "Downloading $0": [
  null,
  "Baixando $0"
 ],
 "Dual rank": [
  null,
  "Dual rank"
 ],
 "Edit": [
  null,
  "Editar"
 ],
 "Edit host": [
  null,
  "Editar host"
 ],
 "Edit hosts": [
  null,
  "Editar hosts"
 ],
 "Embedded PC": [
  null,
  "PC integrado"
 ],
 "Excellent password": [
  null,
  "Senha excelente"
 ],
 "Expansion chassis": [
  null,
  "Chassi de Expansão"
 ],
 "Failed to add machine: $0": [
  null,
  "Falha ao adicionar a máquina: $0"
 ],
 "Failed to change password": [
  null,
  "Falha ao mudar senha"
 ],
 "Failed to edit machine: $0": [
  null,
  "Falha ao editar a máquina: $0"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Falha ao habilitar $0 no firewalld"
 ],
 "Filter menu items": [
  null,
  "Filtrar itens de menu"
 ],
 "Fingerprint": [
  null,
  "Digital"
 ],
 "Go to now": [
  null,
  "Ir para agora"
 ],
 "Handheld": [
  null,
  "Dispositivo portátil"
 ],
 "Help": [
  null,
  "Ajuda"
 ],
 "Hide confirmation password": [
  null,
  "Ocultar confirmação da senha"
 ],
 "Hide password": [
  null,
  "Ocultar senha"
 ],
 "Host": [
  null,
  "Máquina"
 ],
 "Host key is incorrect": [
  null,
  "Chave de Host incorreta"
 ],
 "Hosts": [
  null,
  "Hosts"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Se a impressão digital corresponder, clique em \"Confiar e adicionar host\". Caso contrário, não se conecte e entre em contato com o administrador."
 ],
 "In order to allow log in to $0 as $1 without password in the future, use the login password of $2 on $3 as the key password, or leave the key password blank.": [
  null,
  "Para permitir o login em $0 como $1 sem senha no futuro, use a senha de login de $2 em $3 como a senha principal ou deixe a senha principal em branco."
 ],
 "Install": [
  null,
  "Instalar"
 ],
 "Install software": [
  null,
  "Instalar o software"
 ],
 "Installing $0": [
  null,
  "Instalando $0"
 ],
 "Internal error": [
  null,
  "Erro interno"
 ],
 "Invalid date format": [
  null,
  "Formato de data inválido"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Formato de data inválido e formato de tempo inválido"
 ],
 "Invalid file permissions": [
  null,
  "Permissão de arquivos inválida"
 ],
 "Invalid time format": [
  null,
  "Formato de tempo inválido"
 ],
 "Invalid timezone": [
  null,
  "Fuso horário inválido"
 ],
 "IoT gateway": [
  null,
  "Gateway IoT"
 ],
 "Is sshd running on a different port?": [
  null,
  "O sshd está sendo executado em uma porta diferente?"
 ],
 "Kernel dump": [
  null,
  "Dump do kernel"
 ],
 "Key password": [
  null,
  "Nova senha"
 ],
 "Laptop": [
  null,
  "Laptop"
 ],
 "Learn more": [
  null,
  "Saiba mais"
 ],
 "Licensed under GNU LGPL version 2.1": [
  null,
  "Licenciada sob GNU LGPL versão 2.1"
 ],
 "Light": [
  null,
  "Claro"
 ],
 "Limit access": [
  null,
  "Limitar acesso"
 ],
 "Limited access": [
  null,
  "Acesso limitado"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "O modo de acesso limitado restringe os privilégios administrativos. Algumas partes do console web terão funcionalidade reduzida."
 ],
 "Loading packages...": [
  null,
  "Carregando pacotes..."
 ],
 "Loading system modifications...": [
  null,
  "Carregando modificações do sistema..."
 ],
 "Log in": [
  null,
  "Entrar"
 ],
 "Log in to $0": [
  null,
  "Iniciar sessão para $0"
 ],
 "Log messages": [
  null,
  "Mensagens de Log"
 ],
 "Log out": [
  null,
  "Log out"
 ],
 "Login failed": [
  null,
  "Falha ao logar"
 ],
 "Low profile desktop": [
  null,
  "Desktop de baixo perfil"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "Main server chassis": [
  null,
  "Chassi do Servidor Principal"
 ],
 "Malicious pages on a remote machine may affect other connected hosts": [
  null,
  "Páginas maliciosas em uma máquina remota podem afetar outros hosts conectados"
 ],
 "Manage storage": [
  null,
  "Gerenciar armazenamento"
 ],
 "Manually": [
  null,
  "Manualmente"
 ],
 "Message to logged in users": [
  null,
  "Mensagem para usuários logados"
 ],
 "Messages related to the failure might be found in the journal:": [
  null,
  "Mensagens relacionadas à falha podem ser encontradas no diário:"
 ],
 "Method": [
  null,
  "Método"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini torre"
 ],
 "Multi-system chassis": [
  null,
  "Chassi Multi-sistema"
 ],
 "NTP server": [
  null,
  "Servidor NTP"
 ],
 "Name": [
  null,
  "Nome"
 ],
 "Need at least one NTP server": [
  null,
  "Precisa de pelo menos um servidor NTP"
 ],
 "Networking": [
  null,
  "Rede"
 ],
 "New host: $0": [
  null,
  "Novo host: $0"
 ],
 "New password": [
  null,
  "Nova Senha"
 ],
 "New password was not accepted": [
  null,
  "Nova senha não foi aceita"
 ],
 "No delay": [
  null,
  "Sem Atraso"
 ],
 "No languages match": [
  null,
  ""
 ],
 "No results found": [
  null,
  "Nenhum resultado encontrado"
 ],
 "No such file or directory": [
  null,
  "Diretório ou arquivo não encontrado"
 ],
 "No system modifications": [
  null,
  "Nenhuma modificações no sistema"
 ],
 "Not a valid private key": [
  null,
  "Chave privada não válida"
 ],
 "Not permitted to perform this action.": [
  null,
  "Não é permitido executar esta ação."
 ],
 "Not synchronized": [
  null,
  "Não sincronizado"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Old password not accepted": [
  null,
  "Senha antiga não aceita"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Uma vez instalado o Cockpit, habilite-o com \"systemctl enable --now cockpit.socket\"."
 ],
 "Ooops!": [
  null,
  "Ooops!"
 ],
 "Other": [
  null,
  "De outros"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit caiu"
 ],
 "Page name": [
  null,
  "Nome da página"
 ],
 "Password": [
  null,
  "Senha"
 ],
 "Password is not acceptable": [
  null,
  "Senha não é aceitavél"
 ],
 "Password is too weak": [
  null,
  "Senha é muito fraca"
 ],
 "Password not accepted": [
  null,
  "Senha não aceita"
 ],
 "Paste": [
  null,
  "Colar"
 ],
 "Path to file": [
  null,
  "Caminho para o arquivo"
 ],
 "Peripheral chassis": [
  null,
  "Chassi Periférico"
 ],
 "Pick date": [
  null,
  ""
 ],
 "Pizza box": [
  null,
  "Servidor compacto"
 ],
 "Please authenticate to gain administrative access": [
  null,
  ""
 ],
 "Port": [
  null,
  "Porta"
 ],
 "Portable": [
  null,
  "Portatil"
 ],
 "Present": [
  null,
  "Presente"
 ],
 "Project website": [
  null,
  "Site do projeto"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "A solicitação via ssh-add expirou"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Solicitação via ssh-keygen expirou"
 ],
 "Public key": [
  null,
  "Chave Pública"
 ],
 "RAID chassis": [
  null,
  "Chassis do RAID"
 ],
 "Rack mount chassis": [
  null,
  "Chassis de montagem do Rack"
 ],
 "Read more": [
  null,
  "Leia mais"
 ],
 "Reboot": [
  null,
  "Reiniciar"
 ],
 "Reconnect": [
  null,
  "Reconectar"
 ],
 "Removals:": [
  null,
  "Remoções:"
 ],
 "Remove": [
  null,
  "Remover"
 ],
 "Removing $0": [
  null,
  "Removendo $0"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  ""
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "Chave SSH"
 ],
 "SSH keys": [
  null,
  "Chave SSH"
 ],
 "Safari users need to import and trust the certificate of the self-signing CA:": [
  null,
  ""
 ],
 "Sealed-case PC": [
  null,
  "PC com caixa vedada"
 ],
 "Search": [
  null,
  "Buscar"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  ""
 ],
 "Select": [
  null,
  "Selecione"
 ],
 "Server has closed the connection.": [
  null,
  "O servidor encerrou a conexão."
 ],
 "Session": [
  null,
  "Sessão"
 ],
 "Session is about to expire": [
  null,
  "A sessão está prestes a expirar"
 ],
 "Set": [
  null,
  "Definir"
 ],
 "Set time": [
  null,
  "Definir Tempo"
 ],
 "Shell script": [
  null,
  "Shell script"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show password": [
  null,
  "Exibir senha"
 ],
 "Shut down": [
  null,
  "Encerrar"
 ],
 "Single rank": [
  null,
  ""
 ],
 "Skip main navigation": [
  null,
  ""
 ],
 "Space-saving computer": [
  null,
  "Computador com economia de espaço"
 ],
 "Specific time": [
  null,
  "Tempo Específico"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "Stop editing hosts": [
  null,
  ""
 ],
 "Storage": [
  null,
  "Armazenamento"
 ],
 "Style": [
  null,
  ""
 ],
 "Sub-Chassis": [
  null,
  "Sub chassis"
 ],
 "Sub-Notebook": [
  null,
  "Sub notebook"
 ],
 "Switch to limited access": [
  null,
  ""
 ],
 "Synchronized": [
  null,
  "Sincronizado"
 ],
 "Synchronized with $0": [
  null,
  "Sincronizado com $0"
 ],
 "Synchronizing": [
  null,
  "Sincronizando"
 ],
 "System": [
  null,
  "Sistema"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "The IP address or hostname cannot contain whitespace.": [
  null,
  "O endereço IP ou nome do host não podem conter espaços."
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  ""
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  ""
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  ""
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  ""
 ],
 "The fingerprint should match:": [
  null,
  "A impressão digital deve corresponder a:"
 ],
 "The key password can not be empty": [
  null,
  "A senha da chave não pode estar vazia"
 ],
 "The key passwords do not match": [
  null,
  "As senhas da chave não coincidem"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  ""
 ],
 "The machine is rebooting": [
  null,
  "A máquina esta reiniciando"
 ],
 "The new key password can not be empty": [
  null,
  "A nova senha da chave não pode estar vazia"
 ],
 "The password can not be empty": [
  null,
  "A senha não pode estar vazia"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "A impressão digital resultante pode ser compartilhada por métodos públicos, incluindo e-mail."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "A impressão digital resultante pode ser compartilhada por métodos públicos, incluindo e-mail. Se você estiver pedindo para outra pessoa fazer a verificação para você, ela pode enviar os resultados usando qualquer método."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "O servidor se recusou a autenticar usando quaisquer métodos suportados."
 ],
 "There are currently no active pages": [
  null,
  "Atualmente não há páginas ativas"
 ],
 "There was an unexpected error while connecting to the machine.": [
  null,
  "Ocorreu um erro inesperado enquanto conectava-se à máquina."
 ],
 "This machine has already been added.": [
  null,
  "Esta máquina já foi adicionada."
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Esta ferramenta configura a política do SELinux e pode ajudar a entender e resolver violações de política."
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Esta ferramenta configura o sistema para escrever kernel crash dumps. Ela suporta os alvos de dump \"local\" (disco), \"ssh\" e \"nfs\"."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Esta ferramenta gera um arquivo de informações de configuração e diagnóstico do sistema em execução. O arquivo pode ser armazenado localmente ou centralmente para fins de registro ou rastreamento ou pode ser enviado a representantes de suporte técnico, desenvolvedores ou administradores de sistema para auxiliar na detecção de falhas técnicas e depuração."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Esta ferramenta gerencia armazenamento local, como sistemas de arquivos, grupos de volumes LVM2 e montagens NFS."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Esta ferramenta gerencia redes como vínculos, pontes, times, VLANs e firewalls usando NetworkManager e Firewalld. O NetworkManager é incompatível com o systemd-networkd padrão do Ubuntu e os scripts ifupdown do Debian."
 ],
 "This will allow you to log in without password in the future.": [
  null,
  "Isso permitirá que você faça login sem senha no futuro."
 ],
 "Time zone": [
  null,
  "Fuso Horário"
 ],
 "Tip: Make your key password match your login password to automatically authenticate against other systems.": [
  null,
  "Dica: faça a sua senha de chave corresponder à sua senha de login para autenticar automaticamente contra outros sistemas."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Para garantir que sua conexão não seja interceptada por terceiros mal-intencionados, verifique a impressão digital da chave do host:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Para verificar uma impressão digital, execute o seguinte em $0 enquanto estiver fisicamente sentado na máquina ou por meio de uma rede confiável:"
 ],
 "Toggle": [
  null,
  ""
 ],
 "Toggle date picker": [
  null,
  ""
 ],
 "Too much data": [
  null,
  "Muitos dados"
 ],
 "Tools": [
  null,
  "Ferramentas"
 ],
 "Total size: $0": [
  null,
  "Tamanho total: $0"
 ],
 "Tower": [
  null,
  "Torre"
 ],
 "Trust and add host": [
  null,
  "Confiar e adicionar host"
 ],
 "Trying to synchronize with $0": [
  null,
  "Tentando sincronizar com $0"
 ],
 "Turn on administrative access": [
  null,
  ""
 ],
 "Type": [
  null,
  "Tipo"
 ],
 "Unable to contact $0.": [
  null,
  "Incapaz de contatar $0."
 ],
 "Unable to contact the given host $0. Make sure it has ssh running on port $1, or specify another port in the address.": [
  null,
  "Não foi possível entrar em contato com o host $0. Certifique-se de que o ssh esteja rodando na porta $1 ou especifique outra porta no endereço."
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  ""
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password. You may want to set up your SSH keys for automatic login.": [
  null,
  ""
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  ""
 ],
 "Unexpected error": [
  null,
  "Erro inesperado"
 ],
 "Unknown": [
  null,
  "Desconhecido"
 ],
 "Unknown host: $0": [
  null,
  "Host desconhecido: $0"
 ],
 "Unlock": [
  null,
  "Destravar"
 ],
 "Unlock key $0": [
  null,
  "Desbloquear chave $0"
 ],
 "Untrusted host": [
  null,
  "Host não confiável"
 ],
 "Update": [
  null,
  "Atualizar"
 ],
 "Use the following keys to authenticate against other systems": [
  null,
  "Usar as seguintes chaves para se autenticar em outros sistemas"
 ],
 "User name": [
  null,
  "Nome do usuário"
 ],
 "Verify fingerprint": [
  null,
  "Verificar digital"
 ],
 "View all logs": [
  null,
  "Ver todos os logs"
 ],
 "View automation script": [
  null,
  ""
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Aguardando que outras operações de gerenciamento de software terminem"
 ],
 "Web Console": [
  null,
  "Console web"
 ],
 "Web Console for Linux servers": [
  null,
  "Console da Web para servidores Linux"
 ],
 "When empty, connect with the current user": [
  null,
  ""
 ],
 "You are connecting to $0 for the first time.": [
  null,
  ""
 ],
 "You have been logged out due to inactivity.": [
  null,
  ""
 ],
 "You may want to change the password of the key for automatic login.": [
  null,
  ""
 ],
 "You now have administrative access.": [
  null,
  "Agora você tem acesso administrativo."
 ],
 "You will be logged out in $0 seconds.": [
  null,
  ""
 ],
 "You will be reminded once per session.": [
  null,
  ""
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  ""
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  ""
 ],
 "Your session has been terminated.": [
  null,
  "Sua sessão foi encerrada."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Sua sessão expirou. Por favor, faça o login novamente."
 ],
 "Zone": [
  null,
  "Zona"
 ],
 "[binary data]": [
  null,
  "[dados binários]"
 ],
 "[no data]": [
  null,
  "[sem dados]"
 ],
 "active": [
  null,
  "ativo"
 ],
 "in less than a minute": [
  null,
  "em menos de um minuto"
 ],
 "in most browsers": [
  null,
  "na maioria dos browsers"
 ],
 "less than a minute ago": [
  null,
  "menos de um minuto atrás"
 ],
 "password quality": [
  null,
  "qualidade da senha"
 ],
 "show less": [
  null,
  "mostrar menos"
 ],
 "show more": [
  null,
  "mostrar mais"
 ]
});
