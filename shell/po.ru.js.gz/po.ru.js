cockpit.locale({
 "": {
  "plural-forms": (n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "ru",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 ГиБ"
 ],
 "$0 day": [
  null,
  "$0 день",
  "$0 дня",
  "$0 дней"
 ],
 "$0 documentation": [
  null,
  "Документация $0"
 ],
 "$0 exited with code $1": [
  null,
  "Процесс $0 завершил работу с кодом $1"
 ],
 "$0 failed": [
  null,
  "Сбой процесса $0"
 ],
 "$0 hour": [
  null,
  "$0 час",
  "$0 часа",
  "$0 часов"
 ],
 "$0 is not available from any repository.": [
  null,
  "Компонент $0 недоступен в репозиториях."
 ],
 "$0 key changed": [
  null,
  "Изменен $0 ключ"
 ],
 "$0 killed with signal $1": [
  null,
  "Процесс $0 прерван с сигналом $1"
 ],
 "$0 minute": [
  null,
  "$0 минута",
  "$0 минуты",
  "$0 минут"
 ],
 "$0 month": [
  null,
  "$0 месяц",
  "$0 месяца",
  "$0 месяцев"
 ],
 "$0 week": [
  null,
  "$0 неделя",
  "$0 недели",
  "$0 недель"
 ],
 "$0 will be installed.": [
  null,
  "Будет выполнена установка $0."
 ],
 "$0 year": [
  null,
  "$0 год",
  "$0 года",
  "$0 лет"
 ],
 "1 day": [
  null,
  "1 день"
 ],
 "1 hour": [
  null,
  "1 час"
 ],
 "1 minute": [
  null,
  "1 минута"
 ],
 "1 week": [
  null,
  "1 неделя"
 ],
 "20 minutes": [
  null,
  "20 минут"
 ],
 "40 minutes": [
  null,
  "40 минут"
 ],
 "5 minutes": [
  null,
  "5 минут"
 ],
 "6 hours": [
  null,
  "6 часов"
 ],
 "60 minutes": [
  null,
  "60 минут"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Совместимая версия Cockpit не установлена на $0."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Будет создан новый ключ SSH в $0 для $1 на $2 и добавлен в файл $3 $4 на $5."
 ],
 "About Web Console": [
  null,
  "О веб-консоли"
 ],
 "Absent": [
  null,
  "Отсутствует"
 ],
 "Acceptable password": [
  null,
  "Допустимый пароль"
 ],
 "Active pages": [
  null,
  "Активные страницы"
 ],
 "Add": [
  null,
  "Добавить"
 ],
 "Add $0": [
  null,
  "Добавить $0"
 ],
 "Add key": [
  null,
  "Добавить ключ"
 ],
 "Add new host": [
  null,
  "Добавить новый узел"
 ],
 "Additional packages:": [
  null,
  "Дополнительные пакеты:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Администрирование с помощью веб-панели управления Cockpit"
 ],
 "Administrative access": [
  null,
  "Административный доступ"
 ],
 "Advanced TCA": [
  null,
  "Расширенный TCA"
 ],
 "All-in-one": [
  null,
  "Все в одном"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Документация к ролям Ansible"
 ],
 "Apps": [
  null,
  "Приложения"
 ],
 "Authenticate": [
  null,
  "Проверка подлинности"
 ],
 "Authentication": [
  null,
  "Проверка подлинности"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Для выполнения привилегированных задач с помощью веб-консоли Cockpit необходима проверка подлинности"
 ],
 "Authorize SSH key": [
  null,
  "Авторизовать SSH-ключ"
 ],
 "Automatic login": [
  null,
  "Автоматический вход"
 ],
 "Automatically using NTP": [
  null,
  "Автоматически с использованием серверов NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Автоматически с использованием дополнительных серверов NTP"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Автоматически с использованием определённых серверов NTP"
 ],
 "Automation script": [
  null,
  "Сценарий автоматизации"
 ],
 "Blade": [
  null,
  "Ультракомпактный сервер"
 ],
 "Blade enclosure": [
  null,
  "Корзина"
 ],
 "Bus expansion chassis": [
  null,
  "Корпус расширения шины"
 ],
 "By changing the password of the SSH key $0 to the login password of $1 on $2, the key will be automatically made available and you can log in to $3 without password in the future.": [
  null,
  "Если изменить пароль ключа SSH $0 на пароль для входа $1 на $2, ключ будет автоматически доступен, и вы в будущем сможете входить в $3 без пароля."
 ],
 "Can be a hostname, IP address, alias name, or ssh:// URI": [
  null,
  "Может быть именем узла, IP-адресом, псевдонимом или ssh:// URI"
 ],
 "Cancel": [
  null,
  "Отмена"
 ],
 "Cannot connect to an unknown host": [
  null,
  "Не удаётся подключиться к неизвестному компьютеру"
 ],
 "Cannot forward login credentials": [
  null,
  "Не удаётся передать учётные данные для входа"
 ],
 "Cannot schedule event in the past": [
  null,
  "Невозможно запланировать событие в прошлом"
 ],
 "Change": [
  null,
  "Изменить"
 ],
 "Change password": [
  null,
  "Изменить пароль"
 ],
 "Change system time": [
  null,
  "Изменить системное время"
 ],
 "Change the password of $0": [
  null,
  "Изменить пароль для $0"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Изменение ключей часто происходит в результате переустановки операционной системы. Однако неожиданное изменение может указывать на попытку третьей стороны перехватить ваше соединение."
 ],
 "Checking installed software": [
  null,
  "Проверка установленного программного обеспечения"
 ],
 "Choose the language to be used in the application": [
  null,
  "Выберите язык, который будет использоваться в приложении"
 ],
 "Clear input value": [
  null,
  "Сбросить входное значение"
 ],
 "Clear search": [
  null,
  "Сбросить поиск"
 ],
 "Close": [
  null,
  "Закрыть"
 ],
 "Close selected pages": [
  null,
  "Закрыть выделенные страницы"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Настройка Cockpit для NetworkManager и Firewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Не удалось установить связь между Cockpit и заданным узлом."
 ],
 "Cockpit had an unexpected internal error.": [
  null,
  "У Cockpit произошла неожиданная внутренняя ошибка."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit представляет собой диспетчер серверов, упрощающий администрирование серверов Linux через веб-браузер. Переключение между терминалом и веб-инструментом не представляет сложности. Служба, запущенная с помощью Cockpit, может быть остановлена через терминал. Аналогично, если в терминале возникает ошибка, её можно увидеть в интерфейсе журнала Cockpit."
 ],
 "Cockpit is an interactive Linux server admin interface.": [
  null,
  "Cockpit — это интерактивный интерфейс администратора серверов Linux."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit не совместим с программным обеспечением в системе."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit не установлен"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit не установлен в системе."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit идеально подходит для новых системных администраторов, позволяя им легко выполнять простые задачи, такие как администрирование хранилищ, проверка журналов и запуск и остановка служб. С помощью Cockpit вы можете контролировать и администрировать несколько серверов одновременно. Просто добавьте их одним щелчком мыши, и ваш компьютер позаботится о своих приятелях."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Собрать и упаковать диагностические данные и данные поддержки"
 ],
 "Collect kernel crash dumps": [
  null,
  "Собрать аварийный дамп ядра"
 ],
 "Color": [
  null,
  "Цвет"
 ],
 "Comment": [
  null,
  "Комментарий"
 ],
 "Compact PCI": [
  null,
  "Компактный PCI"
 ],
 "Confirm key password": [
  null,
  "Подтвердите ключевой пароль"
 ],
 "Confirm new key password": [
  null,
  "Подтвердите новый ключевой пароль"
 ],
 "Confirm password": [
  null,
  "Подтвердите пароль"
 ],
 "Connect": [
  null,
  "Подключиться"
 ],
 "Connected hosts can fully control each other. This includes running programs that could harm your system or steal data. Only connect to trusted machines.": [
  null,
  ""
 ],
 "Connecting to the machine": [
  null,
  "Подключение к компьютеру"
 ],
 "Connection error": [
  null,
  "Ошибка подключения"
 ],
 "Connection failed": [
  null,
  "Ошибка подключения"
 ],
 "Connection has timed out.": [
  null,
  "Превышено время ожидания подключения."
 ],
 "Contains:": [
  null,
  "Содержит:"
 ],
 "Continue session": [
  null,
  "Продолжить сессию"
 ],
 "Convertible": [
  null,
  "Компьютер-трансформер"
 ],
 "Copied": [
  null,
  "Скопировано"
 ],
 "Copy": [
  null,
  "Копировать"
 ],
 "Copy to clipboard": [
  null,
  "Копировать в буфер обмена"
 ],
 "Could not contact $0": [
  null,
  "Не удалось связаться с $0"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Создать новый SSH-ключ и авторизовать его"
 ],
 "Create new task file with this content.": [
  null,
  "Создайте новый файл задачи с этим содержимым."
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Ctrl-Shift-I": [
  null,
  "Ctrl-Shift-I"
 ],
 "Dark": [
  null,
  "Тёмный"
 ],
 "Default": [
  null,
  "По умолчанию"
 ],
 "Delay": [
  null,
  "Задержка"
 ],
 "Desktop": [
  null,
  "Настольный компьютер"
 ],
 "Detachable": [
  null,
  "Съёмный компьютер"
 ],
 "Details": [
  null,
  "Подробности"
 ],
 "Diagnostic reports": [
  null,
  "Диагностические отчёты"
 ],
 "Disconnected": [
  null,
  "Отключено"
 ],
 "Display language": [
  null,
  "Язык интерфейса"
 ],
 "Docking station": [
  null,
  "Стыковочный узел"
 ],
 "Downloading $0": [
  null,
  "Загрузка $0"
 ],
 "Dual rank": [
  null,
  "Двухранговая"
 ],
 "Edit": [
  null,
  "Изменить"
 ],
 "Edit host": [
  null,
  "Изменить узел"
 ],
 "Edit hosts": [
  null,
  "Изменить узлы"
 ],
 "Embedded PC": [
  null,
  "Встраиваемый компьютер"
 ],
 "Excellent password": [
  null,
  "Отличный пароль"
 ],
 "Expansion chassis": [
  null,
  "Корпус расширения"
 ],
 "Failed to add machine: $0": [
  null,
  "Не удалось добавить компьютер: $0"
 ],
 "Failed to change password": [
  null,
  "Не удалось изменить пароль"
 ],
 "Failed to edit machine: $0": [
  null,
  "Не удалось изменить компьютер: $0"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Не удалось включить $0 в firewalld"
 ],
 "Filter menu items": [
  null,
  "Фильтровать элементы меню"
 ],
 "Fingerprint": [
  null,
  "Отпечаток"
 ],
 "Go to now": [
  null,
  "Текущий момент"
 ],
 "Handheld": [
  null,
  "Наладонный компьютер"
 ],
 "Help": [
  null,
  "Помощь"
 ],
 "Hide confirmation password": [
  null,
  "Скрыть подтверждение пароля"
 ],
 "Hide password": [
  null,
  "Скрыть пароль"
 ],
 "Host": [
  null,
  "Узел"
 ],
 "Host key is incorrect": [
  null,
  "Неверный ключ узла"
 ],
 "Hosts": [
  null,
  "Узлы"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Если отпечаток совпадает, нажмите «Доверять и добавить хост». В противном случае не подключайтесь и свяжитесь с вашим администратором."
 ],
 "In order to allow log in to $0 as $1 without password in the future, use the login password of $2 on $3 as the key password, or leave the key password blank.": [
  null,
  "В целях обеспечения дальнейшего входа без пароля на $0 как $1, можно в качестве пароля ключа использовать пароль для входа $2 на $3 или оставить поле для пароля ключа пустым."
 ],
 "Install": [
  null,
  "Установить"
 ],
 "Install software": [
  null,
  "Установка программного обеспечения"
 ],
 "Installing $0": [
  null,
  "Установка $0"
 ],
 "Internal error": [
  null,
  "Внутренняя ошибка"
 ],
 "Invalid date format": [
  null,
  "Недопустимый формат даты"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Недопустимый формат даты и недопустимый формат времени"
 ],
 "Invalid file permissions": [
  null,
  "Недопустимые разрешения для файлов"
 ],
 "Invalid time format": [
  null,
  "Недопустимый формат времени"
 ],
 "Invalid timezone": [
  null,
  "Недопустимый часовой пояс"
 ],
 "IoT gateway": [
  null,
  "Шлюз Интернета вещей"
 ],
 "Is sshd running on a different port?": [
  null,
  "Работает ли sshd на другом порту?"
 ],
 "Kernel dump": [
  null,
  "Дамп ядра"
 ],
 "Key password": [
  null,
  "Пароль ключа"
 ],
 "Laptop": [
  null,
  "Полноразмерный ноутбук"
 ],
 "Learn more": [
  null,
  "Подробнее"
 ],
 "Licensed under GNU LGPL version 2.1": [
  null,
  "Распространяется на условиях лицензии GNU LGPL, версия 2.1"
 ],
 "Light": [
  null,
  "Светлый"
 ],
 "Limit access": [
  null,
  "Ограничить доступ"
 ],
 "Limited access": [
  null,
  "Ограниченный доступ"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "В ограниченном режиме доступа ограничиваются полномочия администратора. В некоторых разделах веб-консоли будет урезаны функциональные возможности."
 ],
 "Loading packages...": [
  null,
  "Загрузка пакетов…"
 ],
 "Loading system modifications...": [
  null,
  "Загрузка изменений системы…"
 ],
 "Log in": [
  null,
  "Войти"
 ],
 "Log in to $0": [
  null,
  "Вход на $0"
 ],
 "Log messages": [
  null,
  "Сообщения журнала"
 ],
 "Log out": [
  null,
  "Выход"
 ],
 "Login failed": [
  null,
  "Ошибка входа"
 ],
 "Low profile desktop": [
  null,
  "Низкопрофильный настольный компьютер"
 ],
 "Lunch box": [
  null,
  "Портативный компьютер в ударопрочном корпусе"
 ],
 "Main server chassis": [
  null,
  "Главный серверный корпус"
 ],
 "Malicious pages on a remote machine may affect other connected hosts": [
  null,
  "Вредоносные страницы на удалённом компьютере могут повлиять на другие подключённые хосты."
 ],
 "Manage storage": [
  null,
  "Управление хранилищем"
 ],
 "Manually": [
  null,
  "Вручную"
 ],
 "Message to logged in users": [
  null,
  "Сообщение для вошедших пользователей"
 ],
 "Messages related to the failure might be found in the journal:": [
  null,
  "Сообщения, связанные с ошибкой, могут быть найдены в журнале:"
 ],
 "Method": [
  null,
  "Метод"
 ],
 "Mini PC": [
  null,
  "Мини-ПК"
 ],
 "Mini tower": [
  null,
  "Компьютер в корпусе «мини-башня»"
 ],
 "Multi-system chassis": [
  null,
  "Корпус для нескольких систем"
 ],
 "NTP server": [
  null,
  "Сервер NTP"
 ],
 "Name": [
  null,
  "Имя"
 ],
 "Need at least one NTP server": [
  null,
  "Требуется по крайней мере один сервер NTP"
 ],
 "Networking": [
  null,
  "Сеть"
 ],
 "New host: $0": [
  null,
  "Новый хост: $0"
 ],
 "New key password": [
  null,
  "Новый пароль ключа"
 ],
 "New password": [
  null,
  "Новый пароль"
 ],
 "New password was not accepted": [
  null,
  "Новый пароль не был принят"
 ],
 "No delay": [
  null,
  "Без задержки"
 ],
 "No languages match": [
  null,
  "Ни один язык не подходит"
 ],
 "No results found": [
  null,
  "Нет результатов"
 ],
 "No such file or directory": [
  null,
  "Нет такого файла или каталога"
 ],
 "No system modifications": [
  null,
  "Изменения системы отсутствуют"
 ],
 "Not a valid private key": [
  null,
  "Недопустимый закрытый ключ"
 ],
 "Not connected to host": [
  null,
  "Отсутствует подключение к узлу"
 ],
 "Not permitted to perform this action.": [
  null,
  "Нет прав на выполнение этого действия."
 ],
 "Not synchronized": [
  null,
  "Не синхронизировано"
 ],
 "Notebook": [
  null,
  "Ноутбук"
 ],
 "Occurrences": [
  null,
  "События"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Old password not accepted": [
  null,
  "Старый пароль не был принят"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "После установки Cockpit включите его при помощи команды «systemctl enable --now cockpit.socket»."
 ],
 "Ooops!": [
  null,
  "Упс!"
 ],
 "Other": [
  null,
  "Прочее"
 ],
 "PackageKit crashed": [
  null,
  "Сбой PackageKit"
 ],
 "Page name": [
  null,
  "Название страницы"
 ],
 "Password": [
  null,
  "Пароль"
 ],
 "Password changed successfully": [
  null,
  "Пароль успешно изменён"
 ],
 "Password is not acceptable": [
  null,
  "Недопустимый пароль"
 ],
 "Password is too weak": [
  null,
  "Пароль недостаточно надёжен"
 ],
 "Password not accepted": [
  null,
  "Пароль не принят"
 ],
 "Password tip": [
  null,
  "Подсказка для пароля"
 ],
 "Paste": [
  null,
  "Вставить"
 ],
 "Paste error": [
  null,
  "Ошибка вставки"
 ],
 "Path to file": [
  null,
  "Путь к файлу"
 ],
 "Peripheral chassis": [
  null,
  "Корпус для периферийных устройств"
 ],
 "Pick date": [
  null,
  "Выбор даты"
 ],
 "Pizza box": [
  null,
  "Ультратонкий корпус"
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Пройдите проверку подлинности для получения прав администратора"
 ],
 "Port": [
  null,
  "Порт"
 ],
 "Portable": [
  null,
  "Портативный компьютер"
 ],
 "Present": [
  null,
  "Присутствует"
 ],
 "Problem becoming administrator": [
  null,
  "При получении прав администратора возникли проблемы"
 ],
 "Project website": [
  null,
  "Веб-сайт проекта"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Превышено время ожидания запроса по ssh-add"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Превышено время ожидания запроса по ssh-keygen"
 ],
 "Public key": [
  null,
  "Открытый ключ"
 ],
 "RAID chassis": [
  null,
  "Корпус для RAID-массива"
 ],
 "Rack mount chassis": [
  null,
  "Монтируемый в стойку корпус"
 ],
 "Reboot": [
  null,
  "Перезагрузка"
 ],
 "Reconnect": [
  null,
  "Повторить подключение"
 ],
 "Removals:": [
  null,
  "Для удаления:"
 ],
 "Remove": [
  null,
  "Удалить"
 ],
 "Removing $0": [
  null,
  "Удаление $0"
 ],
 "Row expansion": [
  null,
  "Расширение строки"
 ],
 "Row select": [
  null,
  "Выбор строки"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Запустите эту команду через доверенную сеть или физически на удалённом компьютере:"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "SSH-ключ"
 ],
 "SSH keys": [
  null,
  "SSH-ключи"
 ],
 "Safari users need to import and trust the certificate of the self-signing CA:": [
  null,
  "Пользователям Safari необходимо импортировать и установить доверие к самозаверенному сертификату центра сертификации:"
 ],
 "Sealed-case PC": [
  null,
  "Компьютер с невскрываемым корпусом"
 ],
 "Search": [
  null,
  "Поиск"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Настройка и устранение неисправностей в Linux с улучшенной системой безопасности"
 ],
 "Select": [
  null,
  "Выбрать"
 ],
 "Server has closed the connection.": [
  null,
  "Сервер закрыл соединение."
 ],
 "Session": [
  null,
  "Сеанс"
 ],
 "Session is about to expire": [
  null,
  "Сессия истекает"
 ],
 "Set": [
  null,
  "Настроить"
 ],
 "Set time": [
  null,
  "Настроить время"
 ],
 "Shell script": [
  null,
  "Сценарий оболочки"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show confirmation password": [
  null,
  "Показать подтверждение пароля"
 ],
 "Show password": [
  null,
  "Показать пароль"
 ],
 "Shut down": [
  null,
  "Завершение работы"
 ],
 "Single rank": [
  null,
  "Одноранговая"
 ],
 "Skip main navigation": [
  null,
  "Пропустить основную навигацию"
 ],
 "Skip to content": [
  null,
  "Перейти к содержимому"
 ],
 "Space-saving computer": [
  null,
  "Компактный компьютер"
 ],
 "Specific time": [
  null,
  "Определённое время"
 ],
 "Stick PC": [
  null,
  "ПК-брелок"
 ],
 "Stop editing hosts": [
  null,
  "Закончить изменение узлов"
 ],
 "Storage": [
  null,
  "Хранилище"
 ],
 "Strong password": [
  null,
  "Надёжный пароль"
 ],
 "Style": [
  null,
  "Внешний вид"
 ],
 "Sub-Chassis": [
  null,
  "Дополнительный корпус"
 ],
 "Sub-Notebook": [
  null,
  "Субноутбук"
 ],
 "Switch to administrative access": [
  null,
  "Переключиться на доступ с правами администратора"
 ],
 "Switch to limited access": [
  null,
  "Переключится на ограниченный доступ"
 ],
 "Synchronized": [
  null,
  "Синхронизировано"
 ],
 "Synchronized with $0": [
  null,
  "Синхронизировано с $0"
 ],
 "Synchronizing": [
  null,
  "Синхронизация"
 ],
 "System": [
  null,
  "Система"
 ],
 "Tablet": [
  null,
  "Планшетный ПК"
 ],
 "The IP address or hostname cannot contain whitespace.": [
  null,
  "IP-адрес или имя узла не могут содержать пробелы."
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "SSH-ключ $0 для $1 на $2 будет добавлен к файлу $3 для $4 на $5."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH-ключ $0 будет предоставлен на оставшееся время сеанса, а также будет доступен для входа на другие узлы."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "SSH-ключ для входа на $0 защищён паролем, а вход с паролем на узле запрещён. Введите пароль для ключа на $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "SSH-ключ для входа на $0 защищён. Вход возможен либо при указании пароля для входа, либо пароля ключа на $1."
 ],
 "The fingerprint should match:": [
  null,
  "Отпечаток должен соответствовать:"
 ],
 "The key password can not be empty": [
  null,
  "Пароль ключа не может быть пустым"
 ],
 "The key passwords do not match": [
  null,
  "Пароли ключа не совпадают"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Текущему пользователю запрещено просматривать изменения системы"
 ],
 "The machine is rebooting": [
  null,
  "Компьютер перезагружается"
 ],
 "The new key password can not be empty": [
  null,
  "Новый пароль ключа не может быть пустым"
 ],
 "The password can not be empty": [
  null,
  "Пароль не может быть пустым"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Полученный отпечаток можно распространять по общедоступным каналам связи, включая электронную почту."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Полученный отпечаток пальца можно передавать общедоступными способами, включая электронную почту. Если вы просите кого-то другого выполнить проверку за вас, они могут отправить результаты любым способом."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Сервер отклонил проверку подлинности с использованием любых поддерживаемых методов."
 ],
 "There are currently no active pages": [
  null,
  "В настоящее время нет активных страниц"
 ],
 "There was an unexpected error while connecting to the machine.": [
  null,
  "Произошла непредвиденная ошибка при подключении к компьютеру."
 ],
 "This machine has already been added.": [
  null,
  "Этот компьютер уже добавлен."
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Этот инструмент настраивает правила SELinux и может помочь в понимании и устранении нарушений правил."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Этот инструмент создаёт архив данных по настройкам и диагностике для запущенной системы. Архив может быть сохранён локально или централизованно с целью журналирования или слежения или отправлен представителям технической поддержки, разработчикам или администраторам системы, чтобы помочь с поиском технических проблем и диагностикой."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Этот инструмент управляет локальными хранилищами, такими как файловые системы, группы томов LVM2, и монтированиями NFS."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Этот инструмент управляет возможностями работы в сети, в частности связями, мостами, командами, виртуальными LAN и брандмауэрами, с помощью NetworkManager и Firewalld. NetworkManager несовместим с типичным для Ubuntu systemd-networkd и скриптами ifupdown Debian."
 ],
 "This will allow you to log in without password in the future.": [
  null,
  "В дальнейшем это позволит выполнять вход без ввода пароля."
 ],
 "Time zone": [
  null,
  "Часовой пояс"
 ],
 "Tip: Make your key password match your login password to automatically authenticate against other systems.": [
  null,
  "Совет: сделайте пароль ключа и пароль для входа в систему одинаковыми для автоматической проверки подлинности в других системах."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Чтобы убедиться в том, что данные вашего соединения не были перехвачены злоумышленниками, проверьте отпечаток ключа данного узла:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Для проверки отпечатка запустите следующую команду на $0, физически работая на этом компьютере или по доверенной сети:"
 ],
 "Toggle": [
  null,
  "Переключить"
 ],
 "Toggle date picker": [
  null,
  "Переключить средство выбора даты"
 ],
 "Too much data": [
  null,
  "Слишком много данных"
 ],
 "Tools": [
  null,
  "Инструменты"
 ],
 "Total size: $0": [
  null,
  "Общий размер: $0"
 ],
 "Tower": [
  null,
  "Компьютер в корпусе «башня»"
 ],
 "Trust and add host": [
  null,
  "Доверять и добавить хост"
 ],
 "Trying to synchronize with $0": [
  null,
  "Попытка синхронизации с $0"
 ],
 "Turn on administrative access": [
  null,
  "Включить доступ с правами администратора"
 ],
 "Type": [
  null,
  "Тип"
 ],
 "Unable to contact $0.": [
  null,
  "Не удалось установить связь с $0."
 ],
 "Unable to contact the given host $0. Make sure it has ssh running on port $1, or specify another port in the address.": [
  null,
  "Не удалось установить связь c заданным узлом $0. Убедитесь, что на порте $1 работает SSH или укажите в адресе другой порт."
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password. You may want to set up your SSH keys for automatic login.": [
  null,
  "Не удалось войти на $0 с проверкой подлинности по SSH-ключу. Введите пароль. Для автоматического входа следует настроить SSH-ключи."
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Не удалось войти на $0. Узел не принимает вход ни по паролю, ни по одному из имеющихся SSH-ключей."
 ],
 "Unexpected error": [
  null,
  "Непредвиденная ошибка"
 ],
 "Unknown": [
  null,
  "Неизвестно"
 ],
 "Unlock": [
  null,
  "Разблокировать"
 ],
 "Unlock key $0": [
  null,
  "Разблокирование ключа $0"
 ],
 "Untrusted host": [
  null,
  "Недоверенный узел"
 ],
 "Update": [
  null,
  "Обновить"
 ],
 "Use key": [
  null,
  "Использовать ключ"
 ],
 "Use the following keys to authenticate against other systems": [
  null,
  "Используйте следующие ключи для проверки подлинности в других системах"
 ],
 "User name": [
  null,
  "Имя пользователя"
 ],
 "Verify fingerprint": [
  null,
  "Проверить отпечаток"
 ],
 "View all logs": [
  null,
  "Смотреть все журналы"
 ],
 "View automation script": [
  null,
  "Просмотреть сценарий автоматизации"
 ],
 "Visit firewall": [
  null,
  "Перейти к межсетевому экрану"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Ожидание завершения других операций управления программным обеспечением"
 ],
 "Weak password": [
  null,
  "Ненадёжный пароль"
 ],
 "Web Console": [
  null,
  "Веб-консоль"
 ],
 "Web Console for Linux servers": [
  null,
  "Веб-консоль для серверов Linux"
 ],
 "Web console logo": [
  null,
  "Логотип веб-консоли"
 ],
 "When empty, connect with the current user": [
  null,
  "При отсутствии значения соединение будет осуществляться от текущего пользователя"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Подключение к $0 выполняется в первый раз."
 ],
 "You have been logged out due to inactivity.": [
  null,
  "Вы вышли из системы из-за неактивности."
 ],
 "You may want to change the password of the key for automatic login.": [
  null,
  "Может потребоваться смена пароля ключа для автоматического входа."
 ],
 "You now have administrative access.": [
  null,
  "Получены права администратора."
 ],
 "You will be logged out in $0 seconds.": [
  null,
  "Вы выйдете из системы через $0 секунд."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "В данном браузере отсутствует возможность вставки с помощью контекстного меню. Можно использовать комбинацию Shift+Insert."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Браузер запоминает уровень доступа от сеанса к сеансу."
 ],
 "Your session has been terminated.": [
  null,
  "Сеанс завершён."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Срок действия сеанса истёк. Войдите в систему снова."
 ],
 "Zone": [
  null,
  "Зона"
 ],
 "[binary data]": [
  null,
  "[двоичные данные]"
 ],
 "[no data]": [
  null,
  "[нет данных]"
 ],
 "active": [
  null,
  "активно"
 ],
 "in less than a minute": [
  null,
  ""
 ],
 "in most browsers": [
  null,
  "в большинстве браузеров"
 ],
 "less than a minute ago": [
  null,
  ""
 ],
 "password quality": [
  null,
  "качество пароля"
 ],
 "show less": [
  null,
  "показать меньше"
 ],
 "show more": [
  null,
  "показать больше"
 ]
});
