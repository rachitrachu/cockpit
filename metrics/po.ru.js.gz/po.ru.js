cockpit.locale({
 "": {
  "plural-forms": (n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "ru",
  "language-direction": "ltr"
 },
 "$0 CPU": [
  null,
  "$0 процессор",
  "$0 процессора",
  "$0 процессоров"
 ],
 "$0 GiB": [
  null,
  "$0 ГиБ"
 ],
 "$0 available": [
  null,
  "Доступно $0"
 ],
 "$0 day": [
  null,
  "$0 день",
  "$0 дня",
  "$0 дней"
 ],
 "$0 exited with code $1": [
  null,
  "Процесс $0 завершил работу с кодом $1"
 ],
 "$0 failed": [
  null,
  "Сбой процесса $0"
 ],
 "$0 free": [
  null,
  "Свободно $0"
 ],
 "$0 hour": [
  null,
  "$0 час",
  "$0 часа",
  "$0 часов"
 ],
 "$0 is not available from any repository.": [
  null,
  "Компонент $0 недоступен в репозиториях."
 ],
 "$0 key changed": [
  null,
  "Изменен $0 ключ"
 ],
 "$0 killed with signal $1": [
  null,
  "Процесс $0 прерван с сигналом $1"
 ],
 "$0 minute": [
  null,
  "$0 минута",
  "$0 минуты",
  "$0 минут"
 ],
 "$0 month": [
  null,
  "$0 месяц",
  "$0 месяца",
  "$0 месяцев"
 ],
 "$0 page": [
  null,
  "$0 пакет",
  "$0 пакета",
  "$0 пакетов"
 ],
 "$0 spike": [
  null,
  "$0 пик",
  "$0 пика",
  "$0 пиков"
 ],
 "$0 total": [
  null,
  "Всего $0"
 ],
 "$0 week": [
  null,
  "$0 неделя",
  "$0 недели",
  "$0 недель"
 ],
 "$0 will be installed.": [
  null,
  "Будет выполнена установка $0."
 ],
 "$0 year": [
  null,
  "$0 год",
  "$0 года",
  "$0 лет"
 ],
 "1 day": [
  null,
  "1 день"
 ],
 "1 hour": [
  null,
  "1 час"
 ],
 "1 min": [
  null,
  "1 мин"
 ],
 "1 minute": [
  null,
  "1 минута"
 ],
 "1 week": [
  null,
  "1 неделя"
 ],
 "15 min": [
  null,
  "15 мин"
 ],
 "20 minutes": [
  null,
  "20 минут"
 ],
 "40 minutes": [
  null,
  "40 минут"
 ],
 "5 min": [
  null,
  "5 мин"
 ],
 "5 minutes": [
  null,
  "5 минут"
 ],
 "6 hours": [
  null,
  "6 часов"
 ],
 "60 minutes": [
  null,
  "60 минут"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Совместимая версия Cockpit не установлена на $0."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Будет создан новый ключ SSH в $0 для $1 на $2 и добавлен в файл $3 $4 на $5."
 ],
 "Absent": [
  null,
  "Отсутствует"
 ],
 "Acceptable password": [
  null,
  "Допустимый пароль"
 ],
 "Add $0": [
  null,
  "Добавить $0"
 ],
 "Additional packages:": [
  null,
  "Дополнительные пакеты:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Администрирование с помощью веб-панели управления Cockpit"
 ],
 "Advanced TCA": [
  null,
  "Расширенный TCA"
 ],
 "All-in-one": [
  null,
  "Все в одном"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Документация к ролям Ansible"
 ],
 "Authentication": [
  null,
  "Проверка подлинности"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Для выполнения привилегированных задач с помощью веб-консоли Cockpit необходима проверка подлинности"
 ],
 "Authorize SSH key": [
  null,
  "Авторизовать SSH-ключ"
 ],
 "Automatically using NTP": [
  null,
  "Автоматически с использованием серверов NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Автоматически с использованием дополнительных серверов NTP"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Автоматически с использованием определённых серверов NTP"
 ],
 "Automation script": [
  null,
  "Сценарий автоматизации"
 ],
 "Blade": [
  null,
  "Ультракомпактный сервер"
 ],
 "Blade enclosure": [
  null,
  "Корзина"
 ],
 "Boot": [
  null,
  "Загрузка"
 ],
 "Bus expansion chassis": [
  null,
  "Корпус расширения шины"
 ],
 "CPU": [
  null,
  "ЦП"
 ],
 "CPU usage": [
  null,
  "Использование ЦП"
 ],
 "CPU usage/load": [
  null,
  "Использование/загрузка ЦП"
 ],
 "Cancel": [
  null,
  "Отмена"
 ],
 "Cannot forward login credentials": [
  null,
  "Не удаётся передать учётные данные для входа"
 ],
 "Cannot schedule event in the past": [
  null,
  "Невозможно запланировать событие в прошлом"
 ],
 "Change": [
  null,
  "Изменить"
 ],
 "Change system time": [
  null,
  "Изменить системное время"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Изменение ключей часто происходит в результате переустановки операционной системы. Однако неожиданное изменение может указывать на попытку третьей стороны перехватить ваше соединение."
 ],
 "Checking installed software": [
  null,
  "Проверка установленного программного обеспечения"
 ],
 "Clear input value": [
  null,
  "Сбросить входное значение"
 ],
 "Close": [
  null,
  "Закрыть"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Настройка Cockpit для NetworkManager и Firewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Не удалось установить связь между Cockpit и заданным узлом."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit представляет собой диспетчер серверов, упрощающий администрирование серверов Linux через веб-браузер. Переключение между терминалом и веб-инструментом не представляет сложности. Служба, запущенная с помощью Cockpit, может быть остановлена через терминал. Аналогично, если в терминале возникает ошибка, её можно увидеть в интерфейсе журнала Cockpit."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit не совместим с программным обеспечением в системе."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit не установлен"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit не установлен в системе."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit идеально подходит для новых системных администраторов, позволяя им легко выполнять простые задачи, такие как администрирование хранилищ, проверка журналов и запуск и остановка служб. С помощью Cockpit вы можете контролировать и администрировать несколько серверов одновременно. Просто добавьте их одним щелчком мыши, и ваш компьютер позаботится о своих приятелях."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Собрать и упаковать диагностические данные и данные поддержки"
 ],
 "Collect kernel crash dumps": [
  null,
  "Собрать аварийный дамп ядра"
 ],
 "Collect metrics": [
  null,
  "Собрать метрики"
 ],
 "Compact PCI": [
  null,
  "Компактный PCI"
 ],
 "Confirm key password": [
  null,
  "Подтвердите ключевой пароль"
 ],
 "Connection has timed out.": [
  null,
  "Превышено время ожидания подключения."
 ],
 "Convertible": [
  null,
  "Компьютер-трансформер"
 ],
 "Copied": [
  null,
  "Скопировано"
 ],
 "Copy": [
  null,
  "Копировать"
 ],
 "Copy to clipboard": [
  null,
  "Копировать в буфер обмена"
 ],
 "Core $0": [
  null,
  "Ядро $0"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Создать новый SSH-ключ и авторизовать его"
 ],
 "Create new task file with this content.": [
  null,
  "Создайте новый файл задачи с этим содержимым."
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Current top CPU usage": [
  null,
  "Максимальное текущее использование ЦП"
 ],
 "Delay": [
  null,
  "Задержка"
 ],
 "Desktop": [
  null,
  "Настольный компьютер"
 ],
 "Detachable": [
  null,
  "Съёмный компьютер"
 ],
 "Device": [
  null,
  "Устройство"
 ],
 "Diagnostic reports": [
  null,
  "Диагностические отчёты"
 ],
 "Disk I/O": [
  null,
  "Дисковый ввод-вывод"
 ],
 "Disks": [
  null,
  "Диски"
 ],
 "Disks usage": [
  null,
  "Использование диска"
 ],
 "Docking station": [
  null,
  "Стыковочный узел"
 ],
 "Downloading $0": [
  null,
  "Загрузка $0"
 ],
 "Dual rank": [
  null,
  "Двухранговая"
 ],
 "Embedded PC": [
  null,
  "Встраиваемый компьютер"
 ],
 "Error has occurred": [
  null,
  "Произошла ошибка"
 ],
 "Excellent password": [
  null,
  "Отличный пароль"
 ],
 "Expansion chassis": [
  null,
  "Корпус расширения"
 ],
 "Export to network": [
  null,
  "Экспортировать в сеть"
 ],
 "Failed to change password": [
  null,
  "Не удалось изменить пароль"
 ],
 "Failed to configure PCP": [
  null,
  "Не удалось настроить конфигурацию PCP"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Не удалось включить $0 в firewalld"
 ],
 "Go to now": [
  null,
  "Текущий момент"
 ],
 "Graph visibility": [
  null,
  "Видимость графика"
 ],
 "Graph visibility options menu": [
  null,
  "Меню параметров видимости графика"
 ],
 "Handheld": [
  null,
  "Наладонный компьютер"
 ],
 "Hide confirmation password": [
  null,
  "Скрыть подтверждение пароля"
 ],
 "Hide password": [
  null,
  "Скрыть пароль"
 ],
 "Host key is incorrect": [
  null,
  "Неверный ключ узла"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Если отпечаток совпадает, нажмите «Доверять и добавить хост». В противном случае не подключайтесь и свяжитесь с вашим администратором."
 ],
 "In": [
  null,
  "Вход"
 ],
 "Install": [
  null,
  "Установить"
 ],
 "Install software": [
  null,
  "Установка программного обеспечения"
 ],
 "Installing $0": [
  null,
  "Установка $0"
 ],
 "Interface": [
  null,
  "Интерфейс",
  "Интерфейсы",
  "Интерфейсы"
 ],
 "Internal error": [
  null,
  "Внутренняя ошибка"
 ],
 "Invalid date format": [
  null,
  "Недопустимый формат даты"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Недопустимый формат даты и недопустимый формат времени"
 ],
 "Invalid file permissions": [
  null,
  "Недопустимые разрешения для файлов"
 ],
 "Invalid time format": [
  null,
  "Недопустимый формат времени"
 ],
 "Invalid timezone": [
  null,
  "Недопустимый часовой пояс"
 ],
 "IoT gateway": [
  null,
  "Шлюз Интернета вещей"
 ],
 "Jump to": [
  null,
  "Перейти к"
 ],
 "Kernel dump": [
  null,
  "Дамп ядра"
 ],
 "Key password": [
  null,
  "Пароль ключа"
 ],
 "Laptop": [
  null,
  "Полноразмерный ноутбук"
 ],
 "Learn more": [
  null,
  "Подробнее"
 ],
 "Load": [
  null,
  "Нагрузка"
 ],
 "Load earlier data": [
  null,
  "Загрузить более ранние данные"
 ],
 "Loading system modifications...": [
  null,
  "Загрузка изменений системы…"
 ],
 "Loading...": [
  null,
  "Загрузка…"
 ],
 "Log in": [
  null,
  "Войти"
 ],
 "Log in to $0": [
  null,
  "Вход на $0"
 ],
 "Log messages": [
  null,
  "Сообщения журнала"
 ],
 "Login failed": [
  null,
  "Ошибка входа"
 ],
 "Low profile desktop": [
  null,
  "Низкопрофильный настольный компьютер"
 ],
 "Lunch box": [
  null,
  "Портативный компьютер в ударопрочном корпусе"
 ],
 "Main server chassis": [
  null,
  "Главный серверный корпус"
 ],
 "Manage storage": [
  null,
  "Управление хранилищем"
 ],
 "Manually": [
  null,
  "Вручную"
 ],
 "Memory": [
  null,
  "Память"
 ],
 "Memory usage": [
  null,
  "Использование памяти"
 ],
 "Memory usage/swap": [
  null,
  "Использование/Резервирование памяти"
 ],
 "Message to logged in users": [
  null,
  "Сообщение для вошедших пользователей"
 ],
 "Metrics and history": [
  null,
  "Метрики и история"
 ],
 "Metrics history could not be loaded": [
  null,
  "Не удалось загрузить историю метрик"
 ],
 "Metrics settings": [
  null,
  "Параметры метрик"
 ],
 "Mini PC": [
  null,
  "Мини-ПК"
 ],
 "Mini tower": [
  null,
  "Компьютер в корпусе «мини-башня»"
 ],
 "Multi-system chassis": [
  null,
  "Корпус для нескольких систем"
 ],
 "NTP server": [
  null,
  "Сервер NTP"
 ],
 "Need at least one NTP server": [
  null,
  "Требуется по крайней мере один сервер NTP"
 ],
 "Network": [
  null,
  "Сеть"
 ],
 "Network I/O": [
  null,
  "Сетевой ввод/вывод"
 ],
 "Network usage": [
  null,
  "Использование сети"
 ],
 "Networking": [
  null,
  "Сеть"
 ],
 "New password was not accepted": [
  null,
  "Новый пароль не был принят"
 ],
 "No data available": [
  null,
  "Данные недоступны"
 ],
 "No data available between $0 and $1": [
  null,
  "Данные с $0 по $1 недоступны"
 ],
 "No delay": [
  null,
  "Без задержки"
 ],
 "No events": [
  null,
  "Нет событий"
 ],
 "No log entries": [
  null,
  "Нет записей в журнале"
 ],
 "No results found": [
  null,
  "Нет результатов"
 ],
 "No such file or directory": [
  null,
  "Нет такого файла или каталога"
 ],
 "No system modifications": [
  null,
  "Изменения системы отсутствуют"
 ],
 "Not a valid private key": [
  null,
  "Недопустимый закрытый ключ"
 ],
 "Not permitted to perform this action.": [
  null,
  "Нет прав на выполнение этого действия."
 ],
 "Not synchronized": [
  null,
  "Не синхронизировано"
 ],
 "Notebook": [
  null,
  "Ноутбук"
 ],
 "Occurrences": [
  null,
  "События"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Old password not accepted": [
  null,
  "Старый пароль не был принят"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "После установки Cockpit включите его при помощи команды «systemctl enable --now cockpit.socket»."
 ],
 "Open the pmproxy service in the firewall to share metrics.": [
  null,
  "Включите службу pmproxy в межсетевом экране для совместного использования метрик."
 ],
 "Other": [
  null,
  "Прочее"
 ],
 "Out": [
  null,
  "Выход"
 ],
 "Overview": [
  null,
  "Обзор"
 ],
 "PackageKit crashed": [
  null,
  "Сбой PackageKit"
 ],
 "Password": [
  null,
  "Пароль"
 ],
 "Password is not acceptable": [
  null,
  "Недопустимый пароль"
 ],
 "Password is too weak": [
  null,
  "Пароль недостаточно надёжен"
 ],
 "Password not accepted": [
  null,
  "Пароль не принят"
 ],
 "Paste": [
  null,
  "Вставить"
 ],
 "Paste error": [
  null,
  "Ошибка вставки"
 ],
 "Path to file": [
  null,
  "Путь к файлу"
 ],
 "Performance Co-Pilot collects and analyzes performance metrics from your system.": [
  null,
  "Performance Co-Pilot собирает и анализирует метрики производительностипо данной системе."
 ],
 "Peripheral chassis": [
  null,
  "Корпус для периферийных устройств"
 ],
 "Pick date": [
  null,
  "Выбор даты"
 ],
 "Pizza box": [
  null,
  "Ультратонкий корпус"
 ],
 "Portable": [
  null,
  "Портативный компьютер"
 ],
 "Present": [
  null,
  "Присутствует"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Превышено время ожидания запроса по ssh-add"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Превышено время ожидания запроса по ssh-keygen"
 ],
 "RAID chassis": [
  null,
  "Корпус для RAID-массива"
 ],
 "RAM": [
  null,
  "ОЗУ"
 ],
 "Rack mount chassis": [
  null,
  "Монтируемый в стойку корпус"
 ],
 "Read": [
  null,
  "Чтение"
 ],
 "Read more...": [
  null,
  "Подробнее…"
 ],
 "Reboot": [
  null,
  "Перезагрузка"
 ],
 "Removals:": [
  null,
  "Для удаления:"
 ],
 "Removing $0": [
  null,
  "Удаление $0"
 ],
 "Row expansion": [
  null,
  "Расширение строки"
 ],
 "Row select": [
  null,
  "Выбор строки"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Запустите эту команду через доверенную сеть или физически на удалённом компьютере:"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "SSH-ключ"
 ],
 "Save": [
  null,
  "Сохранить"
 ],
 "Sealed-case PC": [
  null,
  "Компьютер с невскрываемым корпусом"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Настройка и устранение неисправностей в Linux с улучшенной системой безопасности"
 ],
 "Server has closed the connection.": [
  null,
  "Сервер закрыл соединение."
 ],
 "Service": [
  null,
  "Служба"
 ],
 "Set time": [
  null,
  "Настроить время"
 ],
 "Shell script": [
  null,
  "Сценарий оболочки"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show confirmation password": [
  null,
  "Показать подтверждение пароля"
 ],
 "Show password": [
  null,
  "Показать пароль"
 ],
 "Shut down": [
  null,
  "Завершение работы"
 ],
 "Single rank": [
  null,
  "Одноранговая"
 ],
 "Space-saving computer": [
  null,
  "Компактный компьютер"
 ],
 "Specific time": [
  null,
  "Определённое время"
 ],
 "Stick PC": [
  null,
  "ПК-брелок"
 ],
 "Storage": [
  null,
  "Хранилище"
 ],
 "Strong password": [
  null,
  "Надёжный пароль"
 ],
 "Sub-Chassis": [
  null,
  "Дополнительный корпус"
 ],
 "Sub-Notebook": [
  null,
  "Субноутбук"
 ],
 "Swap": [
  null,
  "Подкачка"
 ],
 "Swap out": [
  null,
  "Подкачка"
 ],
 "Synchronized": [
  null,
  "Синхронизировано"
 ],
 "Synchronized with $0": [
  null,
  "Синхронизировано с $0"
 ],
 "Synchronizing": [
  null,
  "Синхронизация"
 ],
 "Tablet": [
  null,
  "Планшетный ПК"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "SSH-ключ $0 для $1 на $2 будет добавлен к файлу $3 для $4 на $5."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH-ключ $0 будет предоставлен на оставшееся время сеанса, а также будет доступен для входа на другие узлы."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "SSH-ключ для входа на $0 защищён паролем, а вход с паролем на узле запрещён. Введите пароль для ключа на $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "SSH-ключ для входа на $0 защищён. Вход возможен либо при указании пароля для входа, либо пароля ключа на $1."
 ],
 "The fingerprint should match:": [
  null,
  "Отпечаток должен соответствовать:"
 ],
 "The key password can not be empty": [
  null,
  "Пароль ключа не может быть пустым"
 ],
 "The key passwords do not match": [
  null,
  "Пароли ключа не совпадают"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Текущему пользователю запрещено просматривать изменения системы"
 ],
 "The password can not be empty": [
  null,
  "Пароль не может быть пустым"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Полученный отпечаток можно распространять по общедоступным каналам связи, включая электронную почту."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Полученный отпечаток пальца можно передавать общедоступными способами, включая электронную почту. Если вы просите кого-то другого выполнить проверку за вас, они могут отправить результаты любым способом."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Сервер отклонил проверку подлинности с использованием любых поддерживаемых методов."
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Этот инструмент настраивает правила SELinux и может помочь в понимании и устранении нарушений правил."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Этот инструмент создаёт архив данных по настройкам и диагностике для запущенной системы. Архив может быть сохранён локально или централизованно с целью журналирования или слежения или отправлен представителям технической поддержки, разработчикам или администраторам системы, чтобы помочь с поиском технических проблем и диагностикой."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Этот инструмент управляет локальными хранилищами, такими как файловые системы, группы томов LVM2, и монтированиями NFS."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Этот инструмент управляет возможностями работы в сети, в частности связями, мостами, командами, виртуальными LAN и брандмауэрами, с помощью NetworkManager и Firewalld. NetworkManager несовместим с типичным для Ubuntu systemd-networkd и скриптами ifupdown Debian."
 ],
 "Time zone": [
  null,
  "Часовой пояс"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Чтобы убедиться в том, что данные вашего соединения не были перехвачены злоумышленниками, проверьте отпечаток ключа данного узла:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Для проверки отпечатка запустите следующую команду на $0, физически работая на этом компьютере или по доверенной сети:"
 ],
 "Today": [
  null,
  "Сегодня"
 ],
 "Toggle date picker": [
  null,
  "Переключить средство выбора даты"
 ],
 "Too much data": [
  null,
  "Слишком много данных"
 ],
 "Top 5 CPU services": [
  null,
  "5 служб с самым большим потреблением процессорного времени"
 ],
 "Top 5 disk usage services": [
  null,
  "Топ-5 служб по использованию диска"
 ],
 "Top 5 memory services": [
  null,
  "5 служб с самым большим потреблением памяти"
 ],
 "Total size: $0": [
  null,
  "Общий размер: $0"
 ],
 "Tower": [
  null,
  "Компьютер в корпусе «башня»"
 ],
 "Troubleshoot": [
  null,
  "Устранить неполадки"
 ],
 "Trust and add host": [
  null,
  "Доверять и добавить хост"
 ],
 "Trying to synchronize with $0": [
  null,
  "Попытка синхронизации с $0"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Не удалось войти на $0. Узел не принимает вход ни по паролю, ни по одному из имеющихся SSH-ключей."
 ],
 "Unknown": [
  null,
  "Неизвестно"
 ],
 "Untrusted host": [
  null,
  "Недоверенный узел"
 ],
 "Usage": [
  null,
  "Использование"
 ],
 "Used": [
  null,
  "Использовано"
 ],
 "Verify fingerprint": [
  null,
  "Проверить отпечаток"
 ],
 "View all CPUs": [
  null,
  "Смотреть все ЦП"
 ],
 "View all disks": [
  null,
  "Смотреть все диски"
 ],
 "View all logs": [
  null,
  "Смотреть все журналы"
 ],
 "View automation script": [
  null,
  "Просмотреть сценарий автоматизации"
 ],
 "View detailed logs": [
  null,
  "Смотреть подробные журналы"
 ],
 "View per-disk throughput": [
  null,
  "Смотреть пропускную способность по дискам"
 ],
 "Visit firewall": [
  null,
  "Перейти к межсетевому экрану"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Ожидание завершения других операций управления программным обеспечением"
 ],
 "Weak password": [
  null,
  "Ненадёжный пароль"
 ],
 "Web Console for Linux servers": [
  null,
  "Веб-консоль для серверов Linux"
 ],
 "Write": [
  null,
  "Запись"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Подключение к $0 выполняется в первый раз."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "В данном браузере отсутствует возможность вставки с помощью контекстного меню. Можно использовать комбинацию Shift+Insert."
 ],
 "Your session has been terminated.": [
  null,
  "Сеанс завершён."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Срок действия сеанса истёк. Войдите в систему снова."
 ],
 "Zone": [
  null,
  "Зона"
 ],
 "[binary data]": [
  null,
  "[двоичные данные]"
 ],
 "[no data]": [
  null,
  "[нет данных]"
 ],
 "average: $0%": [
  null,
  "среднее: $0%"
 ],
 "cockpit-podman is not installed": [
  null,
  "cockpit-podman не установлен"
 ],
 "in less than a minute": [
  null,
  ""
 ],
 "less than a minute ago": [
  null,
  ""
 ],
 "max: $0%": [
  null,
  "максимальное: $0%"
 ],
 "nice": [
  null,
  "приоритетность"
 ],
 "password quality": [
  null,
  "качество пароля"
 ],
 "pmlogger.service has failed": [
  null,
  "сбой службы pmlogger.service"
 ],
 "pmlogger.service is failing to collect data": [
  null,
  "pmlogger.service не может собрать данные"
 ],
 "pmlogger.service is not running": [
  null,
  "pmlogger.service не работает"
 ],
 "pod": [
  null,
  "контейнер"
 ],
 "show less": [
  null,
  "показать меньше"
 ],
 "show more": [
  null,
  "показать больше"
 ],
 "sys": [
  null,
  "система"
 ],
 "user": [
  null,
  "пользователь"
 ]
});
