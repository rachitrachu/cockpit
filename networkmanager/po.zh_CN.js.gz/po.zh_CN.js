cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "zh_CN",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 active zone": [
  null,
  "$0 个已启用的安全区域"
 ],
 "$0 day": [
  null,
  "$0 天"
 ],
 "$0 exited with code $1": [
  null,
  "$0 退出，返回码为 $1"
 ],
 "$0 failed": [
  null,
  "$0 失败"
 ],
 "$0 hour": [
  null,
  "$0 小时"
 ],
 "$0 is not available from any repository.": [
  null,
  "没有提供 $0 组件的仓库。"
 ],
 "$0 key changed": [
  null,
  "已更改 $0 个密钥"
 ],
 "$0 killed with signal $1": [
  null,
  "进程 $0 被信号 $1 终止"
 ],
 "$0 minute": [
  null,
  "$0 分钟"
 ],
 "$0 month": [
  null,
  "$0 月"
 ],
 "$0 week": [
  null,
  "$0 周"
 ],
 "$0 will be installed.": [
  null,
  "即将安装 $0。"
 ],
 "$0 year": [
  null,
  "$0 年"
 ],
 "$0 zone": [
  null,
  "$0 安全区域"
 ],
 "1 day": [
  null,
  "1 天"
 ],
 "1 hour": [
  null,
  "1 小时"
 ],
 "1 minute": [
  null,
  "1 分钟"
 ],
 "1 week": [
  null,
  "1 周"
 ],
 "20 minutes": [
  null,
  "20 分钟"
 ],
 "40 minutes": [
  null,
  "40 分钟"
 ],
 "5 minutes": [
  null,
  "5 分钟"
 ],
 "6 hours": [
  null,
  "6 小时"
 ],
 "60 minutes": [
  null,
  "60 分钟"
 ],
 "802.3ad": [
  null,
  "802.3ad"
 ],
 "802.3ad LACP": [
  null,
  "802.3ad LACP"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "主机 $0 上找不到版本兼容的 Cockpit。"
 ],
 "A network bond combines multiple network interfaces into one logical interface with higher throughput or redundancy.": [
  null,
  "网络绑定 (Network Bond) ：将多个网络接口组合成一个逻辑接口以提高吞吐量和冗余度。"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "将在 $2 上为 $1 在 $0 处创建一个新的 SSH 密钥，该密钥将在 $5 上被添加到 $4 的 $3 文件中。"
 ],
 "ARP": [
  null,
  "ARP"
 ],
 "ARP monitoring": [
  null,
  "ARP 监控"
 ],
 "ARP ping": [
  null,
  "ARP ping"
 ],
 "Absent": [
  null,
  "空缺"
 ],
 "Acceptable password": [
  null,
  "可行的密码"
 ],
 "Active": [
  null,
  "已启用"
 ],
 "Active backup": [
  null,
  "已启用的备用接口"
 ],
 "Adaptive load balancing": [
  null,
  "自适应性负载均衡"
 ],
 "Adaptive transmit load balancing": [
  null,
  "自适应性传输负载均衡"
 ],
 "Add": [
  null,
  "添加"
 ],
 "Add $0": [
  null,
  "添加 $0"
 ],
 "Add DNS server": [
  null,
  "添加DNS服务器"
 ],
 "Add VLAN": [
  null,
  "添加 VLAN"
 ],
 "Add VPN": [
  null,
  "添加 VPN"
 ],
 "Add WireGuard VPN": [
  null,
  "添加 WireGuard VPN"
 ],
 "Add a new zone": [
  null,
  "添加安全区域"
 ],
 "Add address": [
  null,
  "添加地址"
 ],
 "Add bond": [
  null,
  "添加绑定"
 ],
 "Add bridge": [
  null,
  "添加网桥"
 ],
 "Add member": [
  null,
  "添加成员"
 ],
 "Add new zone": [
  null,
  "添加安全区域"
 ],
 "Add peer": [
  null,
  "添加同行"
 ],
 "Add ports": [
  null,
  "添加端口"
 ],
 "Add ports to $0 zone": [
  null,
  "添加端口到安全区域 $0"
 ],
 "Add route": [
  null,
  "添加路线"
 ],
 "Add search domain": [
  null,
  "添加搜索域"
 ],
 "Add services": [
  null,
  "添加系统服务"
 ],
 "Add services to $0 zone": [
  null,
  "添加系统服务到安全区域 $0"
 ],
 "Add services to zone $0": [
  null,
  "添加系统服务到安全区域 $0"
 ],
 "Add team": [
  null,
  "添加组合"
 ],
 "Add zone": [
  null,
  "添加安全区域"
 ],
 "Adding $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "添加 $0 将中断您与服务器的连接，届时管理界面将无法使用。"
 ],
 "Adding custom ports will reload firewalld. A reload will result in the loss of any runtime-only configuration!": [
  null,
  "添加自定义端口需要重启 firewalld，当前的运行时配置将会丢失！"
 ],
 "Additional DNS $val": [
  null,
  "备用 DNS 服务器：$val"
 ],
 "Additional DNS search domains $val": [
  null,
  "备用 DNS 搜索域 $val"
 ],
 "Additional address $val": [
  null,
  "其他 IP 地址 $val"
 ],
 "Additional packages:": [
  null,
  "额外软件包："
 ],
 "Additional ports": [
  null,
  "额外端口"
 ],
 "Address": [
  null,
  "IP 地址"
 ],
 "Address $val": [
  null,
  "IP 地址： $val"
 ],
 "Addresses": [
  null,
  "IP 地址"
 ],
 "Addresses are not formatted correctly": [
  null,
  "地址格式不正确"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "使用 Cockpit 网页控制台管理系统"
 ],
 "Advanced TCA": [
  null,
  "高级 TCA"
 ],
 "All-in-one": [
  null,
  "一体化"
 ],
 "Allowed IPs": [
  null,
  "白名单IP地址"
 ],
 "Allowed addresses": [
  null,
  "白名单地址"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Ansible 角色文档"
 ],
 "Authenticating": [
  null,
  "正在认证"
 ],
 "Authentication": [
  null,
  "认证"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "通过Cockpit Web Console进行验证后才能执行特权操作"
 ],
 "Authorize SSH key": [
  null,
  "授权 SSH 密钥"
 ],
 "Automatic": [
  null,
  "自动"
 ],
 "Automatic (DHCP only)": [
  null,
  "自动 (仅 DHCP)"
 ],
 "Automatically using NTP": [
  null,
  "自动使用 NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "自动使用额外的 NTP 服务器"
 ],
 "Automatically using specific NTP servers": [
  null,
  "自动使用指定的 NTP 服务器"
 ],
 "Automation script": [
  null,
  "自动化脚本"
 ],
 "Balancer": [
  null,
  "平衡器"
 ],
 "Blade": [
  null,
  "刀片"
 ],
 "Blade enclosure": [
  null,
  "刀片机箱"
 ],
 "Bond": [
  null,
  "绑定"
 ],
 "Bridge": [
  null,
  "网桥"
 ],
 "Bridge port": [
  null,
  "网桥端口"
 ],
 "Bridge port settings": [
  null,
  "网桥端口设置"
 ],
 "Broadcast": [
  null,
  "广播"
 ],
 "Broken configuration": [
  null,
  "错误的配置"
 ],
 "Bus expansion chassis": [
  null,
  "总线扩展机箱"
 ],
 "Cancel": [
  null,
  "取消"
 ],
 "Cannot forward login credentials": [
  null,
  "无法转发登录凭证"
 ],
 "Cannot schedule event in the past": [
  null,
  "无法调度以前的事件"
 ],
 "Carrier": [
  null,
  "载体"
 ],
 "Change": [
  null,
  "变更"
 ],
 "Change system time": [
  null,
  "修改系统时间"
 ],
 "Change the settings": [
  null,
  "修改设置"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "密钥的变化通常是操作系统重新安装的结果。但是，意料外的变化可能代表有第三方尝试截获您的连接。"
 ],
 "Changing the settings will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "修改设置将会中断与服务器的连接，并将导致管理界面不可用。"
 ],
 "Checking IP": [
  null,
  "正在检查 IP"
 ],
 "Checking installed software": [
  null,
  "检查安装的软件"
 ],
 "Clear input value": [
  null,
  "清除输入值"
 ],
 "Close": [
  null,
  "关闭"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "NetworkManager 的 Cockpit 配置和防火墙"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit 无法联系指定的主机。"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit 是一个服务器管理工具，可以方便地通过浏览器来管理您的 Linux 服务器。在终端和 web 工具间自由切换将不是问题。通过 Cockpit 启动的服务可以通过终端停止。同样，如果在终端中发生错误, 也可以在 Cockpit 的日志接口中看到。"
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit 与系统上的软件不兼容。"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit 未安装"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit 未安装在系统上。"
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit 是完美的系统管理员工具，它可以轻松完成简单的任务, 如存储管理, 检查日志信息，以及启动/停止服务。 您可以同时监控和管理多个服务器。点一键就可以添加服务器，并开始进行管理。"
 ],
 "Collect and package diagnostic and support data": [
  null,
  "收集并打包诊断和支持数据"
 ],
 "Collect kernel crash dumps": [
  null,
  "收集内核崩溃转储"
 ],
 "Comma-separated ports, ranges, and services are accepted": [
  null,
  "可以接受以逗号分割的端口、范围和服务"
 ],
 "Compact PCI": [
  null,
  "紧凑型 PCI"
 ],
 "Configuring": [
  null,
  "配置中"
 ],
 "Configuring IP": [
  null,
  "正在配置 IP"
 ],
 "Confirm key password": [
  null,
  "确认密钥密码"
 ],
 "Confirm removal of $0": [
  null,
  "确认移除 $0"
 ],
 "Connect automatically": [
  null,
  "自动连接"
 ],
 "Connection has timed out.": [
  null,
  "连接超时。"
 ],
 "Connection will be lost": [
  null,
  "连接将丢失"
 ],
 "Convertible": [
  null,
  "可转换"
 ],
 "Copied": [
  null,
  "复制的"
 ],
 "Copy": [
  null,
  "复制"
 ],
 "Copy to clipboard": [
  null,
  "复制到剪贴板"
 ],
 "Create $0": [
  null,
  "创建 $0"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "创建一个新的 SSH 密钥，并对其进行授权"
 ],
 "Create it": [
  null,
  "创建它"
 ],
 "Create new task file with this content.": [
  null,
  "使用此内容创建新的任务文件。"
 ],
 "Creating this $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "创建该 $0 将会中断与服务器的连接，并且将会导致管理界面不可用。"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Custom ports": [
  null,
  "自定义端口"
 ],
 "Custom zones": [
  null,
  "自定义区域"
 ],
 "DNS": [
  null,
  "DNS"
 ],
 "DNS $val": [
  null,
  "DNS $val"
 ],
 "DNS search domains": [
  null,
  "DNS 搜索域"
 ],
 "DNS search domains $val": [
  null,
  "DNS 搜索域 $val"
 ],
 "Deactivating": [
  null,
  "取消激活中"
 ],
 "Delay": [
  null,
  "延时"
 ],
 "Delete": [
  null,
  "删除"
 ],
 "Delete $0": [
  null,
  "删除 $0"
 ],
 "Deleting $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "删除 $0 将会中断与服务器的连接，并且将会导致管理界面不可用。"
 ],
 "Description": [
  null,
  "描述"
 ],
 "Desktop": [
  null,
  "桌面"
 ],
 "Detachable": [
  null,
  "可拆开"
 ],
 "Diagnostic reports": [
  null,
  "诊断报告"
 ],
 "Disable the firewall": [
  null,
  "禁用防火墙"
 ],
 "Disabled": [
  null,
  "禁用"
 ],
 "Docking station": [
  null,
  "扩展坞"
 ],
 "Downloading $0": [
  null,
  "正在下载 $0"
 ],
 "Dual rank": [
  null,
  "双通道"
 ],
 "Edit": [
  null,
  "编辑"
 ],
 "Edit VLAN settings": [
  null,
  "编辑 VLAN 设置"
 ],
 "Edit WireGuard VPN": [
  null,
  "编辑 WireGuard VPN"
 ],
 "Edit bond settings": [
  null,
  "编辑绑定设置"
 ],
 "Edit bridge settings": [
  null,
  "编辑网桥设置"
 ],
 "Edit custom service in $0 zone": [
  null,
  "编辑 $0 区中的自定义服务"
 ],
 "Edit rules and zones": [
  null,
  "编辑规则和区域"
 ],
 "Edit service": [
  null,
  "编辑服务"
 ],
 "Edit service $0": [
  null,
  "编辑服务 $0"
 ],
 "Edit team settings": [
  null,
  "编辑组合设置"
 ],
 "Embedded PC": [
  null,
  "嵌入式 PC"
 ],
 "Enable or disable the device": [
  null,
  "启用或禁用设备"
 ],
 "Enable service": [
  null,
  "启用服务"
 ],
 "Enable the firewall": [
  null,
  "启用防火墙"
 ],
 "Enabled": [
  null,
  "启用"
 ],
 "Endpoint": [
  null,
  "端点"
 ],
 "Endpoint acting as a \"server\" need to be specified as host:port, otherwise it can be left empty.": [
  null,
  "作为 \"服务器\" 的端点需要指定为 host:port，或者也可以留空。"
 ],
 "Enter a valid MAC address": [
  null,
  "输入有效的 MAC 地址"
 ],
 "Entire subnet": [
  null,
  "整个子网"
 ],
 "Ethernet MAC": [
  null,
  "以太网 MAC"
 ],
 "Ethernet MTU": [
  null,
  "以太网 MTU"
 ],
 "Ethtool": [
  null,
  "Ethtool"
 ],
 "Example: 22,ssh,8080,5900-5910": [
  null,
  "例如: 22,ssh,8080,5900-5910"
 ],
 "Example: 88,2019,nfs,rsync": [
  null,
  "例如: 88,2019,nfs,rsync"
 ],
 "Excellent password": [
  null,
  "密码强度良好"
 ],
 "Expansion chassis": [
  null,
  "扩展机箱"
 ],
 "Failed": [
  null,
  "已失败"
 ],
 "Failed to add port": [
  null,
  "添加端口失败"
 ],
 "Failed to add service": [
  null,
  "添加服务失败"
 ],
 "Failed to add zone": [
  null,
  "添加区域失败"
 ],
 "Failed to change password": [
  null,
  "修改密码失败"
 ],
 "Failed to edit service": [
  null,
  "编辑服务失败"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "在 firewalld 中启用 $0 失败"
 ],
 "Failed to save settings": [
  null,
  "保存设置失败"
 ],
 "Filter services": [
  null,
  "过滤服务"
 ],
 "Firewall": [
  null,
  "防火墙"
 ],
 "Firewall is not available": [
  null,
  "防火墙不可用"
 ],
 "Forward delay $forward_delay": [
  null,
  "转发延迟 $forward_delay"
 ],
 "Gateway": [
  null,
  "网关"
 ],
 "General": [
  null,
  "通用"
 ],
 "Generated": [
  null,
  "生成的"
 ],
 "Go to now": [
  null,
  "转到现在"
 ],
 "Group": [
  null,
  "组"
 ],
 "Hair pin mode": [
  null,
  "发夹模式"
 ],
 "Hairpin mode": [
  null,
  "发夹模式"
 ],
 "Handheld": [
  null,
  "手持式"
 ],
 "Hello time $hello_time": [
  null,
  "Hello 时间 $hello_time"
 ],
 "Hide confirmation password": [
  null,
  "隐藏确认密码"
 ],
 "Hide password": [
  null,
  "隐藏密码"
 ],
 "Host key is incorrect": [
  null,
  "主机密钥不正确"
 ],
 "ID": [
  null,
  "ID"
 ],
 "ID $id": [
  null,
  "ID $id"
 ],
 "IP address": [
  null,
  "IP 地址"
 ],
 "IP address with routing prefix. Separate multiple values with a comma. Example: 192.0.2.0/24, 2001:db8::/32": [
  null,
  "带有路由前缀的IP地址。用逗号分隔多个值。例如：192.0.2.0/24, 2001:db8::/32"
 ],
 "IPv4": [
  null,
  "IPv4"
 ],
 "IPv4 addresses": [
  null,
  "IPv4 地址"
 ],
 "IPv4 settings": [
  null,
  "IPv4 设置"
 ],
 "IPv6": [
  null,
  "IPv6"
 ],
 "IPv6 settings": [
  null,
  "IPv6 设置"
 ],
 "If left empty, ID will be generated based on associated port services and port numbers": [
  null,
  "如果为空，则将根据关联的端口服务和端口号生成 ID"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "如果指纹匹配，点 'Trust and add host'。否则，请不要连接并联系您的管理员。"
 ],
 "Ignore": [
  null,
  "忽略"
 ],
 "Inactive": [
  null,
  "未激活"
 ],
 "Included services": [
  null,
  "包括的服务"
 ],
 "Incoming requests are blocked by default. Outgoing requests are not blocked.": [
  null,
  "传入请求被默认阻断。传出请求不会被阻断。"
 ],
 "Install": [
  null,
  "安装"
 ],
 "Install software": [
  null,
  "安装软件"
 ],
 "Installing $0": [
  null,
  "正在安装 $0"
 ],
 "Interface": [
  null,
  "接口"
 ],
 "Interface members": [
  null,
  "接口成员"
 ],
 "Interfaces": [
  null,
  "接口"
 ],
 "Internal error": [
  null,
  "内部错误"
 ],
 "Invalid address $0": [
  null,
  "无效的地址 $0"
 ],
 "Invalid date format": [
  null,
  "无效的日期格式"
 ],
 "Invalid date format and invalid time format": [
  null,
  "无效的日期格式和时间格式"
 ],
 "Invalid file permissions": [
  null,
  "无效的文件权限"
 ],
 "Invalid metric $0": [
  null,
  "无效的度量 $0"
 ],
 "Invalid port number": [
  null,
  "无效的端口号"
 ],
 "Invalid prefix $0": [
  null,
  "无效的前缀 $0"
 ],
 "Invalid prefix or netmask $0": [
  null,
  "无效的前缀或掩码 $0"
 ],
 "Invalid range": [
  null,
  "无效范围"
 ],
 "Invalid time format": [
  null,
  "无效的时间格式"
 ],
 "Invalid timezone": [
  null,
  "无效的时区"
 ],
 "IoT gateway": [
  null,
  "IoT 网关"
 ],
 "Keep connection": [
  null,
  "保持连接"
 ],
 "Kernel dump": [
  null,
  "内核转储"
 ],
 "Key password": [
  null,
  "钥匙密码"
 ],
 "LACP key": [
  null,
  "LACP 密钥"
 ],
 "Laptop": [
  null,
  "笔记本电脑"
 ],
 "Learn more": [
  null,
  "了解更多"
 ],
 "Link down delay": [
  null,
  "链路断开延时"
 ],
 "Link local": [
  null,
  "本地链路"
 ],
 "Link monitoring": [
  null,
  "链路监控"
 ],
 "Link up delay": [
  null,
  "链路启用延时"
 ],
 "Link watch": [
  null,
  "侦测连接状态"
 ],
 "Listen port": [
  null,
  "侦听端口"
 ],
 "Listen port must be a number": [
  null,
  "侦听端口必须是一个数字"
 ],
 "Load balancing": [
  null,
  "负载均衡"
 ],
 "Loading system modifications...": [
  null,
  "加载系统改变..."
 ],
 "Log in": [
  null,
  "登录"
 ],
 "Log in to $0": [
  null,
  "登录到 $0"
 ],
 "Log messages": [
  null,
  "日志消息"
 ],
 "Login failed": [
  null,
  "登录失败"
 ],
 "Low profile desktop": [
  null,
  "低调桌面"
 ],
 "Lunch box": [
  null,
  "主机类型"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "MII (recommended)": [
  null,
  "MII (推荐)"
 ],
 "MTU": [
  null,
  "MTU"
 ],
 "MTU must be a positive number": [
  null,
  "MTU 必须是正整数"
 ],
 "Main server chassis": [
  null,
  "主服务器机箱"
 ],
 "Manage storage": [
  null,
  "管理存储"
 ],
 "Managed interfaces": [
  null,
  "管理的接口"
 ],
 "Manual": [
  null,
  "手动"
 ],
 "Manually": [
  null,
  "手动的"
 ],
 "Maximum message age $max_age": [
  null,
  "最大消息有效期 $max_age"
 ],
 "Message to logged in users": [
  null,
  "发送给已登录用户的信息"
 ],
 "Metric": [
  null,
  "指标"
 ],
 "Mini PC": [
  null,
  "迷你电脑"
 ],
 "Mini tower": [
  null,
  "迷你塔式主机"
 ],
 "Mode": [
  null,
  "模式"
 ],
 "Monitoring interval": [
  null,
  "监控间隔"
 ],
 "Monitoring targets": [
  null,
  "监控目标"
 ],
 "Multi-system chassis": [
  null,
  "多系统机箱"
 ],
 "Multiple addresses can be specified using commas or spaces as delimiters.": [
  null,
  "可以使用逗号或空格作为分隔符来指定多个地址。"
 ],
 "NSNA ping": [
  null,
  "NSNA ping"
 ],
 "NTP server": [
  null,
  "NTP 服务器"
 ],
 "Name": [
  null,
  "名称"
 ],
 "Need at least one NTP server": [
  null,
  "至少需要一个 NTP 服务器"
 ],
 "Network bond": [
  null,
  "网络绑定"
 ],
 "Network devices and graphs require NetworkManager": [
  null,
  "网络设备和图形需要 NetworkManager"
 ],
 "Network logs": [
  null,
  "网络日志"
 ],
 "NetworkManager is not installed": [
  null,
  "未安装 NetworkManager"
 ],
 "NetworkManager is not running": [
  null,
  "NetworkManager 未运行"
 ],
 "Networking": [
  null,
  "网络"
 ],
 "New password was not accepted": [
  null,
  "新密码不被接受"
 ],
 "No": [
  null,
  "否"
 ],
 "No carrier": [
  null,
  "无载体"
 ],
 "No delay": [
  null,
  "无延时"
 ],
 "No description available": [
  null,
  "没有可用描述"
 ],
 "No peers added.": [
  null,
  "没有添加对等。"
 ],
 "No results found": [
  null,
  "没有找到结果"
 ],
 "No such file or directory": [
  null,
  "没有该文件或目录"
 ],
 "No system modifications": [
  null,
  "没有系统改变"
 ],
 "None": [
  null,
  "无"
 ],
 "Not a valid private key": [
  null,
  "无效的私钥"
 ],
 "Not authorized to disable the firewall": [
  null,
  "无权禁用防火墙"
 ],
 "Not authorized to enable the firewall": [
  null,
  "无权启用防火墙"
 ],
 "Not available": [
  null,
  "不可用"
 ],
 "Not permitted to configure network devices": [
  null,
  "不允许配置网络设备"
 ],
 "Not permitted to perform this action.": [
  null,
  "不允许执行该操作。"
 ],
 "Not synchronized": [
  null,
  "未同步"
 ],
 "Notebook": [
  null,
  "笔记本"
 ],
 "Occurrences": [
  null,
  "发生"
 ],
 "Ok": [
  null,
  "确认"
 ],
 "Old password not accepted": [
  null,
  "旧密码不被接受"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "在安装 Cockpit 后，使用 \"systemctl enable --now cockpit.socket\" 启用它。"
 ],
 "Options": [
  null,
  "选项"
 ],
 "Other": [
  null,
  "其他"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit 已崩溃"
 ],
 "Parent": [
  null,
  "父"
 ],
 "Parent $parent": [
  null,
  "父 $parent"
 ],
 "Part of $0": [
  null,
  "$0 的部分"
 ],
 "Passive": [
  null,
  "被动"
 ],
 "Password": [
  null,
  "密码"
 ],
 "Password is not acceptable": [
  null,
  "不接受该密码"
 ],
 "Password is too weak": [
  null,
  "密码太弱"
 ],
 "Password not accepted": [
  null,
  "密码未接受"
 ],
 "Paste": [
  null,
  "粘贴"
 ],
 "Paste error": [
  null,
  "粘贴错误"
 ],
 "Paste existing key": [
  null,
  "粘贴现有密钥"
 ],
 "Path cost": [
  null,
  "路径开销"
 ],
 "Path cost $path_cost": [
  null,
  "路径开销 $path_cost"
 ],
 "Path to file": [
  null,
  "文件路径"
 ],
 "Peer #$0 has invalid endpoint port. Port must be a number.": [
  null,
  "对等 #$0 有无效的端点端口。端口必须是一个数字。"
 ],
 "Peer #$0 has invalid endpoint. It must be specified as host:port, e.g. 1.2.3.4:51820 or example.com:51820": [
  null,
  "对等 #$0 有无效的端点。它需要以 host:port 的形式指定，如 1.2.3.4:51820 或 example.com:51820"
 ],
 "Peers": [
  null,
  "对等"
 ],
 "Peers are other machines that connect with this one. Public keys from other machines will be shared with each other.": [
  null,
  "对等（peer）是与这个系统连接的其他机器。来自其他机器中的公钥将相互共享。"
 ],
 "Peripheral chassis": [
  null,
  "外设机箱"
 ],
 "Permanent": [
  null,
  "永久的"
 ],
 "Pick date": [
  null,
  "选择日期"
 ],
 "Ping interval": [
  null,
  "Ping 周期"
 ],
 "Ping target": [
  null,
  "Ping 目标"
 ],
 "Pizza box": [
  null,
  "披萨盒"
 ],
 "Please install the $0 package": [
  null,
  "请安装 $0 软件包"
 ],
 "Portable": [
  null,
  "手提"
 ],
 "Ports": [
  null,
  "端口"
 ],
 "Prefix length": [
  null,
  "前缀长度"
 ],
 "Prefix length or netmask": [
  null,
  "前缀长度或网络掩码"
 ],
 "Preparing": [
  null,
  "准备中"
 ],
 "Present": [
  null,
  "当前"
 ],
 "Preserve": [
  null,
  "保留"
 ],
 "Primary": [
  null,
  "主"
 ],
 "Priority": [
  null,
  "优先级"
 ],
 "Priority $priority": [
  null,
  "优先级 $priority"
 ],
 "Private key": [
  null,
  "私钥"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "通过 ssh-add 提示超时"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "通过 ssh-keygen 提示超时"
 ],
 "Public key": [
  null,
  "公钥"
 ],
 "Public key will be generated when a valid private key is entered": [
  null,
  "在输入有效私钥时将生成公钥"
 ],
 "RAID chassis": [
  null,
  "RAID 机箱"
 ],
 "Rack mount chassis": [
  null,
  "机架式机箱"
 ],
 "Random": [
  null,
  "随机"
 ],
 "Range": [
  null,
  "范围"
 ],
 "Range must be strictly ordered": [
  null,
  "范围必须排序"
 ],
 "Reboot": [
  null,
  "重启"
 ],
 "Receiving": [
  null,
  "接收"
 ],
 "Regenerate": [
  null,
  "重新生成"
 ],
 "Removals:": [
  null,
  "移除："
 ],
 "Remove $0": [
  null,
  "移除 $0"
 ],
 "Remove $0 service from $1 zone": [
  null,
  "从 $1 区域中删除 $0 服务"
 ],
 "Remove item": [
  null,
  "删除项目"
 ],
 "Remove service $0": [
  null,
  "删除服务 $0"
 ],
 "Remove zone $0": [
  null,
  "移除区 $0"
 ],
 "Removing $0": [
  null,
  "正在删除 $0"
 ],
 "Removing $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "删除 $0 将断开与服务器的连接，并将导致管理界面不可用。"
 ],
 "Removing the cockpit service might result in the web console becoming unreachable. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "删除 cockpit 服务可能会导致 web 控制台无法被访问。请确认这个区不会应用到当前的 web 控制台连接。"
 ],
 "Removing the zone will remove all services within it.": [
  null,
  "删除区将删除其中的所有服务。"
 ],
 "Restoring connection": [
  null,
  "恢复连接"
 ],
 "Round robin": [
  null,
  "轮循"
 ],
 "Routes": [
  null,
  "路由"
 ],
 "Row expansion": [
  null,
  "行扩展"
 ],
 "Row select": [
  null,
  "行选择"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "通过一个可信网络运行这个命令，或在远程机器上运行这个命令："
 ],
 "Runner": [
  null,
  "运行者"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "SSH 密钥"
 ],
 "SSH key login": [
  null,
  "SSH 密钥登录"
 ],
 "STP forward delay": [
  null,
  "STP 转发延迟"
 ],
 "STP hello time": [
  null,
  "STP Hello 时间"
 ],
 "STP maximum message age": [
  null,
  "STP 最大消息有效期"
 ],
 "STP priority": [
  null,
  "STP 优先级"
 ],
 "Save": [
  null,
  "保存"
 ],
 "Sealed-case PC": [
  null,
  "密封式 PC"
 ],
 "Search domain": [
  null,
  "搜索域"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Security Enhanced Linux 配置和故障排除"
 ],
 "Select an option": [
  null,
  "选择一个选项"
 ],
 "Select method": [
  null,
  "选择方法"
 ],
 "Sending": [
  null,
  "发送"
 ],
 "Server": [
  null,
  "服务器"
 ],
 "Server has closed the connection.": [
  null,
  "服务器已关闭了连接。"
 ],
 "Service": [
  null,
  "服务"
 ],
 "Services": [
  null,
  "服务"
 ],
 "Set time": [
  null,
  "设置时间"
 ],
 "Set to": [
  null,
  "设置为"
 ],
 "Shared": [
  null,
  "共享"
 ],
 "Shell script": [
  null,
  "Shell 脚本"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show confirmation password": [
  null,
  "显示确认密码"
 ],
 "Show password": [
  null,
  "显示密码"
 ],
 "Shut down": [
  null,
  "关机"
 ],
 "Single rank": [
  null,
  "单 rank"
 ],
 "Sorted from least to most trusted": [
  null,
  "按最不被信任到最被信任的顺序排序"
 ],
 "Space-saving computer": [
  null,
  "节省空间的计算机"
 ],
 "Spanning tree protocol": [
  null,
  "生成树协议"
 ],
 "Spanning tree protocol (STP)": [
  null,
  "生成树协议 (STP)"
 ],
 "Specific time": [
  null,
  "指定时间"
 ],
 "Stable": [
  null,
  "稳定的"
 ],
 "Start service": [
  null,
  "启动服务"
 ],
 "Status": [
  null,
  "状态"
 ],
 "Stick PC": [
  null,
  "PC 棒"
 ],
 "Sticky": [
  null,
  "粘性的"
 ],
 "Storage": [
  null,
  "存储"
 ],
 "Strong password": [
  null,
  "强密码"
 ],
 "Sub-Chassis": [
  null,
  "子机箱"
 ],
 "Sub-Notebook": [
  null,
  "子笔记本"
 ],
 "Switch off $0": [
  null,
  "关掉 $0"
 ],
 "Switch on $0": [
  null,
  "打开 $0"
 ],
 "Switching off $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "关掉 $0 将中断与服务器的连接，并将导致管理界面不可用。"
 ],
 "Switching on $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "打开 $0 将中断与服务器的连接，并将导致管理界面不可用。"
 ],
 "Synchronized": [
  null,
  "已同步"
 ],
 "Synchronized with $0": [
  null,
  "与 $0 同步"
 ],
 "Synchronizing": [
  null,
  "同步"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "Tablet": [
  null,
  "平板"
 ],
 "Team": [
  null,
  "组合"
 ],
 "Team port": [
  null,
  "组合端口"
 ],
 "Team port settings": [
  null,
  "组合端口设置"
 ],
 "Testing connection": [
  null,
  "测试连接"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "$2 上 $1 的 SSH 密钥 $0 将被添加到 $5 上 $4 的 $3 文件中。"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH 密钥 $0 将会在剩余的会话中可用，也可以在登录到其他主机时可用。"
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "登录到 $0 的 SSH 密钥是受密码保护的，主机不允许使用密码登录。请在 $1 提供密钥的密码。"
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "登录到 $0 的 SSH 密钥是受保护的。您可以用您的登录密码或通过在 $1 提供密钥的密码来登录。"
 ],
 "The cockpit service is automatically included": [
  null,
  "cockpit 服务被自动包括"
 ],
 "The fingerprint should match:": [
  null,
  "指纹应匹配："
 ],
 "The key password can not be empty": [
  null,
  "密钥密码不能为空"
 ],
 "The key passwords do not match": [
  null,
  "密钥密码不匹配"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "登陆的用户没有权限查看系统改变"
 ],
 "The password can not be empty": [
  null,
  "密钥密码不能为空"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "结果指纹可以通过公共方法（包括电子邮件）共享。"
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "生成的指纹可以通过公共方法（包括电子邮件）共享。如果您需要其他人为您进行验证，他们可以使用任何方法发送结果。"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "服务器拒绝使用任何支持的方式来验证。"
 ],
 "There are no active services in this zone": [
  null,
  "该区中没有任何活跃的服务"
 ],
 "This device cannot be managed here.": [
  null,
  "该设备不能在这里被管理。"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "这个工具配置 SELinux 策略，帮助理解和解决策略违规。"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "这个工具将系统配置为写内核崩溃转储。它支持\"local\" (磁盘)、\"ssh\"和\"nfs\"转储目标。"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "此工具从正在运行的系统中生成配置和诊断信息的存档。出于记录或跟踪目的，存档可能被存储在本地或集中存储，或者被发送到技术支持代表、开发人员或系统管理员，以帮助技术故障查找和调试。"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "此工具管理本地存储，如文件系统、LVM2 卷组和 NFS 挂载。"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "此工具使用 NetworkManager 和 Firewalld 管理网络，如绑定、网桥、组合、VLAN 和防火墙等。NetworkManager 与 Ubuntu 默认的 systemd-networkd 以及 Debian 的 ifupdown 脚本不兼容。"
 ],
 "This zone contains the cockpit service. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "这个区包括 cockpit 服务。请确认这个区不会应用到您当前的 web 控制台连接。"
 ],
 "Time zone": [
  null,
  "时区"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "要确保您的连接没有被恶意第三方截取，请验证主机密钥指纹："
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "要验证指纹，在 $0 上运行以下内容（在实际的物理机器上本地进行，或通过一个可信任的网络进行）："
 ],
 "Toggle date picker": [
  null,
  "切换日期选择器"
 ],
 "Too much data": [
  null,
  "太多数据"
 ],
 "Total size: $0": [
  null,
  "总大小：$0"
 ],
 "Tower": [
  null,
  "Tower"
 ],
 "Transmitting": [
  null,
  "传输"
 ],
 "Troubleshoot…": [
  null,
  "检修…"
 ],
 "Trust and add host": [
  null,
  "信任并添加主机"
 ],
 "Trust level": [
  null,
  "信任级别"
 ],
 "Trying to synchronize with $0": [
  null,
  "正在尝试与 $0 同步"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "无法使用 SSH 密钥身份验证登录到 $0。请提供密码。"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "无法登录到 $0 。主机不接受密码登录，或您的任何 SSH 密钥。"
 ],
 "Unexpected error": [
  null,
  "意外的错误"
 ],
 "Unknown": [
  null,
  "未知"
 ],
 "Unknown \"$0\"": [
  null,
  "未知 \"$0\""
 ],
 "Unknown configuration": [
  null,
  "未知配置"
 ],
 "Unknown host: $0": [
  null,
  "未知主机：$0"
 ],
 "Unknown service name": [
  null,
  "未知的服务名"
 ],
 "Unmanaged interfaces": [
  null,
  "未管理的接口"
 ],
 "Untrusted host": [
  null,
  "不可信的主机"
 ],
 "Use $0": [
  null,
  "使用 $0"
 ],
 "VLAN": [
  null,
  "VLAN"
 ],
 "VLAN ID": [
  null,
  "VLAN ID"
 ],
 "Verify fingerprint": [
  null,
  "验证指纹"
 ],
 "View all logs": [
  null,
  "查看所有日志"
 ],
 "View automation script": [
  null,
  "查看自动化脚本"
 ],
 "Visit firewall": [
  null,
  "访问防火墙"
 ],
 "Waiting": [
  null,
  "等待中"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "等待其他软件管理操作完成"
 ],
 "Weak password": [
  null,
  "弱密码"
 ],
 "Web Console for Linux servers": [
  null,
  "Linux 服务器的 Web 控制台"
 ],
 "Will be set to \"Automatic\"": [
  null,
  "将设置为\"Automatic\""
 ],
 "WireGuard": [
  null,
  "WireGuard"
 ],
 "XOR": [
  null,
  "XOR"
 ],
 "Yes": [
  null,
  "是"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "您第一次连接到 $0。"
 ],
 "You are not authorized to modify the firewall.": [
  null,
  "您无权修改防火墙。"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "您的浏览器不允许从上下文菜单中进行粘贴，您可以使用 Shift+Insert。"
 ],
 "Your session has been terminated.": [
  null,
  "会话被终止。"
 ],
 "Your session has expired. Please log in again.": [
  null,
  "会话超时。请重新登录。"
 ],
 "Zone": [
  null,
  "区域"
 ],
 "[binary data]": [
  null,
  "[二进制数据]"
 ],
 "[no data]": [
  null,
  "[没有数据]"
 ],
 "edit": [
  null,
  "编辑"
 ],
 "in less than a minute": [
  null,
  "少于一分钟"
 ],
 "less than a minute ago": [
  null,
  "少于一分钟前"
 ],
 "password quality": [
  null,
  "密码质量"
 ],
 "show less": [
  null,
  "显示更少"
 ],
 "show more": [
  null,
  "显示更多"
 ],
 "wireguard-tools package is not installed": [
  null,
  "未安装 WireGuard-tools 软件包"
 ]
});
