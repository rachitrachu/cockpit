cockpit.locale({
 "": {
  "plural-forms": (n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "ru",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 ГиБ"
 ],
 "$0 active zone": [
  null,
  "$0 активная зона",
  "$0 активных зоны",
  "$0 активных зон"
 ],
 "$0 day": [
  null,
  "$0 день",
  "$0 дня",
  "$0 дней"
 ],
 "$0 exited with code $1": [
  null,
  "Процесс $0 завершил работу с кодом $1"
 ],
 "$0 failed": [
  null,
  "Сбой процесса $0"
 ],
 "$0 hour": [
  null,
  "$0 час",
  "$0 часа",
  "$0 часов"
 ],
 "$0 is not available from any repository.": [
  null,
  "Компонент $0 недоступен в репозиториях."
 ],
 "$0 key changed": [
  null,
  "Изменен $0 ключ"
 ],
 "$0 killed with signal $1": [
  null,
  "Процесс $0 прерван с сигналом $1"
 ],
 "$0 minute": [
  null,
  "$0 минута",
  "$0 минуты",
  "$0 минут"
 ],
 "$0 month": [
  null,
  "$0 месяц",
  "$0 месяца",
  "$0 месяцев"
 ],
 "$0 week": [
  null,
  "$0 неделя",
  "$0 недели",
  "$0 недель"
 ],
 "$0 will be installed.": [
  null,
  "Будет выполнена установка $0."
 ],
 "$0 year": [
  null,
  "$0 год",
  "$0 года",
  "$0 лет"
 ],
 "$0 zone": [
  null,
  "Зона $0"
 ],
 "1 day": [
  null,
  "1 день"
 ],
 "1 hour": [
  null,
  "1 час"
 ],
 "1 minute": [
  null,
  "1 минута"
 ],
 "1 week": [
  null,
  "1 неделя"
 ],
 "20 minutes": [
  null,
  "20 минут"
 ],
 "40 minutes": [
  null,
  "40 минут"
 ],
 "5 minutes": [
  null,
  "5 минут"
 ],
 "6 hours": [
  null,
  "6 часов"
 ],
 "60 minutes": [
  null,
  "60 минут"
 ],
 "802.3ad": [
  null,
  "802.3ad"
 ],
 "802.3ad LACP": [
  null,
  "802.3ad LACP"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Совместимая версия Cockpit не установлена на $0."
 ],
 "A network bond combines multiple network interfaces into one logical interface with higher throughput or redundancy.": [
  null,
  "Сетевое объединение сливает несколько сетевых интерфейсов в один логический интерфейс с увеличенной пропускной способностью или с избыточностью."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Будет создан новый ключ SSH в $0 для $1 на $2 и добавлен в файл $3 $4 на $5."
 ],
 "ARP": [
  null,
  "ARP"
 ],
 "ARP monitoring": [
  null,
  "Мониторинг ARP"
 ],
 "ARP ping": [
  null,
  "ARP ping"
 ],
 "Absent": [
  null,
  "Отсутствует"
 ],
 "Acceptable password": [
  null,
  "Допустимый пароль"
 ],
 "Active": [
  null,
  "Активно"
 ],
 "Active backup": [
  null,
  "Активное резервирование"
 ],
 "Adaptive load balancing": [
  null,
  "Адаптивная балансировка нагрузки"
 ],
 "Adaptive transmit load balancing": [
  null,
  "Адаптивная балансировка нагрузки передачи"
 ],
 "Add": [
  null,
  "Добавить"
 ],
 "Add $0": [
  null,
  "Добавить $0"
 ],
 "Add DNS server": [
  null,
  "Добавить сервер DNS"
 ],
 "Add VLAN": [
  null,
  "Добавить VLAN"
 ],
 "Add VPN": [
  null,
  "Добавить VPN"
 ],
 "Add WireGuard VPN": [
  null,
  "Добавить WireGuard VPN"
 ],
 "Add a new zone": [
  null,
  "Добавить новую зону"
 ],
 "Add address": [
  null,
  "Добавить адрес"
 ],
 "Add bond": [
  null,
  "Добавить Bond"
 ],
 "Add bridge": [
  null,
  "Добавить Bridge"
 ],
 "Add member": [
  null,
  "Добавить участника"
 ],
 "Add new zone": [
  null,
  "Добавить новую зону"
 ],
 "Add peer": [
  null,
  "Добавить узел"
 ],
 "Add ports": [
  null,
  "Добавить порты"
 ],
 "Add ports to $0 zone": [
  null,
  "Добавить порты в зону $0"
 ],
 "Add route": [
  null,
  "Добавить маршрут"
 ],
 "Add search domain": [
  null,
  "Добавить домен поиска"
 ],
 "Add services": [
  null,
  "Добавить службы"
 ],
 "Add services to $0 zone": [
  null,
  "Добавить сервисы в зону $0"
 ],
 "Add services to zone $0": [
  null,
  "Добавить службы в зону $0"
 ],
 "Add team": [
  null,
  "Добавить Team"
 ],
 "Add zone": [
  null,
  "Добавить зону"
 ],
 "Adding $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Добавление $0 приведёт к разрыву соединения с сервером и недоступности интерфейса администратора."
 ],
 "Adding custom ports will reload firewalld. A reload will result in the loss of any runtime-only configuration!": [
  null,
  "Добавление пользовательских портов приведёт к перезагрузке firewalld. При этом будет утеряна любая конфигурация среды выполнения!"
 ],
 "Additional DNS $val": [
  null,
  "Дополнительный DNS $val"
 ],
 "Additional DNS search domains $val": [
  null,
  "Дополнительные домены поиска DNS $val"
 ],
 "Additional address $val": [
  null,
  "Дополнительный адрес $val"
 ],
 "Additional packages:": [
  null,
  "Дополнительные пакеты:"
 ],
 "Additional ports": [
  null,
  "Дополнительные порты"
 ],
 "Address": [
  null,
  "Адрес"
 ],
 "Address $val": [
  null,
  "Адрес $val"
 ],
 "Addresses": [
  null,
  "Адреса"
 ],
 "Addresses are not formatted correctly": [
  null,
  "Адреса имеют некорректный формат"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Администрирование с помощью веб-панели управления Cockpit"
 ],
 "Advanced TCA": [
  null,
  "Расширенный TCA"
 ],
 "All-in-one": [
  null,
  "Все в одном"
 ],
 "Allowed IPs": [
  null,
  "Разрешённые IP-адреса"
 ],
 "Allowed addresses": [
  null,
  "Разрешённые адреса"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Документация к ролям Ansible"
 ],
 "Authenticating": [
  null,
  "Проверка подлинности"
 ],
 "Authentication": [
  null,
  "Проверка подлинности"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Для выполнения привилегированных задач с помощью веб-консоли Cockpit необходима проверка подлинности"
 ],
 "Authorize SSH key": [
  null,
  "Авторизовать SSH-ключ"
 ],
 "Automatic": [
  null,
  "Автоматически"
 ],
 "Automatic (DHCP only)": [
  null,
  "Автоматически (только DHCP)"
 ],
 "Automatically using NTP": [
  null,
  "Автоматически с использованием серверов NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Автоматически с использованием дополнительных серверов NTP"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Автоматически с использованием определённых серверов NTP"
 ],
 "Automation script": [
  null,
  "Сценарий автоматизации"
 ],
 "Balancer": [
  null,
  "Подсистема балансировки"
 ],
 "Blade": [
  null,
  "Ультракомпактный сервер"
 ],
 "Blade enclosure": [
  null,
  "Корзина"
 ],
 "Bond": [
  null,
  "Объединение"
 ],
 "Bridge": [
  null,
  "Мост"
 ],
 "Bridge port": [
  null,
  "Порт моста"
 ],
 "Bridge port settings": [
  null,
  "Параметры порта моста"
 ],
 "Broadcast": [
  null,
  "Трансляция"
 ],
 "Broken configuration": [
  null,
  "Неверная конфигурация"
 ],
 "Bus expansion chassis": [
  null,
  "Корпус расширения шины"
 ],
 "Cancel": [
  null,
  "Отмена"
 ],
 "Cannot forward login credentials": [
  null,
  "Не удаётся передать учётные данные для входа"
 ],
 "Cannot schedule event in the past": [
  null,
  "Невозможно запланировать событие в прошлом"
 ],
 "Carrier": [
  null,
  "Несущая частота"
 ],
 "Change": [
  null,
  "Изменить"
 ],
 "Change system time": [
  null,
  "Изменить системное время"
 ],
 "Change the settings": [
  null,
  "Изменить параметры"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Изменение ключей часто происходит в результате переустановки операционной системы. Однако неожиданное изменение может указывать на попытку третьей стороны перехватить ваше соединение."
 ],
 "Changing the settings will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Изменение параметров приведёт к разрыву соединения с сервером и недоступности интерфейса администратора."
 ],
 "Checking IP": [
  null,
  "Проверка IP-адреса"
 ],
 "Checking installed software": [
  null,
  "Проверка установленного программного обеспечения"
 ],
 "Clear input value": [
  null,
  "Сбросить входное значение"
 ],
 "Close": [
  null,
  "Закрыть"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Настройка Cockpit для NetworkManager и Firewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Не удалось установить связь между Cockpit и заданным узлом."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit представляет собой диспетчер серверов, упрощающий администрирование серверов Linux через веб-браузер. Переключение между терминалом и веб-инструментом не представляет сложности. Служба, запущенная с помощью Cockpit, может быть остановлена через терминал. Аналогично, если в терминале возникает ошибка, её можно увидеть в интерфейсе журнала Cockpit."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit не совместим с программным обеспечением в системе."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit не установлен"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit не установлен в системе."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit идеально подходит для новых системных администраторов, позволяя им легко выполнять простые задачи, такие как администрирование хранилищ, проверка журналов и запуск и остановка служб. С помощью Cockpit вы можете контролировать и администрировать несколько серверов одновременно. Просто добавьте их одним щелчком мыши, и ваш компьютер позаботится о своих приятелях."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Собрать и упаковать диагностические данные и данные поддержки"
 ],
 "Collect kernel crash dumps": [
  null,
  "Собрать аварийный дамп ядра"
 ],
 "Comma-separated ports, ranges, and services are accepted": [
  null,
  "Допустимы порты, диапазоны и службы с запятыми в качестве разделителей"
 ],
 "Compact PCI": [
  null,
  "Компактный PCI"
 ],
 "Configuring": [
  null,
  "Настройка"
 ],
 "Configuring IP": [
  null,
  "Настройка IP-адреса"
 ],
 "Confirm key password": [
  null,
  "Подтвердите ключевой пароль"
 ],
 "Confirm removal of $0": [
  null,
  "Подтвердите удаление $0"
 ],
 "Connect automatically": [
  null,
  "Подключаться автоматически"
 ],
 "Connection has timed out.": [
  null,
  "Превышено время ожидания подключения."
 ],
 "Connection will be lost": [
  null,
  "Подключение будет прервано"
 ],
 "Convertible": [
  null,
  "Компьютер-трансформер"
 ],
 "Copied": [
  null,
  "Скопировано"
 ],
 "Copy": [
  null,
  "Копировать"
 ],
 "Copy to clipboard": [
  null,
  "Копировать в буфер обмена"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Создать новый SSH-ключ и авторизовать его"
 ],
 "Create it": [
  null,
  "Создать"
 ],
 "Create new task file with this content.": [
  null,
  "Создайте новый файл задачи с этим содержимым."
 ],
 "Creating this $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Создание этой $0 приведёт к разрыву соединения с сервером и недоступности интерфейса администратора."
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Custom ports": [
  null,
  "Настраиваемые порты"
 ],
 "Custom zones": [
  null,
  "Настраиваемые зоны"
 ],
 "DNS": [
  null,
  "DNS"
 ],
 "DNS $val": [
  null,
  "DNS $val"
 ],
 "DNS search domains": [
  null,
  "Домены поиска DNS"
 ],
 "DNS search domains $val": [
  null,
  "Домены поиска DNS $val"
 ],
 "Deactivating": [
  null,
  "Отключение"
 ],
 "Delay": [
  null,
  "Задержка"
 ],
 "Delete": [
  null,
  "Удалить"
 ],
 "Delete $0": [
  null,
  "Удалить $0"
 ],
 "Deleting $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Удаление $0 приведёт к разрыву соединения с сервером и недоступности интерфейса администратора."
 ],
 "Description": [
  null,
  "Описание"
 ],
 "Desktop": [
  null,
  "Настольный компьютер"
 ],
 "Detachable": [
  null,
  "Съёмный компьютер"
 ],
 "Diagnostic reports": [
  null,
  "Диагностические отчёты"
 ],
 "Disable the firewall": [
  null,
  "Отключить межсетевой экран"
 ],
 "Disabled": [
  null,
  "Отключено"
 ],
 "Docking station": [
  null,
  "Стыковочный узел"
 ],
 "Downloading $0": [
  null,
  "Загрузка $0"
 ],
 "Dual rank": [
  null,
  "Двухранговая"
 ],
 "Edit": [
  null,
  "Изменить"
 ],
 "Edit VLAN settings": [
  null,
  "Изменить параметры VLAN"
 ],
 "Edit WireGuard VPN": [
  null,
  "Изменить WireGuard VPN"
 ],
 "Edit bond settings": [
  null,
  "Изменить параметры привязки"
 ],
 "Edit bridge settings": [
  null,
  "Изменить параметры моста"
 ],
 "Edit custom service in $0 zone": [
  null,
  "Изменение пользовательской службы в зоне $0"
 ],
 "Edit rules and zones": [
  null,
  "Изменить правила и зоны"
 ],
 "Edit service": [
  null,
  "Изменить службу"
 ],
 "Edit service $0": [
  null,
  "Изменить службу $0"
 ],
 "Edit team settings": [
  null,
  "Изменить параметры команды"
 ],
 "Embedded PC": [
  null,
  "Встраиваемый компьютер"
 ],
 "Enable or disable the device": [
  null,
  "Включение или отключение устройства"
 ],
 "Enable service": [
  null,
  "Включить службу"
 ],
 "Enable the firewall": [
  null,
  "Включить межсетевой экран"
 ],
 "Enabled": [
  null,
  "Включено"
 ],
 "Endpoint": [
  null,
  "Конечная точка"
 ],
 "Endpoint acting as a \"server\" need to be specified as host:port, otherwise it can be left empty.": [
  null,
  "Конечная точка, выступающая в роли «сервера», должна быть указана как хост:порт, в противном случае можно оставить пустым"
 ],
 "Enter a valid MAC address": [
  null,
  "Введите допустимый MAC-адрес"
 ],
 "Entire subnet": [
  null,
  "Адрес всей подсети"
 ],
 "Ethernet MAC": [
  null,
  "Ethernet MAC"
 ],
 "Ethernet MTU": [
  null,
  "Ethernet MTU"
 ],
 "Ethtool": [
  null,
  "Ethtool"
 ],
 "Example: 22,ssh,8080,5900-5910": [
  null,
  "Пример: 22, ssh, 8080, 5900-5910"
 ],
 "Example: 88,2019,nfs,rsync": [
  null,
  "Пример: 88, 2019, nfs, rsync"
 ],
 "Excellent password": [
  null,
  "Отличный пароль"
 ],
 "Expansion chassis": [
  null,
  "Корпус расширения"
 ],
 "Failed": [
  null,
  "Сбой"
 ],
 "Failed to add port": [
  null,
  "Не удалось добавить порт"
 ],
 "Failed to add service": [
  null,
  "Не удалось добавить службу"
 ],
 "Failed to add zone": [
  null,
  "Не удалось добавить зону"
 ],
 "Failed to change password": [
  null,
  "Не удалось изменить пароль"
 ],
 "Failed to edit service": [
  null,
  "Не удалось изменить службу"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Не удалось включить $0 в firewalld"
 ],
 "Failed to save settings": [
  null,
  "Не удалось сохранить параметры"
 ],
 "Filter services": [
  null,
  "Фильтровать службы"
 ],
 "Firewall": [
  null,
  "Межсетевой экран"
 ],
 "Firewall is not available": [
  null,
  "Межсетевой экран недоступен"
 ],
 "Forward delay $forward_delay": [
  null,
  "Задержка смены состояний $forward_delay"
 ],
 "Gateway": [
  null,
  "Шлюз"
 ],
 "General": [
  null,
  "Общее"
 ],
 "Generated": [
  null,
  "Сгенерирован"
 ],
 "Go to now": [
  null,
  "Текущий момент"
 ],
 "Group": [
  null,
  "Группа"
 ],
 "Hair pin mode": [
  null,
  "Режим NAT loopback"
 ],
 "Hairpin mode": [
  null,
  "Режим NAT loopback"
 ],
 "Handheld": [
  null,
  "Наладонный компьютер"
 ],
 "Hello time $hello_time": [
  null,
  "Время приветствия $hello_time"
 ],
 "Hide confirmation password": [
  null,
  "Скрыть подтверждение пароля"
 ],
 "Hide password": [
  null,
  "Скрыть пароль"
 ],
 "Host key is incorrect": [
  null,
  "Неверный ключ узла"
 ],
 "ID": [
  null,
  "Идентификатор"
 ],
 "ID $id": [
  null,
  "ИД $id"
 ],
 "IP address": [
  null,
  "IP-адрес"
 ],
 "IP address with routing prefix. Separate multiple values with a comma. Example: 192.0.2.0/24, 2001:db8::/32": [
  null,
  "IP-адрес с префиксом маршрутизации. Несколько значений нужно разделять запятой. Например: 192.0.2.0/24, 2001:db8::/32"
 ],
 "IPv4": [
  null,
  "IPv4"
 ],
 "IPv4 addresses": [
  null,
  "Адреса IPv4"
 ],
 "IPv4 settings": [
  null,
  "Параметры IPv4"
 ],
 "IPv6": [
  null,
  "IPv6"
 ],
 "IPv6 settings": [
  null,
  "Параметры IPv6"
 ],
 "If left empty, ID will be generated based on associated port services and port numbers": [
  null,
  "Если оставить поле пустым, ИД будет сгенерирован на основе связанных служб и номеров порта"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Если отпечаток совпадает, нажмите «Доверять и добавить хост». В противном случае не подключайтесь и свяжитесь с вашим администратором."
 ],
 "Ignore": [
  null,
  "Игнорировать"
 ],
 "Inactive": [
  null,
  "Неактивно"
 ],
 "Included services": [
  null,
  "Включённые службы"
 ],
 "Incoming requests are blocked by default. Outgoing requests are not blocked.": [
  null,
  "Входящие запросы заблокированы по умолчанию. Исходящие запросы не заблокированы."
 ],
 "Install": [
  null,
  "Установить"
 ],
 "Install software": [
  null,
  "Установка программного обеспечения"
 ],
 "Installing $0": [
  null,
  "Установка $0"
 ],
 "Interface": [
  null,
  "Интерфейс",
  "Интерфейсы",
  "Интерфейсы"
 ],
 "Interface members": [
  null,
  "Члены интерфейса"
 ],
 "Interfaces": [
  null,
  "Интерфейсы"
 ],
 "Internal error": [
  null,
  "Внутренняя ошибка"
 ],
 "Invalid address $0": [
  null,
  "Недопустимый адрес $0"
 ],
 "Invalid date format": [
  null,
  "Недопустимый формат даты"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Недопустимый формат даты и недопустимый формат времени"
 ],
 "Invalid file permissions": [
  null,
  "Недопустимые разрешения для файлов"
 ],
 "Invalid metric $0": [
  null,
  "Недопустимая метрика $0"
 ],
 "Invalid port number": [
  null,
  "Недопустимый номер порта"
 ],
 "Invalid prefix $0": [
  null,
  "Недопустимый префикс $0"
 ],
 "Invalid prefix or netmask $0": [
  null,
  "Недопустимый префикс или сетевая маска $0"
 ],
 "Invalid range": [
  null,
  "Недопустимый диапазон"
 ],
 "Invalid time format": [
  null,
  "Недопустимый формат времени"
 ],
 "Invalid timezone": [
  null,
  "Недопустимый часовой пояс"
 ],
 "IoT gateway": [
  null,
  "Шлюз Интернета вещей"
 ],
 "Keep connection": [
  null,
  "Сохранить подключение"
 ],
 "Kernel dump": [
  null,
  "Дамп ядра"
 ],
 "Key password": [
  null,
  "Пароль ключа"
 ],
 "LACP key": [
  null,
  "Ключ LACP"
 ],
 "Laptop": [
  null,
  "Полноразмерный ноутбук"
 ],
 "Learn more": [
  null,
  "Подробнее"
 ],
 "Link down delay": [
  null,
  "Задержка разрыва соединения"
 ],
 "Link local": [
  null,
  "Локальный адрес канала"
 ],
 "Link monitoring": [
  null,
  "Мониторинг ссылок"
 ],
 "Link up delay": [
  null,
  "Задержка установки соединения"
 ],
 "Link watch": [
  null,
  "Просмотр ссылок"
 ],
 "Listen port": [
  null,
  "Порт прослушивания"
 ],
 "Listen port must be a number": [
  null,
  "Порт прослушивания должен быть числом"
 ],
 "Load balancing": [
  null,
  "Балансировка нагрузки"
 ],
 "Loading system modifications...": [
  null,
  "Загрузка изменений системы…"
 ],
 "Log in": [
  null,
  "Войти"
 ],
 "Log in to $0": [
  null,
  "Вход на $0"
 ],
 "Log messages": [
  null,
  "Сообщения журнала"
 ],
 "Login failed": [
  null,
  "Ошибка входа"
 ],
 "Low profile desktop": [
  null,
  "Низкопрофильный настольный компьютер"
 ],
 "Lunch box": [
  null,
  "Портативный компьютер в ударопрочном корпусе"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "MII (recommended)": [
  null,
  "MII (рекомендуется)"
 ],
 "MTU": [
  null,
  "MTU"
 ],
 "MTU must be a positive number": [
  null,
  "Значение MTU должно быть положительным числом"
 ],
 "Main server chassis": [
  null,
  "Главный серверный корпус"
 ],
 "Manage storage": [
  null,
  "Управление хранилищем"
 ],
 "Managed interfaces": [
  null,
  "Управляемые интерфейсы"
 ],
 "Manual": [
  null,
  "Вручную"
 ],
 "Manually": [
  null,
  "Вручную"
 ],
 "Maximum message age $max_age": [
  null,
  "Максимальное время жизни сообщения $max_age"
 ],
 "Message to logged in users": [
  null,
  "Сообщение для вошедших пользователей"
 ],
 "Metric": [
  null,
  "Метрика"
 ],
 "Mini PC": [
  null,
  "Мини-ПК"
 ],
 "Mini tower": [
  null,
  "Компьютер в корпусе «мини-башня»"
 ],
 "Mode": [
  null,
  "Режим"
 ],
 "Monitoring interval": [
  null,
  "Интервал мониторинга"
 ],
 "Monitoring targets": [
  null,
  "Цели мониторинга"
 ],
 "Multi-system chassis": [
  null,
  "Корпус для нескольких систем"
 ],
 "Multiple addresses can be specified using commas or spaces as delimiters.": [
  null,
  "Можно указать несколько адресов, используя запятые или пробелы в качестве разделителей."
 ],
 "NSNA ping": [
  null,
  "NSNA ping"
 ],
 "NTP server": [
  null,
  "Сервер NTP"
 ],
 "Name": [
  null,
  "Имя"
 ],
 "Need at least one NTP server": [
  null,
  "Требуется по крайней мере один сервер NTP"
 ],
 "Network bond": [
  null,
  "Сетевое объединение"
 ],
 "Network devices and graphs require NetworkManager": [
  null,
  "Для сетевых устройств и графиков необходим NetworkManager"
 ],
 "Network logs": [
  null,
  "Сетевые журналы"
 ],
 "NetworkManager is not installed": [
  null,
  "NetworkManager не установлен"
 ],
 "NetworkManager is not running": [
  null,
  "NetworkManager не работает"
 ],
 "Networking": [
  null,
  "Сеть"
 ],
 "New password was not accepted": [
  null,
  "Новый пароль не был принят"
 ],
 "No": [
  null,
  "Нет"
 ],
 "No carrier": [
  null,
  "Нет несущей частоты"
 ],
 "No delay": [
  null,
  "Без задержки"
 ],
 "No description available": [
  null,
  "Описание отсутствует"
 ],
 "No peers added.": [
  null,
  "Нет добавленных узлов"
 ],
 "No results found": [
  null,
  "Нет результатов"
 ],
 "No such file or directory": [
  null,
  "Нет такого файла или каталога"
 ],
 "No system modifications": [
  null,
  "Изменения системы отсутствуют"
 ],
 "None": [
  null,
  "Нет"
 ],
 "Not a valid private key": [
  null,
  "Недопустимый закрытый ключ"
 ],
 "Not authorized to disable the firewall": [
  null,
  "Нет прав для отключения межсетевого экрана"
 ],
 "Not authorized to enable the firewall": [
  null,
  "Нет прав для включения межсетевого экрана"
 ],
 "Not available": [
  null,
  "Недоступно"
 ],
 "Not permitted to configure network devices": [
  null,
  "Не допускается настройка сетевых устройств"
 ],
 "Not permitted to perform this action.": [
  null,
  "Нет прав на выполнение этого действия."
 ],
 "Not synchronized": [
  null,
  "Не синхронизировано"
 ],
 "Notebook": [
  null,
  "Ноутбук"
 ],
 "Occurrences": [
  null,
  "События"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Old password not accepted": [
  null,
  "Старый пароль не был принят"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "После установки Cockpit включите его при помощи команды «systemctl enable --now cockpit.socket»."
 ],
 "Options": [
  null,
  "Параметры"
 ],
 "Other": [
  null,
  "Прочее"
 ],
 "PackageKit crashed": [
  null,
  "Сбой PackageKit"
 ],
 "Parent": [
  null,
  "Родительский элемент"
 ],
 "Parent $parent": [
  null,
  "Родительский элемент $parent"
 ],
 "Part of $0": [
  null,
  "Часть $0"
 ],
 "Passive": [
  null,
  "Пассивно"
 ],
 "Password": [
  null,
  "Пароль"
 ],
 "Password is not acceptable": [
  null,
  "Недопустимый пароль"
 ],
 "Password is too weak": [
  null,
  "Пароль недостаточно надёжен"
 ],
 "Password not accepted": [
  null,
  "Пароль не принят"
 ],
 "Paste": [
  null,
  "Вставить"
 ],
 "Paste error": [
  null,
  "Ошибка вставки"
 ],
 "Paste existing key": [
  null,
  "Вставить существующий ключ"
 ],
 "Path cost": [
  null,
  "Стоимость пути"
 ],
 "Path cost $path_cost": [
  null,
  "Стоимость пути $path_cost"
 ],
 "Path to file": [
  null,
  "Путь к файлу"
 ],
 "Peer #$0 has invalid endpoint port. Port must be a number.": [
  null,
  "У узла #$0 некорректный порт конечной точки. Порт должен быть числом."
 ],
 "Peer #$0 has invalid endpoint. It must be specified as host:port, e.g. 1.2.3.4:51820 or example.com:51820": [
  null,
  "У узла #$0 некорректная конечная точка. Он должен быть указан как хост:порт, например 1.2.3.4:51820 или example.com:51820"
 ],
 "Peers": [
  null,
  "Узлы"
 ],
 "Peers are other machines that connect with this one. Public keys from other machines will be shared with each other.": [
  null,
  "Узлы — это другие компьютеры, которые подключаются к этому. Открытые ключи от других компьютеров будут передаваться друг другу"
 ],
 "Peripheral chassis": [
  null,
  "Корпус для периферийных устройств"
 ],
 "Permanent": [
  null,
  "Постоянный"
 ],
 "Pick date": [
  null,
  "Выбор даты"
 ],
 "Ping interval": [
  null,
  "Интервал команды ping"
 ],
 "Ping target": [
  null,
  "Цель команды ping"
 ],
 "Pizza box": [
  null,
  "Ультратонкий корпус"
 ],
 "Please install the $0 package": [
  null,
  "Установите пакет $0"
 ],
 "Portable": [
  null,
  "Портативный компьютер"
 ],
 "Ports": [
  null,
  "Порты"
 ],
 "Prefix length": [
  null,
  "Длина префикса"
 ],
 "Prefix length or netmask": [
  null,
  "Длина префикса или маска сети"
 ],
 "Preparing": [
  null,
  "Подготовка"
 ],
 "Present": [
  null,
  "Присутствует"
 ],
 "Preserve": [
  null,
  "Сохранять"
 ],
 "Primary": [
  null,
  "Первичный интерфейс"
 ],
 "Priority": [
  null,
  "Приоритет"
 ],
 "Priority $priority": [
  null,
  "Приоритет $priority"
 ],
 "Private key": [
  null,
  "Закрытый ключ"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Превышено время ожидания запроса по ssh-add"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Превышено время ожидания запроса по ssh-keygen"
 ],
 "Public key": [
  null,
  "Открытый ключ"
 ],
 "Public key will be generated when a valid private key is entered": [
  null,
  "Открытый ключ будет сгенерирован после ввода действительного закрытого ключа"
 ],
 "RAID chassis": [
  null,
  "Корпус для RAID-массива"
 ],
 "Rack mount chassis": [
  null,
  "Монтируемый в стойку корпус"
 ],
 "Random": [
  null,
  "Случайный"
 ],
 "Range": [
  null,
  "Диапазон"
 ],
 "Range must be strictly ordered": [
  null,
  "Диапазон должен быть строго упорядочен"
 ],
 "Reboot": [
  null,
  "Перезагрузка"
 ],
 "Receiving": [
  null,
  "Приём"
 ],
 "Regenerate": [
  null,
  "Создать повторно"
 ],
 "Removals:": [
  null,
  "Для удаления:"
 ],
 "Remove $0": [
  null,
  "Удалить $0"
 ],
 "Remove $0 service from $1 zone": [
  null,
  "Удалить службу $0 из зоны $1"
 ],
 "Remove item": [
  null,
  "Удалить элемент"
 ],
 "Remove service $0": [
  null,
  "Удалить службу $0"
 ],
 "Remove zone $0": [
  null,
  "Удалить зону $0"
 ],
 "Removing $0": [
  null,
  "Удаление $0"
 ],
 "Removing $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Удаление $0 приведёт к разрыву соединения с сервером и недоступности интерфейса администратора."
 ],
 "Removing the cockpit service might result in the web console becoming unreachable. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Удаление службы cockpit может привести к недоступности веб-консоли. Убедитесь, что эта зона не относится к вашему текущему подключению к веб-консоли."
 ],
 "Removing the zone will remove all services within it.": [
  null,
  "Удаление зоны приведет к удалению всех служб в ней."
 ],
 "Restoring connection": [
  null,
  "Восстановление подключения"
 ],
 "Round robin": [
  null,
  "Циклический перебор"
 ],
 "Routes": [
  null,
  "Маршруты"
 ],
 "Row expansion": [
  null,
  "Расширение строки"
 ],
 "Row select": [
  null,
  "Выбор строки"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Запустите эту команду через доверенную сеть или физически на удалённом компьютере:"
 ],
 "Runner": [
  null,
  "Средство запуска"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "SSH-ключ"
 ],
 "STP forward delay": [
  null,
  "Задержка смены состояний"
 ],
 "STP hello time": [
  null,
  "Время приветствия"
 ],
 "STP maximum message age": [
  null,
  "Максимальное время жизни сообщения"
 ],
 "STP priority": [
  null,
  "Приоритет"
 ],
 "Save": [
  null,
  "Сохранить"
 ],
 "Sealed-case PC": [
  null,
  "Компьютер с невскрываемым корпусом"
 ],
 "Search domain": [
  null,
  "Домен поиска"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Настройка и устранение неисправностей в Linux с улучшенной системой безопасности"
 ],
 "Select method": [
  null,
  "Выбор метода"
 ],
 "Sending": [
  null,
  "Передача"
 ],
 "Server": [
  null,
  "Сервер"
 ],
 "Server has closed the connection.": [
  null,
  "Сервер закрыл соединение."
 ],
 "Service": [
  null,
  "Служба"
 ],
 "Services": [
  null,
  "Службы"
 ],
 "Set time": [
  null,
  "Настроить время"
 ],
 "Set to": [
  null,
  "Установлено на"
 ],
 "Shared": [
  null,
  "С общим доступом"
 ],
 "Shell script": [
  null,
  "Сценарий оболочки"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show confirmation password": [
  null,
  "Показать подтверждение пароля"
 ],
 "Show password": [
  null,
  "Показать пароль"
 ],
 "Shut down": [
  null,
  "Завершение работы"
 ],
 "Single rank": [
  null,
  "Одноранговая"
 ],
 "Sorted from least to most trusted": [
  null,
  "Отсортировано от наименее доверенных к наиболее доверенным"
 ],
 "Space-saving computer": [
  null,
  "Компактный компьютер"
 ],
 "Spanning tree protocol": [
  null,
  "Протокол связующего дерева"
 ],
 "Spanning tree protocol (STP)": [
  null,
  "Протокол связующего дерева (STP)"
 ],
 "Specific time": [
  null,
  "Определённое время"
 ],
 "Stable": [
  null,
  "Стабильный"
 ],
 "Start service": [
  null,
  "Запустить службу"
 ],
 "Status": [
  null,
  "Состояние"
 ],
 "Stick PC": [
  null,
  "ПК-брелок"
 ],
 "Sticky": [
  null,
  "Закреплено"
 ],
 "Storage": [
  null,
  "Хранилище"
 ],
 "Strong password": [
  null,
  "Надёжный пароль"
 ],
 "Sub-Chassis": [
  null,
  "Дополнительный корпус"
 ],
 "Sub-Notebook": [
  null,
  "Субноутбук"
 ],
 "Switch off $0": [
  null,
  "Отключить $0"
 ],
 "Switch on $0": [
  null,
  "Включить $0"
 ],
 "Switching off $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Отключение $0 приведёт к разрыву соединения с сервером и недоступности интерфейса администратора."
 ],
 "Switching on $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Включение $0 приведёт к разрыву соединения с сервером и недоступности интерфейса администратора."
 ],
 "Synchronized": [
  null,
  "Синхронизировано"
 ],
 "Synchronized with $0": [
  null,
  "Синхронизировано с $0"
 ],
 "Synchronizing": [
  null,
  "Синхронизация"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "Tablet": [
  null,
  "Планшетный ПК"
 ],
 "Team": [
  null,
  "Сопряжение"
 ],
 "Team port": [
  null,
  "Порт сопряжения"
 ],
 "Team port settings": [
  null,
  "Параметры порта сопряжения"
 ],
 "Testing connection": [
  null,
  "Проверка подключения"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "SSH-ключ $0 для $1 на $2 будет добавлен к файлу $3 для $4 на $5."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH-ключ $0 будет предоставлен на оставшееся время сеанса, а также будет доступен для входа на другие узлы."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "SSH-ключ для входа на $0 защищён паролем, а вход с паролем на узле запрещён. Введите пароль для ключа на $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "SSH-ключ для входа на $0 защищён. Вход возможен либо при указании пароля для входа, либо пароля ключа на $1."
 ],
 "The cockpit service is automatically included": [
  null,
  "Служба cockpit автоматически входит в состав"
 ],
 "The fingerprint should match:": [
  null,
  "Отпечаток должен соответствовать:"
 ],
 "The key password can not be empty": [
  null,
  "Пароль ключа не может быть пустым"
 ],
 "The key passwords do not match": [
  null,
  "Пароли ключа не совпадают"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Текущему пользователю запрещено просматривать изменения системы"
 ],
 "The password can not be empty": [
  null,
  "Пароль не может быть пустым"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Полученный отпечаток можно распространять по общедоступным каналам связи, включая электронную почту."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Полученный отпечаток пальца можно передавать общедоступными способами, включая электронную почту. Если вы просите кого-то другого выполнить проверку за вас, они могут отправить результаты любым способом."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Сервер отклонил проверку подлинности с использованием любых поддерживаемых методов."
 ],
 "There are no active services in this zone": [
  null,
  "В этой зоне нет активных служб"
 ],
 "This device cannot be managed here.": [
  null,
  "Этим устройством невозможно управлять здесь."
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Этот инструмент настраивает правила SELinux и может помочь в понимании и устранении нарушений правил."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Этот инструмент создаёт архив данных по настройкам и диагностике для запущенной системы. Архив может быть сохранён локально или централизованно с целью журналирования или слежения или отправлен представителям технической поддержки, разработчикам или администраторам системы, чтобы помочь с поиском технических проблем и диагностикой."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Этот инструмент управляет локальными хранилищами, такими как файловые системы, группы томов LVM2, и монтированиями NFS."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Этот инструмент управляет возможностями работы в сети, в частности связями, мостами, командами, виртуальными LAN и брандмауэрами, с помощью NetworkManager и Firewalld. NetworkManager несовместим с типичным для Ubuntu systemd-networkd и скриптами ifupdown Debian."
 ],
 "This zone contains the cockpit service. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Эта зона содержит службу cockpit. Убедитесь, что эта зона не относится к текущему соединению веб-консоли."
 ],
 "Time zone": [
  null,
  "Часовой пояс"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Чтобы убедиться в том, что данные вашего соединения не были перехвачены злоумышленниками, проверьте отпечаток ключа данного узла:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Для проверки отпечатка запустите следующую команду на $0, физически работая на этом компьютере или по доверенной сети:"
 ],
 "Toggle date picker": [
  null,
  "Переключить средство выбора даты"
 ],
 "Too much data": [
  null,
  "Слишком много данных"
 ],
 "Total size: $0": [
  null,
  "Общий размер: $0"
 ],
 "Tower": [
  null,
  "Компьютер в корпусе «башня»"
 ],
 "Transmitting": [
  null,
  "Передача"
 ],
 "Troubleshoot…": [
  null,
  "Устранить неполадки…"
 ],
 "Trust and add host": [
  null,
  "Доверять и добавить хост"
 ],
 "Trust level": [
  null,
  "Уровень доверия"
 ],
 "Trying to synchronize with $0": [
  null,
  "Попытка синхронизации с $0"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Не удалось войти на $0. Узел не принимает вход ни по паролю, ни по одному из имеющихся SSH-ключей."
 ],
 "Unexpected error": [
  null,
  "Непредвиденная ошибка"
 ],
 "Unknown": [
  null,
  "Неизвестно"
 ],
 "Unknown \"$0\"": [
  null,
  "Неизвестно «$0»"
 ],
 "Unknown configuration": [
  null,
  "Неизвестная конфигурация"
 ],
 "Unknown service name": [
  null,
  "Неизвестное название службы"
 ],
 "Unmanaged interfaces": [
  null,
  "Неуправляемые интерфейсы"
 ],
 "Untrusted host": [
  null,
  "Недоверенный узел"
 ],
 "VLAN": [
  null,
  "VLAN"
 ],
 "VLAN ID": [
  null,
  "Идентификатор VLAN"
 ],
 "Verify fingerprint": [
  null,
  "Проверить отпечаток"
 ],
 "View all logs": [
  null,
  "Смотреть все журналы"
 ],
 "View automation script": [
  null,
  "Просмотреть сценарий автоматизации"
 ],
 "Visit firewall": [
  null,
  "Перейти к межсетевому экрану"
 ],
 "Waiting": [
  null,
  "Ожидание"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Ожидание завершения других операций управления программным обеспечением"
 ],
 "Weak password": [
  null,
  "Ненадёжный пароль"
 ],
 "Web Console for Linux servers": [
  null,
  "Веб-консоль для серверов Linux"
 ],
 "Will be set to \"Automatic\"": [
  null,
  "Будет установлено значение «Автоматически»"
 ],
 "WireGuard": [
  null,
  "WireGuard"
 ],
 "XOR": [
  null,
  "XOR"
 ],
 "Yes": [
  null,
  "Да"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Подключение к $0 выполняется в первый раз."
 ],
 "You are not authorized to modify the firewall.": [
  null,
  "У вас нет прав на изменение брандмауэра."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "В данном браузере отсутствует возможность вставки с помощью контекстного меню. Можно использовать комбинацию Shift+Insert."
 ],
 "Your session has been terminated.": [
  null,
  "Сеанс завершён."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Срок действия сеанса истёк. Войдите в систему снова."
 ],
 "Zone": [
  null,
  "Зона"
 ],
 "[binary data]": [
  null,
  "[двоичные данные]"
 ],
 "[no data]": [
  null,
  "[нет данных]"
 ],
 "edit": [
  null,
  "редактировать"
 ],
 "in less than a minute": [
  null,
  ""
 ],
 "less than a minute ago": [
  null,
  ""
 ],
 "password quality": [
  null,
  "качество пароля"
 ],
 "show less": [
  null,
  "показать меньше"
 ],
 "show more": [
  null,
  "показать больше"
 ],
 "wireguard-tools package is not installed": [
  null,
  "Пакет wireguard-tools не установлен"
 ]
});
