cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "de",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 active zone": [
  null,
  "$0 aktive Zone",
  "$0 aktive Zonen"
 ],
 "$0 day": [
  null,
  "$0 Tag",
  "$0 Tage"
 ],
 "$0 exited with code $1": [
  null,
  "$0 mit Code $1 beendet"
 ],
 "$0 failed": [
  null,
  "$0 fehlgeschlagen"
 ],
 "$0 hour": [
  null,
  "$0 Stunde",
  "$0 Stunden"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 ist in keinem Repository verfügbar."
 ],
 "$0 key changed": [
  null,
  "$0 Schlüssel geändert"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 mit Signal $1 beendet"
 ],
 "$0 minute": [
  null,
  "$0 Minute",
  "$0 Minuten"
 ],
 "$0 month": [
  null,
  "$0 Monat",
  "$0 Monate"
 ],
 "$0 week": [
  null,
  "$0 Woche",
  "$0 Wochen"
 ],
 "$0 will be installed.": [
  null,
  "$0 wird installiert."
 ],
 "$0 year": [
  null,
  "$0 Jahr",
  "$0 Jahre"
 ],
 "$0 zone": [
  null,
  "$0 Zone"
 ],
 "1 day": [
  null,
  "1 Tag"
 ],
 "1 hour": [
  null,
  "1 Stunde"
 ],
 "1 minute": [
  null,
  "1 Minute"
 ],
 "1 week": [
  null,
  "1 Woche"
 ],
 "20 minutes": [
  null,
  "20 Minuten"
 ],
 "40 minutes": [
  null,
  "40 Minuten"
 ],
 "5 minutes": [
  null,
  "5 Minuten"
 ],
 "6 hours": [
  null,
  "6 Stunden"
 ],
 "60 minutes": [
  null,
  "60 Minuten"
 ],
 "802.3ad": [
  null,
  "802.3ad"
 ],
 "802.3ad LACP": [
  null,
  "802.3ad LACP"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Eine kompatible Version von Cockpit ist auf $0 nicht installiert."
 ],
 "A network bond combines multiple network interfaces into one logical interface with higher throughput or redundancy.": [
  null,
  "Ein gebündelter Netzwerkadapter kombiniert mehrere Netzweradapter zu einem logischen Netzwerkadapter mit mehr Durchsatz und Redundanz."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Ein neuer SSH-Schlüssel unter $0 wird für $1 auf $2 erstellt und zur Datei $3 von $4 auf $5 hinzugefügt."
 ],
 "ARP": [
  null,
  "ARP"
 ],
 "ARP monitoring": [
  null,
  "ARP-Überwachung"
 ],
 "ARP ping": [
  null,
  "ARP-Ping"
 ],
 "Absent": [
  null,
  "Abwesend"
 ],
 "Acceptable password": [
  null,
  "Akzeptables Passwort"
 ],
 "Active": [
  null,
  "Aktiv"
 ],
 "Active backup": [
  null,
  "Aktive Sicherung"
 ],
 "Adaptive load balancing": [
  null,
  "Adaptiver Lastausgleich (alb)"
 ],
 "Adaptive transmit load balancing": [
  null,
  "Adaptiver Sendeausgleich (tlb)"
 ],
 "Add": [
  null,
  "Hinzufügen"
 ],
 "Add $0": [
  null,
  "$0 hinzufügen"
 ],
 "Add DNS server": [
  null,
  "DNS Server hinzufügen"
 ],
 "Add VLAN": [
  null,
  "VLAN hinzufügen"
 ],
 "Add VPN": [
  null,
  "VPN hinzufügen"
 ],
 "Add WireGuard VPN": [
  null,
  "WireGuard VPN hinzufügen"
 ],
 "Add a new zone": [
  null,
  "Neue Zone hinzufügen"
 ],
 "Add address": [
  null,
  "Adresse hinzufügen"
 ],
 "Add bond": [
  null,
  "Bündelung hinzufügen"
 ],
 "Add bridge": [
  null,
  "Bridge hinzufügen"
 ],
 "Add member": [
  null,
  "Mitglied hinzufügen"
 ],
 "Add new zone": [
  null,
  "Neue Zone hinzufügen"
 ],
 "Add peer": [
  null,
  "Peer hinzufügen"
 ],
 "Add ports": [
  null,
  "Ports hinzufügen"
 ],
 "Add ports to $0 zone": [
  null,
  "Ports zu Zone $0 hinzufügen"
 ],
 "Add route": [
  null,
  "Route hinzufügen"
 ],
 "Add search domain": [
  null,
  "Suchdomäne hinzufügen"
 ],
 "Add services": [
  null,
  "Dienste hinzufügen"
 ],
 "Add services to $0 zone": [
  null,
  "Services zu Zone $0 hinzufügen"
 ],
 "Add services to zone $0": [
  null,
  "Services zu Zone $0 hinzufügen"
 ],
 "Add team": [
  null,
  "Team hinzufügen"
 ],
 "Add zone": [
  null,
  "Zone hinzufügen"
 ],
 "Adding $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Das Hinzufügen von $0 unterbricht die Verbindung zum Server und macht die Administrationsoberfläche nicht mehr verfügbar."
 ],
 "Adding custom ports will reload firewalld. A reload will result in the loss of any runtime-only configuration!": [
  null,
  "Das Hinzufügen von eigenen Ports wird firewalld neu starten. Ein Neustart setzt alle Freischaltungen auf Laufzeitebene zurück!"
 ],
 "Additional DNS $val": [
  null,
  "Zusätzliches DNS $val"
 ],
 "Additional DNS search domains $val": [
  null,
  "Zusätzliche DNS-Suchdomänen $val"
 ],
 "Additional address $val": [
  null,
  "Zusätzliche Adresse $val"
 ],
 "Additional packages:": [
  null,
  "Zusatzpakete:"
 ],
 "Additional ports": [
  null,
  "Mehr Ports"
 ],
 "Address": [
  null,
  "Adresse"
 ],
 "Address $val": [
  null,
  "Adresse $val"
 ],
 "Addresses": [
  null,
  "Adressen"
 ],
 "Addresses are not formatted correctly": [
  null,
  "Adresse darf nicht leer sein oder ist nicht korrekt formatiert"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Mit der Cockpit Web Konsole administrieren"
 ],
 "Advanced TCA": [
  null,
  "Fortgeschrittenes TCA"
 ],
 "All-in-one": [
  null,
  "Alles-in-einem"
 ],
 "Allowed IPs": [
  null,
  "Erlaubte IP-Adressen"
 ],
 "Allowed addresses": [
  null,
  "Erlaubte Adressen"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Ansible Rollendokumentation"
 ],
 "Authenticating": [
  null,
  "Authentifiziere"
 ],
 "Authentication": [
  null,
  "Authentifizierung"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Privilegierte Aktionen der Cockpit Web-Konsole benötigen Berechtigung"
 ],
 "Authorize SSH key": [
  null,
  "SSH-Schlüssel autorisieren"
 ],
 "Automatic": [
  null,
  "Automatisch"
 ],
 "Automatic (DHCP only)": [
  null,
  "Automatisch (nur DHCP)"
 ],
 "Automatically using NTP": [
  null,
  "Automatisch (NTP)"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Automatische Benutzung zusätzlicher NTP-Server"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automatisch (spezifische NTP-Server)"
 ],
 "Automation script": [
  null,
  "Automatisierungs-Skript"
 ],
 "Balancer": [
  null,
  "Balancer"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Bladegehäuse"
 ],
 "Bond": [
  null,
  "Bond"
 ],
 "Bridge": [
  null,
  "Brücke"
 ],
 "Bridge port": [
  null,
  "Netzwerkbrücken-Port"
 ],
 "Bridge port settings": [
  null,
  "Netzwerkbrücke-Port-Einstellungen"
 ],
 "Broadcast": [
  null,
  "Broadcast"
 ],
 "Broken configuration": [
  null,
  "Fehlerhafte Konfiguration"
 ],
 "Bus expansion chassis": [
  null,
  "Bus-Erweiterungsgehäuse"
 ],
 "Cancel": [
  null,
  "Abbrechen"
 ],
 "Cannot forward login credentials": [
  null,
  "Anmeldeinformationen können nicht weitergeleitet werden"
 ],
 "Cannot schedule event in the past": [
  null,
  "Vorgang kann nicht für die Vergangenheit geplant werden"
 ],
 "Carrier": [
  null,
  "Träger"
 ],
 "Change": [
  null,
  "Ändern"
 ],
 "Change system time": [
  null,
  "Systemzeit ändern"
 ],
 "Change the settings": [
  null,
  "Bridge Port-Einstellungen"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Geänderte Schlüssel sind oft das Ergebnis einer Neuinstallation des Betriebssystems. Allerdings kann eine unerwartete Änderung auf einen Versuch eines Dritten hinweisen, Ihre Verbindung auszuspähen."
 ],
 "Changing the settings will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Das Ändern der Einstellungen wird die Verbindung zum Server unterbrechen und damit den Zugriff auf die Benutzeroberfläche unmöglich machen."
 ],
 "Checking IP": [
  null,
  "IP wird überprüft"
 ],
 "Checking installed software": [
  null,
  "Installierte Software wird überprüft"
 ],
 "Clear input value": [
  null,
  "Eingabewert löschen"
 ],
 "Close": [
  null,
  "Schließen"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Cockpit Konfiguration von NetworkManager und Firewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit konnte den angegebenen Host nicht erreichen."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit ist ein Server Manager zur einfachen Verwaltung Ihrer Linux Server via Web Browser. Ein Wechsel zwischen dem Terminal und der Weboberfläche ist kein Problem. Ein Service, der via Cockpit gestartet wurde, kann im Terminal beendet werden. Genauso können Fehler, welche im Terminal vorkommen, im Cockpit Journal angezeigt werden."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit ist mit der Software auf dem System nicht kompatibel."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit ist nicht installiert"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit ist auf dem System nicht installiert."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit ist perfekt für neue Systemadministratoren, da es ihnen auf einfache Weise ermöglicht, simple Aufgaben wie Speicherverwaltung, Journal / Logfile Analyse oder das Starten und Stoppen von Diensten durchzuführen. Sie können gleichzeitig mehrere Server überwachen und verwalten. Fügen Sie weitere Maschinen mit einem Klick hinzu und Ihre Maschinen schauen zu ihren Kumpels."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Sammeln und Packen von Diagnose und Support Daten"
 ],
 "Collect kernel crash dumps": [
  null,
  "Sammeln von Kernel-Absturz-Auszügen"
 ],
 "Comma-separated ports, ranges, and services are accepted": [
  null,
  "Komma-separierte Ports, Bereiche und Dienste sind erlaubt"
 ],
 "Compact PCI": [
  null,
  "Kompakte PCI"
 ],
 "Configuring": [
  null,
  "Konfiguriere"
 ],
 "Configuring IP": [
  null,
  "Konfiguriere IP"
 ],
 "Confirm key password": [
  null,
  "Neues Passwort wiederholen"
 ],
 "Confirm removal of $0": [
  null,
  "Betätigen sie das entfernen von $0"
 ],
 "Connect automatically": [
  null,
  "Verbindung automatisch herstellen"
 ],
 "Connection has timed out.": [
  null,
  "Zeitüberschreitung bei der Verbindung."
 ],
 "Connection will be lost": [
  null,
  "Verbindung geht verloren"
 ],
 "Convertible": [
  null,
  "Convertible"
 ],
 "Copied": [
  null,
  "Kopiert"
 ],
 "Copy": [
  null,
  "Kopieren"
 ],
 "Copy to clipboard": [
  null,
  "In Zwischenablage kopieren"
 ],
 "Create $0": [
  null,
  "$0 erstellen"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Einen neuen SSH-Schlüssel erstellen und ihn autorisieren"
 ],
 "Create it": [
  null,
  "Anlegen"
 ],
 "Create new task file with this content.": [
  null,
  "Neue Task-Datei mit diesem Inhalt erstellen."
 ],
 "Creating this $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Die Erstellung dieser $0 unterbricht die Verbindung zum Server und macht die Administrationsoberfläche nicht mehr erreichbar."
 ],
 "Ctrl+Insert": [
  null,
  "Strg+Einfügen"
 ],
 "Custom ports": [
  null,
  "Eigene Ports"
 ],
 "Custom zones": [
  null,
  "Eigene Zonen"
 ],
 "DNS": [
  null,
  "DNS"
 ],
 "DNS $val": [
  null,
  "DNS $val"
 ],
 "DNS search domains": [
  null,
  "DNS Suchdomänen"
 ],
 "DNS search domains $val": [
  null,
  "DNS-Suchdomänen $val"
 ],
 "Deactivating": [
  null,
  "Wird deaktiviert"
 ],
 "Delay": [
  null,
  "Verzögerung"
 ],
 "Delete": [
  null,
  "Löschen"
 ],
 "Delete $0": [
  null,
  "$0 löschen"
 ],
 "Deleting $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Das Löschen von $0 unterbricht die Verbindung zum Server und macht die Administrationsoberfläche nicht mehr erreichbar."
 ],
 "Description": [
  null,
  "Beschreibung"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Detachable": [
  null,
  "Abnehmbar"
 ],
 "Diagnostic reports": [
  null,
  "Diagnoseberichte"
 ],
 "Disable the firewall": [
  null,
  "Firewall deaktivieren"
 ],
 "Disabled": [
  null,
  "Deaktiviert"
 ],
 "Docking station": [
  null,
  "Dockingstation"
 ],
 "Downloading $0": [
  null,
  "wird heruntergeladen $0"
 ],
 "Dual rank": [
  null,
  "Doppelter Rang"
 ],
 "Edit": [
  null,
  "Bearbeiten"
 ],
 "Edit VLAN settings": [
  null,
  "Editieren der VLAN Einstellungen"
 ],
 "Edit WireGuard VPN": [
  null,
  "WireGuard VPN bearbeiten"
 ],
 "Edit bond settings": [
  null,
  "Bond-Einstellungen bearbeiten"
 ],
 "Edit bridge settings": [
  null,
  "Netzwerkbrücke-Einstellungen bearbeiten"
 ],
 "Edit custom service in $0 zone": [
  null,
  "Benutzerdefinierten Dienst in Zone $0 bearbeiten"
 ],
 "Edit rules and zones": [
  null,
  "Regeln und Zonen bearbeiten"
 ],
 "Edit service": [
  null,
  "Dienst bearbeiten"
 ],
 "Edit service $0": [
  null,
  "Dienst $0 bearbeiten"
 ],
 "Edit team settings": [
  null,
  "Team Einstellungen bearbeiten"
 ],
 "Embedded PC": [
  null,
  "Eingebetteter PC"
 ],
 "Enable or disable the device": [
  null,
  "Gerät aktivieren oder deaktivieren"
 ],
 "Enable service": [
  null,
  "Service aktivieren"
 ],
 "Enable the firewall": [
  null,
  "Firewall aktivieren"
 ],
 "Enabled": [
  null,
  "Aktiviert"
 ],
 "Endpoint": [
  null,
  "Endpunkt"
 ],
 "Endpoint acting as a \"server\" need to be specified as host:port, otherwise it can be left empty.": [
  null,
  "Der Endpunkt, der als \"Server\" fungiert, muss als host:port angegeben werden, andernfalls kann er leer gelassen werden."
 ],
 "Enter a valid MAC address": [
  null,
  "Geben Sie eine gültige MAC-Adresse ein"
 ],
 "Entire subnet": [
  null,
  "Gesamtes Subnetzwerk"
 ],
 "Ethernet MAC": [
  null,
  "Ethernet-MAC"
 ],
 "Ethernet MTU": [
  null,
  "Ethernet-MTU"
 ],
 "Ethtool": [
  null,
  "Ethtool"
 ],
 "Example: 22,ssh,8080,5900-5910": [
  null,
  "Beispiel: 22,ssh,8080,5900-5910"
 ],
 "Example: 88,2019,nfs,rsync": [
  null,
  "Beispiel: 88,2019,nfs,rsync"
 ],
 "Excellent password": [
  null,
  "Perfektes Passwort"
 ],
 "Expansion chassis": [
  null,
  "Erweiterungsgehäuse"
 ],
 "Failed": [
  null,
  "Fehlgeschlagen"
 ],
 "Failed to add port": [
  null,
  "Hinzufügen des Portes fehlgeschlagen"
 ],
 "Failed to add service": [
  null,
  "Hinzufügen des Services fehlgeschlagen"
 ],
 "Failed to add zone": [
  null,
  "Hinzufügen der Zone fehlgeschlagen"
 ],
 "Failed to change password": [
  null,
  "Passwort konnte nicht geändert werden"
 ],
 "Failed to edit service": [
  null,
  "Fehler bei der Bearbeitung des Dienstes"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "$0 konnte nicht in firewalld aktiviert werden"
 ],
 "Failed to save settings": [
  null,
  "Fehler beim Speichern der Einstellungen"
 ],
 "Filter services": [
  null,
  "Filterdienste"
 ],
 "Firewall": [
  null,
  "Firewall"
 ],
 "Firewall is not available": [
  null,
  "Firewall ist nicht verfügbar"
 ],
 "Forward delay $forward_delay": [
  null,
  "Weiterleitungsverzögerung $forward_delay"
 ],
 "Gateway": [
  null,
  "Gateway"
 ],
 "General": [
  null,
  "Allgemein"
 ],
 "Generated": [
  null,
  "Generiert"
 ],
 "Go to now": [
  null,
  "Zu 'Jetzt' gehen"
 ],
 "Group": [
  null,
  "Gruppe"
 ],
 "Hair pin mode": [
  null,
  "Hairpin Modus"
 ],
 "Hairpin mode": [
  null,
  "Hairpin-Modus"
 ],
 "Handheld": [
  null,
  "Handheld"
 ],
 "Hello time $hello_time": [
  null,
  "Hello-Zeit $hello_time"
 ],
 "Hide confirmation password": [
  null,
  "Bestätigungspasswort ausblenden"
 ],
 "Hide password": [
  null,
  "Passwort ausblenden"
 ],
 "Host key is incorrect": [
  null,
  "Host-Schlüssel ist falsch"
 ],
 "ID": [
  null,
  "ID"
 ],
 "ID $id": [
  null,
  "ID $id"
 ],
 "IP address": [
  null,
  "IP-Adresse"
 ],
 "IP address with routing prefix. Separate multiple values with a comma. Example: 192.0.2.0/24, 2001:db8::/32": [
  null,
  "IP-Adresse mit Routing-Präfix. Trennen Sie mehrere Werte mit einem Komma. Beispiel: 192.0.2.0/24, 2001:db8::/32"
 ],
 "IPv4": [
  null,
  "IPv4"
 ],
 "IPv4 addresses": [
  null,
  "IPv4-Adressen"
 ],
 "IPv4 settings": [
  null,
  "IPv4-Einstellungen"
 ],
 "IPv6": [
  null,
  "IPv6"
 ],
 "IPv6 settings": [
  null,
  "IPv6-Einstellungen"
 ],
 "If left empty, ID will be generated based on associated port services and port numbers": [
  null,
  "Wenn leer, wird die Kennung auf Basis der zugehörigen Port-Dienste und Port-Nummern generiert"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Wenn der Fingerabdruck übereinstimmt, klicken Sie 'Vertrauen und Host hinzufügen'. Andernfalls lehnen Sie die Verbindung ab und kontaktieren Sie den Administrator."
 ],
 "Ignore": [
  null,
  "Ignorieren"
 ],
 "Inactive": [
  null,
  "Inaktiv"
 ],
 "Included services": [
  null,
  "Enthaltene Dienste"
 ],
 "Incoming requests are blocked by default. Outgoing requests are not blocked.": [
  null,
  "Eingehende Anfragen werden standardmäßig blockiert. Ausgehende Anfragen werden nicht blockiert."
 ],
 "Install": [
  null,
  "Installation"
 ],
 "Install software": [
  null,
  "Software installieren"
 ],
 "Installing $0": [
  null,
  "$0 wird installiert"
 ],
 "Interface": [
  null,
  "Schnittstelle",
  "Schnittstellen"
 ],
 "Interface members": [
  null,
  "Schnittstellenmitglieder"
 ],
 "Interfaces": [
  null,
  "Schnittstellen"
 ],
 "Internal error": [
  null,
  "Interner Fehler"
 ],
 "Invalid address $0": [
  null,
  "Ungültige Adresse $0"
 ],
 "Invalid date format": [
  null,
  "Ungültiges Datumsformat"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Ungültiges Datumsformat und ungültiges Zeitformat"
 ],
 "Invalid file permissions": [
  null,
  "Ungültige Dateiberechtigungen"
 ],
 "Invalid metric $0": [
  null,
  "Ungültige Metrik $0"
 ],
 "Invalid port number": [
  null,
  "Ungültige Port-Nummer"
 ],
 "Invalid prefix $0": [
  null,
  "Ungültiger Prefix $0"
 ],
 "Invalid prefix or netmask $0": [
  null,
  "Ungültiger Präfix oder ungültige Netzmaske $0"
 ],
 "Invalid range": [
  null,
  "Ungültiger Bereich"
 ],
 "Invalid time format": [
  null,
  "Ungültiges Zeitformat"
 ],
 "Invalid timezone": [
  null,
  "Ungültige Zeitzone"
 ],
 "IoT gateway": [
  null,
  "IoT-Gateway"
 ],
 "Keep connection": [
  null,
  "Verbindung halten"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Key password": [
  null,
  "Schlüsselpasswort"
 ],
 "LACP key": [
  null,
  "LACP-Schlüssel"
 ],
 "Laptop": [
  null,
  "Laptop"
 ],
 "Learn more": [
  null,
  "Mehr erfahren"
 ],
 "Link down delay": [
  null,
  "Verzögerung bei der Deaktivierung einer Verbindung"
 ],
 "Link local": [
  null,
  "Link local"
 ],
 "Link monitoring": [
  null,
  "Verbindungsüberwachung"
 ],
 "Link up delay": [
  null,
  "Verzögerung bei der Aktivierung einer Verbindung"
 ],
 "Link watch": [
  null,
  "Link beobachten"
 ],
 "Listen port": [
  null,
  "Auf Port Lauschen"
 ],
 "Listen port must be a number": [
  null,
  "Der Port, auf dem gehört wird, muss eine Nummer sein"
 ],
 "Load balancing": [
  null,
  "Lastverteilung"
 ],
 "Loading system modifications...": [
  null,
  "System-Änderungen laden..."
 ],
 "Log in": [
  null,
  "Anmelden"
 ],
 "Log in to $0": [
  null,
  "Bei $0 anmelden"
 ],
 "Log messages": [
  null,
  "Nachrichten protokollieren"
 ],
 "Login failed": [
  null,
  "Anmeldung fehlgeschlagen"
 ],
 "Low profile desktop": [
  null,
  "Low-Profile-Desktop"
 ],
 "Lunch box": [
  null,
  "Brotdose"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "MII (recommended)": [
  null,
  "MII (empfohlen)"
 ],
 "MTU": [
  null,
  "MTU"
 ],
 "MTU must be a positive number": [
  null,
  "MTU muss eine positive Zahl sein"
 ],
 "Main server chassis": [
  null,
  "Hauptservergehäuse"
 ],
 "Manage storage": [
  null,
  "Speicher verwalten"
 ],
 "Managed interfaces": [
  null,
  "Verwaltete Schnittstellen"
 ],
 "Manual": [
  null,
  "Manuell"
 ],
 "Manually": [
  null,
  "Manuell"
 ],
 "Maximum message age $max_age": [
  null,
  "Maximales Alter der Nachrichten $max_age"
 ],
 "Message to logged in users": [
  null,
  "Nachricht an angemeldete Benutzer"
 ],
 "Metric": [
  null,
  "Metrik"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini-Tower"
 ],
 "Mode": [
  null,
  "Modus"
 ],
 "Monitoring interval": [
  null,
  "Überwachungsintervall"
 ],
 "Monitoring targets": [
  null,
  "Überwachungsziele"
 ],
 "Multi-system chassis": [
  null,
  "Multi-System-Chassis"
 ],
 "Multiple addresses can be specified using commas or spaces as delimiters.": [
  null,
  "Mehrere Adressen können mit Kommas oder Leerzeichen als Trennzeichen angegeben werden."
 ],
 "NSNA ping": [
  null,
  "NSNA-Ping"
 ],
 "NTP server": [
  null,
  "NTP-Server"
 ],
 "Name": [
  null,
  "Name"
 ],
 "Need at least one NTP server": [
  null,
  "Benötigen Sie mindestens einen NTP-Server"
 ],
 "Network bond": [
  null,
  "Netzwerkbindung"
 ],
 "Network devices and graphs require NetworkManager": [
  null,
  "Netzwerkgeräte und -diagramme erfordern NetworkManager"
 ],
 "Network logs": [
  null,
  "Netzwerkprotokolle"
 ],
 "NetworkManager is not installed": [
  null,
  "NetworkManager ist nicht installiert"
 ],
 "NetworkManager is not running": [
  null,
  "NetworkManager wird nicht ausgeführt"
 ],
 "Networking": [
  null,
  "Netzwerk"
 ],
 "New password was not accepted": [
  null,
  "Das neue Passwort wurde nicht akzeptiert"
 ],
 "No": [
  null,
  "Nein"
 ],
 "No carrier": [
  null,
  "Kein Träger"
 ],
 "No delay": [
  null,
  "Keine Verzögerung"
 ],
 "No description available": [
  null,
  "Keine Beschreibung verfügbar"
 ],
 "No peers added.": [
  null,
  "Keine Peers hinzugefügt."
 ],
 "No results found": [
  null,
  "Keine Ergebnisse gefunden"
 ],
 "No such file or directory": [
  null,
  "Datei oder Verzeichnis nicht vorhanden"
 ],
 "No system modifications": [
  null,
  "Keine Systemänderungen"
 ],
 "None": [
  null,
  "Kein"
 ],
 "Not a valid private key": [
  null,
  "Ungültiger privater Schlüssel"
 ],
 "Not authorized to disable the firewall": [
  null,
  "Keine Berechtigung, die Firewall zu deaktivieren"
 ],
 "Not authorized to enable the firewall": [
  null,
  "Keine Berechtigung, die Firewall zu aktivieren"
 ],
 "Not available": [
  null,
  "Nicht verfügbar"
 ],
 "Not permitted to configure network devices": [
  null,
  "Keine Berechtigung zur Konfiguration von Netzwerkgeräten"
 ],
 "Not permitted to perform this action.": [
  null,
  "Diese Aktion darf nicht ausgeführt werden."
 ],
 "Not synchronized": [
  null,
  "Nicht synchronisiert"
 ],
 "Notebook": [
  null,
  "Notizbuch"
 ],
 "Occurrences": [
  null,
  "Vorkommnisse"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Old password not accepted": [
  null,
  "Altes Passwort wurde nicht akzeptiert"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Wenn Cockpit installiert ist, aktivieren Sie es mit \"systemctl enable --now cockpit.socket\"."
 ],
 "Options": [
  null,
  "Einstellungen"
 ],
 "Other": [
  null,
  "Weitere"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit ist abgestürzt"
 ],
 "Parent": [
  null,
  "Übergeordnet"
 ],
 "Parent $parent": [
  null,
  ""
 ],
 "Part of $0": [
  null,
  "Teil von $0"
 ],
 "Passive": [
  null,
  "Passiv"
 ],
 "Password": [
  null,
  "Passwort"
 ],
 "Password is not acceptable": [
  null,
  "Das Passwort kann nicht akzeptiert werden"
 ],
 "Password is too weak": [
  null,
  "Das gewählte Passwort ist zu schwach"
 ],
 "Password not accepted": [
  null,
  "Passwort wurde nicht akzeptiert"
 ],
 "Paste": [
  null,
  "Einfügen"
 ],
 "Paste error": [
  null,
  "Fehler beim Einfügen"
 ],
 "Paste existing key": [
  null,
  "Vorhandenen Schlüssel einfügen"
 ],
 "Path cost": [
  null,
  "Pfadkosten"
 ],
 "Path cost $path_cost": [
  null,
  "Pfadkosten $path_cost"
 ],
 "Path to file": [
  null,
  "Pfad zur Datei"
 ],
 "Peer #$0 has invalid endpoint port. Port must be a number.": [
  null,
  "Peer #$0 hat ungültigen Endpunkt-Port. Port muss eine Zahl sein."
 ],
 "Peer #$0 has invalid endpoint. It must be specified as host:port, e.g. 1.2.3.4:51820 or example.com:51820": [
  null,
  "Peer #$0 hat einen ungültigen Endpunkt. Er muss als Host:Port angegeben werden, z.B. 1.2.3.4:51820 oder example.com:51820"
 ],
 "Peers": [
  null,
  "Peers"
 ],
 "Peers are other machines that connect with this one. Public keys from other machines will be shared with each other.": [
  null,
  "Peers sind andere Rechner, die eine Verbindung zu diesem Rechner herstellen. Öffentliche Schlüssel von anderen Rechnern werden untereinander ausgetauscht."
 ],
 "Peripheral chassis": [
  null,
  "Peripheriechassis"
 ],
 "Permanent": [
  null,
  "Permanent"
 ],
 "Pick date": [
  null,
  "Datum auswählen"
 ],
 "Ping interval": [
  null,
  "Ping-Intervall"
 ],
 "Ping target": [
  null,
  "Ping-Ziel"
 ],
 "Pizza box": [
  null,
  "Pizza-Box"
 ],
 "Please install the $0 package": [
  null,
  "Bitte installieren Sie die $0 Paket"
 ],
 "Portable": [
  null,
  "tragbar"
 ],
 "Ports": [
  null,
  "Ports"
 ],
 "Prefix length": [
  null,
  "Präfixlänge"
 ],
 "Prefix length or netmask": [
  null,
  "Präfix oder Netzmaske"
 ],
 "Preparing": [
  null,
  "Vorbereitung läuft"
 ],
 "Present": [
  null,
  "Derzeit"
 ],
 "Preserve": [
  null,
  "Beibehalten"
 ],
 "Primary": [
  null,
  "Primär"
 ],
 "Priority": [
  null,
  "Priorität"
 ],
 "Priority $priority": [
  null,
  "Priorität $priority"
 ],
 "Private key": [
  null,
  "Privater Schlüssel"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Die Aufforderung über ssh-add ist abgelaufen"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Die Aufforderung über ssh-keygen ist abgelaufen"
 ],
 "Public key": [
  null,
  "Öffentlicher Schlüssel"
 ],
 "Public key will be generated when a valid private key is entered": [
  null,
  "Der öffentliche Schlüssel wird generiert, wenn ein gültiger privater Schlüssel eingegeben wird"
 ],
 "RAID chassis": [
  null,
  "RAID-Chassis"
 ],
 "Rack mount chassis": [
  null,
  "Rack-Einbaugehäuse"
 ],
 "Random": [
  null,
  "Zufällig"
 ],
 "Range": [
  null,
  "Bereich"
 ],
 "Range must be strictly ordered": [
  null,
  "Bereich muss strikt geordnet sein"
 ],
 "Reboot": [
  null,
  "Neustart"
 ],
 "Receiving": [
  null,
  "Empfangen"
 ],
 "Regenerate": [
  null,
  "Regenerieren"
 ],
 "Removals:": [
  null,
  "Umzüge:"
 ],
 "Remove $0": [
  null,
  "Entferne $0"
 ],
 "Remove $0 service from $1 zone": [
  null,
  "Dienst $0 aus der Zone $1 entfernen"
 ],
 "Remove item": [
  null,
  "Element entfernen"
 ],
 "Remove service $0": [
  null,
  "Dienst $0 entfernen"
 ],
 "Remove zone $0": [
  null,
  "Zone $0 entfernen"
 ],
 "Removing $0": [
  null,
  "Entfernen $0"
 ],
 "Removing $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Das Entfernen von $0 wird die Verbindung zum Server unterbrechen und damit den Zugriff auf die Benutzeroberfläche unmöglich machen."
 ],
 "Removing the cockpit service might result in the web console becoming unreachable. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Das entfernen des Cockpit-Services kann die Web Konsole nicht mehr erreichbar machen. Stelen sie sicher, dass die Zone keine Auswirkungen auf ihre aktuelle Web Konsolen Verbindung hat."
 ],
 "Removing the zone will remove all services within it.": [
  null,
  "Das entfernen der Zone wird alle Service in ihr entfernen."
 ],
 "Restoring connection": [
  null,
  "Verbindung wird wiederhergestellt"
 ],
 "Round robin": [
  null,
  "Round robin"
 ],
 "Routes": [
  null,
  "Routen"
 ],
 "Row expansion": [
  null,
  "Zeilenerweiterung"
 ],
 "Row select": [
  null,
  "Zeilenauswahl"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Führen Sie diesen Befehl über ein vertrauenswürdiges Netzwerk oder physisch auf dem entfernten Rechner aus:"
 ],
 "Runner": [
  null,
  "Runner"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "SSH-Schlüssel"
 ],
 "SSH key login": [
  null,
  "SSH-Schlüssel-Anmeldung"
 ],
 "STP forward delay": [
  null,
  "STP Forward Delay"
 ],
 "STP hello time": [
  null,
  "STP Hello-Zeitintervall"
 ],
 "STP maximum message age": [
  null,
  "STP Maximum Message Age"
 ],
 "STP priority": [
  null,
  "STP-Priorität"
 ],
 "Save": [
  null,
  "Speichern"
 ],
 "Sealed-case PC": [
  null,
  "PC mit versiegeltem Gehäuse"
 ],
 "Search domain": [
  null,
  "Suchdomäne"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Sicherheitsverstärkte Linuxkonfiguration und Problemlösung"
 ],
 "Select an option": [
  null,
  "Wählen Sie eine Option aus"
 ],
 "Select method": [
  null,
  "Methode auswählen"
 ],
 "Sending": [
  null,
  "Senden"
 ],
 "Server": [
  null,
  "Server"
 ],
 "Server has closed the connection.": [
  null,
  "Der Server hat die Verbindung beendet."
 ],
 "Service": [
  null,
  "Dienst"
 ],
 "Services": [
  null,
  "Dienste"
 ],
 "Set time": [
  null,
  "Zeit setzen"
 ],
 "Set to": [
  null,
  "Einstellen"
 ],
 "Shared": [
  null,
  "Geteilt"
 ],
 "Shell script": [
  null,
  "Shell script"
 ],
 "Shift+Insert": [
  null,
  "Shift+Einfügen"
 ],
 "Show confirmation password": [
  null,
  "Bestätigungspasswort anzeigen"
 ],
 "Show password": [
  null,
  "Passwort anzeigen"
 ],
 "Shut down": [
  null,
  "Herunterfahren"
 ],
 "Single rank": [
  null,
  "Einzelner Rang"
 ],
 "Sorted from least to most trusted": [
  null,
  "Sortiert von am wenigsten bis am meisten vertrauenswürdig"
 ],
 "Space-saving computer": [
  null,
  "Platzsparender Computer"
 ],
 "Spanning tree protocol": [
  null,
  "Spanning tree protocol"
 ],
 "Spanning tree protocol (STP)": [
  null,
  "Spanning tree protocol (STP)"
 ],
 "Specific time": [
  null,
  "Bestimmte Zeit"
 ],
 "Stable": [
  null,
  "Stabil"
 ],
 "Start service": [
  null,
  "Dienst starten"
 ],
 "Status": [
  null,
  "Status"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "Sticky": [
  null,
  "Sticky"
 ],
 "Storage": [
  null,
  "Speicher"
 ],
 "Strong password": [
  null,
  "Starkes Passwort"
 ],
 "Sub-Chassis": [
  null,
  "Sub-Chassis"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Switch off $0": [
  null,
  "$0 ausschalten"
 ],
 "Switch on $0": [
  null,
  "$0 anschalten"
 ],
 "Switching off $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Das Ausschalten von $0 wird die Verbindung zum Server unterbrechen und damit den Zugriff auf die Benutzeroberfläche unmöglich machen."
 ],
 "Switching on $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Das Einschalten von $0 wird die Verbindung zum Server unterbrechen und damit den Zugriff auf die Benutzeroberfläche unmöglich machen."
 ],
 "Synchronized": [
  null,
  "Synchronisiert"
 ],
 "Synchronized with $0": [
  null,
  "Mit $0 synchronisiert"
 ],
 "Synchronizing": [
  null,
  "Wird synchronisiert"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "Tablet": [
  null,
  "Tablett"
 ],
 "Team": [
  null,
  "Team"
 ],
 "Team port": [
  null,
  "Netzwerk-Team Anschluss"
 ],
 "Team port settings": [
  null,
  "Team port Einstellungen"
 ],
 "Testing connection": [
  null,
  "Prüfe Verbindung"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "Der SSH-Schlüssel $0 von $1 auf $2 wird der Datei $3 von $4 auf $5 hinzugefügt."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "Der SSH-Schlüssel $0 wird für den Rest der Sitzung zur Verfügung gestellt und steht auch für die Anmeldung bei anderen Hosts zur Verfügung."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "Der SSH-Schlüssel für die Anmeldung bei $0 ist durch ein Passwort geschützt, und der Host erlaubt keine Anmeldung mit einem Passwort. Bitte geben Sie das Passwort des Schlüssels auf $1 an."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "Der SSH-Schlüssel für die Anmeldung bei $0 ist geschützt. Sie können sich entweder mit Ihrem Anmeldepasswort oder mit dem Passwort des Schlüssels bei $1 anmelden."
 ],
 "The cockpit service is automatically included": [
  null,
  "Der Cockpit-Dienst ist automatisch enthalten"
 ],
 "The fingerprint should match:": [
  null,
  "Der Fingerabdruck sollte übereinstimmen:"
 ],
 "The key password can not be empty": [
  null,
  "Das Schlüsselpasswort darf nicht leer sein"
 ],
 "The key passwords do not match": [
  null,
  "Die Schlüsselpasswörter stimmen nicht überein"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Der angemeldete Benutzer ist nicht berechtigt, Systemänderungen einzusehen"
 ],
 "The password can not be empty": [
  null,
  "Das Passwort darf nicht leer sein"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Der entstandene Fingerabdruck kann über öffentliche Methoden, einschließlich E-Mail, weitergegeben werden."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Der resultierende Fingerabdruck kann über öffentliche Methoden, einschließlich E-Mail, weitergegeben werden. Wenn Sie eine andere Person bitten, die Überprüfung für Sie vorzunehmen, kann diese die Ergebnisse mit einer beliebigen Methode übermitteln."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Der Server hat die Authentifizierung mit allen unterstützten Methoden abgelehnt."
 ],
 "There are no active services in this zone": [
  null,
  "In dieser Zone gibt es keine aktiven Dienste"
 ],
 "This device cannot be managed here.": [
  null,
  "Dieses Gerät kann hier nicht verwaltet werden."
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Dieses Tool konfiguriert die SELinux Policy und hilft dabei Verletzungen der Policy zu verstehen und aufzulösen."
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Dieses Werkzeug konfiguriert das System zum Erzeugen von Kernel Crashdumps. Es unterstützt \"local\" (Festplatte), \"ssh\" und \"nfs\" als Schreibziele."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Dieses Tool generiert ein Archiv der Konfiguration und Diagnoseinformation des laufenden Systems.Das Archiv kann lokal oder zentral abgespeichert werden zum Zweck der Archivierung oder Nachverfolgung oder kann an den Technischen Support, Entwickler oder Systemadministratoren gesendet werden, um bei der Fehlersuche oder Debugging zu helfen."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Dieses Tool verwaltet den lokalen Speicher, wie etwa Dateisysteme, LVM2 Volume Gruppen und NFS Einhängepunkte."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Dieses Tool verwaltet die Netzwerkumgebung wie etwa Bindungen, Bridges, Teams, VLANs und Firewalls durch den NetworkManager und Firewalld. Der NetworkManager ist inkompatibel mit dem Ubuntus Standard systemd-networkd und Debians ifupdown Scipts."
 ],
 "This zone contains the cockpit service. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Diese Zone enthält den Cockpit-Dienst. Stellen Sie sicher, dass diese Zone nicht auf Ihre aktuelle Web-Konsolenverbindung angewendet wird."
 ],
 "Time zone": [
  null,
  "Zeitzone"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Überprüfen Sie bitte den Fingerabdruck des Host-Schlüssels, um sicherzustellen, dass Ihre Verbindung nicht von einem böswilligen Dritten ausgespäht wird:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Um einen Fingerabdruck zu überprüfen, führen Sie die folgenden Schritte auf $0 aus, während Sie physisch an der Maschine sitzen oder über ein vertrauenswürdiges Netzwerk:"
 ],
 "Toggle date picker": [
  null,
  "Datumsauswahl umschalten"
 ],
 "Too much data": [
  null,
  "Zu viele Daten"
 ],
 "Total size: $0": [
  null,
  "Gesamtgröße: $0"
 ],
 "Tower": [
  null,
  "Turm"
 ],
 "Transmitting": [
  null,
  "Wird übertragen"
 ],
 "Troubleshoot…": [
  null,
  "Fehlerbehebung…"
 ],
 "Trust and add host": [
  null,
  "Host vertrauen und hinzufügen"
 ],
 "Trust level": [
  null,
  "Vertrauensstufe"
 ],
 "Trying to synchronize with $0": [
  null,
  "Versuche mit $0 zu synchronisieren"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Die Anmeldung bei $0 mit SSH-Schlüsselauthentifizierung ist nicht möglich. Bitte geben Sie das Passwort an."
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Die Anmeldung bei $0 ist nicht möglich. Der Host akzeptiert weder ein Passwort noch einen Ihrer SSH-Schlüssel."
 ],
 "Unexpected error": [
  null,
  "Unerwarteter Fehler"
 ],
 "Unknown": [
  null,
  "Unbekannt"
 ],
 "Unknown \"$0\"": [
  null,
  "Unbekannte \"$0\""
 ],
 "Unknown configuration": [
  null,
  "Unbekannte Konfiguration"
 ],
 "Unknown host: $0": [
  null,
  "Unbekannter Host: $0"
 ],
 "Unknown service name": [
  null,
  "Unbekannten Servicename"
 ],
 "Unmanaged interfaces": [
  null,
  "Unverwaltete Schnittstellen"
 ],
 "Untrusted host": [
  null,
  "Nicht vertrauenswürdiger Host"
 ],
 "Use $0": [
  null,
  "$0 verwenden"
 ],
 "VLAN": [
  null,
  "VLAN"
 ],
 "VLAN ID": [
  null,
  "VLAN-Kennung"
 ],
 "Verify fingerprint": [
  null,
  "Fingerabdruck verifizieren"
 ],
 "View all logs": [
  null,
  "Alle Protokolle ansehen"
 ],
 "View automation script": [
  null,
  "Automatisierungs-Script anzeigen"
 ],
 "Visit firewall": [
  null,
  "Firewall besuchen"
 ],
 "Waiting": [
  null,
  "Wartet"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Warten, bis andere Software-Verwaltungsvorgänge abgeschlossen sind"
 ],
 "Weak password": [
  null,
  "Schwaches Passwort"
 ],
 "Web Console for Linux servers": [
  null,
  "Webkonsole für Linux-Server"
 ],
 "Will be set to \"Automatic\"": [
  null,
  "Wird auf \"Automatisch\" gesetzt"
 ],
 "WireGuard": [
  null,
  "WireGuard"
 ],
 "XOR": [
  null,
  "XOR"
 ],
 "Yes": [
  null,
  "Ja"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Sie stellen zum ersten Mal eine Verbindung zu $0 her."
 ],
 "You are not authorized to modify the firewall.": [
  null,
  "Sie sind nicht berechtigt, die Firewall zu ändern."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Ihr Browser lässt das Einfügen über das Kontextmenü nicht zu. Sie können Umschalt+Einfügen verwenden."
 ],
 "Your session has been terminated.": [
  null,
  "Ihre Sitzung wurde beendet."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Die Session ist abgelaufen. Bitte neu einloggen."
 ],
 "Zone": [
  null,
  "Zone"
 ],
 "[binary data]": [
  null,
  "[Binärdaten]"
 ],
 "[no data]": [
  null,
  "[keine Daten]"
 ],
 "edit": [
  null,
  "bearbeiten"
 ],
 "in less than a minute": [
  null,
  "in weniger als einer Minute"
 ],
 "less than a minute ago": [
  null,
  "vor weniger als einer Minute"
 ],
 "password quality": [
  null,
  "Passwortqualität"
 ],
 "show less": [
  null,
  "zeige weniger"
 ],
 "show more": [
  null,
  "Zeig mehr"
 ],
 "wireguard-tools package is not installed": [
  null,
  "Paket wireguard-tools ist nicht installiert"
 ]
});
