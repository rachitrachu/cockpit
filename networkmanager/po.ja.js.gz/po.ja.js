cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "ja",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 active zone": [
  null,
  "$0 アクティブゾーン"
 ],
 "$0 day": [
  null,
  "$0 日"
 ],
 "$0 exited with code $1": [
  null,
  "$0 がコード $1 で終了しました"
 ],
 "$0 failed": [
  null,
  "$0 が失敗しました"
 ],
 "$0 hour": [
  null,
  "$0 時間"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 は、あらゆるリポジトリーから利用できません。"
 ],
 "$0 key changed": [
  null,
  "$0 キーが変更されました"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 がシグナル $1 で終了しました"
 ],
 "$0 minute": [
  null,
  "$0 分"
 ],
 "$0 month": [
  null,
  "$0 カ月"
 ],
 "$0 week": [
  null,
  "$0 週"
 ],
 "$0 will be installed.": [
  null,
  "$0 がインストールされます。"
 ],
 "$0 year": [
  null,
  "$0 年"
 ],
 "$0 zone": [
  null,
  "$0 ゾーン"
 ],
 "1 day": [
  null,
  "1 日"
 ],
 "1 hour": [
  null,
  "1 時間"
 ],
 "1 minute": [
  null,
  "1 分"
 ],
 "1 week": [
  null,
  "1 週間"
 ],
 "20 minutes": [
  null,
  "20 分"
 ],
 "40 minutes": [
  null,
  "40 分"
 ],
 "5 minutes": [
  null,
  "5 分"
 ],
 "6 hours": [
  null,
  "6 時間"
 ],
 "60 minutes": [
  null,
  "60 分"
 ],
 "802.3ad": [
  null,
  "802.3ad"
 ],
 "802.3ad LACP": [
  null,
  "802.3ad LACP"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Cockpit の互換バージョンが $0 にインストールされていません。"
 ],
 "A network bond combines multiple network interfaces into one logical interface with higher throughput or redundancy.": [
  null,
  "ネットワークボンディングは、複数のネットワークインターフェイスを単一の論理インターフェイスにまとめることで、スループットや冗長性を向上させます。"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "$0 で新しい SSH キーが $2 の $1 用に作成され、$5 上の $3 の $3 ファイルに追加されました。"
 ],
 "ARP": [
  null,
  "ARP"
 ],
 "ARP monitoring": [
  null,
  "ARP 監視"
 ],
 "ARP ping": [
  null,
  "ARP ping"
 ],
 "Absent": [
  null,
  "不在"
 ],
 "Acceptable password": [
  null,
  "受け入れられるパスワード"
 ],
 "Active": [
  null,
  "動作中"
 ],
 "Active backup": [
  null,
  "アクティブなバックアップ"
 ],
 "Adaptive load balancing": [
  null,
  "適応ロードバランス"
 ],
 "Adaptive transmit load balancing": [
  null,
  "適応送信のロードバランス"
 ],
 "Add": [
  null,
  "追加"
 ],
 "Add $0": [
  null,
  "$0 の追加"
 ],
 "Add DNS server": [
  null,
  "DNS サーバーの追加"
 ],
 "Add VLAN": [
  null,
  "VLAN の追加"
 ],
 "Add VPN": [
  null,
  "VPN の追加"
 ],
 "Add WireGuard VPN": [
  null,
  "WireGuard VPN の追加"
 ],
 "Add a new zone": [
  null,
  "新規ゾーンの追加"
 ],
 "Add address": [
  null,
  "アドレスの追加"
 ],
 "Add bond": [
  null,
  "ボンディングの追加"
 ],
 "Add bridge": [
  null,
  "ブリッジの追加"
 ],
 "Add member": [
  null,
  "メンバーの追加"
 ],
 "Add new zone": [
  null,
  "新規ゾーンの追加"
 ],
 "Add peer": [
  null,
  "ピアの追加"
 ],
 "Add ports": [
  null,
  "ポートの追加"
 ],
 "Add ports to $0 zone": [
  null,
  "$0 ゾーンにポートを追加"
 ],
 "Add route": [
  null,
  "ルートの追加"
 ],
 "Add search domain": [
  null,
  "検索ドメインの追加"
 ],
 "Add services": [
  null,
  "サービスの追加"
 ],
 "Add services to $0 zone": [
  null,
  "$0 ゾーンにサービスを追加"
 ],
 "Add services to zone $0": [
  null,
  "ゾーン $0 にサービスを追加"
 ],
 "Add team": [
  null,
  "チームの追加"
 ],
 "Add zone": [
  null,
  "ゾーンの追加"
 ],
 "Adding $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "$0 を追加すると、サーバーへの接続が切断され、管理 UI が利用できなくなります。"
 ],
 "Adding custom ports will reload firewalld. A reload will result in the loss of any runtime-only configuration!": [
  null,
  "カスタムポートを追加すると、firewalld がリロードされます。リロードにより、ランタイムのみの設定が失われます!"
 ],
 "Additional DNS $val": [
  null,
  "追加の DNS $val"
 ],
 "Additional DNS search domains $val": [
  null,
  "追加の DNS 検索ドメイン $val"
 ],
 "Additional address $val": [
  null,
  "追加のアドレス $val"
 ],
 "Additional packages:": [
  null,
  "追加のパッケージ:"
 ],
 "Additional ports": [
  null,
  "追加ポート"
 ],
 "Address": [
  null,
  "アドレス"
 ],
 "Address $val": [
  null,
  "アドレス $val"
 ],
 "Addresses": [
  null,
  "アドレス"
 ],
 "Addresses are not formatted correctly": [
  null,
  "アドレスの形式が正しくありません"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Cockpit Web コンソールでの管理"
 ],
 "Advanced TCA": [
  null,
  "高度な TCA"
 ],
 "All-in-one": [
  null,
  "オールインワン"
 ],
 "Allowed IPs": [
  null,
  "利用可能な IP"
 ],
 "Allowed addresses": [
  null,
  "許可されたアドレス"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Ansible ロールのドキュメント"
 ],
 "Authenticating": [
  null,
  "認証中"
 ],
 "Authentication": [
  null,
  "認証"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Cockpit Web コンソールでの特権タスクの実行には、認証が必要です"
 ],
 "Authorize SSH key": [
  null,
  "SSH キーの認証"
 ],
 "Automatic": [
  null,
  "自動"
 ],
 "Automatic (DHCP only)": [
  null,
  "自動 (DHCP のみ)"
 ],
 "Automatically using NTP": [
  null,
  "NTP を自動的に使用"
 ],
 "Automatically using additional NTP servers": [
  null,
  "追加の NTP サーバーを自動的に使用"
 ],
 "Automatically using specific NTP servers": [
  null,
  "特定の NTP サーバーを自動的に使用"
 ],
 "Automation script": [
  null,
  "オートメーションスクリプト"
 ],
 "Balancer": [
  null,
  "バランサー"
 ],
 "Blade": [
  null,
  "ブレード"
 ],
 "Blade enclosure": [
  null,
  "ブレードエンクロージャー"
 ],
 "Bond": [
  null,
  "ボンディング"
 ],
 "Bridge": [
  null,
  "ブリッジ"
 ],
 "Bridge port": [
  null,
  "ブリッジポート"
 ],
 "Bridge port settings": [
  null,
  "ブリッジポート設定"
 ],
 "Broadcast": [
  null,
  "ブロードキャスト"
 ],
 "Broken configuration": [
  null,
  "破損した設定"
 ],
 "Bus expansion chassis": [
  null,
  "バス拡張シャーシ"
 ],
 "Cancel": [
  null,
  "取り消し"
 ],
 "Cannot forward login credentials": [
  null,
  "ログインのクレデンシャルをフォワードできません"
 ],
 "Cannot schedule event in the past": [
  null,
  "過去のイベントはスケジュールできません"
 ],
 "Carrier": [
  null,
  "キャリア"
 ],
 "Change": [
  null,
  "変更"
 ],
 "Change system time": [
  null,
  "システム時間の変更"
 ],
 "Change the settings": [
  null,
  "設定の変更"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "キーを変更すると、オペレーティングシステムを再インストールすることになることが多くあります。ただし、予期しない変更により接続の傍受が試行される場合もあります。"
 ],
 "Changing the settings will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "設定を変更すると、サーバーへの接続が切断され、管理 UI が利用できなくなります。"
 ],
 "Checking IP": [
  null,
  "IP の確認中"
 ],
 "Checking installed software": [
  null,
  "インストールされたソフトウェアの確認中"
 ],
 "Clear input value": [
  null,
  "入力値の消去"
 ],
 "Close": [
  null,
  "閉じる"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Cockpit の NetworkManager と Firewalld の設定"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit は該当するホストに接続できませんでした。"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit は、Web ブラウザーで Linux サーバーを簡単に管理できるサーバーマネージャーです。端末と Web ツールを区別せずに使用できます。Cockpit で起動されたサービスは端末で停止できます。同様に、端末でエラーが発生した場合は、そのエラーを Cockpit ジャーナルインターフェースで確認できます。"
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit にはシステム上のそのソフトウェアとの互換性がありません。"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit はインストールされていません"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit はシステムにインストールされていません。"
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit は経験が少ないシステム管理者に最適です。これらのシステム管理者はストレージの管理、ジャーナルの検査、サービスの起動および停止などの単純なタスクを簡単に実行できるようになります。また、複数のサーバーを同時に監視および管理できます。これらのサーバーはクリックするだけで追加できます。追加後に、ご使用のマシンは他のマシンを管理するようになります。"
 ],
 "Collect and package diagnostic and support data": [
  null,
  "診断およびサポートデータの収集とパッケージ化"
 ],
 "Collect kernel crash dumps": [
  null,
  "カーネルクラッシュダンプの収集"
 ],
 "Comma-separated ports, ranges, and services are accepted": [
  null,
  "ポート、範囲、およびサービスをコンマ区切りで指定できます"
 ],
 "Compact PCI": [
  null,
  "PCI の圧縮"
 ],
 "Configuring": [
  null,
  "設定中"
 ],
 "Configuring IP": [
  null,
  "IP の設定中"
 ],
 "Confirm key password": [
  null,
  "キーパスワードの確認"
 ],
 "Confirm removal of $0": [
  null,
  "$0 の削除を確認"
 ],
 "Connect automatically": [
  null,
  "自動的に接続"
 ],
 "Connection has timed out.": [
  null,
  "接続がタイムアウトしました。"
 ],
 "Connection will be lost": [
  null,
  "接続が失われます"
 ],
 "Convertible": [
  null,
  "変換可能"
 ],
 "Copied": [
  null,
  "コピー済み"
 ],
 "Copy": [
  null,
  "コピー"
 ],
 "Copy to clipboard": [
  null,
  "クリップボードにコピー"
 ],
 "Create $0": [
  null,
  "$0 を作成"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "新しい SSH キーを作成して承認します"
 ],
 "Create it": [
  null,
  "作成"
 ],
 "Create new task file with this content.": [
  null,
  "このコンテンツで新しいタスクファイルを作成します。"
 ],
 "Creating this $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "この $0 を作成すると、サーバーへの接続が切断され、管理 UI が利用できなくなります。"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Custom ports": [
  null,
  "カスタムポート"
 ],
 "Custom zones": [
  null,
  "カスタムゾーン"
 ],
 "DNS": [
  null,
  "DNS"
 ],
 "DNS $val": [
  null,
  "DNS $val"
 ],
 "DNS search domains": [
  null,
  "DNS 検索ドメイン"
 ],
 "DNS search domains $val": [
  null,
  "DNS 検索ドメイン $val"
 ],
 "Deactivating": [
  null,
  "非アクティブ化"
 ],
 "Delay": [
  null,
  "遅延"
 ],
 "Delete": [
  null,
  "削除"
 ],
 "Delete $0": [
  null,
  "$0 の削除"
 ],
 "Deleting $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "$0 を削除すると、サーバーへの接続が切断され、管理 UI が利用できなくなります。"
 ],
 "Description": [
  null,
  "説明"
 ],
 "Desktop": [
  null,
  "デスクトップ"
 ],
 "Detachable": [
  null,
  "割り当て解除可能"
 ],
 "Diagnostic reports": [
  null,
  "診断レポート"
 ],
 "Disable the firewall": [
  null,
  "ファイアウォールの無効化"
 ],
 "Disabled": [
  null,
  "無効"
 ],
 "Docking station": [
  null,
  "ドッキングステーション"
 ],
 "Downloading $0": [
  null,
  "$0 をダウンロード中"
 ],
 "Dual rank": [
  null,
  "デュアルランク"
 ],
 "Edit": [
  null,
  "編集"
 ],
 "Edit VLAN settings": [
  null,
  "VLAN 設定の編集"
 ],
 "Edit WireGuard VPN": [
  null,
  "WireGuard VPN を編集する"
 ],
 "Edit bond settings": [
  null,
  "ボンディング設定の編集"
 ],
 "Edit bridge settings": [
  null,
  "ブリッジ設定の編集"
 ],
 "Edit custom service in $0 zone": [
  null,
  "$0 ゾーンでカスタムサービスを編集する"
 ],
 "Edit rules and zones": [
  null,
  "ルールとゾーンを編集する"
 ],
 "Edit service": [
  null,
  "サービスの編集"
 ],
 "Edit service $0": [
  null,
  "サービス $0 を編集する"
 ],
 "Edit team settings": [
  null,
  "チーム設定の編集"
 ],
 "Embedded PC": [
  null,
  "組み込み PC"
 ],
 "Enable or disable the device": [
  null,
  "デバイスを有効化または無効化します"
 ],
 "Enable service": [
  null,
  "サービスを有効にします"
 ],
 "Enable the firewall": [
  null,
  "ファイアウォールを有効にします"
 ],
 "Enabled": [
  null,
  "有効"
 ],
 "Endpoint": [
  null,
  "エンドポイント"
 ],
 "Endpoint acting as a \"server\" need to be specified as host:port, otherwise it can be left empty.": [
  null,
  "\"サーバー\" として機能するエンドポイントは host:port の形式で指定する必要があります。それ以外の場合は空白のままにできます。"
 ],
 "Enter a valid MAC address": [
  null,
  "有効な MAC アドレスを入力します"
 ],
 "Entire subnet": [
  null,
  "サブネット全体"
 ],
 "Ethernet MAC": [
  null,
  "Ethernet MAC"
 ],
 "Ethernet MTU": [
  null,
  "Ethernet MTU"
 ],
 "Ethtool": [
  null,
  "Ethtool"
 ],
 "Example: 22,ssh,8080,5900-5910": [
  null,
  "例: 22,ssh,8080,5900-5910"
 ],
 "Example: 88,2019,nfs,rsync": [
  null,
  "例: 88,2019,nfs,rsync"
 ],
 "Excellent password": [
  null,
  "優れたパスワード"
 ],
 "Expansion chassis": [
  null,
  "拡張シャーシ"
 ],
 "Failed": [
  null,
  "失敗"
 ],
 "Failed to add port": [
  null,
  "ポートの追加に失敗しました"
 ],
 "Failed to add service": [
  null,
  "サービスの追加に失敗しました"
 ],
 "Failed to add zone": [
  null,
  "ゾーンの追加に失敗しました"
 ],
 "Failed to change password": [
  null,
  "パスワードの変更に失敗しました"
 ],
 "Failed to edit service": [
  null,
  "サービスの編集に失敗しました"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "firewalld での $0 の有効化に失敗しました"
 ],
 "Failed to save settings": [
  null,
  "設定の保存に失敗しました"
 ],
 "Filter services": [
  null,
  "サービスの絞り込み"
 ],
 "Firewall": [
  null,
  "ファイアウォール"
 ],
 "Firewall is not available": [
  null,
  "ファイアウォールは利用できません"
 ],
 "Forward delay $forward_delay": [
  null,
  "フォワード遅延 $forward_delay"
 ],
 "Gateway": [
  null,
  "ゲートウェイ"
 ],
 "General": [
  null,
  "全般"
 ],
 "Generated": [
  null,
  "生成しました"
 ],
 "Go to now": [
  null,
  "今すぐ移動"
 ],
 "Group": [
  null,
  "グループ"
 ],
 "Hair pin mode": [
  null,
  "ヘアピンモード"
 ],
 "Hairpin mode": [
  null,
  "ヘアピンモード"
 ],
 "Handheld": [
  null,
  "ハンドヘルド"
 ],
 "Hello time $hello_time": [
  null,
  "Hello タイム $hello_time"
 ],
 "Hide confirmation password": [
  null,
  "確認パスワードの非表示"
 ],
 "Hide password": [
  null,
  "パスワードの非表示"
 ],
 "Host key is incorrect": [
  null,
  "ホスト鍵が正しくありません"
 ],
 "ID": [
  null,
  "ID"
 ],
 "ID $id": [
  null,
  "ID $id"
 ],
 "IP address": [
  null,
  "IP アドレス"
 ],
 "IP address with routing prefix. Separate multiple values with a comma. Example: 192.0.2.0/24, 2001:db8::/32": [
  null,
  "ルーティングプレフィックス付きの IP アドレス。複数の値はコンマで区切ります。例: 192.0.2.0/24, 2001:db8::/32"
 ],
 "IPv4": [
  null,
  "IPv4"
 ],
 "IPv4 addresses": [
  null,
  "IPv4 アドレス"
 ],
 "IPv4 settings": [
  null,
  "IPv4 の設定"
 ],
 "IPv6": [
  null,
  "IPv6"
 ],
 "IPv6 settings": [
  null,
  "IPv6 の設定"
 ],
 "If left empty, ID will be generated based on associated port services and port numbers": [
  null,
  "空白のままの場合、関連付けられたポートサービスおよびポート番号に基づいて ID が生成されます"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "フィンガープリントが一致している場合は、'ホストを信頼して追加' をクリックします。一致していない場合は、接続せずに管理者にお問い合わせください。"
 ],
 "Ignore": [
  null,
  "無視"
 ],
 "Inactive": [
  null,
  "停止"
 ],
 "Included services": [
  null,
  "含まれているサービス"
 ],
 "Incoming requests are blocked by default. Outgoing requests are not blocked.": [
  null,
  "受信リクエストはデフォルトでブロックされます。発信リクエストはブロックされません。"
 ],
 "Install": [
  null,
  "インストール"
 ],
 "Install software": [
  null,
  "ソフトウェアをインストール"
 ],
 "Installing $0": [
  null,
  "$0 をインストール中"
 ],
 "Interface": [
  null,
  "インターフェース"
 ],
 "Interface members": [
  null,
  "インターフェースメンバー"
 ],
 "Interfaces": [
  null,
  "インターフェース"
 ],
 "Internal error": [
  null,
  "内部エラー"
 ],
 "Invalid address $0": [
  null,
  "無効なアドレス $0"
 ],
 "Invalid date format": [
  null,
  "無効な日付形式"
 ],
 "Invalid date format and invalid time format": [
  null,
  "無効な日付形式と無効な時間形式"
 ],
 "Invalid file permissions": [
  null,
  "無効なファイルパーミッション"
 ],
 "Invalid metric $0": [
  null,
  "無効なメトリック $0"
 ],
 "Invalid port number": [
  null,
  "無効なポート番号"
 ],
 "Invalid prefix $0": [
  null,
  "無効なプレフィックス $0"
 ],
 "Invalid prefix or netmask $0": [
  null,
  "無効なプレフィックスまたはネットマスク $0"
 ],
 "Invalid range": [
  null,
  "無効な範囲"
 ],
 "Invalid time format": [
  null,
  "無効な時間形式"
 ],
 "Invalid timezone": [
  null,
  "無効なタイムゾーン"
 ],
 "IoT gateway": [
  null,
  "IoT ゲートウェイ"
 ],
 "Keep connection": [
  null,
  "接続の保持"
 ],
 "Kernel dump": [
  null,
  "カーネルダンプ"
 ],
 "Key password": [
  null,
  "キーパスワード"
 ],
 "LACP key": [
  null,
  "LACP キー"
 ],
 "Laptop": [
  null,
  "ラップトップ"
 ],
 "Learn more": [
  null,
  "もっと詳しく"
 ],
 "Link down delay": [
  null,
  "リンクダウンの遅延"
 ],
 "Link local": [
  null,
  "ローカルリンク"
 ],
 "Link monitoring": [
  null,
  "リンクのモニタリング"
 ],
 "Link up delay": [
  null,
  "リンクアップの遅延"
 ],
 "Link watch": [
  null,
  "リンクの監視"
 ],
 "Listen port": [
  null,
  "リッスンポート"
 ],
 "Listen port must be a number": [
  null,
  "リッスンポートは数値である必要があります"
 ],
 "Load balancing": [
  null,
  "ロードバランシング"
 ],
 "Loading system modifications...": [
  null,
  "システム変更をロード中..."
 ],
 "Log in": [
  null,
  "ログイン"
 ],
 "Log in to $0": [
  null,
  "$0 へのログイン"
 ],
 "Log messages": [
  null,
  "ログメッセージ"
 ],
 "Login failed": [
  null,
  "ログインが失敗しました"
 ],
 "Low profile desktop": [
  null,
  "低プロファイルデスクトップ"
 ],
 "Lunch box": [
  null,
  "ランチボックス"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "MII (recommended)": [
  null,
  "MII (推奨)"
 ],
 "MTU": [
  null,
  "MTU"
 ],
 "MTU must be a positive number": [
  null,
  "MTU は正の数値である必要があります"
 ],
 "Main server chassis": [
  null,
  "メインサーバーシャーシ"
 ],
 "Manage storage": [
  null,
  "ストレージの管理"
 ],
 "Managed interfaces": [
  null,
  "管理対象インターフェース"
 ],
 "Manual": [
  null,
  "手作業"
 ],
 "Manually": [
  null,
  "手動"
 ],
 "Maximum message age $max_age": [
  null,
  "メッセージ最大期間 $max_age"
 ],
 "Message to logged in users": [
  null,
  "ログインしているユーザーへのメッセージ"
 ],
 "Metric": [
  null,
  "メトリック"
 ],
 "Mini PC": [
  null,
  "ミニ PC"
 ],
 "Mini tower": [
  null,
  "ミニタワー"
 ],
 "Mode": [
  null,
  "モード"
 ],
 "Monitoring interval": [
  null,
  "監視間隔"
 ],
 "Monitoring targets": [
  null,
  "ターゲットの監視"
 ],
 "Multi-system chassis": [
  null,
  "マルチシステムシャーシ"
 ],
 "Multiple addresses can be specified using commas or spaces as delimiters.": [
  null,
  "コンマまたはスペースを区切り文字として使用すると、複数のアドレスを指定できます。"
 ],
 "NSNA ping": [
  null,
  "NSNA ping"
 ],
 "NTP server": [
  null,
  "NTP サーバー"
 ],
 "Name": [
  null,
  "名前"
 ],
 "Need at least one NTP server": [
  null,
  "少なくとも 1 つの NTP サーバーが必要です"
 ],
 "Network bond": [
  null,
  "ネットワークボンディング"
 ],
 "Network devices and graphs require NetworkManager": [
  null,
  "ネットワークデバイスおよびグラフには、NetworkManager が必要です"
 ],
 "Network logs": [
  null,
  "ネットワークログ"
 ],
 "NetworkManager is not installed": [
  null,
  "NetworkManager はインストールされていません"
 ],
 "NetworkManager is not running": [
  null,
  "NetworkManager は実行していません"
 ],
 "Networking": [
  null,
  "ネットワーキング"
 ],
 "New password was not accepted": [
  null,
  "新規パスワードは受け入れられませんでした"
 ],
 "No": [
  null,
  "いいえ"
 ],
 "No carrier": [
  null,
  "キャリアなし"
 ],
 "No delay": [
  null,
  "遅延なし"
 ],
 "No description available": [
  null,
  "利用可能な説明はありません"
 ],
 "No peers added.": [
  null,
  "ピアが追加されていません。"
 ],
 "No results found": [
  null,
  "結果が見つかりません"
 ],
 "No such file or directory": [
  null,
  "このようなファイルまたはディレクトリーがありません"
 ],
 "No system modifications": [
  null,
  "システム変更がありません"
 ],
 "None": [
  null,
  "なし"
 ],
 "Not a valid private key": [
  null,
  "有効な秘密鍵ではありません"
 ],
 "Not authorized to disable the firewall": [
  null,
  "ファイアウォールを無効にする権限がありません"
 ],
 "Not authorized to enable the firewall": [
  null,
  "ファイアウォールを有効にする権限がありません"
 ],
 "Not available": [
  null,
  "利用できません"
 ],
 "Not permitted to configure network devices": [
  null,
  "ネットワークデバイスの設定が許可されていません"
 ],
 "Not permitted to perform this action.": [
  null,
  "この動作を実行する権限がありません。"
 ],
 "Not synchronized": [
  null,
  "同期されていません"
 ],
 "Notebook": [
  null,
  "ノートブック"
 ],
 "Occurrences": [
  null,
  "発生"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Old password not accepted": [
  null,
  "古いパスワードは受け入れられません"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Cockpit がインストールされたら、\"systemctl enable --now cockpit.socket\" コマンドで有効にします。"
 ],
 "Options": [
  null,
  "オプション"
 ],
 "Other": [
  null,
  "その他"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit がクラッシュしました"
 ],
 "Parent": [
  null,
  "親"
 ],
 "Parent $parent": [
  null,
  "親 $parent"
 ],
 "Part of $0": [
  null,
  "$0 の一部"
 ],
 "Passive": [
  null,
  "パッシブ"
 ],
 "Password": [
  null,
  "パスワード"
 ],
 "Password is not acceptable": [
  null,
  "パスワードは受け入れられません"
 ],
 "Password is too weak": [
  null,
  "パスワードが弱すぎます"
 ],
 "Password not accepted": [
  null,
  "パスワードは受け入れられません"
 ],
 "Paste": [
  null,
  "貼り付け"
 ],
 "Paste error": [
  null,
  "貼り付けエラー"
 ],
 "Paste existing key": [
  null,
  "既存の鍵を貼り付けます"
 ],
 "Path cost": [
  null,
  "パスコスト"
 ],
 "Path cost $path_cost": [
  null,
  "パスコスト $path_cost"
 ],
 "Path to file": [
  null,
  "ファイルのパス"
 ],
 "Peer #$0 has invalid endpoint port. Port must be a number.": [
  null,
  "ピア #$0 に無効なエンドポイントポートがあります。ポートは数値である必要があります。"
 ],
 "Peer #$0 has invalid endpoint. It must be specified as host:port, e.g. 1.2.3.4:51820 or example.com:51820": [
  null,
  "ピア #$0 に無効なエンドポイントがあります。host:port の形式で指定する必要があります。例: 1.2.3.4:51820、example.com:51820"
 ],
 "Peers": [
  null,
  "ピア"
 ],
 "Peers are other machines that connect with this one. Public keys from other machines will be shared with each other.": [
  null,
  "ピアとは、このマシンに接続する他のマシンです。他のマシンの公開鍵が相互に共有されます。"
 ],
 "Peripheral chassis": [
  null,
  "周辺機器シャーシ"
 ],
 "Permanent": [
  null,
  "永続"
 ],
 "Pick date": [
  null,
  "日付けの選択"
 ],
 "Ping interval": [
  null,
  "Ping 間隔"
 ],
 "Ping target": [
  null,
  "Ping ターゲット"
 ],
 "Pizza box": [
  null,
  "ピザ箱"
 ],
 "Please install the $0 package": [
  null,
  "$0 パッケージをインストールしてください"
 ],
 "Portable": [
  null,
  "ポータブル"
 ],
 "Ports": [
  null,
  "ポート"
 ],
 "Prefix length": [
  null,
  "プレフィックス長"
 ],
 "Prefix length or netmask": [
  null,
  "プレフィックス長 / ネットマスク"
 ],
 "Preparing": [
  null,
  "準備中"
 ],
 "Present": [
  null,
  "存在"
 ],
 "Preserve": [
  null,
  "保存"
 ],
 "Primary": [
  null,
  "プライマリ"
 ],
 "Priority": [
  null,
  "優先度"
 ],
 "Priority $priority": [
  null,
  "優先度 $priority"
 ],
 "Private key": [
  null,
  "秘密鍵"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "ssh-add によるプロンプトがタイムアウトしました"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "ssh-keygen によるプロンプトがタイムアウトしました"
 ],
 "Public key": [
  null,
  "公開鍵"
 ],
 "Public key will be generated when a valid private key is entered": [
  null,
  "有効な秘密鍵を入力すると公開鍵が生成されます"
 ],
 "RAID chassis": [
  null,
  "RAID シャーシ"
 ],
 "Rack mount chassis": [
  null,
  "ラックマウントシャーシ"
 ],
 "Random": [
  null,
  "ランダム"
 ],
 "Range": [
  null,
  "範囲"
 ],
 "Range must be strictly ordered": [
  null,
  "範囲の順序は厳密でなければなりません"
 ],
 "Reboot": [
  null,
  "再起動"
 ],
 "Receiving": [
  null,
  "受信中"
 ],
 "Regenerate": [
  null,
  "再生成"
 ],
 "Removals:": [
  null,
  "削除:"
 ],
 "Remove $0": [
  null,
  "$0 を削除する"
 ],
 "Remove $0 service from $1 zone": [
  null,
  "$1 ゾーンから $0 サービスを削除する"
 ],
 "Remove item": [
  null,
  "アイテムの削除"
 ],
 "Remove service $0": [
  null,
  "サービス $0 を削除します"
 ],
 "Remove zone $0": [
  null,
  "ゾーン $0 を削除します"
 ],
 "Removing $0": [
  null,
  "$0 を削除中"
 ],
 "Removing $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "$0 を削除すると、サーバーへの接続が切断され、管理 UI が利用できなくなります。"
 ],
 "Removing the cockpit service might result in the web console becoming unreachable. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Cockpit サービスを削除すると、web コンソールにアクセスできなくなる可能性があります。このゾーンが現在お使いの web コンソール接続に適用されないことを確認してください。"
 ],
 "Removing the zone will remove all services within it.": [
  null,
  "ゾーンを削除すると、そのゾーン内のすべてのサービスが削除されます。"
 ],
 "Restoring connection": [
  null,
  "接続の復元"
 ],
 "Round robin": [
  null,
  "ラウンドロビン"
 ],
 "Routes": [
  null,
  "ルート"
 ],
 "Row expansion": [
  null,
  "行の拡張"
 ],
 "Row select": [
  null,
  "行の選択"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "信頼できるネットワーク経由で、またはリモートマシンで直接、次のコマンドを実行します:"
 ],
 "Runner": [
  null,
  "ランナー"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "SSH キー"
 ],
 "SSH key login": [
  null,
  "SSH 鍵ログイン"
 ],
 "STP forward delay": [
  null,
  "STP フォワード遅延"
 ],
 "STP hello time": [
  null,
  "STP Hello タイム"
 ],
 "STP maximum message age": [
  null,
  "STP メッセージ最大期間"
 ],
 "STP priority": [
  null,
  "STP 優先度"
 ],
 "Save": [
  null,
  "保存"
 ],
 "Sealed-case PC": [
  null,
  "シールドケース PC"
 ],
 "Search domain": [
  null,
  "検索ドメイン"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Security Enhanced Linux の設定とトラブルシューティング"
 ],
 "Select an option": [
  null,
  "オプションの選択"
 ],
 "Select method": [
  null,
  "メソッドの選択"
 ],
 "Sending": [
  null,
  "送信中"
 ],
 "Server": [
  null,
  "サーバー"
 ],
 "Server has closed the connection.": [
  null,
  "サーバーの接続が終了しました。"
 ],
 "Service": [
  null,
  "サービス"
 ],
 "Services": [
  null,
  "サービス"
 ],
 "Set time": [
  null,
  "時間の設定"
 ],
 "Set to": [
  null,
  "設定値"
 ],
 "Shared": [
  null,
  "共有"
 ],
 "Shell script": [
  null,
  "シェルスクリプト"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show confirmation password": [
  null,
  "確認パスワードの表示"
 ],
 "Show password": [
  null,
  "パスワードを表示する"
 ],
 "Shut down": [
  null,
  "シャットダウン"
 ],
 "Single rank": [
  null,
  "シングルランク"
 ],
 "Sorted from least to most trusted": [
  null,
  "信頼性が最も低い順から最も高い順"
 ],
 "Space-saving computer": [
  null,
  "省スペースコンピューター"
 ],
 "Spanning tree protocol": [
  null,
  "スパニング ツリープロトコル"
 ],
 "Spanning tree protocol (STP)": [
  null,
  "スパニング ツリープロトコル (STP)"
 ],
 "Specific time": [
  null,
  "特定の時間"
 ],
 "Stable": [
  null,
  "安定"
 ],
 "Start service": [
  null,
  "サービスの起動"
 ],
 "Status": [
  null,
  "ステータス"
 ],
 "Stick PC": [
  null,
  "スティッキー PC"
 ],
 "Sticky": [
  null,
  "スティッキー"
 ],
 "Storage": [
  null,
  "ストレージ"
 ],
 "Strong password": [
  null,
  "強固なパスワード"
 ],
 "Sub-Chassis": [
  null,
  "サブシャーシ"
 ],
 "Sub-Notebook": [
  null,
  "サブノート"
 ],
 "Switch off $0": [
  null,
  "$0 をオフにする"
 ],
 "Switch on $0": [
  null,
  "$0 をオンにする"
 ],
 "Switching off $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "$0 をオフにすると、サーバーへの接続が切断され、管理 UI が利用できなくなります。"
 ],
 "Switching on $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "$0 をオンにすると、サーバーへの接続が切断され、管理 UI が利用できなくなります。"
 ],
 "Synchronized": [
  null,
  "同期済み"
 ],
 "Synchronized with $0": [
  null,
  "$0 と同期済み"
 ],
 "Synchronizing": [
  null,
  "同期中"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "Tablet": [
  null,
  "タブレット"
 ],
 "Team": [
  null,
  "チーム"
 ],
 "Team port": [
  null,
  "Team ポート"
 ],
 "Team port settings": [
  null,
  "チームポート設定"
 ],
 "Testing connection": [
  null,
  "接続のテスト"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "$2 の $1 の SSH キー $0 は、$5 上の $4 の $3 ファイルに追加されます。"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH キー $0 はセッションの残りの時間に利用できるようになり、他のホストにもログインできるようになります。"
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "$0 にログインするための SSH キーはパスワードで保護され、パスワードによるログインを許可しません。$1 にキーのパスワードを指定してください。"
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "$0 にログインするための SSH キーは保護されています。ログインパスワードでログインするか、$1 で鍵のパスワードを提供することでログインできます。"
 ],
 "The cockpit service is automatically included": [
  null,
  "Cockpit サービスは自動的に含まれます"
 ],
 "The fingerprint should match:": [
  null,
  "フィンガープリントは次のものと一致する必要があります:"
 ],
 "The key password can not be empty": [
  null,
  "キーのパスワードは空にすることはできません"
 ],
 "The key passwords do not match": [
  null,
  "キーのパスワードが一致しません"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "ログインしているユーザーには、システム変更を表示する権限がありません"
 ],
 "The password can not be empty": [
  null,
  "パスワードは空にできません"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "作成されたフィンガープリントは、電子メールを含むパブリックメソッドを介して共有すると問題ありません。"
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "生成されたフィンガープリントは、メールなどのパブリックな方法で共有しても問題ありません。他の人に検証を依頼した場合、その人は任意の方法で結果を送信できます。"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "サーバーはサポートされた方法を使用した認証を拒否しました。"
 ],
 "There are no active services in this zone": [
  null,
  "このゾーンにはアクティブなサービスがありません"
 ],
 "This device cannot be managed here.": [
  null,
  "このデバイスはここで管理できません。"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "このツールは、SELinux ポリシーを設定します。また、ポリシー違反の把握と解決に役立ちます。"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "このツールは、システムがカーネルクラッシュダンプを書き込むように設定します。\"local\"（ディスク）、\"ssh\"、および \"nfs\" をターゲットとしてサポートしています。"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "このツールは、実行中のシステムから設定および診断情報のアーカイブを生成します。アーカイブは、記録や追跡の目的でローカルまたは一元的に保存することも、技術的な障害の発見やデバッグを支援するためにテクニカルサポート担当者、開発者、システム管理者に送信することもできます。"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "このツールは、ファイルシステム、LVM2 ボリュームグループ、NFS マウントなどのローカルストレージを管理します。"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "このツールは、NetworkManager と Firewalld を使用して、ボンディング、ブリッジ、チーム、VLAN、ファイアウォールなどのネットワーク設定を管理します。NetworkManager は、Ubuntu のデフォルトの systemd-networkd および Debian の ifupdown スクリプトと互換性がありません。"
 ],
 "This zone contains the cockpit service. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "このゾーンには Cockpit サービスが含まれます。このゾーンが現在の web コンソール接続に適用されないことを確認してください。"
 ],
 "Time zone": [
  null,
  "タイムゾーン"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "悪意のあるサードパーティーによって接続がインターセプトされないようにするには、ホストキーフィンガープリントを確認してください:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "フィンガープリントを確認するには、マシン上に物理的に置かれるか、信頼できるネットワークを介して $0 で次のコマンドを実行します:"
 ],
 "Toggle date picker": [
  null,
  "日付選択の切り替え"
 ],
 "Too much data": [
  null,
  "データが多すぎます"
 ],
 "Total size: $0": [
  null,
  "合計サイズ: $0"
 ],
 "Tower": [
  null,
  "タワー"
 ],
 "Transmitting": [
  null,
  "送信中"
 ],
 "Troubleshoot…": [
  null,
  "トラブルシュート…"
 ],
 "Trust and add host": [
  null,
  "ホストを信頼して追加"
 ],
 "Trust level": [
  null,
  "信頼レベル"
 ],
 "Trying to synchronize with $0": [
  null,
  "$0 との同期を試行中です"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "SSH 鍵認証を使用して $0 にログインできません。パスワードを入力してください。"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "$0 にログインできません。ホストが、パスワードログインまたは SSH キーを受け付けていません。"
 ],
 "Unexpected error": [
  null,
  "予期しないエラー"
 ],
 "Unknown": [
  null,
  "不明"
 ],
 "Unknown \"$0\"": [
  null,
  "不明な \"$0\""
 ],
 "Unknown configuration": [
  null,
  "不明な設定"
 ],
 "Unknown host: $0": [
  null,
  "不明なホスト: $0"
 ],
 "Unknown service name": [
  null,
  "不明なサービス名"
 ],
 "Unmanaged interfaces": [
  null,
  "未管理のインターフェース"
 ],
 "Untrusted host": [
  null,
  "信用できないホスト"
 ],
 "Use $0": [
  null,
  "$0 を利用"
 ],
 "VLAN": [
  null,
  "VLAN"
 ],
 "VLAN ID": [
  null,
  "VLAN ID"
 ],
 "Verify fingerprint": [
  null,
  "フィンガープリントの検証"
 ],
 "View all logs": [
  null,
  "すべてのログの表示"
 ],
 "View automation script": [
  null,
  "オートメーションスクリプトの表示"
 ],
 "Visit firewall": [
  null,
  "ファイアウォールへのアクセス"
 ],
 "Waiting": [
  null,
  "待機中"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "他のソフトウェア管理オペレーションが終了するまで待機中"
 ],
 "Weak password": [
  null,
  "脆弱なパスワード"
 ],
 "Web Console for Linux servers": [
  null,
  "Linux サーバー用 Web コンソール"
 ],
 "Will be set to \"Automatic\"": [
  null,
  "\"自動\" に設定されます"
 ],
 "WireGuard": [
  null,
  "WireGuard"
 ],
 "XOR": [
  null,
  "XOR"
 ],
 "Yes": [
  null,
  "はい"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "初めて $0 に接続しています。"
 ],
 "You are not authorized to modify the firewall.": [
  null,
  "ファイアウォールを修正する権限がありません。"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "お使いのブラウザーでは、コンテキストメニューからの貼り付けが許可されていません。Shift+Insert を使用できます。"
 ],
 "Your session has been terminated.": [
  null,
  "セッションが終了しました。"
 ],
 "Your session has expired. Please log in again.": [
  null,
  "セッションの有効期限が切れました。再度ログインしてください。"
 ],
 "Zone": [
  null,
  "ゾーン"
 ],
 "[binary data]": [
  null,
  "[バイナリーデータ]"
 ],
 "[no data]": [
  null,
  "[データなし]"
 ],
 "edit": [
  null,
  "編集"
 ],
 "in less than a minute": [
  null,
  "一分以内"
 ],
 "less than a minute ago": [
  null,
  "一分以内"
 ],
 "password quality": [
  null,
  "パスワードの強度"
 ],
 "show less": [
  null,
  "簡易表示"
 ],
 "show more": [
  null,
  "詳細表示"
 ],
 "wireguard-tools package is not installed": [
  null,
  "wireguard-tools パッケージがインストールされていません"
 ]
});
