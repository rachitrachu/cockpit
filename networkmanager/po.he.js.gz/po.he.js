cockpit.locale({
 "": {
  "plural-forms": (n) => (n == 1) ? 0 : ((n == 2) ? 1 : ((n > 10 && n % 10 == 0) ? 2 : 3)),
  "language": "he",
  "language-direction": "rtl"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 active zone": [
  null,
  "אזור פעיל",
  "שני אזורים פעילים",
  "$0 אזורים פעילים",
  "$0 אזורים פעילים"
 ],
 "$0 day": [
  null,
  "יום",
  "יומיים",
  "$0 ימים",
  "$0 ימים"
 ],
 "$0 exited with code $1": [
  null,
  "$0 הסתיים עם הקוד $1"
 ],
 "$0 failed": [
  null,
  "$0 נכשל"
 ],
 "$0 hour": [
  null,
  "שעה",
  "שעתיים",
  "$0 שעות",
  "$0 שעות"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 אינו זמין מאף מאגר."
 ],
 "$0 key changed": [
  null,
  "המפתח $0 השתנה"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 נקטל עם האות $1"
 ],
 "$0 minute": [
  null,
  "דקה",
  "$0 דקות",
  "$0 דקות",
  "$0 דקות"
 ],
 "$0 month": [
  null,
  "חודש",
  "חודשיים",
  "$0 חודשים",
  "$0 חודשים"
 ],
 "$0 week": [
  null,
  "שבוע",
  "שבועיים",
  "$0 שבועות",
  "$0 שבועות"
 ],
 "$0 will be installed.": [
  null,
  "$0 יותקן."
 ],
 "$0 year": [
  null,
  "שנה",
  "שנתיים",
  "$0 שנים",
  "$0 שנים"
 ],
 "$0 zone": [
  null,
  "אזור $0"
 ],
 "1 day": [
  null,
  "יום"
 ],
 "1 hour": [
  null,
  "שעה"
 ],
 "1 minute": [
  null,
  "דקה"
 ],
 "1 week": [
  null,
  "שבוע"
 ],
 "20 minutes": [
  null,
  "20 דקות"
 ],
 "40 minutes": [
  null,
  "40 דקות"
 ],
 "5 minutes": [
  null,
  "5 דקות"
 ],
 "6 hours": [
  null,
  "6 שעות"
 ],
 "60 minutes": [
  null,
  "60 דקות"
 ],
 "802.3ad": [
  null,
  "802.3ad"
 ],
 "802.3ad LACP": [
  null,
  "802.3ad LACP"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "לא מותקנת גרסה תואמת של Cockpit ב־$0."
 ],
 "A network bond combines multiple network interfaces into one logical interface with higher throughput or redundancy.": [
  null,
  "מאגד רשת משלב מספר מנשקי רשת למנשק לוגי אחד עם קצב העברה גבוה יותר או יתירות."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "מפתח SSH חדש תחת $0 ייווצר עבור $1 על גבי $2 והוא יתווסף לקובץ $3 של $4 על גבי $5."
 ],
 "ARP": [
  null,
  "ARP"
 ],
 "ARP monitoring": [
  null,
  "מעקב אחר ARP"
 ],
 "ARP ping": [
  null,
  "פינג ARP"
 ],
 "Absent": [
  null,
  "חסר"
 ],
 "Acceptable password": [
  null,
  "סיסמה מקובלת"
 ],
 "Active": [
  null,
  "פעיל"
 ],
 "Active backup": [
  null,
  "גיבוי פעיל"
 ],
 "Adaptive load balancing": [
  null,
  "איזון עומס מסתגל"
 ],
 "Adaptive transmit load balancing": [
  null,
  "איזון עומס העברה מסתגל"
 ],
 "Add": [
  null,
  "הוספה"
 ],
 "Add $0": [
  null,
  "הוספת $0"
 ],
 "Add DNS server": [
  null,
  "הוספת שרת DNS"
 ],
 "Add VLAN": [
  null,
  "הוספת VLAN"
 ],
 "Add VPN": [
  null,
  "הוספת VPN"
 ],
 "Add WireGuard VPN": [
  null,
  "הוספת VPN מסוג WireGuard"
 ],
 "Add a new zone": [
  null,
  "הוספת אזור חדש"
 ],
 "Add address": [
  null,
  "הוספת כתובת"
 ],
 "Add bond": [
  null,
  "הוספת מאגד"
 ],
 "Add bridge": [
  null,
  "הוספת גשר"
 ],
 "Add member": [
  null,
  "הוספת חבר"
 ],
 "Add new zone": [
  null,
  "הוספת אזור חדש"
 ],
 "Add peer": [
  null,
  "הוספת עמית"
 ],
 "Add ports": [
  null,
  "הוספת פתחות"
 ],
 "Add ports to $0 zone": [
  null,
  "הוספת פתחות לאזור $0"
 ],
 "Add route": [
  null,
  "הוספת נתיב"
 ],
 "Add search domain": [
  null,
  "הוספת שם תחום לחיפוש"
 ],
 "Add services": [
  null,
  "הוספת שירותים"
 ],
 "Add services to $0 zone": [
  null,
  "הוספת שירותים לאזור $0"
 ],
 "Add services to zone $0": [
  null,
  "הוספת שירותים לאזור $0"
 ],
 "Add team": [
  null,
  "הוספת צוות"
 ],
 "Add zone": [
  null,
  "הוספת אזור"
 ],
 "Adding $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "הוספת $0 תקטע את החיבור לשרת ותגרום לכך שמנשק הניהול לא יהיה זמין."
 ],
 "Adding custom ports will reload firewalld. A reload will result in the loss of any runtime-only configuration!": [
  null,
  "הוספת פתחות מותאמות אישית תטען מחדש את firewalld. טעינה מחדש תגרום לאבדן של הגדרות שנקבעו לזמן הריצה בלבד!"
 ],
 "Additional DNS $val": [
  null,
  "$val נוסף ב־DNS"
 ],
 "Additional DNS search domains $val": [
  null,
  "חיפוש שמות תחום DNS נוספים $val"
 ],
 "Additional address $val": [
  null,
  "כתובת נוספת $val"
 ],
 "Additional packages:": [
  null,
  "חבילות נוספות:"
 ],
 "Additional ports": [
  null,
  "פתחות נוספות"
 ],
 "Address": [
  null,
  "כתובת"
 ],
 "Address $val": [
  null,
  "כתובת $val"
 ],
 "Addresses": [
  null,
  "כתובות"
 ],
 "Addresses are not formatted correctly": [
  null,
  "הכתובות אינן בתבנית נכונה"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "ניהול עם המסוף המקוון Cockpit"
 ],
 "Advanced TCA": [
  null,
  "TCA מתקדם"
 ],
 "All-in-one": [
  null,
  "אול אין ואן"
 ],
 "Allowed IPs": [
  null,
  "כתובות IP מורשות"
 ],
 "Allowed addresses": [
  null,
  "כתובות מורשות"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "תיעוד תפקידים של Ansible"
 ],
 "Authenticating": [
  null,
  "מתבצע אימות"
 ],
 "Authentication": [
  null,
  "אימות"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "נדרש אימות כדי לבצע משימות שדורשות השראה עם המסוף המקוון Cockpit"
 ],
 "Authorize SSH key": [
  null,
  "אישור מפתח SSH"
 ],
 "Automatic": [
  null,
  "אוטומטית"
 ],
 "Automatic (DHCP only)": [
  null,
  "אוטומטית (DHCP בלבד)"
 ],
 "Automatically using NTP": [
  null,
  "אוטומטית באמצעות NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "אוטומטית באמצעות שרתי NTP נוספים"
 ],
 "Automatically using specific NTP servers": [
  null,
  "אוטומטית באמצעות שרתי NTP מסוימים"
 ],
 "Automation script": [
  null,
  "סקריפט אוטומטי"
 ],
 "Balancer": [
  null,
  "מאזן"
 ],
 "Blade": [
  null,
  "בלייד"
 ],
 "Blade enclosure": [
  null,
  "אריזת בלייד"
 ],
 "Bond": [
  null,
  "מאגד"
 ],
 "Bridge": [
  null,
  "גשר"
 ],
 "Bridge port": [
  null,
  "פתחת גשר"
 ],
 "Bridge port settings": [
  null,
  "הגדרות פתחת גשר"
 ],
 "Broadcast": [
  null,
  "שידור"
 ],
 "Broken configuration": [
  null,
  "הגדרות פגומות"
 ],
 "Bus expansion chassis": [
  null,
  "שלדת הרחבת אפיקים"
 ],
 "Cancel": [
  null,
  "ביטול"
 ],
 "Cannot forward login credentials": [
  null,
  "לא ניתן להעביר פרטי גישה"
 ],
 "Cannot schedule event in the past": [
  null,
  "לא ניתן לתזמן אירוע לעבר"
 ],
 "Carrier": [
  null,
  "ספקית"
 ],
 "Change": [
  null,
  "החלפה"
 ],
 "Change system time": [
  null,
  "החלפת שעון המערכת"
 ],
 "Change the settings": [
  null,
  "שינוי ההגדרות"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "מפתחות שהוחלפו הם לעתים תוצאה של התקנת מערכת הפעלה מחדש. עם זאת, שינוי בלתי צפוי עשוי להעיד שגורם צד־שלישי מנסה ליירט את החיבור שלך."
 ],
 "Changing the settings will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "שינוי ההגדרות יפגע בחיבור לשרת וימנע את הגישה למנשק הניהול."
 ],
 "Checking IP": [
  null,
  "ה־IP נבדק"
 ],
 "Checking installed software": [
  null,
  "התכנה שמותקנת נבדקת"
 ],
 "Clear input value": [
  null,
  "מחיקת ערך קלט"
 ],
 "Close": [
  null,
  "סגירה"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "ההגדרות של Cockpit ל־NetworkManager ול־Firewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "ל־Cockpit אין אפשרות ליצור קשר עם המארח שסופק."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit הוא מנהל שרתים שמקל על ניהול שרתי הלינוקס שלך דרך הדפדפן. מעבר חטוף בין המסוף והכלי המקוון הוא פשוט וקל. שירות שהופעל דרך Cockpit ניתן לעצור דרך המסוף. באותו האופן, אם מתרחשת שגיאה במסוף ניתן לצפות בה במנשק היומן של Cockpit."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit אינו תואם לתכנה שרצה על המערכת."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit אינו מותקן"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit אינו מותקן על המערכת."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit הוא מושלם למנהלי מערכות מתחילים, מאפשר להם לבצע משימות פשוטות בקלות כגון ניהול אחסון, חקירת יומנים והפעלה ועצירה של שירותים. ניתן לנהל ולעקוב אחר מספר שרתים בו־זמנית. כל שעליך לעשות הוא להוסיף אותם בלחיצה בודדת והמכונות שלך תדאגנה לחברותיהן."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "איסוף ואריזה של נתוני ניתוח ותמיכה"
 ],
 "Collect kernel crash dumps": [
  null,
  "איסוף היטלי קריסת ליבה"
 ],
 "Comma-separated ports, ranges, and services are accepted": [
  null,
  "פתחות, טווחים ושירותים מופרדים בפסיקים יתקבלו"
 ],
 "Compact PCI": [
  null,
  "PCI חסכוני"
 ],
 "Configuring": [
  null,
  "מתבצעת הגדרה"
 ],
 "Configuring IP": [
  null,
  "מוגדרת כתובת IP"
 ],
 "Confirm key password": [
  null,
  "אישור סיסמת מפתח"
 ],
 "Confirm removal of $0": [
  null,
  "אישור הסרת $0"
 ],
 "Connect automatically": [
  null,
  "התחברות אוטומטית"
 ],
 "Connection has timed out.": [
  null,
  "הזמן שהוקצב להתחברות תם."
 ],
 "Connection will be lost": [
  null,
  "החיבור יאבד"
 ],
 "Convertible": [
  null,
  "מתהפך"
 ],
 "Copied": [
  null,
  "הועתק"
 ],
 "Copy": [
  null,
  "העתקה"
 ],
 "Copy to clipboard": [
  null,
  "העתקה ללוח הגזירים"
 ],
 "Create $0": [
  null,
  "יצירת $0"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "ליצור מפתח SSH חדש ולאשר אותו"
 ],
 "Create it": [
  null,
  "ליצור אותו"
 ],
 "Create new task file with this content.": [
  null,
  "יצירת קובץ משימה עם התוכן הזה."
 ],
 "Creating this $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "יצירת ה־$0 הזה תקטע את החיבור לשרת ותמנע את הגישה למנשק הניהול."
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Custom ports": [
  null,
  "פתחות מותאמות אישית"
 ],
 "Custom zones": [
  null,
  "אזורים מותאמים אישית"
 ],
 "DNS": [
  null,
  "DNS"
 ],
 "DNS $val": [
  null,
  "DNS $val"
 ],
 "DNS search domains": [
  null,
  "חיפוש שמות תחום DNS"
 ],
 "DNS search domains $val": [
  null,
  "חיפוש שמות תחום DNS‏ $val"
 ],
 "Deactivating": [
  null,
  "מתבצעת השבתה"
 ],
 "Delay": [
  null,
  "השהיה"
 ],
 "Delete": [
  null,
  "מחיקה"
 ],
 "Delete $0": [
  null,
  "מחיקת $0"
 ],
 "Deleting $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "מחיקת $0 תקטע את החיבור לשרת ותמנע את הגישה למנשק הניהול."
 ],
 "Description": [
  null,
  "תיאור"
 ],
 "Desktop": [
  null,
  "שולחן עבודה"
 ],
 "Detachable": [
  null,
  "נתיק"
 ],
 "Diagnostic reports": [
  null,
  "דוחות אבחון"
 ],
 "Disable the firewall": [
  null,
  "השבתת חומת האש"
 ],
 "Disabled": [
  null,
  "מושבת"
 ],
 "Docking station": [
  null,
  "תחנת עגינה"
 ],
 "Downloading $0": [
  null,
  "$0 בהורדה"
 ],
 "Dual rank": [
  null,
  "דו־צדדי"
 ],
 "Edit": [
  null,
  "עריכה"
 ],
 "Edit VLAN settings": [
  null,
  "עריכת הגדרות VLAN"
 ],
 "Edit WireGuard VPN": [
  null,
  "עריכת VPN מסוג VPN"
 ],
 "Edit bond settings": [
  null,
  "עריכת הגדרות מאגד"
 ],
 "Edit bridge settings": [
  null,
  "עריכת הגדרות גשר"
 ],
 "Edit custom service in $0 zone": [
  null,
  "עריכת שירות משלך באזור $0"
 ],
 "Edit rules and zones": [
  null,
  "עריכת כללים ואזורים"
 ],
 "Edit service": [
  null,
  "עריכת שירות"
 ],
 "Edit service $0": [
  null,
  "עריכת השירות $0"
 ],
 "Edit team settings": [
  null,
  "עריכת הגדרות ציוות"
 ],
 "Embedded PC": [
  null,
  "מחשב משובץ"
 ],
 "Enable or disable the device": [
  null,
  "להפעיל או להשבית את ההתקן"
 ],
 "Enable service": [
  null,
  "הפעלת שירות"
 ],
 "Enable the firewall": [
  null,
  "הפעלת חומת האש"
 ],
 "Enabled": [
  null,
  "מופעל"
 ],
 "Endpoint": [
  null,
  "נקודת קצה"
 ],
 "Endpoint acting as a \"server\" need to be specified as host:port, otherwise it can be left empty.": [
  null,
  "נקודת קצה שמתנהגת כ„שרת” צריך לציין בתור מארח:פתחה (host:port), אחרת אפשר להשאיר ריק."
 ],
 "Enter a valid MAC address": [
  null,
  "נא למלא כתובת MAC תקנית"
 ],
 "Entire subnet": [
  null,
  "כל תת־הרשת"
 ],
 "Ethernet MAC": [
  null,
  "כתובת חומרת אתרנט"
 ],
 "Ethernet MTU": [
  null,
  "יחידת העברה מרבית של אתרנט"
 ],
 "Ethtool": [
  null,
  "Ethtool"
 ],
 "Example: 22,ssh,8080,5900-5910": [
  null,
  "לדוגמה: 22,ssh,8080,5900-5910"
 ],
 "Example: 88,2019,nfs,rsync": [
  null,
  "לדוגמה: 88,2019,nfs,rsync"
 ],
 "Excellent password": [
  null,
  "סיסמה מצוינת"
 ],
 "Expansion chassis": [
  null,
  "שלדת הרחבה"
 ],
 "Failed": [
  null,
  "נכשל"
 ],
 "Failed to add port": [
  null,
  "הוספת הפתחה נכשלה"
 ],
 "Failed to add service": [
  null,
  "הוספת השירות נכשל"
 ],
 "Failed to add zone": [
  null,
  "הוספת האזור נכשלה"
 ],
 "Failed to change password": [
  null,
  "החלפת הסיסמה נכשלה"
 ],
 "Failed to edit service": [
  null,
  "עריכת השירות נכשלה"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "הפעלת $0 ב־firewalld נכשלה"
 ],
 "Failed to save settings": [
  null,
  "שמירת ההגדרות נכשלה"
 ],
 "Filter services": [
  null,
  "סינון שירותים"
 ],
 "Firewall": [
  null,
  "חומת אש"
 ],
 "Firewall is not available": [
  null,
  "חומת האש אינה זמינה"
 ],
 "Forward delay $forward_delay": [
  null,
  "השהיית העברה $forward_delay"
 ],
 "Gateway": [
  null,
  "שער גישה"
 ],
 "General": [
  null,
  "כללי"
 ],
 "Generated": [
  null,
  "נוצר"
 ],
 "Go to now": [
  null,
  "לעבור כעת"
 ],
 "Group": [
  null,
  "קבוצה"
 ],
 "Hair pin mode": [
  null,
  "מצב סיכת שיער"
 ],
 "Hairpin mode": [
  null,
  "מצב סיכת שיער"
 ],
 "Handheld": [
  null,
  "נישא"
 ],
 "Hello time $hello_time": [
  null,
  "זמן Hello‏ $hello_time"
 ],
 "Hide confirmation password": [
  null,
  "הסתרת סיסמת האישור"
 ],
 "Hide password": [
  null,
  "הסתרת הסיסמה"
 ],
 "Host key is incorrect": [
  null,
  "מפתח המארח שגוי"
 ],
 "ID": [
  null,
  "מזהה"
 ],
 "ID $id": [
  null,
  "מזהה $id"
 ],
 "IP address": [
  null,
  "כתובת IP"
 ],
 "IP address with routing prefix. Separate multiple values with a comma. Example: 192.0.2.0/24, 2001:db8::/32": [
  null,
  "כתובת IP עם קידומת ניתוב. יש להפריד בין ערכים בפסיק. למשל: 192.0.2.0/24, ‎2001:db8::/32"
 ],
 "IPv4": [
  null,
  "IPv4"
 ],
 "IPv4 addresses": [
  null,
  "כתובות IPv4"
 ],
 "IPv4 settings": [
  null,
  "הגדרות IPv4"
 ],
 "IPv6": [
  null,
  "IPv6"
 ],
 "IPv6 settings": [
  null,
  "הגדרות IPv6"
 ],
 "If left empty, ID will be generated based on associated port services and port numbers": [
  null,
  "אם השדה נשאר ריק, המזהה יווצר אוטומטית על בסיס השירותים על הפתחה המשויכת ומספרי הפתחות"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "אם טביעת האצבע תואמת, יש ללחוץ על ‚מתן אמון והוספת מארח’. אחרת, לא להתחבר וליצור קשר עם הנהלת המערכת."
 ],
 "Ignore": [
  null,
  "התעלמות"
 ],
 "Inactive": [
  null,
  "לא פעיל"
 ],
 "Included services": [
  null,
  "שירותים כלולים"
 ],
 "Incoming requests are blocked by default. Outgoing requests are not blocked.": [
  null,
  "בקשות נכנסות נחסמות כברירת מחדל. בקשות יוצאות לא נחסמות."
 ],
 "Install": [
  null,
  "התקנה"
 ],
 "Install software": [
  null,
  "התקנת תכנה"
 ],
 "Installing $0": [
  null,
  "$0 בהתקנה"
 ],
 "Interface": [
  null,
  "מנשק",
  "מנשקים",
  "מנשקים",
  "מנשקים"
 ],
 "Interface members": [
  null,
  "חברים במנשק"
 ],
 "Interfaces": [
  null,
  "מנשקים"
 ],
 "Internal error": [
  null,
  "שגיאה פנימה"
 ],
 "Invalid address $0": [
  null,
  "כתובת שגויה $0"
 ],
 "Invalid date format": [
  null,
  "מבנה התאריך שגוי"
 ],
 "Invalid date format and invalid time format": [
  null,
  "מבנה תאריך שגוי ומבנה שעה שגוי"
 ],
 "Invalid file permissions": [
  null,
  "הרשאות הקובץ שגויות"
 ],
 "Invalid metric $0": [
  null,
  "מדד שגוי $0"
 ],
 "Invalid port number": [
  null,
  "מספר הפתחה שגוי"
 ],
 "Invalid prefix $0": [
  null,
  "קידומת שגויה $0"
 ],
 "Invalid prefix or netmask $0": [
  null,
  "קידומת או מסכת רשת שגויה $0"
 ],
 "Invalid range": [
  null,
  "טווח שגוי"
 ],
 "Invalid time format": [
  null,
  "מבנה השעה שגוי"
 ],
 "Invalid timezone": [
  null,
  "אזור זמן שגוי"
 ],
 "IoT gateway": [
  null,
  "שער גישה IoT"
 ],
 "Keep connection": [
  null,
  "לשמור על החיבור"
 ],
 "Kernel dump": [
  null,
  "היטל ליבה"
 ],
 "Key password": [
  null,
  "סיסמת מפתח"
 ],
 "LACP key": [
  null,
  "מפתח LACP"
 ],
 "Laptop": [
  null,
  "מחשב נייד"
 ],
 "Learn more": [
  null,
  "מידע נוסף"
 ],
 "Link down delay": [
  null,
  "השהיית קטיעת קישור"
 ],
 "Link local": [
  null,
  "קישור מקומי"
 ],
 "Link monitoring": [
  null,
  "מעקב אחר קישורים"
 ],
 "Link up delay": [
  null,
  "השהיית חיבור קישור"
 ],
 "Link watch": [
  null,
  "עקיבה אחר קישורים"
 ],
 "Listen port": [
  null,
  "פתחת האזנה"
 ],
 "Listen port must be a number": [
  null,
  "פתחת ההאזנה חייבת להיות מספר"
 ],
 "Load balancing": [
  null,
  "איזון עומס"
 ],
 "Loading system modifications...": [
  null,
  "השינויים למערכת נטענים…"
 ],
 "Log in": [
  null,
  "כניסה"
 ],
 "Log in to $0": [
  null,
  "כניסה אל $0"
 ],
 "Log messages": [
  null,
  "הודעות יומן"
 ],
 "Login failed": [
  null,
  "הכניסה נכשלה"
 ],
 "Low profile desktop": [
  null,
  "מחשב שולחני עם פרופיל נמוך"
 ],
 "Lunch box": [
  null,
  "קופסת אוכל"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "MII (recommended)": [
  null,
  "MII (מומלץ)"
 ],
 "MTU": [
  null,
  "MTU"
 ],
 "MTU must be a positive number": [
  null,
  "MTU חייב להיות מספר חיובי"
 ],
 "Main server chassis": [
  null,
  "שלדת שרת ראשית"
 ],
 "Manage storage": [
  null,
  "ניהול אחסון"
 ],
 "Managed interfaces": [
  null,
  "מנשקים מנוהלים"
 ],
 "Manual": [
  null,
  "ידני"
 ],
 "Manually": [
  null,
  "ידנית"
 ],
 "Maximum message age $max_age": [
  null,
  "גיל הודעה מרבי $max_age"
 ],
 "Message to logged in users": [
  null,
  "הודעה למשתמשים שנמצאים במערכת"
 ],
 "Metric": [
  null,
  "מדד (עדיפות)"
 ],
 "Mini PC": [
  null,
  "מחשב מוקטן"
 ],
 "Mini tower": [
  null,
  "מארז מוקטן"
 ],
 "Mode": [
  null,
  "מצב"
 ],
 "Monitoring interval": [
  null,
  "הפרש בין דגימות מעקב"
 ],
 "Monitoring targets": [
  null,
  "יעדי מעקב"
 ],
 "Multi-system chassis": [
  null,
  "שלדה למגוון מערכות"
 ],
 "Multiple addresses can be specified using commas or spaces as delimiters.": [
  null,
  ""
 ],
 "NSNA ping": [
  null,
  "פינג מסוג NSNA"
 ],
 "NTP server": [
  null,
  "שרת NTP"
 ],
 "Name": [
  null,
  "שם"
 ],
 "Need at least one NTP server": [
  null,
  "נדרש שרת NTP אחד לפחות"
 ],
 "Network bond": [
  null,
  "מאגד רשת"
 ],
 "Network devices and graphs require NetworkManager": [
  null,
  "התקני רשת ותרשימים דורשים NetworkManager"
 ],
 "Network logs": [
  null,
  "יומני תקשורת"
 ],
 "NetworkManager is not installed": [
  null,
  "NetworkManager אינו מותקן"
 ],
 "NetworkManager is not running": [
  null,
  "NetworkManager אינו פעיל"
 ],
 "Networking": [
  null,
  "תקשורת"
 ],
 "New password was not accepted": [
  null,
  "הסיסמה החדשה לא התקבלה"
 ],
 "No": [
  null,
  "לא"
 ],
 "No carrier": [
  null,
  "אין ספקית"
 ],
 "No delay": [
  null,
  "אין השהיה"
 ],
 "No description available": [
  null,
  "אין תיאור זמין"
 ],
 "No peers added.": [
  null,
  "לא נוספו עמיתים."
 ],
 "No results found": [
  null,
  "לא נמצאו תוצאות"
 ],
 "No such file or directory": [
  null,
  "אין קובץ או תיקייה בשם הזה"
 ],
 "No system modifications": [
  null,
  "אין שינויים במערכת"
 ],
 "None": [
  null,
  "אין"
 ],
 "Not a valid private key": [
  null,
  "לא מפתח פרטי תקני"
 ],
 "Not authorized to disable the firewall": [
  null,
  "לא מורשה להשבית את חומת האש"
 ],
 "Not authorized to enable the firewall": [
  null,
  "לא מורשה להפעיל את חומת האש"
 ],
 "Not available": [
  null,
  "לא זמין"
 ],
 "Not permitted to configure network devices": [
  null,
  "אין הקשה להגדיר התקני רשת"
 ],
 "Not permitted to perform this action.": [
  null,
  "לא מורשה לבצע את הפעולה הזאת."
 ],
 "Not synchronized": [
  null,
  "לא מסונכרן"
 ],
 "Notebook": [
  null,
  "מחברת"
 ],
 "Occurrences": [
  null,
  "מופעים"
 ],
 "Ok": [
  null,
  "אישור"
 ],
 "Old password not accepted": [
  null,
  "הסיסמה הישנה לא התקבלה"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "לאחר התקנת Cockpit, יש להפעיל את השירות בעזרת „systemctl enable --now cockpit.socket”."
 ],
 "Options": [
  null,
  "אפשרויות"
 ],
 "Other": [
  null,
  "אחר"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit קרס"
 ],
 "Parent": [
  null,
  "הורה"
 ],
 "Parent $parent": [
  null,
  "$parent הורה"
 ],
 "Part of $0": [
  null,
  "חלק מתוך $0"
 ],
 "Passive": [
  null,
  "סביל"
 ],
 "Password": [
  null,
  "סיסמה"
 ],
 "Password is not acceptable": [
  null,
  "הסיסמה לא מקובלת"
 ],
 "Password is too weak": [
  null,
  "הסיסמה חלשה מדי"
 ],
 "Password not accepted": [
  null,
  "הסיסמה לא התקבלה"
 ],
 "Paste": [
  null,
  "הדבקה"
 ],
 "Paste error": [
  null,
  "שגיאת הדבקה"
 ],
 "Paste existing key": [
  null,
  "הדבקת מפתח קיים"
 ],
 "Path cost": [
  null,
  "עלות נתיב"
 ],
 "Path cost $path_cost": [
  null,
  "עלות הנתיב $path_cost"
 ],
 "Path to file": [
  null,
  "הנתיב לקובץ"
 ],
 "Peer #$0 has invalid endpoint port. Port must be a number.": [
  null,
  ""
 ],
 "Peer #$0 has invalid endpoint. It must be specified as host:port, e.g. 1.2.3.4:51820 or example.com:51820": [
  null,
  ""
 ],
 "Peers": [
  null,
  "עמיתים"
 ],
 "Peers are other machines that connect with this one. Public keys from other machines will be shared with each other.": [
  null,
  ""
 ],
 "Peripheral chassis": [
  null,
  "שלדת התקנים חיצוניים"
 ],
 "Permanent": [
  null,
  "קבוע"
 ],
 "Pick date": [
  null,
  "בחירת תאריך"
 ],
 "Ping interval": [
  null,
  "הפרש בין פינגים"
 ],
 "Ping target": [
  null,
  "יעד פינג"
 ],
 "Pizza box": [
  null,
  "קופסת פיצה"
 ],
 "Please install the $0 package": [
  null,
  "נא להתקין את החבילה $0"
 ],
 "Portable": [
  null,
  "נייד"
 ],
 "Ports": [
  null,
  "פתחות"
 ],
 "Prefix length": [
  null,
  "אורך קידומת"
 ],
 "Prefix length or netmask": [
  null,
  "אורך קידומת או מסכת רשת"
 ],
 "Preparing": [
  null,
  "בהכנה"
 ],
 "Present": [
  null,
  "נוכחי"
 ],
 "Preserve": [
  null,
  "שימור"
 ],
 "Primary": [
  null,
  "עיקרי"
 ],
 "Priority": [
  null,
  "עדיפות"
 ],
 "Priority $priority": [
  null,
  "עדיפות $priority"
 ],
 "Private key": [
  null,
  "מפתח פרטי"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "משך הצגת הבקשה דרך ssh-add תם"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "משך הצגת הבקשה דרך ssh-keygen תם"
 ],
 "Public key": [
  null,
  "מפתח ציבורי"
 ],
 "Public key will be generated when a valid private key is entered": [
  null,
  ""
 ],
 "RAID chassis": [
  null,
  "שלדת RAID"
 ],
 "Rack mount chassis": [
  null,
  "שלדת מעגן מתלה (Rack)"
 ],
 "Random": [
  null,
  "אקראי"
 ],
 "Range": [
  null,
  "טווח"
 ],
 "Range must be strictly ordered": [
  null,
  "הטווח חייב להיות מסודר בקפידה"
 ],
 "Reboot": [
  null,
  "הפעלה מחדש"
 ],
 "Receiving": [
  null,
  "קבלה"
 ],
 "Removals:": [
  null,
  "הסרות:"
 ],
 "Remove $0": [
  null,
  "הסרת $0"
 ],
 "Remove $0 service from $1 zone": [
  null,
  "הסרת השירות $0 מהאזור $1"
 ],
 "Remove item": [
  null,
  "הסרת פריט"
 ],
 "Remove service $0": [
  null,
  "הסרת השירות $0"
 ],
 "Remove zone $0": [
  null,
  "הסרת האזור $0"
 ],
 "Removing $0": [
  null,
  "$0 בהסרה"
 ],
 "Removing $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "הסרת $0 תקטע את החיבור לשרת ותמנע את הגישה למנשק הניהול."
 ],
 "Removing the cockpit service might result in the web console becoming unreachable. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "הסרת השירות cockpit עלול לגרום לקטיעת שירות המסוף המקוון. נא לוודא שאזור זה אינו חל על חיבור המסוף המקוון הנוכחי שלך."
 ],
 "Removing the zone will remove all services within it.": [
  null,
  "הסרת האזור תסיר את כל השירותים שבו."
 ],
 "Restoring connection": [
  null,
  "החיבור משוחזר"
 ],
 "Round robin": [
  null,
  "ראונד-רובין"
 ],
 "Routes": [
  null,
  "ניתובים"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  ""
 ],
 "Runner": [
  null,
  "שליח"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "מפתח SSH"
 ],
 "STP forward delay": [
  null,
  "השהיית העברת STP"
 ],
 "STP hello time": [
  null,
  "זמן Hello של STP"
 ],
 "STP maximum message age": [
  null,
  "גיל ההודעה המרבי של STP"
 ],
 "STP priority": [
  null,
  "עדיפות STP"
 ],
 "Save": [
  null,
  "שמירה"
 ],
 "Sealed-case PC": [
  null,
  "מחשב במארז אטום"
 ],
 "Search domain": [
  null,
  "שם תחום לחיפוש"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "הגדרות ופתרון תקלות של Security Enhanced Linux"
 ],
 "Select method": [
  null,
  "בחירת שיטה"
 ],
 "Sending": [
  null,
  "שליחה"
 ],
 "Server": [
  null,
  "שרת"
 ],
 "Server has closed the connection.": [
  null,
  "השרת סגר את החיבור."
 ],
 "Service": [
  null,
  "שירות"
 ],
 "Services": [
  null,
  "שירותים"
 ],
 "Set time": [
  null,
  "הגדרת שעה"
 ],
 "Set to": [
  null,
  "הגדרה לכדי"
 ],
 "Shared": [
  null,
  "משותף"
 ],
 "Shell script": [
  null,
  "סקריפט מעטפת"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show password": [
  null,
  "הצגת הסיסמה"
 ],
 "Shut down": [
  null,
  "כיבוי"
 ],
 "Single rank": [
  null,
  "שורה אחת"
 ],
 "Sorted from least to most trusted": [
  null,
  "מסודר מהכי מהימן להכי פחות"
 ],
 "Space-saving computer": [
  null,
  "מחשב חסכוני במקום"
 ],
 "Spanning tree protocol": [
  null,
  "פרוטוקול העץ הפורש"
 ],
 "Spanning tree protocol (STP)": [
  null,
  "פרוטוקול העץ הפורש (STP)"
 ],
 "Specific time": [
  null,
  "זמן מסוים"
 ],
 "Stable": [
  null,
  "יציב"
 ],
 "Start service": [
  null,
  "התחלת שירות"
 ],
 "Status": [
  null,
  "מצב"
 ],
 "Stick PC": [
  null,
  "מחשב מקלון"
 ],
 "Sticky": [
  null,
  "דביק"
 ],
 "Storage": [
  null,
  "אחסון"
 ],
 "Sub-Chassis": [
  null,
  "תת שלדה"
 ],
 "Sub-Notebook": [
  null,
  "תת מחברת"
 ],
 "Switch off $0": [
  null,
  "כיבוי $0"
 ],
 "Switch on $0": [
  null,
  "הדלקת $0"
 ],
 "Switching off $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "כיבוי $0 יקטע את החיבור לשרת וגרום לכך שמנשק הניהול לא יהיה זמין."
 ],
 "Switching on $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "הפעלת $0 תקטע את החיבור לשרת ותגרום לכך שמנשק הניהול לא יהיה זמין."
 ],
 "Synchronized": [
  null,
  "מסונכרן"
 ],
 "Synchronized with $0": [
  null,
  "מסונכרן עם $0"
 ],
 "Synchronizing": [
  null,
  "מתבצע סנכרון"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "Tablet": [
  null,
  "מחשב לוח"
 ],
 "Team": [
  null,
  "ציוות"
 ],
 "Team port": [
  null,
  "פתחת ציוות"
 ],
 "Team port settings": [
  null,
  "הגדרות פתחת ציוות"
 ],
 "Testing connection": [
  null,
  "החיבור נבדק"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "מפתח ה־SSH‏ $0 של $1 על גבי $2 יתווסף לקובץ $3 של $4 על גבי $5."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "מפתח ה־SSH‏ $0 יהפוך לזמין עד ליציאה מהמערכת ויהיה זמין לכניסה למארחים אחרים גם כן."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "מפתח ה־SSH לכניסה אל $0 מוגן בסיסמה, והמארח לא מרשה להיכנס למערכת עם סיסמה. נא לספק את הסיסמה למפתח שב־$1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "מפתח ה־SSH לכניסה אל $0 מוגן. יש לך אפשרות להיכנס עם שם המשתמש והסיסמה שלך או על ידי אספקת הסיסמה למפתח שב־$1."
 ],
 "The cockpit service is automatically included": [
  null,
  "שירות ה־cockpit נכלל אוטומטית"
 ],
 "The fingerprint should match:": [
  null,
  "טביעת האצבע אמורה להיות תואמת:"
 ],
 "The key password can not be empty": [
  null,
  "סיסמת המפתח לא יכולה להישאר ריקה"
 ],
 "The key passwords do not match": [
  null,
  "סיסמאות המפתח אינן תואמות"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "המשתמש הנוכחי שנכנס למערכת אינו מורשה לצפות בשינויים שבוצעו במערכת"
 ],
 "The password can not be empty": [
  null,
  "סיסמת המפתח לא יכולה להישאר ריקה"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "זה בסדר לשתף את טביעת האצבע באופן ציבורי, לרבות בדוא״ל."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  ""
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "השרת סירב לאמת בעזרת השיטות הנתמכות."
 ],
 "There are no active services in this zone": [
  null,
  "אין שירותים פעילים באזור הזה"
 ],
 "This device cannot be managed here.": [
  null,
  "לא ניתן לנהל את ההתקן הזה כאן."
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "הכלי הזה מגדיר את המדיניות של SELinux ויכול לסייע והבנת ופתרון הפרות של המדיניות."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "כלי זה מייצר ארכיון של הגדרות ופרטי ניתוח של המערכת. אפשר לאחסן את הארכיון מקומית או באופן מרכזי למטרות תיעוד או מעקב או לנציגי תמיכה, מתכנתים או מנהלי מערכות כדי שיוכלו לסייע באיתור תקלות טכניות וניפוי שגיאות."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "כלי זה מנהל אחסון מקומי כגון מערכות קבצים, קבוצות כרכים ב־LVM2 ועיגונים של NFS."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  ""
 ],
 "This zone contains the cockpit service. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "אזור זה מכיל את שירות ה־Cockpit. נא לוודא שאזור זה אינו חל על חיבור המסוף המקוון הנוכחי שלך."
 ],
 "Time zone": [
  null,
  "אזור זמן"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "כדי לוודא שהחיבור שלך לא מיורט על ידי גורמי צד־שלישי זדוניים, נא לאמת את טביעת האצבע של מפתח המארח:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "כדי לאמת את טביעת האצבע, יש להריץ את הפקודה הבאה על $0 במהלך ישיבה פיזית מול המכונה או דרך רשת מהימנה:"
 ],
 "Toggle date picker": [
  null,
  "החלפת מצב בורר תאריכים"
 ],
 "Too much data": [
  null,
  "יותר מדי נתונים"
 ],
 "Total size: $0": [
  null,
  "גודל כולל: $0"
 ],
 "Tower": [
  null,
  "מארז גבוה"
 ],
 "Transmitting": [
  null,
  "בהעברה"
 ],
 "Troubleshoot…": [
  null,
  "פתרון תקלות…"
 ],
 "Trust and add host": [
  null,
  "מתן אמון והוספת מארח"
 ],
 "Trust level": [
  null,
  "רמת אמון"
 ],
 "Trying to synchronize with $0": [
  null,
  "מתבצע ניסיון להסתנכרן מול $0"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "לא ניתן להיכנס אל $0 באמצעות אימות עם מפתח SSH. נא לספק את הסיסמה."
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "לא ניתן להיכנס אל $0. המארח לא מקבל כניסה עם סיסמה או אף אחד ממפתחות ה־SSH האחרים שלך."
 ],
 "Unexpected error": [
  null,
  "שגיאה בלתי צפויה"
 ],
 "Unknown": [
  null,
  "לא ידוע"
 ],
 "Unknown \"$0\"": [
  null,
  "„$0” לא ידוע"
 ],
 "Unknown configuration": [
  null,
  "הגדרות לא ידועות"
 ],
 "Unknown host: $0": [
  null,
  "מארח לא ידוע: $0"
 ],
 "Unknown service name": [
  null,
  "שם השירות לא ידוע"
 ],
 "Unmanaged interfaces": [
  null,
  "מנשקים לא מנוהלים"
 ],
 "Untrusted host": [
  null,
  "מארח בלתי מהימן"
 ],
 "VLAN": [
  null,
  "VLAN"
 ],
 "VLAN ID": [
  null,
  "מזהה VLAN"
 ],
 "View all logs": [
  null,
  "הצגת כל היומנים"
 ],
 "View automation script": [
  null,
  "הצגת סקריפט אוטומציה"
 ],
 "Visit firewall": [
  null,
  "ביקור בחומת האש"
 ],
 "Waiting": [
  null,
  "בהמתנה"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "בהמתנה לסיום פעולות ניהול תכנה אחרות"
 ],
 "Weak password": [
  null,
  "סיסמה חלשה"
 ],
 "Web Console for Linux servers": [
  null,
  "מסוף מקוון לשרתי לינוקס"
 ],
 "Will be set to \"Automatic\"": [
  null,
  "יוגדר ל„אוטומטי”"
 ],
 "WireGuard": [
  null,
  "WireGuard"
 ],
 "XOR": [
  null,
  "XOR (קסור)"
 ],
 "Yes": [
  null,
  "כן"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "זאת ההתחברות הראשונה שלך אל $0."
 ],
 "You are not authorized to modify the firewall.": [
  null,
  "אין לך הרשאה לשנות את חומת האש."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "הדפדפן שלך לא מרשה להדביק מתפריט ההקשר. אפשר להשתמש ב־Shift+Insert."
 ],
 "Your session has been terminated.": [
  null,
  "ההפעלה שלך הושמדה."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "תוקף ההפעלה שלך פג. נא להיכנס שוב."
 ],
 "Zone": [
  null,
  "אזור"
 ],
 "[binary data]": [
  null,
  "[נתונים בינריים]"
 ],
 "[no data]": [
  null,
  "[אין נתונים]"
 ],
 "edit": [
  null,
  "עריכה"
 ],
 "in less than a minute": [
  null,
  "בעוד פחות מדקה"
 ],
 "less than a minute ago": [
  null,
  "לפני פחות מדקה"
 ],
 "password quality": [
  null,
  "איכות הסיסמה"
 ],
 "show less": [
  null,
  "להציג פחות"
 ],
 "show more": [
  null,
  "להציג יותר"
 ],
 "wireguard-tools package is not installed": [
  null,
  "חבילת wireguard-tools לא מותקנת"
 ]
});
