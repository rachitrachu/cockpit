cockpit.locale({
 "": {
  "plural-forms": (n) => n==0 ? 0 : n==1 ? 1 : n==2 ? 2 : n%100>=3 && n%100<=10 ? 3 : n%100>=11 ? 4 : 5,
  "language": "ar",
  "language-direction": "rtl"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 active zone": [
  null,
  "$0 لا يوجد منطقة نشطة",
  "$0 منطقة نشطة واحدة",
  "$0 منطقتين نشطتين",
  "$0 مناطق نشطة",
  "$0 منطقة نشطة",
  "$0 منطقة نشطة"
 ],
 "$0 day": [
  null,
  "$0 ولا يوم",
  "$0 يوم واحد",
  "$0 يومان",
  "$0 أيام",
  "$0 يوما",
  "$0 يوم"
 ],
 "$0 exited with code $1": [
  null,
  "$0 خرج مع الرمز $1"
 ],
 "$0 failed": [
  null,
  "$0 فشل"
 ],
 "$0 hour": [
  null,
  "$0 ولا ساعة",
  "$0 ساعة واحدة",
  "$0 ساعتان",
  "$0 ساعات",
  "$0 ساعة",
  "$0 ساعة"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 غير متوفر في أي مستودع."
 ],
 "$0 key changed": [
  null,
  "$0 مفتاح قد تغير"
 ],
 "$0 killed with signal $1": [
  null,
  "تم إيقاف $0 بالإشارة $1"
 ],
 "$0 minute": [
  null,
  "0 دقيقة",
  "دقيقة واحدة",
  "دقيقتان",
  "$0 دقائق",
  "$0 دقيقة",
  "$0 دقيقة"
 ],
 "$0 month": [
  null,
  "$0 شهر",
  "شهر واحد",
  "شهران",
  "$0 أشهر",
  "$0 شهراً",
  "$0 شهراً"
 ],
 "$0 week": [
  null,
  "$0 لا أسابيع",
  "$0 اسبوع واحد",
  "$0 اسبوعان",
  "$0 اسابيع",
  "$0 اسبوعا",
  "$0 اسبوع"
 ],
 "$0 will be installed.": [
  null,
  "$0 سيُثبت."
 ],
 "$0 year": [
  null,
  "$0 ولا سنة",
  "$0 سنة واحدة",
  "$0 سنتان",
  "$0 سنوات",
  "$0 سنة",
  "$0 سنة"
 ],
 "$0 zone": [
  null,
  "منطقة $0"
 ],
 "1 day": [
  null,
  "يوم واحد"
 ],
 "1 hour": [
  null,
  "ساعة واحدة"
 ],
 "1 minute": [
  null,
  "دقيقة واحدة"
 ],
 "1 week": [
  null,
  "أسبوع واحد"
 ],
 "20 minutes": [
  null,
  "٢٠ دقيقة"
 ],
 "40 minutes": [
  null,
  "٤٠ دقيقة"
 ],
 "5 minutes": [
  null,
  "٥ دقائق"
 ],
 "6 hours": [
  null,
  "٦ ساعات"
 ],
 "60 minutes": [
  null,
  "٦٠ دقيقة"
 ],
 "802.3ad": [
  null,
  "802.3ad"
 ],
 "802.3ad LACP": [
  null,
  "802.3ad LACP"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "لم يتم تثبيت إصدار متوافق من Cockpit على $0."
 ],
 "A network bond combines multiple network interfaces into one logical interface with higher throughput or redundancy.": [
  null,
  "يجمع رابِط الشبكة (Bond) عدة واجهات شبكية في واجهة منطقية واحدة لزيادة الإنتاجية أو تحقيق التكرار."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "سيتم إنشاء مفتاح SSH جديد في $0 لـ $1 بتاريخ $2 ، وإضافته إلى الملف $3 الخاص بـ $4 على $5."
 ],
 "ARP": [
  null,
  "ARP"
 ],
 "ARP monitoring": [
  null,
  "مراقبة ARP"
 ],
 "ARP ping": [
  null,
  "فحص اتصال ARP"
 ],
 "Absent": [
  null,
  "غائب"
 ],
 "Acceptable password": [
  null,
  "كلمة السر صالحة"
 ],
 "Active": [
  null,
  "نشط"
 ],
 "Active backup": [
  null,
  "النسخ الاحتياطي النشط"
 ],
 "Adaptive load balancing": [
  null,
  "موازنة حمل إرسال تكيفية"
 ],
 "Adaptive transmit load balancing": [
  null,
  "موازنة حمل إرسال تكيفية"
 ],
 "Add": [
  null,
  "إضافة"
 ],
 "Add $0": [
  null,
  "أضف $0"
 ],
 "Add DNS server": [
  null,
  "أضف خادم DNS"
 ],
 "Add VLAN": [
  null,
  "أضف VLAN"
 ],
 "Add VPN": [
  null,
  "أضف VPN"
 ],
 "Add WireGuard VPN": [
  null,
  "أضف WireGuard VPN"
 ],
 "Add a new zone": [
  null,
  "إضافة منطقة جديدة"
 ],
 "Add address": [
  null,
  "إضافة عناوين"
 ],
 "Add bond": [
  null,
  "إضافة رابط شبكي"
 ],
 "Add bridge": [
  null,
  "إضافة جسر"
 ],
 "Add member": [
  null,
  "إضافة عضو"
 ],
 "Add new zone": [
  null,
  "إضافة منطقة جديدة"
 ],
 "Add peer": [
  null,
  "إضافة نظير"
 ],
 "Add ports": [
  null,
  "إضافة منافذ"
 ],
 "Add ports to $0 zone": [
  null,
  "إضافة منافذ للمنطقة $0"
 ],
 "Add route": [
  null,
  "إضافة توجيه"
 ],
 "Add search domain": [
  null,
  "إضافة نطاق البحث"
 ],
 "Add services": [
  null,
  "إضافة خدمات"
 ],
 "Add services to $0 zone": [
  null,
  "إضافة خدمات للمنطقة $0"
 ],
 "Add services to zone $0": [
  null,
  "إضافة خدمات إلى المنطقة $0"
 ],
 "Add team": [
  null,
  "إضافة فريق"
 ],
 "Add zone": [
  null,
  "إضافة منطقة"
 ],
 "Adding $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "إضافة $0 ستؤدي إلى قطع الاتصال بالخادم، وسيجعل واجهة الإدارة غير متاحة."
 ],
 "Adding custom ports will reload firewalld. A reload will result in the loss of any runtime-only configuration!": [
  null,
  "إضافة منافذ مخصصة سيؤدي إلى إعادة تحميل firewalld ، بالتالي فقدان أي إعدادات مؤقتة!"
 ],
 "Additional DNS $val": [
  null,
  "خادم DNS إضافي: ‎$val"
 ],
 "Additional DNS search domains $val": [
  null,
  "نطاقات بحث DNS إضافية: ‎$val"
 ],
 "Additional address $val": [
  null,
  "عناوين إضافية $val"
 ],
 "Additional packages:": [
  null,
  "حزم إضافية:"
 ],
 "Additional ports": [
  null,
  "منافذ إضافية"
 ],
 "Address": [
  null,
  "العنوان"
 ],
 "Address $val": [
  null,
  "العنوان $val"
 ],
 "Addresses": [
  null,
  "العناوين"
 ],
 "Addresses are not formatted correctly": [
  null,
  "تنسيق العناوين غير صحيح"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "الإدارة عبر وحدة تحكم الويب Cockpit"
 ],
 "Advanced TCA": [
  null,
  "TCA متقدم"
 ],
 "All-in-one": [
  null,
  "الكل في واحد"
 ],
 "Allowed IPs": [
  null,
  "عناوين الـ IP المسموح بها"
 ],
 "Allowed addresses": [
  null,
  "العناوين المسموح بها"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "توثيق الأدوار في Ansible"
 ],
 "Authenticating": [
  null,
  "جار المصادقة"
 ],
 "Authentication": [
  null,
  "المصادقة"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "المصادقة مطلوبة لأداء المهام المميّزة في وحدة تحكم Cockpit على الويب"
 ],
 "Authorize SSH key": [
  null,
  "اعتماد مفاتيح SSH"
 ],
 "Automatic": [
  null,
  "تلقائي"
 ],
 "Automatic (DHCP only)": [
  null,
  "تلقائي ( DHCP فقط )"
 ],
 "Automatically using NTP": [
  null,
  "استخدام NTP بشكل تلقائي"
 ],
 "Automatically using additional NTP servers": [
  null,
  "استخدام خادم NTP إضافي بشكل تلقائي"
 ],
 "Automatically using specific NTP servers": [
  null,
  "استخدام خادم NTP محدد بشكل تلقائي"
 ],
 "Automation script": [
  null,
  "البرنامج النصي للتشغيل الآلي"
 ],
 "Balancer": [
  null,
  "الموازِن"
 ],
 "Blade": [
  null,
  "شفرة"
 ],
 "Blade enclosure": [
  null,
  "حاوية الشفرة"
 ],
 "Bond": [
  null,
  "شبكة وثاقية"
 ],
 "Bridge": [
  null,
  "جسر"
 ],
 "Bridge port": [
  null,
  "منفذ الجسر"
 ],
 "Bridge port settings": [
  null,
  "إعدادات منفذ الجسر"
 ],
 "Broadcast": [
  null,
  "البث"
 ],
 "Broken configuration": [
  null,
  "تكوين معطل"
 ],
 "Bus expansion chassis": [
  null,
  "هيكل توسيع الناقل"
 ],
 "Cancel": [
  null,
  "إلغاء"
 ],
 "Cannot forward login credentials": [
  null,
  "لا يمكن إعادة توجيه بيانات اعتماد تسجيل الدخول"
 ],
 "Cannot schedule event in the past": [
  null,
  "لا يمكن جدولة الحدث في الماضي"
 ],
 "Carrier": [
  null,
  "الناقل"
 ],
 "Change": [
  null,
  "تغيير"
 ],
 "Change system time": [
  null,
  "تغيير توقيت النظام"
 ],
 "Change the settings": [
  null,
  "تغيير الإعدادات"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "غالباً تكون المفاتيح المتغيرة نتيجة إعادة تثبيت نظام التشغيل. رغم ذلك، قد يشير التغيير غير المتوقع إلى محاولة طرف ثالث اعتراض اتصالك."
 ],
 "Changing the settings will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "سيؤدي تغيير الإعدادات إلى قطع الاتصال مع الخادم وسيجعل واجهة الإدارة الرسومية غير متاحة."
 ],
 "Checking IP": [
  null,
  "التحقق من عنوان الـ IP"
 ],
 "Checking installed software": [
  null,
  "التحقق من البرامج المثبتة"
 ],
 "Clear input value": [
  null,
  "مسح قيمة المدخلات"
 ],
 "Close": [
  null,
  "أغلق"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "تكوين Cockpit الخاص بـ NetworkManager وFirewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "لم يتمكن Cockpit بالاتصال بالمضيف المحدد."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit هو أداة لإدارة الخوادم تُسهّل عليك الإشراف على خوادم Linux عبر متصفّح الويب. التنقّل بين الطرفية (الترمينال) والأداة على الويب سلس تمامًا؛ فمثلاً يمكنك إيقاف خدمة تمّ تشغيلها عبر Cockpit من داخل الطرفية، وبالمثل إذا ظهر خطأ في الطرفية ستجده معروضًا في واجهة سجلات Journal الخاصة بـ Cockpit."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit غير متوافق مع البرنامج على النظام."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit غير مثبت"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit غير مثبت على النظام."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "تُعد Cockpit مثالية لمديري النظام الجدد، حيث تتيح لهم أداء مهام بسيطة بسهولة مثل إدارة التخزين وفحص السجلات وبدء تشغيل الخدمات وإيقافها. يمكنك مراقبة وإدارة عدة خوادم في نفس الوقت. ما عليك سوى إضافتها بنقرة واحدة وستعتني أجهزتك بالباقي."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "جمع بيانات التشخيص والدعم وتجميعها"
 ],
 "Collect kernel crash dumps": [
  null,
  "جمع تفريغات أعطال نواة النظام"
 ],
 "Comma-separated ports, ranges, and services are accepted": [
  null,
  "إدخال المنافذ والنطاقات والخدمات مفصولة بفواصل متاح"
 ],
 "Compact PCI": [
  null,
  "PCI مدمج"
 ],
 "Configuring": [
  null,
  "التكوين"
 ],
 "Configuring IP": [
  null,
  "اضبط IP"
 ],
 "Confirm key password": [
  null,
  "تأكيد مفتاح كلمة السر"
 ],
 "Confirm removal of $0": [
  null,
  "تأكيد إزالة $0"
 ],
 "Connect automatically": [
  null,
  "غير ممكن آليا"
 ],
 "Connection has timed out.": [
  null,
  "انتهت مدة الاتصال."
 ],
 "Connection will be lost": [
  null,
  "سيفقد الاتصال"
 ],
 "Convertible": [
  null,
  "قابل للتحويل"
 ],
 "Copied": [
  null,
  "نُسخ"
 ],
 "Copy": [
  null,
  "نسخ"
 ],
 "Copy to clipboard": [
  null,
  "نسخ للحافظة"
 ],
 "Create $0": [
  null,
  "أنشئ $0"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "إنشاء مفتاح SSH جديد وتفويضه"
 ],
 "Create it": [
  null,
  "قم بإنشائه"
 ],
 "Create new task file with this content.": [
  null,
  "إنشاء ملف مهمة جديدة بهذا المحتوى."
 ],
 "Creating this $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "سيؤدي إنشاء هذا $0 إلى قطع الاتصال بالخادم، وسيجعل واجهة مستخدم الإدارة غير متاحة."
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Custom ports": [
  null,
  "منافذ مخصصة"
 ],
 "Custom zones": [
  null,
  "مناطق مخصصة"
 ],
 "DNS": [
  null,
  "DNS"
 ],
 "DNS $val": [
  null,
  "DNS $val"
 ],
 "DNS search domains": [
  null,
  "البحث في نطاقات DNS"
 ],
 "DNS search domains $val": [
  null,
  "البحث في نطاقات DNS $val"
 ],
 "Deactivating": [
  null,
  "إلغاء تنشيط"
 ],
 "Delay": [
  null,
  "التأخير"
 ],
 "Delete": [
  null,
  "حذف"
 ],
 "Delete $0": [
  null,
  "حذف $0"
 ],
 "Deleting $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "سيؤدي حذف $0 إلى قطع الاتصال بالخادم، وسيجعل واجهة المستخدم الخاصة بالإدارة غير متاحة."
 ],
 "Description": [
  null,
  "الوصف"
 ],
 "Desktop": [
  null,
  "سطح المكتب"
 ],
 "Detachable": [
  null,
  "قابل للفصل"
 ],
 "Diagnostic reports": [
  null,
  "تقارير التشخيص"
 ],
 "Disable the firewall": [
  null,
  "تعطيل الجدار الناري"
 ],
 "Disabled": [
  null,
  "معطّل"
 ],
 "Docking station": [
  null,
  "محطة إرساء"
 ],
 "Downloading $0": [
  null,
  "جاري تنزيل $0"
 ],
 "Dual rank": [
  null,
  "رتبة مزدوجة"
 ],
 "Edit": [
  null,
  "عدِّل"
 ],
 "Edit VLAN settings": [
  null,
  "تعديل إعدادات VLAN"
 ],
 "Edit WireGuard VPN": [
  null,
  "تعديل إعدادات WireGuard VPN"
 ],
 "Edit bond settings": [
  null,
  "تعديل إعدادات الربط الشبكي"
 ],
 "Edit bridge settings": [
  null,
  "تعديل إعدادات الجسر"
 ],
 "Edit custom service in $0 zone": [
  null,
  "تعديل خدمة مخصصة في المنطقة $0"
 ],
 "Edit rules and zones": [
  null,
  "تعدسل القواعد والمناطق"
 ],
 "Edit service": [
  null,
  "تعديل الخدمة"
 ],
 "Edit service $0": [
  null,
  "تعديل الخدمة $0"
 ],
 "Edit team settings": [
  null,
  "تعديل إعدادات الفريق"
 ],
 "Embedded PC": [
  null,
  "حاسوب مدمج"
 ],
 "Enable or disable the device": [
  null,
  "تفعيل أو إلغاء تفعيل الجهاز"
 ],
 "Enable service": [
  null,
  "تفعيل الخدمة"
 ],
 "Enable the firewall": [
  null,
  "تفعيل الجدار الناري"
 ],
 "Enabled": [
  null,
  "مُفعَّل"
 ],
 "Endpoint": [
  null,
  "نقطة نهاية"
 ],
 "Endpoint acting as a \"server\" need to be specified as host:port, otherwise it can be left empty.": [
  null,
  "ينبغي تحديد نقطة النهاية التي تعمل كـ ”خادم“ كمضيف:منفذ، وإلا يمكن تركها فارغة."
 ],
 "Enter a valid MAC address": [
  null,
  "أدخل عنوان MAC صالحاً"
 ],
 "Entire subnet": [
  null,
  "الشبكة الفرعية بالكامل"
 ],
 "Ethernet MAC": [
  null,
  "عنوان MAC للإيثرنت"
 ],
 "Ethernet MTU": [
  null,
  "إيثرنت MTU"
 ],
 "Ethtool": [
  null,
  "Ethtool"
 ],
 "Example: 22,ssh,8080,5900-5910": [
  null,
  "مثلاً: 22,ssh,8080,5900-5910"
 ],
 "Example: 88,2019,nfs,rsync": [
  null,
  "مثلاً: 88,2019,nfs,rsync"
 ],
 "Excellent password": [
  null,
  "كلمة سر ممتازة"
 ],
 "Expansion chassis": [
  null,
  "هيكل التوسعة"
 ],
 "Failed": [
  null,
  "فشل"
 ],
 "Failed to add port": [
  null,
  "فشل في إضافة منفذ"
 ],
 "Failed to add service": [
  null,
  "فشل في إضافة خدمة"
 ],
 "Failed to add zone": [
  null,
  "فشل في إضافة منطقة"
 ],
 "Failed to change password": [
  null,
  "فشل في تغيير كلمة السر"
 ],
 "Failed to edit service": [
  null,
  "فشل في تعديل الخدمة"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "فشل بتمكين $0 في الجدار الناري"
 ],
 "Failed to save settings": [
  null,
  "فشل في حفظ الإعدادات"
 ],
 "Filter services": [
  null,
  "خدمة التصفية"
 ],
 "Firewall": [
  null,
  "الجدار النّاري"
 ],
 "Firewall is not available": [
  null,
  "الجدار الناري غير متاح"
 ],
 "Forward delay $forward_delay": [
  null,
  "التأخير إلى الأمام $forward_delay"
 ],
 "Gateway": [
  null,
  "البوّابة"
 ],
 "General": [
  null,
  "عام"
 ],
 "Generated": [
  null,
  "تم توليده"
 ],
 "Go to now": [
  null,
  "انتقل الآن"
 ],
 "Group": [
  null,
  "مجموعة"
 ],
 "Hair pin mode": [
  null,
  "وضعية الالتفاف"
 ],
 "Hairpin mode": [
  null,
  "وضع الالتفاف"
 ],
 "Handheld": [
  null,
  "محمول باليد"
 ],
 "Hello time $hello_time": [
  null,
  "وقت الترحيب $hello_time"
 ],
 "Hide confirmation password": [
  null,
  "أخفِ تأكيد كلمة السر"
 ],
 "Hide password": [
  null,
  "أخفِ كلمة السر"
 ],
 "Host key is incorrect": [
  null,
  "مفتاح الاستضافة غير صحيح"
 ],
 "ID": [
  null,
  "المعرّف"
 ],
 "ID $id": [
  null,
  "المعرف $id"
 ],
 "IP address": [
  null,
  "عنوان IP"
 ],
 "IP address with routing prefix. Separate multiple values with a comma. Example: 192.0.2.0/24, 2001:db8::/32": [
  null,
  "عنوان IP مع بادئة التوجيه. افصل بين القيم المتعددة بفاصلة. مثال: 192.0.2.0.0/24، 2001:db8:/32"
 ],
 "IPv4": [
  null,
  "IPv4"
 ],
 "IPv4 addresses": [
  null,
  "عنوانين الـ IPv4"
 ],
 "IPv4 settings": [
  null,
  "إعدادات IPv4"
 ],
 "IPv6": [
  null,
  "IPv6"
 ],
 "IPv6 settings": [
  null,
  "إعدادات IPv6"
 ],
 "If left empty, ID will be generated based on associated port services and port numbers": [
  null,
  "إذا تُرك فارغًا، فسيتم توليد المعرف وفق خدمات المنافذ ، وأرقامها ذات الصلة"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "إذا كانت البصمة متطابقة، انقر فوق ”توثيق وإضافة مضيف“. وإلا فلا تتصل ، وتواصل مع مسؤول النظام."
 ],
 "Ignore": [
  null,
  "تجاهل"
 ],
 "Inactive": [
  null,
  "غير مفعَّل"
 ],
 "Included services": [
  null,
  "الخدمات المضمّنة"
 ],
 "Incoming requests are blocked by default. Outgoing requests are not blocked.": [
  null,
  "يتم حظر الطلبات الواردة بشكل افتراضي دون الصادرة."
 ],
 "Install": [
  null,
  "تثبيت"
 ],
 "Install software": [
  null,
  "ثبت التطبيق"
 ],
 "Installing $0": [
  null,
  "يثبت $0"
 ],
 "Interface": [
  null,
  "الواجهة",
  "واجهة",
  "واجهتين",
  "واجهات",
  "واجهة",
  "واجهة"
 ],
 "Interface members": [
  null,
  "واجهة الأعضاء"
 ],
 "Interfaces": [
  null,
  "الواجهات"
 ],
 "Internal error": [
  null,
  "خطأ داخلي"
 ],
 "Invalid address $0": [
  null,
  "عنوان غير صالح $0"
 ],
 "Invalid date format": [
  null,
  "تنسيق التاريخ خاطئ"
 ],
 "Invalid date format and invalid time format": [
  null,
  "صيغة البيانات والوقت غير صالحتان"
 ],
 "Invalid file permissions": [
  null,
  "صلاحيات ملف غير صالحة"
 ],
 "Invalid metric $0": [
  null,
  "مقياس غير صالح $0"
 ],
 "Invalid port number": [
  null,
  "رقم المنفذ غير صالح"
 ],
 "Invalid prefix $0": [
  null,
  "بادئة غير صحيحة $0"
 ],
 "Invalid prefix or netmask $0": [
  null,
  "بادئة أو غطاء شبكة غير صالح $0"
 ],
 "Invalid range": [
  null,
  "مدى غير صالح"
 ],
 "Invalid time format": [
  null,
  "تنسيق الوقت خاطئ"
 ],
 "Invalid timezone": [
  null,
  "منطقة زمنية غير صالحة"
 ],
 "IoT gateway": [
  null,
  "بوابة IoT"
 ],
 "Keep connection": [
  null,
  "ابقِ الاتصال"
 ],
 "Kernel dump": [
  null,
  "عطب نواة النظام"
 ],
 "Key password": [
  null,
  "مفتاح كلمة السر"
 ],
 "LACP key": [
  null,
  "مفتاح LACP"
 ],
 "Laptop": [
  null,
  "لابتوب"
 ],
 "Learn more": [
  null,
  "اعرف المزيد"
 ],
 "Link down delay": [
  null,
  "تأخير تعطل الرابط"
 ],
 "Link local": [
  null,
  "عنوان ربط محلي"
 ],
 "Link monitoring": [
  null,
  "مراقبة الرابط"
 ],
 "Link up delay": [
  null,
  "تأثير تفعيل الرابط"
 ],
 "Link watch": [
  null,
  "رصد الرابط"
 ],
 "Listen port": [
  null,
  "منفذ الاستماع"
 ],
 "Listen port must be a number": [
  null,
  "منفذ الاستماع يجب أن يكون رقماً"
 ],
 "Load balancing": [
  null,
  "موازنة الأحمال"
 ],
 "Loading system modifications...": [
  null,
  "تحميل تعديلات النظام..."
 ],
 "Log in": [
  null,
  "تسجيل الدخول"
 ],
 "Log in to $0": [
  null,
  "تسجيل الدخول إلى $0"
 ],
 "Log messages": [
  null,
  "رسالة طويلة"
 ],
 "Login failed": [
  null,
  "فشل تسجيل الدخول"
 ],
 "Low profile desktop": [
  null,
  "ملف سطح مكتب منخفض"
 ],
 "Lunch box": [
  null,
  "صندوق التشغيل"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "MII (recommended)": [
  null,
  "MII (مستحسن)"
 ],
 "MTU": [
  null,
  "MTU"
 ],
 "MTU must be a positive number": [
  null,
  "يجب أن يكون MTU عدداً موجباً"
 ],
 "Main server chassis": [
  null,
  "هيكل الخادم الرئيسي"
 ],
 "Manage storage": [
  null,
  "إدارة التخزين"
 ],
 "Managed interfaces": [
  null,
  "الواجهات المدارة"
 ],
 "Manual": [
  null,
  "يدوي"
 ],
 "Manually": [
  null,
  "يدوياً"
 ],
 "Maximum message age $max_age": [
  null,
  "الحد الأقصى لعمر الرسالة $max_age"
 ],
 "Message to logged in users": [
  null,
  "رسالة للمستخدمين النشطين"
 ],
 "Metric": [
  null,
  "مقياس"
 ],
 "Mini PC": [
  null,
  "حاسب آلي صغير"
 ],
 "Mini tower": [
  null,
  "برج صغير"
 ],
 "Mode": [
  null,
  "الطور"
 ],
 "Monitoring interval": [
  null,
  "فترة المراقبة"
 ],
 "Monitoring targets": [
  null,
  "أهداف المراقبة"
 ],
 "Multi-system chassis": [
  null,
  "هيكل متعدد الأنظمة"
 ],
 "Multiple addresses can be specified using commas or spaces as delimiters.": [
  null,
  "يمكن تحديد عناوين متعددة باستخدام فواصل أو مسافات كمحددات."
 ],
 "NSNA ping": [
  null,
  "اختبار اتصال NSNA"
 ],
 "NTP server": [
  null,
  "خادم NTP"
 ],
 "Name": [
  null,
  "الاسم"
 ],
 "Need at least one NTP server": [
  null,
  "يحتاج خادم NTP واحداً على الأقل"
 ],
 "Network bond": [
  null,
  "رابطة الشبكة"
 ],
 "Network devices and graphs require NetworkManager": [
  null,
  "تتطلب أجهزة الشبكة والرسوم البيانية خدمة NetworkManager"
 ],
 "Network logs": [
  null,
  "سجل الشبكة"
 ],
 "NetworkManager is not installed": [
  null,
  "NetworkManager ليس مثبتاً"
 ],
 "NetworkManager is not running": [
  null,
  "NetworkManager لا يعمل"
 ],
 "Networking": [
  null,
  "التشبيك"
 ],
 "New password was not accepted": [
  null,
  "كلمة السر الجديدة لم تقبل"
 ],
 "No": [
  null,
  "لا"
 ],
 "No carrier": [
  null,
  "لا حامل"
 ],
 "No delay": [
  null,
  "لا تأخير"
 ],
 "No description available": [
  null,
  "لا يوجد وصف متاح"
 ],
 "No peers added.": [
  null,
  "لا نظائر تم إضافتهم."
 ],
 "No results found": [
  null,
  "لم يعثر على نتائج"
 ],
 "No such file or directory": [
  null,
  "لا ملف أو مجلد من هذا النوع"
 ],
 "No system modifications": [
  null,
  "لا يوجد تعديلات على النظام"
 ],
 "None": [
  null,
  "لا شيء"
 ],
 "Not a valid private key": [
  null,
  "مفتاح خاص غير صالح"
 ],
 "Not authorized to disable the firewall": [
  null,
  "غير مصرَّح بتعطيل جدار الحماية"
 ],
 "Not authorized to enable the firewall": [
  null,
  "غير مصرح بتفعيل جدار الحمايةّ"
 ],
 "Not available": [
  null,
  "غير متوفر"
 ],
 "Not permitted to configure network devices": [
  null,
  "غير مسموح بتكوين أجهزة الشبكة"
 ],
 "Not permitted to perform this action.": [
  null,
  "غير مصرح لك بهذا الإجراء."
 ],
 "Not synchronized": [
  null,
  "غير مزامن"
 ],
 "Notebook": [
  null,
  "محرر النصوص"
 ],
 "Occurrences": [
  null,
  "الحوادث"
 ],
 "Ok": [
  null,
  "موافق"
 ],
 "Old password not accepted": [
  null,
  "كلمة السر القديمة غير مطابقة"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "بمجرد تثبيت Cockpit، قم بتمكينه باستخدام ”systemctl enable --now cockpit.socket“."
 ],
 "Options": [
  null,
  "الخيارات"
 ],
 "Other": [
  null,
  "أُخرى"
 ],
 "PackageKit crashed": [
  null,
  "تعطيل PackageKit"
 ],
 "Parent": [
  null,
  "الأصل"
 ],
 "Parent $parent": [
  null,
  "الأب $parent"
 ],
 "Part of $0": [
  null,
  "جزء من $0"
 ],
 "Passive": [
  null,
  "سلبي"
 ],
 "Password": [
  null,
  "كلمة السر"
 ],
 "Password is not acceptable": [
  null,
  "كلمة السر غير مقبولة"
 ],
 "Password is too weak": [
  null,
  "كلمة السر ضعيفة جداً"
 ],
 "Password not accepted": [
  null,
  "كلمة السر مرفوضة"
 ],
 "Paste": [
  null,
  "لصق"
 ],
 "Paste error": [
  null,
  "خطأ في اللصق"
 ],
 "Paste existing key": [
  null,
  "لصق مفتاح موجود"
 ],
 "Path cost": [
  null,
  "تكلفة المسار"
 ],
 "Path cost $path_cost": [
  null,
  "تكلفة المسار $path_cost"
 ],
 "Path to file": [
  null,
  "المسار إلى الملف"
 ],
 "Peer #$0 has invalid endpoint port. Port must be a number.": [
  null,
  "النظير #$0 يحتوي على منفذ نهاية غير صالح. يجب أن يكون المنفذ رقماً."
 ],
 "Peer #$0 has invalid endpoint. It must be specified as host:port, e.g. 1.2.3.4:51820 or example.com:51820": [
  null,
  "النظير #$0 يحتوي على نقطة نهاية غير صالحة. يجب تحديدها بالشكل: مضيف:منفذ، مثل 1.2.3.4:51820 أو example.com:51820"
 ],
 "Peers": [
  null,
  "النظائر"
 ],
 "Peers are other machines that connect with this one. Public keys from other machines will be shared with each other.": [
  null,
  "النظائر هي أجهزة أخرى تتصل بهذا الجهاز. سيتم تبادل المفاتيح العامة بين الأجهزة."
 ],
 "Peripheral chassis": [
  null,
  "هيكل الأجهزة الطرفية"
 ],
 "Permanent": [
  null,
  "دائم"
 ],
 "Pick date": [
  null,
  "اختيار التاريخ والوقت"
 ],
 "Ping interval": [
  null,
  "فترة اختبار الاتصال"
 ],
 "Ping target": [
  null,
  "هدف اختبار الاتصال"
 ],
 "Pizza box": [
  null,
  "صندوق البيتزا"
 ],
 "Please install the $0 package": [
  null,
  "الرجاء تثبيت الحزمة $0"
 ],
 "Portable": [
  null,
  "متنقل"
 ],
 "Ports": [
  null,
  "المنافذ"
 ],
 "Prefix length": [
  null,
  "طول البادئة"
 ],
 "Prefix length or netmask": [
  null,
  "طول البادئة أو قناع الشبكة"
 ],
 "Preparing": [
  null,
  "يحضّر"
 ],
 "Present": [
  null,
  "موجود"
 ],
 "Preserve": [
  null,
  "احمِ"
 ],
 "Primary": [
  null,
  "أولي"
 ],
 "Priority": [
  null,
  "الأولوية"
 ],
 "Priority $priority": [
  null,
  "الألولوية $priority"
 ],
 "Private key": [
  null,
  "المفتاح الخاص"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "انتهت مهلة الطلب عبر ssh-add"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "انتهت مهلة الطلب عبر ssh-keygen"
 ],
 "Public key": [
  null,
  "مفتاح عام"
 ],
 "Public key will be generated when a valid private key is entered": [
  null,
  "سيتم توليد المفتاح العام عند إدخال مفتاح خاص صالح"
 ],
 "RAID chassis": [
  null,
  "هيكل RAID"
 ],
 "Rack mount chassis": [
  null,
  "هيكل مثبت على حامل"
 ],
 "Random": [
  null,
  "عشوائي"
 ],
 "Range": [
  null,
  "المدى"
 ],
 "Range must be strictly ordered": [
  null,
  "يجب أن يكون النطاق مرتبًا بدقة"
 ],
 "Reboot": [
  null,
  "إعادة تشغيل"
 ],
 "Receiving": [
  null,
  "استقبال"
 ],
 "Regenerate": [
  null,
  "إعادة توليد"
 ],
 "Removals:": [
  null,
  "عمليات الإزالة:"
 ],
 "Remove $0": [
  null,
  "إزالة $0"
 ],
 "Remove $0 service from $1 zone": [
  null,
  "أزل الخدمة $0 من المنطقة $1"
 ],
 "Remove item": [
  null,
  "إزالة العنصر"
 ],
 "Remove service $0": [
  null,
  "إزالة الخدمة $0"
 ],
 "Remove zone $0": [
  null,
  "إزالة المنطقة $0"
 ],
 "Removing $0": [
  null,
  "قيد إزالة $0"
 ],
 "Removing $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "ستؤدي إزالة $0 إلى قطع الاتصال بالخادم، وستجعل واجهة مستخدم الإدارة غير متاحة."
 ],
 "Removing the cockpit service might result in the web console becoming unreachable. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "قد تؤدي إزالة خدمة Cockpit إلى تعذر الوصول إلى وحدة تحكم الويب. تأكد من أن هذه المنطقة لا تنطبق على اتصال وحدة تحكم الويب الحالية."
 ],
 "Removing the zone will remove all services within it.": [
  null,
  "ستؤدي إزالة المنطقة إلى إزالة جميع الخدمات داخلها."
 ],
 "Restoring connection": [
  null,
  "إعادة تخزين الاتصال"
 ],
 "Round robin": [
  null,
  "جولة روبن"
 ],
 "Routes": [
  null,
  "الطرق"
 ],
 "Row expansion": [
  null,
  "توسعة الصف"
 ],
 "Row select": [
  null,
  "حدد الصف"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "قم بتشغيل هذا الأمر عبر شبكة موثوقة أوا مادياً على الجهاز البعيد:"
 ],
 "Runner": [
  null,
  "مشغِّل"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "مفتاح SSH"
 ],
 "SSH key login": [
  null,
  "تسجيل دخول عبر مفتاح SSH"
 ],
 "STP forward delay": [
  null,
  "التأخير إلى الأمام STP"
 ],
 "STP hello time": [
  null,
  "وقت ترحيب STP"
 ],
 "STP maximum message age": [
  null,
  "الحد الأقصى لعمر رسالة STP"
 ],
 "STP priority": [
  null,
  "سياسة STP"
 ],
 "Save": [
  null,
  "حفظ"
 ],
 "Sealed-case PC": [
  null,
  "حاسوب شخصي مغلق"
 ],
 "Search domain": [
  null,
  "نطاق البحث"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "إعداد نظام Linux المحسّن للأمان واستكشاف الأخطاء وإصلاحها"
 ],
 "Select an option": [
  null,
  "تحديد خيار"
 ],
 "Select method": [
  null,
  "تحديد طريقة"
 ],
 "Sending": [
  null,
  "جاري الإرسال"
 ],
 "Server": [
  null,
  "خادم"
 ],
 "Server has closed the connection.": [
  null,
  "قام الخادم بإغلاق الاتصال."
 ],
 "Service": [
  null,
  "خدمة"
 ],
 "Services": [
  null,
  "الخدمات"
 ],
 "Set time": [
  null,
  "تعيين الوقت"
 ],
 "Set to": [
  null,
  "تعيين لـ"
 ],
 "Shared": [
  null,
  "مشتركة"
 ],
 "Shell script": [
  null,
  "سكريبت شِل"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show confirmation password": [
  null,
  "إظهار تأكيد كلمة السر"
 ],
 "Show password": [
  null,
  "أظهر كلمة السر"
 ],
 "Shut down": [
  null,
  "أوقف التشغيل"
 ],
 "Single rank": [
  null,
  "رتبة واحدة"
 ],
 "Sorted from least to most trusted": [
  null,
  "مُرتبة من الأقل إلى الأكثر ثقة"
 ],
 "Space-saving computer": [
  null,
  "حاسوب موفر للمساحة"
 ],
 "Spanning tree protocol": [
  null,
  "بروتوكول شجرة الامتداد"
 ],
 "Spanning tree protocol (STP)": [
  null,
  "بروتوكول شجرة الامتداد (STP)"
 ],
 "Specific time": [
  null,
  "الوقت المحدد"
 ],
 "Stable": [
  null,
  "مستقر"
 ],
 "Start service": [
  null,
  "بدء الخدمة"
 ],
 "Status": [
  null,
  "الحالة"
 ],
 "Stick PC": [
  null,
  "حاسوب عصا"
 ],
 "Sticky": [
  null,
  "لاصق"
 ],
 "Storage": [
  null,
  "التخزين"
 ],
 "Strong password": [
  null,
  "كلمة سر قوية"
 ],
 "Sub-Chassis": [
  null,
  "الهيكل الفرعي"
 ],
 "Sub-Notebook": [
  null,
  "دفتر ملاحظات فرعي"
 ],
 "Switch off $0": [
  null,
  "إيقاف تشغيل $0"
 ],
 "Switch on $0": [
  null,
  "تشغيل $0"
 ],
 "Switching off $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "سيؤدي إيقاف تشغيل $0 إلى قطع الاتصال بالخادم، وسيجعل واجهة مستخدم الإدارة غير متاحة."
 ],
 "Switching on $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "سيؤدي تشغيل $0 إلى قطع الاتصال بالخادم، وسيجعل واجهة مستخدم الإدارة غير متاحة."
 ],
 "Synchronized": [
  null,
  "متزامن"
 ],
 "Synchronized with $0": [
  null,
  "متزامن مع $0"
 ],
 "Synchronizing": [
  null,
  "جار المزامنة"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "Tablet": [
  null,
  "جهاز لوحي"
 ],
 "Team": [
  null,
  "الفريق"
 ],
 "Team port": [
  null,
  "منفذ الفريق"
 ],
 "Team port settings": [
  null,
  "إعدادات منفذ الفريق"
 ],
 "Testing connection": [
  null,
  "فحص الاتصال"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "سيتم إضافة مفتاح SSH $0 الخاص بـ $1 على $2 إلى ملف $3 الخاص بـ $4 على $5."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "سيكون مفتاح SSH $0 متاحًا لبقية الجلسة وسيكون متاحًا لتسجيل الدخول إلى مضيفين آخرين أيضًا."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "مفتاح SSH لتسجيل الدخول إلى $0 محمي بكلمة سر، ولا يسمح المضيف بتسجيل الدخول بكلمة سر. يرجى تقديم كلمة سر المفتاح في $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "مفتاح SSH لتسجيل الدخول إلى $0 محمي. يمكنك تسجيل الدخول إما باستخدام كلمة سر تسجيل الدخول الخاصة بك أو عن طريق توفير كلمة سر المفتاح في $1."
 ],
 "The cockpit service is automatically included": [
  null,
  "خدمة Cockpit مضمّنة تلقائياً"
 ],
 "The fingerprint should match:": [
  null,
  "ينبغي أن تتطابق البصمة:"
 ],
 "The key password can not be empty": [
  null,
  "مفتاح كلمة السر لا يمكن أن يكون فارغاً"
 ],
 "The key passwords do not match": [
  null,
  "كلمات المرور الرئيسية غير متطابقة"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "لا يُسمح للمستخدم الذي قام بتسجيل الدخول بعرض تعديلات النظام"
 ],
 "The password can not be empty": [
  null,
  "كلمة السر لا بمكن أن تكون فارغة"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "لا بأس بمشاركة البصمة الناتجة عبر الطرق العامة، بما في ذلك البريد الإلكتروني."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "بصمة المفتاح الناتجة آمنة للمشاركة عبر قنوات عامة، بما في ذلك البريد الإلكتروني."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "رفض الخادم المصادقة بأي طريقة مدعومة."
 ],
 "There are no active services in this zone": [
  null,
  "لا توجد خدمات نشطة في هذه المنطقة"
 ],
 "This device cannot be managed here.": [
  null,
  "لا يمكن إدارة هذا الجهاز هنا."
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "تقوم هذه الأداة بتكوين سياسة SELinux ويمكن أن تساعد في فهم انتهاكاتها وحلها."
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "تُهيئ هذه الأداة النظام لكتابة تفريغ أعطاب نواة النظام. وهي تدعم أهداف التفريغ التالية: \"محلي\" (على القرص)، و\"ssh\"، و\"nfs\"."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "تقوم هذه الأداة بإنشاء أرشيف يحتوي على معلومات الإعدادات والتشخيص من نظام التشغيل الذي يكون قيد العمل. قد يتم تخزين الأرشيف محليًا أو مركزيًا لأغراض التسجيل أو التتبع، أو إرساله إلى ممثلي الدعم الفني أو المطورين أو مسؤولي النظام اعدة في تحديد الأعطال ‌الفنية ، وتصحيح الأخطاء."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "تُدير هذه الأداة التخزين المحلي، بما في ذلك أنظمة الملفات، ومجموعات وحدات التخزين LVM2، ونقاط تركيب NFS."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "تُدير هذه الأداة الشبكات بما في ذلك الوصلات المجمعة (Bonds)، والجسور (Bridges)، وفرق الشبكات (Teams)، وشبكات VLAN، والجدران النارية، باستخدام NetworkManager وFirewalld. يُذكر أن NetworkManager غير متوافق مع نظام systemd-networkd الافتراضي في أوبونتو ونصوص ifupdown في دبيان."
 ],
 "This zone contains the cockpit service. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "هذه المنطقة تحتوي على خدمة Cockpit. تأكد أنها لا تنطبق على اتصال وحدة التحكم الويب الحالي."
 ],
 "Time zone": [
  null,
  "المنطقة الزمنية"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "لضمان عدم اعتراض اتصالك من قِبَل طرف ثالث ضار، يُرجى التحقق من بَصمة مفتاح الخادم:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "للتحقق من البصمة ، قم بتشغيل ما يلي على $0 أثناء تشغيل الجهاز أو من خلال شبكة موثوقة:"
 ],
 "Toggle date picker": [
  null,
  "إخفاء منتقي التاريخ و الوقت"
 ],
 "Too much data": [
  null,
  "الكثير من البيانات"
 ],
 "Total size: $0": [
  null,
  "الحجم الإجمالي: $0"
 ],
 "Tower": [
  null,
  "برج"
 ],
 "Transmitting": [
  null,
  "النقل"
 ],
 "Troubleshoot…": [
  null,
  "استكشاف الأخطاء وإصلاحها…"
 ],
 "Trust and add host": [
  null,
  "الثقة بالمضيف وإضافته"
 ],
 "Trust level": [
  null,
  "مستوى الثقة"
 ],
 "Trying to synchronize with $0": [
  null,
  "محاولة المزامنة مع $0"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "تعذّر تسجيل الدخول إلى $0 باستخدام مصادقة مفتاح SSH. يرجى إدخال كلمة السر."
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "تعذّر تسجيل الدهول إلى $0. لا يقبل المضيف تسجيل الدخول بكلمة سر ، أو أي من مفاتيح SSH الخاصة بك."
 ],
 "Unexpected error": [
  null,
  "خطأ غير متوقع"
 ],
 "Unknown": [
  null,
  "غير معروف"
 ],
 "Unknown \"$0\"": [
  null,
  "\"$0\" غير معروف"
 ],
 "Unknown configuration": [
  null,
  "تكوين غير معروف"
 ],
 "Unknown host: $0": [
  null,
  "مضيف غير معروف: $0"
 ],
 "Unknown service name": [
  null,
  "اسم خدمة غير معروف"
 ],
 "Unmanaged interfaces": [
  null,
  "الواجهات غير المُدارة"
 ],
 "Untrusted host": [
  null,
  "مضيف غير موثوق به"
 ],
 "Use $0": [
  null,
  "اشتخدم $0"
 ],
 "VLAN": [
  null,
  "شبكة VLAN"
 ],
 "VLAN ID": [
  null,
  "معرّف شبكة VLAN"
 ],
 "Verify fingerprint": [
  null,
  "أكّد البصمة"
 ],
 "View all logs": [
  null,
  "عرض جميع السجلات"
 ],
 "View automation script": [
  null,
  "عرض سكربت الأتمتة"
 ],
 "Visit firewall": [
  null,
  "زر الجدار الناري"
 ],
 "Waiting": [
  null,
  "انتظر"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "ينتظر انتهاء عمليات مدير البرامج الآخر"
 ],
 "Weak password": [
  null,
  "كلمة سر ضعيفة"
 ],
 "Web Console for Linux servers": [
  null,
  "وحدة تحكم الويب لخوادم Linux"
 ],
 "Will be set to \"Automatic\"": [
  null,
  "سيتم ضبطه على \"تلقائي\""
 ],
 "WireGuard": [
  null,
  "Wireguard"
 ],
 "XOR": [
  null,
  "XOR"
 ],
 "Yes": [
  null,
  "نعم"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "انت تتصل بـ $0 لأول مرة."
 ],
 "You are not authorized to modify the firewall.": [
  null,
  "أنت غير مخول بتعديل جدار الحماية."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "لا يسمح متصفحك باللصق من قائمة السياق. يمكنك استخدام Shift+Insert."
 ],
 "Your session has been terminated.": [
  null,
  "تم إنهاء جلستك."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "انتهت صلاحية جلستك , يرجى تسجيل الدخول مرة أخرى."
 ],
 "Zone": [
  null,
  "المنطقة"
 ],
 "[binary data]": [
  null,
  "[بيانات ثنائية]"
 ],
 "[no data]": [
  null,
  "[لا بيانات]"
 ],
 "edit": [
  null,
  "عدِّل"
 ],
 "in less than a minute": [
  null,
  "في أقل من دقيقة"
 ],
 "less than a minute ago": [
  null,
  "منذ أقل من دقيقة"
 ],
 "password quality": [
  null,
  "جودة كلمة السر"
 ],
 "show less": [
  null,
  "عرض أقل"
 ],
 "show more": [
  null,
  "عرض أكثر"
 ],
 "wireguard-tools package is not installed": [
  null,
  "حزمة wireguard-tools غير مثبتة"
 ]
});
