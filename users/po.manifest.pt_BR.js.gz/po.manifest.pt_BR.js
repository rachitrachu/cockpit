cockpit.locale({
 "": {
  "plural-forms": (n) => (n != 1),
  "language": "pt_BR",
  "language-direction": "ltr"
 },
 "Accounts": [
  null,
  "Contas"
 ],
 "Diagnostic reports": [
  null,
  "Relatório de diagnostico"
 ],
 "Kernel dump": [
  null,
  "Dump do kernel"
 ],
 "Managing user accounts": [
  null,
  "Gerenciando contas de usuário"
 ],
 "Networking": [
  null,
  "Rede"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "Armazenamento"
 ],
 "access": [
  null,
  "acesso"
 ],
 "keys": [
  null,
  "chaves"
 ],
 "login": [
  null,
  "login"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "password": [
  null,
  "senha"
 ],
 "roles": [
  null,
  "papéis"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "user": [
  null,
  "usuário"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "username": [
  null,
  "nome de usuário"
 ]
});
