cockpit.locale({
 "": {
  "plural-forms": (n) => n==0 ? 0 : n==1 ? 1 : n==2 ? 2 : n%100>=3 && n%100<=10 ? 3 : n%100>=11 ? 4 : 5,
  "language": "ar",
  "language-direction": "rtl"
 },
 "Accounts": [
  null,
  "الحسابات"
 ],
 "Diagnostic reports": [
  null,
  "تقارير التشخيص"
 ],
 "Kernel dump": [
  null,
  "عطب نواة النظام"
 ],
 "Managing user accounts": [
  null,
  "إدارة حسابات المستخدم"
 ],
 "Networking": [
  null,
  "التشبيك"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "التخزين"
 ],
 "access": [
  null,
  "وصول"
 ],
 "keys": [
  null,
  "مفاتيح"
 ],
 "login": [
  null,
  "سجل الدخول"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "password": [
  null,
  "كَلمة السر"
 ],
 "roles": [
  null,
  "قواعد"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "user": [
  null,
  "المُستخدم"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "username": [
  null,
  "اسم المستخدم"
 ]
});
