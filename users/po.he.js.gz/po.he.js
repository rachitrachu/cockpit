cockpit.locale({
 "": {
  "plural-forms": (n) => (n == 1) ? 0 : ((n == 2) ? 1 : ((n > 10 && n % 10 == 0) ? 2 : 3)),
  "language": "he",
  "language-direction": "rtl"
 },
 "# of users": [
  null,
  "מס׳ משתמשים"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 day": [
  null,
  "יום",
  "יומיים",
  "$0 ימים",
  "$0 ימים"
 ],
 "$0 exited with code $1": [
  null,
  "$0 הסתיים עם הקוד $1"
 ],
 "$0 failed": [
  null,
  "$0 נכשל"
 ],
 "$0 hour": [
  null,
  "שעה",
  "שעתיים",
  "$0 שעות",
  "$0 שעות"
 ],
 "$0 is an existing file": [
  null,
  "$0 הוא קובץ קיים"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 אינו זמין מאף מאגר."
 ],
 "$0 key changed": [
  null,
  "המפתח $0 השתנה"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 נקטל עם האות $1"
 ],
 "$0 minute": [
  null,
  "דקה",
  "$0 דקות",
  "$0 דקות",
  "$0 דקות"
 ],
 "$0 month": [
  null,
  "חודש",
  "חודשיים",
  "$0 חודשים",
  "$0 חודשים"
 ],
 "$0 more...": [
  null,
  "$0 נוספים…"
 ],
 "$0 week": [
  null,
  "שבוע",
  "שבועיים",
  "$0 שבועות",
  "$0 שבועות"
 ],
 "$0 will be installed.": [
  null,
  "$0 יותקן."
 ],
 "$0 year": [
  null,
  "שנה",
  "שנתיים",
  "$0 שנים",
  "$0 שנים"
 ],
 "1 day": [
  null,
  "יום"
 ],
 "1 hour": [
  null,
  "שעה"
 ],
 "1 minute": [
  null,
  "דקה"
 ],
 "1 week": [
  null,
  "שבוע"
 ],
 "20 minutes": [
  null,
  "20 דקות"
 ],
 "40 minutes": [
  null,
  "40 דקות"
 ],
 "5 minutes": [
  null,
  "5 דקות"
 ],
 "6 hours": [
  null,
  "6 שעות"
 ],
 "60 minutes": [
  null,
  "60 דקות"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "לא מותקנת גרסה תואמת של Cockpit ב־$0."
 ],
 "A group with this name already exists": [
  null,
  "כבר קיימת קבוצה בשם הזה"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "מפתח SSH חדש תחת $0 ייווצר עבור $1 על גבי $2 והוא יתווסף לקובץ $3 של $4 על גבי $5."
 ],
 "Absent": [
  null,
  "חסר"
 ],
 "Acceptable password": [
  null,
  "סיסמה מקובלת"
 ],
 "Account expiration": [
  null,
  "תפוגת תוקף חשבון"
 ],
 "Account not available or cannot be edited.": [
  null,
  "החשבון לא זמין או שאין אפשרות לערוך אותו."
 ],
 "Accounts": [
  null,
  "חשבונות"
 ],
 "Actions": [
  null,
  "פעולות"
 ],
 "Add": [
  null,
  "הוספה"
 ],
 "Add $0": [
  null,
  "הוספת $0"
 ],
 "Add key": [
  null,
  "הוספת מפתח"
 ],
 "Add public key": [
  null,
  "הוספת מפתח ציבורי"
 ],
 "Additional packages:": [
  null,
  "חבילות נוספות:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "ניהול עם המסוף המקוון Cockpit"
 ],
 "Advanced TCA": [
  null,
  "TCA מתקדם"
 ],
 "All-in-one": [
  null,
  "אול אין ואן"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "תיעוד תפקידים של Ansible"
 ],
 "Authentication": [
  null,
  "אימות"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "נדרש אימות כדי לבצע משימות שדורשות השראה עם המסוף המקוון Cockpit"
 ],
 "Authorize SSH key": [
  null,
  "אישור מפתח SSH"
 ],
 "Authorized public SSH keys": [
  null,
  "מפתחות SSH ציבוריים מורשים"
 ],
 "Automatically using NTP": [
  null,
  "אוטומטית באמצעות NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "אוטומטית באמצעות שרתי NTP נוספים"
 ],
 "Automatically using specific NTP servers": [
  null,
  "אוטומטית באמצעות שרתי NTP מסוימים"
 ],
 "Automation script": [
  null,
  "סקריפט אוטומטי"
 ],
 "Back to accounts": [
  null,
  "חזרה לחשבונות"
 ],
 "Blade": [
  null,
  "בלייד"
 ],
 "Blade enclosure": [
  null,
  "אריזת בלייד"
 ],
 "Bus expansion chassis": [
  null,
  "שלדת הרחבת אפיקים"
 ],
 "Cancel": [
  null,
  "ביטול"
 ],
 "Cannot forward login credentials": [
  null,
  "לא ניתן להעביר פרטי גישה"
 ],
 "Cannot schedule event in the past": [
  null,
  "לא ניתן לתזמן אירוע לעבר"
 ],
 "Change": [
  null,
  "החלפה"
 ],
 "Change shell": [
  null,
  "החלפת מעטפת"
 ],
 "Change system time": [
  null,
  "החלפת שעון המערכת"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "מפתחות שהוחלפו הם לעתים תוצאה של התקנת מערכת הפעלה מחדש. עם זאת, שינוי בלתי צפוי עשוי להעיד שגורם צד־שלישי מנסה ליירט את החיבור שלך."
 ],
 "Checking installed software": [
  null,
  "התכנה שמותקנת נבדקת"
 ],
 "Clear filter": [
  null,
  "הסרת מסנן"
 ],
 "Clear input value": [
  null,
  "מחיקת ערך קלט"
 ],
 "Close": [
  null,
  "סגירה"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "ההגדרות של Cockpit ל־NetworkManager ול־Firewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "ל־Cockpit אין אפשרות ליצור קשר עם המארח שסופק."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit הוא מנהל שרתים שמקל על ניהול שרתי הלינוקס שלך דרך הדפדפן. מעבר חטוף בין המסוף והכלי המקוון הוא פשוט וקל. שירות שהופעל דרך Cockpit ניתן לעצור דרך המסוף. באותו האופן, אם מתרחשת שגיאה במסוף ניתן לצפות בה במנשק היומן של Cockpit."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit אינו תואם לתכנה שרצה על המערכת."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit אינו מותקן"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit אינו מותקן על המערכת."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit הוא מושלם למנהלי מערכות מתחילים, מאפשר להם לבצע משימות פשוטות בקלות כגון ניהול אחסון, חקירת יומנים והפעלה ועצירה של שירותים. ניתן לנהל ולעקוב אחר מספר שרתים בו־זמנית. כל שעליך לעשות הוא להוסיף אותם בלחיצה בודדת והמכונות שלך תדאגנה לחברותיהן."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "איסוף ואריזה של נתוני ניתוח ותמיכה"
 ],
 "Collect kernel crash dumps": [
  null,
  "איסוף היטלי קריסת ליבה"
 ],
 "Compact PCI": [
  null,
  "PCI חסכוני"
 ],
 "Confirm key password": [
  null,
  "אישור סיסמת מפתח"
 ],
 "Confirm new password": [
  null,
  "אישור סיסמה חדשה"
 ],
 "Confirm password": [
  null,
  "אישור סיסמה"
 ],
 "Connection has timed out.": [
  null,
  "הזמן שהוקצב להתחברות תם."
 ],
 "Convertible": [
  null,
  "מתהפך"
 ],
 "Copied": [
  null,
  "הועתק"
 ],
 "Copy": [
  null,
  "העתקה"
 ],
 "Copy to clipboard": [
  null,
  "העתקה ללוח הגזירים"
 ],
 "Create": [
  null,
  "יצירה"
 ],
 "Create $0": [
  null,
  "יצירת $0"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "ליצור מפתח SSH חדש ולאשר אותו"
 ],
 "Create account with non-unique UID": [
  null,
  "יצירת חשבון עם מזהה משתמש לא ייחודי"
 ],
 "Create account with weak password": [
  null,
  "יצירת חשבון עם סיסמה חלשה"
 ],
 "Create and change ownership of home directory": [
  null,
  "יצירה ושינוי בעלות על תיקיית הבית"
 ],
 "Create new account": [
  null,
  "יצירת חשבון חדש"
 ],
 "Create new group": [
  null,
  "יצירת קבוצה חדשה"
 ],
 "Create new task file with this content.": [
  null,
  "יצירת קובץ משימה עם התוכן הזה."
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Delay": [
  null,
  "השהיה"
 ],
 "Delete": [
  null,
  "מחיקה"
 ],
 "Delete $0": [
  null,
  "מחיקת $0"
 ],
 "Delete account": [
  null,
  "מחיקת חשבון"
 ],
 "Delete files": [
  null,
  "מחיקת קבצים"
 ],
 "Delete group": [
  null,
  "מחיקת קבוצה"
 ],
 "Desktop": [
  null,
  "שולחן עבודה"
 ],
 "Detachable": [
  null,
  "נתיק"
 ],
 "Diagnostic reports": [
  null,
  "דוחות אבחון"
 ],
 "Disallow interactive password": [
  null,
  "איסור סיסמה אינטראקטיבית"
 ],
 "Disallow password authentication": [
  null,
  "לא לאפשר אימות בסיסמה"
 ],
 "Docking station": [
  null,
  "תחנת עגינה"
 ],
 "Downloading $0": [
  null,
  "$0 בהורדה"
 ],
 "Dual rank": [
  null,
  "דו־צדדי"
 ],
 "Edit user": [
  null,
  "עריכת משתמש"
 ],
 "Embedded PC": [
  null,
  "מחשב משובץ"
 ],
 "Empty password": [
  null,
  "סיסמה ריקה"
 ],
 "Ended": [
  null,
  "הסתיים"
 ],
 "Error saving authorized keys: ": [
  null,
  "שגיאה בשמירת המפתחות המורשים: "
 ],
 "Excellent password": [
  null,
  "סיסמה מצוינת"
 ],
 "Expansion chassis": [
  null,
  "שלדת הרחבה"
 ],
 "Expire account on": [
  null,
  "החשבון יפוג ב־"
 ],
 "Expire account on $0": [
  null,
  "החשבון יפוג ב־$0"
 ],
 "Failed to change password": [
  null,
  "החלפת הסיסמה נכשלה"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "הפעלת $0 ב־firewalld נכשלה"
 ],
 "Failed to load authorized keys.": [
  null,
  "טעינת המפתחות המורשים נכשלה."
 ],
 "Fingerprint": [
  null,
  "טביעת אצבע"
 ],
 "Force change": [
  null,
  "לאלץ החלפה"
 ],
 "Force delete": [
  null,
  "לאלץ מחיקה"
 ],
 "Force password change": [
  null,
  "לאלץ החלפת סיסמה"
 ],
 "From": [
  null,
  "התחלה"
 ],
 "Full name": [
  null,
  "שם מלא"
 ],
 "Go to now": [
  null,
  "לעבור כעת"
 ],
 "Group": [
  null,
  "קבוצה"
 ],
 "Group name": [
  null,
  "שם הקבוצה"
 ],
 "Groups": [
  null,
  "קבוצות"
 ],
 "Handheld": [
  null,
  "נישא"
 ],
 "Hide confirmation password": [
  null,
  "הסתרת סיסמת האישור"
 ],
 "Hide password": [
  null,
  "הסתרת הסיסמה"
 ],
 "Home directory": [
  null,
  "תיקיית בית"
 ],
 "Host key is incorrect": [
  null,
  "מפתח המארח שגוי"
 ],
 "ID": [
  null,
  "מזהה"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "אם טביעת האצבע תואמת, יש ללחוץ על ‚מתן אמון והוספת מארח’. אחרת, לא להתחבר וליצור קשר עם הנהלת המערכת."
 ],
 "Install": [
  null,
  "התקנה"
 ],
 "Install software": [
  null,
  "התקנת תכנה"
 ],
 "Installing $0": [
  null,
  "$0 בהתקנה"
 ],
 "Internal error": [
  null,
  "שגיאה פנימה"
 ],
 "Invalid date format": [
  null,
  "מבנה התאריך שגוי"
 ],
 "Invalid date format and invalid time format": [
  null,
  "מבנה תאריך שגוי ומבנה שעה שגוי"
 ],
 "Invalid expiration date": [
  null,
  "מועד התפוגה שגוי"
 ],
 "Invalid file permissions": [
  null,
  "הרשאות הקובץ שגויות"
 ],
 "Invalid key": [
  null,
  "מפתח שגוי"
 ],
 "Invalid number of days": [
  null,
  "מספר הימים שגוי"
 ],
 "Invalid time format": [
  null,
  "מבנה השעה שגוי"
 ],
 "Invalid timezone": [
  null,
  "אזור זמן שגוי"
 ],
 "IoT gateway": [
  null,
  "שער גישה IoT"
 ],
 "Kernel dump": [
  null,
  "היטל ליבה"
 ],
 "Key password": [
  null,
  "סיסמת מפתח"
 ],
 "Laptop": [
  null,
  "מחשב נייד"
 ],
 "Last active": [
  null,
  "פעילות אחרונה"
 ],
 "Last login": [
  null,
  "כניסה אחרונה"
 ],
 "Learn more": [
  null,
  "מידע נוסף"
 ],
 "Loading system modifications...": [
  null,
  "השינויים למערכת נטענים…"
 ],
 "Loading...": [
  null,
  "בטעינה…"
 ],
 "Local accounts": [
  null,
  "חשבונות מקומיים"
 ],
 "Lock": [
  null,
  "נעילה"
 ],
 "Lock $0": [
  null,
  "נעילת $0"
 ],
 "Lock account": [
  null,
  "נעילת חשבון"
 ],
 "Log in": [
  null,
  "כניסה"
 ],
 "Log in to $0": [
  null,
  "כניסה אל $0"
 ],
 "Log messages": [
  null,
  "הודעות יומן"
 ],
 "Log out": [
  null,
  "יציאה"
 ],
 "Log user out": [
  null,
  "הוצאת משתמש"
 ],
 "Logged in": [
  null,
  "נכנסת"
 ],
 "Login failed": [
  null,
  "הכניסה נכשלה"
 ],
 "Login history": [
  null,
  "היסטוריית כניסות"
 ],
 "Login history list": [
  null,
  "רשימת היסטוריית כניסות"
 ],
 "Logout $0": [
  null,
  "הוצאת $0 מהמערכת"
 ],
 "Low profile desktop": [
  null,
  "מחשב שולחני עם פרופיל נמוך"
 ],
 "Lunch box": [
  null,
  "קופסת אוכל"
 ],
 "Main server chassis": [
  null,
  "שלדת שרת ראשית"
 ],
 "Manage storage": [
  null,
  "ניהול אחסון"
 ],
 "Manually": [
  null,
  "ידנית"
 ],
 "Message to logged in users": [
  null,
  "הודעה למשתמשים שנמצאים במערכת"
 ],
 "Mini PC": [
  null,
  "מחשב מוקטן"
 ],
 "Mini tower": [
  null,
  "מארז מוקטן"
 ],
 "Multi-system chassis": [
  null,
  "שלדה למגוון מערכות"
 ],
 "NTP server": [
  null,
  "שרת NTP"
 ],
 "Name": [
  null,
  "שם"
 ],
 "Need at least one NTP server": [
  null,
  "נדרש שרת NTP אחד לפחות"
 ],
 "Networking": [
  null,
  "תקשורת"
 ],
 "Never": [
  null,
  "אף פעם"
 ],
 "Never expire account": [
  null,
  "חשבון שתוקפו לא פג"
 ],
 "Never expire password": [
  null,
  "הסיסמה לא תפוג לעולם"
 ],
 "Never logged in": [
  null,
  "מעולם לא נכנס"
 ],
 "New name": [
  null,
  "שם חדש"
 ],
 "New password": [
  null,
  "סיסמה חדשה"
 ],
 "New password was not accepted": [
  null,
  "הסיסמה החדשה לא התקבלה"
 ],
 "No ID specified": [
  null,
  "לא מוגדר מזהה"
 ],
 "No delay": [
  null,
  "אין השהיה"
 ],
 "No group name specified": [
  null,
  "לא צוין שם לקבוצה"
 ],
 "No matching results": [
  null,
  "אין כללים תואמים"
 ],
 "No real name specified": [
  null,
  "לא צוין שם אמתי"
 ],
 "No results found": [
  null,
  "לא נמצאו תוצאות"
 ],
 "No such file or directory": [
  null,
  "אין קובץ או תיקייה בשם הזה"
 ],
 "No system modifications": [
  null,
  "אין שינויים במערכת"
 ],
 "No user name specified": [
  null,
  "לא צוין שם משתמש"
 ],
 "Not a valid private key": [
  null,
  "לא מפתח פרטי תקני"
 ],
 "Not permitted to perform this action.": [
  null,
  "לא מורשה לבצע את הפעולה הזאת."
 ],
 "Not synchronized": [
  null,
  "לא מסונכרן"
 ],
 "Notebook": [
  null,
  "מחברת"
 ],
 "Occurrences": [
  null,
  "מופעים"
 ],
 "Ok": [
  null,
  "אישור"
 ],
 "Old password": [
  null,
  "סיסמה ישנה"
 ],
 "Old password not accepted": [
  null,
  "הסיסמה הישנה לא התקבלה"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "לאחר התקנת Cockpit, יש להפעיל את השירות בעזרת „systemctl enable --now cockpit.socket”."
 ],
 "Options": [
  null,
  "אפשרויות"
 ],
 "Other": [
  null,
  "אחר"
 ],
 "Other authentication methods are still available even when interactive password authentication is not allowed.": [
  null,
  "שיטות אימות אחרות עדיין זמינות אפילו כאשר אימות סיסמאות אינטראקטיבי אסור לשימוש."
 ],
 "PackageKit crashed": [
  null,
  "PackageKit קרס"
 ],
 "Password": [
  null,
  "סיסמה"
 ],
 "Password expiration": [
  null,
  "תפוגת סיסמה"
 ],
 "Password is longer than 256 characters": [
  null,
  "הסיסמה ארוכה מ־256 תווים"
 ],
 "Password is not acceptable": [
  null,
  "הסיסמה לא מקובלת"
 ],
 "Password is too weak": [
  null,
  "הסיסמה חלשה מדי"
 ],
 "Password must be changed": [
  null,
  "חובה לשנות את הסיסמה"
 ],
 "Password not accepted": [
  null,
  "הסיסמה לא התקבלה"
 ],
 "Paste": [
  null,
  "הדבקה"
 ],
 "Paste error": [
  null,
  "שגיאת הדבקה"
 ],
 "Paste the contents of your public SSH key file here": [
  null,
  "עליך להדביק את תוכן קובץ מפתח ה־SSH הציבורי שלך כאן"
 ],
 "Path to directory": [
  null,
  "נתיב לתיקייה"
 ],
 "Path to file": [
  null,
  "הנתיב לקובץ"
 ],
 "Peripheral chassis": [
  null,
  "שלדת התקנים חיצוניים"
 ],
 "Permanently delete $0 group?": [
  null,
  "למחוק את הקבוצה $0 לצמיתות?"
 ],
 "Pick date": [
  null,
  "בחירת תאריך"
 ],
 "Pizza box": [
  null,
  "קופסת פיצה"
 ],
 "Please specify an expiration date": [
  null,
  "נא לציין מועד תפוגת תוקף"
 ],
 "Portable": [
  null,
  "נייד"
 ],
 "Present": [
  null,
  "נוכחי"
 ],
 "Prompting via passwd timed out": [
  null,
  "משך הצגת הבקשה דרך passwd תם"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "משך הצגת הבקשה דרך ssh-add תם"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "משך הצגת הבקשה דרך ssh-keygen תם"
 ],
 "RAID chassis": [
  null,
  "שלדת RAID"
 ],
 "Rack mount chassis": [
  null,
  "שלדת מעגן מתלה (Rack)"
 ],
 "Reboot": [
  null,
  "הפעלה מחדש"
 ],
 "Removals:": [
  null,
  "הסרות:"
 ],
 "Remove": [
  null,
  "הסרה"
 ],
 "Removing $0": [
  null,
  "$0 בהסרה"
 ],
 "Rename": [
  null,
  "שינוי שם"
 ],
 "Rename group": [
  null,
  "שינוי שם של קבוצה"
 ],
 "Rename group $0": [
  null,
  "שינוי שם הקבוצה $0"
 ],
 "Renaming a group may affect sudo and similar rules": [
  null,
  "שינוי שם של קבוצה יכולה להשפיע על sudo ועל כללים דומים"
 ],
 "Require password change every $0 days": [
  null,
  "לדרוש החלפת סיסמה כל $0 ימים"
 ],
 "Require password change on $0": [
  null,
  "לדרוש החלפת סיסמה ב־$0"
 ],
 "Require password change on first login": [
  null,
  "לדרוש החלפת סיסמה בכניסה הראשונה"
 ],
 "Reset password": [
  null,
  "איפוס סיסמה"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  ""
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "מפתח SSH"
 ],
 "Sealed-case PC": [
  null,
  "מחשב במארז אטום"
 ],
 "Search for name or ID": [
  null,
  "חיפוש אחר שם או מזהה"
 ],
 "Search for name, group or ID": [
  null,
  "חיפוש אחר שם, קבוצה או מזהה"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "הגדרות ופתרון תקלות של Security Enhanced Linux"
 ],
 "Server has closed the connection.": [
  null,
  "השרת סגר את החיבור."
 ],
 "Set password": [
  null,
  "הגדרת סיסמה"
 ],
 "Set time": [
  null,
  "הגדרת שעה"
 ],
 "Set weak password": [
  null,
  "הגדרת סיסמה חלשה"
 ],
 "Shell": [
  null,
  "מעטפת"
 ],
 "Shell script": [
  null,
  "סקריפט מעטפת"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show password": [
  null,
  "הצגת הסיסמה"
 ],
 "Shut down": [
  null,
  "כיבוי"
 ],
 "Single rank": [
  null,
  "שורה אחת"
 ],
 "Space-saving computer": [
  null,
  "מחשב חסכוני במקום"
 ],
 "Specific time": [
  null,
  "זמן מסוים"
 ],
 "Started": [
  null,
  "הופעל"
 ],
 "Stick PC": [
  null,
  "מחשב מקלון"
 ],
 "Storage": [
  null,
  "אחסון"
 ],
 "Sub-Chassis": [
  null,
  "תת שלדה"
 ],
 "Sub-Notebook": [
  null,
  "תת מחברת"
 ],
 "Synchronized": [
  null,
  "מסונכרן"
 ],
 "Synchronized with $0": [
  null,
  "מסונכרן עם $0"
 ],
 "Synchronizing": [
  null,
  "מתבצע סנכרון"
 ],
 "Tablet": [
  null,
  "מחשב לוח"
 ],
 "Terminate session": [
  null,
  "חיסול הפעלה"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "מפתח ה־SSH‏ $0 של $1 על גבי $2 יתווסף לקובץ $3 של $4 על גבי $5."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "מפתח ה־SSH‏ $0 יהפוך לזמין עד ליציאה מהמערכת ויהיה זמין לכניסה למארחים אחרים גם כן."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "מפתח ה־SSH לכניסה אל $0 מוגן בסיסמה, והמארח לא מרשה להיכנס למערכת עם סיסמה. נא לספק את הסיסמה למפתח שב־$1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "מפתח ה־SSH לכניסה אל $0 מוגן. יש לך אפשרות להיכנס עם שם המשתמש והסיסמה שלך או על ידי אספקת הסיסמה למפתח שב־$1."
 ],
 "The account '$0' will be forced to change their password on next login": [
  null,
  "החשבון ‚$0’ יאולץ להחליף את הסיסמה שלו עם כניסתו הבאה למערכת"
 ],
 "The fingerprint should match:": [
  null,
  "טביעת האצבע אמורה להיות תואמת:"
 ],
 "The full name must not contain colons.": [
  null,
  "השם המלא לא יכול להכיל נקודתיים."
 ],
 "The group ID must be positive integer": [
  null,
  "מזהה הקבוצה חייב להיות מספר שלם וחיובי"
 ],
 "The group name can only consist of letters from a-z, digits, dots, dashes and underscores": [
  null,
  "שם הקבוצה יכול להיות מורכב מהתווים a-z, ספרות, נקודות, מינוסים וקווים תחתונים"
 ],
 "The home directory $0 already exists. Its ownership will be changed to the new user.": [
  null,
  "תיקיית הבית $0 כבר קיימת. הבעלות עליה תועבר לידי המשתמש החדש."
 ],
 "The key password can not be empty": [
  null,
  "סיסמת המפתח לא יכולה להישאר ריקה"
 ],
 "The key passwords do not match": [
  null,
  "סיסמאות המפתח אינן תואמות"
 ],
 "The key you provided was not valid.": [
  null,
  "המפתח שסיפקת אינו תקף."
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "המשתמש הנוכחי שנכנס למערכת אינו מורשה לצפות בשינויים שבוצעו במערכת"
 ],
 "The password can not be empty": [
  null,
  "סיסמת המפתח לא יכולה להישאר ריקה"
 ],
 "The passwords do not match": [
  null,
  "הסיסמאות אינן תואמות"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "זה בסדר לשתף את טביעת האצבע באופן ציבורי, לרבות בדוא״ל."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  ""
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "השרת סירב לאמת בעזרת השיטות הנתמכות."
 ],
 "The user must log out and log back in for the new configuration to take effect.": [
  null,
  "על המשתמש לצאת ולהיכנס בחזרה למערכת כדי שההגדרות החדשות תיכנסנה לתוקף."
 ],
 "The user name can only consist of letters from a-z, digits, dots, dashes and underscores.": [
  null,
  "שם המשתמש יכול להיות מורכב מהתווים a-z, ספרות, נקודות, מינוסים וקווים תחתונים."
 ],
 "There are no authorized public keys for this account.": [
  null,
  "אין מפתחות ציבוריים מורשים לחשבון זה."
 ],
 "This group is the primary group for the following users:": [
  null,
  "הקבוצה הזאת היא הקבוצה העיקרית של המשתמשים הבאים:"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "הכלי הזה מגדיר את המדיניות של SELinux ויכול לסייע והבנת ופתרון הפרות של המדיניות."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "כלי זה מייצר ארכיון של הגדרות ופרטי ניתוח של המערכת. אפשר לאחסן את הארכיון מקומית או באופן מרכזי למטרות תיעוד או מעקב או לנציגי תמיכה, מתכנתים או מנהלי מערכות כדי שיוכלו לסייע באיתור תקלות טכניות וניפוי שגיאות."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "כלי זה מנהל אחסון מקומי כגון מערכות קבצים, קבוצות כרכים ב־LVM2 ועיגונים של NFS."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  ""
 ],
 "This user name already exists": [
  null,
  "שם משתמש זה כבר קיים"
 ],
 "Time zone": [
  null,
  "אזור זמן"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "כדי לוודא שהחיבור שלך לא מיורט על ידי גורמי צד־שלישי זדוניים, נא לאמת את טביעת האצבע של מפתח המארח:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "כדי לאמת את טביעת האצבע, יש להריץ את הפקודה הבאה על $0 במהלך ישיבה פיזית מול המכונה או דרך רשת מהימנה:"
 ],
 "Toggle date picker": [
  null,
  "החלפת מצב בורר תאריכים"
 ],
 "Too much data": [
  null,
  "יותר מדי נתונים"
 ],
 "Total size: $0": [
  null,
  "גודל כולל: $0"
 ],
 "Tower": [
  null,
  "מארז גבוה"
 ],
 "Trust and add host": [
  null,
  "מתן אמון והוספת מארח"
 ],
 "Trying to synchronize with $0": [
  null,
  "מתבצע ניסיון להסתנכרן מול $0"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "לא ניתן להיכנס אל $0 באמצעות אימות עם מפתח SSH. נא לספק את הסיסמה."
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "לא ניתן להיכנס אל $0. המארח לא מקבל כניסה עם סיסמה או אף אחד ממפתחות ה־SSH האחרים שלך."
 ],
 "Undo": [
  null,
  "ביטול שינוי"
 ],
 "Unexpected error": [
  null,
  "שגיאה בלתי צפויה"
 ],
 "Unknown": [
  null,
  "לא ידוע"
 ],
 "Unknown host: $0": [
  null,
  "מארח לא ידוע: $0"
 ],
 "Unnamed": [
  null,
  "ללא שם"
 ],
 "Untrusted host": [
  null,
  "מארח בלתי מהימן"
 ],
 "Use password": [
  null,
  "להשתמש בסיסמה"
 ],
 "User ID": [
  null,
  "מזהה משתמש"
 ],
 "User ID is already used by another user": [
  null,
  "מזהה משתמש זה כבר בשימוש על ידי משתמש אחר"
 ],
 "User ID must be a positive integer": [
  null,
  "מזהה המשתמש חייב להיות מספר שלם וחיובי"
 ],
 "User ID must not be higher than $0": [
  null,
  "מזהה המשתמש לא יכול להיות גדול מ־$0"
 ],
 "User ID must not be lower than $0": [
  null,
  "מזהה המשתמש לא יכול להיות קטן מ־$0"
 ],
 "User name": [
  null,
  "שם משתמש"
 ],
 "Username": [
  null,
  "שם משתמש"
 ],
 "View all logs": [
  null,
  "הצגת כל היומנים"
 ],
 "View automation script": [
  null,
  "הצגת סקריפט אוטומציה"
 ],
 "Visit firewall": [
  null,
  "ביקור בחומת האש"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "בהמתנה לסיום פעולות ניהול תכנה אחרות"
 ],
 "Weak password": [
  null,
  "סיסמה חלשה"
 ],
 "Web Console for Linux servers": [
  null,
  "מסוף מקוון לשרתי לינוקס"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "זאת ההתחברות הראשונה שלך אל $0."
 ],
 "You do not have permission to view the authorized public keys for this account.": [
  null,
  "אין לך הרשאה לצפות במפתחות ציבוריים מורשים לחשבון זה."
 ],
 "You must wait longer to change your password": [
  null,
  "עליך להמתין זמן רב יותר כדי להחליף את הסיסמה שלך"
 ],
 "Your account": [
  null,
  "החשבון שלך"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "הדפדפן שלך לא מרשה להדביק מתפריט ההקשר. אפשר להשתמש ב־Shift+Insert."
 ],
 "Your session has been terminated.": [
  null,
  "ההפעלה שלך הושמדה."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "תוקף ההפעלה שלך פג. נא להיכנס שוב."
 ],
 "Zone": [
  null,
  "אזור"
 ],
 "[binary data]": [
  null,
  "[נתונים בינריים]"
 ],
 "[no data]": [
  null,
  "[אין נתונים]"
 ],
 "change": [
  null,
  "החלפה"
 ],
 "edit": [
  null,
  "עריכה"
 ],
 "in less than a minute": [
  null,
  "בעוד פחות מדקה"
 ],
 "less than a minute ago": [
  null,
  "לפני פחות מדקה"
 ],
 "password quality": [
  null,
  "איכות הסיסמה"
 ],
 "show less": [
  null,
  "להציג פחות"
 ],
 "show more": [
  null,
  "להציג יותר"
 ],
 "user": [
  null,
  "משתמש"
 ]
});
