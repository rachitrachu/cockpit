cockpit.locale({
 "": {
  "plural-forms": (n) => (n != 1),
  "language": "pt_BR",
  "language-direction": "ltr"
 },
 "Configuring system settings": [
  null,
  "Configurando as definições do sistema"
 ],
 "Diagnostic reports": [
  null,
  "Relatório de diagnostico"
 ],
 "Kernel dump": [
  null,
  "Dump do kernel"
 ],
 "Logs": [
  null,
  "Logs"
 ],
 "Managing services": [
  null,
  "Gerenciando serviços"
 ],
 "Networking": [
  null,
  "Rede"
 ],
 "Overview": [
  null,
  "Visão geral"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Services": [
  null,
  "Serviços"
 ],
 "Storage": [
  null,
  "Armazenamento"
 ],
 "Terminal": [
  null,
  "Terminal"
 ],
 "asset tag": [
  null,
  "etiqueta de ativo"
 ],
 "boot": [
  null,
  "inicialização"
 ],
 "command": [
  null,
  "comando"
 ],
 "console": [
  null,
  "console"
 ],
 "coredump": [
  null,
  "despejo de memória"
 ],
 "cpu": [
  null,
  "cpu"
 ],
 "crash": [
  null,
  "crash"
 ],
 "date": [
  null,
  "data"
 ],
 "debug": [
  null,
  "depurar"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "disable": [
  null,
  "desabilitado"
 ],
 "disks": [
  null,
  "discos"
 ],
 "domain": [
  null,
  "domínio"
 ],
 "enable": [
  null,
  "habilitar"
 ],
 "error": [
  null,
  "erro"
 ],
 "graphs": [
  null,
  "gráficos"
 ],
 "hardware": [
  null,
  "hardware"
 ],
 "history": [
  null,
  "histórico"
 ],
 "host": [
  null,
  "host"
 ],
 "journal": [
  null,
  "registro do log"
 ],
 "machine": [
  null,
  "máquina"
 ],
 "mask": [
  null,
  "máscara"
 ],
 "memory": [
  null,
  "memória"
 ],
 "metrics": [
  null,
  "métricas"
 ],
 "mitigation": [
  null,
  "mitigação"
 ],
 "network": [
  null,
  "rede"
 ],
 "operating system": [
  null,
  "sistema operacional"
 ],
 "os": [
  null,
  "so"
 ],
 "path": [
  null,
  "caminho"
 ],
 "pci": [
  null,
  "pci"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "performance": [
  null,
  "desempenho"
 ],
 "power": [
  null,
  "corrente"
 ],
 "ram": [
  null,
  "ram"
 ],
 "restart": [
  null,
  "reiniciar"
 ],
 "serial": [
  null,
  "série"
 ],
 "service": [
  null,
  "serviço"
 ],
 "shell": [
  null,
  "shell"
 ],
 "shut": [
  null,
  "encerrar"
 ],
 "socket": [
  null,
  "soquete"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "alvo"
 ],
 "time": [
  null,
  "hora"
 ],
 "timer": [
  null,
  "temporizador"
 ],
 "unit": [
  null,
  "unidade"
 ],
 "unmask": [
  null,
  "desmascarar"
 ],
 "version": [
  null,
  "versão"
 ],
 "warning": [
  null,
  "aviso"
 ]
});
