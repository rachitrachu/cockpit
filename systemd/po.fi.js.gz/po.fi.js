cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "fi",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 Git"
 ],
 "$0 critical hit": [
  null,
  "$0 kriittinen osuma",
  "$0 osumaa, sisältäen kriittisiä"
 ],
 "$0 day": [
  null,
  "$0 päivä",
  "$0 päivää"
 ],
 "$0 does not exist": [
  null,
  "$0 ei ole olemassa"
 ],
 "$0 exited with code $1": [
  null,
  "$0 poistui koodilla $1"
 ],
 "$0 failed": [
  null,
  "$0 epäonnistui"
 ],
 "$0 failed login attempt": [
  null,
  "$0 epäonnistunut sisäänkirjautumisyritys",
  "$0 epäonnistutta sisäänkirjautumisyritystä"
 ],
 "$0 filters applied": [
  null,
  "$0 suodatinta toteutettu"
 ],
 "$0 hour": [
  null,
  "$0 tunti",
  "$0 tuntia"
 ],
 "$0 important hit": [
  null,
  "$0 tärkeä osuma",
  "$0 osumaa, mukaan lukien tärkeät"
 ],
 "$0 is not a directory": [
  null,
  "$0 ei ole hakemisto"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 ei ole saatavilla mistään ohjelmistovarastosta."
 ],
 "$0 key changed": [
  null,
  "$0 avain muuttunut"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 tapettu signaalilla $1"
 ],
 "$0 low severity hit": [
  null,
  "$0 matala vakavuus -osuma",
  "$0 matala vakavuus -osumaa"
 ],
 "$0 minute": [
  null,
  "$0 minuutti",
  "$0 minuuttia"
 ],
 "$0 moderate hit": [
  null,
  "$0 kohtalainen osuma",
  "$0 osumia, mukaan lukien kohtalaiset"
 ],
 "$0 month": [
  null,
  "$0 kuukausi",
  "$0 kuukautta"
 ],
 "$0 service has failed": [
  null,
  "$0 palvelu on epäonnistunut",
  "$0 palvelua on epäonnistunut"
 ],
 "$0 week": [
  null,
  "$0 viikko",
  "$0 viikkoa"
 ],
 "$0 will be installed.": [
  null,
  "$0 asennetaan."
 ],
 "$0 year": [
  null,
  "$0 vuosi",
  "$0 vuotta"
 ],
 "1 day": [
  null,
  "1 päivä"
 ],
 "1 hour": [
  null,
  "1 tunti"
 ],
 "1 minute": [
  null,
  "1 minuutti"
 ],
 "1 week": [
  null,
  "1 viikko"
 ],
 "10th": [
  null,
  "10."
 ],
 "11th": [
  null,
  "11."
 ],
 "12th": [
  null,
  "12."
 ],
 "13th": [
  null,
  "13."
 ],
 "14th": [
  null,
  "14."
 ],
 "15th": [
  null,
  "15."
 ],
 "16th": [
  null,
  "16."
 ],
 "17th": [
  null,
  "17."
 ],
 "18th": [
  null,
  "18."
 ],
 "19th": [
  null,
  "19."
 ],
 "1st": [
  null,
  "1."
 ],
 "20 minutes": [
  null,
  "20 minuuttia"
 ],
 "20th": [
  null,
  "20."
 ],
 "21th": [
  null,
  "21."
 ],
 "22th": [
  null,
  "22."
 ],
 "23th": [
  null,
  "23."
 ],
 "24th": [
  null,
  "24."
 ],
 "25th": [
  null,
  "25."
 ],
 "26th": [
  null,
  "26."
 ],
 "27th": [
  null,
  "27."
 ],
 "28th": [
  null,
  "28."
 ],
 "29th": [
  null,
  "29."
 ],
 "2nd": [
  null,
  "2."
 ],
 "30th": [
  null,
  "30."
 ],
 "31st": [
  null,
  "31."
 ],
 "3rd": [
  null,
  "3."
 ],
 "40 minutes": [
  null,
  "40 minuuttia"
 ],
 "4th": [
  null,
  "4."
 ],
 "5 minutes": [
  null,
  "5 minuuttia"
 ],
 "5th": [
  null,
  "5."
 ],
 "6 hours": [
  null,
  "6 tuntia"
 ],
 "60 minutes": [
  null,
  "60 minuuttia"
 ],
 "6th": [
  null,
  "6."
 ],
 "7th": [
  null,
  "7."
 ],
 "8th": [
  null,
  "8."
 ],
 "9th": [
  null,
  "9."
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Yhteensopivaa versiota Cockpitistä ei ole asennettu kohteessa $0."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Uusi SSH-avain nimellä $0 luodaan käyttäjälle $1 koneella $2 ja se lisätään käyttäjän $3 tiedostoon $4 koneella $5."
 ],
 "Absent": [
  null,
  "Poissa"
 ],
 "Acceptable password": [
  null,
  "Hyväksyttävä salasana"
 ],
 "Active since ": [
  null,
  "Aktiivinen lähtien "
 ],
 "Active state": [
  null,
  "Aktiivinen tila"
 ],
 "Add": [
  null,
  "Lisää"
 ],
 "Add $0": [
  null,
  "Lisää $0"
 ],
 "Additional actions": [
  null,
  "Ylimääräiset toimet"
 ],
 "Additional packages:": [
  null,
  "Ylimääräiset paketit:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Hallinta Cockpit-verkkokonsolilla"
 ],
 "Advanced TCA": [
  null,
  "Edistynyt TCA"
 ],
 "After": [
  null,
  "Jälkeen"
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "Kun olet poistunut toimialueesta, vain käyttäjät, joilla on paikalliset kirjautumistiedot, voivat kirjautua tähän koneeseen. Tämä voi vaikuttaa myös muihin palveluihin, kuten DNS-ratkaisimen asetukset, ja luotettujen varmentajien CA-luettelo voi muuttua."
 ],
 "After system boot": [
  null,
  "Järjestelmän käynnistyksen jälkeen"
 ],
 "Alert and above": [
  null,
  "Varoitus ja yli"
 ],
 "Alias": [
  null,
  "Alias"
 ],
 "All": [
  null,
  "Kaikki"
 ],
 "All-in-one": [
  null,
  "Kaikki yhdessä"
 ],
 "Allow running (unmask)": [
  null,
  "Salli, että suoritetaan (paljastaa)"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Ansible-roolien dokumentaatio"
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  "Mikä tahansa tekstimerkkijono lokiviesteissä voidaan suodattaa. Merkkijono voi olla myös säännöllisen lausekkeen muodossa. Tukee myös suodatusta viestilokikenttien mukaan. Nämä ovat välilyönnillä erotettuja arvoja muodossa KENTTÄ=ARVO, jossa arvo voi olla pilkuilla erotettu luettelo mahdollisista arvoista."
 ],
 "Appearance": [
  null,
  "Ulkomuoto"
 ],
 "Apply and reboot": [
  null,
  "Käytä ja käynnistä uudelleen"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  "Uuden käytännön soveltaminen; tämä saattaa kestää muutaman minuutin."
 ],
 "Asset tag": [
  null,
  "Sisältötunniste"
 ],
 "At minute": [
  null,
  "Hetkessä"
 ],
 "At second": [
  null,
  "Toiseksi"
 ],
 "At specific time": [
  null,
  "Tiettynä aikana"
 ],
 "Authentication": [
  null,
  "Tunnistautuminen"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Todennus vaaditaan etuoikeutettujen tehtävien suorittamiseen Cockpit Web Console:ssa"
 ],
 "Authorize SSH key": [
  null,
  "Valtuuta SSH-avain"
 ],
 "Automatically starts": [
  null,
  "Käynnistyy automaattisesti"
 ],
 "Automatically using NTP": [
  null,
  "Käytetään automaattisesti NTP:tä"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Käytetään automaattisesti lisättyjä NTP-palvelimia"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Käytetään automaattisesti tiettyjä NTP-palvelimia"
 ],
 "Automation script": [
  null,
  "Automaatio-komentosarja"
 ],
 "BIOS": [
  null,
  "BIOS"
 ],
 "BIOS date": [
  null,
  "BIOS-päiväys"
 ],
 "BIOS version": [
  null,
  "BIOS-versio"
 ],
 "Bad": [
  null,
  "Huono"
 ],
 "Bad setting": [
  null,
  "Huono asetus"
 ],
 "Before": [
  null,
  "Ennen"
 ],
 "Binds to": [
  null,
  "Sitoo tähän"
 ],
 "Black": [
  null,
  "Musta"
 ],
 "Blade": [
  null,
  "Terä"
 ],
 "Blade enclosure": [
  null,
  "Teräkotelo"
 ],
 "Boot": [
  null,
  "Käynnistys"
 ],
 "Bound by": [
  null,
  "Sillä sidottu"
 ],
 "Bus expansion chassis": [
  null,
  "Väylän laajennusalusta"
 ],
 "CPU": [
  null,
  "Suoritin"
 ],
 "CPU security": [
  null,
  "Suorittimen turvallisuus"
 ],
 "CPU security toggles": [
  null,
  "Suorittimen turvallisuusvalinnat"
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "Lokeja ei löydy käyttämällä nykyistä suodatinten yhdistelmää."
 ],
 "Cancel": [
  null,
  "Peru"
 ],
 "Cancel poweroff": [
  null,
  "Peru sammutus"
 ],
 "Cancel reboot": [
  null,
  "Peru uudelleenkäynnistys"
 ],
 "Cannot be enabled": [
  null,
  "Ei voida ottaa käyttöön"
 ],
 "Cannot forward login credentials": [
  null,
  "Kirjautumistietoja ei voi välittää eteenpäin"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  "Toimialueeseen ei voi liittyä, koska realmd ei ole käytettävissä tässä järjestelmässä"
 ],
 "Cannot schedule event in the past": [
  null,
  "Tapahtumaa ei voi aikatauluttaa menneisyyteen"
 ],
 "Change": [
  null,
  "Vaihda"
 ],
 "Change cryptographic policy": [
  null,
  "Muuta kryptografista käytäntöä"
 ],
 "Change directory": [
  null,
  "Vaihda hakemistoa"
 ],
 "Change host name": [
  null,
  "Vaihda konenimi"
 ],
 "Change performance profile": [
  null,
  "Vaihda suorituskyvyn profiili"
 ],
 "Change profile": [
  null,
  "Vaihda profiili"
 ],
 "Change system time": [
  null,
  "Vaihda järjestelmän aika"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Muutetut avaimet ovat usein seurausta käyttöjärjestelmän uudelleenasennuksesta. Odottamaton muutos voi kuitenkin tarkoittaa kolmannen osapuolen yritystä siepata yhteys."
 ],
 "Changing the directory will forcefully stop the currently running process. The process can also be stopped manually in the terminal before continuing.": [
  null,
  "Hakemiston muuttaminen pysäyttää voimalla parhaillaan käynnissä olevan prosessin. Prosessi voidaan pysäyttää myös manuaalisesti terminaalissa ennen jatkamista."
 ],
 "Checking installed software": [
  null,
  "Tarkistetaan asennettu ohjelmisto"
 ],
 "Class": [
  null,
  "Luokka"
 ],
 "Clear 'Failed to start'": [
  null,
  "Tyhjennä \"Aloitus epäonnistui\""
 ],
 "Clear all filters": [
  null,
  "Tyhjennä kaikki suodattimet"
 ],
 "Clear input value": [
  null,
  "Tyhjennä syöttöarvo"
 ],
 "Client software": [
  null,
  "Asiakasohjelmisto"
 ],
 "Close": [
  null,
  "Sulje"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "NetworkManagerin ja Firewalld:n Cockit-asetukset"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit ei saanut yhteyttä koneeseen."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit on palvelinhallintatyökalu, joka tekee ylläpidon helpoksi selaimen kautta. Liikkuminen päätteen ja verkkokäyttöliittymän välillä ei ole ongelma. Cockpitissä aloitettu palvelu voidaan lopettaa päätteessä. Samaten päätteessä näkyvä virheilmoitus voidaan nähdä myös Cockpitin journal-näkymässä."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit ei ole yhteensopiva järjestelmän ohjelmiston kanssa."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit ei ole asennettu"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit ei ole asennettu järjestelmässä."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit on täydellinen uusille ylläpitäjille. Sen avulla voi tehdä helposti toimenpiteitä kuten tallennustilan hallintaa, lokien tarkistamista sekä palveluiden käynnistämistä ja lopettamista. Voit monitoroida ja hallita useita palvelimia samanaikaisesti. Lisää ne yhdellä napsautuksella ja koneesi katsovat kavereidensa perään."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Kerää ja paketoi diagnostiikkaa ja tukitietoja"
 ],
 "Collect kernel crash dumps": [
  null,
  "Kerää ytimen kaatumisvedoksia"
 ],
 "Command": [
  null,
  "Komento"
 ],
 "Command not found": [
  null,
  "Komentoa ei löytynyt"
 ],
 "Communication with tuned has failed": [
  null,
  "Yhteydenpito tuned:n kanssa epäonnistui"
 ],
 "Compact PCI": [
  null,
  "Kompakti PCI"
 ],
 "Condition $0=$1 was not met": [
  null,
  "Ehto $0=$1 ei toteutunut"
 ],
 "Condition failed": [
  null,
  "Ehto epäonnistui"
 ],
 "Configuration": [
  null,
  "Kokoonpano"
 ],
 "Confirm deletion of $0": [
  null,
  "Vahvista kohteen $0 poistaminen"
 ],
 "Confirm key password": [
  null,
  "Vahvista avaimen salasana"
 ],
 "Conflicted by": [
  null,
  "Näiden kanssa ristiriitainen"
 ],
 "Conflicts": [
  null,
  "Ristiriidat"
 ],
 "Connecting to dbus failed: $0": [
  null,
  "Yhteyden muodostaminen dbus-verkkoon epäonnistui: $0"
 ],
 "Connection has timed out.": [
  null,
  "Yhteys aikakatkaistiin."
 ],
 "Consists of": [
  null,
  "Näistä koostuu"
 ],
 "Contacted domain": [
  null,
  "Toimialue, johon otettiin yhteyttä"
 ],
 "Convertible": [
  null,
  "Muunnettavissa"
 ],
 "Copied": [
  null,
  "Kopioitu"
 ],
 "Copy": [
  null,
  "Kopio"
 ],
 "Copy to clipboard": [
  null,
  "Kopioi leikepöydälle"
 ],
 "Create $0": [
  null,
  "Luo $0"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Luo uusi SSH-avain ja valtuuta se"
 ],
 "Create new task file with this content.": [
  null,
  "Luo uusi tehtävätiedosto tällä sisällöllä."
 ],
 "Create timer": [
  null,
  "Luo ajastin"
 ],
 "Critical and above": [
  null,
  "Kriittinen ja yli"
 ],
 "Cryptographic Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  "Kryptografiset käytännöt on järjestelmäkomponentti, joka määrittää keskeiset salausalijärjestelmät, jotka kattavat TLS-, IPSec-, SSH-, DNSSec- ja Kerberos-protokollat."
 ],
 "Cryptographic policy": [
  null,
  "Kryptografinen käytäntö"
 ],
 "Cryptographic policy is inconsistent": [
  null,
  "Kryptografinen käytäntö on epäjohdonmukainen"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Current boot": [
  null,
  "Tämänhetkinen käynnistys"
 ],
 "Custom cryptographic policy": [
  null,
  "Mukautettu kryptografinen käytäntö"
 ],
 "DEFAULT with SHA-1 signature verification allowed.": [
  null,
  "OLETUS, SHA-1-allekirjoituksen vahvistus sallittu."
 ],
 "Daily": [
  null,
  "Joka päivä"
 ],
 "Dark": [
  null,
  "Tumma"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  "Päivämäärätietojen on oltava muodossa VVVV-KK-PP tt:mm:ss. Vaihtoehtoisesti merkkijonot \"eilen\", \"tänään\", \"huomenna\" ymmärretään. \"nyt\" viittaa nykyiseen aikaan. Lopuksi suhteelliset ajat voidaan määrittää etuliitteellä '-' tai '+'"
 ],
 "Debug and above": [
  null,
  "Virheenkorjaus ja yli"
 ],
 "Decrease by one": [
  null,
  "Vähennä yhdellä"
 ],
 "Default": [
  null,
  "Oletus"
 ],
 "Delay": [
  null,
  "Viive"
 ],
 "Delay must be a number": [
  null,
  "Viiveen tulee olla numero"
 ],
 "Delete": [
  null,
  "Poista"
 ],
 "Deletion will remove the following files:": [
  null,
  "Poistaminen poistaa seuraavat tiedostot:"
 ],
 "Description": [
  null,
  "Kuvaus"
 ],
 "Desktop": [
  null,
  "Työpöytä"
 ],
 "Detachable": [
  null,
  "Irrotettava"
 ],
 "Details": [
  null,
  "Yksityiskohdat"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostiikkaraportit"
 ],
 "Disable simultaneous multithreading": [
  null,
  "Poista samanaikainen monisäikeisyys käytöstä"
 ],
 "Disable tuned": [
  null,
  "Poista tuned käytöstä"
 ],
 "Disabled": [
  null,
  "Ei käytössä"
 ],
 "Disallow running (mask)": [
  null,
  "Estä suorittaminen (piilota)"
 ],
 "Docking station": [
  null,
  "Telakka"
 ],
 "Does not automatically start": [
  null,
  "Ei käynnisty automaattisesti"
 ],
 "Domain": [
  null,
  "Toimialue"
 ],
 "Domain address": [
  null,
  "Toimialue-osoite"
 ],
 "Domain administrator name": [
  null,
  "Toimialueen ylläpitäjän nimi"
 ],
 "Domain administrator password": [
  null,
  "Toimialueen ylläpitäjän salasana"
 ],
 "Domain could not be contacted": [
  null,
  "Toimialueeseen ei saatu yhteyttä"
 ],
 "Domain is not supported": [
  null,
  "Toimialue ei ole tuettu"
 ],
 "Don't repeat": [
  null,
  "Älä toista"
 ],
 "Downloading $0": [
  null,
  "Ladataan $0"
 ],
 "Dual rank": [
  null,
  "Kaksinkertainen sijoitus"
 ],
 "Edit /etc/motd": [
  null,
  "Muokkaa /etc/motd"
 ],
 "Edit motd": [
  null,
  "Muokkaa motd-tiedostoa"
 ],
 "Embedded PC": [
  null,
  "Sulautettu tietokone"
 ],
 "Enabled": [
  null,
  "Käytössä"
 ],
 "Entry at $0": [
  null,
  "Merkintä $0:lla"
 ],
 "Error": [
  null,
  "Virhe"
 ],
 "Error and above": [
  null,
  "Virhe ja yli"
 ],
 "Error message": [
  null,
  "Virheviesti"
 ],
 "Excellent password": [
  null,
  "Erinomainen salasana"
 ],
 "Expansion chassis": [
  null,
  "Laajennusrunko"
 ],
 "FIPS is not properly enabled": [
  null,
  "FIPS ei ole otettu oikein käyttöön"
 ],
 "FIPS with further Common Criteria restrictions.": [
  null,
  "FIPS jossa muita yleisiä kriteerejä koskevia rajoituksia."
 ],
 "Failed to change password": [
  null,
  "Salasanan vaihtaminen epäonnistui"
 ],
 "Failed to disable tuned": [
  null,
  "tuned:n käytöstä poistaminen epäonnistui"
 ],
 "Failed to disable tuned profile": [
  null,
  "muokatun profiilin käytöstä poistaminen epäonnistui"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "$0:n käyttöönotto firewalld:ssä epäonnistui"
 ],
 "Failed to enable tuned": [
  null,
  "tuned:n käyttöönotto epäonnistui"
 ],
 "Failed to fetch logs": [
  null,
  "Logien nouto epäonnistui"
 ],
 "Failed to load unit": [
  null,
  "Yksikön lataaminen epäonnistui"
 ],
 "Failed to save changes in /etc/motd": [
  null,
  "Muutosten tallentaminen /etc/motd:een epäonnistui"
 ],
 "Failed to start": [
  null,
  "Käynnistäminen epäonnistui"
 ],
 "Failed to switch profile": [
  null,
  "Profiilin vaihtaminen epäonnistui"
 ],
 "File state": [
  null,
  "Tiedoston tila"
 ],
 "Filter by name or description": [
  null,
  "Suodata nimen tai kuvauksen mukaan"
 ],
 "Filters": [
  null,
  "Suotimet"
 ],
 "Font size": [
  null,
  "Kirjasinkoko"
 ],
 "Forbidden from running": [
  null,
  "Kielletty suorittamasta"
 ],
 "Free-form search": [
  null,
  "Vapaamuotoinen haku"
 ],
 "Fridays": [
  null,
  "Perjantai"
 ],
 "Generated": [
  null,
  "Luotu"
 ],
 "Go to $0": [
  null,
  "Mene kohteeseen $0"
 ],
 "Go to now": [
  null,
  "Mene nyt"
 ],
 "Handheld": [
  null,
  "Kädessä pidettävä"
 ],
 "Hardware information": [
  null,
  "Laitteistotiedot"
 ],
 "Health": [
  null,
  "Terveys"
 ],
 "Help": [
  null,
  "Ohje"
 ],
 "Hide confirmation password": [
  null,
  "Piilota salasanan vahvistus"
 ],
 "Hide password": [
  null,
  "Piilota salasana"
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  "Parempi yhteentoimivuus lisääntyneen hyökkäysrajapinnan kustannuksella."
 ],
 "Host key is incorrect": [
  null,
  "Koneen avain on väärin"
 ],
 "Hostname": [
  null,
  "Koneen nimi"
 ],
 "Hourly": [
  null,
  "Joka tunti"
 ],
 "Hours": [
  null,
  "Tuntia"
 ],
 "ID": [
  null,
  "Tunniste"
 ],
 "Identifier": [
  null,
  "Tunniste"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Jos sormenjälki on sama, napsauta 'Luota ja lisää yhteys'. Muussa tapauksessa älä muodosta yhteyttä ja ota yhteyttä järjestelmänvalvojaan."
 ],
 "Increase by one": [
  null,
  "Lisää yhdellä"
 ],
 "Indirect": [
  null,
  "Epäsuora"
 ],
 "Info and above": [
  null,
  "Tiedot ja yli"
 ],
 "Insights: ": [
  null,
  "Oivalluksia: "
 ],
 "Install": [
  null,
  "Asennus"
 ],
 "Install realmd support": [
  null,
  "Asenna realmd-tuki"
 ],
 "Install software": [
  null,
  "Asennetaan ohjelmistoja"
 ],
 "Installing $0": [
  null,
  "Asennetaan $0"
 ],
 "Internal error": [
  null,
  "Sisäinen virhe"
 ],
 "Invalid": [
  null,
  "Virheellinen"
 ],
 "Invalid date format": [
  null,
  "Virheellinen päivämuoto"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Virheellinen päivämuoto ja aikamuoto"
 ],
 "Invalid file permissions": [
  null,
  "Virheelliset tiedosto-oikeudet"
 ],
 "Invalid time format": [
  null,
  "Virheellinen aikamuoto"
 ],
 "Invalid timezone": [
  null,
  "Virheellinen aikavyöhyke"
 ],
 "IoT gateway": [
  null,
  "IoT -yhdyskäytävä"
 ],
 "Join": [
  null,
  "Liity"
 ],
 "Join domain": [
  null,
  "Liity toimialueeseen"
 ],
 "Joining": [
  null,
  "Liitytään"
 ],
 "Joining a domain requires installation of realmd": [
  null,
  "Toimialueeseen liittyminen vaatii realmd:n asentamisen"
 ],
 "Joining this domain is not supported": [
  null,
  "Liittyminen tähän toimialueeseen ei ole tuettu"
 ],
 "Joins namespace of": [
  null,
  "Liittyy tämän nimitilaan"
 ],
 "Journal": [
  null,
  "Päiväkirja"
 ],
 "Journal entry": [
  null,
  "Päiväkirjan tietue"
 ],
 "Journal entry not found": [
  null,
  "Päiväkirjan tietuetta ei löytynyt"
 ],
 "Kernel dump": [
  null,
  "Ytimen tyhjennys"
 ],
 "Key password": [
  null,
  "Avaimen salasana"
 ],
 "LEGACY with Active Directory interoperability.": [
  null,
  "LEGACY Active Directoryn yhteentoimivuudella."
 ],
 "Laptop": [
  null,
  "Kannettava"
 ],
 "Last 24 hours": [
  null,
  "Viimeiset 24 tuntia"
 ],
 "Last 7 days": [
  null,
  "Viimeiset 7 päivää"
 ],
 "Last successful login:": [
  null,
  "Edellinen onnistunut kirjautuminen:"
 ],
 "Learn more": [
  null,
  "Opi lisää"
 ],
 "Leave $0": [
  null,
  "Poistu $0:sta"
 ],
 "Leave domain": [
  null,
  "Jätä toimialue"
 ],
 "Light": [
  null,
  "Vaalea"
 ],
 "Linked": [
  null,
  "Linkitetty"
 ],
 "Listen": [
  null,
  "Kuuntele"
 ],
 "Listing units": [
  null,
  "Listauksen yksiköt"
 ],
 "Listing units failed: $0": [
  null,
  "Yksiköiden listaus epäonnistui: $0"
 ],
 "Load earlier entries": [
  null,
  "Lataa aiemmat merkinnät"
 ],
 "Loading keys...": [
  null,
  "Ladataan avaimet..."
 ],
 "Loading of SSH keys failed": [
  null,
  "SSH-avainten lataaminen epäonnistui"
 ],
 "Loading of units failed": [
  null,
  "Yksiköiden lataus epäonnistui"
 ],
 "Loading system modifications...": [
  null,
  "Ladataan järjestelmän muutoksia ..."
 ],
 "Loading unit failed": [
  null,
  "Yksiköiden lataus epäonnistui"
 ],
 "Loading...": [
  null,
  "Ladataan..."
 ],
 "Log in": [
  null,
  "Kirjaudu sisään"
 ],
 "Log in to $0": [
  null,
  "Kirjaudu kohteeseen $0"
 ],
 "Log messages": [
  null,
  "Kirjaa viestit"
 ],
 "Login failed": [
  null,
  "Kirjautuminen epäonnistui"
 ],
 "Login format": [
  null,
  "Sisäänkirjautumisen muoto"
 ],
 "Logs": [
  null,
  "Lokit"
 ],
 "Low profile desktop": [
  null,
  "Matalan tason työpöytä"
 ],
 "Lunch box": [
  null,
  "Eväslaatikko"
 ],
 "Machine ID": [
  null,
  "Koneen ID"
 ],
 "Machine SSH key fingerprints": [
  null,
  "Koneen SSH-avaimen sormenjäljet"
 ],
 "Main server chassis": [
  null,
  "Pääpalvelimen runko"
 ],
 "Maintenance": [
  null,
  "Ylläpito"
 ],
 "Manage storage": [
  null,
  "Tallennustilan hallinta"
 ],
 "Manually": [
  null,
  "Manuaalisesti"
 ],
 "Mask service": [
  null,
  "Piilota palvelu"
 ],
 "Masked": [
  null,
  "Piilotettu"
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  "Palvelun piilottaminen estää kaikkia riippuvaisia yksiköitä toimimasta. Tällä voi olla odotettua suurempi vaikutus. Vahvista, että haluat piilottaa tämän yksikön."
 ],
 "Memory": [
  null,
  "Muisti"
 ],
 "Memory technology": [
  null,
  "Muistitekniikka"
 ],
 "Merged": [
  null,
  "Yhdistetty"
 ],
 "Message to logged in users": [
  null,
  "Viesti sisäänkirjautuneille käyttäjille"
 ],
 "Mini PC": [
  null,
  "Minitietokone"
 ],
 "Mini tower": [
  null,
  "Minitorni"
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "Minuutit tulee olla esitetty numerovälillä 0-59"
 ],
 "Minutely": [
  null,
  "Tarkasti"
 ],
 "Minutes": [
  null,
  "Minuutit"
 ],
 "Mitigations": [
  null,
  "Lievennykset"
 ],
 "Model": [
  null,
  "Malli"
 ],
 "Mondays": [
  null,
  "Maanantai"
 ],
 "Monthly": [
  null,
  "Joka kuukausi"
 ],
 "Multi-system chassis": [
  null,
  "Monijärjestelmäinen alusta"
 ],
 "NTP server": [
  null,
  "NTP-palvelin"
 ],
 "Name": [
  null,
  "Nimi"
 ],
 "Need at least one NTP server": [
  null,
  "Tarvitaan vähintään yksi NTP-palvelin"
 ],
 "Networking": [
  null,
  "Verkko"
 ],
 "New password was not accepted": [
  null,
  "Uutta salasanaa ei hyväksytty"
 ],
 "No delay": [
  null,
  "Ei viivettä"
 ],
 "No host keys found.": [
  null,
  "Koneen avaimia ei löytynyt."
 ],
 "No log entries": [
  null,
  "Ei lokimerkintöjä"
 ],
 "No logs found": [
  null,
  "Ei löytynyt lokeja"
 ],
 "No matching results": [
  null,
  "Ei vastaavia tuloksia"
 ],
 "No results found": [
  null,
  "Tuloksia ei löytynyt"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  "Ei tuloksia, jotka vastaavat suodatinkriteerejä. Tyhjennä kaikki suodattimet nähdäksesi tulokset."
 ],
 "No rule hits": [
  null,
  "Ei sääntöosumia"
 ],
 "No such file or directory": [
  null,
  "Tiedostoa tai hakemistoa ei löydy"
 ],
 "No system modifications": [
  null,
  "Ei järjestelmän muutoksia"
 ],
 "None": [
  null,
  "Ei yhtään"
 ],
 "Not a valid private key": [
  null,
  "Ei kelvollinen yksityinen avain"
 ],
 "Not connected to Insights": [
  null,
  "Ei yhdistetty tilastoihin"
 ],
 "Not found": [
  null,
  "Ei löytynyt"
 ],
 "Not permitted to configure realms": [
  null,
  "Alueen määrittäminen ei ole sallittua"
 ],
 "Not permitted to perform this action.": [
  null,
  "Ei oikeutta suorittaa tätä toimintoa."
 ],
 "Not running": [
  null,
  "Ei käynnissä"
 ],
 "Not synchronized": [
  null,
  "Ei synkronisoitu"
 ],
 "Note": [
  null,
  "Huomautus"
 ],
 "Notebook": [
  null,
  "Muistikirja"
 ],
 "Notice and above": [
  null,
  "Ilmoitus ja yli"
 ],
 "Occurrences": [
  null,
  "Tapahtumat"
 ],
 "Ok": [
  null,
  "Hyvä on"
 ],
 "Old password not accepted": [
  null,
  "Vanhaa salasanaa ei hyväksytty"
 ],
 "On failure": [
  null,
  "Epäonnistumisesta"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Kun Cockpit on asennettu, ota se käyttöön 'systemctl enable --now cockpit.socket'."
 ],
 "Only alphabets, numbers, : , _ , . , @ , - are allowed": [
  null,
  "Vain aakkoset, numerot, : , _ , . , @ , - ovat sallittuja"
 ],
 "Only emergency": [
  null,
  "Vain hätätilanne"
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  "Käytä vain hyväksyttyjä ja sallittuja algoritmeja käynnistettäessä FIPS-tilassa."
 ],
 "Other": [
  null,
  "Muu"
 ],
 "Overview": [
  null,
  "Esittely"
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit kaatui"
 ],
 "Part of": [
  null,
  "Osa tätä"
 ],
 "Password": [
  null,
  "Salasana"
 ],
 "Password is not acceptable": [
  null,
  "Salasana ei ole hyväksyttävä"
 ],
 "Password is too weak": [
  null,
  "Salasana on liian heikko"
 ],
 "Password not accepted": [
  null,
  "Salasanaa ei hyväksytty"
 ],
 "Paste": [
  null,
  "Siirrä"
 ],
 "Paste error": [
  null,
  "Liittämisvirhe"
 ],
 "Path": [
  null,
  "Polku"
 ],
 "Path to file": [
  null,
  "Polku tiedostoon"
 ],
 "Paths": [
  null,
  "Polut"
 ],
 "Pause": [
  null,
  "Keskeytä"
 ],
 "Performance profile": [
  null,
  "Suorituskykyprofiili"
 ],
 "Peripheral chassis": [
  null,
  "Lisälaitteen kotelo"
 ],
 "Pick date": [
  null,
  "Valitse päivämäärä"
 ],
 "Pin unit": [
  null,
  "Merkitse yksikkö"
 ],
 "Pinned unit": [
  null,
  "Merkitty yksikkö"
 ],
 "Pizza box": [
  null,
  "Pizza-laatikko"
 ],
 "Portable": [
  null,
  "Kannettava"
 ],
 "Present": [
  null,
  "Nykyinen"
 ],
 "Pretty host name": [
  null,
  "Tyylikäs konenimi"
 ],
 "Previous boot": [
  null,
  "Edellinen käynnistys"
 ],
 "Priority": [
  null,
  "Prioriteetti"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Kysely 'ssh-add':in kautta aikakatkaistiin"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Kysely 'ssh-keygen':in kautta aikakatkaistiin"
 ],
 "Propagates reload to": [
  null,
  "Laajentaa uudelleenlatausta kohteeseen"
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  "Suojaa ennakoiduilta lähiajan hyökkäyksiltä yhteentoimivuuden kustannuksella."
 ],
 "RAID chassis": [
  null,
  "RAID-runko"
 ],
 "Rack mount chassis": [
  null,
  "Räkkiin liitettävä runko"
 ],
 "Rank": [
  null,
  "Sijoitus"
 ],
 "Read more...": [
  null,
  "Lue lisää..."
 ],
 "Read-only": [
  null,
  "Vain luku"
 ],
 "Real host name": [
  null,
  "Oikea konenimi"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "Oikea konenimi voi sisältää vain pieniä kirjaimia, numeroita, viivoja ja pisteitä (täytetyillä alitoimialueilla)"
 ],
 "Real host name must be 64 characters or less": [
  null,
  "Oikea konenimi saa sisältää enintään 64 merkkiä"
 ],
 "Reapply and reboot": [
  null,
  "Ota käyttöön uudelleen ja käynnistä uudelleen"
 ],
 "Reboot": [
  null,
  "Käynnistä uudelleen"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  "Suositeltu, turvalliset asetukset nykyisiä uhkamalleja vastaan."
 ],
 "Reload": [
  null,
  "Lataa uudelleen"
 ],
 "Reload propagated from": [
  null,
  "Uudelleenlataus levitetty tältä"
 ],
 "Reloading": [
  null,
  "Ladataan uudelleen"
 ],
 "Removals:": [
  null,
  "Poistot:"
 ],
 "Remove": [
  null,
  "Poista"
 ],
 "Removing $0": [
  null,
  "Poistetaan $0"
 ],
 "Repeat": [
  null,
  "Toista"
 ],
 "Repeat monthly": [
  null,
  "Toista joka kuukausi"
 ],
 "Repeat weekly": [
  null,
  "Toista joka viikko"
 ],
 "Required by": [
  null,
  "Tämän edellyttämänä"
 ],
 "Required by ": [
  null,
  "Tämän edellyttämänä "
 ],
 "Requires": [
  null,
  "Vaatii"
 ],
 "Requires administration access to edit": [
  null,
  "Muokkaaminen edellyttää ylläpitäjän käyttöoikeuksia"
 ],
 "Requisite": [
  null,
  "Vaaditaan"
 ],
 "Requisite of": [
  null,
  "Tämä vaaditaan"
 ],
 "Reset": [
  null,
  "Nollaa"
 ],
 "Restart": [
  null,
  "Käynnistä uudelleen"
 ],
 "Resume": [
  null,
  "Palauta"
 ],
 "Review cryptographic policy": [
  null,
  "Tarkastele kryptografista käytäntöä"
 ],
 "Row expansion": [
  null,
  "Rivin laajennus"
 ],
 "Row select": [
  null,
  "Rivin valinta"
 ],
 "Run at": [
  null,
  "Aja klo"
 ],
 "Run on": [
  null,
  "Aja kohteessa"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Suorita tämä komento luotetussa verkossa tai fyysisesti etäkoneella:"
 ],
 "Running": [
  null,
  "Käynnissä"
 ],
 "Running process prevents directory change": [
  null,
  "Prosessin suorittaminen estää hakemiston muuttamisen"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "SSH-avain"
 ],
 "SSH key login": [
  null,
  "SSH-avaimen sisäänkirjautuminen"
 ],
 "Saturdays": [
  null,
  "Lauantai"
 ],
 "Save": [
  null,
  "Tallenna"
 ],
 "Save and reboot": [
  null,
  "Tallenna ja käynnistä uudelleen"
 ],
 "Save changes": [
  null,
  "Tallenna muutokset"
 ],
 "Scheduled poweroff at $0": [
  null,
  "Ajastettu sammutus $0"
 ],
 "Scheduled reboot at $0": [
  null,
  "Ajastettu sammutus kello $0"
 ],
 "Sealed-case PC": [
  null,
  "Suljettu tietokonekotelo"
 ],
 "Search": [
  null,
  "Haku"
 ],
 "Second needs to be a number between 0-59": [
  null,
  "Sekuntit tulee olla esitetty numerovälillä 0-59"
 ],
 "Seconds": [
  null,
  "Sekunnit"
 ],
 "Secure shell keys": [
  null,
  "Secure shell -avaimet"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Security Enhanced Linuxin asetukset ja ongelmanratkaisu"
 ],
 "Select an option": [
  null,
  "Valitse vaihtoehto"
 ],
 "Server has closed the connection.": [
  null,
  "Palvelin on sulkenut yhteyden."
 ],
 "Server software": [
  null,
  "Palvelinohjelmisto"
 ],
 "Service logs": [
  null,
  "Palvelulokit"
 ],
 "Services": [
  null,
  "Palvelut"
 ],
 "Set hostname": [
  null,
  "Määritä konenimi"
 ],
 "Set time": [
  null,
  "Aseta aika"
 ],
 "Shell script": [
  null,
  "Komentotulkin komentosarja"
 ],
 "Shift+Insert": [
  null,
  "Vaihto + Syöttö"
 ],
 "Show confirmation password": [
  null,
  "Näytä salasanan vahvistus"
 ],
 "Show fingerprints": [
  null,
  "Näytä sormenjäljet"
 ],
 "Show messages containing given string.": [
  null,
  "Näytä viestit, jotka sisältävät annetun merkkijonon."
 ],
 "Show messages for the specified systemd unit.": [
  null,
  "Näytä määritetyn järjestelmäyksikön viestit."
 ],
 "Show messages from a specific boot.": [
  null,
  "Näytä viestit tietystä käynnistyksestä."
 ],
 "Show more relationships": [
  null,
  "Näytä lisää suhteita"
 ],
 "Show password": [
  null,
  "Näytä salasana"
 ],
 "Show relationships": [
  null,
  "Näytä suhteet"
 ],
 "Shut down": [
  null,
  "Sammuta"
 ],
 "Shutdown": [
  null,
  "Sammuta"
 ],
 "Since": [
  null,
  "Siitä asti kun"
 ],
 "Single rank": [
  null,
  "Yksi sijoitus"
 ],
 "Size": [
  null,
  "Koko"
 ],
 "Slot": [
  null,
  "Paikka"
 ],
 "Sockets": [
  null,
  "Pistokkeet"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  "Ohjelmistopohjaiset ratkaisut auttavat estämään suorittimen tietoturvaongelmia. Näillä lievennyksillä on sivuvaikutus suorituskyvyn heikentämisessä. Muuta näitä asetuksia omalla vastuullasi."
 ],
 "Space-saving computer": [
  null,
  "Tilaa säästävä tietokone"
 ],
 "Specific time": [
  null,
  "Tietty aika"
 ],
 "Speed": [
  null,
  "Nopeus"
 ],
 "Start": [
  null,
  "Käynnistä"
 ],
 "Start and enable": [
  null,
  "Käynnistä ja ota käyttöön"
 ],
 "Start service": [
  null,
  "Käynnistä palvelu"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  "Aloita merkintöjen näyttäminen määritetystä tai sitä myöhemmästä päivästä."
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  "Aloita merkintöjen näyttäminen määritetystä tai sitä aiemmasta päivästä."
 ],
 "State": [
  null,
  "Tila"
 ],
 "Static": [
  null,
  "Staattinen"
 ],
 "Status": [
  null,
  "Tila"
 ],
 "Stick PC": [
  null,
  "Tikku-PC"
 ],
 "Stop": [
  null,
  "Pysäytä"
 ],
 "Stop and disable": [
  null,
  "Pysäytä ja poista käytöstä"
 ],
 "Storage": [
  null,
  "Tallennustila"
 ],
 "Strong password": [
  null,
  "Vahva salasana"
 ],
 "Stub": [
  null,
  "Tynkä"
 ],
 "Sub-Chassis": [
  null,
  "Alirunko"
 ],
 "Sub-Notebook": [
  null,
  "Pieni kannettava tietokone"
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  "Systemd-signaalien tilaaminen epäonnistui: $0"
 ],
 "Successfully copied to clipboard": [
  null,
  "Kopioitu onnistuneesti leikepöydälle"
 ],
 "Sundays": [
  null,
  "Sunnuntai"
 ],
 "Synchronized": [
  null,
  "Synkronoitu"
 ],
 "Synchronized with $0": [
  null,
  "Synkronoi palvelimen $0 kanssa"
 ],
 "Synchronizing": [
  null,
  "Synkronoidaan"
 ],
 "System": [
  null,
  "Järjestelmä"
 ],
 "System information": [
  null,
  "Järjestelmätiedot"
 ],
 "System time": [
  null,
  "Järjestelmän aika"
 ],
 "Systemd units": [
  null,
  "Systemd-yksiköt"
 ],
 "Tablet": [
  null,
  "Tabletti"
 ],
 "Targets": [
  null,
  "Kohteet"
 ],
 "Terminal": [
  null,
  "Pääte"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "Käyttäjän $0:n SSH-avain $1 koneella $2 lisätään käyttäjän $4 tiedostoon $3 koneella $5."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH-avain $0 on käytettävissä koko istunnon ajan ja on käytettävissä myös muille koneille sisäänkirjautumista varten."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "SSH-avain koneelle $0 sisäänkirjautumista varten on suojattu salasanalla, eikä kone salli salasanalla kirjautumista. Anna avaimen $1 salasana."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "SSH-avain koneelle $0 sisäänkirjautumista varten on suojattu. Voit kirjautua sisään joko kirjautumissalasanallasi tai antamalla avaimen $1 salasanan."
 ],
 "The fingerprint should match:": [
  null,
  "Sormenjäljen tulee vastata:"
 ],
 "The key password can not be empty": [
  null,
  "Avaimen salasana ei voi olla tyhjä"
 ],
 "The key passwords do not match": [
  null,
  "Avainsalasanat eivät täsmää"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Sisäänkirjautunut käyttäjä ei saa tarkastella järjestelmän muutoksia"
 ],
 "The password can not be empty": [
  null,
  "Salasana ei voi olla tyhjä"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Tuloksena oleva sormenjälki sopii jakaa julkisilla menetelmillä, mukaan lukien sähköposti."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Tuloksena oleva sormenjälki sopii jaettavaksi julkisilla menetelmillä, mukaan lukien sähköposti. Jos pyydät jotakuta toista suorittamaan vahvistuksen puolestasi, hän voi lähettää tulokset millä tahansa menetelmällä."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Palvelin kieltäytyi tunnistautumista käyttäen mitään tuetuista tavoista."
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  "Käyttäjä $0 ei saa muuttaa suorittimen suojauksen lievennyksiä"
 ],
 "The user $0 is not permitted to change cryptographic policies": [
  null,
  "Käyttäjällä $0 ei ole oikeutta muokata kryptografisia käytäntöjä"
 ],
 "This field cannot be empty": [
  null,
  "Tämä kenttä ei voi olla tyhjä"
 ],
 "This may take a while": [
  null,
  "Tässä voi mennä hetki"
 ],
 "This system is using a custom profile": [
  null,
  "Tämä järjestelmä käyttää mukautettua profiilia"
 ],
 "This system is using the recommended profile": [
  null,
  "Tämä järjestelmä käyttää suositeltua profiilia"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Tämä työkalu asettaa SELinux-käytännön ja auttaa käytäntörikkeiden ymmärtämisessä ja ratkaisemisessa."
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Tämä työkalu määrittää järjestelmän kirjoittamaan ytimen kaatumisvedoksia. Se tukee \"paikallisia\" (levy-), \"ssh\"- ja \"nfs\"-vedoskohteita."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Tämä työkalu luo arkiston konfiguraatio- ja diagnostiikkatiedoista käynnissä olevasta järjestelmästä. Arkisto voidaan tallentaa paikallisesti tai keskitetysti tallennus- tai seurantatarkoituksiin tai se voidaan lähettää teknisen tuen edustajille, kehittäjille tai järjestelmänvalvojille auttamaan teknisten vikojen etsinnässä ja virheenkorjauksessa."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Tämä työkalu hallinnoi paikallista tallennustilaa, kuten tiedostojärjestelmiä, LVM2-taltioryhmiä ja NFS-liitoksia."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Tämä työkalu hallitsee verkkoyhteyksiä, kuten sidoksia, siltoja, ryhmiä, VLAN-verkkoja ja palomuureja NetworkManagerin ja Firewalld:n avulla. NetworkManager ei ole yhteensopiva Ubuntun oletusarvoisten systemd-networkd- ja Debianin ifupdown-komentosarjojen kanssa."
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  "Tätä yksikköä ei ole suunniteltu nimenomaisesti käytettäväksi."
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  "Tämä lisää osuman '_BOOT_ID ='. Jos sitä ei ole määritetty, nykyisen käynnistyksen lokit näytetään. Jos käynnistystunnus jätetään pois, positiivinen siirtymä etsii käynnistykset päiväkirjan alusta alkaen ja yhtä suuri tai pienempi kuin nolla-siirtymä etsii käynnistykset päiväkirjan lopusta alkaen. Siten 1 tarkoittaa ensimmäistä löydettyä käynnistystä päiväkirjassa aikajärjestyksessä, 2 toista ja niin edelleen; kun -0 on viimeinen käynnistys, -1 käynnistys ennen viimeistä jne."
 ],
 "Thursdays": [
  null,
  "Torstai"
 ],
 "Time": [
  null,
  "Aika"
 ],
 "Time zone": [
  null,
  "Aikavyöhyke"
 ],
 "Timer creation failed": [
  null,
  "Ajastimen luonti epäonnistui"
 ],
 "Timer deletion failed": [
  null,
  "Ajastimen poisto epäonnistui"
 ],
 "Timers": [
  null,
  "Ajastimet"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Tarkista koneen avaimen sormenjälki varmistaaksesi, että haitallinen kolmas osapuoli ei sieppaa yhteyttä:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Vahvistaaksesi sormenjäljen, suorita seuraava koneella $0 istuessasi fyysisesti koneen ääressä tai luotettavan verkon kautta:"
 ],
 "Toggle date picker": [
  null,
  "Vaihda päivämäärän valitsin"
 ],
 "Toggle filters": [
  null,
  "Vaihda suodattimet"
 ],
 "Too much data": [
  null,
  "Liian paljon dataa"
 ],
 "Total size: $0": [
  null,
  "Koko yhteensä: $0"
 ],
 "Tower": [
  null,
  "Torni"
 ],
 "Transient": [
  null,
  "Tilapäinen"
 ],
 "Trigger": [
  null,
  "Laukaise"
 ],
 "Triggered by": [
  null,
  "Tämän laukaisema"
 ],
 "Triggers": [
  null,
  "Laukaisimet"
 ],
 "Trust and add host": [
  null,
  "Luota ja lisää isäntä"
 ],
 "Trying to synchronize with $0": [
  null,
  "Yritetään synkronoida palvelimen $0 kanssa"
 ],
 "Tuesdays": [
  null,
  "Tiistai"
 ],
 "Tuned has failed to start": [
  null,
  "Tuned:n käynnistys epäonnistui"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned on palvelu, joka valvoo järjestelmääsi ja optimoi suorituskyvyn tietyillä kuormituksilla. Tuned:n ytimessä on profiileja, jotka virittävät järjestelmän eri käyttötapauksiin."
 ],
 "Tuned is not available": [
  null,
  "Tuned ei ole saatavilla"
 ],
 "Tuned is not running": [
  null,
  "Tuned ei ole käynnissä"
 ],
 "Tuned is off": [
  null,
  "Tuned on pois päältä"
 ],
 "Type": [
  null,
  "Tyyppi"
 ],
 "Type to filter": [
  null,
  "Kirjoita suodattaaksesi"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Ei voida kirjautua sisään $0:iin SSH-avaimella. Syötä salasana."
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Ei voida kirjautua sisään koneelle $0. Kone ei hyväksy salasanakirjautumista tai mitään SSH-avaimistasi."
 ],
 "Unable to open directory": [
  null,
  "Hakemistoa ei voi avata"
 ],
 "Unit": [
  null,
  "Yksikkö"
 ],
 "Unknown": [
  null,
  "Tuntematon"
 ],
 "Unknown host: $0": [
  null,
  "Tuntematon isäntä: $0"
 ],
 "Unpin unit": [
  null,
  "Poista yksikön merkkaus"
 ],
 "Until": [
  null,
  "Kunnes"
 ],
 "Untrusted host": [
  null,
  "Epäluotettava kone"
 ],
 "Up since": [
  null,
  "Käynnissä lähtien"
 ],
 "Updating status...": [
  null,
  "Päivitetään tilaa ..."
 ],
 "Usage": [
  null,
  "Käyttö"
 ],
 "User": [
  null,
  "Käyttäjä"
 ],
 "Validating address": [
  null,
  "Vahvistetaan osoite"
 ],
 "Vendor": [
  null,
  "Toimittaja"
 ],
 "Verify fingerprint": [
  null,
  "Vahvista sormenjälki"
 ],
 "Version": [
  null,
  "Versio"
 ],
 "View all logs": [
  null,
  "Katso kaikki lokit"
 ],
 "View all services": [
  null,
  "Katso kaikki palvelut"
 ],
 "View automation script": [
  null,
  "Näytä automaatio-komentosarja"
 ],
 "View hardware details": [
  null,
  "Tarkastele laitteiston yksityiskohtia"
 ],
 "View login history": [
  null,
  "Tarkastele kirjautumishistoriaa"
 ],
 "View metrics and history": [
  null,
  "Tarkastele tietoja ja historiaa"
 ],
 "Viewing memory information requires administrative access.": [
  null,
  "Muistiin liittyvien tietojen katselu vaatii ylläpitäjän käyttöoikeudet."
 ],
 "Visit firewall": [
  null,
  "Käy palomuurissa"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Odotetaan muiden ohjelmistojen hallintatoimintojen päättymistä"
 ],
 "Wanted by": [
  null,
  "Tämän haluama"
 ],
 "Wants": [
  null,
  "Haluaa"
 ],
 "Warning and above": [
  null,
  "Varoitus ja yli"
 ],
 "Weak password": [
  null,
  "Heikko salasana"
 ],
 "Web Console for Linux servers": [
  null,
  "Verkkokonsoli Linux-palvelimille"
 ],
 "Web console is running in limited access mode.": [
  null,
  "Verkkokonsoli toimii rajoitetun pääsyn tilassa."
 ],
 "Wednesdays": [
  null,
  "Keskiviikko"
 ],
 "Weekly": [
  null,
  "Joka viikko"
 ],
 "Weeks": [
  null,
  "Viikot"
 ],
 "White": [
  null,
  "Valkoinen"
 ],
 "Yearly": [
  null,
  "Vuosittain"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Yhdistät koneeseen $0 ensimmäistä kertaa."
 ],
 "You may try to load older entries.": [
  null,
  "Voit yrittää ladata vanhempia merkintöjä."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Selaimesi ei salli liittämistä pikavalikosta. Voit käyttää Vaihto+Insert."
 ],
 "Your session has been terminated.": [
  null,
  "Istuntosi on päätetty."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Istuntosi on vahventunut. Ole hyvä ja kirjaudu uudelleen sisään."
 ],
 "Zone": [
  null,
  "Alue"
 ],
 "[binary data]": [
  null,
  "[binääridata]"
 ],
 "[no data]": [
  null,
  "[ei dataa]"
 ],
 "active": [
  null,
  "aktiivinen"
 ],
 "edit": [
  null,
  "muokkaa"
 ],
 "failed to list ssh host keys: $0": [
  null,
  "ssh-koneavainten luettelointi epäonnistui: $0"
 ],
 "in less than a minute": [
  null,
  "alle minuutissa"
 ],
 "inconsistent": [
  null,
  "epäkonsistentti"
 ],
 "journalctl manpage": [
  null,
  "journalctl:n man-sivu"
 ],
 "less than a minute ago": [
  null,
  "alle minuutti sitten"
 ],
 "none": [
  null,
  "Ei mitään"
 ],
 "of $0 CPU": [
  null,
  "$0 CPU:sta",
  "$0 CPU:ista"
 ],
 "password quality": [
  null,
  "salasanan laatu"
 ],
 "recommended": [
  null,
  "suositeltu"
 ],
 "running $0": [
  null,
  "käyttöjärjestelmänä $0"
 ],
 "show less": [
  null,
  "näytä vähemmän"
 ],
 "show more": [
  null,
  "näytä enemmän"
 ],
 "unknown": [
  null,
  "tuntematon"
 ],
 "dialog-title\u0004Domain": [
  null,
  "Toimialue"
 ],
 "dialog-title\u0004Join a domain": [
  null,
  "Liity toimialueeseen"
 ],
 "from <host>\u0004from $0": [
  null,
  "$0:sta"
 ],
 "from <host> on <terminal>\u0004from $0 on $1": [
  null,
  "sijainnista $0 päätteellä $1"
 ],
 "on <terminal>\u0004on $0": [
  null,
  "päätteellä $0"
 ]
});
