cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "de",
  "language-direction": "ltr"
 },
 "Configuring system settings": [
  null,
  "Konfiguriere System-Einstellungen"
 ],
 "Diagnostic reports": [
  null,
  "Diagnoseberichte"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Logs": [
  null,
  "Protokolle"
 ],
 "Managing services": [
  null,
  "Dienste verwalten"
 ],
 "Networking": [
  null,
  "Netzwerk"
 ],
 "Overview": [
  null,
  "Überblick"
 ],
 "Reviewing logs": [
  null,
  "Protokolle bewerten"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Services": [
  null,
  "Dienste"
 ],
 "Storage": [
  null,
  "Speicher"
 ],
 "Terminal": [
  null,
  "Terminal"
 ],
 "abrt": [
  null,
  "abrt"
 ],
 "asset tag": [
  null,
  "Asset-Tag"
 ],
 "bash": [
  null,
  "bash"
 ],
 "bios": [
  null,
  "bios"
 ],
 "boot": [
  null,
  "Start"
 ],
 "cgroups": [
  null,
  "Cgroups"
 ],
 "command": [
  null,
  "Kommando"
 ],
 "console": [
  null,
  "Konsole"
 ],
 "coredump": [
  null,
  "Coredump"
 ],
 "cpu": [
  null,
  "CPU"
 ],
 "crash": [
  null,
  "Absturz"
 ],
 "date": [
  null,
  "Datum"
 ],
 "debug": [
  null,
  "Debug"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "disable": [
  null,
  "deaktivieren"
 ],
 "disks": [
  null,
  "Datenträger"
 ],
 "domain": [
  null,
  "Domain"
 ],
 "enable": [
  null,
  "aktivieren"
 ],
 "error": [
  null,
  "Fehler"
 ],
 "graphs": [
  null,
  "Kurven"
 ],
 "hardware": [
  null,
  "Hardware"
 ],
 "history": [
  null,
  "Verlauf"
 ],
 "host": [
  null,
  "host"
 ],
 "journal": [
  null,
  "Journal"
 ],
 "machine": [
  null,
  "Maschine"
 ],
 "mask": [
  null,
  "Maske"
 ],
 "memory": [
  null,
  "Speicher"
 ],
 "metrics": [
  null,
  "Metriken"
 ],
 "mitigation": [
  null,
  "Milderung"
 ],
 "network": [
  null,
  "Netzwerk"
 ],
 "operating system": [
  null,
  "Betriebssystem"
 ],
 "os": [
  null,
  "os"
 ],
 "path": [
  null,
  "Pfad"
 ],
 "pci": [
  null,
  "pci"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "performance": [
  null,
  "Leistung"
 ],
 "power": [
  null,
  "Leistung"
 ],
 "ram": [
  null,
  "Arbeitsspeicher"
 ],
 "restart": [
  null,
  "Neustart"
 ],
 "serial": [
  null,
  "Seriell"
 ],
 "service": [
  null,
  "Dienst"
 ],
 "shell": [
  null,
  "Shell"
 ],
 "shut": [
  null,
  "schließen"
 ],
 "socket": [
  null,
  "Socket"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "Ziel"
 ],
 "time": [
  null,
  "Zeit"
 ],
 "timer": [
  null,
  "Timer"
 ],
 "unit": [
  null,
  "Einheit"
 ],
 "unmask": [
  null,
  "Freigeben"
 ],
 "version": [
  null,
  "Version"
 ],
 "warning": [
  null,
  "Warnung"
 ]
});
