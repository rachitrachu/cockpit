cockpit.locale({
 "": {
  "plural-forms": (n) => n==0 ? 0 : n==1 ? 1 : n==2 ? 2 : n%100>=3 && n%100<=10 ? 3 : n%100>=11 ? 4 : 5,
  "language": "ar",
  "language-direction": "rtl"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 critical hit": [
  null,
  "$0 لا يوجد إصابات",
  "$0 إصابة حرجة واحدة",
  "$0 إصابتان, بما في ذلك الإصابات الحرجة",
  "$0 إصابات, بما في ذلك الإصابات الحرجة",
  "$0 إصابة, بما في ذلك الإصابات الحرجة",
  "$0 إصابة, بما في ذلك الإصابات الحرجة"
 ],
 "$0 day": [
  null,
  "$0 ولا يوم",
  "$0 يوم واحد",
  "$0 يومان",
  "$0 أيام",
  "$0 يوما",
  "$0 يوم"
 ],
 "$0 disk is failing": [
  null,
  "لا قرص معطل",
  "القرص معطل",
  "القرصان معطلان",
  "توجد $0 أقراص معطلة",
  "يوجد $0 قرصاً معطلاً",
  "يوجد $0 قرصاً معطلاً"
 ],
 "$0 does not exist": [
  null,
  "$0 غير موجود"
 ],
 "$0 exited with code $1": [
  null,
  "$0 خرج مع الرمز $1"
 ],
 "$0 failed": [
  null,
  "$0 فشل"
 ],
 "$0 failed login attempt": [
  null,
  "لا يوجد محاولات تسجيل دخول فاشلة",
  "$0 محاولة تسجيل دخول واحدة فاشلة",
  "$0 محاولتا تسجيل دخول فاشلة",
  "$0 محاولات تسجيل دخول فاشلة",
  "$0 محاولة تسجيل دخول فاشلة",
  "$0 محاولة تسجيل دخول فاشلة"
 ],
 "$0 filters applied": [
  null,
  "تم تطبيق ‎$0 من عوامل التصفية"
 ],
 "$0 hour": [
  null,
  "$0 ولا ساعة",
  "$0 ساعة واحدة",
  "$0 ساعتان",
  "$0 ساعات",
  "$0 ساعة",
  "$0 ساعة"
 ],
 "$0 important hit": [
  null,
  "$0 لا يوجد إصابات",
  "$0 إصابة واحدة",
  "$0 إصابتان, بما في ذلك المهمة",
  "$0 إصابات, بما في ذلك المهمة",
  "$0 إصابة, بما في ذلك المهمة",
  "$0 إصابة, بما في ذلك المهمة"
 ],
 "$0 is not a directory": [
  null,
  "$0 ليس مجلداً"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 غير متوفر في أي مستودع."
 ],
 "$0 key changed": [
  null,
  "$0 مفتاح قد تغير"
 ],
 "$0 killed with signal $1": [
  null,
  "تم إيقاف $0 بالإشارة $1"
 ],
 "$0 low severity hit": [
  null,
  "لا نتيجة منخفضة الخطورة",
  "نتيجة واحدة منخفضة الخطورة",
  "نتيجتان منخفضتا الخطورة",
  "$0 نتيجة منخفضة الخطورة",
  "$0 نتيجة منخفضة الخطورة",
  "$0 نتيجة منخفضة الخطورة"
 ],
 "$0 minute": [
  null,
  "0 دقيقة",
  "دقيقة واحدة",
  "دقيقتان",
  "$0 دقائق",
  "$0 دقيقة",
  "$0 دقيقة"
 ],
 "$0 moderate hit": [
  null,
  "لا نتيجة متوسطة الخطورة",
  "نتيجة واحدة متوسطة الخطورة",
  "نتيجتان متوسطتا الخطورة",
  "$0 نتيجة متوسطة الخطورة",
  "$0 نتيجة متوسطة الخطورة",
  "$0 نتيجة متوسطة الخطورة"
 ],
 "$0 month": [
  null,
  "$0 شهر",
  "شهر واحد",
  "شهران",
  "$0 أشهر",
  "$0 شهراً",
  "$0 شهراً"
 ],
 "$0 service has failed": [
  null,
  "لا خدمة توقفت عن العمل",
  "خدمة واحدة توقفت عن العمل",
  "خدمتان توقفتا عن العمل",
  "‎$0 خدمات توقفت عن العمل",
  "$0 خدمة توقفت عن العمل",
  "‎$0 خدمة توقفت عن العمل"
 ],
 "$0 week": [
  null,
  "$0 لا أسابيع",
  "$0 اسبوع واحد",
  "$0 اسبوعان",
  "$0 اسابيع",
  "$0 اسبوعا",
  "$0 اسبوع"
 ],
 "$0 will be installed.": [
  null,
  "$0 سيُثبت."
 ],
 "$0 year": [
  null,
  "$0 ولا سنة",
  "$0 سنة واحدة",
  "$0 سنتان",
  "$0 سنوات",
  "$0 سنة",
  "$0 سنة"
 ],
 "1 day": [
  null,
  "يوم واحد"
 ],
 "1 hour": [
  null,
  "ساعة واحدة"
 ],
 "1 minute": [
  null,
  "دقيقة واحدة"
 ],
 "1 week": [
  null,
  "أسبوع واحد"
 ],
 "10th": [
  null,
  "العاشر"
 ],
 "11th": [
  null,
  "الحادي عشر"
 ],
 "12th": [
  null,
  "الثاني عشر"
 ],
 "13th": [
  null,
  "الثالث عشر"
 ],
 "14th": [
  null,
  "الرابع عشر"
 ],
 "15th": [
  null,
  "الخامس عشر"
 ],
 "16th": [
  null,
  "السادس عشر"
 ],
 "17th": [
  null,
  "السابع عشر"
 ],
 "18th": [
  null,
  "الثامن عشر"
 ],
 "19th": [
  null,
  "التاسع عشر"
 ],
 "1st": [
  null,
  "الأول"
 ],
 "20 minutes": [
  null,
  "٢٠ دقيقة"
 ],
 "20th": [
  null,
  "العشرون"
 ],
 "21th": [
  null,
  "الحادي والعشرون"
 ],
 "22th": [
  null,
  "الثاني والعشرون"
 ],
 "23th": [
  null,
  "الثالث والعشرون"
 ],
 "24th": [
  null,
  "الرابع والعشرون"
 ],
 "25th": [
  null,
  "الخامس والعشرون"
 ],
 "26th": [
  null,
  "السادس والعشرون"
 ],
 "27th": [
  null,
  "السابع والعشرون"
 ],
 "28th": [
  null,
  "الثامن والعشرون"
 ],
 "29th": [
  null,
  "التاسع والعشرون"
 ],
 "2nd": [
  null,
  "الثاني"
 ],
 "30th": [
  null,
  "الثلاثون"
 ],
 "31st": [
  null,
  "الواحد والثلاثون"
 ],
 "3rd": [
  null,
  "الثالث"
 ],
 "40 minutes": [
  null,
  "٤٠ دقيقة"
 ],
 "4th": [
  null,
  "الرابع"
 ],
 "5 minutes": [
  null,
  "٥ دقائق"
 ],
 "5th": [
  null,
  "الخامس"
 ],
 "6 hours": [
  null,
  "٦ ساعات"
 ],
 "60 minutes": [
  null,
  "٦٠ دقيقة"
 ],
 "6th": [
  null,
  "السادس"
 ],
 "7th": [
  null,
  "السابع"
 ],
 "8th": [
  null,
  "الثامن"
 ],
 "9th": [
  null,
  "التاسع"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "لم يتم تثبيت إصدار متوافق من Cockpit على $0."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "سيتم إنشاء مفتاح SSH جديد في $0 لـ $1 بتاريخ $2 ، وإضافته إلى الملف $3 الخاص بـ $4 على $5."
 ],
 "Absent": [
  null,
  "غائب"
 ],
 "Acceptable password": [
  null,
  "كلمة السر صالحة"
 ],
 "Active since ": [
  null,
  "نشط منذ "
 ],
 "Active state": [
  null,
  "حالة النشاط"
 ],
 "Add": [
  null,
  "إضافة"
 ],
 "Add $0": [
  null,
  "أضف $0"
 ],
 "Additional actions": [
  null,
  "عمليات إضافية"
 ],
 "Additional packages:": [
  null,
  "حزم إضافية:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "الإدارة عبر وحدة تحكم الويب Cockpit"
 ],
 "Advanced TCA": [
  null,
  "TCA متقدم"
 ],
 "After": [
  null,
  "بعد"
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "بعد إزالة الجهاز من النطاق، يقتصر تسجيل الدخول على الحسابات المحلية فقط. وقد يؤثر ذلك أيضًا على خدمات أخرى، مثل إعدادات استعلام نظام أسماء النطاقات (DNS) وقائمة شهادات الجهة المصدرة (CAs) الموثوقة."
 ],
 "After system boot": [
  null,
  "بعد إقلاع النظام"
 ],
 "Alert and above": [
  null,
  "تنبيه وما فوق"
 ],
 "Alias": [
  null,
  "اسم مستعار"
 ],
 "All": [
  null,
  "الكل"
 ],
 "All-in-one": [
  null,
  "الكل في واحد"
 ],
 "Allow running (unmask)": [
  null,
  "السماح بالتشغيل (إلغاء الحجب)"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "توثيق الأدوار في Ansible"
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  "يمكن تصفية أي سلسلة نصية في رسائل السجلات. يمكن أن تكون السلسلة أيضًا على شكل تعبير نمطي (Regular Expression). كما يدعم التصفية حسب حقول سجل الرسائل. هذه الحقول هي قيم مفصولة بمسافات، بالشكل FIELD=VALUE، حيث يمكن أن تكون القيمة قائمة مفصولة بفواصل من القيم الممكنة."
 ],
 "Appearance": [
  null,
  "المظهر"
 ],
 "Apply and reboot": [
  null,
  "طبق وأعد التشغيل"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  "يتم تطبيق السياسة الجديدة... قد يستغرق هذا بضع دقائق."
 ],
 "Asset tag": [
  null,
  "معرّف الأصل"
 ],
 "At minute": [
  null,
  "عند الدقيقة"
 ],
 "At second": [
  null,
  "عند ثانية"
 ],
 "At specific time": [
  null,
  "عند وقت محدد"
 ],
 "Authentication": [
  null,
  "المصادقة"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "المصادقة مطلوبة لأداء المهام المميّزة في وحدة تحكم Cockpit على الويب"
 ],
 "Authorize SSH key": [
  null,
  "اعتماد مفاتيح SSH"
 ],
 "Automatically starts": [
  null,
  "يبدأ تلقائيًا"
 ],
 "Automatically using NTP": [
  null,
  "استخدام NTP بشكل تلقائي"
 ],
 "Automatically using additional NTP servers": [
  null,
  "استخدام خادم NTP إضافي بشكل تلقائي"
 ],
 "Automatically using specific NTP servers": [
  null,
  "استخدام خادم NTP محدد بشكل تلقائي"
 ],
 "Automation script": [
  null,
  "البرنامج النصي للتشغيل الآلي"
 ],
 "BIOS": [
  null,
  "BIOS"
 ],
 "BIOS date": [
  null,
  "تاريخ الـ BIOS"
 ],
 "BIOS version": [
  null,
  "إصدار الـ BIOS"
 ],
 "Bad": [
  null,
  "سيء"
 ],
 "Bad setting": [
  null,
  "إعدادات سيئة"
 ],
 "Before": [
  null,
  "قبل"
 ],
 "Binds to": [
  null,
  "مرتبط بـ"
 ],
 "Black": [
  null,
  "أسود"
 ],
 "Blade": [
  null,
  "شفرة"
 ],
 "Blade enclosure": [
  null,
  "حاوية الشفرة"
 ],
 "Boot": [
  null,
  "الإقلاع"
 ],
 "Bound by": [
  null,
  "ملزم بـ"
 ],
 "Bus expansion chassis": [
  null,
  "هيكل توسيع الناقل"
 ],
 "CPU": [
  null,
  "المعالج"
 ],
 "CPU security": [
  null,
  "أمان المعالج"
 ],
 "CPU security toggles": [
  null,
  "مفاتيح تبديل أمان المعالج"
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "لا يمكن العثور على أي سجلات عبر مجموعة المرشحات الحالية."
 ],
 "Cancel": [
  null,
  "إلغاء"
 ],
 "Cancel poweroff": [
  null,
  "إلغاء إيقاف التشغيل"
 ],
 "Cancel reboot": [
  null,
  "إيقاف إعادة التشغيل"
 ],
 "Cannot be enabled": [
  null,
  "غير قابل للتغعيل"
 ],
 "Cannot forward login credentials": [
  null,
  "لا يمكن إعادة توجيه بيانات اعتماد تسجيل الدخول"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  "لا يمكن الانضمام إلى نطاق ؛ لأن realmd غير متوفر على هذا النظام"
 ],
 "Cannot schedule event in the past": [
  null,
  "لا يمكن جدولة الحدث في الماضي"
 ],
 "Change": [
  null,
  "تغيير"
 ],
 "Change cryptographic policy": [
  null,
  "غيّر سياسة التشفير"
 ],
 "Change directory": [
  null,
  "غير الدليل"
 ],
 "Change host name": [
  null,
  "تغيير اسم المضيف"
 ],
 "Change performance profile": [
  null,
  "تغيير ملف تعريف الأداء"
 ],
 "Change profile": [
  null,
  "تغيير ملف التعريف"
 ],
 "Change system time": [
  null,
  "تغيير توقيت النظام"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "غالباً تكون المفاتيح المتغيرة نتيجة إعادة تثبيت نظام التشغيل. رغم ذلك، قد يشير التغيير غير المتوقع إلى محاولة طرف ثالث اعتراض اتصالك."
 ],
 "Changing the directory will forcefully stop the currently running process. The process can also be stopped manually in the terminal before continuing.": [
  null,
  "سيؤدي تغيير المجلد إلى إيقاف العملية قيد التشغيل حاليًا بالقوة. يمكن إيقاف العملية يدويًا عبر الطرفية قبل المتابعة."
 ],
 "Checking installed software": [
  null,
  "التحقق من البرامج المثبتة"
 ],
 "Class": [
  null,
  "الصنف"
 ],
 "Clear 'Failed to start'": [
  null,
  "المسح \"فشل في البدء\""
 ],
 "Clear all filters": [
  null,
  "إزالة كل المرشحات"
 ],
 "Clear input value": [
  null,
  "مسح قيمة المدخلات"
 ],
 "Client software": [
  null,
  "برنامج العميل"
 ],
 "Close": [
  null,
  "أغلق"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "تكوين Cockpit الخاص بـ NetworkManager وFirewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "لم يتمكن Cockpit بالاتصال بالمضيف المحدد."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit هو أداة لإدارة الخوادم تُسهّل عليك الإشراف على خوادم Linux عبر متصفّح الويب. التنقّل بين الطرفية (الترمينال) والأداة على الويب سلس تمامًا؛ فمثلاً يمكنك إيقاف خدمة تمّ تشغيلها عبر Cockpit من داخل الطرفية، وبالمثل إذا ظهر خطأ في الطرفية ستجده معروضًا في واجهة سجلات Journal الخاصة بـ Cockpit."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit غير متوافق مع البرنامج على النظام."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit غير مثبت"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit غير مثبت على النظام."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "تُعد Cockpit مثالية لمديري النظام الجدد، حيث تتيح لهم أداء مهام بسيطة بسهولة مثل إدارة التخزين وفحص السجلات وبدء تشغيل الخدمات وإيقافها. يمكنك مراقبة وإدارة عدة خوادم في نفس الوقت. ما عليك سوى إضافتها بنقرة واحدة وستعتني أجهزتك بالباقي."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "جمع بيانات التشخيص والدعم وتجميعها"
 ],
 "Collect kernel crash dumps": [
  null,
  "جمع تفريغات أعطال نواة النظام"
 ],
 "Command": [
  null,
  "أمر"
 ],
 "Command not found": [
  null,
  "الأمر غير موجود"
 ],
 "Communication with tuned has failed": [
  null,
  "تعذّر الاتصال بـ Tuned"
 ],
 "Compact PCI": [
  null,
  "PCI مدمج"
 ],
 "Condition $0=$1 was not met": [
  null,
  "لم يتم تحقيق الشرط $0=$1"
 ],
 "Condition failed": [
  null,
  "الشرط لم يتحقق"
 ],
 "Configuration": [
  null,
  "الضبط"
 ],
 "Confirm deletion of $0": [
  null,
  "تأكيد حذف $0"
 ],
 "Confirm key password": [
  null,
  "تأكيد مفتاح كلمة السر"
 ],
 "Conflicted by": [
  null,
  "متعارض مع"
 ],
 "Conflicts": [
  null,
  "تعارضات"
 ],
 "Connecting to dbus failed: $0": [
  null,
  "الاتصال بـ dbus فشل: $0"
 ],
 "Connection has timed out.": [
  null,
  "انتهت مدة الاتصال."
 ],
 "Consists of": [
  null,
  "يتكون من"
 ],
 "Contacted domain": [
  null,
  "النطاق المُتصَّل به"
 ],
 "Container": [
  null,
  "حاوية"
 ],
 "Convertible": [
  null,
  "قابل للتحويل"
 ],
 "Copied": [
  null,
  "نُسخ"
 ],
 "Copy": [
  null,
  "نسخ"
 ],
 "Copy to clipboard": [
  null,
  "نسخ للحافظة"
 ],
 "Create $0": [
  null,
  "أنشئ $0"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "إنشاء مفتاح SSH جديد وتفويضه"
 ],
 "Create new task file with this content.": [
  null,
  "إنشاء ملف مهمة جديدة بهذا المحتوى."
 ],
 "Create timer": [
  null,
  "إنشاء مؤقت"
 ],
 "Critical and above": [
  null,
  "حرج فما فوق ذلك"
 ],
 "Cryptographic Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  "سياسة التشفير عبارة عن مكوّن نظام يقوم بتكوين أنظمة التشفير الفرعية الأساسية، التي تغطي بروتوكولات TLS و IPSec و SSH و DNSSec و Kerberos."
 ],
 "Cryptographic policy": [
  null,
  "سياسة التشفير"
 ],
 "Cryptographic policy is inconsistent": [
  null,
  "سياسة التشفير غير متسقة"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Current boot": [
  null,
  "الإقلاع الحالي"
 ],
 "Custom cryptographic policy": [
  null,
  "سياسة تشفير مخصصة"
 ],
 "DEFAULT with SHA-1 signature verification allowed.": [
  null,
  "DEFAULT مع السماح بالتحقق من توقيع SHA-1."
 ],
 "Daily": [
  null,
  "يومياً"
 ],
 "Dark": [
  null,
  "داكن"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  "‍يجب أن تكون مواصفات التاريخ بالصيغة YYYYY-MMM-DD hh:mm:ss. وبدلاً من ذلك، تُفهم السلاسل 'yesterday'، و'today'، و'tomorrow'. تشير كلمة 'now' إلى الوقت الحالي. أخيرًا، يمكن تحديد الأوقات النسبية، مسبوقة ب '-' أو '+'"
 ],
 "Debug and above": [
  null,
  "تصحيح الأخطاء وما فوق"
 ],
 "Decrease by one": [
  null,
  "إنقاص بمقدار واحد"
 ],
 "Default": [
  null,
  "افتراضي"
 ],
 "Delay": [
  null,
  "التأخير"
 ],
 "Delay must be a number": [
  null,
  "التأخير يجب أن يكون عدداً"
 ],
 "Delete": [
  null,
  "حذف"
 ],
 "Deletion will remove the following files:": [
  null,
  "سيؤدي الحذف إلى إزالة الملفات التالية:"
 ],
 "Description": [
  null,
  "الوصف"
 ],
 "Desktop": [
  null,
  "سطح المكتب"
 ],
 "Detachable": [
  null,
  "قابل للفصل"
 ],
 "Details": [
  null,
  "التفاصيل"
 ],
 "Diagnostic reports": [
  null,
  "تقارير التشخيص"
 ],
 "Disable simultaneous multithreading": [
  null,
  "تعطيل تعدد مؤشرات الترابط المتزامن"
 ],
 "Disable tuned": [
  null,
  "تعطيل الضبط"
 ],
 "Disabled": [
  null,
  "معطّل"
 ],
 "Disallow running (mask)": [
  null,
  "عدم السماح بالتشغيل (قناع)"
 ],
 "Docking station": [
  null,
  "محطة إرساء"
 ],
 "Does not automatically start": [
  null,
  "لا تبدأ تلقائياً"
 ],
 "Domain": [
  null,
  "نطاق"
 ],
 "Domain address": [
  null,
  "عنوان النطاق"
 ],
 "Domain administrator name": [
  null,
  "اسم نطاق مسؤول النظام"
 ],
 "Domain administrator password": [
  null,
  "كلمة سر نطاق مسؤول النظام"
 ],
 "Domain could not be contacted": [
  null,
  "تعذر الاتصال بالنطاق"
 ],
 "Domain is not supported": [
  null,
  "النطاق غير مدعوم"
 ],
 "Don't repeat": [
  null,
  "لا تكرر"
 ],
 "Downloading $0": [
  null,
  "جاري تنزيل $0"
 ],
 "Dual rank": [
  null,
  "رتبة مزدوجة"
 ],
 "Edit /etc/motd": [
  null,
  "تعديل /etc/motd"
 ],
 "Edit motd": [
  null,
  "تعديل motd"
 ],
 "Embedded PC": [
  null,
  "حاسوب مدمج"
 ],
 "Enabled": [
  null,
  "مُفعَّل"
 ],
 "Entry at $0": [
  null,
  "الدخول عند $0"
 ],
 "Error": [
  null,
  "خطأ"
 ],
 "Error and above": [
  null,
  "الخطأ وما فوق"
 ],
 "Error message": [
  null,
  "رسالة خطأ"
 ],
 "Excellent password": [
  null,
  "كلمة سر ممتازة"
 ],
 "Expansion chassis": [
  null,
  "هيكل التوسعة"
 ],
 "FIPS is not properly enabled": [
  null,
  "لم يتم تمكين FIPS بشكل صحيح"
 ],
 "FIPS with further Common Criteria restrictions.": [
  null,
  "FIPS مع مزيد من قيود المعايير المشتركة."
 ],
 "Failed to change password": [
  null,
  "فشل في تغيير كلمة السر"
 ],
 "Failed to disable tuned": [
  null,
  "فشل في تعطيل الضبط"
 ],
 "Failed to disable tuned profile": [
  null,
  "فشل تعطيل ملف التعريف المضبوط"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "فشل بتمكين $0 في الجدار الناري"
 ],
 "Failed to enable tuned": [
  null,
  "فشل في تمكين الضبط"
 ],
 "Failed to fetch logs": [
  null,
  "فشل في جلب السجلات"
 ],
 "Failed to load unit": [
  null,
  "فشل في تحميل الوحدة"
 ],
 "Failed to save changes in /etc/motd": [
  null,
  "فشل في حفظ التغييرات في /etc/motd"
 ],
 "Failed to start": [
  null,
  "فشل في البدء"
 ],
 "Failed to switch profile": [
  null,
  "فشل في تبديل الملف الشخصي"
 ],
 "File state": [
  null,
  "حالة الملف"
 ],
 "Filter by name or description": [
  null,
  "التصفية حسب الاسم أو الوصف"
 ],
 "Filters": [
  null,
  "عوامل التصفية"
 ],
 "Font size": [
  null,
  "حجم الخط"
 ],
 "Forbidden from running": [
  null,
  "ممنوع من التشغيل"
 ],
 "Free-form search": [
  null,
  "بحث حر البنية"
 ],
 "Fridays": [
  null,
  "أيام الجُمع"
 ],
 "Generated": [
  null,
  "تم توليده"
 ],
 "Go to $0": [
  null,
  "‎انتقل إلى $0"
 ],
 "Go to now": [
  null,
  "انتقل الآن"
 ],
 "Handheld": [
  null,
  "محمول باليد"
 ],
 "Hardware information": [
  null,
  "معلومات العتاد المادي"
 ],
 "Health": [
  null,
  "الصحة"
 ],
 "Help": [
  null,
  "مساعدة"
 ],
 "Hide confirmation password": [
  null,
  "أخفِ تأكيد كلمة السر"
 ],
 "Hide password": [
  null,
  "أخفِ كلمة السر"
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  "توافقية أعلى على حساب زيادة المساحة المعرضة للهجوم."
 ],
 "Host key is incorrect": [
  null,
  "مفتاح الاستضافة غير صحيح"
 ],
 "Hostname": [
  null,
  "اسم-المضيف"
 ],
 "Hourly": [
  null,
  "كل ساعة"
 ],
 "Hours": [
  null,
  "ساعات"
 ],
 "ID": [
  null,
  "المعرّف"
 ],
 "Identifier": [
  null,
  "معرّف"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "إذا كانت البصمة متطابقة، انقر فوق ”توثيق وإضافة مضيف“. وإلا فلا تتصل ، وتواصل مع مسؤول النظام."
 ],
 "Increase by one": [
  null,
  "الزيادة بمقدار واحد"
 ],
 "Indirect": [
  null,
  "غير مباشر"
 ],
 "Info and above": [
  null,
  "معلومات وأكثر"
 ],
 "Insights: ": [
  null,
  "إنسايتس: "
 ],
 "Install": [
  null,
  "تثبيت"
 ],
 "Install realmd support": [
  null,
  "تثبيت دعم realmd"
 ],
 "Install software": [
  null,
  "ثبت التطبيق"
 ],
 "Installing $0": [
  null,
  "يثبت $0"
 ],
 "Internal error": [
  null,
  "خطأ داخلي"
 ],
 "Invalid": [
  null,
  "غير صالح"
 ],
 "Invalid date format": [
  null,
  "تنسيق التاريخ خاطئ"
 ],
 "Invalid date format and invalid time format": [
  null,
  "صيغة البيانات والوقت غير صالحتان"
 ],
 "Invalid file permissions": [
  null,
  "صلاحيات ملف غير صالحة"
 ],
 "Invalid time format": [
  null,
  "تنسيق الوقت خاطئ"
 ],
 "Invalid timezone": [
  null,
  "منطقة زمنية غير صالحة"
 ],
 "IoT gateway": [
  null,
  "بوابة IoT"
 ],
 "Join": [
  null,
  "انضم"
 ],
 "Join domain": [
  null,
  "الانضمام إلى النطاق"
 ],
 "Joining": [
  null,
  "الانضمام"
 ],
 "Joining a domain requires installation of realmd": [
  null,
  "الانضمام لنطاق يتطلب تثبيت realmd"
 ],
 "Joining this domain is not supported": [
  null,
  "الانضمام لهذا المجال غير مدعوم"
 ],
 "Joins namespace of": [
  null,
  "ينضم إلى مساحة الأسماء الخاصة بـ"
 ],
 "Journal": [
  null,
  "سجل اليومية"
 ],
 "Journal entry": [
  null,
  "قيد اليوميات"
 ],
 "Journal entry not found": [
  null,
  "قيد اليوميات غير موجود"
 ],
 "Kernel dump": [
  null,
  "عطب نواة النظام"
 ],
 "Key password": [
  null,
  "مفتاح كلمة السر"
 ],
 "LEGACY with Active Directory interoperability.": [
  null,
  "LEGACY مع إمكانية التشغيل البيني لـ Active Directory."
 ],
 "Laptop": [
  null,
  "لابتوب"
 ],
 "Last 24 hours": [
  null,
  "آخر ٢٤ ساعة"
 ],
 "Last 7 days": [
  null,
  "آخر ٧ أيام"
 ],
 "Last successful login:": [
  null,
  "آخر تسجيل دخول ناجح:"
 ],
 "Learn more": [
  null,
  "اعرف المزيد"
 ],
 "Leave $0": [
  null,
  "مغادرة $0"
 ],
 "Leave domain": [
  null,
  "مغادرة النطاق"
 ],
 "Light": [
  null,
  "فاتح"
 ],
 "Linked": [
  null,
  "مرتبط"
 ],
 "Listen": [
  null,
  "استماع"
 ],
 "Listing units": [
  null,
  "وحدات الاستماع"
 ],
 "Listing units failed: $0": [
  null,
  "استماع الوحدات فشل: $0"
 ],
 "Load earlier entries": [
  null,
  "تحميل المدخلات السابقة"
 ],
 "Loading keys...": [
  null,
  "تحميل المفاتيح..."
 ],
 "Loading of SSH keys failed": [
  null,
  "تحميل مفاتيح SSH فشل"
 ],
 "Loading of units failed": [
  null,
  "تحميل الوحدات فشل"
 ],
 "Loading system modifications...": [
  null,
  "تحميل تعديلات النظام..."
 ],
 "Loading unit failed": [
  null,
  "تحميل الوحدة فشل"
 ],
 "Loading...": [
  null,
  "قيد التحميل..."
 ],
 "Log in": [
  null,
  "تسجيل الدخول"
 ],
 "Log in to $0": [
  null,
  "تسجيل الدخول إلى $0"
 ],
 "Log messages": [
  null,
  "رسالة طويلة"
 ],
 "Login failed": [
  null,
  "فشل تسجيل الدخول"
 ],
 "Login format": [
  null,
  "تهيئة تسجيل الدخول"
 ],
 "Logs": [
  null,
  "السجلات"
 ],
 "Low profile desktop": [
  null,
  "ملف سطح مكتب منخفض"
 ],
 "Lunch box": [
  null,
  "صندوق التشغيل"
 ],
 "Machine ID": [
  null,
  "معرف الآلة ID"
 ],
 "Machine SSH key fingerprints": [
  null,
  "بصمات مفتاح SSH للآلة"
 ],
 "Main server chassis": [
  null,
  "هيكل الخادم الرئيسي"
 ],
 "Maintenance": [
  null,
  "الصيانة"
 ],
 "Manage storage": [
  null,
  "إدارة التخزين"
 ],
 "Manually": [
  null,
  "يدوياً"
 ],
 "Mask service": [
  null,
  "خدمة الإخفاء"
 ],
 "Masked": [
  null,
  "مخفي"
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  "تمننع خدمة الإخفاء جميع الوحدات المعتمدة عليها من التشغيل. قد يكون لهذا تأثير أكبر مما هو متوقع. يرجى تأكيد رغبتك في إخفاء هذه الوحدة."
 ],
 "Memory": [
  null,
  "الذاكرة"
 ],
 "Memory technology": [
  null,
  "تقنية الذاكرة"
 ],
 "Merged": [
  null,
  "مدمج"
 ],
 "Message to logged in users": [
  null,
  "رسالة للمستخدمين النشطين"
 ],
 "Mini PC": [
  null,
  "حاسب آلي صغير"
 ],
 "Mini tower": [
  null,
  "برج صغير"
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "يجب أن تكون قيمة الدقيقة عدداً بين 0-59"
 ],
 "Minutely": [
  null,
  "بالدقيقة"
 ],
 "Minutes": [
  null,
  "دقائق"
 ],
 "Mitigations": [
  null,
  "إجراءات التخفيف"
 ],
 "Model": [
  null,
  "النموذج"
 ],
 "Mondays": [
  null,
  "أيام الإثنين"
 ],
 "Monthly": [
  null,
  "شهرياً"
 ],
 "Multi-system chassis": [
  null,
  "هيكل متعدد الأنظمة"
 ],
 "NTP server": [
  null,
  "خادم NTP"
 ],
 "Name": [
  null,
  "الاسم"
 ],
 "Need at least one NTP server": [
  null,
  "يحتاج خادم NTP واحداً على الأقل"
 ],
 "Networking": [
  null,
  "التشبيك"
 ],
 "New password was not accepted": [
  null,
  "كلمة السر الجديدة لم تقبل"
 ],
 "No delay": [
  null,
  "لا تأخير"
 ],
 "No host keys found.": [
  null,
  "لا يوجد مفاتيح استضافة."
 ],
 "No log entries": [
  null,
  "لا إدخالات في السجل"
 ],
 "No logs found": [
  null,
  "لا يوجد سجلات"
 ],
 "No matching results": [
  null,
  "لا نتائج مطابقة"
 ],
 "No results found": [
  null,
  "لم يعثر على نتائج"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  "لا توجد نتائج تطابق معايير التصفية. امسح جميع عوامل التصفية لإظهار النتائج."
 ],
 "No rule hits": [
  null,
  "لم يتم انطباق أي قواعد"
 ],
 "No such file or directory": [
  null,
  "لا ملف أو مجلد من هذا النوع"
 ],
 "No system modifications": [
  null,
  "لا يوجد تعديلات على النظام"
 ],
 "None": [
  null,
  "لا شيء"
 ],
 "Not a valid private key": [
  null,
  "مفتاح خاص غير صالح"
 ],
 "Not connected to Insights": [
  null,
  "غير متصل بـ Insights"
 ],
 "Not found": [
  null,
  "غير موجود"
 ],
 "Not permitted to configure realms": [
  null,
  "غير مسموح بتكوين realms"
 ],
 "Not permitted to perform this action.": [
  null,
  "غير مصرح لك بهذا الإجراء."
 ],
 "Not running": [
  null,
  "لا يعمل"
 ],
 "Not synchronized": [
  null,
  "غير مزامن"
 ],
 "Note": [
  null,
  "ملاحظة"
 ],
 "Notebook": [
  null,
  "محرر النصوص"
 ],
 "Notice and above": [
  null,
  "ملاحظة وما فوق"
 ],
 "Occurrences": [
  null,
  "الحوادث"
 ],
 "Ok": [
  null,
  "موافق"
 ],
 "Old password not accepted": [
  null,
  "كلمة السر القديمة غير مطابقة"
 ],
 "On failure": [
  null,
  "عند الفشل"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "بمجرد تثبيت Cockpit، قم بتمكينه باستخدام ”systemctl enable --now cockpit.socket“."
 ],
 "Only alphabets, numbers, : , _ , . , @ , - are allowed": [
  null,
  "فقط الحروف الهجائية، والأرقام، : ،، _، . ، @، @، - مسموح بها"
 ],
 "Only emergency": [
  null,
  "الطوارئ فقط"
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  "استخدم الخوارزميات المعتمدة والمسموح بها فقط عند الإقلاع في وضع FIPS."
 ],
 "Other": [
  null,
  "أُخرى"
 ],
 "Overview": [
  null,
  "نظرة عامة"
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "PackageKit crashed": [
  null,
  "تعطيل PackageKit"
 ],
 "Part of": [
  null,
  "جزء من"
 ],
 "Password": [
  null,
  "كلمة السر"
 ],
 "Password is not acceptable": [
  null,
  "كلمة السر غير مقبولة"
 ],
 "Password is too weak": [
  null,
  "كلمة السر ضعيفة جداً"
 ],
 "Password not accepted": [
  null,
  "كلمة السر مرفوضة"
 ],
 "Paste": [
  null,
  "لصق"
 ],
 "Paste error": [
  null,
  "خطأ في اللصق"
 ],
 "Path": [
  null,
  "مسار"
 ],
 "Path to file": [
  null,
  "المسار إلى الملف"
 ],
 "Paths": [
  null,
  "المسارات"
 ],
 "Pause": [
  null,
  "إيقاف مؤقَّت"
 ],
 "Performance profile": [
  null,
  "ملف تعريف الأداء"
 ],
 "Peripheral chassis": [
  null,
  "هيكل الأجهزة الطرفية"
 ],
 "Pick date": [
  null,
  "اختيار التاريخ والوقت"
 ],
 "Pin unit": [
  null,
  "تعليق الوحدة"
 ],
 "Pinned unit": [
  null,
  "الوحدة المعلَّقة"
 ],
 "Pizza box": [
  null,
  "صندوق البيتزا"
 ],
 "Portable": [
  null,
  "متنقل"
 ],
 "Present": [
  null,
  "موجود"
 ],
 "Pretty host name": [
  null,
  "الاسم الظاهر للمضيف"
 ],
 "Previous boot": [
  null,
  "جلسة الإقلاع السابقة"
 ],
 "Priority": [
  null,
  "الأولوية"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "انتهت مهلة الطلب عبر ssh-add"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "انتهت مهلة الطلب عبر ssh-keygen"
 ],
 "Propagates reload to": [
  null,
  "يُنقل أمر إعادة التحميل إلى"
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  "يوفر الحماية ضد الهجمات المتوقعة في المدى القريب على حساب التوافقية."
 ],
 "RAID chassis": [
  null,
  "هيكل RAID"
 ],
 "Rack mount chassis": [
  null,
  "هيكل مثبت على حامل"
 ],
 "Rank": [
  null,
  "الرتبة"
 ],
 "Read more...": [
  null,
  "اقرأ المزيد..."
 ],
 "Read-only": [
  null,
  "القراءة-فقط"
 ],
 "Real host name": [
  null,
  "اسم مضيف حقيقي"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "اسم المضيف الحقيقي يمكن أن يحتوي فقط على أحرف صغيرة وأرقام وشرطات ونقاط (مع نطاقات فرعية مأهولة)"
 ],
 "Real host name must be 64 characters or less": [
  null,
  "يجب أن يتكون اسم المضيف الحقيقي من ٦٤ حرفاً أو أقل"
 ],
 "Reapply and reboot": [
  null,
  "إعادة التطبيق ثم إعادة التشغيل"
 ],
 "Reboot": [
  null,
  "إعادة تشغيل"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  "الإعدادات الموصى بها والآمنة لنماذج التهديد الحالية."
 ],
 "Reload": [
  null,
  "إعادة تحميل"
 ],
 "Reload propagated from": [
  null,
  "إعادة التحميل المنتشر من"
 ],
 "Reloading": [
  null,
  "إعادة التحميل"
 ],
 "Removals:": [
  null,
  "عمليات الإزالة:"
 ],
 "Remove": [
  null,
  "إزالة"
 ],
 "Removing $0": [
  null,
  "قيد إزالة $0"
 ],
 "Repeat": [
  null,
  "تكرار"
 ],
 "Repeat monthly": [
  null,
  "التكرار شهرياً"
 ],
 "Repeat weekly": [
  null,
  "التكرار أسبوعياً"
 ],
 "Required by": [
  null,
  "مطلوب من قِبل"
 ],
 "Required by ": [
  null,
  "مطلوب من قِبل "
 ],
 "Requires": [
  null,
  "يتطلب"
 ],
 "Requires administration access to edit": [
  null,
  "يتطلب صلاحيات المسؤول للتعديل"
 ],
 "Requisite": [
  null,
  "متطلب"
 ],
 "Requisite of": [
  null,
  "متطلبات"
 ],
 "Reset": [
  null,
  "صفر"
 ],
 "Restart": [
  null,
  "أعد التشغيل"
 ],
 "Resume": [
  null,
  "استئناف"
 ],
 "Review cryptographic policy": [
  null,
  "مراجعة سياسة الحماية"
 ],
 "Row expansion": [
  null,
  "توسعة الصف"
 ],
 "Row select": [
  null,
  "حدد الصف"
 ],
 "Run at": [
  null,
  "تشغيل عند"
 ],
 "Run on": [
  null,
  "التشغيل على"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "قم بتشغيل هذا الأمر عبر شبكة موثوقة أوا مادياً على الجهاز البعيد:"
 ],
 "Running": [
  null,
  "التشغيل"
 ],
 "Running process prevents directory change": [
  null,
  "تشغيل العملية يمنع تغيير المجلد"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "مفتاح SSH"
 ],
 "SSH key login": [
  null,
  "تسجيل دخول عبر مفتاح SSH"
 ],
 "Saturdays": [
  null,
  "أيام السبت"
 ],
 "Save": [
  null,
  "حفظ"
 ],
 "Save and reboot": [
  null,
  "حفظ ثم إعادة تشغيل النظام"
 ],
 "Save changes": [
  null,
  "احفظ التغييرات"
 ],
 "Scheduled poweroff at $0": [
  null,
  "إيقاف تشغيل مجدول عند $0"
 ],
 "Scheduled reboot at $0": [
  null,
  "إعادة تشغيل للنظام مجدولة عند $0"
 ],
 "Sealed-case PC": [
  null,
  "حاسوب شخصي مغلق"
 ],
 "Search": [
  null,
  "ابحث"
 ],
 "Second needs to be a number between 0-59": [
  null,
  "الثواني يلزم أن تكون عددً بين ٠-٥٩"
 ],
 "Seconds": [
  null,
  "الثواني"
 ],
 "Secure shell keys": [
  null,
  "مفاتيح الطرفية الآمنة"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "إعداد نظام Linux المحسّن للأمان واستكشاف الأخطاء وإصلاحها"
 ],
 "Select an option": [
  null,
  "تحديد خيار"
 ],
 "Server has closed the connection.": [
  null,
  "قام الخادم بإغلاق الاتصال."
 ],
 "Server software": [
  null,
  "برنامج الخادم"
 ],
 "Service logs": [
  null,
  "سجلات الخدمة"
 ],
 "Services": [
  null,
  "الخدمات"
 ],
 "Set hostname": [
  null,
  "عيّن اسم المضيف"
 ],
 "Set time": [
  null,
  "تعيين الوقت"
 ],
 "Shell script": [
  null,
  "سكريبت شِل"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show confirmation password": [
  null,
  "إظهار تأكيد كلمة السر"
 ],
 "Show fingerprints": [
  null,
  "إظهار البصمات"
 ],
 "Show messages containing given string.": [
  null,
  "عرض الرسائل التي تحتوي على النص المحدد."
 ],
 "Show messages for the specified systemd unit.": [
  null,
  "عرض رسائل وحدة systemd المحددة."
 ],
 "Show messages from a specific boot.": [
  null,
  "إظهار الرسائل من إقلاع معين."
 ],
 "Show more relationships": [
  null,
  "عرض المزبد من العلاقات"
 ],
 "Show password": [
  null,
  "أظهر كلمة السر"
 ],
 "Show relationships": [
  null,
  "أظهر العلاقات"
 ],
 "Shut down": [
  null,
  "أوقف التشغيل"
 ],
 "Shutdown": [
  null,
  "إيقاف التشغيل"
 ],
 "Since": [
  null,
  "منذ"
 ],
 "Single rank": [
  null,
  "رتبة واحدة"
 ],
 "Size": [
  null,
  "الحجم"
 ],
 "Slot": [
  null,
  "الفتحة"
 ],
 "Sockets": [
  null,
  "مقابس التوصيل"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  "تساعد الحلول المستندة إلى البرامج في منع مشاكل أمان وحدة المعالجة المركزية. هذه الحلول لها تأثير جانبي يتمثل في تقليل الأداء. قم بتغيير هذه الإعدادات على مسؤوليتك الخاصة."
 ],
 "Space-saving computer": [
  null,
  "حاسوب موفر للمساحة"
 ],
 "Specific time": [
  null,
  "الوقت المحدد"
 ],
 "Speed": [
  null,
  "السرعة"
 ],
 "Start": [
  null,
  "بدء"
 ],
 "Start and enable": [
  null,
  "بدء ثم تفعيل"
 ],
 "Start service": [
  null,
  "بدء الخدمة"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  "بدء عرض الإدخالات في التاريخ المحدد أو أحدث منه."
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  "بدء عرض الإدخالات في التاريخ المحدد أو أقدم."
 ],
 "State": [
  null,
  "حالة"
 ],
 "Static": [
  null,
  "ثابت"
 ],
 "Status": [
  null,
  "الحالة"
 ],
 "Stick PC": [
  null,
  "حاسوب عصا"
 ],
 "Stop": [
  null,
  "إيقاف"
 ],
 "Stop and disable": [
  null,
  "إيقاف وإلغاء تفعيل"
 ],
 "Storage": [
  null,
  "التخزين"
 ],
 "Strong password": [
  null,
  "كلمة سر قوية"
 ],
 "Stub": [
  null,
  "هيكل أولي"
 ],
 "Sub-Chassis": [
  null,
  "الهيكل الفرعي"
 ],
 "Sub-Notebook": [
  null,
  "دفتر ملاحظات فرعي"
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  "فشل الاشتراك في إشارات النظام systemd: $0"
 ],
 "Successfully copied to clipboard": [
  null,
  "تم النسخ بنجاح إلى الحافظة"
 ],
 "Sundays": [
  null,
  "أيام الأحد"
 ],
 "Synchronized": [
  null,
  "متزامن"
 ],
 "Synchronized with $0": [
  null,
  "متزامن مع $0"
 ],
 "Synchronizing": [
  null,
  "جار المزامنة"
 ],
 "System": [
  null,
  "النظام"
 ],
 "System information": [
  null,
  "معلومات النظام"
 ],
 "System time": [
  null,
  "توقيت النظام"
 ],
 "Systemd units": [
  null,
  "وحدات Systemd"
 ],
 "Tablet": [
  null,
  "جهاز لوحي"
 ],
 "Targets": [
  null,
  "الأهداف"
 ],
 "Terminal": [
  null,
  "الطرفية"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "سيتم إضافة مفتاح SSH $0 الخاص بـ $1 على $2 إلى ملف $3 الخاص بـ $4 على $5."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "سيكون مفتاح SSH $0 متاحًا لبقية الجلسة وسيكون متاحًا لتسجيل الدخول إلى مضيفين آخرين أيضًا."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "مفتاح SSH لتسجيل الدخول إلى $0 محمي بكلمة سر، ولا يسمح المضيف بتسجيل الدخول بكلمة سر. يرجى تقديم كلمة سر المفتاح في $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "مفتاح SSH لتسجيل الدخول إلى $0 محمي. يمكنك تسجيل الدخول إما باستخدام كلمة سر تسجيل الدخول الخاصة بك أو عن طريق توفير كلمة سر المفتاح في $1."
 ],
 "The fingerprint should match:": [
  null,
  "ينبغي أن تتطابق البصمة:"
 ],
 "The key password can not be empty": [
  null,
  "مفتاح كلمة السر لا يمكن أن يكون فارغاً"
 ],
 "The key passwords do not match": [
  null,
  "كلمات المرور الرئيسية غير متطابقة"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "لا يُسمح للمستخدم الذي قام بتسجيل الدخول بعرض تعديلات النظام"
 ],
 "The password can not be empty": [
  null,
  "كلمة السر لا بمكن أن تكون فارغة"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "لا بأس بمشاركة البصمة الناتجة عبر الطرق العامة، بما في ذلك البريد الإلكتروني."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "بصمة المفتاح الناتجة آمنة للمشاركة عبر قنوات عامة، بما في ذلك البريد الإلكتروني."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "رفض الخادم المصادقة بأي طريقة مدعومة."
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  "المستخدم $0 غير مصرَّح له بتغيير إجراءات التخفيف الأمني لوحدة المعالجة المركزية (CPU)"
 ],
 "The user $0 is not permitted to change cryptographic policies": [
  null,
  "المستخدم $0 غير مصرَّح له بتغيير سياسات التشفير"
 ],
 "This field cannot be empty": [
  null,
  "هذا الحقل لا يمكن أن يكون فارغاً"
 ],
 "This may take a while": [
  null,
  "قد يستغرق هذا بعض الوقت"
 ],
 "This system is using a custom profile": [
  null,
  "هذا النظام يستخدم ملف تعريف مخصص"
 ],
 "This system is using the recommended profile": [
  null,
  "هذا النظام يستخدم ملف التعريف الموصى به"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "تقوم هذه الأداة بتكوين سياسة SELinux ويمكن أن تساعد في فهم انتهاكاتها وحلها."
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "تُهيئ هذه الأداة النظام لكتابة تفريغ أعطاب نواة النظام. وهي تدعم أهداف التفريغ التالية: \"محلي\" (على القرص)، و\"ssh\"، و\"nfs\"."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "تقوم هذه الأداة بإنشاء أرشيف يحتوي على معلومات الإعدادات والتشخيص من نظام التشغيل الذي يكون قيد العمل. قد يتم تخزين الأرشيف محليًا أو مركزيًا لأغراض التسجيل أو التتبع، أو إرساله إلى ممثلي الدعم الفني أو المطورين أو مسؤولي النظام اعدة في تحديد الأعطال ‌الفنية ، وتصحيح الأخطاء."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "تُدير هذه الأداة التخزين المحلي، بما في ذلك أنظمة الملفات، ومجموعات وحدات التخزين LVM2، ونقاط تركيب NFS."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "تُدير هذه الأداة الشبكات بما في ذلك الوصلات المجمعة (Bonds)، والجسور (Bridges)، وفرق الشبكات (Teams)، وشبكات VLAN، والجدران النارية، باستخدام NetworkManager وFirewalld. يُذكر أن NetworkManager غير متوافق مع نظام systemd-networkd الافتراضي في أوبونتو ونصوص ifupdown في دبيان."
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  "لم يتم تصميم هذه الوحدة ليتم تمكينها بشكل صريح."
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  "سيؤدي هذا إلى إضافة تطابق لـ '_BOOT_ID='. إذا لم يتم تحديده، سيتم عرض سجلات عملية الإقلاع الحالية. إذا حُذِف مُعرَّف الإقلاع (boot ID)، سيبحث الإزاحة الموجبة (positive offset) عن عمليات الإقلاع بدءًا من بداية سجلات النظام (journal)، بينما سيبحث الإزاحة المساوية للصفر أو الأقل (equal-or-less-than zero offset) عن عمليات الإقلاع بدءًا من نهاية السجل. وبالتالي: الرقم 1 يعني أول عملية إقلاع موجودة في السجل بالترتيب الزمني، 2 تعني الثانية وهكذا، بينما 0- يشير إلى آخر عملية إقلاع، و1- يشير إلى ما قبل الأخيرة، وهكذا."
 ],
 "This will add match for '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' and 'UNIT=' to find all possible messages for the given unit. Can contain more units separated by comma.": [
  null,
  "سيؤدي ذلك إلى إضافة تطابق لـ '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' و 'UNIT=' للعثور على جميع الرسائل المحتملة لهذه الوحدة. يمكن أن تحتوي على وحدات أكثر مفصولة بفاصلة."
 ],
 "Thursdays": [
  null,
  "أيام الخميس"
 ],
 "Time": [
  null,
  "وقت"
 ],
 "Time zone": [
  null,
  "المنطقة الزمنية"
 ],
 "Timer creation failed": [
  null,
  "فشل إنشاء المؤقِّت"
 ],
 "Timer deletion failed": [
  null,
  "فشل حذف المؤقِّت"
 ],
 "Timers": [
  null,
  "المؤقتات"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "لضمان عدم اعتراض اتصالك من قِبَل طرف ثالث ضار، يُرجى التحقق من بَصمة مفتاح الخادم:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "للتحقق من البصمة ، قم بتشغيل ما يلي على $0 أثناء تشغيل الجهاز أو من خلال شبكة موثوقة:"
 ],
 "Toggle date picker": [
  null,
  "إخفاء منتقي التاريخ و الوقت"
 ],
 "Toggle filters": [
  null,
  "تبديل عوامل التصفية"
 ],
 "Too much data": [
  null,
  "الكثير من البيانات"
 ],
 "Total size: $0": [
  null,
  "الحجم الإجمالي: $0"
 ],
 "Tower": [
  null,
  "برج"
 ],
 "Transient": [
  null,
  "مؤقَّت"
 ],
 "Trigger": [
  null,
  "المشغِّل"
 ],
 "Triggered by": [
  null,
  "تم تشغيله بواسطة"
 ],
 "Triggers": [
  null,
  "المشغِّلات"
 ],
 "Trust and add host": [
  null,
  "الثقة بالمضيف وإضافته"
 ],
 "Trying to synchronize with $0": [
  null,
  "محاولة المزامنة مع $0"
 ],
 "Tuesdays": [
  null,
  "أيام الخميس"
 ],
 "Tuned has failed to start": [
  null,
  "فشل الضبط في بدء التشغيل"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned هو خدمة تراقب نظامك وتحسّن أداءه تحت أعباء عمل محددة. جوهر Tuned يتمثل في التشكيلات التي تضبط نظامك ليتناسب مع حالات استخدام مختلفة."
 ],
 "Tuned is not available": [
  null,
  "Tuned غير متوفر"
 ],
 "Tuned is not running": [
  null,
  "Tuned ليس قيد التشغيل"
 ],
 "Tuned is off": [
  null,
  "Tuned مطفئ"
 ],
 "Type": [
  null,
  "النوع"
 ],
 "Type to filter": [
  null,
  "نوع عامل التصفية"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "تعذّر تسجيل الدخول إلى $0 باستخدام مصادقة مفتاح SSH. يرجى إدخال كلمة السر."
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "تعذّر تسجيل الدهول إلى $0. لا يقبل المضيف تسجيل الدخول بكلمة سر ، أو أي من مفاتيح SSH الخاصة بك."
 ],
 "Unable to open directory": [
  null,
  "تعذر فتح المجلد"
 ],
 "Unit": [
  null,
  "وحدة"
 ],
 "Unknown": [
  null,
  "غير معروف"
 ],
 "Unknown host: $0": [
  null,
  "مضيف غير معروف: $0"
 ],
 "Unpin unit": [
  null,
  "وحدة فك التثبيت"
 ],
 "Until": [
  null,
  "حتى"
 ],
 "Untrusted host": [
  null,
  "مضيف غير موثوق به"
 ],
 "Up since": [
  null,
  "منذ ذلك الحين"
 ],
 "Updating status...": [
  null,
  "حالة التحديث..."
 ],
 "Usage": [
  null,
  "الاستخدام"
 ],
 "User": [
  null,
  "المستخدم"
 ],
 "Validating address": [
  null,
  "التحقق من صحة العنوان"
 ],
 "Vendor": [
  null,
  "المُنتِج"
 ],
 "Verify fingerprint": [
  null,
  "أكّد البصمة"
 ],
 "Version": [
  null,
  "الإصدار"
 ],
 "View Podman container": [
  null,
  "عرض حاوية Podman"
 ],
 "View all logs": [
  null,
  "عرض جميع السجلات"
 ],
 "View all services": [
  null,
  "عرض جميع الخدمات"
 ],
 "View automation script": [
  null,
  "عرض سكربت الأتمتة"
 ],
 "View hardware details": [
  null,
  "عرض تفاصيل العتاد المادي"
 ],
 "View login history": [
  null,
  "عرض التاريخ المسجَّل"
 ],
 "View metrics and history": [
  null,
  "عرض المقاييس والتاريخ"
 ],
 "Viewing memory information requires administrative access.": [
  null,
  "يتطلب عرض معلومات الذاكرة الوصول الإداري."
 ],
 "Visit firewall": [
  null,
  "زر الجدار الناري"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "ينتظر انتهاء عمليات مدير البرامج الآخر"
 ],
 "Wanted by": [
  null,
  "مطلوب من قبل"
 ],
 "Wants": [
  null,
  "المطلوبات"
 ],
 "Warning and above": [
  null,
  "تحذير وما فوق"
 ],
 "Weak password": [
  null,
  "كلمة سر ضعيفة"
 ],
 "Web Console for Linux servers": [
  null,
  "وحدة تحكم الويب لخوادم Linux"
 ],
 "Web console is running in limited access mode.": [
  null,
  "تعمل وحدة تحكم الويب في وضع الوصول المحدود."
 ],
 "Wednesdays": [
  null,
  "أيام الأربعاء"
 ],
 "Weekly": [
  null,
  "أسبوعياً"
 ],
 "Weeks": [
  null,
  "أسابيع"
 ],
 "White": [
  null,
  "أبيض"
 ],
 "Yearly": [
  null,
  "سنوياً"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "انت تتصل بـ $0 لأول مرة."
 ],
 "You may try to load older entries.": [
  null,
  "يمكنك محاولة تحميل الإدخالات القديمة."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "لا يسمح متصفحك باللصق من قائمة السياق. يمكنك استخدام Shift+Insert."
 ],
 "Your session has been terminated.": [
  null,
  "تم إنهاء جلستك."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "انتهت صلاحية جلستك , يرجى تسجيل الدخول مرة أخرى."
 ],
 "Zone": [
  null,
  "المنطقة"
 ],
 "[binary data]": [
  null,
  "[بيانات ثنائية]"
 ],
 "[no data]": [
  null,
  "[لا بيانات]"
 ],
 "active": [
  null,
  "نشِط"
 ],
 "edit": [
  null,
  "عدِّل"
 ],
 "failed to list ssh host keys: $0": [
  null,
  "فشل في سرد مفاتيح ssh للمضيف: $0"
 ],
 "in less than a minute": [
  null,
  "في أقل من دقيقة"
 ],
 "inconsistent": [
  null,
  "غير متناسق"
 ],
 "journalctl manpage": [
  null,
  "صفحة الدليل لأداة journalctl"
 ],
 "less than a minute ago": [
  null,
  "منذ أقل من دقيقة"
 ],
 "none": [
  null,
  "لا شيء"
 ],
 "of $0 CPU": [
  null,
  "من $0 وحدة معالجة مركزية",
  "من وحدة معالجة مركزية واحدة CPU",
  "من وحدتي معالجة مركزية CPUs",
  "من $0 وحدة معالجة مركزية CPUs",
  "من $0 وحدة معالجة مركزية CPUs",
  "من $0 وحدة معالجة مركزية CPUs"
 ],
 "password quality": [
  null,
  "جودة كلمة السر"
 ],
 "recommended": [
  null,
  "مستحسن"
 ],
 "running $0": [
  null,
  "قيد تشغيل $0"
 ],
 "show less": [
  null,
  "عرض أقل"
 ],
 "show more": [
  null,
  "عرض أكثر"
 ],
 "unknown": [
  null,
  "غير معروف"
 ],
 "dialog-title\u0004Domain": [
  null,
  "نطاق"
 ],
 "dialog-title\u0004Join a domain": [
  null,
  "الانضمام إلى نطاق"
 ],
 "from <host>\u0004from $0": [
  null,
  "من $0"
 ],
 "from <host> on <terminal>\u0004from $0 on $1": [
  null,
  "من $0 على $1"
 ],
 "on <terminal>\u0004on $0": [
  null,
  "على $0"
 ]
});
