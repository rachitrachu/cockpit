cockpit.locale({
 "": {
  "plural-forms": (n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2,
  "language": "sk",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 critical hit": [
  null,
  "$0 kritický zásah",
  "$0 kritické zásahy",
  "$0 kritických zásahov"
 ],
 "$0 day": [
  null,
  "$0 deň",
  "$0 dni",
  "$0 dní"
 ],
 "$0 does not exist": [
  null,
  "$0 neexistuje"
 ],
 "$0 exited with code $1": [
  null,
  "$0 skončilo s kódom $1"
 ],
 "$0 failed": [
  null,
  "$0 sa nepodarilo"
 ],
 "$0 failed login attempt": [
  null,
  "$0 neúspešný pokus o prihlásenie",
  "$0 neúspešné pokusy o prihlásenie",
  "$0 neúspešných pokusov o prihlásenie"
 ],
 "$0 filters applied": [
  null,
  ""
 ],
 "$0 hour": [
  null,
  "$0 hodina",
  "$0 hodiny",
  "$0 hodín"
 ],
 "$0 important hit": [
  null,
  "$0 dôležitý zásah",
  "$0 zásahy, vrátane dôležitých",
  "$0 zásahov, vrátane dôležitých"
 ],
 "$0 is not a directory": [
  null,
  "$0 nie je adresár"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 nie je k dispozícií v žiadom repozitári."
 ],
 "$0 key changed": [
  null,
  "$0 kľúč sa zmenil"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 nútene ukončené signálom $1"
 ],
 "$0 low severity hit": [
  null,
  "$0 zásah s nízkou prioritou",
  "$0 zásahy s nízkou prioritou",
  "$0 zásahov s nízkou prioritou"
 ],
 "$0 minute": [
  null,
  "$0 minúta",
  "$0 minúty",
  "$0 minút"
 ],
 "$0 moderate hit": [
  null,
  "$0 zásah strednej závažnosti",
  "$0 zásahy, vrátane strednej závažnosti",
  "$0 zásahov, vrátane strednej závažnosti"
 ],
 "$0 month": [
  null,
  "$0 mesiac",
  "$0 mesiace",
  "$0 mesiacov"
 ],
 "$0 service has failed": [
  null,
  "$0 služba havarovala",
  "$0 služby havarovali",
  "$0 služieb havarovalo"
 ],
 "$0 week": [
  null,
  "$0 týždeň",
  "$0 týždne",
  "$0 týždňov"
 ],
 "$0 will be installed.": [
  null,
  "Nainštaluje sa $0."
 ],
 "$0 year": [
  null,
  "$0 rok",
  "$0 roky",
  "$0 rokov"
 ],
 "1 day": [
  null,
  "1 deň"
 ],
 "1 hour": [
  null,
  "1 hodina"
 ],
 "1 minute": [
  null,
  "1 minúta"
 ],
 "1 week": [
  null,
  "1 týždeň"
 ],
 "10th": [
  null,
  "10."
 ],
 "11th": [
  null,
  "11."
 ],
 "12th": [
  null,
  "12."
 ],
 "13th": [
  null,
  "13."
 ],
 "14th": [
  null,
  "14."
 ],
 "15th": [
  null,
  "15."
 ],
 "16th": [
  null,
  "16."
 ],
 "17th": [
  null,
  "17."
 ],
 "18th": [
  null,
  "18."
 ],
 "19th": [
  null,
  "19."
 ],
 "1st": [
  null,
  "1."
 ],
 "20 minutes": [
  null,
  "20 minút"
 ],
 "20th": [
  null,
  "20."
 ],
 "21th": [
  null,
  "21."
 ],
 "22th": [
  null,
  "22."
 ],
 "23th": [
  null,
  "23."
 ],
 "24th": [
  null,
  "24."
 ],
 "25th": [
  null,
  "25."
 ],
 "26th": [
  null,
  "26."
 ],
 "27th": [
  null,
  "27."
 ],
 "28th": [
  null,
  "28."
 ],
 "29th": [
  null,
  "29."
 ],
 "2nd": [
  null,
  "2."
 ],
 "30th": [
  null,
  "30."
 ],
 "31st": [
  null,
  "31."
 ],
 "3rd": [
  null,
  "3."
 ],
 "40 minutes": [
  null,
  "40 minút"
 ],
 "4th": [
  null,
  "4."
 ],
 "5 minutes": [
  null,
  "5 minút"
 ],
 "5th": [
  null,
  "5."
 ],
 "6 hours": [
  null,
  "6 hodín"
 ],
 "60 minutes": [
  null,
  "60 minút"
 ],
 "6th": [
  null,
  "6."
 ],
 "7th": [
  null,
  "7."
 ],
 "8th": [
  null,
  "8."
 ],
 "9th": [
  null,
  "9."
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Na $0 nie je nainštalovaná kompatibilná verzia Cockpitu."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Na $0 bude vygenerovaný nový kľúč SSH $1 na $2 a bude pridaný do súboru $3 $4 na $5."
 ],
 "Absent": [
  null,
  "Chýba"
 ],
 "Acceptable password": [
  null,
  "Prijateľné heslo"
 ],
 "Active since ": [
  null,
  "Aktívna od "
 ],
 "Active state": [
  null,
  "Aktívny stav"
 ],
 "Add": [
  null,
  "Pridať"
 ],
 "Add $0": [
  null,
  "Pridať $0"
 ],
 "Additional actions": [
  null,
  "Ďalšie akcie"
 ],
 "Additional packages:": [
  null,
  "Ďalšie balíky:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Správa pomocou webovej konzole Cockpit"
 ],
 "Advanced TCA": [
  null,
  "Pokročilé TCA"
 ],
 "After": [
  null,
  "Po"
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "Po opustení domény sa k tomuto stroji budú môcť prihlásiť iba tí užívatelia, ktorý majú účet priamo na ňom. Môže to postihnúť aj ostatné služby, ako je nastavenie DNS prekladu a môže sa zmeniť zoznam dôveryhodných cert. autorít."
 ],
 "After system boot": [
  null,
  "Po štarte systému"
 ],
 "Alert and above": [
  null,
  "Výstraha a závažnejšie"
 ],
 "Alias": [
  null,
  "Alternatívny názov"
 ],
 "All": [
  null,
  "Všetko"
 ],
 "All-in-one": [
  null,
  "All-in-one"
 ],
 "Allow running (unmask)": [
  null,
  "Povoliť spustenie (odmaskovať)"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Dokumentácia k Ansible roliam"
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  "V správach záznamu je možné filtrovať podľa ľubovoľného textového reťazca. Reťazec tiež môže mať podobu regulárneho výrazu. Rovnako je podporované filtrovanie podľa polí správ záznamu udalostí. Tie uvádzajte ako medzerami oddeľované hodnoty v podobe POLE=HODNOTA, kde hodnota môže byť čiarkou oddelený zoznam možných hodnôt."
 ],
 "Appearance": [
  null,
  "Vzhľad"
 ],
 "Apply and reboot": [
  null,
  "Použiť a reštartovať"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  "Aplikujú sa nové politiky… Toto môže niekoľko minút trvať."
 ],
 "Asset tag": [
  null,
  "Inventárny štítok"
 ],
 "At minute": [
  null,
  "V minúte"
 ],
 "At second": [
  null,
  "V sekunde"
 ],
 "At specific time": [
  null,
  "V konkrétny čas"
 ],
 "Authentication": [
  null,
  "Overovanie"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Pre vykonávanie privilegovaných úloh pomocou webovej konzole Cockpit je potrebné overiť svoju totožnosť"
 ],
 "Authorize SSH key": [
  null,
  "Poveriť SSH kľúč"
 ],
 "Automatically starts": [
  null,
  "Spúšťa sa automaticky"
 ],
 "Automatically using NTP": [
  null,
  "Automaticky využitím NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Automatické využitím ďalších NTP serverov"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automaticky využitím konkrétnych NTP serverov"
 ],
 "Automation script": [
  null,
  "Automatizačný skript"
 ],
 "BIOS": [
  null,
  "BIOS"
 ],
 "BIOS date": [
  null,
  "Dátum vydania BIOSu"
 ],
 "BIOS version": [
  null,
  "Verzia BIOSu"
 ],
 "Bad": [
  null,
  "Chybné"
 ],
 "Bad setting": [
  null,
  "Chybné nastavenie"
 ],
 "Before": [
  null,
  "Pred"
 ],
 "Binds to": [
  null,
  "Viaže sa na"
 ],
 "Black": [
  null,
  "Čierny"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Skriňa pre blade servery"
 ],
 "Boot": [
  null,
  "Zavádzanie"
 ],
 "Bound by": [
  null,
  "Viazaný"
 ],
 "Bus expansion chassis": [
  null,
  "Šasi pre rozšírenie zbernice"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "CPU security": [
  null,
  "Zabezpečenie procesoru"
 ],
 "CPU security toggles": [
  null,
  "Prepínače zabezpečenia procesora"
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "Nepodarilo sa nájsť žiadne záznamy pre danú kombináciu filtrov."
 ],
 "Cancel": [
  null,
  "Zrušiť"
 ],
 "Cancel poweroff": [
  null,
  "Zrušiť vypínanie"
 ],
 "Cancel reboot": [
  null,
  "Zrušiť reštart"
 ],
 "Cannot be enabled": [
  null,
  "Nie je možné povoliť"
 ],
 "Cannot forward login credentials": [
  null,
  "Nie je možné preposlať prístupové údaje"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  "Nie je možné pridanie do domény, pretože na tomto systéme chýba realmd"
 ],
 "Cannot schedule event in the past": [
  null,
  "Nie je možné plánovať udalosti do minulosti"
 ],
 "Change": [
  null,
  "Zmeniť"
 ],
 "Change cryptographic policy": [
  null,
  "Zmeniť politiky pre šifrovanie"
 ],
 "Change host name": [
  null,
  "Zmeniť názov stroja"
 ],
 "Change performance profile": [
  null,
  "Zmeniť profil výkonu"
 ],
 "Change profile": [
  null,
  "Zmeniť profil"
 ],
 "Change system time": [
  null,
  "Zmeniť systémový čas"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Zmenené kľúče sú často výsledkom preinštalovania operačného systému. Avšak neočakávaná zmena môže znamenať, že sa tretia strana snaží odpočúvať vaše spojenie."
 ],
 "Changing the directory will forcefully stop the currently running process. The process can also be stopped manually in the terminal before continuing.": [
  null,
  ""
 ],
 "Checking installed software": [
  null,
  "Zisťujem nainštalovaný softvér"
 ],
 "Class": [
  null,
  "Trieda"
 ],
 "Clear 'Failed to start'": [
  null,
  "Vyčistiť „Nepodarilo sa spustiť“"
 ],
 "Clear all filters": [
  null,
  "Vypnúť všetky filtre"
 ],
 "Client software": [
  null,
  "Softvér klienta"
 ],
 "Close": [
  null,
  "Zavrieť"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Konfigurácia NetworkManagera a Firewalld v Cockpite"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpitu sa nepodarilo kontaktovať daného hostiteľa."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit je správca serveru, který uľahčuje správu Linuxových serverov cez webový prehliadač. Nie je žiadnym problémom prechádzať medzi terminálom a webovým nástrojom. Služba spustená cez Cockpit môže byť zastavená v termináli. Podobne, pokiaľ dôjde k chybe v termináli, je toto vidieť v rozhraní žurnálu v Cockpite."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit nie je kompatibilný so sofvérom na systéme."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit nie je nainštalovaný"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit nie je nainštalovaný na tomto systéme."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit je skvelý nástroj pre nových správcov serverov, ktorým jednoducho umožňuje vykonávať úlohy ako správa úložiska, kontrola žurnálu a spúšťanie či zastavovanie služieb. Môžte monitorovať a spravovať viacero serverov naraz. Stačí ich pridať jedným kliknutím a vaše stroje sa budú starať o svojích kamarátov."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Zhromaždiť a zabaliť dáta pre diagnostiku a podporu"
 ],
 "Collect kernel crash dumps": [
  null,
  "Zhromaždiť výpisy pádov jadra systému"
 ],
 "Command": [
  null,
  "Príkaz"
 ],
 "Command not found": [
  null,
  "Príkaz nebol nájdený"
 ],
 "Communication with tuned has failed": [
  null,
  "Komunikácia s tuned sa nepodarila"
 ],
 "Compact PCI": [
  null,
  "Kompaktné PCI"
 ],
 "Condition $0=$1 was not met": [
  null,
  "Podmienka $0=$1 nebola splnená"
 ],
 "Condition failed": [
  null,
  "Podmienka nesplnená"
 ],
 "Configuration": [
  null,
  "Konfigurácia"
 ],
 "Confirm deletion of $0": [
  null,
  "Potvrďte odstránenie $0"
 ],
 "Confirm key password": [
  null,
  "Potvrdiť heslo ku kľúči"
 ],
 "Conflicted by": [
  null,
  "V konflikte"
 ],
 "Conflicts": [
  null,
  "V konflikte"
 ],
 "Connecting to dbus failed: $0": [
  null,
  "Pripojenie k dbus sa nepodarilo: $0"
 ],
 "Connection has timed out.": [
  null,
  "Časový limit spojenia vypršal."
 ],
 "Consists of": [
  null,
  "Skladá sa z"
 ],
 "Contacted domain": [
  null,
  "Pripojená doména"
 ],
 "Convertible": [
  null,
  "Počítač 2v1"
 ],
 "Copied": [
  null,
  "Skopírované"
 ],
 "Copy": [
  null,
  "Kopírovať"
 ],
 "Copy to clipboard": [
  null,
  "Kopírovať do schránky"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Vytvoriť nový SSH kľúč a poveriť ho"
 ],
 "Create new task file with this content.": [
  null,
  "Vytvoriť nový súbor s úlohou s týmto obsahom."
 ],
 "Create timer": [
  null,
  "Vytvoriť časovač"
 ],
 "Critical and above": [
  null,
  "Kritické a závažnejšie"
 ],
 "Cryptographic Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  "Kryptografické politiky sú súčasť systému, ktorá nastavuje hlavné kryptografické subsystémy, pokrýva protokoly TLS, IPSec, SSH, DNSSec a Kerberos."
 ],
 "Cryptographic policy": [
  null,
  "Politiky pre šifrovanie"
 ],
 "Cryptographic policy is inconsistent": [
  null,
  "Politiky pre šifrovanie nie sú konzistentné"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Current boot": [
  null,
  "Od tohto spustenia"
 ],
 "Custom cryptographic policy": [
  null,
  "Používateľom definovaná politiky pre šifrovanie"
 ],
 "DEFAULT with SHA-1 signature verification allowed.": [
  null,
  "PREDVOLENÝ so zapnutím overovania podpisu SHA-1."
 ],
 "Daily": [
  null,
  "Denne"
 ],
 "Dark": [
  null,
  "Tmavý"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  "Zadané dátumy by mali byť vo formáte RRRR-MM-DD hh:mm:ss. Prípadne je možné použiť aj reťazce „yesterday\" (včera), „today\" (dnes), „tomorrow\" (zajtra). „Now\" (teraz) odkazuje na aktuálny čas. Ďalej je možné zadávať relatívne časy uvedené predponou „-\" alebo „+\""
 ],
 "Debug and above": [
  null,
  "Ladiace a závažnejšie"
 ],
 "Decrease by one": [
  null,
  "Znížiť o jedno"
 ],
 "Default": [
  null,
  "Predvolené"
 ],
 "Delay": [
  null,
  "Omeškanie"
 ],
 "Delay must be a number": [
  null,
  "Je potrebné, aby oneskorenie bolo číslo"
 ],
 "Delete": [
  null,
  "Odstrániť"
 ],
 "Deletion will remove the following files:": [
  null,
  "Zmazanie odstráni nasledujúce súbory:"
 ],
 "Description": [
  null,
  "Popis"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Detachable": [
  null,
  "Odpojiteľné"
 ],
 "Details": [
  null,
  "Detaily"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostické hlásenia"
 ],
 "Disable simultaneous multithreading": [
  null,
  "Vypnúť simultánny multithreading"
 ],
 "Disable tuned": [
  null,
  "Vypnúť tuned"
 ],
 "Disabled": [
  null,
  "Vypnutá"
 ],
 "Disallow running (mask)": [
  null,
  "Nepovoliť spustenie (maskovať)"
 ],
 "Docking station": [
  null,
  "Dokovacia stanica"
 ],
 "Does not automatically start": [
  null,
  "Nespúšťa sa automaticky"
 ],
 "Domain": [
  null,
  "Doména"
 ],
 "Domain address": [
  null,
  "Adresa domény"
 ],
 "Domain administrator name": [
  null,
  "Meno správcu domény"
 ],
 "Domain administrator password": [
  null,
  "Heslo správcu domény"
 ],
 "Domain could not be contacted": [
  null,
  "Doménu sa nepodarilo kontaktovať"
 ],
 "Domain is not supported": [
  null,
  "Doména nie je podporovaná"
 ],
 "Don't repeat": [
  null,
  "Neopakovať"
 ],
 "Downloading $0": [
  null,
  "Sťahujem $0"
 ],
 "Dual rank": [
  null,
  "Dual rank"
 ],
 "Edit /etc/motd": [
  null,
  "Upraviť /etc/motd"
 ],
 "Edit motd": [
  null,
  "Upraviť motd"
 ],
 "Embedded PC": [
  null,
  "Jednodoskový počítač"
 ],
 "Enabled": [
  null,
  "Povolená"
 ],
 "Entry at $0": [
  null,
  "Položka z"
 ],
 "Error": [
  null,
  "Chyba"
 ],
 "Error and above": [
  null,
  "Chyba a závažnejšie"
 ],
 "Error message": [
  null,
  "Chybové hlásenie"
 ],
 "Excellent password": [
  null,
  "Skvelé heslo"
 ],
 "Expansion chassis": [
  null,
  "Rozširujúce šasi"
 ],
 "FIPS is not properly enabled": [
  null,
  "FIPS nie je poriadne zapnuté"
 ],
 "FIPS with further Common Criteria restrictions.": [
  null,
  "FIPS s ďalšími obmedzeniami Common Criteria."
 ],
 "Failed to change password": [
  null,
  "Nepodarilo sa zmeniť heslo"
 ],
 "Failed to disable tuned": [
  null,
  "Nepodarilo sa deaktivovať tuned"
 ],
 "Failed to disable tuned profile": [
  null,
  "Nepodarilo sa vypnúť profil tuned"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Nepodarilo sa povoliť $0 vo firewalld"
 ],
 "Failed to enable tuned": [
  null,
  "Nepodarilo sa aktivovať tuned"
 ],
 "Failed to fetch logs": [
  null,
  "Nepodarilo sa získať záznamy udalostí"
 ],
 "Failed to load unit": [
  null,
  "Jednotku sa nepodarilo načítať"
 ],
 "Failed to save changes in /etc/motd": [
  null,
  "Nepodarilo sa uložiť zmeny v /etc/motd"
 ],
 "Failed to start": [
  null,
  "Nepodarilo sa spustiť"
 ],
 "Failed to switch profile": [
  null,
  "Nepodarilo sa prepnúť profil"
 ],
 "File state": [
  null,
  "Stav súboru"
 ],
 "Filter by name or description": [
  null,
  "Filtrovať podľa názvu či popisu"
 ],
 "Filters": [
  null,
  "Filtre"
 ],
 "Font size": [
  null,
  "Veľkosť písma"
 ],
 "Forbidden from running": [
  null,
  "Spustenie je zakázané"
 ],
 "Free-form search": [
  null,
  "Vyhľadávania voľnou formou"
 ],
 "Fridays": [
  null,
  "Piatky"
 ],
 "Generated": [
  null,
  "Vytvorené"
 ],
 "Go to $0": [
  null,
  "Prejsť na $0"
 ],
 "Go to now": [
  null,
  "Prejsť na súčasnosť"
 ],
 "Handheld": [
  null,
  "Pre držanie do ruky"
 ],
 "Hardware information": [
  null,
  "Informácie o hardware"
 ],
 "Health": [
  null,
  "Kondícia systému"
 ],
 "Help": [
  null,
  "Nápoveda"
 ],
 "Hide confirmation password": [
  null,
  "Skryť potvrdenie hesla"
 ],
 "Hide password": [
  null,
  "Skryť heslo"
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  "Vyššia interoperabilita za cenu zvýšeného vystavenia sa útokom."
 ],
 "Host key is incorrect": [
  null,
  "Kľúč stroja nie je správny"
 ],
 "Hostname": [
  null,
  "Názov stroja"
 ],
 "Hourly": [
  null,
  "Každú hodinu"
 ],
 "Hours": [
  null,
  "Hodiny"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Identifier": [
  null,
  "Identifikátor"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Ak sa odtlačok zhoduje, kliknite na „Dôverovať a pridať stroj\". V opačnom prípade sa nepripájajte a obráťte sa na správcu systému."
 ],
 "Increase by one": [
  null,
  "Zvýšiť o jednu"
 ],
 "Indirect": [
  null,
  "Nepriamo"
 ],
 "Info and above": [
  null,
  "Informácia a závažnejšie"
 ],
 "Insights: ": [
  null,
  "Insights: "
 ],
 "Install": [
  null,
  "Inštalovať"
 ],
 "Install realmd support": [
  null,
  "Nainštalovať podporu pre realmd"
 ],
 "Install software": [
  null,
  "Nainštalovať softvér"
 ],
 "Installing $0": [
  null,
  "Inštalujem $0"
 ],
 "Internal error": [
  null,
  "Interná chyba"
 ],
 "Invalid": [
  null,
  "Neplatné"
 ],
 "Invalid date format": [
  null,
  "Neplatný formát dátumu"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Neplatný formát dátumu a času"
 ],
 "Invalid file permissions": [
  null,
  "Neplatné práva súborov"
 ],
 "Invalid time format": [
  null,
  "Neplatný formát čase"
 ],
 "Invalid timezone": [
  null,
  "Neplatná časová zóna"
 ],
 "IoT gateway": [
  null,
  "Brána internetu vecí (IoT)"
 ],
 "Join": [
  null,
  "Spojiť"
 ],
 "Join domain": [
  null,
  "Pripojiť sa k doméne"
 ],
 "Joining": [
  null,
  "Pridávam"
 ],
 "Joining a domain requires installation of realmd": [
  null,
  "Pripájanie sa do domény vyžaduje inštaláciu realmd"
 ],
 "Joining this domain is not supported": [
  null,
  "Pridanie do tejto domény nie je podporované"
 ],
 "Joins namespace of": [
  null,
  "Pripája menný priestor od"
 ],
 "Journal": [
  null,
  "Žurnál"
 ],
 "Journal entry": [
  null,
  "Položka žurnálu"
 ],
 "Journal entry not found": [
  null,
  "Položka žurnálu nájdená"
 ],
 "Kernel dump": [
  null,
  "Výpis pamäti jadra"
 ],
 "Key password": [
  null,
  "Heslo ku kľúču"
 ],
 "LEGACY with Active Directory interoperability.": [
  null,
  "PÔVODNÉ s interoperabilitou s Active Directory."
 ],
 "Laptop": [
  null,
  "Notebook"
 ],
 "Last 24 hours": [
  null,
  "Posledných 24 hodín"
 ],
 "Last 7 days": [
  null,
  "Posledných 7 dní"
 ],
 "Last successful login:": [
  null,
  "Posledné úspešné prihlásenie:"
 ],
 "Learn more": [
  null,
  "Zistiť viac"
 ],
 "Leave $0": [
  null,
  "Opustiť $0"
 ],
 "Leave domain": [
  null,
  "Opustiť doménu"
 ],
 "Light": [
  null,
  "Svetlý"
 ],
 "Linked": [
  null,
  "Odkazované"
 ],
 "Listen": [
  null,
  "Načúvať"
 ],
 "Listing units": [
  null,
  "Vypisujem jednotky"
 ],
 "Listing units failed: $0": [
  null,
  "Vypisovanie jednotiek skončilo s chybou: $0"
 ],
 "Load earlier entries": [
  null,
  "Načítať skoršie položky"
 ],
 "Loading keys...": [
  null,
  "Načítavam kľúče..."
 ],
 "Loading of SSH keys failed": [
  null,
  "Načítanie SSH kľúčov sa nepodarilo"
 ],
 "Loading of units failed": [
  null,
  "Načítanie jednotiek sa nepodarilo"
 ],
 "Loading system modifications...": [
  null,
  "Načítavam systémové zmeny..."
 ],
 "Loading unit failed": [
  null,
  "Načítanie jednotiek zlyhalo"
 ],
 "Loading...": [
  null,
  "Načítavam..."
 ],
 "Log in": [
  null,
  "Prihlásiť"
 ],
 "Log in to $0": [
  null,
  "Prihlásiť sa k $0"
 ],
 "Log messages": [
  null,
  "Záznamy udalostí"
 ],
 "Login failed": [
  null,
  "Prihlásenie sa nepodarilo"
 ],
 "Login format": [
  null,
  "Formát prihlasovania"
 ],
 "Logs": [
  null,
  "Záznamy udalostí"
 ],
 "Low profile desktop": [
  null,
  "Nízky desktop"
 ],
 "Lunch box": [
  null,
  "Kufríkový počítač"
 ],
 "Machine ID": [
  null,
  "Identifikátor stroja"
 ],
 "Machine SSH key fingerprints": [
  null,
  "Odtlačky SSH kľúčov stroja"
 ],
 "Main server chassis": [
  null,
  "Šasi hlavného servera"
 ],
 "Maintenance": [
  null,
  "Údržba"
 ],
 "Manage storage": [
  null,
  "Spravovať úložisko"
 ],
 "Manually": [
  null,
  "Ručne"
 ],
 "Mask service": [
  null,
  "Maskovať službu"
 ],
 "Masked": [
  null,
  "Maskovaná"
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  "Maskovanie služby zabráni spúšťaniu všetkých závislých jednotiek. Toto môže mať väčší dopad ako je zamýšľané. Prosím potvrďte, že chcete maskovať túto jednotku."
 ],
 "Memory": [
  null,
  "Pamäť"
 ],
 "Memory technology": [
  null,
  "Technológia pamäte"
 ],
 "Merged": [
  null,
  "Zlúčené"
 ],
 "Message to logged in users": [
  null,
  "Správa pre prihlásených používateľov"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Miniveža"
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "Minúta musí byť číslo medzi 0-59"
 ],
 "Minutely": [
  null,
  "Po minútach"
 ],
 "Minutes": [
  null,
  "Minúty"
 ],
 "Mitigations": [
  null,
  "Zmiernenia dopadu"
 ],
 "Model": [
  null,
  "Model"
 ],
 "Mondays": [
  null,
  "Pondelky"
 ],
 "Monthly": [
  null,
  "Každý mesiac"
 ],
 "Multi-system chassis": [
  null,
  "Šasi pre viac systémov"
 ],
 "NTP server": [
  null,
  "NTP server"
 ],
 "Name": [
  null,
  "Názov"
 ],
 "Need at least one NTP server": [
  null,
  "Je potrebný aspoň jeden server NTP"
 ],
 "Networking": [
  null,
  "Sieť"
 ],
 "New password was not accepted": [
  null,
  "Nové heslo nebolo prijaté"
 ],
 "No delay": [
  null,
  "Bez oneskorenia"
 ],
 "No host keys found.": [
  null,
  "Neboli nájdené žiadne kľúče stroja."
 ],
 "No log entries": [
  null,
  "Žiadne záznamy udalostí"
 ],
 "No logs found": [
  null,
  "Nenájdené žiadne záznamy udalostí"
 ],
 "No matching results": [
  null,
  "Žiadne vyhovujúce výsledky"
 ],
 "No results found": [
  null,
  "Neboli nájdené žiadne výsledky"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  "Kritériám filtra nezodpovedajú žiadne výsledky. Pre zobrazenie výsledkov vypnite všetky filtre."
 ],
 "No rule hits": [
  null,
  "Žiadne zásahy pravidla"
 ],
 "No such file or directory": [
  null,
  "Žiaden taký súbor alebo adresár neexistuje"
 ],
 "No system modifications": [
  null,
  "Žiadne systémové zmeny"
 ],
 "None": [
  null,
  "Žiadny"
 ],
 "Not a valid private key": [
  null,
  "Nie je platná súkromná časť kľúča"
 ],
 "Not connected to Insights": [
  null,
  "Nepripojené k Insights"
 ],
 "Not found": [
  null,
  "Nenájdené"
 ],
 "Not permitted to configure realms": [
  null,
  "Nemáte oprávnenia nastavovať realmy"
 ],
 "Not permitted to perform this action.": [
  null,
  "Neoprávený k vykonaniu tejto akcie."
 ],
 "Not running": [
  null,
  "Nespustená"
 ],
 "Not synchronized": [
  null,
  "Nezosynchronizované"
 ],
 "Note": [
  null,
  "Poznámka"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Notice and above": [
  null,
  "Oznámenie a závažnejšie"
 ],
 "Occurrences": [
  null,
  "Výskyty"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Old password not accepted": [
  null,
  "Pôvodné heslo nebolo prijaté"
 ],
 "On failure": [
  null,
  "Pri chybe"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Keď bude Cockpit nainštalovaný, povoľte ho pomocou \"systemctl enable --now cockpit.socket\"."
 ],
 "Only alphabets, numbers, : , _ , . , @ , - are allowed": [
  null,
  "Sú povolené iba písmena, čísla a znaky :_.@-"
 ],
 "Only emergency": [
  null,
  "Iba núdzové"
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  "Pri štarte systému v režime FIPS použiť iba schválené a povolené algoritmy."
 ],
 "Other": [
  null,
  "Iný"
 ],
 "Overview": [
  null,
  "Prehľad"
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit zhavaroval"
 ],
 "Part of": [
  null,
  "Súčasť"
 ],
 "Password": [
  null,
  "Heslo"
 ],
 "Password is not acceptable": [
  null,
  "Heslo nie je prijatelné"
 ],
 "Password is too weak": [
  null,
  "Heslo je príliš slabé"
 ],
 "Password not accepted": [
  null,
  "Heslo nebolo prijaté"
 ],
 "Paste": [
  null,
  "Vložiť"
 ],
 "Paste error": [
  null,
  "Chyba vkladania"
 ],
 "Path": [
  null,
  "Cesta"
 ],
 "Path to file": [
  null,
  "Cesta k súboru"
 ],
 "Paths": [
  null,
  "Cesty"
 ],
 "Pause": [
  null,
  "Pozastaviť"
 ],
 "Performance profile": [
  null,
  "Profil výkonu"
 ],
 "Peripheral chassis": [
  null,
  "Šasi pre periférie"
 ],
 "Pick date": [
  null,
  "Vybrať dátum"
 ],
 "Pin unit": [
  null,
  "Pripnúť jednotku"
 ],
 "Pinned unit": [
  null,
  "Pripnutá jednotka"
 ],
 "Pizza box": [
  null,
  "Veľkosť „krabice od pizzy“"
 ],
 "Portable": [
  null,
  "Prenosný"
 ],
 "Present": [
  null,
  "Prítomné"
 ],
 "Pretty host name": [
  null,
  "Pekný názov stroja"
 ],
 "Previous boot": [
  null,
  "Predchádzajúci štart"
 ],
 "Priority": [
  null,
  "Priorita"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Časový limit výzvy prostredníctvom ssh-add bol prekročený"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Časový limit výzvy prostredníctvom ssh-keygen bol prekročený"
 ],
 "Propagates reload to": [
  null,
  "Propaguje načítať opäť k"
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  "Chráni pred očakávanými útokmi v blízkej budúcnosti za cenu horšej interoperability."
 ],
 "RAID chassis": [
  null,
  "Šasi pre RAID"
 ],
 "Rack mount chassis": [
  null,
  "Šasi pre umiestnenie do racku"
 ],
 "Rank": [
  null,
  "Rank"
 ],
 "Read more...": [
  null,
  "Zistiť viac…"
 ],
 "Read-only": [
  null,
  "Iba na čítanie"
 ],
 "Real host name": [
  null,
  "Skutočný názov stroja"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "Skutočný názov stroja môže obsahovať iba malé písmená, číslice, pomlčky a bodky (pri použití subdomén)"
 ],
 "Real host name must be 64 characters or less": [
  null,
  "Skutočný názov stroja musí byť 64 znakov alebo menej"
 ],
 "Reapply and reboot": [
  null,
  "Znovu použiť a reštartovať"
 ],
 "Reboot": [
  null,
  "Reštartovať"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  "Odporúčané, bezpečné nastavenia pre aktuálne modely hrozieb."
 ],
 "Reload": [
  null,
  "Znova načítať"
 ],
 "Reload propagated from": [
  null,
  "Znovu načítať propagované z"
 ],
 "Reloading": [
  null,
  "Opätovne načítam"
 ],
 "Removals:": [
  null,
  "Odstránenia:"
 ],
 "Remove": [
  null,
  "Odobrať"
 ],
 "Removing $0": [
  null,
  "Odstraňujem $0"
 ],
 "Repeat": [
  null,
  "Opakovať"
 ],
 "Repeat monthly": [
  null,
  "Opakovať každý mesiac"
 ],
 "Repeat weekly": [
  null,
  "Opakovať každý týždeň"
 ],
 "Required by": [
  null,
  "Vyžadované"
 ],
 "Required by ": [
  null,
  "Vyžadované "
 ],
 "Requires": [
  null,
  "Vyžaduje"
 ],
 "Requires administration access to edit": [
  null,
  "Pre úpravu sa vyžadujú administrátorské práva"
 ],
 "Requisite": [
  null,
  "Rekvizita"
 ],
 "Requisite of": [
  null,
  "Závislosť pre"
 ],
 "Reset": [
  null,
  "Reset"
 ],
 "Restart": [
  null,
  "Reštart"
 ],
 "Resume": [
  null,
  "Obnoviť chod"
 ],
 "Review cryptographic policy": [
  null,
  "Skontrolovať politiky pre šifrovanie"
 ],
 "Row expansion": [
  null,
  "Rozšírenie riadka"
 ],
 "Row select": [
  null,
  "Výber riadka"
 ],
 "Run at": [
  null,
  "Spustiť v"
 ],
 "Run on": [
  null,
  "Spustiť na"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Na vzdialenom stroji spustite – cez dôveryhodnú sieť alebo fyzicky priamo na ňom – tento príkaz:"
 ],
 "Running": [
  null,
  "Beží"
 ],
 "Running process prevents directory change": [
  null,
  ""
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "SSH kľúč"
 ],
 "Saturdays": [
  null,
  "Soboty"
 ],
 "Save": [
  null,
  "Uložiť"
 ],
 "Save and reboot": [
  null,
  "Uložiť a reštartovať"
 ],
 "Save changes": [
  null,
  "Uložiť zmeny"
 ],
 "Scheduled poweroff at $0": [
  null,
  "Naplánované vypnutie o $0"
 ],
 "Scheduled reboot at $0": [
  null,
  "Naplánovaný reštart o $0"
 ],
 "Sealed-case PC": [
  null,
  "Počítač so zapäčatenou skriňou"
 ],
 "Search": [
  null,
  "Hľadať"
 ],
 "Second needs to be a number between 0-59": [
  null,
  "Je potrebné, aby sekunda bola číslo medzi 0 a 59"
 ],
 "Seconds": [
  null,
  "Sekundy"
 ],
 "Secure shell keys": [
  null,
  "Kľúče zabezpečeného shellu"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Nastavenie SELinuxu a riešenie problémov"
 ],
 "Server has closed the connection.": [
  null,
  "Server zavrel spojenie."
 ],
 "Server software": [
  null,
  "Serverový softvér"
 ],
 "Service logs": [
  null,
  "Záznamy udalostí služby"
 ],
 "Services": [
  null,
  "Služby"
 ],
 "Set hostname": [
  null,
  "Nastaviť názov stroja"
 ],
 "Set time": [
  null,
  "Nastaviť čas"
 ],
 "Shell script": [
  null,
  "Shellový skript"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show confirmation password": [
  null,
  "Zobraziť potvrdenie hesla"
 ],
 "Show fingerprints": [
  null,
  "Zobraziť odtlačky"
 ],
 "Show messages containing given string.": [
  null,
  "Zobraziť správy obsahujúce zadaný reťazec."
 ],
 "Show messages for the specified systemd unit.": [
  null,
  "Zobraziť správy pre zadanú jednotku systemd."
 ],
 "Show messages from a specific boot.": [
  null,
  "Zobraziť správy z konkrétneho štartu systému."
 ],
 "Show more relationships": [
  null,
  "Zobraziť ďalšie vzťahy"
 ],
 "Show password": [
  null,
  "Zobraziť heslo"
 ],
 "Show relationships": [
  null,
  "Zobraziť vzťahy"
 ],
 "Shut down": [
  null,
  "Vypnúť"
 ],
 "Shutdown": [
  null,
  "Vypnúť"
 ],
 "Since": [
  null,
  "Od"
 ],
 "Single rank": [
  null,
  "Single rank"
 ],
 "Size": [
  null,
  "Veľkosť"
 ],
 "Slot": [
  null,
  "Slot"
 ],
 "Sockets": [
  null,
  "Sokety"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  "Softvérové ošetrenie problémov zabezpečenia procesoru znižujúce riziko ich zneužitia. Majú negatívny vplyv na výkon. Nastavenie meňte na vlastnú zodpovednosť."
 ],
 "Space-saving computer": [
  null,
  "Priestorovo úsporný počítač"
 ],
 "Specific time": [
  null,
  "Konkrétny čas"
 ],
 "Speed": [
  null,
  "Rýchlosť"
 ],
 "Start": [
  null,
  "Spustiť"
 ],
 "Start and enable": [
  null,
  "Spustiť a zapnúť"
 ],
 "Start service": [
  null,
  "Spustiť službu"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  "Začať zobrazovať položky od zadaného dátumu vyššie."
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  "Začať zobrazovať položky od zadaného dátumu ďalej do minulosti."
 ],
 "State": [
  null,
  "Stav"
 ],
 "Static": [
  null,
  "Statická"
 ],
 "Status": [
  null,
  "Stav"
 ],
 "Stick PC": [
  null,
  "Počítač vo forme USB kľúča"
 ],
 "Stop": [
  null,
  "Zastaviť"
 ],
 "Stop and disable": [
  null,
  "Zastaviť a vypnúť"
 ],
 "Storage": [
  null,
  "Úložisko"
 ],
 "Strong password": [
  null,
  "Silné heslo"
 ],
 "Stub": [
  null,
  "Výhonok"
 ],
 "Sub-Chassis": [
  null,
  "Menšie šasi"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  "Prihlásenie k odberu signálov systemd sa nepodarilo: $0"
 ],
 "Successfully copied to clipboard": [
  null,
  "Úspešne skopírované do schránky"
 ],
 "Sundays": [
  null,
  "Nedele"
 ],
 "Synchronized": [
  null,
  "Synchronizované"
 ],
 "Synchronized with $0": [
  null,
  "Synchronizované s $0"
 ],
 "Synchronizing": [
  null,
  "Synchronizujem"
 ],
 "System": [
  null,
  "Systém"
 ],
 "System information": [
  null,
  "Informácie o systéme"
 ],
 "System time": [
  null,
  "Systémový čas"
 ],
 "Systemd units": [
  null,
  "Systemd jednotky"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Targets": [
  null,
  "Ciele"
 ],
 "Terminal": [
  null,
  "Terminál"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "Kľúč SSH $0 používateľa $1 na $2 bude pridaný do súboru $3 používateľa $4 na $5."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH kľúč $0 bude sprístupnený po celú reláciu a bude k dispozícií tiež pre prihlasovanie se k ostatním strojom."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "Kľúč SSH na prihlásenie k $0 je chránený a hostiteľ neumožňuje prihlásenie pomocou hesla. Zadajte, prosím, heslo pre kľúč na $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "Kľúč SSH na prihlásenie k $0 je chránený. Môžete sa pripojiť buď pomocou prihlasovacím heslom alebo zadaním hesla ku kľúču na $1."
 ],
 "The fingerprint should match:": [
  null,
  "Odtlačok by sa mal zhodovať:"
 ],
 "The key password can not be empty": [
  null,
  "Heslo ku kľúču nemôže byť prázdne"
 ],
 "The key passwords do not match": [
  null,
  "Heslá ku kľúču sa líšia"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Prihlásený používateľ nie je oprávnený zobrazovať modifikácie systému"
 ],
 "The password can not be empty": [
  null,
  "Heslo nemôže byť prázdne"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Výsledný odtlačok je možné zdieľať verejnými spôsobmi, vrátane e-mailu."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Výsledný odtlačok je bez problémov možné zdieľať prostredníctvom verejných spôsobov, vrátane e-mailu. Ak niekoho iného žiadate, aby urobil overovanie za vás, môže poslať výsledky ľubovoľnou cestou."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Server odmietol overovanie pri všetkých podporovaných metódach."
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  "Používateľ $0 nie je oprávnený meniť zmierňovanie dopadu chýb zabezpečenia procesora"
 ],
 "The user $0 is not permitted to change cryptographic policies": [
  null,
  "Používateľ $0 nemá oprávnenia meniť politiky pre šifrovanie"
 ],
 "This field cannot be empty": [
  null,
  "Meno používateľa nesmie byť prázdne"
 ],
 "This may take a while": [
  null,
  "Toto môže chvíľu trvať"
 ],
 "This system is using a custom profile": [
  null,
  "Tento systém používa používateľom definovaný profil"
 ],
 "This system is using the recommended profile": [
  null,
  "Tento systém používa odporúčaný profil"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Tento nástroj nastavuje politiky pre SELinux a môže pomôcť s porozumením a riešením porušenia pravidiel."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Tento nástroj vytvára archív nastavení a diagnostických informácií z bežiaceho systému. Archív je možné uložiť lokálne alebo centrálne pre účely sledovania či záznamu alebo je možné ho poslať zástupcom technickej podpory, vývojárom alebo správcom systému, aby tak mohli pomôcť s nájdením technického nedostatku alebo ladením chyby."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Tento nástroj spravuje miestne úložisko, ako sú napríklad systémy súborov, LVM2 skupiny zväzkov a NFS pripojenia."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Tento nástroj spravuje sieťovanie ako napríklad sieťové spojenia (bond), teaming, mosty (bridge), VLAN siete a brány firewall pomocou nástroja NetworkManager a FIrewalld. NetworkManager nie je kompatibilný s Ubuntu v predvolenom stave pri používaní systemd-networkd a skriptami ifupdown v distribúcii Debian."
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  "Táto jednotka je navrhnutá na to, aby bola výslovne zapnutá."
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  "Toto pridá zhodu pre „_BOOT_ID=“. Ak nie je určené, zobrazia sa záznamy udalostí pre súčasný štart systému. Ak identifikátor štartu vynecháte, kladný posun prehľadá štarty od začiatku žurnálu a posun rovný alebo menší ak nula prehľadá štarty od jeho konca. Preto 1 znamená v chronologickom poradí prvý štart nájdený v žurnáli, 2 druhý atď. Odbodne -0 znamená posledný štart, -1 predposledný štart atď."
 ],
 "Thursdays": [
  null,
  "štvrtky"
 ],
 "Time": [
  null,
  "Čas"
 ],
 "Time zone": [
  null,
  "Časová zóna"
 ],
 "Timer creation failed": [
  null,
  "Vytvorenie časovača zlyhalo"
 ],
 "Timer deletion failed": [
  null,
  "Odstránenie časovača zlyhalo"
 ],
 "Timers": [
  null,
  "Časovače"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Aby ste zaistili, že do vášho pripojenia nie je zasahované záškodníckou treťou stranou, overte odtlačok kľúča hostiteľa:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Ak chcete odtlačok overiť, spustite nasledujúce príkazy na $0 počas fyzickej prítomnosti pri stroji alebo prostredníctvom dôveryhodnej siete:"
 ],
 "Toggle date picker": [
  null,
  "Prepnúť vyberač dátumov"
 ],
 "Toggle filters": [
  null,
  "Prepnúť filtre"
 ],
 "Too much data": [
  null,
  "Príliš veľa dát"
 ],
 "Total size: $0": [
  null,
  "Celková veľkosť: $0"
 ],
 "Tower": [
  null,
  "Veža"
 ],
 "Transient": [
  null,
  "Prechodné"
 ],
 "Trigger": [
  null,
  "Spúšťač"
 ],
 "Triggered by": [
  null,
  "Spustené na základe"
 ],
 "Triggers": [
  null,
  "Spúšťače"
 ],
 "Trust and add host": [
  null,
  "Dôverovať a pridať hostiteľa"
 ],
 "Trying to synchronize with $0": [
  null,
  "Pokus o synchronizáciu s $0"
 ],
 "Tuesdays": [
  null,
  "utorky"
 ],
 "Tuned has failed to start": [
  null,
  "Spustenie procesu služby tuned skončilo neúspechom"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned je služba, ktorá sleduje váš systém a optimalizuje jeho výkon pod určitými typmi záťaží. Jadrom Tuned sú profily, ktoré ladia váš systém pre rôzne prípady použitia."
 ],
 "Tuned is not available": [
  null,
  "Tuned nie je k dispozícii"
 ],
 "Tuned is not running": [
  null,
  "Tuned nie je spustené"
 ],
 "Tuned is off": [
  null,
  "Tuned je vypnuté"
 ],
 "Type": [
  null,
  "Typ"
 ],
 "Type to filter": [
  null,
  "Filtrujte písaním"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Nedarí sa prihlásiť k $0. Hostiteľ neprijíma prihlasovanie heslom ani žiaden z vašich SSH kľúčov."
 ],
 "Unit": [
  null,
  "Jednotka"
 ],
 "Unknown": [
  null,
  "Neznáme"
 ],
 "Unpin unit": [
  null,
  "Zrušiť pripnutie jednotky"
 ],
 "Until": [
  null,
  "Až do"
 ],
 "Untrusted host": [
  null,
  "Nedôveryhodnotný stroj"
 ],
 "Up since": [
  null,
  "Beží od"
 ],
 "Updating status...": [
  null,
  "Aktualizujem stav..."
 ],
 "Usage": [
  null,
  "Využitie"
 ],
 "User": [
  null,
  "Používateľ"
 ],
 "Validating address": [
  null,
  "Overujem adresu"
 ],
 "Vendor": [
  null,
  "Výrobca"
 ],
 "Verify fingerprint": [
  null,
  "Overiť odtlačok"
 ],
 "Version": [
  null,
  "Verzia"
 ],
 "View Podman container": [
  null,
  ""
 ],
 "View all logs": [
  null,
  "Zobraziť všetky záznamy udalostí"
 ],
 "View all services": [
  null,
  "Zobraziť všetky služby"
 ],
 "View automation script": [
  null,
  "Zobraziť automatizačný skript"
 ],
 "View hardware details": [
  null,
  "Zobraziť podrobnosti o hardvéri"
 ],
 "View login history": [
  null,
  "Zobraziť históriu prihlásení"
 ],
 "View metrics and history": [
  null,
  "Zobraziť metriky a históriu"
 ],
 "Viewing memory information requires administrative access.": [
  null,
  "Zobrazovanie informácií o pamäti vyžaduje oprávnenie na úrovni správcu systému."
 ],
 "Visit firewall": [
  null,
  "Prejsť na bránu firewall"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Čakám na dokončenie ostatných operácií správy balíčkov"
 ],
 "Wanted by": [
  null,
  "Vyžadované"
 ],
 "Wants": [
  null,
  "Vyžaduje"
 ],
 "Warning and above": [
  null,
  "Varovanie a závažnejšie"
 ],
 "Weak password": [
  null,
  "Ľahko prelomiteľné heslo"
 ],
 "Web Console for Linux servers": [
  null,
  "Webová konzola pre linuxové servery"
 ],
 "Web console is running in limited access mode.": [
  null,
  "Webová konzola beží v režime obmedzeného prístupu."
 ],
 "Wednesdays": [
  null,
  "Stredy"
 ],
 "Weekly": [
  null,
  "Každý týždeň"
 ],
 "Weeks": [
  null,
  "Týždne"
 ],
 "White": [
  null,
  "Biely"
 ],
 "Yearly": [
  null,
  "Každý rok"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "K $0 sa pripájate prvýkrát."
 ],
 "You may try to load older entries.": [
  null,
  "Môžte skúsiť načítať skoršie záznamy."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Vami používaný prehliadač neumožňuje vkladanie z kontextovej ponuky. Ako náhradu môžete použiť Shift+Insert."
 ],
 "Your session has been terminated.": [
  null,
  "Vaša relácia bola ukončená."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Platnosť vašej relácie skončila. Prihláste sa, prosím, znovu."
 ],
 "Zone": [
  null,
  "Zóna"
 ],
 "[binary data]": [
  null,
  "[binárne dáta]"
 ],
 "[no data]": [
  null,
  "[žiadne dáta]"
 ],
 "active": [
  null,
  "Aktívna"
 ],
 "edit": [
  null,
  "upraviť"
 ],
 "failed to list ssh host keys: $0": [
  null,
  "nepodarilo sa vypísať SSH kľúče stroja: $0"
 ],
 "in less than a minute": [
  null,
  "o menej ako minútu"
 ],
 "inconsistent": [
  null,
  "nekonzistentný"
 ],
 "journalctl manpage": [
  null,
  "manuálové stránky k journalctl"
 ],
 "less than a minute ago": [
  null,
  "pred menej ako minútou"
 ],
 "none": [
  null,
  "žiaden"
 ],
 "of $0 CPU": [
  null,
  "z $0 procesoru",
  "z $0 procesorov",
  "z $0 procesorov"
 ],
 "password quality": [
  null,
  "kvalita hesla"
 ],
 "recommended": [
  null,
  "odporúčaný"
 ],
 "running $0": [
  null,
  "beží na $0"
 ],
 "show less": [
  null,
  "zobraziť menej"
 ],
 "show more": [
  null,
  "zobraziť viac"
 ],
 "unknown": [
  null,
  "neznáme"
 ],
 "dialog-title\u0004Domain": [
  null,
  "Doména"
 ],
 "dialog-title\u0004Join a domain": [
  null,
  "Pridať do domény"
 ],
 "from <host>\u0004from $0": [
  null,
  "z $0"
 ],
 "from <host> on <terminal>\u0004from $0 on $1": [
  null,
  "z $0 na $1"
 ],
 "on <terminal>\u0004on $0": [
  null,
  "na $0"
 ]
});
