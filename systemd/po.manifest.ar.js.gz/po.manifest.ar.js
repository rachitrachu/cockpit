cockpit.locale({
 "": {
  "plural-forms": (n) => n==0 ? 0 : n==1 ? 1 : n==2 ? 2 : n%100>=3 && n%100<=10 ? 3 : n%100>=11 ? 4 : 5,
  "language": "ar",
  "language-direction": "rtl"
 },
 "Configuring system settings": [
  null,
  "تكوين إعدادات النظام"
 ],
 "Diagnostic reports": [
  null,
  "تقارير التشخيص"
 ],
 "Kernel dump": [
  null,
  "عطب نواة النظام"
 ],
 "Logs": [
  null,
  "السجلات"
 ],
 "Managing services": [
  null,
  "إدارة الخدمات"
 ],
 "Networking": [
  null,
  "التشبيك"
 ],
 "Overview": [
  null,
  "نظرة عامة"
 ],
 "Reviewing logs": [
  null,
  "مراجعة السجلات"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Services": [
  null,
  "الخدمات"
 ],
 "Storage": [
  null,
  "التخزين"
 ],
 "Terminal": [
  null,
  "الطرفية"
 ],
 "abrt": [
  null,
  "abrt"
 ],
 "asset tag": [
  null,
  "معرّف الأصل"
 ],
 "bash": [
  null,
  "bash"
 ],
 "bios": [
  null,
  "bios"
 ],
 "boot": [
  null,
  "إقلاع"
 ],
 "cgroups": [
  null,
  "مجموعات التحكم"
 ],
 "command": [
  null,
  "أَمر"
 ],
 "console": [
  null,
  "وحدة تحكم"
 ],
 "coredump": [
  null,
  "تفريغ الذاكرة الأساسية"
 ],
 "cpu": [
  null,
  "وحدة معالجة مركزية"
 ],
 "crash": [
  null,
  "تعطل"
 ],
 "date": [
  null,
  "التاريخ"
 ],
 "debug": [
  null,
  "التنقيح"
 ],
 "dimm": [
  null,
  "خافت"
 ],
 "disable": [
  null,
  "عطل"
 ],
 "disks": [
  null,
  "الأَقراص"
 ],
 "domain": [
  null,
  "نِطاق"
 ],
 "enable": [
  null,
  "ممكن"
 ],
 "error": [
  null,
  "خَطأ"
 ],
 "graphs": [
  null,
  "الرسوم البيانية"
 ],
 "hardware": [
  null,
  "العتاد المادي"
 ],
 "history": [
  null,
  "تاريخ"
 ],
 "host": [
  null,
  "مضيف"
 ],
 "journal": [
  null,
  "سجل اليوميات"
 ],
 "machine": [
  null,
  "آلة"
 ],
 "mask": [
  null,
  "قناع"
 ],
 "memory": [
  null,
  "ذاكرة"
 ],
 "metrics": [
  null,
  "المقاييس"
 ],
 "mitigation": [
  null,
  "التخفيف"
 ],
 "network": [
  null,
  "الشَبكة"
 ],
 "operating system": [
  null,
  "نظام تشغيل"
 ],
 "os": [
  null,
  "os"
 ],
 "path": [
  null,
  "<path>"
 ],
 "pci": [
  null,
  "pci"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "performance": [
  null,
  "الأداء"
 ],
 "power": [
  null,
  "طاقة"
 ],
 "ram": [
  null,
  "ram"
 ],
 "restart": [
  null,
  "أَعد التشغيل"
 ],
 "serial": [
  null,
  "تسلسلي"
 ],
 "service": [
  null,
  "الخدمة"
 ],
 "shell": [
  null,
  "واجهة سطر أوامر النظام"
 ],
 "shut": [
  null,
  "أوقف"
 ],
 "socket": [
  null,
  "مقبس الشبكة"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "هدف"
 ],
 "time": [
  null,
  "وقت"
 ],
 "timer": [
  null,
  "مؤقِّت"
 ],
 "unit": [
  null,
  "وحدة"
 ],
 "unmask": [
  null,
  "إزالة الإخفاء"
 ],
 "version": [
  null,
  "الإِصدار"
 ],
 "warning": [
  null,
  "تحذير"
 ]
});
