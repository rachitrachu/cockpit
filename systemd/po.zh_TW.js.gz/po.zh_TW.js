cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "zh_TW",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 critical hit": [
  null,
  "$0 筆，包含嚴重影響"
 ],
 "$0 day": [
  null,
  "$0 天"
 ],
 "$0 disk is failing": [
  null,
  "$0 個磁碟即將故障"
 ],
 "$0 does not exist": [
  null,
  "$0 不存在"
 ],
 "$0 exited with code $1": [
  null,
  "$0 結束執行並回傳 $1"
 ],
 "$0 failed": [
  null,
  "$0 失敗"
 ],
 "$0 failed login attempt": [
  null,
  "$0 次嘗試登入失敗"
 ],
 "$0 filters applied": [
  null,
  "$0 個篩選器己經應用"
 ],
 "$0 hour": [
  null,
  "$0 小時"
 ],
 "$0 important hit": [
  null,
  "$0 筆，包含重要影響"
 ],
 "$0 is not a directory": [
  null,
  "$0 不是目錄"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 在任何軟體庫中都未提供。"
 ],
 "$0 key changed": [
  null,
  "金鑰 $0 已被更改"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 被 $1 訊號終止執行"
 ],
 "$0 low severity hit": [
  null,
  "$0 筆低重要性影響"
 ],
 "$0 minute": [
  null,
  "$0 分鐘"
 ],
 "$0 moderate hit": [
  null,
  "$0 筆，包含中度影響"
 ],
 "$0 month": [
  null,
  "$0 月"
 ],
 "$0 service has failed": [
  null,
  "$0 服務發生錯誤"
 ],
 "$0 week": [
  null,
  "$0 週"
 ],
 "$0 will be installed.": [
  null,
  "$0 將會被安裝。"
 ],
 "$0 year": [
  null,
  "$0 年"
 ],
 "1 day": [
  null,
  "1 天"
 ],
 "1 hour": [
  null,
  "1 小時"
 ],
 "1 minute": [
  null,
  "1 分鐘"
 ],
 "1 week": [
  null,
  "1週"
 ],
 "10th": [
  null,
  "第 10 天"
 ],
 "11th": [
  null,
  "第 11 天"
 ],
 "12th": [
  null,
  "第 12 天"
 ],
 "13th": [
  null,
  "第13"
 ],
 "14th": [
  null,
  "第 14 天"
 ],
 "15th": [
  null,
  "第 15 天"
 ],
 "16th": [
  null,
  "第 16 天"
 ],
 "17th": [
  null,
  "第 17 天"
 ],
 "18th": [
  null,
  "第 18 天"
 ],
 "19th": [
  null,
  "第 19 天"
 ],
 "1st": [
  null,
  "第 1 天"
 ],
 "20 minutes": [
  null,
  "20 分鐘"
 ],
 "20th": [
  null,
  "第 20 天"
 ],
 "21th": [
  null,
  "第 21 日"
 ],
 "22th": [
  null,
  "第 22 天"
 ],
 "23th": [
  null,
  "23 日"
 ],
 "24th": [
  null,
  "第 24 天"
 ],
 "25th": [
  null,
  "第 25 天"
 ],
 "26th": [
  null,
  "第 26 天"
 ],
 "27th": [
  null,
  "第 27 天"
 ],
 "28th": [
  null,
  "第 28 天"
 ],
 "29th": [
  null,
  "第 29 天"
 ],
 "2nd": [
  null,
  "第 2 天"
 ],
 "30th": [
  null,
  "第 30 天"
 ],
 "31st": [
  null,
  "第 31 天"
 ],
 "3rd": [
  null,
  "第 3 天"
 ],
 "40 minutes": [
  null,
  "40 分鐘"
 ],
 "4th": [
  null,
  "第 4 天"
 ],
 "5 minutes": [
  null,
  "5 分鐘"
 ],
 "5th": [
  null,
  "第 5 天"
 ],
 "6 hours": [
  null,
  "6 小時"
 ],
 "60 minutes": [
  null,
  "60 分鐘"
 ],
 "6th": [
  null,
  "第 6 天"
 ],
 "7th": [
  null,
  "第 7 天"
 ],
 "8th": [
  null,
  "第 8 天"
 ],
 "9th": [
  null,
  "第 9 天"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "未在 $0 上安裝相容的 Cockpit 版本。"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "將為了在 $2 上的 $1 建立一個於 $0 的新 SSH 金鑰，且其將會被加到 $5 上 $4 的 $3 檔案中。"
 ],
 "Absent": [
  null,
  "不存在"
 ],
 "Acceptable password": [
  null,
  "可接受的密碼強度"
 ],
 "Active since ": [
  null,
  "已啟動自從 "
 ],
 "Active state": [
  null,
  "啟用狀態"
 ],
 "Add": [
  null,
  "加入"
 ],
 "Add $0": [
  null,
  "新增 $0"
 ],
 "Additional actions": [
  null,
  "其他動作"
 ],
 "Additional packages:": [
  null,
  "額外軟體包："
 ],
 "Administration with Cockpit Web Console": [
  null,
  "使用 Cockpit 網頁控制台進行管理"
 ],
 "Advanced TCA": [
  null,
  "進階 TCA"
 ],
 "After": [
  null,
  "在...之後"
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "在離開網域後，將只有具備本機身份憑證的使用者能夠登入此主機。由於 DNS 解析設定與 CA 信任清單可能會改變，也可能影響其他的服務。"
 ],
 "After system boot": [
  null,
  "系統啟動後"
 ],
 "Alert and above": [
  null,
  "警示與更高等級"
 ],
 "Alias": [
  null,
  "別名"
 ],
 "All": [
  null,
  "全部"
 ],
 "All-in-one": [
  null,
  "一體成型電腦"
 ],
 "Allow running (unmask)": [
  null,
  "允許執行 (解除遮罩)"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Ansible 角色文件"
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  "任何在紀錄訊息之中的字串皆可被篩選。字串也可以用正規表達式表示。同時支援用紀錄訊息的欄位作為條件篩選。條件使用「欄位=數值」的形式、其數值可以是由逗號分隔的多個可能數值；以空格分隔多個篩選條件。"
 ],
 "Appearance": [
  null,
  "外觀"
 ],
 "Apply and reboot": [
  null,
  "套用並重新開機"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  "正在套用新的政策… 可能會花上幾分鐘的時間。"
 ],
 "Asset tag": [
  null,
  "標籤"
 ],
 "At minute": [
  null,
  "於分鐘"
 ],
 "At second": [
  null,
  "於秒"
 ],
 "At specific time": [
  null,
  "在特定時間"
 ],
 "Authentication": [
  null,
  "核對"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "需要驗證才可以透過 Cockpit 網頁控制台執行高權限的工作"
 ],
 "Authorize SSH key": [
  null,
  "授權 SSH 金鑰"
 ],
 "Automatically starts": [
  null,
  "自動啟動"
 ],
 "Automatically using NTP": [
  null,
  "自動使用 NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "自動使用額外的 NTP 伺服器"
 ],
 "Automatically using specific NTP servers": [
  null,
  "自動使用指定的 NTP 伺服器"
 ],
 "Automation script": [
  null,
  "自動化腳本"
 ],
 "BIOS": [
  null,
  "BIOS 廠牌"
 ],
 "BIOS date": [
  null,
  "BIOS 日期"
 ],
 "BIOS version": [
  null,
  "BIOS 版本"
 ],
 "Bad": [
  null,
  "錯誤"
 ],
 "Bad setting": [
  null,
  "錯誤的設定"
 ],
 "Before": [
  null,
  "在...之前"
 ],
 "Binds to": [
  null,
  "綁定到"
 ],
 "Black": [
  null,
  "黑色"
 ],
 "Blade": [
  null,
  "刀鋒"
 ],
 "Blade enclosure": [
  null,
  "刀鋒外殼"
 ],
 "Boot": [
  null,
  "開機"
 ],
 "Bound by": [
  null,
  "以......為界"
 ],
 "Bus expansion chassis": [
  null,
  "匯流排擴充機殼"
 ],
 "CPU": [
  null,
  "處理器"
 ],
 "CPU security": [
  null,
  "處理器安全"
 ],
 "CPU security toggles": [
  null,
  "處理器安全開關"
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "使用目前的篩選器組合無法找到任何紀錄檔。"
 ],
 "Cancel": [
  null,
  "取消"
 ],
 "Cancel poweroff": [
  null,
  "取消關機"
 ],
 "Cancel reboot": [
  null,
  "取消重新開機"
 ],
 "Cannot be enabled": [
  null,
  "無法被啟用"
 ],
 "Cannot forward login credentials": [
  null,
  "無法轉發登入憑證"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  "因無法在此系統找到 realmd 而無法加入網域"
 ],
 "Cannot schedule event in the past": [
  null,
  "無法安排過去的活動"
 ],
 "Change": [
  null,
  "變更"
 ],
 "Change cryptographic policy": [
  null,
  "變更加密政策"
 ],
 "Change directory": [
  null,
  "變更目錄"
 ],
 "Change host name": [
  null,
  "變更主機名稱"
 ],
 "Change performance profile": [
  null,
  "變更效能設定檔"
 ],
 "Change profile": [
  null,
  "變更設定檔"
 ],
 "Change system time": [
  null,
  "變更系統時間"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "重新安裝作業系統通常會導致金鑰變更。然而，未預期的變更可能是第三方嘗試竊聽連線的跡象。"
 ],
 "Changing the directory will forcefully stop the currently running process. The process can also be stopped manually in the terminal before continuing.": [
  null,
  "變更目錄將會強制中止目前執行中的處理程序。也可以在終端機中手動停止該處理程序後，再繼續變更。"
 ],
 "Checking installed software": [
  null,
  "正在檢查已安裝的軟體"
 ],
 "Class": [
  null,
  "類別"
 ],
 "Clear 'Failed to start'": [
  null,
  "清除「啟動失敗」"
 ],
 "Clear all filters": [
  null,
  "清除所有篩選器"
 ],
 "Clear input value": [
  null,
  "清除輸入的值"
 ],
 "Client software": [
  null,
  "客戶端軟體"
 ],
 "Close": [
  null,
  "關閉"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Cockpit 的 NetworkManager 與 Firewalld 設定"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit 無法聯絡指定的主機。"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit 是一個伺服器管理器，它可以讓您透過網頁瀏覽器輕鬆管理 Linux 伺服器。同時運用終端機與網頁工具是沒有問題的。由 Cockpit 啟動的服務可在終端機中被停止。同樣地，若終端機中發生錯誤時，也可以在 Cockpit 的紀錄檔日誌介面中看到。"
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit 與該系統上的軟體不相容。"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit 未安裝"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit 未安裝在系統上。"
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit 非常適合新的系統管理員，使他們能夠輕鬆執行簡單的任務，如：儲存空間管理、檢查日誌紀錄及啟動與停止服務。您可以同時監控和管理多個伺服器。只需輕鬆的新增它們，您的機器們將會關心彼此的狀況。"
 ],
 "Collect and package diagnostic and support data": [
  null,
  "收集並封裝診斷與支援資料"
 ],
 "Collect kernel crash dumps": [
  null,
  "蒐集核心當機傾印"
 ],
 "Command": [
  null,
  "指令"
 ],
 "Command not found": [
  null,
  "找不到指令"
 ],
 "Communication with tuned has failed": [
  null,
  "與 tuned 通訊失敗"
 ],
 "Compact PCI": [
  null,
  "緊密型 PCI"
 ],
 "Condition $0=$1 was not met": [
  null,
  "條件 $0=$1 未滿足"
 ],
 "Condition failed": [
  null,
  "條件失敗"
 ],
 "Configuration": [
  null,
  "組態"
 ],
 "Confirm deletion of $0": [
  null,
  "確認刪除 $0"
 ],
 "Confirm key password": [
  null,
  "確認金鑰密碼"
 ],
 "Conflicted by": [
  null,
  "衝突的"
 ],
 "Conflicts": [
  null,
  "衝突"
 ],
 "Connecting to dbus failed: $0": [
  null,
  "與 dbus 連線失敗： $0"
 ],
 "Connection has timed out.": [
  null,
  "連線已逾時。"
 ],
 "Consists of": [
  null,
  "由組成"
 ],
 "Contacted domain": [
  null,
  "已聯絡的網域"
 ],
 "Container": [
  null,
  "容器"
 ],
 "Convertible": [
  null,
  "二合一電腦"
 ],
 "Copied": [
  null,
  "已複製"
 ],
 "Copy": [
  null,
  "複製"
 ],
 "Copy to clipboard": [
  null,
  "複製到剪貼簿"
 ],
 "Create $0": [
  null,
  "建立 $0"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "建立新的 SSH 金鑰並對其授權"
 ],
 "Create new task file with this content.": [
  null,
  "以此內容建立新的工作檔案。"
 ],
 "Create timer": [
  null,
  "建立計時器"
 ],
 "Critical and above": [
  null,
  "嚴重與更高等級"
 ],
 "Cryptographic Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  "加密政策是一個設定核心加密子系統的系統元件，其負責 TLS、IPSec、SSH、DNSSec 與 Kerberos 協定。"
 ],
 "Cryptographic policy": [
  null,
  "加密政策"
 ],
 "Cryptographic policy is inconsistent": [
  null,
  "加密政策不一致"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Current boot": [
  null,
  "目前這次開機"
 ],
 "Custom cryptographic policy": [
  null,
  "自訂加密政策"
 ],
 "DEFAULT with SHA-1 signature verification allowed.": [
  null,
  "已允許具 SHA-1 簽章驗證的 DEFAULT 。"
 ],
 "Daily": [
  null,
  "每日"
 ],
 "Dark": [
  null,
  "深色"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  "日期規格應為 YYYY-MM-DD hh:mm:ss 格式。也可以使用如 'yesterday', 'today', 'tomorrow' 的字串。'now' 代表目前的時間。此外，可以透過 '-' 或 '+' 前置字元指定相對時間"
 ],
 "Debug and above": [
  null,
  "除錯與更高等級"
 ],
 "Decrease by one": [
  null,
  "減少 1"
 ],
 "Default": [
  null,
  "預設值"
 ],
 "Delay": [
  null,
  "延遲"
 ],
 "Delay must be a number": [
  null,
  "延遲必須為數字"
 ],
 "Delete": [
  null,
  "刪除"
 ],
 "Deletion will remove the following files:": [
  null,
  "刪除時將會移除下列檔案："
 ],
 "Description": [
  null,
  "說明"
 ],
 "Desktop": [
  null,
  "桌機"
 ],
 "Detachable": [
  null,
  "可拆開"
 ],
 "Details": [
  null,
  "詳細資訊"
 ],
 "Diagnostic reports": [
  null,
  "診斷報告"
 ],
 "Disable simultaneous multithreading": [
  null,
  "停用同步多執行緒"
 ],
 "Disable tuned": [
  null,
  "停用 tuned"
 ],
 "Disabled": [
  null,
  "已停用"
 ],
 "Disallow running (mask)": [
  null,
  "禁止執行 (遮罩)"
 ],
 "Docking station": [
  null,
  "擴充基座"
 ],
 "Does not automatically start": [
  null,
  "不要自動啟動"
 ],
 "Domain": [
  null,
  "網域"
 ],
 "Domain address": [
  null,
  "網域位址"
 ],
 "Domain administrator name": [
  null,
  "域管理員名稱"
 ],
 "Domain administrator password": [
  null,
  "域管理員密碼"
 ],
 "Domain could not be contacted": [
  null,
  "無法聯絡網域"
 ],
 "Domain is not supported": [
  null,
  "網域不被支援"
 ],
 "Don't repeat": [
  null,
  "不要重複"
 ],
 "Downloading $0": [
  null,
  "下載 $0"
 ],
 "Dual rank": [
  null,
  "雙 Rank"
 ],
 "Edit /etc/motd": [
  null,
  "編輯 /etc/motd"
 ],
 "Edit motd": [
  null,
  "編輯 motd"
 ],
 "Embedded PC": [
  null,
  "嵌入式PC"
 ],
 "Enabled": [
  null,
  "已啟用"
 ],
 "Entry at $0": [
  null,
  "於 $0 的項目"
 ],
 "Error": [
  null,
  "錯誤"
 ],
 "Error and above": [
  null,
  "錯誤與更高等級"
 ],
 "Error message": [
  null,
  "錯誤訊息"
 ],
 "Excellent password": [
  null,
  "優秀的密碼"
 ],
 "Expansion chassis": [
  null,
  "擴充機殼"
 ],
 "FIPS is not properly enabled": [
  null,
  "FIPS 沒有被正確啟用"
 ],
 "FIPS with further Common Criteria restrictions.": [
  null,
  "具進一步通用準則限制的 FIPS。"
 ],
 "Failed to change password": [
  null,
  "無法更改密碼"
 ],
 "Failed to disable tuned": [
  null,
  "停用 tuned 失敗"
 ],
 "Failed to disable tuned profile": [
  null,
  "停用 tuned 設定檔失敗"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "啟用 firewalld 中的 $0 失敗"
 ],
 "Failed to enable tuned": [
  null,
  "無法啟用 tuned"
 ],
 "Failed to fetch logs": [
  null,
  "取得紀錄檔失敗"
 ],
 "Failed to load unit": [
  null,
  "讀取單元失敗"
 ],
 "Failed to save changes in /etc/motd": [
  null,
  "儲存 /etc/motd 變更失敗"
 ],
 "Failed to start": [
  null,
  "啟動失敗"
 ],
 "Failed to switch profile": [
  null,
  "切換設定檔失敗"
 ],
 "File state": [
  null,
  "檔案狀態"
 ],
 "Filter by name or description": [
  null,
  "以名稱或說明篩選"
 ],
 "Filters": [
  null,
  "篩選器"
 ],
 "Font size": [
  null,
  "字體大小"
 ],
 "Forbidden from running": [
  null,
  "已被禁止執行"
 ],
 "Free-form search": [
  null,
  "自由形式搜尋"
 ],
 "Fridays": [
  null,
  "每週五"
 ],
 "Generated": [
  null,
  "產生的"
 ],
 "Go to $0": [
  null,
  "前往 $0"
 ],
 "Go to now": [
  null,
  "移至現在"
 ],
 "Handheld": [
  null,
  "手持裝置"
 ],
 "Hardware information": [
  null,
  "硬體資訊"
 ],
 "Health": [
  null,
  "系統摘要"
 ],
 "Help": [
  null,
  "說明"
 ],
 "Hide confirmation password": [
  null,
  "隱藏確認密碼"
 ],
 "Hide password": [
  null,
  "隱藏密碼"
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  "更高的可交互運作性會造成攻擊面增加的代價。"
 ],
 "Host key is incorrect": [
  null,
  "主機金鑰不正確"
 ],
 "Hostname": [
  null,
  "主機名稱"
 ],
 "Hourly": [
  null,
  "每小時"
 ],
 "Hours": [
  null,
  "時"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Identifier": [
  null,
  "辨識碼"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "如果指紋相符，點選「信任並新增主機」。否則，不要連線並聯絡您的管理人員。"
 ],
 "Increase by one": [
  null,
  "增加 1"
 ],
 "Indirect": [
  null,
  "間接"
 ],
 "Info and above": [
  null,
  "資訊與更高等級"
 ],
 "Insights: ": [
  null,
  "洞察： "
 ],
 "Install": [
  null,
  "安裝"
 ],
 "Install realmd support": [
  null,
  "安裝 realmd 支援"
 ],
 "Install software": [
  null,
  "安裝軟體"
 ],
 "Installing $0": [
  null,
  "正在安裝 $0"
 ],
 "Internal error": [
  null,
  "內部錯誤"
 ],
 "Invalid": [
  null,
  "無效"
 ],
 "Invalid date format": [
  null,
  "日期格式無效"
 ],
 "Invalid date format and invalid time format": [
  null,
  "無效的日期與時間格式"
 ],
 "Invalid file permissions": [
  null,
  "檔案權限無效"
 ],
 "Invalid time format": [
  null,
  "時間格式無效"
 ],
 "Invalid timezone": [
  null,
  "無效的時區"
 ],
 "IoT gateway": [
  null,
  "物聯網閘道"
 ],
 "Join": [
  null,
  "加入"
 ],
 "Join domain": [
  null,
  "網域設定"
 ],
 "Joining": [
  null,
  "正在加入"
 ],
 "Joining a domain requires installation of realmd": [
  null,
  "需要安裝 realmd 才能加入網域"
 ],
 "Joining this domain is not supported": [
  null,
  "不支援加入此網域"
 ],
 "Joins namespace of": [
  null,
  "加入命名空間"
 ],
 "Journal": [
  null,
  "日誌"
 ],
 "Journal entry": [
  null,
  "期刊錄入"
 ],
 "Journal entry not found": [
  null,
  "日誌紀錄項目未找到"
 ],
 "Kernel dump": [
  null,
  "核心傾印"
 ],
 "Key password": [
  null,
  "金鑰密碼"
 ],
 "LEGACY with Active Directory interoperability.": [
  null,
  "具 Active Directory 互通性的 LEGACY。"
 ],
 "Laptop": [
  null,
  "筆記型電腦"
 ],
 "Last 24 hours": [
  null,
  "過去 24 小時"
 ],
 "Last 7 days": [
  null,
  "過去 7 天"
 ],
 "Last successful login:": [
  null,
  "最近一次成功登入："
 ],
 "Learn more": [
  null,
  "了解更多"
 ],
 "Leave $0": [
  null,
  "離開 $0"
 ],
 "Leave domain": [
  null,
  "離開網域"
 ],
 "Light": [
  null,
  "淺色"
 ],
 "Linked": [
  null,
  "已連結"
 ],
 "Listen": [
  null,
  "接聽"
 ],
 "Listing units": [
  null,
  "正在列出單元"
 ],
 "Listing units failed: $0": [
  null,
  "列出單元失敗： $0"
 ],
 "Load earlier entries": [
  null,
  "讀取這之前的項目"
 ],
 "Loading keys...": [
  null,
  "正在讀取金鑰…"
 ],
 "Loading of SSH keys failed": [
  null,
  "讀取 SSH 金鑰失敗"
 ],
 "Loading of units failed": [
  null,
  "讀取單元失敗"
 ],
 "Loading system modifications...": [
  null,
  "讀取系統變更中…"
 ],
 "Loading unit failed": [
  null,
  "讀取單元失敗"
 ],
 "Loading...": [
  null,
  "正在載入..."
 ],
 "Log in": [
  null,
  "登入"
 ],
 "Log in to $0": [
  null,
  "登入至 $0"
 ],
 "Log messages": [
  null,
  "記錄訊息"
 ],
 "Login failed": [
  null,
  "登入失敗"
 ],
 "Login format": [
  null,
  "登入格式"
 ],
 "Logs": [
  null,
  "系統日誌"
 ],
 "Low profile desktop": [
  null,
  "尺寸較小的桌上型電腦"
 ],
 "Lunch box": [
  null,
  "午餐盒"
 ],
 "Machine ID": [
  null,
  "機器 ID"
 ],
 "Machine SSH key fingerprints": [
  null,
  "機器 SSH 金鑰指紋"
 ],
 "Main server chassis": [
  null,
  "主伺服器機殼"
 ],
 "Maintenance": [
  null,
  "維護中"
 ],
 "Manage storage": [
  null,
  "管理儲存空間"
 ],
 "Manually": [
  null,
  "手動"
 ],
 "Mask service": [
  null,
  "遮罩服務"
 ],
 "Masked": [
  null,
  "已遮罩"
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  "遮罩服務會阻止所有相依的單元執行。這可能會造成比預期更大的影響。請確認你想遮罩這個單元。"
 ],
 "Memory": [
  null,
  "記憶體"
 ],
 "Memory technology": [
  null,
  "記憶體技術"
 ],
 "Merged": [
  null,
  "已合併"
 ],
 "Message to logged in users": [
  null,
  "給已登入使用者的訊息"
 ],
 "Mini PC": [
  null,
  "迷你電腦"
 ],
 "Mini tower": [
  null,
  "迷你塔"
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "分鐘需要是 0-59 之間的數字"
 ],
 "Minutely": [
  null,
  "每分鐘"
 ],
 "Minutes": [
  null,
  "分"
 ],
 "Mitigations": [
  null,
  "緩解"
 ],
 "Model": [
  null,
  "型號"
 ],
 "Mondays": [
  null,
  "每週一"
 ],
 "Monthly": [
  null,
  "每月"
 ],
 "Multi-system chassis": [
  null,
  "多系統機殼"
 ],
 "NTP server": [
  null,
  "NTP 伺服器"
 ],
 "Name": [
  null,
  "名稱"
 ],
 "Need at least one NTP server": [
  null,
  "至少需要一台 NTP 伺服器"
 ],
 "Networking": [
  null,
  "網路"
 ],
 "New password was not accepted": [
  null,
  "不接受新密碼"
 ],
 "No delay": [
  null,
  "沒有延遲"
 ],
 "No host keys found.": [
  null,
  "沒有找到主機金鑰。"
 ],
 "No log entries": [
  null,
  "無紀錄檔項目"
 ],
 "No logs found": [
  null,
  "沒有找到紀錄檔"
 ],
 "No matching results": [
  null,
  "沒有找到相符的結果"
 ],
 "No results found": [
  null,
  "沒有找到結果"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  "沒有結果符合篩選條件。清除所有篩選器以顯示結果。"
 ],
 "No rule hits": [
  null,
  "沒有條件符合"
 ],
 "No such file or directory": [
  null,
  "無此檔案或目錄"
 ],
 "No system modifications": [
  null,
  "沒有系統異動"
 ],
 "None": [
  null,
  "無"
 ],
 "Not a valid private key": [
  null,
  "不是有效的私鑰"
 ],
 "Not connected to Insights": [
  null,
  "未連線至 Insights"
 ],
 "Not found": [
  null,
  "未找到"
 ],
 "Not permitted to configure realms": [
  null,
  "未被允許設定領域"
 ],
 "Not permitted to perform this action.": [
  null,
  "不允許執行此操作。"
 ],
 "Not running": [
  null,
  "非執行中"
 ],
 "Not synchronized": [
  null,
  "不同步"
 ],
 "Note": [
  null,
  "備註"
 ],
 "Notebook": [
  null,
  "筆記型"
 ],
 "Notice and above": [
  null,
  "通知與更高等級"
 ],
 "Occurrences": [
  null,
  "發生次數"
 ],
 "Ok": [
  null,
  "確定"
 ],
 "Old password not accepted": [
  null,
  "舊密碼不被接受"
 ],
 "On failure": [
  null,
  "失敗"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "安裝Cockpit後，使用“systemctl enable --now cockpit.socket”啟用它。"
 ],
 "Only alphabets, numbers, : , _ , . , @ , - are allowed": [
  null,
  "僅允許字母、數字、\":\" 、 \"_\" 、 \".\" 、 \"@\" 和 \"-\""
 ],
 "Only emergency": [
  null,
  "只有緊急情況"
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  "使用 FIPS 模式開機時，僅使用已認證並被允許的演算法。"
 ],
 "Other": [
  null,
  "其它"
 ],
 "Overview": [
  null,
  "主機狀態"
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit 當掉了"
 ],
 "Part of": [
  null,
  "部分"
 ],
 "Password": [
  null,
  "密碼"
 ],
 "Password is not acceptable": [
  null,
  "密碼是不可接受的"
 ],
 "Password is too weak": [
  null,
  "密碼太弱了"
 ],
 "Password not accepted": [
  null,
  "密碼不被接受"
 ],
 "Paste": [
  null,
  "貼上"
 ],
 "Paste error": [
  null,
  "貼上時發生錯誤"
 ],
 "Path": [
  null,
  "路徑"
 ],
 "Path to file": [
  null,
  "檔案路徑"
 ],
 "Paths": [
  null,
  "路徑"
 ],
 "Pause": [
  null,
  "暫停"
 ],
 "Performance profile": [
  null,
  "效能設定檔"
 ],
 "Peripheral chassis": [
  null,
  "週邊設備機殼"
 ],
 "Pick date": [
  null,
  "選擇日期"
 ],
 "Pin unit": [
  null,
  "將單元固定"
 ],
 "Pinned unit": [
  null,
  "已固定的單元"
 ],
 "Pizza box": [
  null,
  "披薩盒"
 ],
 "Portable": [
  null,
  "手提"
 ],
 "Present": [
  null,
  "存在"
 ],
 "Pretty host name": [
  null,
  "易讀主機名稱"
 ],
 "Previous boot": [
  null,
  "上次開機"
 ],
 "Priority": [
  null,
  "優先等級"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "以 ssh-add 提示輸入已逾時"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "以 ssh-keygen 提示輸入已逾時"
 ],
 "Propagates reload to": [
  null,
  "傳播重新載入至"
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  "以犧牲可交互運作性為代價，保護可預期的近期未來攻擊。"
 ],
 "RAID chassis": [
  null,
  "RAID 機殼"
 ],
 "Rack mount chassis": [
  null,
  "機架式機殼"
 ],
 "Rank": [
  null,
  "Rank"
 ],
 "Read more...": [
  null,
  "了解更多…"
 ],
 "Read-only": [
  null,
  "唯讀"
 ],
 "Real host name": [
  null,
  "實際主機名稱"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "實際主機名稱只能包含小寫字元、數字、連字號和句點（與填充的子網域）"
 ],
 "Real host name must be 64 characters or less": [
  null,
  "實際主機名稱須等於或少於 64 個字元"
 ],
 "Reapply and reboot": [
  null,
  "重新套用並重新開機"
 ],
 "Reboot": [
  null,
  "重新開機"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  "可應對當今威脅模式之推薦且安全的設定。"
 ],
 "Reload": [
  null,
  "重新載入"
 ],
 "Reload propagated from": [
  null,
  "重新載入的傳播來自"
 ],
 "Reloading": [
  null,
  "重新讀取中"
 ],
 "Removals:": [
  null,
  "移除："
 ],
 "Remove": [
  null,
  "移除"
 ],
 "Removing $0": [
  null,
  "正在移除 $0"
 ],
 "Repeat": [
  null,
  "重複"
 ],
 "Repeat monthly": [
  null,
  "每月重複"
 ],
 "Repeat weekly": [
  null,
  "每週重複"
 ],
 "Required by": [
  null,
  "要求的"
 ],
 "Required by ": [
  null,
  "被需要於 "
 ],
 "Requires": [
  null,
  "需要"
 ],
 "Requires administration access to edit": [
  null,
  "須有管理員存取權限才能編輯"
 ],
 "Requisite": [
  null,
  "必要"
 ],
 "Requisite of": [
  null,
  "必要於"
 ],
 "Reset": [
  null,
  "重置"
 ],
 "Restart": [
  null,
  "重新啟動"
 ],
 "Resume": [
  null,
  "繼續"
 ],
 "Review cryptographic policy": [
  null,
  "檢視加密政策"
 ],
 "Row expansion": [
  null,
  "展開橫列"
 ],
 "Row select": [
  null,
  "選擇列"
 ],
 "Run at": [
  null,
  "執行於"
 ],
 "Run on": [
  null,
  "執行於"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "由受信任的網路或親自到場於遠端機器上執行此指令："
 ],
 "Running": [
  null,
  "執行中"
 ],
 "Running process prevents directory change": [
  null,
  "執行中的處理程序阻止目錄變更"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "SSH 金鑰"
 ],
 "SSH key login": [
  null,
  "SSH 金鑰登入"
 ],
 "Saturdays": [
  null,
  "每週六"
 ],
 "Save": [
  null,
  "儲存"
 ],
 "Save and reboot": [
  null,
  "儲存並重新開機"
 ],
 "Save changes": [
  null,
  "儲存變更"
 ],
 "Scheduled poweroff at $0": [
  null,
  "預定於 $0 關機"
 ],
 "Scheduled reboot at $0": [
  null,
  "預定於 $0 重新開機"
 ],
 "Sealed-case PC": [
  null,
  "密封式PC"
 ],
 "Search": [
  null,
  "搜尋"
 ],
 "Second needs to be a number between 0-59": [
  null,
  "秒必須為 0-59 間的數字"
 ],
 "Seconds": [
  null,
  "秒"
 ],
 "Secure shell keys": [
  null,
  "安全資料"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Security Enhanced Linux 設定與疑難排解"
 ],
 "Select an option": [
  null,
  "選擇選項"
 ],
 "Server has closed the connection.": [
  null,
  "伺服器已關閉連線。"
 ],
 "Server software": [
  null,
  "伺服器軟體"
 ],
 "Service logs": [
  null,
  "服務日誌"
 ],
 "Services": [
  null,
  "服務"
 ],
 "Set hostname": [
  null,
  "設定主機名稱"
 ],
 "Set time": [
  null,
  "設定時間"
 ],
 "Shell script": [
  null,
  "Shell script"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show confirmation password": [
  null,
  "顯示確認密碼"
 ],
 "Show fingerprints": [
  null,
  "顯示指紋"
 ],
 "Show messages containing given string.": [
  null,
  "顯示包含指定字串的訊息。"
 ],
 "Show messages for the specified systemd unit.": [
  null,
  "顯示所指定 systemd 單元的訊息。"
 ],
 "Show messages from a specific boot.": [
  null,
  "顯示來自指定開機的訊息。"
 ],
 "Show more relationships": [
  null,
  "顯示更多相關服務"
 ],
 "Show password": [
  null,
  "顯示密碼"
 ],
 "Show relationships": [
  null,
  "顯示相關服務"
 ],
 "Shut down": [
  null,
  "關機"
 ],
 "Shutdown": [
  null,
  "關機"
 ],
 "Since": [
  null,
  "自從"
 ],
 "Single rank": [
  null,
  "單 Rank"
 ],
 "Size": [
  null,
  "大小"
 ],
 "Slot": [
  null,
  "插槽"
 ],
 "Sockets": [
  null,
  "Socket"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  "基於軟體的緩解方式可協助避開 CPU 的安全性問題。這些緩解方式有著降低效能的副作用。請審慎評估後才變更這些設定。"
 ],
 "Space-saving computer": [
  null,
  "節省空間的計算機"
 ],
 "Specific time": [
  null,
  "特定的時間"
 ],
 "Speed": [
  null,
  "速度"
 ],
 "Start": [
  null,
  "開始"
 ],
 "Start and enable": [
  null,
  "啟動並啟用"
 ],
 "Start service": [
  null,
  "開始服務"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  "將顯示指定日期與其之後的項目。"
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  "將顯示指定日期與其之前的項目。"
 ],
 "State": [
  null,
  "狀態"
 ],
 "Static": [
  null,
  "靜態"
 ],
 "Status": [
  null,
  "狀態"
 ],
 "Stick PC": [
  null,
  "堅持使用PC"
 ],
 "Stop": [
  null,
  "停止"
 ],
 "Stop and disable": [
  null,
  "停止並停用"
 ],
 "Storage": [
  null,
  "儲存裝置"
 ],
 "Strong password": [
  null,
  "強密碼"
 ],
 "Stub": [
  null,
  "Stub"
 ],
 "Sub-Chassis": [
  null,
  "子機殼"
 ],
 "Sub-Notebook": [
  null,
  "小筆電"
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  "訂閱 systemd 訊號時失敗： $0"
 ],
 "Successfully copied to clipboard": [
  null,
  "已成功複製到剪貼簿"
 ],
 "Sundays": [
  null,
  "每週日"
 ],
 "Synchronized": [
  null,
  "同步"
 ],
 "Synchronized with $0": [
  null,
  "已與 $0 同步"
 ],
 "Synchronizing": [
  null,
  "同步中"
 ],
 "System": [
  null,
  "系統"
 ],
 "System information": [
  null,
  "系統資訊"
 ],
 "System time": [
  null,
  "系統時間"
 ],
 "Systemd units": [
  null,
  "Systemd 單元"
 ],
 "Tablet": [
  null,
  "平板電腦"
 ],
 "Targets": [
  null,
  "目標"
 ],
 "Terminal": [
  null,
  "終端機"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "$2 上 $1 的 SSH 金鑰 $0 將會被新增至 $5 上 $4 的 $3 檔案中。"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH 金鑰 $0 將會於剩餘的工作階段可供使用，也將會可用於登入其他主機。"
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "登入 $0 的 SSH 所用的金鑰受到密碼保護，且該主機並不允許使用密碼登入。請於 $1 提供該金鑰的密碼。"
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "登入 $0 的 SSH 金鑰受到保護。您可以用您的登入密碼、或提供前述金鑰的密碼於 $1 以便登入。"
 ],
 "The fingerprint should match:": [
  null,
  "指紋應該相符："
 ],
 "The key password can not be empty": [
  null,
  "金鑰密碼不可為空值"
 ],
 "The key passwords do not match": [
  null,
  "金鑰密碼不相符"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "登入的使用者沒有檢視系統變更所需的權限"
 ],
 "The password can not be empty": [
  null,
  "密碼不可為空值"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "產生的指紋可放心以公開方式分享，包含電子郵件。"
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "產生的指紋可放心以公開方式分享，包含電子郵件。如果您需要其他人士為您進行驗證，那些人士可使用任何方法傳送結果。"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "伺服器拒絕使用任何受支援的方式進行驗證。"
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  "使用者 $0 無權變更 CPU 安全性緩解方式設定"
 ],
 "The user $0 is not permitted to change cryptographic policies": [
  null,
  "使用者 <b>$0</b> 不被允許變更加密政策"
 ],
 "This field cannot be empty": [
  null,
  "此欄位不可為空"
 ],
 "This may take a while": [
  null,
  "可能還要等一下"
 ],
 "This system is using a custom profile": [
  null,
  "此系統正在使用自訂設定檔"
 ],
 "This system is using the recommended profile": [
  null,
  "此系統正在使用建議的設定檔"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "此工具設定 SELinux 政策且能協助瞭解與處理政策違規事件。"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "此工具設定系統以儲存核心當機傾印。它支援 \"本機\" (磁碟)、\"ssh\"，與 \"nfs\" 作為傾印儲存目的地。"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "此工具會從運作中的系統產生一個具有診斷資訊與設定的封存檔案。這個封存檔案可被存在本機、或為了紀錄與追蹤用途集中存放，也可能被傳送至技術支援代表、開發者或系統管理員以協助排除技術障礙與對程式除錯。"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "此工具管理本機儲存空間，如檔案系統、LVM2 磁碟區群組與掛載 NFS。"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "此工具使用 NetworkManager 與 Firewalld 管理網路功能，如 bond、橋接、teams、VLAN 和防火牆。NetworkManager 與 Ubuntu 預設的 systemd-networkd 及 Debian 的 ifupdown scripts 皆不相容。"
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  "此單元未設計為顯式啟用。"
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  "這將會增加 '_BOOT_ID=' 搜尋條件。如果條件未指定則會顯示當下這次開機的紀錄檔。如果 boot ID 被省略，直接給予一個正的偏移值 (offset) 將會從日誌紀錄的開頭尋找開機項次，而給予等於或小於零的偏移值會從日誌紀錄的結尾往前尋找。因此， 1 代表是日誌中以時間順序找到的第一次開機，2 是第二次、以此類推；而 -0 是最後一次開機、-1 是倒數第二次，以此類推。"
 ],
 "This will add match for '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' and 'UNIT=' to find all possible messages for the given unit. Can contain more units separated by comma.": [
  null,
  "這將會增加 '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' 及 'UNIT=' ' 搜尋條件以尋找指定單元的所有可能訊息。 可透過逗號分隔尋找更多單元。"
 ],
 "Thursdays": [
  null,
  "每週四"
 ],
 "Time": [
  null,
  "時間"
 ],
 "Time zone": [
  null,
  "時區"
 ],
 "Timer creation failed": [
  null,
  "計時器建立失敗"
 ],
 "Timer deletion failed": [
  null,
  "計時器刪除失敗"
 ],
 "Timers": [
  null,
  "計時器"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "要確保您的連線未被惡意的第三方截取，請驗證主機金鑰指紋："
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "要驗證指紋，請實際坐在機器前或透過可信任的網路於 $0 上執行以下指令："
 ],
 "Toggle date picker": [
  null,
  "打開/關閉日期挑選器"
 ],
 "Toggle filters": [
  null,
  "切換篩選器"
 ],
 "Too much data": [
  null,
  "資料過多"
 ],
 "Total size: $0": [
  null,
  "總大小： $0"
 ],
 "Tower": [
  null,
  "塔"
 ],
 "Transient": [
  null,
  "暫時的"
 ],
 "Trigger": [
  null,
  "觸發器"
 ],
 "Triggered by": [
  null,
  "觸發自"
 ],
 "Triggers": [
  null,
  "觸發器"
 ],
 "Trust and add host": [
  null,
  "信任並新增主機"
 ],
 "Trying to synchronize with $0": [
  null,
  "正在嘗試與 $0 同步"
 ],
 "Tuesdays": [
  null,
  "每週二"
 ],
 "Tuned has failed to start": [
  null,
  "Tuned 啟動失敗"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned 是一個監控您的系統並改善特定工作負載效能的服務。Tuned 的核心是設定檔，其基於不同的使用情境調整您的系統。"
 ],
 "Tuned is not available": [
  null,
  "Tuned 無法使用"
 ],
 "Tuned is not running": [
  null,
  "Tuned 非執行中"
 ],
 "Tuned is off": [
  null,
  "Tuned 已關閉"
 ],
 "Type": [
  null,
  "類型"
 ],
 "Type to filter": [
  null,
  "鍵入以篩選"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "無法使用 SSH 金鑰驗證登入 $0。請提供密碼。"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "無法登入 $0 。該主機不接受密碼登入、或您的任何 SSH 金鑰。"
 ],
 "Unable to open directory": [
  null,
  "無法打開目錄"
 ],
 "Unit": [
  null,
  "單元"
 ],
 "Unknown": [
  null,
  "不明"
 ],
 "Unknown host: $0": [
  null,
  "未知的主機： $0"
 ],
 "Unpin unit": [
  null,
  "將單元解除固定"
 ],
 "Until": [
  null,
  "直到"
 ],
 "Untrusted host": [
  null,
  "不受信任的主機"
 ],
 "Up since": [
  null,
  "上線自從"
 ],
 "Updating status...": [
  null,
  "正在更新狀態…"
 ],
 "Usage": [
  null,
  "使用率"
 ],
 "User": [
  null,
  "使用者"
 ],
 "Validating address": [
  null,
  "正在驗證位址"
 ],
 "Vendor": [
  null,
  "供應商"
 ],
 "Verify fingerprint": [
  null,
  "驗證指紋"
 ],
 "Version": [
  null,
  "版本"
 ],
 "View Podman container": [
  null,
  "檢視 Podman 容器"
 ],
 "View all logs": [
  null,
  "檢視所有日誌紀錄檔"
 ],
 "View all services": [
  null,
  "檢視所有服務"
 ],
 "View automation script": [
  null,
  "檢視自動化 script"
 ],
 "View hardware details": [
  null,
  "詳細資料"
 ],
 "View login history": [
  null,
  "檢視登入歷史紀錄"
 ],
 "View metrics and history": [
  null,
  "檢視指標度量與歷史紀錄"
 ],
 "Viewing memory information requires administrative access.": [
  null,
  "檢視記憶體資訊需要管理員存取權限。"
 ],
 "Visit firewall": [
  null,
  "前往防火牆"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "等待其他軟體管理動作完成"
 ],
 "Wanted by": [
  null,
  "被想要於"
 ],
 "Wants": [
  null,
  "想要"
 ],
 "Warning and above": [
  null,
  "警告與更高等級"
 ],
 "Weak password": [
  null,
  "弱密碼"
 ],
 "Web Console for Linux servers": [
  null,
  "Linux伺服器的Web控制台"
 ],
 "Web console is running in limited access mode.": [
  null,
  "網頁控制台目前運作於受限制的存取模式。"
 ],
 "Wednesdays": [
  null,
  "每週三"
 ],
 "Weekly": [
  null,
  "每週"
 ],
 "Weeks": [
  null,
  "週"
 ],
 "White": [
  null,
  "白色"
 ],
 "Yearly": [
  null,
  "每年"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "您第一次連線到 $0 。"
 ],
 "You may try to load older entries.": [
  null,
  "您可以嘗試讀取更早的項目。"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "您的瀏覽器不允許從網頁選單貼上。您可以使用 Shift+Insert 。"
 ],
 "Your session has been terminated.": [
  null,
  "您的工作階段已被終止。"
 ],
 "Your session has expired. Please log in again.": [
  null,
  "您的工作階段已過期。請再次登入。"
 ],
 "Zone": [
  null,
  "區域"
 ],
 "[binary data]": [
  null,
  "[二進位資料]"
 ],
 "[no data]": [
  null,
  "[沒有資料]"
 ],
 "active": [
  null,
  "活性"
 ],
 "edit": [
  null,
  "編輯"
 ],
 "failed to list ssh host keys: $0": [
  null,
  "列出 ssh 主機金鑰失敗： $0"
 ],
 "in less than a minute": [
  null,
  "於一分鐘內"
 ],
 "inconsistent": [
  null,
  "不一致"
 ],
 "journalctl manpage": [
  null,
  "journalctl 線上手冊"
 ],
 "less than a minute ago": [
  null,
  "不到一分鐘前"
 ],
 "none": [
  null,
  "無"
 ],
 "of $0 CPU": [
  null,
  "/ $0 個 CPU"
 ],
 "password quality": [
  null,
  "密碼品質"
 ],
 "recommended": [
  null,
  "推薦的"
 ],
 "running $0": [
  null,
  "正在執行 $0"
 ],
 "show less": [
  null,
  "顯示較少"
 ],
 "show more": [
  null,
  "顯示更多"
 ],
 "unknown": [
  null,
  "不明"
 ],
 "dialog-title\u0004Domain": [
  null,
  "網域"
 ],
 "dialog-title\u0004Join a domain": [
  null,
  "加入網域"
 ],
 "from <host>\u0004from $0": [
  null,
  "從 $0"
 ],
 "from <host> on <terminal>\u0004from $0 on $1": [
  null,
  "從 $1 上的 $0"
 ],
 "on <terminal>\u0004on $0": [
  null,
  "於 $0"
 ]
});
