cockpit.locale({
 "": {
  "plural-forms": (n) => (n>1),
  "language": "tr",
  "language-direction": "ltr"
 },
 "Configuring system settings": [
  null,
  "Sistem ayarlarını yapılandırma"
 ],
 "Diagnostic reports": [
  null,
  "Tanılama raporları"
 ],
 "Kernel dump": [
  null,
  "Çekirdek dökümü"
 ],
 "Logs": [
  null,
  "Günlükler"
 ],
 "Managing services": [
  null,
  "Hizmetleri yönetme"
 ],
 "Networking": [
  null,
  "Ağ"
 ],
 "Overview": [
  null,
  "Genel Bakış"
 ],
 "Reviewing logs": [
  null,
  "Günlükleri gözden geçirme"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Services": [
  null,
  "Hizmetler"
 ],
 "Storage": [
  null,
  "Depolama"
 ],
 "Terminal": [
  null,
  "Terminal"
 ],
 "abrt": [
  null,
  "abrt"
 ],
 "asset tag": [
  null,
  "demirbaş etiketi"
 ],
 "bash": [
  null,
  "bash"
 ],
 "bios": [
  null,
  "bios"
 ],
 "boot": [
  null,
  "önyükleme"
 ],
 "cgroups": [
  null,
  "cgruplar"
 ],
 "command": [
  null,
  "komut"
 ],
 "console": [
  null,
  "konsol"
 ],
 "coredump": [
  null,
  "çekirdek dökümü"
 ],
 "cpu": [
  null,
  "cpu"
 ],
 "crash": [
  null,
  "çökme"
 ],
 "date": [
  null,
  "tarih"
 ],
 "debug": [
  null,
  "hata ayıklama"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "disable": [
  null,
  "etkisizleştir"
 ],
 "disks": [
  null,
  "diskler"
 ],
 "domain": [
  null,
  "etki alanı"
 ],
 "enable": [
  null,
  "etkinleştir"
 ],
 "error": [
  null,
  "hata"
 ],
 "graphs": [
  null,
  "grafikler"
 ],
 "hardware": [
  null,
  "donanım"
 ],
 "history": [
  null,
  "geçmiş"
 ],
 "host": [
  null,
  "anamakine"
 ],
 "journal": [
  null,
  "günlük"
 ],
 "machine": [
  null,
  "makine"
 ],
 "mask": [
  null,
  "maskele"
 ],
 "memory": [
  null,
  "bellek"
 ],
 "metrics": [
  null,
  "ölçümler"
 ],
 "mitigation": [
  null,
  "azaltma"
 ],
 "network": [
  null,
  "ağ"
 ],
 "operating system": [
  null,
  "işletim sistemi"
 ],
 "os": [
  null,
  "is"
 ],
 "path": [
  null,
  "yol"
 ],
 "pci": [
  null,
  "pci"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "performance": [
  null,
  "performans"
 ],
 "power": [
  null,
  "güç"
 ],
 "ram": [
  null,
  "ram"
 ],
 "restart": [
  null,
  "yeniden başlat"
 ],
 "serial": [
  null,
  "seri"
 ],
 "service": [
  null,
  "hizmet"
 ],
 "shell": [
  null,
  "kabuk"
 ],
 "shut": [
  null,
  "kapat"
 ],
 "socket": [
  null,
  "soket"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "hedef"
 ],
 "time": [
  null,
  "saat"
 ],
 "timer": [
  null,
  "zamanlayıcı"
 ],
 "unit": [
  null,
  "birim"
 ],
 "unmask": [
  null,
  "maskelemeyi kaldır"
 ],
 "version": [
  null,
  "sürüm"
 ],
 "warning": [
  null,
  "uyarı"
 ]
});
