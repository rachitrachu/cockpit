cockpit.locale({
 "": {
  "plural-forms": (n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2,
  "language": "cs",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 critical hit": [
  null,
  "$0 kritický zásah",
  "$0 zásahy, včetně kritických",
  "$0 zásahů, včetně kritických"
 ],
 "$0 day": [
  null,
  "$0 den",
  "$0 dny",
  "$0 dnů"
 ],
 "$0 disk is failing": [
  null,
  "$0 disk selhává",
  "$0 disky selhávají",
  "$0 disků selhává"
 ],
 "$0 does not exist": [
  null,
  "$0 neexistuje"
 ],
 "$0 exited with code $1": [
  null,
  "$0 skončilo s kódem $1"
 ],
 "$0 failed": [
  null,
  "$0 se nezdařilo"
 ],
 "$0 failed login attempt": [
  null,
  "$0 nepodařený pokus o přihlášení",
  "$0 nepodařené pokusy o přihlášení",
  "$0 nepodařených pokusů o přihlášení"
 ],
 "$0 filters applied": [
  null,
  "$0 filtrů uplatněno"
 ],
 "$0 hour": [
  null,
  "$0 hodina",
  "$0 hodiny",
  "$0 hodin"
 ],
 "$0 important hit": [
  null,
  "$0 důležitý zásah",
  "$0 zásahy, včetně důležitých",
  "$0 zásahů, včetně důležitých"
 ],
 "$0 is not a directory": [
  null,
  "$0 není složka"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 není k dispozici z žádného z repozitářů."
 ],
 "$0 key changed": [
  null,
  "$0 klíč změněn"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 vynuceně ukončeno signálem $1"
 ],
 "$0 low severity hit": [
  null,
  "$0 zásah s nízkou prioritou",
  "$0 zásahy s nízkou prioritou",
  "$0 zásahů s nízkou prioritou"
 ],
 "$0 minute": [
  null,
  "$0 minuta",
  "$0 minuty",
  "$0 minut"
 ],
 "$0 moderate hit": [
  null,
  "$0 zásah střední závažnosti",
  "$0 zásahy, včetně střední závažnosti",
  "$0 zásahů, včetně střední závažnosti"
 ],
 "$0 month": [
  null,
  "$0 měsíc",
  "$0 měsíce",
  "$0 měsíců"
 ],
 "$0 service has failed": [
  null,
  "$0 služba zhavarovala",
  "$0 služby zhavarovaly",
  "$0 služeb zhavarovalo"
 ],
 "$0 week": [
  null,
  "$0 týden",
  "$0 týdny",
  "$0 týdnů"
 ],
 "$0 will be installed.": [
  null,
  "Bude nainstalováno $0."
 ],
 "$0 year": [
  null,
  "$0 rok",
  "$0 roky",
  "$0 let"
 ],
 "1 day": [
  null,
  "1 den"
 ],
 "1 hour": [
  null,
  "1 hodina"
 ],
 "1 minute": [
  null,
  "1 minuta"
 ],
 "1 week": [
  null,
  "1 týden"
 ],
 "10th": [
  null,
  "10."
 ],
 "11th": [
  null,
  "11."
 ],
 "12th": [
  null,
  "12."
 ],
 "13th": [
  null,
  "13."
 ],
 "14th": [
  null,
  "14."
 ],
 "15th": [
  null,
  "15."
 ],
 "16th": [
  null,
  "16."
 ],
 "17th": [
  null,
  "17."
 ],
 "18th": [
  null,
  "18."
 ],
 "19th": [
  null,
  "19."
 ],
 "1st": [
  null,
  "1."
 ],
 "20 minutes": [
  null,
  "20 minut"
 ],
 "20th": [
  null,
  "20."
 ],
 "21th": [
  null,
  "21."
 ],
 "22th": [
  null,
  "22."
 ],
 "23th": [
  null,
  "23."
 ],
 "24th": [
  null,
  "24."
 ],
 "25th": [
  null,
  "25."
 ],
 "26th": [
  null,
  "26."
 ],
 "27th": [
  null,
  "27."
 ],
 "28th": [
  null,
  "28."
 ],
 "29th": [
  null,
  "29."
 ],
 "2nd": [
  null,
  "2."
 ],
 "30th": [
  null,
  "30."
 ],
 "31st": [
  null,
  "31."
 ],
 "3rd": [
  null,
  "3."
 ],
 "40 minutes": [
  null,
  "40 minut"
 ],
 "4th": [
  null,
  "4."
 ],
 "5 minutes": [
  null,
  "5 minut"
 ],
 "5th": [
  null,
  "5."
 ],
 "6 hours": [
  null,
  "6 hodin"
 ],
 "60 minutes": [
  null,
  "60 minut"
 ],
 "6th": [
  null,
  "6."
 ],
 "7th": [
  null,
  "7."
 ],
 "8th": [
  null,
  "8."
 ],
 "9th": [
  null,
  "9."
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Na $0 není nainstalovaná kompatibilní verze Cockpit."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Na $0 bude vytvořen nový SSH klíč pro $1 na $2 a bude přidán do souboru $3 od $4 na $5."
 ],
 "Absent": [
  null,
  "Chybí"
 ],
 "Acceptable password": [
  null,
  "Přijatelné heslo"
 ],
 "Active since ": [
  null,
  "Aktivní od "
 ],
 "Active state": [
  null,
  "Aktivní stav"
 ],
 "Add": [
  null,
  "Přidat"
 ],
 "Add $0": [
  null,
  "Přidat $0"
 ],
 "Additional actions": [
  null,
  "Další akce"
 ],
 "Additional packages:": [
  null,
  "Další balíčky:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Správa pomocí webové konzole Cockpit"
 ],
 "Advanced TCA": [
  null,
  "Pokročilé TCA"
 ],
 "After": [
  null,
  "Po"
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "Po opuštění domény se do tohoto stroje budou moci přihlásit jen ti uživatelé, kteří mají účet přímo na něm. Může to postihnout také ostatní služby, jako je nastavení DNS překladu a může se změnit seznam důvěryhodných cert. autorit."
 ],
 "After system boot": [
  null,
  "Po startu systému"
 ],
 "Alert and above": [
  null,
  "Výstraha a závažnější"
 ],
 "Alias": [
  null,
  "Alternativní název"
 ],
 "All": [
  null,
  "Vše"
 ],
 "All-in-one": [
  null,
  "Vše-v-jednom"
 ],
 "Allow running (unmask)": [
  null,
  "Umožnit spouštění (odmaskovat)"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Dokumentace k Ansible rolím"
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  "V hlášeních v záznamu událostí (log) je možné filtrovat podle libovolného textového řetězce. Řetězec také může mít podobu regulárního výrazu. Také je podporováno filtrování podle kolonek zprávy záznamu událostí. Zde se jedná o mezerami oddělované hodnoty v podobě KOLONKA=HODNOTA, kde hodnota může být čárkou oddělovaný seznam možných hodnot."
 ],
 "Appearance": [
  null,
  "Vzhled"
 ],
 "Apply and reboot": [
  null,
  "Použít a restartovat"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  "Uplatňování nových zásad… Toto může zabrat několik minut."
 ],
 "Asset tag": [
  null,
  "Inventární štítek"
 ],
 "At minute": [
  null,
  "V minutě"
 ],
 "At second": [
  null,
  "V sekundě"
 ],
 "At specific time": [
  null,
  "V uvedený čas"
 ],
 "Authentication": [
  null,
  "Ověření se"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Pro provádění privilegovaných úloh pomocí webové konzole Cockpit je třeba ověřit se"
 ],
 "Authorize SSH key": [
  null,
  "Pověřit SSH klíč"
 ],
 "Automatically starts": [
  null,
  "Spouští se automaticky"
 ],
 "Automatically using NTP": [
  null,
  "Automaticky pomocí NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Automaticky pomocí dalších NTP serverů"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automaticky pomocí konkrétních NTP serverů"
 ],
 "Automation script": [
  null,
  "Automatizační skript"
 ],
 "BIOS": [
  null,
  "BIOS/UEFI"
 ],
 "BIOS date": [
  null,
  "Datum vydání BIOS/UEFI"
 ],
 "BIOS version": [
  null,
  "Verze BIOS/UEFI"
 ],
 "Bad": [
  null,
  "Chybné"
 ],
 "Bad setting": [
  null,
  "Chybné nastavení"
 ],
 "Before": [
  null,
  "Před"
 ],
 "Binds to": [
  null,
  "Navazuje se na"
 ],
 "Black": [
  null,
  "Černý"
 ],
 "Blade": [
  null,
  "Blade server"
 ],
 "Blade enclosure": [
  null,
  "Skříň se šachtami pro blade servery"
 ],
 "Boot": [
  null,
  "Start systému"
 ],
 "Bound by": [
  null,
  "Spojeno"
 ],
 "Bus expansion chassis": [
  null,
  "Skříň rozšíření sběrnice"
 ],
 "CPU": [
  null,
  "Procesor"
 ],
 "CPU security": [
  null,
  "Zabezpečení procesoru"
 ],
 "CPU security toggles": [
  null,
  "Přepínače zabezpečení procesoru"
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "Při použití stávající kombinace filtrů se nedaří nalézt žádné záznamy událostí."
 ],
 "Cancel": [
  null,
  "Storno"
 ],
 "Cancel poweroff": [
  null,
  "Zrušit vypínání"
 ],
 "Cancel reboot": [
  null,
  "Zrušit restartování"
 ],
 "Cannot be enabled": [
  null,
  "Není možné zapnout"
 ],
 "Cannot forward login credentials": [
  null,
  "Nedaří přeposlat přístupové údaje"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  "Nelze přidat do domény, protože na tomto systému chybí nástroj realmd"
 ],
 "Cannot schedule event in the past": [
  null,
  "Nelze naplánovat událost v minulosti"
 ],
 "Change": [
  null,
  "Změnit"
 ],
 "Change cryptographic policy": [
  null,
  "Změnit zásady pro šifrování"
 ],
 "Change directory": [
  null,
  "Změnit složku"
 ],
 "Change host name": [
  null,
  "Změnit název stroje"
 ],
 "Change performance profile": [
  null,
  "Změnit výkonnostní profil"
 ],
 "Change profile": [
  null,
  "Změnit profil"
 ],
 "Change system time": [
  null,
  "Změnit systémový čas"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Změněné klíče jsou často výsledkem přeinstalace operačního systému. Nicméně, neočekávaná změna může značit pokus třetí strany o vložení se do vaší komunikace."
 ],
 "Changing the directory will forcefully stop the currently running process. The process can also be stopped manually in the terminal before continuing.": [
  null,
  "Změna složky vynuceně ukončí právě spuštěný proces. Proces je také možné před pokračováním zastavit ručně v terminálu."
 ],
 "Checking installed software": [
  null,
  "Zjišťuje se nainstalovaný sofware"
 ],
 "Class": [
  null,
  "Třída"
 ],
 "Clear 'Failed to start'": [
  null,
  "Vyčistit „Nepodařilo se spustit“"
 ],
 "Clear all filters": [
  null,
  "Vyčistit všechny filtry"
 ],
 "Clear input value": [
  null,
  "Vymazat vstupní hodnotu"
 ],
 "Client software": [
  null,
  "Klientský software"
 ],
 "Close": [
  null,
  "Zavřít"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Nastavování NetworkManager a Firewalld v pomocí Cockpit"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit se nepodařilo daný stroj kontaktovat."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit je nástroj, který usnadňuje správu linuxových serverů prostřednictvím webového prohlížeče. Není žádným problémem přecházet mezi terminálem a webovým nástrojem. Služba spuštěná přes Cockpit může být zastavena v terminálu. Podobně, pokud dojde k chybě v terminálu, je toto vidět v rozhraní žurnálu v Cockpit."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit není kompatibilní se softwarem v systému."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit není nainstalován"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit není v systému nainstalován."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit je ideální nástroj pro nové správce systémů, neboť jim umožňuje snadno provádět jednoduché úkoly, jako je správa úložišť, kontrola žurnálu či spouštění a zastavování služeb. Je možné souběžně sledovat a spravovat několik serverů naráz. Stačí je jedním kliknutím přidat a vaše stroje se budou starat o své kamarády."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Shromáždit a zabalit data pro diagnostiku a podporu"
 ],
 "Collect kernel crash dumps": [
  null,
  "Shromáždit výpisy pádů jádra systému"
 ],
 "Command": [
  null,
  "Příkaz"
 ],
 "Command not found": [
  null,
  "Příkaz nenalezen"
 ],
 "Communication with tuned has failed": [
  null,
  "Komunikace s procesem služby tuned se nezdařila"
 ],
 "Compact PCI": [
  null,
  "Compact PCI"
 ],
 "Condition $0=$1 was not met": [
  null,
  "Podmínka $0=$1 nebyla splněna"
 ],
 "Condition failed": [
  null,
  "Podmínka nebyla úspěšná"
 ],
 "Configuration": [
  null,
  "Nastavení"
 ],
 "Confirm deletion of $0": [
  null,
  "Potvrďte smazání $0"
 ],
 "Confirm key password": [
  null,
  "Potvrdit heslo ke klíči"
 ],
 "Conflicted by": [
  null,
  "V konfliktu s"
 ],
 "Conflicts": [
  null,
  "Konflikty"
 ],
 "Connecting to dbus failed: $0": [
  null,
  "Připojení k dbus se nezdařilo: $0"
 ],
 "Connection has timed out.": [
  null,
  "Překročen časový limit připojení."
 ],
 "Consists of": [
  null,
  "Sestává se z"
 ],
 "Contacted domain": [
  null,
  "Připojená doména"
 ],
 "Container": [
  null,
  "Kontejner"
 ],
 "Convertible": [
  null,
  "Počítač 2v1"
 ],
 "Copied": [
  null,
  "Zkopírováno"
 ],
 "Copy": [
  null,
  "Zkopírovat"
 ],
 "Copy to clipboard": [
  null,
  "Zkopírovat do schránky"
 ],
 "Create $0": [
  null,
  "Vytvořit $0"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Vytvořit nový SSH klíč a pověřit ho"
 ],
 "Create new task file with this content.": [
  null,
  "Vytvořte nový soubor s úlohou s tímto obsahem."
 ],
 "Create timer": [
  null,
  "Vytvořit časovač"
 ],
 "Critical and above": [
  null,
  "Kritické a závažnější"
 ],
 "Cryptographic Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  "Kryptografické zásady je systémová součást, která nastavuje hlavní kryptografické podsystémy – pokrývá protokoly TLS, IPSec, SSH, DNSSec a Kerberos."
 ],
 "Cryptographic policy": [
  null,
  "Zásady pro šifrování"
 ],
 "Cryptographic policy is inconsistent": [
  null,
  "Zásady pro šifrování nejsou konzistentní"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Current boot": [
  null,
  "Od tohoto spuštění systému"
 ],
 "Custom cryptographic policy": [
  null,
  "Uživatelsky určené zásady pro šifrování"
 ],
 "DEFAULT with SHA-1 signature verification allowed.": [
  null,
  "VÝCHOZÍ s umožněným ověřování SHA-1 podpisu."
 ],
 "Daily": [
  null,
  "Denně"
 ],
 "Dark": [
  null,
  "Tmavý"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  "Zadání datumů by mělo být ve formátu RRRR-MM-DD hh:mm:ss. Alternativně je možné použít ještě řetězce „yesterday“ (včera), „today“ (dnes), „tomorrow“ (zítra). „now“ (nyní) odkazuje na aktuální dobu. Dále je možné zadávat vztažené (relativní) časy, předeslané předponou „-“ nebo „+“"
 ],
 "Debug and above": [
  null,
  "Ladící a závažnější"
 ],
 "Decrease by one": [
  null,
  "Snížit o jedno"
 ],
 "Default": [
  null,
  "Výchozí"
 ],
 "Delay": [
  null,
  "Prodleva"
 ],
 "Delay must be a number": [
  null,
  "Je třeba, aby prodleva byla číslo"
 ],
 "Delete": [
  null,
  "Smazat"
 ],
 "Deletion will remove the following files:": [
  null,
  "Smazání odebere následující soubory:"
 ],
 "Description": [
  null,
  "Popis"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Detachable": [
  null,
  "Odpojitelné"
 ],
 "Details": [
  null,
  "Podrobnosti"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostická hlášení"
 ],
 "Disable simultaneous multithreading": [
  null,
  "Vypnout souběžné vícevláknové zpracovávání (SMT)"
 ],
 "Disable tuned": [
  null,
  "Zakázat proces služby tuned"
 ],
 "Disabled": [
  null,
  "Vypnuto"
 ],
 "Disallow running (mask)": [
  null,
  "Nepovolit spuštění (maskovat)"
 ],
 "Docking station": [
  null,
  "Dokovací stanice"
 ],
 "Does not automatically start": [
  null,
  "Nespouštět automaticky"
 ],
 "Domain": [
  null,
  "Doména"
 ],
 "Domain address": [
  null,
  "Adresa domény"
 ],
 "Domain administrator name": [
  null,
  "Uživatelské jméno správce domény"
 ],
 "Domain administrator password": [
  null,
  "Heslo správce domény"
 ],
 "Domain could not be contacted": [
  null,
  "Doménu se nedaří kontaktovat"
 ],
 "Domain is not supported": [
  null,
  "Doména není podporována"
 ],
 "Don't repeat": [
  null,
  "Neopakovat"
 ],
 "Downloading $0": [
  null,
  "Stahuje se $0"
 ],
 "Dual rank": [
  null,
  "Dual rank"
 ],
 "Edit /etc/motd": [
  null,
  "Upravit soubor /etc/motd"
 ],
 "Edit motd": [
  null,
  "Upravit motd"
 ],
 "Embedded PC": [
  null,
  "Jednodeskový počítač"
 ],
 "Enabled": [
  null,
  "Povoleno"
 ],
 "Entry at $0": [
  null,
  "Položka na $0"
 ],
 "Error": [
  null,
  "Chyba"
 ],
 "Error and above": [
  null,
  "Chyba a závažnější"
 ],
 "Error message": [
  null,
  "Chybové hlášení"
 ],
 "Excellent password": [
  null,
  "Skvělé heslo"
 ],
 "Expansion chassis": [
  null,
  "Rozšiřující šasi"
 ],
 "FIPS is not properly enabled": [
  null,
  "FIPS není řádně zapnuté"
 ],
 "FIPS with further Common Criteria restrictions.": [
  null,
  "FIPS s dalšími omezeními běžnými kritérii."
 ],
 "Failed to change password": [
  null,
  "Nepodařilo se změnit heslo"
 ],
 "Failed to disable tuned": [
  null,
  "Nepodařilo se zakázat proces služby tuned"
 ],
 "Failed to disable tuned profile": [
  null,
  "Nepodařilo se vypnout tuned profil"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Nepodařilo se povolit $0 ve firewalld"
 ],
 "Failed to enable tuned": [
  null,
  "Nepodařilo se zapnout tuned"
 ],
 "Failed to fetch logs": [
  null,
  "Nepodařilo se získat záznamy událostí"
 ],
 "Failed to load unit": [
  null,
  "Jednotku (unit) se nepodařilo načíst"
 ],
 "Failed to save changes in /etc/motd": [
  null,
  "Nepodařilo se uložit změny v /etc/motd"
 ],
 "Failed to start": [
  null,
  "Nepodařilo se spustit"
 ],
 "Failed to switch profile": [
  null,
  "Nepodařilo se přepnout profil"
 ],
 "File state": [
  null,
  "Stav souboru"
 ],
 "Filter by name or description": [
  null,
  "Filtrovat podle názvu nebo popisu"
 ],
 "Filters": [
  null,
  "Filtry"
 ],
 "Font size": [
  null,
  "Velikost písmen"
 ],
 "Forbidden from running": [
  null,
  "Spuštění zakázáno"
 ],
 "Free-form search": [
  null,
  "Vyhledávání volnou formou"
 ],
 "Fridays": [
  null,
  "Pátky"
 ],
 "Generated": [
  null,
  "Vytvořeno"
 ],
 "Go to $0": [
  null,
  "Jít na $0"
 ],
 "Go to now": [
  null,
  "Přejít na nyní"
 ],
 "Handheld": [
  null,
  "Pro držení v rukou"
 ],
 "Hardware information": [
  null,
  "Informace o hardware"
 ],
 "Health": [
  null,
  "Celkový stav"
 ],
 "Help": [
  null,
  "Nápověda"
 ],
 "Hide confirmation password": [
  null,
  "Skrýt potvrzení hesla"
 ],
 "Hide password": [
  null,
  "Skrýt heslo"
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  "Výborná interoperabilita na úkor zvýšeného vystavení se útokům."
 ],
 "Host key is incorrect": [
  null,
  "Klíč stroje není správný"
 ],
 "Hostname": [
  null,
  "Název stroje"
 ],
 "Hourly": [
  null,
  "Každou hodinu"
 ],
 "Hours": [
  null,
  "Hodin"
 ],
 "ID": [
  null,
  "Identif."
 ],
 "Identifier": [
  null,
  "Identifikátor"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Pokud se otisk shoduje, klikněte na „Důvěřovat a přidat stroj“. V opačném případě se nepřipojujte a obraťte se na správce."
 ],
 "Increase by one": [
  null,
  "Navýšit o jednu"
 ],
 "Indirect": [
  null,
  "Nepřímé"
 ],
 "Info and above": [
  null,
  "Informace a závažnější"
 ],
 "Insights: ": [
  null,
  "Vhledy: "
 ],
 "Install": [
  null,
  "Nainstalovat"
 ],
 "Install realmd support": [
  null,
  "Nainstalovat podporu pro realmd"
 ],
 "Install software": [
  null,
  "Nainstalovat software"
 ],
 "Installing $0": [
  null,
  "Instaluje se $0"
 ],
 "Internal error": [
  null,
  "Vnitřní chyba"
 ],
 "Invalid": [
  null,
  "Neplatné"
 ],
 "Invalid date format": [
  null,
  "Neplatný formát data"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Neplatný formát data a času"
 ],
 "Invalid file permissions": [
  null,
  "Neplatná oprávnění k souboru"
 ],
 "Invalid time format": [
  null,
  "Neplatný formát času"
 ],
 "Invalid timezone": [
  null,
  "Neplatné časové pásmo"
 ],
 "IoT gateway": [
  null,
  "Brána Internetu věcí (IoT)"
 ],
 "Join": [
  null,
  "Spojit"
 ],
 "Join domain": [
  null,
  "Přidat do domény"
 ],
 "Joining": [
  null,
  "Přidává se"
 ],
 "Joining a domain requires installation of realmd": [
  null,
  "Přidání do domény vyžaduje instalaci nástroje realmd"
 ],
 "Joining this domain is not supported": [
  null,
  "Přidání do této domény není podporováno"
 ],
 "Joins namespace of": [
  null,
  "Připojuje jmenný prostor od"
 ],
 "Journal": [
  null,
  "Žurnál"
 ],
 "Journal entry": [
  null,
  "Položka žurnálu"
 ],
 "Journal entry not found": [
  null,
  "Položka žurnálu nenalezena"
 ],
 "Kernel dump": [
  null,
  "Výpis paměti jádra"
 ],
 "Key password": [
  null,
  "Heslo ke klíči"
 ],
 "LEGACY with Active Directory interoperability.": [
  null,
  "PŮVODNÍ s interoperabilitou s Active Directory."
 ],
 "Laptop": [
  null,
  "Notebook"
 ],
 "Last 24 hours": [
  null,
  "Uplynulých 24 hodin"
 ],
 "Last 7 days": [
  null,
  "Uplynulých 7 dnů"
 ],
 "Last successful login:": [
  null,
  "Poslední úspěšné přihlášení:"
 ],
 "Learn more": [
  null,
  "Zjistit více"
 ],
 "Leave $0": [
  null,
  "Opustit $0"
 ],
 "Leave domain": [
  null,
  "Opustit doménu"
 ],
 "Light": [
  null,
  "Světlý"
 ],
 "Linked": [
  null,
  "Odkazováno"
 ],
 "Listen": [
  null,
  "Očekávat spojení"
 ],
 "Listing units": [
  null,
  "Vypisují se jednotky (unit)"
 ],
 "Listing units failed: $0": [
  null,
  "Vypsání jednotek se nezdařilo: $0"
 ],
 "Load earlier entries": [
  null,
  "Načíst dřívější položky"
 ],
 "Loading keys...": [
  null,
  "Načítání klíčů…"
 ],
 "Loading of SSH keys failed": [
  null,
  "Načítání SSH klíčů se nezdařilo"
 ],
 "Loading of units failed": [
  null,
  "Načítání jednotek se nezdařilo"
 ],
 "Loading system modifications...": [
  null,
  "Načítání modifikací systému…"
 ],
 "Loading unit failed": [
  null,
  "Načítání jednotek se nezdařilo"
 ],
 "Loading...": [
  null,
  "Načítání…"
 ],
 "Log in": [
  null,
  "Přihlásit se"
 ],
 "Log in to $0": [
  null,
  "Přihlásit se k $0"
 ],
 "Log messages": [
  null,
  "Zprávy záznamu událostí"
 ],
 "Login failed": [
  null,
  "Přihlášení se nezdařilo"
 ],
 "Login format": [
  null,
  "Formát přihlašování"
 ],
 "Logs": [
  null,
  "Záznamy událostí"
 ],
 "Low profile desktop": [
  null,
  "Nízký desktop"
 ],
 "Lunch box": [
  null,
  "Kufříkový počítač"
 ],
 "Machine ID": [
  null,
  "Identif. stroje"
 ],
 "Machine SSH key fingerprints": [
  null,
  "Otisky SSH klíče stroje"
 ],
 "Main server chassis": [
  null,
  "Hlavní skříň serveru"
 ],
 "Maintenance": [
  null,
  "Údržba"
 ],
 "Manage storage": [
  null,
  "Spravovat úložiště"
 ],
 "Manually": [
  null,
  "Ručně"
 ],
 "Mask service": [
  null,
  "Maskovat službu"
 ],
 "Masked": [
  null,
  "Maskováno"
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  "Maskování služby zabrání všem závislým jednotkám ve spouštění. To může mít větší dopad, než zamýšleno. Potvrďte, že chcete tuto jednotku maskovat."
 ],
 "Memory": [
  null,
  "Paměť"
 ],
 "Memory technology": [
  null,
  "Technologie paměti"
 ],
 "Merged": [
  null,
  "Sloučeno"
 ],
 "Message to logged in users": [
  null,
  "Zpráva přihlášeným uživatelům"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini věž"
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "Je třeba, aby minuta bylo číslo z rozmezí 0-59"
 ],
 "Minutely": [
  null,
  "Po minutách"
 ],
 "Minutes": [
  null,
  "Minut"
 ],
 "Mitigations": [
  null,
  "Zmírnění dopadu zranitelností"
 ],
 "Model": [
  null,
  "Model"
 ],
 "Mondays": [
  null,
  "Pondělky"
 ],
 "Monthly": [
  null,
  "Každý měsíc"
 ],
 "Multi-system chassis": [
  null,
  "Skříň pro více systémů"
 ],
 "NTP server": [
  null,
  "NTP server"
 ],
 "Name": [
  null,
  "Název"
 ],
 "Need at least one NTP server": [
  null,
  "Je třeba alespoň jeden NTP server"
 ],
 "Networking": [
  null,
  "Síť"
 ],
 "New password was not accepted": [
  null,
  "Nové heslo nebylo přijato"
 ],
 "No delay": [
  null,
  "Bez prodlevy"
 ],
 "No host keys found.": [
  null,
  "Nenalezeny žádné klíče stroje."
 ],
 "No log entries": [
  null,
  "Žádné položky záznamu událostí"
 ],
 "No logs found": [
  null,
  "Nenalezeny žádné záznamy událostí"
 ],
 "No matching results": [
  null,
  "Žádné shodující se výsledky"
 ],
 "No results found": [
  null,
  "Nenalezeny žádné výsledky"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  "Kritériím filtru neodpovídají žádné výsledky. Pro zobrazení výsledků vyčistěte veškeré filtry."
 ],
 "No rule hits": [
  null,
  "Žádné zásahy pravidla"
 ],
 "No such file or directory": [
  null,
  "Žádný takový soubor nebo složka"
 ],
 "No system modifications": [
  null,
  "Žádné modifikace systému"
 ],
 "None": [
  null,
  "Žádné"
 ],
 "Not a valid private key": [
  null,
  "Není platná soukromá část klíče"
 ],
 "Not connected to Insights": [
  null,
  "Nepřipojeno k Insights"
 ],
 "Not found": [
  null,
  "Nenalezeno"
 ],
 "Not permitted to configure realms": [
  null,
  "Nemáte oprávnění nastavovat realmy"
 ],
 "Not permitted to perform this action.": [
  null,
  "Neoprávněni k provedení této akce."
 ],
 "Not running": [
  null,
  "Není spuštěné"
 ],
 "Not synchronized": [
  null,
  "Nesynchronizováno"
 ],
 "Note": [
  null,
  "Poznámka"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Notice and above": [
  null,
  "Oznámení a závažnější"
 ],
 "Occurrences": [
  null,
  "Výskyty"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Old password not accepted": [
  null,
  "Původní heslo nebylo přijato"
 ],
 "On failure": [
  null,
  "Při nezdaru"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Jakmile bude Cockpit nainstalovaný, zapněte ho pomocí příkazu „systemctl enable --now cockpit.socket“."
 ],
 "Only alphabets, numbers, : , _ , . , @ , - are allowed": [
  null,
  "Dovolena jsou pouze písmena a číslice, dále ještě znaky : , _ , . , @ , -"
 ],
 "Only emergency": [
  null,
  "Pouze nouzové"
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  "Při startu systému ve FIPS režimu použít pouze schválené a povolené algoritmy."
 ],
 "Other": [
  null,
  "Ostatní"
 ],
 "Overview": [
  null,
  "Přehled"
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit zhavaroval"
 ],
 "Part of": [
  null,
  "Součástí"
 ],
 "Password": [
  null,
  "Heslo"
 ],
 "Password is not acceptable": [
  null,
  "Heslo není přijatelné"
 ],
 "Password is too weak": [
  null,
  "Heslo je příliš slabé"
 ],
 "Password not accepted": [
  null,
  "Heslo nepřijato"
 ],
 "Paste": [
  null,
  "Vložit"
 ],
 "Paste error": [
  null,
  "Chyba vkládání"
 ],
 "Path": [
  null,
  "Popis umístění"
 ],
 "Path to file": [
  null,
  "Popis umístění souboru"
 ],
 "Paths": [
  null,
  "Popisy umístění"
 ],
 "Pause": [
  null,
  "Pozastavit"
 ],
 "Performance profile": [
  null,
  "Výkonnostní profil"
 ],
 "Peripheral chassis": [
  null,
  "Skříň periferií"
 ],
 "Pick date": [
  null,
  "Vyberte datum"
 ],
 "Pin unit": [
  null,
  "Připnout jednotku"
 ],
 "Pinned unit": [
  null,
  "Připnutá jednotka"
 ],
 "Pizza box": [
  null,
  "Velikost „krabice od pizzy“"
 ],
 "Portable": [
  null,
  "Přenosný"
 ],
 "Present": [
  null,
  "Přítomno"
 ],
 "Pretty host name": [
  null,
  "Hezký název stroje"
 ],
 "Previous boot": [
  null,
  "Předchozí spuštění systému"
 ],
 "Priority": [
  null,
  "Priorita"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Časový limit výzvy prostřednictvím ssh-add překročen"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Časový limit výzvy prostřednictvím ssh-keygen překročen"
 ],
 "Propagates reload to": [
  null,
  "Propaguje načíst znovu k"
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  "Chrání před očekávanými nedalekými budoucími útoky za cenu horší interoperability."
 ],
 "RAID chassis": [
  null,
  "RAID skříň"
 ],
 "Rack mount chassis": [
  null,
  "Skříň do stojanu"
 ],
 "Rank": [
  null,
  "Rank"
 ],
 "Read more...": [
  null,
  "Zjistit více…"
 ],
 "Read-only": [
  null,
  "Pouze pro čtení"
 ],
 "Real host name": [
  null,
  "Skutečný název stroje"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "Skutečný název stroje může obsahovat pouze malá písmena (bez diakritiky), číslice, spojovníky a tečky (u použitých subdomén)"
 ],
 "Real host name must be 64 characters or less": [
  null,
  "Je třeba, aby skutečný název stroje byl nanejvýš 64 znaků dlouhý"
 ],
 "Reapply and reboot": [
  null,
  "Znovu uplatnit a restartovat"
 ],
 "Reboot": [
  null,
  "Restartovat"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  "Doporučeno, bezpečné nastavení pro stávající modely ohrožení."
 ],
 "Reload": [
  null,
  "Načíst znovu"
 ],
 "Reload propagated from": [
  null,
  "Znovu načíst propagated z"
 ],
 "Reloading": [
  null,
  "Opětovné načítání"
 ],
 "Removals:": [
  null,
  "Odebrání:"
 ],
 "Remove": [
  null,
  "Odebrat"
 ],
 "Removing $0": [
  null,
  "Odebírá se $0"
 ],
 "Repeat": [
  null,
  "Opakovat"
 ],
 "Repeat monthly": [
  null,
  "Opakovat každý měsíc"
 ],
 "Repeat weekly": [
  null,
  "Opakovat každý týden"
 ],
 "Required by": [
  null,
  "Vyžadováno"
 ],
 "Required by ": [
  null,
  "Vyžadováno "
 ],
 "Requires": [
  null,
  "Vyžaduje"
 ],
 "Requires administration access to edit": [
  null,
  "Pro úpravu jsou vyžadována oprávnění správce systému"
 ],
 "Requisite": [
  null,
  "Závislost"
 ],
 "Requisite of": [
  null,
  "Závislost pro"
 ],
 "Reset": [
  null,
  "Reset"
 ],
 "Restart": [
  null,
  "Restartovat"
 ],
 "Resume": [
  null,
  "Pokračovat"
 ],
 "Review cryptographic policy": [
  null,
  "Zkontrolovat zásady pro šifrování"
 ],
 "Row expansion": [
  null,
  "Rozbalení řádku"
 ],
 "Row select": [
  null,
  "Výběr řádku"
 ],
 "Run at": [
  null,
  "Spustit v"
 ],
 "Run on": [
  null,
  "Spustit na"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Na vzdáleném stroji spusťte – přes důvěryhodnou síť nebo fyzicky přímo na něm – tento příkaz:"
 ],
 "Running": [
  null,
  "Spuštěné"
 ],
 "Running process prevents directory change": [
  null,
  "Spuštěný proces brání ve změně složky"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "SSH klíč"
 ],
 "SSH key login": [
  null,
  "Přihlášení SSH klíčem"
 ],
 "Saturdays": [
  null,
  "Soboty"
 ],
 "Save": [
  null,
  "Uložit"
 ],
 "Save and reboot": [
  null,
  "Uložit a restartovat"
 ],
 "Save changes": [
  null,
  "Uložit změny"
 ],
 "Scheduled poweroff at $0": [
  null,
  "Naplánované vypnutí v $0"
 ],
 "Scheduled reboot at $0": [
  null,
  "Naplánovaný restart v $0"
 ],
 "Sealed-case PC": [
  null,
  "Počítač se zapečetěnou skříní"
 ],
 "Search": [
  null,
  "Hledat"
 ],
 "Second needs to be a number between 0-59": [
  null,
  "Je třeba, aby sekunda bylo číslo z rozmezí 0-59"
 ],
 "Seconds": [
  null,
  "Sekund"
 ],
 "Secure shell keys": [
  null,
  "Klíče zabezpečeného shellu"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Nastavení SELinux a řešení problémů"
 ],
 "Select an option": [
  null,
  "Vyberte možnost"
 ],
 "Server has closed the connection.": [
  null,
  "Server zavřel spojení."
 ],
 "Server software": [
  null,
  "Serverový software"
 ],
 "Service logs": [
  null,
  "Záznamy událostí služby"
 ],
 "Services": [
  null,
  "Služby"
 ],
 "Set hostname": [
  null,
  "Nastavit název stroje"
 ],
 "Set time": [
  null,
  "Nastavit čas"
 ],
 "Shell script": [
  null,
  "Shellový skript"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show confirmation password": [
  null,
  "Zobrazit potvrzení hesla"
 ],
 "Show fingerprints": [
  null,
  "Zobrazit otisky"
 ],
 "Show messages containing given string.": [
  null,
  "Zobrazit zprávy obsahující daný řetězec."
 ],
 "Show messages for the specified systemd unit.": [
  null,
  "Zobrazit zprávy pro zadanou systemd jednotku."
 ],
 "Show messages from a specific boot.": [
  null,
  "Zobrazit zprávy z konkrétního startu systému."
 ],
 "Show more relationships": [
  null,
  "Zobrazit další vztahy"
 ],
 "Show password": [
  null,
  "Zobrazit heslo"
 ],
 "Show relationships": [
  null,
  "Zobrazit vztahy"
 ],
 "Shut down": [
  null,
  "Vypnout"
 ],
 "Shutdown": [
  null,
  "Vypnout"
 ],
 "Since": [
  null,
  "Od"
 ],
 "Single rank": [
  null,
  "Single rank"
 ],
 "Size": [
  null,
  "Velikost"
 ],
 "Slot": [
  null,
  "Slot"
 ],
 "Sockets": [
  null,
  "Sokety"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  "Softwarová ošetření problémů zabezpečení procesoru, snižující riziko jejich zneužití. Mají negativní dopad na výkonnost. Nastavení měníte na vlastní nebezpeční."
 ],
 "Space-saving computer": [
  null,
  "Prostorově úsporný počítač"
 ],
 "Specific time": [
  null,
  "Konkrétní čas"
 ],
 "Speed": [
  null,
  "Rychlost"
 ],
 "Start": [
  null,
  "Spustit"
 ],
 "Start and enable": [
  null,
  "Spustit a zapnout"
 ],
 "Start service": [
  null,
  "Spustit službu"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  "Začít zobrazovat položky od zadaného data výše."
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  "Začít zobrazovat položky od zadaného data dál do minulosti."
 ],
 "State": [
  null,
  "Stav"
 ],
 "Static": [
  null,
  "Statické"
 ],
 "Status": [
  null,
  "Stav"
 ],
 "Stick PC": [
  null,
  "Počítač v klíčence"
 ],
 "Stop": [
  null,
  "Zastavit"
 ],
 "Stop and disable": [
  null,
  "Zastavit a vypnout"
 ],
 "Storage": [
  null,
  "Úložiště"
 ],
 "Strong password": [
  null,
  "Odolné heslo"
 ],
 "Stub": [
  null,
  "Pahýl"
 ],
 "Sub-Chassis": [
  null,
  "Zmenšená skříň"
 ],
 "Sub-Notebook": [
  null,
  "Zmenšený notebook"
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  "Přihlášení se k odběru systemd signálů se nezdařilo: $0"
 ],
 "Successfully copied to clipboard": [
  null,
  "Úspěšně zkopírováno do schránky"
 ],
 "Sundays": [
  null,
  "Neděle"
 ],
 "Synchronized": [
  null,
  "Synchronizováno"
 ],
 "Synchronized with $0": [
  null,
  "Synchronizováno s $0"
 ],
 "Synchronizing": [
  null,
  "Synchronizuje se"
 ],
 "System": [
  null,
  "Systém"
 ],
 "System information": [
  null,
  "Informace o systému"
 ],
 "System time": [
  null,
  "Systémový čas"
 ],
 "Systemd units": [
  null,
  "Systemd jednotky"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Targets": [
  null,
  "Cíle"
 ],
 "Terminal": [
  null,
  "Terminál"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "SSH klíč $0 uživatele $1 na $2 bude přidán do souboru $3 uživatele $4 na $5."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH klíč $0 bude zpřístupněn po celou relaci a bude k dispozici také pro přihlašování se k ostatním strojům."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "SSH klíč pro přihlašování se k $0 je chráněn. Můžete se buď přihlásit svým přihlašovacím heslem nebo zadáním hesla ke klíči na $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "SSH klíč pro přihlašování se k $0 je chráněn. Můžete se buď přihlásit svým přihlašovacím heslem nebo zadáním hesla ke klíči na $1."
 ],
 "The fingerprint should match:": [
  null,
  "Otisk by se měl shodovat:"
 ],
 "The key password can not be empty": [
  null,
  "Heslo ke klíči je třeba vyplnit"
 ],
 "The key passwords do not match": [
  null,
  "Zadání hesla ke klíči se neshodují"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Přihlášený uživatel není oprávněn zobrazovat modifikace systému"
 ],
 "The password can not be empty": [
  null,
  "Heslo je třeba vyplnit"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Výsledný otisk je možné sdílet veřejnými způsoby, včetně e-mailu."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Výsledný otisk je možné bez problémů sdílet prostřednictvím veřejných metod, včetně e-mailu. Pokud někoho jiného požádáte, aby pro vás ověřil, může výsledky poslat libovolnou metodou."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Server odmítl ověřit u všech podporovaných metod."
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  "Uživatel $0 není oprávněn měnit zmírňování dopadu chyb zabezpečení procesoru"
 ],
 "The user $0 is not permitted to change cryptographic policies": [
  null,
  "Uživatel $0 nemá oprávnění měnit pravidla pro šifrování"
 ],
 "This field cannot be empty": [
  null,
  "Tuto kolonku je třeba vyplnit"
 ],
 "This may take a while": [
  null,
  "Toto může chvíli trvat"
 ],
 "This system is using a custom profile": [
  null,
  "Tento systém používá uživatelsky určený profil"
 ],
 "This system is using the recommended profile": [
  null,
  "Tento systém používá doporučený profil"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Tento nástroj nastavuje zásady pro SELinux a může pomoci s porozuměním a řešením jejich porušení."
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Tento nástroj nastavuje systém tak, aby byly zapisovány výpisy pádů jádra. Podporuje cíle výstupu „local“ (disk), „ssh“ a „nfs“."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Tento nástroj vytváří archiv nastavení a diagnostických informací z běžícího systému. Archiv je možné uložit lokálně nebo centrálně pro účely sledování či záznamu nebo je možné ho poslat zástupcům technické podpory, vývojářům nebo správcům systémů aby pomohli s hledáním technických selhání a laděním."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Tento nástroj spravuje místní úložiště, jako například souborové systémy, LVM2 skupiny svazků a NFS připojení."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Tento nástroj spravuje síťování jako například spřažení linek (typu bond i tým), mosty, VLAN sítě a brány firewall pomocí NetworkManager a Firewalld. NetworkManager není kompatibilní s výchozím stavem v Ubuntu (to používá systemd-networkd) a skripty ifupdown v distribuci Debian."
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  "Tato jednotka není navržena k tomu, aby byla výslovně zapnuta."
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  "Toto přidá shodu pro „_BOOT_ID=“. Pokud není určeno, budou zobrazeny záznamy událostí pro stávající start systému. Pokud je identifikátor startu vynechán, kladný posun prohledá starty počínaje od začátku žurnálu a posun rovný nebo menší než nula prohledá starty počínaje od konce žurnálu. Proto 1 znamená první start, nalezený v žurnálu v chronologickém pořadí, 2 druhý a tak dále; zatímco -0 je poslední start, -1 start před tím posledním, a tak dále."
 ],
 "This will add match for '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' and 'UNIT=' to find all possible messages for the given unit. Can contain more units separated by comma.": [
  null,
  "Toto přidá shodu pro „_SYSTEMD_UNIT=“, „COREDUMP_UNIT=“ a „UNIT=“ a pomůže tak nalezení všech případných zpráv pro danou jednotku. Může obsahovat vícero jednotek, oddělovaných čárkou."
 ],
 "Thursdays": [
  null,
  "Čtvrtky"
 ],
 "Time": [
  null,
  "Čas"
 ],
 "Time zone": [
  null,
  "Časové pásmo"
 ],
 "Timer creation failed": [
  null,
  "Vytvoření časovače se nezdařilo"
 ],
 "Timer deletion failed": [
  null,
  "Smazání časovače se nezdařilo"
 ],
 "Timers": [
  null,
  "Časovače"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Abyste zajistili, že do vašeho připojení není zasahováno záškodnickou třetí stranou, ověřte otisk klíče hostitele:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Pokud chcete otisk ověřit, spusťte následující na $0 když jste fyzicky u stroje nebo prostřednictvím důvěryhodné sítě:"
 ],
 "Toggle date picker": [
  null,
  "Přepnout volič datumů"
 ],
 "Toggle filters": [
  null,
  "Přepnout filtry"
 ],
 "Too much data": [
  null,
  "Příliš mnoho dat"
 ],
 "Total size: $0": [
  null,
  "Celková velikost: $0"
 ],
 "Tower": [
  null,
  "Věž"
 ],
 "Transient": [
  null,
  "Přechodné"
 ],
 "Trigger": [
  null,
  "Spouštěč"
 ],
 "Triggered by": [
  null,
  "Spuštěno na základě"
 ],
 "Triggers": [
  null,
  "Spouštěče"
 ],
 "Trust and add host": [
  null,
  "Důvěřovat a přidat hostitele"
 ],
 "Trying to synchronize with $0": [
  null,
  "Pokus o synchronizaci se $0"
 ],
 "Tuesdays": [
  null,
  "Úterky"
 ],
 "Tuned has failed to start": [
  null,
  "Spuštění procesu služby tuned se nezdařilo"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned je služba která monitoruje váš systém a optimalizuje jeho výkon pod určitými zátěžemi. Jádrem Tuned jsou profily, který ladí váš systém pro různé případy použití."
 ],
 "Tuned is not available": [
  null,
  "Tuned není k dispozici"
 ],
 "Tuned is not running": [
  null,
  "Tuned není spuštěné"
 ],
 "Tuned is off": [
  null,
  "Tuned je vypnuté"
 ],
 "Type": [
  null,
  "Typ"
 ],
 "Type to filter": [
  null,
  "Filtrujte psaním"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Nepodařilo se přihlásit k $0 pomocí ověření se SSH klíčem. Prosím zadejte heslo."
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Nedaří se přihlásit k $0. Hostitel nepřijímá přihlášení heslem nebo žádný z vašich SSH klíčů."
 ],
 "Unable to open directory": [
  null,
  "Složku není možné otevřít"
 ],
 "Unit": [
  null,
  "Jednotka"
 ],
 "Unknown": [
  null,
  "Neznámé"
 ],
 "Unknown host: $0": [
  null,
  "Neznámý hostitel: $0"
 ],
 "Unpin unit": [
  null,
  "Zrušit připnutí jednotky"
 ],
 "Until": [
  null,
  "Do"
 ],
 "Untrusted host": [
  null,
  "Nedůvěryhodný stroj"
 ],
 "Up since": [
  null,
  "Zapnuto před"
 ],
 "Updating status...": [
  null,
  "Aktualizace stavu…"
 ],
 "Usage": [
  null,
  "Využití"
 ],
 "User": [
  null,
  "Uživatel"
 ],
 "Validating address": [
  null,
  "Ověřuje se adresa"
 ],
 "Vendor": [
  null,
  "Výrobce"
 ],
 "Verify fingerprint": [
  null,
  "Ověřit otisk"
 ],
 "Version": [
  null,
  "Verze"
 ],
 "View Podman container": [
  null,
  "Zobrazit Podman kontejner"
 ],
 "View all logs": [
  null,
  "Zobrazit všechny záznamy událostí"
 ],
 "View all services": [
  null,
  "Zobrazit všechny služby"
 ],
 "View automation script": [
  null,
  "Zobrazit automatizační skript"
 ],
 "View hardware details": [
  null,
  "Zobrazit podrobnosti o hardware"
 ],
 "View login history": [
  null,
  "Zobrazit historii přihlášení"
 ],
 "View metrics and history": [
  null,
  "Zobrazit metriky a jejich historii"
 ],
 "Viewing memory information requires administrative access.": [
  null,
  "Zobrazování informaci o paměti vyžaduje oprávnění na úrovni správy systému."
 ],
 "Visit firewall": [
  null,
  "Jít na bránu firewall"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Čeká se na dokončení ostatních operací správy balíčků"
 ],
 "Wanted by": [
  null,
  "Vyžadováno"
 ],
 "Wants": [
  null,
  "Vyžaduje"
 ],
 "Warning and above": [
  null,
  "Varování a závažnější"
 ],
 "Weak password": [
  null,
  "Snadno prolomitelné heslo"
 ],
 "Web Console for Linux servers": [
  null,
  "Webová konzole pro linuxové servery"
 ],
 "Web console is running in limited access mode.": [
  null,
  "Webová konzole je spuštěná v režimu omezeného přístupu."
 ],
 "Wednesdays": [
  null,
  "Středy"
 ],
 "Weekly": [
  null,
  "Každý týden"
 ],
 "Weeks": [
  null,
  "Týdny"
 ],
 "White": [
  null,
  "Bílý"
 ],
 "Yearly": [
  null,
  "Každý rok"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "K $0 se připojujete poprvé."
 ],
 "You may try to load older entries.": [
  null,
  "Můžete zkusit načíst starší položky."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Vámi využívaný prohlížeč neumožňuje vkládání z kontextové nabídky. Náhradně je možné použít Shift+Insert."
 ],
 "Your session has been terminated.": [
  null,
  "Vaše sezení bylo ukončeno."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Platnost vašeho sezení skončila. Přihlaste se znovu."
 ],
 "Zone": [
  null,
  "Zóna"
 ],
 "[binary data]": [
  null,
  "[binární data]"
 ],
 "[no data]": [
  null,
  "[žádná data]"
 ],
 "active": [
  null,
  "aktivní"
 ],
 "edit": [
  null,
  "upravit"
 ],
 "failed to list ssh host keys: $0": [
  null,
  "nepodařilo se vypsat ssh klíče stroje: $0"
 ],
 "in less than a minute": [
  null,
  "za méně než minutu"
 ],
 "inconsistent": [
  null,
  "nekonzistentní"
 ],
 "journalctl manpage": [
  null,
  "manuálová stránka k journalctl"
 ],
 "less than a minute ago": [
  null,
  "před méně než minutou"
 ],
 "none": [
  null,
  "nic"
 ],
 "of $0 CPU": [
  null,
  "z $0 procesoru",
  "ze $0 procesorů",
  "z $0 procesorů"
 ],
 "password quality": [
  null,
  "odolnost hesla"
 ],
 "recommended": [
  null,
  "doporučeno"
 ],
 "running $0": [
  null,
  "provozováno na $0"
 ],
 "show less": [
  null,
  "zobrazit méně"
 ],
 "show more": [
  null,
  "zobrazit více"
 ],
 "unknown": [
  null,
  "neznámý"
 ],
 "dialog-title\u0004Domain": [
  null,
  "Doména"
 ],
 "dialog-title\u0004Join a domain": [
  null,
  "Přidat do domény"
 ],
 "from <host>\u0004from $0": [
  null,
  "z $0"
 ],
 "from <host> on <terminal>\u0004from $0 on $1": [
  null,
  "z $0 na $1"
 ],
 "on <terminal>\u0004on $0": [
  null,
  "na $0"
 ]
});
