cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "es",
  "language-direction": "ltr"
 },
 "Configuring system settings": [
  null,
  "Cambiando la configuración del sistema"
 ],
 "Diagnostic reports": [
  null,
  "Informes de diagnóstico"
 ],
 "Kernel dump": [
  null,
  "Volcado del kernel"
 ],
 "Logs": [
  null,
  "Registros"
 ],
 "Managing services": [
  null,
  "Gestión de servicios"
 ],
 "Networking": [
  null,
  "Redes"
 ],
 "Overview": [
  null,
  "Visión global"
 ],
 "Reviewing logs": [
  null,
  "Revisión de registros"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Services": [
  null,
  "Servicios"
 ],
 "Storage": [
  null,
  "Almacenamiento"
 ],
 "Terminal": [
  null,
  "Terminal"
 ],
 "abrt": [
  null,
  "abrt"
 ],
 "asset tag": [
  null,
  "etiqueta de propiedad"
 ],
 "bash": [
  null,
  "bash"
 ],
 "bios": [
  null,
  "bios"
 ],
 "boot": [
  null,
  "arrancar"
 ],
 "cgroups": [
  null,
  "cgroups"
 ],
 "command": [
  null,
  "comando"
 ],
 "console": [
  null,
  "consola"
 ],
 "coredump": [
  null,
  "coredump"
 ],
 "cpu": [
  null,
  "cpu"
 ],
 "crash": [
  null,
  "colapso"
 ],
 "date": [
  null,
  "fecha"
 ],
 "debug": [
  null,
  "depurar"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "disable": [
  null,
  "desactivar"
 ],
 "disks": [
  null,
  "discos"
 ],
 "domain": [
  null,
  "dominio"
 ],
 "enable": [
  null,
  "activar"
 ],
 "error": [
  null,
  "error"
 ],
 "graphs": [
  null,
  "gráficos"
 ],
 "hardware": [
  null,
  "hardware"
 ],
 "history": [
  null,
  "histórico"
 ],
 "host": [
  null,
  "anfitrión"
 ],
 "journal": [
  null,
  "journal"
 ],
 "machine": [
  null,
  "máquina"
 ],
 "mask": [
  null,
  "máscara"
 ],
 "memory": [
  null,
  "memoria"
 ],
 "metrics": [
  null,
  "métricas"
 ],
 "mitigation": [
  null,
  "migitación"
 ],
 "network": [
  null,
  "red"
 ],
 "operating system": [
  null,
  "sistema operativo"
 ],
 "os": [
  null,
  "so"
 ],
 "path": [
  null,
  "ruta"
 ],
 "pci": [
  null,
  "pci"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "performance": [
  null,
  "rendimiento"
 ],
 "power": [
  null,
  "corriente"
 ],
 "ram": [
  null,
  "ram"
 ],
 "restart": [
  null,
  "reiniciar"
 ],
 "serial": [
  null,
  "serie"
 ],
 "service": [
  null,
  "servicio"
 ],
 "shell": [
  null,
  "shell"
 ],
 "shut": [
  null,
  "cerrar"
 ],
 "socket": [
  null,
  "socket"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "destino"
 ],
 "time": [
  null,
  "hora"
 ],
 "timer": [
  null,
  "temporizador"
 ],
 "unit": [
  null,
  "unit"
 ],
 "unmask": [
  null,
  "desenmascarar"
 ],
 "version": [
  null,
  "versión"
 ],
 "warning": [
  null,
  "aviso"
 ]
});
