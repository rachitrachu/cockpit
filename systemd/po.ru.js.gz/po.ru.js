cockpit.locale({
 "": {
  "plural-forms": (n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "ru",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 ГиБ"
 ],
 "$0 critical hit": [
  null,
  "$0 критическое попадание",
  "$0 попадания, включая критическое",
  "$0 попаданий, включая критическое"
 ],
 "$0 day": [
  null,
  "$0 день",
  "$0 дня",
  "$0 дней"
 ],
 "$0 disk is failing": [
  null,
  "Сбой $0 диска",
  "Сбой $0 дисков",
  "Сбой $0 дисков"
 ],
 "$0 does not exist": [
  null,
  "$0 не существует"
 ],
 "$0 exited with code $1": [
  null,
  "Процесс $0 завершил работу с кодом $1"
 ],
 "$0 failed": [
  null,
  "Сбой процесса $0"
 ],
 "$0 failed login attempt": [
  null,
  "$0 неудачная попытка входа в систему",
  "$0 неудачные попытки входа в систему",
  "$0 неудачных попыток входа в систему"
 ],
 "$0 filters applied": [
  null,
  "Фильтров применено: $0"
 ],
 "$0 hour": [
  null,
  "$0 час",
  "$0 часа",
  "$0 часов"
 ],
 "$0 important hit": [
  null,
  "$0 важное попадание",
  "$0 попадания, включая важное",
  "$0 попаданий, включая важное"
 ],
 "$0 is not a directory": [
  null,
  "$0 не является каталогом"
 ],
 "$0 is not available from any repository.": [
  null,
  "Компонент $0 недоступен в репозиториях."
 ],
 "$0 key changed": [
  null,
  "Изменен $0 ключ"
 ],
 "$0 killed with signal $1": [
  null,
  "Процесс $0 прерван с сигналом $1"
 ],
 "$0 low severity hit": [
  null,
  "$0 попадание с низким уровнем серьезности",
  "$0 попадания с низким уровнем серьезности",
  "$0 попаданий с низким уровнем серьезности"
 ],
 "$0 minute": [
  null,
  "$0 минута",
  "$0 минуты",
  "$0 минут"
 ],
 "$0 moderate hit": [
  null,
  "$0 умеренное попадание",
  "$0 попадания, включая умеренные",
  "$0 попаданий, включая умеренные"
 ],
 "$0 month": [
  null,
  "$0 месяц",
  "$0 месяца",
  "$0 месяцев"
 ],
 "$0 service has failed": [
  null,
  "Сбой $0 службы",
  "Сбой $0 служб",
  "Сбой $0 служб"
 ],
 "$0 week": [
  null,
  "$0 неделя",
  "$0 недели",
  "$0 недель"
 ],
 "$0 will be installed.": [
  null,
  "Будет выполнена установка $0."
 ],
 "$0 year": [
  null,
  "$0 год",
  "$0 года",
  "$0 лет"
 ],
 "1 day": [
  null,
  "1 день"
 ],
 "1 hour": [
  null,
  "1 час"
 ],
 "1 minute": [
  null,
  "1 минута"
 ],
 "1 week": [
  null,
  "1 неделя"
 ],
 "10th": [
  null,
  "10-го числа"
 ],
 "11th": [
  null,
  "11-го числа"
 ],
 "12th": [
  null,
  "12-го числа"
 ],
 "13th": [
  null,
  "13-го числа"
 ],
 "14th": [
  null,
  "14-го числа"
 ],
 "15th": [
  null,
  "15-го числа"
 ],
 "16th": [
  null,
  "16-го числа"
 ],
 "17th": [
  null,
  "17-го числа"
 ],
 "18th": [
  null,
  "18-го числа"
 ],
 "19th": [
  null,
  "19-го числа"
 ],
 "1st": [
  null,
  "1-го числа"
 ],
 "20 minutes": [
  null,
  "20 минут"
 ],
 "20th": [
  null,
  "20-го числа"
 ],
 "21th": [
  null,
  "21-го числа"
 ],
 "22th": [
  null,
  "22-го числа"
 ],
 "23th": [
  null,
  "23-го числа"
 ],
 "24th": [
  null,
  "24-го числа"
 ],
 "25th": [
  null,
  "25-го числа"
 ],
 "26th": [
  null,
  "26-го числа"
 ],
 "27th": [
  null,
  "27-го числа"
 ],
 "28th": [
  null,
  "28-го числа"
 ],
 "29th": [
  null,
  "29-го числа"
 ],
 "2nd": [
  null,
  "2-го числа"
 ],
 "30th": [
  null,
  "30-го числа"
 ],
 "31st": [
  null,
  "31-го числа"
 ],
 "3rd": [
  null,
  "3-го числа"
 ],
 "40 minutes": [
  null,
  "40 минут"
 ],
 "4th": [
  null,
  "4-го числа"
 ],
 "5 minutes": [
  null,
  "5 минут"
 ],
 "5th": [
  null,
  "5-го числа"
 ],
 "6 hours": [
  null,
  "6 часов"
 ],
 "60 minutes": [
  null,
  "60 минут"
 ],
 "6th": [
  null,
  "6-го числа"
 ],
 "7th": [
  null,
  "7-го числа"
 ],
 "8th": [
  null,
  "8-го числа"
 ],
 "9th": [
  null,
  "9-го числа"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Совместимая версия Cockpit не установлена на $0."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Будет создан новый ключ SSH в $0 для $1 на $2 и добавлен в файл $3 $4 на $5."
 ],
 "Absent": [
  null,
  "Отсутствует"
 ],
 "Acceptable password": [
  null,
  "Допустимый пароль"
 ],
 "Active since ": [
  null,
  "Активно с "
 ],
 "Active state": [
  null,
  "Активное состояние"
 ],
 "Add": [
  null,
  "Добавить"
 ],
 "Add $0": [
  null,
  "Добавить $0"
 ],
 "Additional actions": [
  null,
  "Дополнительные действия"
 ],
 "Additional packages:": [
  null,
  "Дополнительные пакеты:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Администрирование с помощью веб-панели управления Cockpit"
 ],
 "Advanced TCA": [
  null,
  "Расширенный TCA"
 ],
 "After": [
  null,
  "After="
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "После выхода из домена только пользователи с локальными учётными данными смогут выполнить вход в эту систему. Это также может повлиять и на другие службы, поскольку параметры разрешения DNS и список доверенных центров сертификации могут измениться."
 ],
 "After system boot": [
  null,
  "После загрузки системы"
 ],
 "Alert and above": [
  null,
  "Оповещения и выше"
 ],
 "Alias": [
  null,
  "Псевдоним"
 ],
 "All": [
  null,
  "Все"
 ],
 "All-in-one": [
  null,
  "Все в одном"
 ],
 "Allow running (unmask)": [
  null,
  "Разрешить выполнение (снять маску)"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Документация к ролям Ansible"
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  "Любая текстовая строка в сообщениях журнала может быть отфильтрована. Строка также может быть представлена в виде регулярного выражения. Также поддерживает фильтрацию по полям журнала сообщений. Это значения, разделенные пробелами, в форме ПОЛЕ=ЗНАЧЕНИЕ, где значение может быть списком возможных значений, разделенных запятыми."
 ],
 "Appearance": [
  null,
  "Стиль отображения"
 ],
 "Apply and reboot": [
  null,
  "Применить и перезагрузить"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  "Применение новой политики… Это может занять несколько минут."
 ],
 "Asset tag": [
  null,
  "Тег актива"
 ],
 "At minute": [
  null,
  "В минуту"
 ],
 "At second": [
  null,
  "В секунду"
 ],
 "At specific time": [
  null,
  "В определённое время"
 ],
 "Authentication": [
  null,
  "Проверка подлинности"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Для выполнения привилегированных задач с помощью веб-консоли Cockpit необходима проверка подлинности"
 ],
 "Authorize SSH key": [
  null,
  "Авторизовать SSH-ключ"
 ],
 "Automatically starts": [
  null,
  "Запускается автоматически"
 ],
 "Automatically using NTP": [
  null,
  "Автоматически с использованием серверов NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Автоматически с использованием дополнительных серверов NTP"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Автоматически с использованием определённых серверов NTP"
 ],
 "Automation script": [
  null,
  "Сценарий автоматизации"
 ],
 "BIOS": [
  null,
  "BIOS"
 ],
 "BIOS date": [
  null,
  "Дата BIOS"
 ],
 "BIOS version": [
  null,
  "Версия BIOS"
 ],
 "Bad": [
  null,
  "Плохо"
 ],
 "Bad setting": [
  null,
  "Плохой параметр"
 ],
 "Before": [
  null,
  "Before="
 ],
 "Binds to": [
  null,
  "BindsTo="
 ],
 "Black": [
  null,
  "Чёрный"
 ],
 "Blade": [
  null,
  "Ультракомпактный сервер"
 ],
 "Blade enclosure": [
  null,
  "Корзина"
 ],
 "Boot": [
  null,
  "Загрузка"
 ],
 "Bound by": [
  null,
  "BoundBy="
 ],
 "Bus expansion chassis": [
  null,
  "Корпус расширения шины"
 ],
 "CPU": [
  null,
  "ЦП"
 ],
 "CPU security": [
  null,
  "Безопасность процессора"
 ],
 "CPU security toggles": [
  null,
  "Переключатели безопасности ЦП"
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "Не удается найти журналы на основе текущего сочетания фильтров."
 ],
 "Cancel": [
  null,
  "Отмена"
 ],
 "Cancel poweroff": [
  null,
  "Отменить выключение"
 ],
 "Cancel reboot": [
  null,
  "Отменить перезагрузку"
 ],
 "Cannot be enabled": [
  null,
  "Не может быть активирован"
 ],
 "Cannot forward login credentials": [
  null,
  "Не удаётся передать учётные данные для входа"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  "Не удается присоединиться к домену, потому что на этой системе нет realmd"
 ],
 "Cannot schedule event in the past": [
  null,
  "Невозможно запланировать событие в прошлом"
 ],
 "Change": [
  null,
  "Изменить"
 ],
 "Change cryptographic policy": [
  null,
  "Изменить правила шифрования"
 ],
 "Change directory": [
  null,
  "Сменить каталог"
 ],
 "Change host name": [
  null,
  "Изменить имя узла"
 ],
 "Change performance profile": [
  null,
  "Изменить профиль производительности"
 ],
 "Change profile": [
  null,
  "Изменить профиль"
 ],
 "Change system time": [
  null,
  "Изменить системное время"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Изменение ключей часто происходит в результате переустановки операционной системы. Однако неожиданное изменение может указывать на попытку третьей стороны перехватить ваше соединение."
 ],
 "Changing the directory will forcefully stop the currently running process. The process can also be stopped manually in the terminal before continuing.": [
  null,
  "Смена каталога приведет к принудительной остановке текущего процесса. Процесс также можно остановить вручную в терминале, прежде чем продолжить."
 ],
 "Checking installed software": [
  null,
  "Проверка установленного программного обеспечения"
 ],
 "Class": [
  null,
  "Класс"
 ],
 "Clear 'Failed to start'": [
  null,
  "Очистить «Сбой запуска»"
 ],
 "Clear all filters": [
  null,
  "Сбросить все фильтры"
 ],
 "Clear input value": [
  null,
  "Сбросить входное значение"
 ],
 "Client software": [
  null,
  "Клиентское программное обеспечение"
 ],
 "Close": [
  null,
  "Закрыть"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Настройка Cockpit для NetworkManager и Firewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Не удалось установить связь между Cockpit и заданным узлом."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit представляет собой диспетчер серверов, упрощающий администрирование серверов Linux через веб-браузер. Переключение между терминалом и веб-инструментом не представляет сложности. Служба, запущенная с помощью Cockpit, может быть остановлена через терминал. Аналогично, если в терминале возникает ошибка, её можно увидеть в интерфейсе журнала Cockpit."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit не совместим с программным обеспечением в системе."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit не установлен"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit не установлен в системе."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit идеально подходит для новых системных администраторов, позволяя им легко выполнять простые задачи, такие как администрирование хранилищ, проверка журналов и запуск и остановка служб. С помощью Cockpit вы можете контролировать и администрировать несколько серверов одновременно. Просто добавьте их одним щелчком мыши, и ваш компьютер позаботится о своих приятелях."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Собрать и упаковать диагностические данные и данные поддержки"
 ],
 "Collect kernel crash dumps": [
  null,
  "Собрать аварийный дамп ядра"
 ],
 "Command": [
  null,
  "Команда"
 ],
 "Command not found": [
  null,
  "Команда не найдена"
 ],
 "Communication with tuned has failed": [
  null,
  "Сбой связи с демоном tuned"
 ],
 "Compact PCI": [
  null,
  "Компактный PCI"
 ],
 "Condition $0=$1 was not met": [
  null,
  "Не выполнено условие $0=$1"
 ],
 "Condition failed": [
  null,
  "Условие не выполнено"
 ],
 "Configuration": [
  null,
  "Настройка"
 ],
 "Confirm deletion of $0": [
  null,
  "Подтвердите удаление $0"
 ],
 "Confirm key password": [
  null,
  "Подтвердите ключевой пароль"
 ],
 "Conflicted by": [
  null,
  "ConflictedBy="
 ],
 "Conflicts": [
  null,
  "Conflicts="
 ],
 "Connecting to dbus failed: $0": [
  null,
  "Не удалось подключиться к dbus: $0"
 ],
 "Connection has timed out.": [
  null,
  "Превышено время ожидания подключения."
 ],
 "Consists of": [
  null,
  "ConsistsOf="
 ],
 "Contacted domain": [
  null,
  "Связь с доменом установлена"
 ],
 "Convertible": [
  null,
  "Компьютер-трансформер"
 ],
 "Copied": [
  null,
  "Скопировано"
 ],
 "Copy": [
  null,
  "Копировать"
 ],
 "Copy to clipboard": [
  null,
  "Копировать в буфер обмена"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Создать новый SSH-ключ и авторизовать его"
 ],
 "Create new task file with this content.": [
  null,
  "Создайте новый файл задачи с этим содержимым."
 ],
 "Create timer": [
  null,
  "Создать таймер"
 ],
 "Critical and above": [
  null,
  "Критические оповещения и выше"
 ],
 "Cryptographic Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  "«Правила шифрования» (Crypto Policies) — это системный компонент для настройки основных криптографических подсистем, включающих протоколы TLS, IPSec, SSH, DNSSec и Kerberos."
 ],
 "Cryptographic policy": [
  null,
  "Правило шифрования"
 ],
 "Cryptographic policy is inconsistent": [
  null,
  "Правило шифрования несовместимо"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Current boot": [
  null,
  "Текущая сессия"
 ],
 "Custom cryptographic policy": [
  null,
  "Дополнительное правило шифрования"
 ],
 "DEFAULT with SHA-1 signature verification allowed.": [
  null,
  "DEFAULT с разрешённой проверкой подписи SHA-1."
 ],
 "Daily": [
  null,
  "Ежедневно"
 ],
 "Dark": [
  null,
  "Тёмный"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  "Дата должна быть представлена в формате YYYY-MM-DD hh:mm:ss. Также можно использовать строки «yesterday» (вчера), «today» (сегодня), «tomorrow» (завтра). Строка «now» (сейчас) означает текущее время. Наконец, можно указывать относительное время с префиксом «-» или «+»"
 ],
 "Debug and above": [
  null,
  "Отладочные сообщения и выше"
 ],
 "Decrease by one": [
  null,
  "Уменьшить на один"
 ],
 "Default": [
  null,
  "По умолчанию"
 ],
 "Delay": [
  null,
  "Задержка"
 ],
 "Delay must be a number": [
  null,
  "Величина задержки должна быть задана в виде числа"
 ],
 "Delete": [
  null,
  "Удалить"
 ],
 "Deletion will remove the following files:": [
  null,
  "При удалении будут уничтожены следующие файлы:"
 ],
 "Description": [
  null,
  "Описание"
 ],
 "Desktop": [
  null,
  "Настольный компьютер"
 ],
 "Detachable": [
  null,
  "Съёмный компьютер"
 ],
 "Details": [
  null,
  "Подробности"
 ],
 "Diagnostic reports": [
  null,
  "Диагностические отчёты"
 ],
 "Disable simultaneous multithreading": [
  null,
  "Отключить одновременную многопотоковость"
 ],
 "Disable tuned": [
  null,
  "Отключить демон tuned"
 ],
 "Disabled": [
  null,
  "Отключено"
 ],
 "Disallow running (mask)": [
  null,
  "Запретить выполнение (добавить маску)"
 ],
 "Docking station": [
  null,
  "Стыковочный узел"
 ],
 "Does not automatically start": [
  null,
  "Не запускается автоматически"
 ],
 "Domain": [
  null,
  "Домен"
 ],
 "Domain address": [
  null,
  "Адрес домена"
 ],
 "Domain administrator name": [
  null,
  "Имя администратора домена"
 ],
 "Domain administrator password": [
  null,
  "Пароль администратора домена"
 ],
 "Domain could not be contacted": [
  null,
  "Не удалось установить связь с доменом"
 ],
 "Domain is not supported": [
  null,
  "Домен не поддерживается"
 ],
 "Don't repeat": [
  null,
  "Без повтора"
 ],
 "Downloading $0": [
  null,
  "Загрузка $0"
 ],
 "Dual rank": [
  null,
  "Двухранговая"
 ],
 "Edit /etc/motd": [
  null,
  "Изменение /etc/motd"
 ],
 "Edit motd": [
  null,
  "Изменение motd"
 ],
 "Embedded PC": [
  null,
  "Встраиваемый компьютер"
 ],
 "Enabled": [
  null,
  "Включено"
 ],
 "Entry at $0": [
  null,
  "Запись в $0"
 ],
 "Error": [
  null,
  "Ошибка"
 ],
 "Error and above": [
  null,
  "Сообщения об ошибках и выше"
 ],
 "Error message": [
  null,
  "Сообщение об ошибке"
 ],
 "Excellent password": [
  null,
  "Отличный пароль"
 ],
 "Expansion chassis": [
  null,
  "Корпус расширения"
 ],
 "FIPS is not properly enabled": [
  null,
  "FIPS активирован неправильно"
 ],
 "FIPS with further Common Criteria restrictions.": [
  null,
  "FIPS с дополнительными ограничениями по общим критериям."
 ],
 "Failed to change password": [
  null,
  "Не удалось изменить пароль"
 ],
 "Failed to disable tuned": [
  null,
  "Не удалось отключить демон tuned"
 ],
 "Failed to disable tuned profile": [
  null,
  "Не удалось отключить профиль демона tuned"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Не удалось включить $0 в firewalld"
 ],
 "Failed to enable tuned": [
  null,
  "Не удалось включить демон tuned"
 ],
 "Failed to fetch logs": [
  null,
  "Не удалось получить журналы"
 ],
 "Failed to load unit": [
  null,
  "Не удалось загрузить модуль"
 ],
 "Failed to save changes in /etc/motd": [
  null,
  "Не удалось сохранить изменения в /etc/motd"
 ],
 "Failed to start": [
  null,
  "Сбой запуска"
 ],
 "Failed to switch profile": [
  null,
  "Не удалось переключить профиль"
 ],
 "File state": [
  null,
  "Состояние файла"
 ],
 "Filter by name or description": [
  null,
  "Фильтровать по имени или описанию"
 ],
 "Filters": [
  null,
  "Фильтры"
 ],
 "Font size": [
  null,
  "Размер шрифта"
 ],
 "Forbidden from running": [
  null,
  "Выполнение запрещено"
 ],
 "Free-form search": [
  null,
  "Произвольный поиск"
 ],
 "Fridays": [
  null,
  "По пятницам"
 ],
 "Generated": [
  null,
  "Сгенерирован"
 ],
 "Go to $0": [
  null,
  "Перейти к $0"
 ],
 "Go to now": [
  null,
  "Текущий момент"
 ],
 "Handheld": [
  null,
  "Наладонный компьютер"
 ],
 "Hardware information": [
  null,
  "Сведения об оборудовании"
 ],
 "Health": [
  null,
  "Здоровье"
 ],
 "Help": [
  null,
  "Помощь"
 ],
 "Hide confirmation password": [
  null,
  "Скрыть подтверждение пароля"
 ],
 "Hide password": [
  null,
  "Скрыть пароль"
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  "Увеличение возможностей взаимодействия за счёт увеличения количества направлений атак."
 ],
 "Host key is incorrect": [
  null,
  "Неверный ключ узла"
 ],
 "Hostname": [
  null,
  "Имя узла"
 ],
 "Hourly": [
  null,
  "Ежечасно"
 ],
 "Hours": [
  null,
  "ч"
 ],
 "ID": [
  null,
  "Идентификатор"
 ],
 "Identifier": [
  null,
  "Идентификатор"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Если отпечаток совпадает, нажмите «Доверять и добавить хост». В противном случае не подключайтесь и свяжитесь с вашим администратором."
 ],
 "Increase by one": [
  null,
  "Увеличить на один"
 ],
 "Indirect": [
  null,
  "Indirect"
 ],
 "Info and above": [
  null,
  "Информационные сообщения и выше"
 ],
 "Insights: ": [
  null,
  "Анализ: "
 ],
 "Install": [
  null,
  "Установить"
 ],
 "Install realmd support": [
  null,
  "Установить поддержку realmd"
 ],
 "Install software": [
  null,
  "Установка программного обеспечения"
 ],
 "Installing $0": [
  null,
  "Установка $0"
 ],
 "Internal error": [
  null,
  "Внутренняя ошибка"
 ],
 "Invalid": [
  null,
  "Недопустимый"
 ],
 "Invalid date format": [
  null,
  "Недопустимый формат даты"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Недопустимый формат даты и недопустимый формат времени"
 ],
 "Invalid file permissions": [
  null,
  "Недопустимые разрешения для файлов"
 ],
 "Invalid time format": [
  null,
  "Недопустимый формат времени"
 ],
 "Invalid timezone": [
  null,
  "Недопустимый часовой пояс"
 ],
 "IoT gateway": [
  null,
  "Шлюз Интернета вещей"
 ],
 "Join": [
  null,
  "Присоединиться"
 ],
 "Join domain": [
  null,
  "Присоединиться к домену"
 ],
 "Joining": [
  null,
  "Присоединение"
 ],
 "Joining a domain requires installation of realmd": [
  null,
  "Присоединение к этому домену требует установки realmd"
 ],
 "Joining this domain is not supported": [
  null,
  "Присоединение к этому домену не поддерживается"
 ],
 "Joins namespace of": [
  null,
  "JoinsNamespaceOf="
 ],
 "Journal": [
  null,
  "Журнал"
 ],
 "Journal entry": [
  null,
  "Запись в журнале"
 ],
 "Journal entry not found": [
  null,
  "Запись в журнале не найдена"
 ],
 "Kernel dump": [
  null,
  "Дамп ядра"
 ],
 "Key password": [
  null,
  "Пароль ключа"
 ],
 "LEGACY with Active Directory interoperability.": [
  null,
  "LEGACY с возможностью взаимодействия с Active Directory."
 ],
 "Laptop": [
  null,
  "Полноразмерный ноутбук"
 ],
 "Last 24 hours": [
  null,
  "Последние 24 часа"
 ],
 "Last 7 days": [
  null,
  "Последние 7 дней"
 ],
 "Last successful login:": [
  null,
  "Последний удачный вход:"
 ],
 "Learn more": [
  null,
  "Подробнее"
 ],
 "Leave $0": [
  null,
  "Выйти из $0"
 ],
 "Leave domain": [
  null,
  "Выйти из домена"
 ],
 "Light": [
  null,
  "Светлый"
 ],
 "Linked": [
  null,
  "Linked"
 ],
 "Listen": [
  null,
  "Прослушивать"
 ],
 "Listing units": [
  null,
  "Вывод списка юнитов"
 ],
 "Listing units failed: $0": [
  null,
  "Не удалось вывести список юнитов: $0"
 ],
 "Load earlier entries": [
  null,
  "Загрузить более ранние записи"
 ],
 "Loading keys...": [
  null,
  "Загрузка ключей…"
 ],
 "Loading of SSH keys failed": [
  null,
  "Не удалось загрузить SSH-ключи"
 ],
 "Loading of units failed": [
  null,
  "Не удалось загрузить юниты"
 ],
 "Loading system modifications...": [
  null,
  "Загрузка изменений системы…"
 ],
 "Loading unit failed": [
  null,
  "Не удалось загрузить модуль"
 ],
 "Loading...": [
  null,
  "Загрузка…"
 ],
 "Log in": [
  null,
  "Войти"
 ],
 "Log in to $0": [
  null,
  "Вход на $0"
 ],
 "Log messages": [
  null,
  "Сообщения журнала"
 ],
 "Login failed": [
  null,
  "Ошибка входа"
 ],
 "Login format": [
  null,
  "Формат учётной записи"
 ],
 "Logs": [
  null,
  "Журналы"
 ],
 "Low profile desktop": [
  null,
  "Низкопрофильный настольный компьютер"
 ],
 "Lunch box": [
  null,
  "Портативный компьютер в ударопрочном корпусе"
 ],
 "Machine ID": [
  null,
  "Идентификатор системы"
 ],
 "Machine SSH key fingerprints": [
  null,
  "Отпечатки SSH-ключей компьютера"
 ],
 "Main server chassis": [
  null,
  "Главный серверный корпус"
 ],
 "Maintenance": [
  null,
  "Обслуживание"
 ],
 "Manage storage": [
  null,
  "Управление хранилищем"
 ],
 "Manually": [
  null,
  "Вручную"
 ],
 "Mask service": [
  null,
  "Скрыть службу"
 ],
 "Masked": [
  null,
  "Скрыто"
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  "Маскирование службы делает невозможным выполнение всех связанных с ней служб. Эффект может оказаться серьёзнее, чем кажется. Подтвердите маскирование данной службы."
 ],
 "Memory": [
  null,
  "Память"
 ],
 "Memory technology": [
  null,
  "Технология памяти"
 ],
 "Merged": [
  null,
  "Объединённый"
 ],
 "Message to logged in users": [
  null,
  "Сообщение для вошедших пользователей"
 ],
 "Mini PC": [
  null,
  "Мини-ПК"
 ],
 "Mini tower": [
  null,
  "Компьютер в корпусе «мини-башня»"
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "Количество минут должно лежать в интервале от 0 до 59"
 ],
 "Minutely": [
  null,
  "Ежеминутно"
 ],
 "Minutes": [
  null,
  "мин"
 ],
 "Mitigations": [
  null,
  "Меры по защите"
 ],
 "Model": [
  null,
  "Модель"
 ],
 "Mondays": [
  null,
  "По понедельникам"
 ],
 "Monthly": [
  null,
  "Ежемесячно"
 ],
 "Multi-system chassis": [
  null,
  "Корпус для нескольких систем"
 ],
 "NTP server": [
  null,
  "Сервер NTP"
 ],
 "Name": [
  null,
  "Имя"
 ],
 "Need at least one NTP server": [
  null,
  "Требуется по крайней мере один сервер NTP"
 ],
 "Networking": [
  null,
  "Сеть"
 ],
 "New password was not accepted": [
  null,
  "Новый пароль не был принят"
 ],
 "No delay": [
  null,
  "Без задержки"
 ],
 "No host keys found.": [
  null,
  "Ключи узла не найдены."
 ],
 "No log entries": [
  null,
  "Нет записей в журнале"
 ],
 "No logs found": [
  null,
  "Журналов не найдено"
 ],
 "No matching results": [
  null,
  "Соответствующие результаты не найдены"
 ],
 "No results found": [
  null,
  "Нет результатов"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  "Совпадения с критериями фильтров отсутствуют. Сбросьте все фильтры для вывода результатов."
 ],
 "No rule hits": [
  null,
  "Нет совпадений с правилами"
 ],
 "No such file or directory": [
  null,
  "Нет такого файла или каталога"
 ],
 "No system modifications": [
  null,
  "Изменения системы отсутствуют"
 ],
 "None": [
  null,
  "Нет"
 ],
 "Not a valid private key": [
  null,
  "Недопустимый закрытый ключ"
 ],
 "Not connected to Insights": [
  null,
  "Нет подключения к Insights"
 ],
 "Not found": [
  null,
  "Не найдено"
 ],
 "Not permitted to configure realms": [
  null,
  "Запрещено настраивать области"
 ],
 "Not permitted to perform this action.": [
  null,
  "Нет прав на выполнение этого действия."
 ],
 "Not running": [
  null,
  "Не работает"
 ],
 "Not synchronized": [
  null,
  "Не синхронизировано"
 ],
 "Note": [
  null,
  "Примечание"
 ],
 "Notebook": [
  null,
  "Ноутбук"
 ],
 "Notice and above": [
  null,
  "Уведомления и выше"
 ],
 "Occurrences": [
  null,
  "События"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Old password not accepted": [
  null,
  "Старый пароль не был принят"
 ],
 "On failure": [
  null,
  "OnFailure="
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "После установки Cockpit включите его при помощи команды «systemctl enable --now cockpit.socket»."
 ],
 "Only alphabets, numbers, : , _ , . , @ , - are allowed": [
  null,
  "Допускаются только буквы, цифры и символы «:», «_», «.», «@» и «-»"
 ],
 "Only emergency": [
  null,
  "Только экстренные оповещения"
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  "При загрузке в режиме FIPS можно использовать только утверждённые и разрешённые алгоритмы."
 ],
 "Other": [
  null,
  "Прочее"
 ],
 "Overview": [
  null,
  "Обзор"
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "PackageKit crashed": [
  null,
  "Сбой PackageKit"
 ],
 "Part of": [
  null,
  "Часть"
 ],
 "Password": [
  null,
  "Пароль"
 ],
 "Password is not acceptable": [
  null,
  "Недопустимый пароль"
 ],
 "Password is too weak": [
  null,
  "Пароль недостаточно надёжен"
 ],
 "Password not accepted": [
  null,
  "Пароль не принят"
 ],
 "Paste": [
  null,
  "Вставить"
 ],
 "Paste error": [
  null,
  "Ошибка вставки"
 ],
 "Path": [
  null,
  "Путь"
 ],
 "Path to file": [
  null,
  "Путь к файлу"
 ],
 "Paths": [
  null,
  "Пути"
 ],
 "Pause": [
  null,
  "Приостановить"
 ],
 "Performance profile": [
  null,
  "Профиль производительности"
 ],
 "Peripheral chassis": [
  null,
  "Корпус для периферийных устройств"
 ],
 "Pick date": [
  null,
  "Выбор даты"
 ],
 "Pin unit": [
  null,
  "Закрепить юнит"
 ],
 "Pinned unit": [
  null,
  "Закреплённый юнит"
 ],
 "Pizza box": [
  null,
  "Ультратонкий корпус"
 ],
 "Portable": [
  null,
  "Портативный компьютер"
 ],
 "Present": [
  null,
  "Присутствует"
 ],
 "Pretty host name": [
  null,
  "Автоматическое имя узла"
 ],
 "Previous boot": [
  null,
  "Предыдущая загрузка"
 ],
 "Priority": [
  null,
  "Приоритет"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Превышено время ожидания запроса по ssh-add"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Превышено время ожидания запроса по ssh-keygen"
 ],
 "Propagates reload to": [
  null,
  "PropagatesReloadTo="
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  "Обеспечивает защиту от атак, предполагаемых в ближайшей перспективе, за счёт уменьшения возможностей взаимодействия."
 ],
 "RAID chassis": [
  null,
  "Корпус для RAID-массива"
 ],
 "Rack mount chassis": [
  null,
  "Монтируемый в стойку корпус"
 ],
 "Rank": [
  null,
  "Ранг"
 ],
 "Read more...": [
  null,
  "Подробнее…"
 ],
 "Read-only": [
  null,
  "Только для чтения"
 ],
 "Real host name": [
  null,
  "Реальное имя узла"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "Реальное имя узла может содержать только строчные буквы, цифры, тире и точки (с заполненными поддоменами)"
 ],
 "Real host name must be 64 characters or less": [
  null,
  "Реальное имя узла должно содержать не более 64 символов"
 ],
 "Reapply and reboot": [
  null,
  "Повторно применить и перезагрузить"
 ],
 "Reboot": [
  null,
  "Перезагрузка"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  "Рекомендуется, безопасные настройки для существующих сейчас моделей угроз."
 ],
 "Reload": [
  null,
  "Перезагрузить"
 ],
 "Reload propagated from": [
  null,
  "ReloadPropagatedFrom="
 ],
 "Reloading": [
  null,
  "Перезагрузка"
 ],
 "Removals:": [
  null,
  "Для удаления:"
 ],
 "Remove": [
  null,
  "Удалить"
 ],
 "Removing $0": [
  null,
  "Удаление $0"
 ],
 "Repeat": [
  null,
  "Повторять"
 ],
 "Repeat monthly": [
  null,
  "Повторять ежемесячно"
 ],
 "Repeat weekly": [
  null,
  "Повторять еженедельно"
 ],
 "Required by": [
  null,
  "RequiredBy="
 ],
 "Required by ": [
  null,
  "Требуется для "
 ],
 "Requires": [
  null,
  "Requires="
 ],
 "Requires administration access to edit": [
  null,
  "Для изменения необходимы права администратора"
 ],
 "Requisite": [
  null,
  "Requisite="
 ],
 "Requisite of": [
  null,
  "RequisiteOf="
 ],
 "Reset": [
  null,
  "Сброс"
 ],
 "Restart": [
  null,
  "Перезапустить"
 ],
 "Resume": [
  null,
  "Возобновить"
 ],
 "Review cryptographic policy": [
  null,
  "Пересмотреть правила шифрования"
 ],
 "Row expansion": [
  null,
  "Расширение строки"
 ],
 "Row select": [
  null,
  "Выбор строки"
 ],
 "Run at": [
  null,
  "Запускать в"
 ],
 "Run on": [
  null,
  "Запускать по"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Запустите эту команду через доверенную сеть или физически на удалённом компьютере:"
 ],
 "Running": [
  null,
  "Работает"
 ],
 "Running process prevents directory change": [
  null,
  ""
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "SSH-ключ"
 ],
 "Saturdays": [
  null,
  "По субботам"
 ],
 "Save": [
  null,
  "Сохранить"
 ],
 "Save and reboot": [
  null,
  "Сохранить и перезагрузить"
 ],
 "Save changes": [
  null,
  "Сохранить изменения"
 ],
 "Scheduled poweroff at $0": [
  null,
  "Запланировано отключение в $0"
 ],
 "Scheduled reboot at $0": [
  null,
  "Запланирована перезагрузка в $0"
 ],
 "Sealed-case PC": [
  null,
  "Компьютер с невскрываемым корпусом"
 ],
 "Search": [
  null,
  "Поиск"
 ],
 "Second needs to be a number between 0-59": [
  null,
  "Количество секунд должно быть в интервале от 0 до 59"
 ],
 "Seconds": [
  null,
  "сек"
 ],
 "Secure shell keys": [
  null,
  "Ключи Secure Shell"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Настройка и устранение неисправностей в Linux с улучшенной системой безопасности"
 ],
 "Server has closed the connection.": [
  null,
  "Сервер закрыл соединение."
 ],
 "Server software": [
  null,
  "Серверное программное обеспечение"
 ],
 "Service logs": [
  null,
  "Журналы службы"
 ],
 "Services": [
  null,
  "Службы"
 ],
 "Set hostname": [
  null,
  "Установить название узла"
 ],
 "Set time": [
  null,
  "Настроить время"
 ],
 "Shell script": [
  null,
  "Сценарий оболочки"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show confirmation password": [
  null,
  "Показать подтверждение пароля"
 ],
 "Show fingerprints": [
  null,
  "Показать отпечатки"
 ],
 "Show messages containing given string.": [
  null,
  "Показать сообщения, содержащие данную строку."
 ],
 "Show messages for the specified systemd unit.": [
  null,
  "Показать сообщения для указанного юнита systemd."
 ],
 "Show messages from a specific boot.": [
  null,
  "Показать сообщения для указанной загрузки."
 ],
 "Show more relationships": [
  null,
  "Показать больше связей"
 ],
 "Show password": [
  null,
  "Показать пароль"
 ],
 "Show relationships": [
  null,
  "Показать связи"
 ],
 "Shut down": [
  null,
  "Завершение работы"
 ],
 "Shutdown": [
  null,
  "Выключить"
 ],
 "Since": [
  null,
  "C"
 ],
 "Single rank": [
  null,
  "Одноранговая"
 ],
 "Size": [
  null,
  "Размер"
 ],
 "Slot": [
  null,
  "Слот"
 ],
 "Sockets": [
  null,
  "Сокеты"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  "Программные обходные решения помогают предотвратить проблемы безопасности ЦП. Побочным эффектом этих мер является снижение производительности. Вы изменяете эти параметры на свой страх и риск."
 ],
 "Space-saving computer": [
  null,
  "Компактный компьютер"
 ],
 "Specific time": [
  null,
  "Определённое время"
 ],
 "Speed": [
  null,
  "Скорость"
 ],
 "Start": [
  null,
  "Запустить"
 ],
 "Start and enable": [
  null,
  "Включить и запустить"
 ],
 "Start service": [
  null,
  "Запустить службу"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  "Показывать записи, начиная с указанной даты и более поздних."
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  "Показывать записи, начиная с указанной даты и более ранних."
 ],
 "State": [
  null,
  "Состояние"
 ],
 "Static": [
  null,
  "Статически"
 ],
 "Status": [
  null,
  "Состояние"
 ],
 "Stick PC": [
  null,
  "ПК-брелок"
 ],
 "Stop": [
  null,
  "Остановить"
 ],
 "Stop and disable": [
  null,
  "Остановить и отключить"
 ],
 "Storage": [
  null,
  "Хранилище"
 ],
 "Strong password": [
  null,
  "Надёжный пароль"
 ],
 "Stub": [
  null,
  "Заглушка"
 ],
 "Sub-Chassis": [
  null,
  "Дополнительный корпус"
 ],
 "Sub-Notebook": [
  null,
  "Субноутбук"
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  "Сбой подписки на сигналы systemd: $0"
 ],
 "Successfully copied to clipboard": [
  null,
  "Успешно скопировано в буфер обмена"
 ],
 "Sundays": [
  null,
  "По воскресеньям"
 ],
 "Synchronized": [
  null,
  "Синхронизировано"
 ],
 "Synchronized with $0": [
  null,
  "Синхронизировано с $0"
 ],
 "Synchronizing": [
  null,
  "Синхронизация"
 ],
 "System": [
  null,
  "Система"
 ],
 "System information": [
  null,
  "Сведения о системе"
 ],
 "System time": [
  null,
  "Системное время"
 ],
 "Systemd units": [
  null,
  "Юниты systemd"
 ],
 "Tablet": [
  null,
  "Планшетный ПК"
 ],
 "Targets": [
  null,
  "Цели"
 ],
 "Terminal": [
  null,
  "Терминал"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "SSH-ключ $0 для $1 на $2 будет добавлен к файлу $3 для $4 на $5."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH-ключ $0 будет предоставлен на оставшееся время сеанса, а также будет доступен для входа на другие узлы."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "SSH-ключ для входа на $0 защищён паролем, а вход с паролем на узле запрещён. Введите пароль для ключа на $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "SSH-ключ для входа на $0 защищён. Вход возможен либо при указании пароля для входа, либо пароля ключа на $1."
 ],
 "The fingerprint should match:": [
  null,
  "Отпечаток должен соответствовать:"
 ],
 "The key password can not be empty": [
  null,
  "Пароль ключа не может быть пустым"
 ],
 "The key passwords do not match": [
  null,
  "Пароли ключа не совпадают"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Текущему пользователю запрещено просматривать изменения системы"
 ],
 "The password can not be empty": [
  null,
  "Пароль не может быть пустым"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Полученный отпечаток можно распространять по общедоступным каналам связи, включая электронную почту."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Полученный отпечаток пальца можно передавать общедоступными способами, включая электронную почту. Если вы просите кого-то другого выполнить проверку за вас, они могут отправить результаты любым способом."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Сервер отклонил проверку подлинности с использованием любых поддерживаемых методов."
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  "Пользователю $0 не разрешено изменять параметры, влияющие на безопасность ЦП"
 ],
 "The user $0 is not permitted to change cryptographic policies": [
  null,
  "Пользователю $0 запрещено изменять правила шифрования"
 ],
 "This field cannot be empty": [
  null,
  "Это поле не может быть пустым"
 ],
 "This may take a while": [
  null,
  "Это может занять некоторое время"
 ],
 "This system is using a custom profile": [
  null,
  "Эта система использует настраиваемый профиль"
 ],
 "This system is using the recommended profile": [
  null,
  "Эта система использует рекомендуемый профиль"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Этот инструмент настраивает правила SELinux и может помочь в понимании и устранении нарушений правил."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Этот инструмент создаёт архив данных по настройкам и диагностике для запущенной системы. Архив может быть сохранён локально или централизованно с целью журналирования или слежения или отправлен представителям технической поддержки, разработчикам или администраторам системы, чтобы помочь с поиском технических проблем и диагностикой."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Этот инструмент управляет локальными хранилищами, такими как файловые системы, группы томов LVM2, и монтированиями NFS."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Этот инструмент управляет возможностями работы в сети, в частности связями, мостами, командами, виртуальными LAN и брандмауэрами, с помощью NetworkManager и Firewalld. NetworkManager несовместим с типичным для Ubuntu systemd-networkd и скриптами ifupdown Debian."
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  "Эта служба не предназначена для явного включения."
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  "Здесь можно добавить строку для совпадения с параметром «_BOOT_ID=». При отсутствии строки выводятся записи журнала для текущей загрузки. Если вместо идентификатора загрузки указано положительное число, будут выведены загрузки с началаведения журнала, если же число меньше или равно нулю, вывод записей начинается с конца журнала. Например, 1 выводит первую загрузку в журнале в хронологическом порядке, 2 — вторую и так далее; при этом -0 означает последнюю загрузку, -1 предпоследнюю загрузку и так далее."
 ],
 "Thursdays": [
  null,
  "По четвергам"
 ],
 "Time": [
  null,
  "Время"
 ],
 "Time zone": [
  null,
  "Часовой пояс"
 ],
 "Timer creation failed": [
  null,
  "Не удалось создать таймер"
 ],
 "Timer deletion failed": [
  null,
  "Не удалось удалить таймер"
 ],
 "Timers": [
  null,
  "Таймеры"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Чтобы убедиться в том, что данные вашего соединения не были перехвачены злоумышленниками, проверьте отпечаток ключа данного узла:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Для проверки отпечатка запустите следующую команду на $0, физически работая на этом компьютере или по доверенной сети:"
 ],
 "Toggle date picker": [
  null,
  "Переключить средство выбора даты"
 ],
 "Toggle filters": [
  null,
  "Переключение фильтров"
 ],
 "Too much data": [
  null,
  "Слишком много данных"
 ],
 "Total size: $0": [
  null,
  "Общий размер: $0"
 ],
 "Tower": [
  null,
  "Компьютер в корпусе «башня»"
 ],
 "Transient": [
  null,
  "Transient"
 ],
 "Trigger": [
  null,
  "Триггер"
 ],
 "Triggered by": [
  null,
  "TriggeredBy="
 ],
 "Triggers": [
  null,
  "Triggers="
 ],
 "Trust and add host": [
  null,
  "Доверять и добавить хост"
 ],
 "Trying to synchronize with $0": [
  null,
  "Попытка синхронизации с $0"
 ],
 "Tuesdays": [
  null,
  "По вторникам"
 ],
 "Tuned has failed to start": [
  null,
  "Сбой при запуске демона tuned"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned — это служба, предназначенная для контроля системы и оптимизации производительности при определённых нагрузках. В основе Tuned лежат профили, позволяющие настроить систему для различных случаев использования."
 ],
 "Tuned is not available": [
  null,
  "Демон tuned недоступен"
 ],
 "Tuned is not running": [
  null,
  "Демон tuned не запущен"
 ],
 "Tuned is off": [
  null,
  "Демон tuned отключен"
 ],
 "Type": [
  null,
  "Тип"
 ],
 "Type to filter": [
  null,
  "Введите условия фильтра"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Не удалось войти на $0. Узел не принимает вход ни по паролю, ни по одному из имеющихся SSH-ключей."
 ],
 "Unit": [
  null,
  "Устройство"
 ],
 "Unknown": [
  null,
  "Неизвестно"
 ],
 "Unpin unit": [
  null,
  "Открепить юнит"
 ],
 "Until": [
  null,
  "До"
 ],
 "Untrusted host": [
  null,
  "Недоверенный узел"
 ],
 "Updating status...": [
  null,
  "Обновление состояния…"
 ],
 "Usage": [
  null,
  "Использование"
 ],
 "User": [
  null,
  "Пользователь"
 ],
 "Validating address": [
  null,
  "Проверка адреса"
 ],
 "Vendor": [
  null,
  "Производитель"
 ],
 "Verify fingerprint": [
  null,
  "Проверить отпечаток"
 ],
 "Version": [
  null,
  "Версия"
 ],
 "View all logs": [
  null,
  "Смотреть все журналы"
 ],
 "View all services": [
  null,
  "Смотреть все службы"
 ],
 "View automation script": [
  null,
  "Просмотреть сценарий автоматизации"
 ],
 "View hardware details": [
  null,
  "Просмотреть сведения об оборудовании"
 ],
 "View login history": [
  null,
  "Смотреть истории входов"
 ],
 "View metrics and history": [
  null,
  "Смотреть метрики и историю"
 ],
 "Viewing memory information requires administrative access.": [
  null,
  "Для информации о памяти необходимы права администратора."
 ],
 "Visit firewall": [
  null,
  "Перейти к межсетевому экрану"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Ожидание завершения других операций управления программным обеспечением"
 ],
 "Wanted by": [
  null,
  "WantedBy="
 ],
 "Wants": [
  null,
  "Wants="
 ],
 "Warning and above": [
  null,
  "Предупреждающие сообщения и выше"
 ],
 "Weak password": [
  null,
  "Ненадёжный пароль"
 ],
 "Web Console for Linux servers": [
  null,
  "Веб-консоль для серверов Linux"
 ],
 "Web console is running in limited access mode.": [
  null,
  "Веб-консоль работает в режиме ограниченного доступа."
 ],
 "Wednesdays": [
  null,
  "По средам"
 ],
 "Weekly": [
  null,
  "Еженедельно"
 ],
 "Weeks": [
  null,
  "нед"
 ],
 "White": [
  null,
  "Белый"
 ],
 "Yearly": [
  null,
  "Ежегодно"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Подключение к $0 выполняется в первый раз."
 ],
 "You may try to load older entries.": [
  null,
  "Вы можете попробовать загрузить более старые записи."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "В данном браузере отсутствует возможность вставки с помощью контекстного меню. Можно использовать комбинацию Shift+Insert."
 ],
 "Your session has been terminated.": [
  null,
  "Сеанс завершён."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Срок действия сеанса истёк. Войдите в систему снова."
 ],
 "Zone": [
  null,
  "Зона"
 ],
 "[binary data]": [
  null,
  "[двоичные данные]"
 ],
 "[no data]": [
  null,
  "[нет данных]"
 ],
 "active": [
  null,
  "активно"
 ],
 "edit": [
  null,
  "редактировать"
 ],
 "failed to list ssh host keys: $0": [
  null,
  "не удалось отобразить список SSH-ключей узла: $0"
 ],
 "in less than a minute": [
  null,
  ""
 ],
 "inconsistent": [
  null,
  "несогласованный"
 ],
 "journalctl manpage": [
  null,
  "Man-страница journalctl"
 ],
 "less than a minute ago": [
  null,
  ""
 ],
 "none": [
  null,
  "нет"
 ],
 "of $0 CPU": [
  null,
  "из $0 процессора",
  "из $0 процессоров",
  "из $0 процессоров"
 ],
 "password quality": [
  null,
  "качество пароля"
 ],
 "recommended": [
  null,
  "рекомендуется"
 ],
 "running $0": [
  null,
  "выполняется $0"
 ],
 "show less": [
  null,
  "показать меньше"
 ],
 "show more": [
  null,
  "показать больше"
 ],
 "unknown": [
  null,
  "неизвестно"
 ],
 "dialog-title\u0004Domain": [
  null,
  "Домен"
 ],
 "dialog-title\u0004Join a domain": [
  null,
  "Присоединение к домену"
 ],
 "from <host>\u0004from $0": [
  null,
  "c $0"
 ],
 "from <host> on <terminal>\u0004from $0 on $1": [
  null,
  "с $0 на $1"
 ],
 "on <terminal>\u0004on $0": [
  null,
  "на $1"
 ]
});
