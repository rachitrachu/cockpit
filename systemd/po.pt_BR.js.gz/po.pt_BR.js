cockpit.locale({
 "": {
  "plural-forms": (n) => (n != 1),
  "language": "pt_BR",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 critical hit": [
  null,
  "$0 ocorrência crítica",
  "$0 ocorrências, incluindo críticas"
 ],
 "$0 day": [
  null,
  "$0 dia",
  "$0 dias"
 ],
 "$0 disk is failing": [
  null,
  "$0 disco está falhando",
  "$0 discos estão falhando"
 ],
 "$0 does not exist": [
  null,
  "$0 não existe"
 ],
 "$0 exited with code $1": [
  null,
  "$0 foi encerrado com o código $1"
 ],
 "$0 failed": [
  null,
  "$0 falhou"
 ],
 "$0 failed login attempt": [
  null,
  "$0 tentativa de login falhou",
  "$0 tentativas de login falharam"
 ],
 "$0 filters applied": [
  null,
  "$0 filtros aplicados"
 ],
 "$0 hour": [
  null,
  "$0 hora",
  "$0 horas"
 ],
 "$0 important hit": [
  null,
  "$0 ocorrência importante",
  "$0 ocorrências, incluindo importantes"
 ],
 "$0 is not a directory": [
  null,
  "$0 não é um diretório"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 não está disponível em nenhum repositório."
 ],
 "$0 key changed": [
  null,
  "$0 chave alterada"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 morto com sinal $1"
 ],
 "$0 low severity hit": [
  null,
  "$0 ocorrência de baixa gravidade",
  "$0 ocorrências de baixas gravidades"
 ],
 "$0 minute": [
  null,
  "$0 minuto",
  "$0 minutos"
 ],
 "$0 moderate hit": [
  null,
  "$0 ocorrência moderada",
  "$0 ocorrências, incluindo moderadas"
 ],
 "$0 month": [
  null,
  "$0 mês",
  "$0 meses"
 ],
 "$0 service has failed": [
  null,
  "$0 serviço falhou",
  "$0 serviços falharam"
 ],
 "$0 week": [
  null,
  "$0 semana",
  "$0 semanas"
 ],
 "$0 will be installed.": [
  null,
  "$0 será instalado."
 ],
 "$0 year": [
  null,
  "$0 ano",
  "$0 anos"
 ],
 "1 day": [
  null,
  "1 dia"
 ],
 "1 hour": [
  null,
  "1 hora"
 ],
 "1 minute": [
  null,
  "1 minuto"
 ],
 "1 week": [
  null,
  "1 semana"
 ],
 "10th": [
  null,
  "10º"
 ],
 "11th": [
  null,
  "11º"
 ],
 "12th": [
  null,
  "12º"
 ],
 "13th": [
  null,
  "13º"
 ],
 "14th": [
  null,
  "14º"
 ],
 "15th": [
  null,
  "15º"
 ],
 "16th": [
  null,
  "16º"
 ],
 "17th": [
  null,
  "17º"
 ],
 "18th": [
  null,
  "18º"
 ],
 "19th": [
  null,
  "19º"
 ],
 "1st": [
  null,
  "1º"
 ],
 "20 minutes": [
  null,
  "20 minutos"
 ],
 "20th": [
  null,
  "20º"
 ],
 "21th": [
  null,
  "21º"
 ],
 "22th": [
  null,
  "22º"
 ],
 "23th": [
  null,
  "23º"
 ],
 "24th": [
  null,
  "24º"
 ],
 "25th": [
  null,
  "25º"
 ],
 "26th": [
  null,
  "26º"
 ],
 "27th": [
  null,
  "27º"
 ],
 "28th": [
  null,
  "28º"
 ],
 "29th": [
  null,
  "29º"
 ],
 "2nd": [
  null,
  "2º"
 ],
 "30th": [
  null,
  "30º"
 ],
 "31st": [
  null,
  "31º"
 ],
 "3rd": [
  null,
  "3º"
 ],
 "40 minutes": [
  null,
  "40 minutos"
 ],
 "4th": [
  null,
  "4º"
 ],
 "5 minutes": [
  null,
  "5 minutos"
 ],
 "5th": [
  null,
  "5º"
 ],
 "6 hours": [
  null,
  "6 horas"
 ],
 "60 minutes": [
  null,
  "60 minutos"
 ],
 "6th": [
  null,
  "6º"
 ],
 "7th": [
  null,
  "7º"
 ],
 "8th": [
  null,
  "8º"
 ],
 "9th": [
  null,
  "9º"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Uma versão compatível do Cockpit não está instalada em $0."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Uma nova chave SSH em $0 será criada por $1 em $2 e será adicionada ao arquivo $3 de $4 em $5."
 ],
 "Absent": [
  null,
  "Ausente"
 ],
 "Acceptable password": [
  null,
  "Senha aceitável"
 ],
 "Active since ": [
  null,
  "Ativo desde "
 ],
 "Active state": [
  null,
  "Estado ativo"
 ],
 "Add": [
  null,
  "Adicionar"
 ],
 "Add $0": [
  null,
  "Adicionar $0"
 ],
 "Additional actions": [
  null,
  "Ações adicionais"
 ],
 "Additional packages:": [
  null,
  "Pacotes adicionais:"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Administração com o Console Web do Cockpit"
 ],
 "Advanced TCA": [
  null,
  "TCA avançado"
 ],
 "After": [
  null,
  "Após"
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "Após sair do domínio, apenas os usuários com credenciais locais poderão fazer login nesta máquina. Isso também pode afetar outros serviços, como as configurações de resolução DNS e a lista de autoridades de certificação confiáveis."
 ],
 "After system boot": [
  null,
  "Após a inicialização do sistema"
 ],
 "Alert and above": [
  null,
  "Alerta e acima"
 ],
 "Alias": [
  null,
  "Apelido"
 ],
 "All": [
  null,
  "Todos"
 ],
 "All-in-one": [
  null,
  "All-in-one"
 ],
 "Allow running (unmask)": [
  null,
  "Permitir a execução (desmascarar)"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Documentação de papéis do Ansible"
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  "Qualquer sequência de texto nas mensagens de log pode ser filtrada. A sequência também pode estar na forma de uma expressão regular. Também suporta filtragem por campos de registro de mensagem. Esses valores são separados por espaços, no formato CAMPO=VALOR, onde o valor pode ser uma lista separada por vírgulas de valores possíveis."
 ],
 "Appearance": [
  null,
  "Aparência"
 ],
 "Apply and reboot": [
  null,
  "Aplicar e reiniciar"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  "Aplicando a nova política... Isso pode levar alguns minutos."
 ],
 "Asset tag": [
  null,
  "Etiqueta de ativo"
 ],
 "At minute": [
  null,
  "A cada minuto"
 ],
 "At second": [
  null,
  "A cada segundo"
 ],
 "At specific time": [
  null,
  "Em tempo específico"
 ],
 "Authentication": [
  null,
  "Autenticação"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Autenticação é necessária para executar ações privilegiadas no Console Web do Cockpit"
 ],
 "Authorize SSH key": [
  null,
  "Autorizar chave SSH"
 ],
 "Automatically starts": [
  null,
  "Inicia automaticamente"
 ],
 "Automatically using NTP": [
  null,
  "Usando automaticamente o NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Usando automaticamente servidores NTP adicionais"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Usando automaticamente servidores NTP específicos"
 ],
 "Automation script": [
  null,
  "Script de automação"
 ],
 "BIOS": [
  null,
  "BIOS"
 ],
 "BIOS date": [
  null,
  "BIOS data"
 ],
 "BIOS version": [
  null,
  "BIOS versão"
 ],
 "Bad": [
  null,
  "Ruim"
 ],
 "Bad setting": [
  null,
  "Má configuração"
 ],
 "Before": [
  null,
  "Antes"
 ],
 "Binds to": [
  null,
  "Vincula a"
 ],
 "Black": [
  null,
  "Preto"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Invólucro da lâmina"
 ],
 "Boot": [
  null,
  "Inicialização"
 ],
 "Bound by": [
  null,
  "Vinculado pela"
 ],
 "Bus expansion chassis": [
  null,
  "Chassi de Expansão de Barramento"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "CPU security": [
  null,
  "Segurança da CPU"
 ],
 "CPU security toggles": [
  null,
  "Interruptores de segurança da CPU"
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "Não é possível encontrar nenhum registro usando a combinação atual de filtros."
 ],
 "Cancel": [
  null,
  "Cancelar"
 ],
 "Cancel poweroff": [
  null,
  "Cancelar desligamento"
 ],
 "Cancel reboot": [
  null,
  "Cancelar reinicialização"
 ],
 "Cannot be enabled": [
  null,
  "Não pode ser habilitado"
 ],
 "Cannot forward login credentials": [
  null,
  "Não é possível prosseguir com as credenciais de login"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  "Não é possível ingressar em um domínio porque realmd não está disponível neste sistema"
 ],
 "Cannot schedule event in the past": [
  null,
  "Não é possível agendar eventos no passado"
 ],
 "Change": [
  null,
  "Alterar"
 ],
 "Change cryptographic policy": [
  null,
  "Modifique a política criptográfica"
 ],
 "Change directory": [
  null,
  "Mudar diretório"
 ],
 "Change host name": [
  null,
  "Alterar o Nome do Host"
 ],
 "Change performance profile": [
  null,
  "Perfil alterar o desempenho"
 ],
 "Change profile": [
  null,
  "Alterar o perfil"
 ],
 "Change system time": [
  null,
  "Alterar Horário do Sistema"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "As chaves alteradas frequentemente são resultado de uma reinstalação do sistema operacional. No entanto, uma alteração inesperada pode indicar uma tentativa de terceiros de interceptar sua conexão."
 ],
 "Changing the directory will forcefully stop the currently running process. The process can also be stopped manually in the terminal before continuing.": [
  null,
  "Alterar o diretório interromperá à força o processo em execução no momento. O processo também pode ser interrompido manualmente no terminal antes de continuar."
 ],
 "Checking installed software": [
  null,
  "Verificando o software instalado"
 ],
 "Class": [
  null,
  "Classe"
 ],
 "Clear 'Failed to start'": [
  null,
  "Limpar 'Falha ao iniciar'"
 ],
 "Clear all filters": [
  null,
  "Limpar todos os filtros"
 ],
 "Clear input value": [
  null,
  "Limpar valor inserido"
 ],
 "Client software": [
  null,
  "Software do cliente"
 ],
 "Close": [
  null,
  "Fechar"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Configuração do cockpit do NetworkManager e Firewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "O Cockpit não poderia entrar em contato com o host fornecido."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit é um gerenciador de Servidores que facilita a tarefa de administrar seu servidor Linux via navegador web. Alternar entre o terminal e a ferramenta web, não é dif[icil. Um serviço pode ser iniciado pelo Cockpit e finalizado pelo Terminal. Da mesma forma, se um erro ocorrer no terminal, este pode ser detectado via interface do Cockpit."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "O Cockpit não é compatível com o software no sistema."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit não está instalado"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit não está instalado no sistema."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit é perfeito para novos administradores de sistemas, permitindo-lhes facilmente realizar tarefas simples, como a administração de armazenamento, inspecionando logs e iniciar/parar serviços. É possível monitorar e administrar vários servidores ao mesmo tempo. Basta adicioná-los com um único clique e suas máquinas vão cuidar de seus companheiros."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Coletar e empacotar dados de diagnóstico e suporte"
 ],
 "Collect kernel crash dumps": [
  null,
  "Coletar despejos de travamento de kernel"
 ],
 "Command": [
  null,
  "Comando"
 ],
 "Command not found": [
  null,
  "Comando não encontrado"
 ],
 "Communication with tuned has failed": [
  null,
  "A comunicação com sintonizado falhou"
 ],
 "Compact PCI": [
  null,
  "Compacto PCI"
 ],
 "Condition $0=$1 was not met": [
  null,
  "Condição $0=$1 não foi cumprida"
 ],
 "Condition failed": [
  null,
  "Condição falhou"
 ],
 "Configuration": [
  null,
  "Configuração"
 ],
 "Confirm deletion of $0": [
  null,
  "Confirmar a exclusão de $0"
 ],
 "Confirm key password": [
  null,
  "Confirme a senha da chave"
 ],
 "Conflicted by": [
  null,
  "Conflito por"
 ],
 "Conflicts": [
  null,
  "Conflita"
 ],
 "Connecting to dbus failed: $0": [
  null,
  "Falha na conexão com dbus: $0"
 ],
 "Connection has timed out.": [
  null,
  "A conexão expirou."
 ],
 "Consists of": [
  null,
  "Consiste em"
 ],
 "Contacted domain": [
  null,
  "Domínio contatado"
 ],
 "Container": [
  null,
  "Contêiner"
 ],
 "Convertible": [
  null,
  "Conversível"
 ],
 "Copied": [
  null,
  "Copiado"
 ],
 "Copy": [
  null,
  "Copiar"
 ],
 "Copy to clipboard": [
  null,
  "Copiar para área de transferência"
 ],
 "Create $0": [
  null,
  "Criar $0"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Criar uma nova chave SSH e autorizá-la"
 ],
 "Create new task file with this content.": [
  null,
  "Crie um novo arquivo de tarefa com esse conteúdo."
 ],
 "Create timer": [
  null,
  "Criar Temporizador"
 ],
 "Critical and above": [
  null,
  "Crítico e acima"
 ],
 "Cryptographic Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  "Políticas criptográficas é um componente do sistema que configura os principais subsistemas criptográficos, abrangendo os protocolos TLS, IPSec, SSH, DNSSec e Kerberos."
 ],
 "Cryptographic policy": [
  null,
  "Política de criptografia"
 ],
 "Cryptographic policy is inconsistent": [
  null,
  "A política de criptografia está inconsistente"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Current boot": [
  null,
  "Inicialização atual"
 ],
 "Custom cryptographic policy": [
  null,
  "Política de criptografia customizada"
 ],
 "DEFAULT with SHA-1 signature verification allowed.": [
  null,
  "DEFAULT com verificação de assinatura SHA-1 permitida."
 ],
 "Daily": [
  null,
  "Diariamente"
 ],
 "Dark": [
  null,
  "Escuro"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  "As especificações de data devem estar no formato AAAA-MM-DD hh:mm:ss. Alternativamente, as strings 'yesterday', 'today', 'tomorrow' são compreendidas. 'now' se refere ao tempo atual. Finalmente, tempos relativos podem ser especificados, prefixados com '-' ou '+'"
 ],
 "Debug and above": [
  null,
  "Depurar e acima"
 ],
 "Decrease by one": [
  null,
  "Diminuir em um"
 ],
 "Default": [
  null,
  "Padrão"
 ],
 "Delay": [
  null,
  "Atraso"
 ],
 "Delay must be a number": [
  null,
  "O atraso deve ser um número"
 ],
 "Delete": [
  null,
  "Excluir"
 ],
 "Deletion will remove the following files:": [
  null,
  "A exclusão vai remover os seguintes arquivos:"
 ],
 "Description": [
  null,
  "Descrição"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Detachable": [
  null,
  "Destacável"
 ],
 "Details": [
  null,
  "Detalhes"
 ],
 "Diagnostic reports": [
  null,
  "Relatório de diagnostico"
 ],
 "Disable simultaneous multithreading": [
  null,
  "Desabilitar multithreading simultâneo"
 ],
 "Disable tuned": [
  null,
  "Desabilitar tuned"
 ],
 "Disabled": [
  null,
  "Desabilitado"
 ],
 "Disallow running (mask)": [
  null,
  "Não permitir execução (máscara)"
 ],
 "Docking station": [
  null,
  "Estação de ancoragem"
 ],
 "Does not automatically start": [
  null,
  "Não inicia automaticamente"
 ],
 "Domain": [
  null,
  "Domínio"
 ],
 "Domain address": [
  null,
  "Endereço do Domínio"
 ],
 "Domain administrator name": [
  null,
  "Nome do Administrador de Domínio"
 ],
 "Domain administrator password": [
  null,
  "Senha do Administrador de Domínio"
 ],
 "Domain could not be contacted": [
  null,
  "O Domínio não pôde ser contatado"
 ],
 "Domain is not supported": [
  null,
  "O Domínio não é suportado"
 ],
 "Don't repeat": [
  null,
  "Não Repita"
 ],
 "Downloading $0": [
  null,
  "Baixando $0"
 ],
 "Dual rank": [
  null,
  "Dual rank"
 ],
 "Edit /etc/motd": [
  null,
  "Editar /etc/motd"
 ],
 "Edit motd": [
  null,
  "Editar motd"
 ],
 "Embedded PC": [
  null,
  "PC integrado"
 ],
 "Enabled": [
  null,
  "Habilitado"
 ],
 "Entry at $0": [
  null,
  "Entrada em $0"
 ],
 "Error": [
  null,
  "Erro"
 ],
 "Error and above": [
  null,
  "Erro e acima"
 ],
 "Error message": [
  null,
  "Mensagem de erro"
 ],
 "Excellent password": [
  null,
  "Senha excelente"
 ],
 "Expansion chassis": [
  null,
  "Chassi de Expansão"
 ],
 "FIPS is not properly enabled": [
  null,
  "FIPS não está habilitado corretamente"
 ],
 "FIPS with further Common Criteria restrictions.": [
  null,
  "FIPS com outras restrições de Common Criteria."
 ],
 "Failed to change password": [
  null,
  "Falha ao mudar senha"
 ],
 "Failed to disable tuned": [
  null,
  "Falha ao desabilitar tuned"
 ],
 "Failed to disable tuned profile": [
  null,
  "Falha ao desativar o perfil do tuned"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Falha ao habilitar $0 no firewalld"
 ],
 "Failed to enable tuned": [
  null,
  "Falha ao habilitar tuned"
 ],
 "Failed to fetch logs": [
  null,
  "Falha ao obter os logs"
 ],
 "Failed to load unit": [
  null,
  "Falha ao carregar unidade"
 ],
 "Failed to save changes in /etc/motd": [
  null,
  "Falha ao salvar alterações em /etc/motd"
 ],
 "Failed to start": [
  null,
  "Falha ao iniciar"
 ],
 "Failed to switch profile": [
  null,
  "Falha ao mudar de perfil"
 ],
 "File state": [
  null,
  "Estado de arquivo"
 ],
 "Filter by name or description": [
  null,
  "Filtrar por nome ou descrição"
 ],
 "Filters": [
  null,
  "Filtros"
 ],
 "Font size": [
  null,
  "Tamanho da fonte"
 ],
 "Forbidden from running": [
  null,
  "Proibido executar"
 ],
 "Free-form search": [
  null,
  "Pesquisa livre"
 ],
 "Fridays": [
  null,
  "Sextas"
 ],
 "Generated": [
  null,
  "Gerado"
 ],
 "Go to $0": [
  null,
  "Ir para $0"
 ],
 "Go to now": [
  null,
  "Ir para agora"
 ],
 "Handheld": [
  null,
  "Dispositivo portátil"
 ],
 "Hardware information": [
  null,
  "Informação de Hardware"
 ],
 "Health": [
  null,
  "Saúde"
 ],
 "Help": [
  null,
  "Ajuda"
 ],
 "Hide confirmation password": [
  null,
  "Ocultar confirmação da senha"
 ],
 "Hide password": [
  null,
  "Ocultar senha"
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  "Maior interoperabilidade ao custo de uma maior superfície de ataque."
 ],
 "Host key is incorrect": [
  null,
  "Chave de Host incorreta"
 ],
 "Hostname": [
  null,
  "Nome do host"
 ],
 "Hourly": [
  null,
  "A cada hora"
 ],
 "Hours": [
  null,
  "Horas"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Identifier": [
  null,
  "Identificador"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Se a impressão digital corresponder, clique em \"Confiar e adicionar host\". Caso contrário, não se conecte e entre em contato com o administrador."
 ],
 "Increase by one": [
  null,
  "Incrementar em um"
 ],
 "Indirect": [
  null,
  "Indireto"
 ],
 "Info and above": [
  null,
  "Info e acima"
 ],
 "Insights: ": [
  null,
  "Ideias: "
 ],
 "Install": [
  null,
  "Instalar"
 ],
 "Install realmd support": [
  null,
  "Instalar o suporte ao realmd"
 ],
 "Install software": [
  null,
  "Instalar o software"
 ],
 "Installing $0": [
  null,
  "Instalando $0"
 ],
 "Internal error": [
  null,
  "Erro interno"
 ],
 "Invalid": [
  null,
  "Inválido"
 ],
 "Invalid date format": [
  null,
  "Formato de data inválido"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Formato de data inválido e formato de tempo inválido"
 ],
 "Invalid file permissions": [
  null,
  "Permissão de arquivos inválida"
 ],
 "Invalid time format": [
  null,
  "Formato de tempo inválido"
 ],
 "Invalid timezone": [
  null,
  "Fuso horário inválido"
 ],
 "IoT gateway": [
  null,
  "Gateway IoT"
 ],
 "Join": [
  null,
  "Afiliar-se"
 ],
 "Join domain": [
  null,
  "Associar-se ao domínio"
 ],
 "Joining": [
  null,
  "Juntando-se"
 ],
 "Joining a domain requires installation of realmd": [
  null,
  "A adesão a um domínio requer a instalação do realmd"
 ],
 "Joining this domain is not supported": [
  null,
  "A adesão à este domínio não é suportada"
 ],
 "Joins namespace of": [
  null,
  "Junte os espaços nos nomes de"
 ],
 "Journal": [
  null,
  "Diário"
 ],
 "Journal entry": [
  null,
  "Entrada do diário"
 ],
 "Journal entry not found": [
  null,
  "Entrada do diário não encontrada"
 ],
 "Kernel dump": [
  null,
  "Dump do kernel"
 ],
 "Key password": [
  null,
  "Nova senha"
 ],
 "LEGACY with Active Directory interoperability.": [
  null,
  "LEGACY com interoperabilidade com Active Directory."
 ],
 "Laptop": [
  null,
  "Laptop"
 ],
 "Last 24 hours": [
  null,
  "Últimas 24 horas"
 ],
 "Last 7 days": [
  null,
  "Últimos 7 dias"
 ],
 "Last successful login:": [
  null,
  "Último login bem-sucedido:"
 ],
 "Learn more": [
  null,
  "Saiba mais"
 ],
 "Leave $0": [
  null,
  "Abandonar $0"
 ],
 "Leave domain": [
  null,
  "Abandonar Domínio"
 ],
 "Light": [
  null,
  "Claro"
 ],
 "Linked": [
  null,
  "Vinculado"
 ],
 "Listen": [
  null,
  "Ouvindo"
 ],
 "Listing units": [
  null,
  "Listando unidades"
 ],
 "Listing units failed: $0": [
  null,
  "Falha na listagem de unidades: $0"
 ],
 "Load earlier entries": [
  null,
  "Carregar logs anteriores"
 ],
 "Loading keys...": [
  null,
  "Carregando chaves..."
 ],
 "Loading of SSH keys failed": [
  null,
  "O carregamento das chaves SSH falhou"
 ],
 "Loading of units failed": [
  null,
  "O carregamento das unidades falhou"
 ],
 "Loading system modifications...": [
  null,
  "Carregando modificações do sistema..."
 ],
 "Loading unit failed": [
  null,
  "Falha ao carregar unidade"
 ],
 "Loading...": [
  null,
  "Carregando..."
 ],
 "Log in": [
  null,
  "Entrar"
 ],
 "Log in to $0": [
  null,
  "Iniciar sessão para $0"
 ],
 "Log messages": [
  null,
  "Mensagens de Log"
 ],
 "Login failed": [
  null,
  "Falha ao logar"
 ],
 "Login format": [
  null,
  "Formato de Login"
 ],
 "Logs": [
  null,
  "Logs"
 ],
 "Low profile desktop": [
  null,
  "Desktop de baixo perfil"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "Machine ID": [
  null,
  "ID de Máquina"
 ],
 "Machine SSH key fingerprints": [
  null,
  "Máquina de Chaves SSH e Impressões digitais"
 ],
 "Main server chassis": [
  null,
  "Chassi do Servidor Principal"
 ],
 "Maintenance": [
  null,
  "Manutenção"
 ],
 "Manage storage": [
  null,
  "Gerenciar armazenamento"
 ],
 "Manually": [
  null,
  "Manualmente"
 ],
 "Mask service": [
  null,
  "Serviço de máscara"
 ],
 "Masked": [
  null,
  "Mascarado"
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  "O serviço de mascaramento impede a execução de todas as unidades dependentes. Isso pode ter um impacto maior do que o previsto. Confirme que deseja mascarar esta unidade."
 ],
 "Memory": [
  null,
  "Memória"
 ],
 "Memory technology": [
  null,
  "Tecnologia de memória"
 ],
 "Merged": [
  null,
  "Mesclado"
 ],
 "Message to logged in users": [
  null,
  "Mensagem para usuários logados"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini torre"
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "Minutos precisam ser números entre 0-59"
 ],
 "Minutely": [
  null,
  "A cada minuto"
 ],
 "Minutes": [
  null,
  "Minutos"
 ],
 "Mitigations": [
  null,
  "Mitigações"
 ],
 "Model": [
  null,
  "Modelo"
 ],
 "Mondays": [
  null,
  "Segundas"
 ],
 "Monthly": [
  null,
  "Mensalmente"
 ],
 "Multi-system chassis": [
  null,
  "Chassi Multi-sistema"
 ],
 "NTP server": [
  null,
  "Servidor NTP"
 ],
 "Name": [
  null,
  "Nome"
 ],
 "Need at least one NTP server": [
  null,
  "Precisa de pelo menos um servidor NTP"
 ],
 "Networking": [
  null,
  "Rede"
 ],
 "New password was not accepted": [
  null,
  "Nova senha não foi aceita"
 ],
 "No delay": [
  null,
  "Sem Atraso"
 ],
 "No host keys found.": [
  null,
  "Nenhuma chave de host encontrada."
 ],
 "No log entries": [
  null,
  "Nenhuma entrada de log"
 ],
 "No logs found": [
  null,
  "Nenhum log encontrado"
 ],
 "No matching results": [
  null,
  "Nenhum resultado correspondente"
 ],
 "No results found": [
  null,
  "Nenhum resultado encontrado"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  ""
 ],
 "No rule hits": [
  null,
  ""
 ],
 "No such file or directory": [
  null,
  "Diretório ou arquivo não encontrado"
 ],
 "No system modifications": [
  null,
  "Nenhuma modificações no sistema"
 ],
 "None": [
  null,
  "Nenhum"
 ],
 "Not a valid private key": [
  null,
  "Chave privada não válida"
 ],
 "Not connected to Insights": [
  null,
  ""
 ],
 "Not found": [
  null,
  "Não encontrado"
 ],
 "Not permitted to configure realms": [
  null,
  "Não autorizado a configurar reinos"
 ],
 "Not permitted to perform this action.": [
  null,
  "Não é permitido executar esta ação."
 ],
 "Not running": [
  null,
  "Não está em execução"
 ],
 "Not synchronized": [
  null,
  "Não sincronizado"
 ],
 "Note": [
  null,
  "Nota"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Notice and above": [
  null,
  "Observe e acima"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Old password not accepted": [
  null,
  "Senha antiga não aceita"
 ],
 "On failure": [
  null,
  "Em Falha"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Uma vez instalado o Cockpit, habilite-o com \"systemctl enable --now cockpit.socket\"."
 ],
 "Only alphabets, numbers, : , _ , . , @ , - are allowed": [
  null,
  "Apenas alfabetos, números, : , _ , . , @ , - são permitidos"
 ],
 "Only emergency": [
  null,
  "Apenas emergência"
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  ""
 ],
 "Other": [
  null,
  "De outros"
 ],
 "Overview": [
  null,
  "Visão geral"
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit caiu"
 ],
 "Part of": [
  null,
  "Parte de"
 ],
 "Password": [
  null,
  "Senha"
 ],
 "Password is not acceptable": [
  null,
  "Senha não é aceitavél"
 ],
 "Password is too weak": [
  null,
  "Senha é muito fraca"
 ],
 "Password not accepted": [
  null,
  "Senha não aceita"
 ],
 "Paste": [
  null,
  "Colar"
 ],
 "Path": [
  null,
  "Caminho"
 ],
 "Path to file": [
  null,
  "Caminho para o arquivo"
 ],
 "Paths": [
  null,
  "Caminhos"
 ],
 "Pause": [
  null,
  "Pausar"
 ],
 "Performance profile": [
  null,
  "Perfil de desempenho"
 ],
 "Peripheral chassis": [
  null,
  "Chassi Periférico"
 ],
 "Pick date": [
  null,
  ""
 ],
 "Pinned unit": [
  null,
  ""
 ],
 "Pizza box": [
  null,
  "Servidor compacto"
 ],
 "Portable": [
  null,
  "Portatil"
 ],
 "Present": [
  null,
  "Presente"
 ],
 "Pretty host name": [
  null,
  "Nome de Host Bonito"
 ],
 "Previous boot": [
  null,
  ""
 ],
 "Priority": [
  null,
  "Prioridade"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "A solicitação via ssh-add expirou"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Solicitação via ssh-keygen expirou"
 ],
 "Propagates reload to": [
  null,
  "Propaga Recarregar para"
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  ""
 ],
 "RAID chassis": [
  null,
  "Chassis do RAID"
 ],
 "Rack mount chassis": [
  null,
  "Chassis de montagem do Rack"
 ],
 "Rank": [
  null,
  ""
 ],
 "Read more...": [
  null,
  "Saiba mais..."
 ],
 "Read-only": [
  null,
  "Somente leitura"
 ],
 "Real host name": [
  null,
  "Nome Real de Host"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "Nome de host real só pode conter caracteres minúsculos, dígitos, traços e períodos (com subdomínios preenchidos)"
 ],
 "Real host name must be 64 characters or less": [
  null,
  "Nome de host real deve conter 64 caracteres ou menos"
 ],
 "Reapply and reboot": [
  null,
  "Reaplicar e reiniciar"
 ],
 "Reboot": [
  null,
  "Reiniciar"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  ""
 ],
 "Reload": [
  null,
  "Recarregar"
 ],
 "Reload propagated from": [
  null,
  "Recarregar propagado de"
 ],
 "Reloading": [
  null,
  "Carregando novamente"
 ],
 "Removals:": [
  null,
  "Remoções:"
 ],
 "Remove": [
  null,
  "Remover"
 ],
 "Removing $0": [
  null,
  "Removendo $0"
 ],
 "Repeat": [
  null,
  "Repetir"
 ],
 "Repeat monthly": [
  null,
  "Repita Mensalmente"
 ],
 "Repeat weekly": [
  null,
  "Repita Semanalmente"
 ],
 "Required by": [
  null,
  "Solicitado por"
 ],
 "Required by ": [
  null,
  "Solicitado por "
 ],
 "Requires": [
  null,
  "Requer"
 ],
 "Requires administration access to edit": [
  null,
  "Requer acesso administrativo para editar"
 ],
 "Requisite": [
  null,
  "Requisita"
 ],
 "Requisite of": [
  null,
  "Requisitode"
 ],
 "Reset": [
  null,
  "Redefinir"
 ],
 "Restart": [
  null,
  "Reiniciar"
 ],
 "Resume": [
  null,
  "Continuar"
 ],
 "Run at": [
  null,
  "Executar em"
 ],
 "Run on": [
  null,
  ""
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  ""
 ],
 "Running": [
  null,
  "Em execução"
 ],
 "Running process prevents directory change": [
  null,
  ""
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "Chave SSH"
 ],
 "Saturdays": [
  null,
  "Sábados"
 ],
 "Save": [
  null,
  "Salvar"
 ],
 "Save and reboot": [
  null,
  ""
 ],
 "Save changes": [
  null,
  "Salvar Mudanças"
 ],
 "Scheduled poweroff at $0": [
  null,
  ""
 ],
 "Scheduled reboot at $0": [
  null,
  ""
 ],
 "Sealed-case PC": [
  null,
  "PC com caixa vedada"
 ],
 "Search": [
  null,
  "Buscar"
 ],
 "Second needs to be a number between 0-59": [
  null,
  "Segundo precisam ser números entre 0-59"
 ],
 "Seconds": [
  null,
  "Segundos"
 ],
 "Secure shell keys": [
  null,
  "Chaves de Shell Seguras"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  ""
 ],
 "Server has closed the connection.": [
  null,
  "O servidor encerrou a conexão."
 ],
 "Server software": [
  null,
  "Software de servidor"
 ],
 "Service logs": [
  null,
  "Nenhuma entrada de log"
 ],
 "Services": [
  null,
  "Serviços"
 ],
 "Set hostname": [
  null,
  "Definir nome do host"
 ],
 "Set time": [
  null,
  "Definir Tempo"
 ],
 "Shell script": [
  null,
  "Shell script"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show fingerprints": [
  null,
  "Exibir digitais"
 ],
 "Show messages containing given string.": [
  null,
  ""
 ],
 "Show messages for the specified systemd unit.": [
  null,
  ""
 ],
 "Show messages from a specific boot.": [
  null,
  ""
 ],
 "Show more relationships": [
  null,
  ""
 ],
 "Show password": [
  null,
  "Exibir senha"
 ],
 "Show relationships": [
  null,
  ""
 ],
 "Shut down": [
  null,
  "Encerrar"
 ],
 "Shutdown": [
  null,
  "Desligar"
 ],
 "Since": [
  null,
  "Desde"
 ],
 "Single rank": [
  null,
  ""
 ],
 "Size": [
  null,
  "Tamanho"
 ],
 "Slot": [
  null,
  "Slot"
 ],
 "Sockets": [
  null,
  "Sockets"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  ""
 ],
 "Space-saving computer": [
  null,
  "Computador com economia de espaço"
 ],
 "Specific time": [
  null,
  "Tempo Específico"
 ],
 "Speed": [
  null,
  "Velocidade"
 ],
 "Start": [
  null,
  "Iniciar"
 ],
 "Start and enable": [
  null,
  "Iniciar e habilitar"
 ],
 "Start service": [
  null,
  "Começar serviço"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  ""
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  ""
 ],
 "State": [
  null,
  "Estado"
 ],
 "Static": [
  null,
  "Estático"
 ],
 "Status": [
  null,
  "Estado"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "Stop": [
  null,
  "Pare"
 ],
 "Stop and disable": [
  null,
  "Parar e desabilitar"
 ],
 "Storage": [
  null,
  "Armazenamento"
 ],
 "Stub": [
  null,
  ""
 ],
 "Sub-Chassis": [
  null,
  "Sub chassis"
 ],
 "Sub-Notebook": [
  null,
  "Sub notebook"
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  ""
 ],
 "Successfully copied to clipboard": [
  null,
  "Copiado com sucesso para a área de transferência"
 ],
 "Sundays": [
  null,
  "Domingos"
 ],
 "Synchronized": [
  null,
  "Sincronizado"
 ],
 "Synchronized with $0": [
  null,
  "Sincronizado com $0"
 ],
 "Synchronizing": [
  null,
  "Sincronizando"
 ],
 "System": [
  null,
  "Sistema"
 ],
 "System information": [
  null,
  "Informação do sistema"
 ],
 "System time": [
  null,
  "Hora do sistema"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Targets": [
  null,
  "Alvos"
 ],
 "Terminal": [
  null,
  "Terminal"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  ""
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  ""
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  ""
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  ""
 ],
 "The fingerprint should match:": [
  null,
  "A impressão digital deve corresponder a:"
 ],
 "The key password can not be empty": [
  null,
  "A senha da chave não pode estar vazia"
 ],
 "The key passwords do not match": [
  null,
  "As senhas da chave não coincidem"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  ""
 ],
 "The password can not be empty": [
  null,
  "A senha não pode estar vazia"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "A impressão digital resultante pode ser compartilhada por métodos públicos, incluindo e-mail."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "A impressão digital resultante pode ser compartilhada por métodos públicos, incluindo e-mail. Se você estiver pedindo para outra pessoa fazer a verificação para você, ela pode enviar os resultados usando qualquer método."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "O servidor se recusou a autenticar usando quaisquer métodos suportados."
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  ""
 ],
 "The user $0 is not permitted to change cryptographic policies": [
  null,
  "O usuário $0 não tem permissão para alterar políticas criptográficas"
 ],
 "This field cannot be empty": [
  null,
  "Este campo não pode estar vazio"
 ],
 "This may take a while": [
  null,
  "Isso pode demorar um pouco"
 ],
 "This system is using a custom profile": [
  null,
  "Este sistema está usando um perfil personalizado"
 ],
 "This system is using the recommended profile": [
  null,
  "Este sistema está usando o perfil recomendado"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Esta ferramenta configura a política do SELinux e pode ajudar a entender e resolver violações de política."
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Esta ferramenta configura o sistema para escrever kernel crash dumps. Ela suporta os alvos de dump \"local\" (disco), \"ssh\" e \"nfs\"."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Esta ferramenta gera um arquivo de informações de configuração e diagnóstico do sistema em execução. O arquivo pode ser armazenado localmente ou centralmente para fins de registro ou rastreamento ou pode ser enviado a representantes de suporte técnico, desenvolvedores ou administradores de sistema para auxiliar na detecção de falhas técnicas e depuração."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Esta ferramenta gerencia armazenamento local, como sistemas de arquivos, grupos de volumes LVM2 e montagens NFS."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Esta ferramenta gerencia redes como vínculos, pontes, times, VLANs e firewalls usando NetworkManager e Firewalld. O NetworkManager é incompatível com o systemd-networkd padrão do Ubuntu e os scripts ifupdown do Debian."
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  "Esta unidade não foi projetada para ser habilitada explicitamente."
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  "Isso adicionará uma correspondência para '_BOOT_ID='. Se não especificado, os logs para a inicialização atual serão exibidos. Se o ID de inicialização for omitido, um deslocamento positivo procurará as inicializações começando do início do diário, e um deslocamento igual ou menor que zero procurará as inicializações começando do final do diário. Assim, 1 significa a primeira inicialização encontrada no diário em ordem cronológica, 2 a segunda e assim por diante; enquanto -0 é a última inicialização, -1 a penúltima inicialização e assim por diante."
 ],
 "This will add match for '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' and 'UNIT=' to find all possible messages for the given unit. Can contain more units separated by comma.": [
  null,
  "Isso adicionará correspondência para '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' e 'UNIT=' para encontrar todas as mensagens possíveis para a unidade fornecida. Pode conter mais unidades separadas por vírgula."
 ],
 "Thursdays": [
  null,
  "Quintas"
 ],
 "Time": [
  null,
  "Tempo"
 ],
 "Time zone": [
  null,
  "Fuso Horário"
 ],
 "Timer creation failed": [
  null,
  "Criação de temporizador falhou"
 ],
 "Timer deletion failed": [
  null,
  "Exclusão de temporizador falhou"
 ],
 "Timers": [
  null,
  "Temporizadores"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Para garantir que sua conexão não seja interceptada por terceiros mal-intencionados, verifique a impressão digital da chave do host:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Para verificar uma impressão digital, execute o seguinte em $0 enquanto estiver fisicamente sentado na máquina ou por meio de uma rede confiável:"
 ],
 "Toggle date picker": [
  null,
  ""
 ],
 "Too much data": [
  null,
  "Muitos dados"
 ],
 "Total size: $0": [
  null,
  "Tamanho total: $0"
 ],
 "Tower": [
  null,
  "Torre"
 ],
 "Transient": [
  null,
  ""
 ],
 "Trigger": [
  null,
  "Gatilhos"
 ],
 "Triggered by": [
  null,
  "Disparado por"
 ],
 "Triggers": [
  null,
  "Disparadores"
 ],
 "Trust and add host": [
  null,
  "Confiar e adicionar host"
 ],
 "Trying to synchronize with $0": [
  null,
  "Tentando sincronizar com $0"
 ],
 "Tuesdays": [
  null,
  "Terças"
 ],
 "Tuned has failed to start": [
  null,
  "Falha ao iniciar Tuned"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  ""
 ],
 "Tuned is not available": [
  null,
  "Tuned não está disponível"
 ],
 "Tuned is not running": [
  null,
  "Tuned não está em execução"
 ],
 "Tuned is off": [
  null,
  "Tuned está fora"
 ],
 "Type": [
  null,
  "Tipo"
 ],
 "Type to filter": [
  null,
  "Tipo para filtrar"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  ""
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  ""
 ],
 "Unit": [
  null,
  "Unidade"
 ],
 "Unknown": [
  null,
  "Desconhecido"
 ],
 "Unknown host: $0": [
  null,
  "Host desconhecido: $0"
 ],
 "Until": [
  null,
  ""
 ],
 "Untrusted host": [
  null,
  "Host não confiável"
 ],
 "Up since": [
  null,
  "Ligado desde"
 ],
 "Updating status...": [
  null,
  ""
 ],
 "Usage": [
  null,
  "Uso"
 ],
 "User": [
  null,
  "Usuário"
 ],
 "Validating address": [
  null,
  "Validando endereço"
 ],
 "Vendor": [
  null,
  "Fabricante"
 ],
 "Verify fingerprint": [
  null,
  "Verificar digital"
 ],
 "Version": [
  null,
  "Versão"
 ],
 "View all logs": [
  null,
  "Ver todos os logs"
 ],
 "View automation script": [
  null,
  ""
 ],
 "View hardware details": [
  null,
  ""
 ],
 "View login history": [
  null,
  ""
 ],
 "View metrics and history": [
  null,
  ""
 ],
 "Viewing memory information requires administrative access.": [
  null,
  "Visualizar informações de memória requer acesso administrativo."
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Aguardando que outras operações de gerenciamento de software terminem"
 ],
 "Wanted by": [
  null,
  "Requerido por"
 ],
 "Wants": [
  null,
  "Deseja"
 ],
 "Warning and above": [
  null,
  "Aviso e acima"
 ],
 "Web Console for Linux servers": [
  null,
  "Console da Web para servidores Linux"
 ],
 "Web console is running in limited access mode.": [
  null,
  ""
 ],
 "Wednesdays": [
  null,
  "Quartas"
 ],
 "Weeks": [
  null,
  "Semanas"
 ],
 "White": [
  null,
  "Branco"
 ],
 "Yearly": [
  null,
  ""
 ],
 "You are connecting to $0 for the first time.": [
  null,
  ""
 ],
 "You may try to load older entries.": [
  null,
  ""
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  ""
 ],
 "Your session has been terminated.": [
  null,
  "Sua sessão foi encerrada."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Sua sessão expirou. Por favor, faça o login novamente."
 ],
 "Zone": [
  null,
  "Zona"
 ],
 "[binary data]": [
  null,
  "[dados binários]"
 ],
 "[no data]": [
  null,
  "[sem dados]"
 ],
 "active": [
  null,
  "ativo"
 ],
 "edit": [
  null,
  "editar"
 ],
 "failed to list ssh host keys: $0": [
  null,
  "falha ao listar chaves locais de ssh: $0"
 ],
 "in less than a minute": [
  null,
  "em menos de um minuto"
 ],
 "inconsistent": [
  null,
  "inconsistente"
 ],
 "journalctl manpage": [
  null,
  "manpage do journalctl"
 ],
 "less than a minute ago": [
  null,
  "menos de um minuto atrás"
 ],
 "none": [
  null,
  "nenhum"
 ],
 "of $0 CPU": [
  null,
  "de $0 CPU",
  "de $0 núcleos de CPU"
 ],
 "password quality": [
  null,
  "qualidade da senha"
 ],
 "recommended": [
  null,
  "recomendado"
 ],
 "running $0": [
  null,
  "executando $0"
 ],
 "show less": [
  null,
  "mostrar menos"
 ],
 "show more": [
  null,
  "mostrar mais"
 ],
 "unknown": [
  null,
  "desconhecido"
 ],
 "dialog-title\u0004Domain": [
  null,
  "Domínio"
 ],
 "dialog-title\u0004Join a domain": [
  null,
  "Ingressar em um domínio"
 ],
 "from <host>\u0004from $0": [
  null,
  "desde $0"
 ],
 "from <host> on <terminal>\u0004from $0 on $1": [
  null,
  "de $0 em $1"
 ],
 "on <terminal>\u0004on $0": [
  null,
  "em $0"
 ]
});
