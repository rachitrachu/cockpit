cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "zh_CN",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 day": [
  null,
  "$0 天"
 ],
 "$0 exited with code $1": [
  null,
  "$0 退出，返回码为 $1"
 ],
 "$0 failed": [
  null,
  "$0 失败"
 ],
 "$0 hour": [
  null,
  "$0 小时"
 ],
 "$0 is not available from any repository.": [
  null,
  "没有提供 $0 组件的仓库。"
 ],
 "$0 key changed": [
  null,
  "已更改 $0 个密钥"
 ],
 "$0 killed with signal $1": [
  null,
  "进程 $0 被信号 $1 终止"
 ],
 "$0 minute": [
  null,
  "$0 分钟"
 ],
 "$0 month": [
  null,
  "$0 月"
 ],
 "$0 week": [
  null,
  "$0 周"
 ],
 "$0 will be installed.": [
  null,
  "即将安装 $0。"
 ],
 "$0 year": [
  null,
  "$0 年"
 ],
 "1 day": [
  null,
  "1 天"
 ],
 "1 hour": [
  null,
  "1 小时"
 ],
 "1 minute": [
  null,
  "1 分钟"
 ],
 "1 week": [
  null,
  "1 周"
 ],
 "20 minutes": [
  null,
  "20 分钟"
 ],
 "40 minutes": [
  null,
  "40 分钟"
 ],
 "5 minutes": [
  null,
  "5 分钟"
 ],
 "6 hours": [
  null,
  "6 小时"
 ],
 "60 minutes": [
  null,
  "60 分钟"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "主机 $0 上找不到版本兼容的 Cockpit。"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "将在 $2 上为 $1 在 $0 处创建一个新的 SSH 密钥，该密钥将在 $5 上被添加到 $4 的 $3 文件中。"
 ],
 "Absent": [
  null,
  "空缺"
 ],
 "Acceptable password": [
  null,
  "可行的密码"
 ],
 "Actions": [
  null,
  "操作"
 ],
 "Add $0": [
  null,
  "添加 $0"
 ],
 "Additional packages:": [
  null,
  "额外软件包："
 ],
 "Administration with Cockpit Web Console": [
  null,
  "使用 Cockpit 网页控制台管理系统"
 ],
 "Advanced TCA": [
  null,
  "高级 TCA"
 ],
 "All-in-one": [
  null,
  "一体化"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Ansible 角色文档"
 ],
 "Application information is missing": [
  null,
  "缺少应用程序信息"
 ],
 "Applications": [
  null,
  "应用程序"
 ],
 "Applications list": [
  null,
  "应用程序列表"
 ],
 "Authentication": [
  null,
  "认证"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "通过Cockpit Web Console进行验证后才能执行特权操作"
 ],
 "Authorize SSH key": [
  null,
  "授权 SSH 密钥"
 ],
 "Automatically using NTP": [
  null,
  "自动使用 NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "自动使用额外的 NTP 服务器"
 ],
 "Automatically using specific NTP servers": [
  null,
  "自动使用指定的 NTP 服务器"
 ],
 "Automation script": [
  null,
  "自动化脚本"
 ],
 "Blade": [
  null,
  "刀片"
 ],
 "Blade enclosure": [
  null,
  "刀片机箱"
 ],
 "Bus expansion chassis": [
  null,
  "总线扩展机箱"
 ],
 "Cancel": [
  null,
  "取消"
 ],
 "Cannot forward login credentials": [
  null,
  "无法转发登录凭证"
 ],
 "Cannot schedule event in the past": [
  null,
  "无法调度以前的事件"
 ],
 "Change": [
  null,
  "变更"
 ],
 "Change system time": [
  null,
  "修改系统时间"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "密钥的变化通常是操作系统重新安装的结果。但是，意料外的变化可能代表有第三方尝试截获您的连接。"
 ],
 "Checking installed software": [
  null,
  "检查安装的软件"
 ],
 "Clear input value": [
  null,
  "清除输入值"
 ],
 "Close": [
  null,
  "关闭"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "NetworkManager 的 Cockpit 配置和防火墙"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit 无法联系指定的主机。"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit 是一个服务器管理工具，可以方便地通过浏览器来管理您的 Linux 服务器。在终端和 web 工具间自由切换将不是问题。通过 Cockpit 启动的服务可以通过终端停止。同样，如果在终端中发生错误, 也可以在 Cockpit 的日志接口中看到。"
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit 与系统上的软件不兼容。"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit 未安装"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit 未安装在系统上。"
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit 是完美的系统管理员工具，它可以轻松完成简单的任务, 如存储管理, 检查日志信息，以及启动/停止服务。 您可以同时监控和管理多个服务器。点一键就可以添加服务器，并开始进行管理。"
 ],
 "Collect and package diagnostic and support data": [
  null,
  "收集并打包诊断和支持数据"
 ],
 "Collect kernel crash dumps": [
  null,
  "收集内核崩溃转储"
 ],
 "Compact PCI": [
  null,
  "紧凑型 PCI"
 ],
 "Confirm key password": [
  null,
  "确认密钥密码"
 ],
 "Connection has timed out.": [
  null,
  "连接超时。"
 ],
 "Convertible": [
  null,
  "可转换"
 ],
 "Copied": [
  null,
  "复制的"
 ],
 "Copy": [
  null,
  "复制"
 ],
 "Copy to clipboard": [
  null,
  "复制到剪贴板"
 ],
 "Create $0": [
  null,
  "创建 $0"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "创建一个新的 SSH 密钥，并对其进行授权"
 ],
 "Create new task file with this content.": [
  null,
  "使用此内容创建新的任务文件。"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Delay": [
  null,
  "延时"
 ],
 "Desktop": [
  null,
  "桌面"
 ],
 "Detachable": [
  null,
  "可拆开"
 ],
 "Diagnostic reports": [
  null,
  "诊断报告"
 ],
 "Docking station": [
  null,
  "扩展坞"
 ],
 "Downloading $0": [
  null,
  "正在下载 $0"
 ],
 "Dual rank": [
  null,
  "双通道"
 ],
 "Embedded PC": [
  null,
  "嵌入式 PC"
 ],
 "Error": [
  null,
  "错误"
 ],
 "Excellent password": [
  null,
  "密码强度良好"
 ],
 "Expansion chassis": [
  null,
  "扩展机箱"
 ],
 "Failed to change password": [
  null,
  "修改密码失败"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "在 firewalld 中启用 $0 失败"
 ],
 "Go to application": [
  null,
  "转到应用"
 ],
 "Go to now": [
  null,
  "转到现在"
 ],
 "Handheld": [
  null,
  "手持式"
 ],
 "Hide confirmation password": [
  null,
  "隐藏确认密码"
 ],
 "Hide password": [
  null,
  "隐藏密码"
 ],
 "Host key is incorrect": [
  null,
  "主机密钥不正确"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "如果指纹匹配，点 'Trust and add host'。否则，请不要连接并联系您的管理员。"
 ],
 "Install": [
  null,
  "安装"
 ],
 "Install application information": [
  null,
  "安装应用程序信息"
 ],
 "Install software": [
  null,
  "安装软件"
 ],
 "Installing": [
  null,
  "正在安装"
 ],
 "Installing $0": [
  null,
  "正在安装 $0"
 ],
 "Internal error": [
  null,
  "内部错误"
 ],
 "Invalid date format": [
  null,
  "无效的日期格式"
 ],
 "Invalid date format and invalid time format": [
  null,
  "无效的日期格式和时间格式"
 ],
 "Invalid file permissions": [
  null,
  "无效的文件权限"
 ],
 "Invalid time format": [
  null,
  "无效的时间格式"
 ],
 "Invalid timezone": [
  null,
  "无效的时区"
 ],
 "IoT gateway": [
  null,
  "IoT 网关"
 ],
 "Kernel dump": [
  null,
  "内核转储"
 ],
 "Key password": [
  null,
  "钥匙密码"
 ],
 "Laptop": [
  null,
  "笔记本电脑"
 ],
 "Learn more": [
  null,
  "了解更多"
 ],
 "Loading system modifications...": [
  null,
  "加载系统改变..."
 ],
 "Log in": [
  null,
  "登录"
 ],
 "Log in to $0": [
  null,
  "登录到 $0"
 ],
 "Log messages": [
  null,
  "日志消息"
 ],
 "Login failed": [
  null,
  "登录失败"
 ],
 "Low profile desktop": [
  null,
  "低调桌面"
 ],
 "Lunch box": [
  null,
  "主机类型"
 ],
 "Main server chassis": [
  null,
  "主服务器机箱"
 ],
 "Manage storage": [
  null,
  "管理存储"
 ],
 "Manually": [
  null,
  "手动的"
 ],
 "Message to logged in users": [
  null,
  "发送给已登录用户的信息"
 ],
 "Mini PC": [
  null,
  "迷你电脑"
 ],
 "Mini tower": [
  null,
  "迷你塔式主机"
 ],
 "Multi-system chassis": [
  null,
  "多系统机箱"
 ],
 "NTP server": [
  null,
  "NTP 服务器"
 ],
 "Need at least one NTP server": [
  null,
  "至少需要一个 NTP 服务器"
 ],
 "Networking": [
  null,
  "网络"
 ],
 "New password was not accepted": [
  null,
  "新密码不被接受"
 ],
 "No applications installed or available.": [
  null,
  "应用未安装或不可用."
 ],
 "No delay": [
  null,
  "无延时"
 ],
 "No description provided.": [
  null,
  "没有提供说明。"
 ],
 "No installation package found for this application.": [
  null,
  "没有找到该应用的安装包。"
 ],
 "No results found": [
  null,
  "没有找到结果"
 ],
 "No such file or directory": [
  null,
  "没有该文件或目录"
 ],
 "No system modifications": [
  null,
  "没有系统改变"
 ],
 "Not a valid private key": [
  null,
  "无效的私钥"
 ],
 "Not permitted to perform this action.": [
  null,
  "不允许执行该操作。"
 ],
 "Not synchronized": [
  null,
  "未同步"
 ],
 "Notebook": [
  null,
  "笔记本"
 ],
 "Occurrences": [
  null,
  "发生"
 ],
 "Ok": [
  null,
  "确认"
 ],
 "Old password not accepted": [
  null,
  "旧密码不被接受"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "在安装 Cockpit 后，使用 \"systemctl enable --now cockpit.socket\" 启用它。"
 ],
 "Other": [
  null,
  "其他"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit 已崩溃"
 ],
 "Password": [
  null,
  "密码"
 ],
 "Password is not acceptable": [
  null,
  "不接受该密码"
 ],
 "Password is too weak": [
  null,
  "密码太弱"
 ],
 "Password not accepted": [
  null,
  "密码未接受"
 ],
 "Paste": [
  null,
  "粘贴"
 ],
 "Paste error": [
  null,
  "粘贴错误"
 ],
 "Path to file": [
  null,
  "文件路径"
 ],
 "Peripheral chassis": [
  null,
  "外设机箱"
 ],
 "Pick date": [
  null,
  "选择日期"
 ],
 "Pizza box": [
  null,
  "披萨盒"
 ],
 "Portable": [
  null,
  "手提"
 ],
 "Present": [
  null,
  "当前"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "通过 ssh-add 提示超时"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "通过 ssh-keygen 提示超时"
 ],
 "RAID chassis": [
  null,
  "RAID 机箱"
 ],
 "Rack mount chassis": [
  null,
  "机架式机箱"
 ],
 "Reboot": [
  null,
  "重启"
 ],
 "Removals:": [
  null,
  "移除："
 ],
 "Remove": [
  null,
  "删除"
 ],
 "Removing": [
  null,
  "删除"
 ],
 "Removing $0": [
  null,
  "正在删除 $0"
 ],
 "Row expansion": [
  null,
  "行扩展"
 ],
 "Row select": [
  null,
  "行选择"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "通过一个可信网络运行这个命令，或在远程机器上运行这个命令："
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "SSH 密钥"
 ],
 "SSH key login": [
  null,
  "SSH 密钥登录"
 ],
 "Sealed-case PC": [
  null,
  "密封式 PC"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Security Enhanced Linux 配置和故障排除"
 ],
 "Select an option": [
  null,
  "选择一个选项"
 ],
 "Server has closed the connection.": [
  null,
  "服务器已关闭了连接。"
 ],
 "Set time": [
  null,
  "设置时间"
 ],
 "Shell script": [
  null,
  "Shell 脚本"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show confirmation password": [
  null,
  "显示确认密码"
 ],
 "Show password": [
  null,
  "显示密码"
 ],
 "Shut down": [
  null,
  "关机"
 ],
 "Single rank": [
  null,
  "单 rank"
 ],
 "Space-saving computer": [
  null,
  "节省空间的计算机"
 ],
 "Specific time": [
  null,
  "指定时间"
 ],
 "Stick PC": [
  null,
  "PC 棒"
 ],
 "Storage": [
  null,
  "存储"
 ],
 "Strong password": [
  null,
  "强密码"
 ],
 "Sub-Chassis": [
  null,
  "子机箱"
 ],
 "Sub-Notebook": [
  null,
  "子笔记本"
 ],
 "Synchronized": [
  null,
  "已同步"
 ],
 "Synchronized with $0": [
  null,
  "与 $0 同步"
 ],
 "Synchronizing": [
  null,
  "同步"
 ],
 "Tablet": [
  null,
  "平板"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "$2 上 $1 的 SSH 密钥 $0 将被添加到 $5 上 $4 的 $3 文件中。"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH 密钥 $0 将会在剩余的会话中可用，也可以在登录到其他主机时可用。"
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "登录到 $0 的 SSH 密钥是受密码保护的，主机不允许使用密码登录。请在 $1 提供密钥的密码。"
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "登录到 $0 的 SSH 密钥是受保护的。您可以用您的登录密码或通过在 $1 提供密钥的密码来登录。"
 ],
 "The fingerprint should match:": [
  null,
  "指纹应匹配："
 ],
 "The key password can not be empty": [
  null,
  "密钥密码不能为空"
 ],
 "The key passwords do not match": [
  null,
  "密钥密码不匹配"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "登陆的用户没有权限查看系统改变"
 ],
 "The password can not be empty": [
  null,
  "密钥密码不能为空"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "结果指纹可以通过公共方法（包括电子邮件）共享。"
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "生成的指纹可以通过公共方法（包括电子邮件）共享。如果您需要其他人为您进行验证，他们可以使用任何方法发送结果。"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "服务器拒绝使用任何支持的方式来验证。"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "这个工具配置 SELinux 策略，帮助理解和解决策略违规。"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "这个工具将系统配置为写内核崩溃转储。它支持\"local\" (磁盘)、\"ssh\"和\"nfs\"转储目标。"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "此工具从正在运行的系统中生成配置和诊断信息的存档。出于记录或跟踪目的，存档可能被存储在本地或集中存储，或者被发送到技术支持代表、开发人员或系统管理员，以帮助技术故障查找和调试。"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "此工具管理本地存储，如文件系统、LVM2 卷组和 NFS 挂载。"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "此工具使用 NetworkManager 和 Firewalld 管理网络，如绑定、网桥、组合、VLAN 和防火墙等。NetworkManager 与 Ubuntu 默认的 systemd-networkd 以及 Debian 的 ifupdown 脚本不兼容。"
 ],
 "Time zone": [
  null,
  "时区"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "要确保您的连接没有被恶意第三方截取，请验证主机密钥指纹："
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "要验证指纹，在 $0 上运行以下内容（在实际的物理机器上本地进行，或通过一个可信任的网络进行）："
 ],
 "Toggle date picker": [
  null,
  "切换日期选择器"
 ],
 "Too much data": [
  null,
  "太多数据"
 ],
 "Total size: $0": [
  null,
  "总大小：$0"
 ],
 "Tower": [
  null,
  "Tower"
 ],
 "Trust and add host": [
  null,
  "信任并添加主机"
 ],
 "Trying to synchronize with $0": [
  null,
  "正在尝试与 $0 同步"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "无法使用 SSH 密钥身份验证登录到 $0。请提供密码。"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "无法登录到 $0 。主机不接受密码登录，或您的任何 SSH 密钥。"
 ],
 "Unknown": [
  null,
  "未知"
 ],
 "Unknown application": [
  null,
  "未知应用"
 ],
 "Unknown host: $0": [
  null,
  "未知主机：$0"
 ],
 "Untrusted host": [
  null,
  "不可信的主机"
 ],
 "Update package information": [
  null,
  "更新软件包信息"
 ],
 "Verify fingerprint": [
  null,
  "验证指纹"
 ],
 "View all logs": [
  null,
  "查看所有日志"
 ],
 "View automation script": [
  null,
  "查看自动化脚本"
 ],
 "View project website": [
  null,
  "查看项目网站"
 ],
 "Visit firewall": [
  null,
  "访问防火墙"
 ],
 "Waiting for other programs to finish using the package manager...": [
  null,
  "正在等待其他程序来结束使用软件包管理器..."
 ],
 "Waiting for other software management operations to finish": [
  null,
  "等待其他软件管理操作完成"
 ],
 "Weak password": [
  null,
  "弱密码"
 ],
 "Web Console for Linux servers": [
  null,
  "Linux 服务器的 Web 控制台"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "您第一次连接到 $0。"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "您的浏览器不允许从上下文菜单中进行粘贴，您可以使用 Shift+Insert。"
 ],
 "Your session has been terminated.": [
  null,
  "会话被终止。"
 ],
 "Your session has expired. Please log in again.": [
  null,
  "会话超时。请重新登录。"
 ],
 "Zone": [
  null,
  "区域"
 ],
 "[binary data]": [
  null,
  "[二进制数据]"
 ],
 "[no data]": [
  null,
  "[没有数据]"
 ],
 "in less than a minute": [
  null,
  "少于一分钟"
 ],
 "less than a minute ago": [
  null,
  "少于一分钟前"
 ],
 "password quality": [
  null,
  "密码质量"
 ],
 "show less": [
  null,
  "显示更少"
 ],
 "show more": [
  null,
  "显示更多"
 ]
});
