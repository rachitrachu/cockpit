cockpit.locale({
 "": {
  "plural-forms": (n) => n==0 ? 0 : n==1 ? 1 : n==2 ? 2 : n%100>=3 && n%100<=10 ? 3 : n%100>=11 ? 4 : 5,
  "language": "ar",
  "language-direction": "rtl"
 },
 "Applications": [
  null,
  "التطبيقات"
 ],
 "Diagnostic reports": [
  null,
  "تقارير التشخيص"
 ],
 "Kernel dump": [
  null,
  "عطب نواة النظام"
 ],
 "Networking": [
  null,
  "التشبيك"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "التخزين"
 ],
 "add-on": [
  null,
  "وظيفة إضافية"
 ],
 "addon": [
  null,
  "الوظيفة الإضافية"
 ],
 "apps": [
  null,
  "تطبيقات"
 ],
 "extension": [
  null,
  "إمتداد"
 ],
 "install": [
  null,
  "ثبِّت"
 ],
 "plugin": [
  null,
  "ملحق"
 ]
});
