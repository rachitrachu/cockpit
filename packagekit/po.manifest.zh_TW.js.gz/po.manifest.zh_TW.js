cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "zh_TW",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "診斷報告"
 ],
 "Kernel dump": [
  null,
  "核心傾印"
 ],
 "Managing software updates": [
  null,
  "管理軟體更新"
 ],
 "Networking": [
  null,
  "網路"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Software updates": [
  null,
  "軟體更新"
 ],
 "Storage": [
  null,
  "儲存裝置"
 ],
 "apt-get": [
  null,
  "apt-get"
 ],
 "dnf": [
  null,
  "dnf"
 ],
 "kpatch": [
  null,
  "kpatch"
 ],
 "package": [
  null,
  "軟體包"
 ],
 "packagekit": [
  null,
  "packagekit"
 ],
 "security": [
  null,
  "安全性"
 ],
 "updates": [
  null,
  "更新"
 ],
 "yum": [
  null,
  "yum"
 ]
});
