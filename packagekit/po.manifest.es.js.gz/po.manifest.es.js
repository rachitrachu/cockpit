cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "es",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Informes de diagnóstico"
 ],
 "Kernel dump": [
  null,
  "Volcado del kernel"
 ],
 "Managing software updates": [
  null,
  "Gestión de actualizaciones de software"
 ],
 "Networking": [
  null,
  "Redes"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Software updates": [
  null,
  "Actualizaciones de software"
 ],
 "Storage": [
  null,
  "Almacenamiento"
 ],
 "apt-get": [
  null,
  "apt-get"
 ],
 "dnf": [
  null,
  "dnf"
 ],
 "kpatch": [
  null,
  "kparche"
 ],
 "package": [
  null,
  "paquete"
 ],
 "packagekit": [
  null,
  "packagekit"
 ],
 "security": [
  null,
  "seguridad"
 ],
 "updates": [
  null,
  "actualizaciones"
 ],
 "yum": [
  null,
  "yum"
 ]
});
