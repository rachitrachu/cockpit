cockpit.locale({
 "": {
  "plural-forms": (n) => n==0 ? 0 : n==1 ? 1 : n==2 ? 2 : n%100>=3 && n%100<=10 ? 3 : n%100>=11 ? 4 : 5,
  "language": "ar",
  "language-direction": "rtl"
 },
 "Diagnostic reports": [
  null,
  "تقارير التشخيص"
 ],
 "Kernel dump": [
  null,
  "عطب نواة النظام"
 ],
 "Managing software updates": [
  null,
  "إدارة تحديثات التطبيقات"
 ],
 "Networking": [
  null,
  "التشبيك"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Software updates": [
  null,
  "تحديثات التطبيق"
 ],
 "Storage": [
  null,
  "التخزين"
 ],
 "apt-get": [
  null,
  "apt-get"
 ],
 "dnf": [
  null,
  "dnf"
 ],
 "kpatch": [
  null,
  "كباتش"
 ],
 "package": [
  null,
  "حزمة"
 ],
 "packagekit": [
  null,
  "packagekit"
 ],
 "security": [
  null,
  "الأمان"
 ],
 "updates": [
  null,
  "تحديثات"
 ],
 "yum": [
  null,
  "yum"
 ]
});
