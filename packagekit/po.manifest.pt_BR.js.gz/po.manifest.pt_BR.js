cockpit.locale({
 "": {
  "plural-forms": (n) => (n != 1),
  "language": "pt_BR",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Relatório de diagnostico"
 ],
 "Kernel dump": [
  null,
  "Dump do kernel"
 ],
 "Managing software updates": [
  null,
  "Gerenciando atualizações de software"
 ],
 "Networking": [
  null,
  "Rede"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Software updates": [
  null,
  "Atualizações de Software"
 ],
 "Storage": [
  null,
  "Armazenamento"
 ],
 "dnf": [
  null,
  "dnf"
 ],
 "kpatch": [
  null,
  "kpatch"
 ],
 "package": [
  null,
  "pacote"
 ],
 "packagekit": [
  null,
  "packagekit"
 ],
 "security": [
  null,
  "segurança"
 ],
 "updates": [
  null,
  "atualizações"
 ],
 "yum": [
  null,
  "yum"
 ]
});
