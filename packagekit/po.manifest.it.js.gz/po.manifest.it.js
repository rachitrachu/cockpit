cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "it",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Rapporti diagnostici"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Managing software updates": [
  null,
  "Gestione degli aggiornamenti software"
 ],
 "Networking": [
  null,
  "Rete"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Software updates": [
  null,
  "Aggiornamenti software"
 ],
 "Storage": [
  null,
  "Archiviazione"
 ],
 "apt-get": [
  null,
  "apt-get"
 ],
 "dnf": [
  null,
  "dnf"
 ],
 "kpatch": [
  null,
  "kpatch"
 ],
 "package": [
  null,
  "pacchetto"
 ],
 "packagekit": [
  null,
  "packagekit"
 ],
 "security": [
  null,
  "sicurezza"
 ],
 "updates": [
  null,
  "aggiornamenti"
 ],
 "yum": [
  null,
  "yum"
 ]
});
