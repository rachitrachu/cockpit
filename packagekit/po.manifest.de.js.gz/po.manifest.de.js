cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "de",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Diagnoseberichte"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Managing software updates": [
  null,
  "Software-Aktualisierungen verwalten"
 ],
 "Networking": [
  null,
  "Netzwerk"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Software updates": [
  null,
  "Aktualisierungen"
 ],
 "Storage": [
  null,
  "Speicher"
 ],
 "apt-get": [
  null,
  "apt-get"
 ],
 "dnf": [
  null,
  "dnf"
 ],
 "kpatch": [
  null,
  "kpatch"
 ],
 "package": [
  null,
  "Paket"
 ],
 "packagekit": [
  null,
  "packagekit"
 ],
 "security": [
  null,
  "Sicherheit"
 ],
 "updates": [
  null,
  "Aktualisierungen"
 ],
 "yum": [
  null,
  "yum"
 ]
});
