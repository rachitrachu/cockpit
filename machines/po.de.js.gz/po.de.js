cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "de",
  "language-direction": "ltr"
 },
 "$0 $1 available at default location": [
  null,
  "$0 $1 am Standardort verfügbar"
 ],
 "$0 $1 available on host": [
  null,
  "$0 $1 auf dem Host verfügbar"
 ],
 "$0 CPU details": [
  null,
  "$0 CPU-Details"
 ],
 "$0 Network": [
  null,
  "$0 Netzwerk",
  "$0 Netzwerke"
 ],
 "$0 Storage pool": [
  null,
  "$0 Storage Pool",
  "$0 Storage Pools"
 ],
 "$0 does not support unattended installation.": [
  null,
  "$0 unterstützt keine unbeaufsichtigte Installation."
 ],
 "$0 memory adjustment": [
  null,
  "$0 Speicher-Anpassung"
 ],
 "$0 network": [
  null,
  "$0 Netzwerk"
 ],
 "$0 vCPU": [
  null,
  "$0 vCPU",
  "$0 vCPUs"
 ],
 "$0 virtual network interface settings": [
  null,
  "$0 Virtuelle Netzwerkschnittstelle hinzufügen"
 ],
 "A copy of the VM will run on the destination and will disappear when it is shut off. Meanwhile, the origin host keeps its copy of the VM configuration.": [
  null,
  "Eine Kopie der VM wird auf dem Zielhost ausgeführt und verschwindet, wenn dieser ausgeschaltet wird. In der Zwischenzeit behält der ursprüngliche Host seine Kopie der VM-Konfiguration."
 ],
 "Access": [
  null,
  "Zugriff"
 ],
 "Action": [
  null,
  "Aktion"
 ],
 "Actions": [
  null,
  "Aktionen"
 ],
 "Activate": [
  null,
  "Aktivieren"
 ],
 "Activate the storage pool to administer volumes": [
  null,
  "Aktivieren Sie den Speicher-Pool zum Verwalten von Datenträgern"
 ],
 "Add": [
  null,
  "Hinzufügen"
 ],
 "Add SSH keys": [
  null,
  "SSH-Schlüssel hinzufügen"
 ],
 "Add TPM": [
  null,
  "TPM hinzufügen"
 ],
 "Add VNC": [
  null,
  "VNC hinzufügen"
 ],
 "Add a DHCP static host entry": [
  null,
  "Statischen DHCP-Host-Eintrag hinzufügen"
 ],
 "Add disk": [
  null,
  "Festplatte hinzufügen"
 ],
 "Add host device": [
  null,
  "Host-Gerät hinzufügen"
 ],
 "Add network interface": [
  null,
  "Netzwerkschnittstelle hinzufügen"
 ],
 "Add serial console": [
  null,
  "Serielle Konsole hinzufügen"
 ],
 "Add shared directory": [
  null,
  "Geteiltes Verzeichnis hinzufügen"
 ],
 "Add virtual network interface": [
  null,
  "Virtuelle Netzwerkschnittstelle hinzufügen"
 ],
 "Add vsock interface": [
  null,
  "vsock-schnittstelle hinzufügen"
 ],
 "Add watchdog device type": [
  null,
  "Watchdog-Gerätetyp hinzufügen"
 ],
 "Adding a watchdog will require a reboot to take effect.": [
  null,
  "Hinzufügen eines Watchdogs erfordert einen Neustart zur Aktivierung."
 ],
 "Adding shared directories is possible only when the guest is shut off": [
  null,
  "Geteiltes Verzeichnis kann nur hinzugefügt werden wenn Gast ausgeschaltet ist"
 ],
 "Additional": [
  null,
  "Mehr"
 ],
 "Address": [
  null,
  "Adresse"
 ],
 "Address not within subnet": [
  null,
  "Adresse befindet sich nicht im Subnetz"
 ],
 "All": [
  null,
  "Alle"
 ],
 "All VM activity, including storage, will be temporary. This will result in data loss on the destination host.": [
  null,
  "Alle VM-Aktivitäten, einschließlich der Speicherung, sind temporär. Dies führt zu einem Datenverlust auf dem Zielhost."
 ],
 "Allowed characters: basic Latin alphabet, numbers, and limited punctuation (-, _, +, .)": [
  null,
  "Erlaubte Zeichen: lateinisches Grundalphabet, Zahlen und begrenzte Satzzeichen (-, _, +, .)"
 ],
 "Also delete all volumes inside this pool:": [
  null,
  "Löschen aller Datenträger innerhalb dieses Pools:"
 ],
 "Always attach": [
  null,
  "Immer verbinden"
 ],
 "An example of vsock-aware software is socat": [
  null,
  "Ein Beispiel für vsock-fähiger Software ist socat"
 ],
 "Apply": [
  null,
  "Anwenden"
 ],
 "Apply on next boot": [
  null,
  "Beim nächsten Bootvorgang anwenden"
 ],
 "Assign automatically": [
  null,
  "Automatisch zuweisen"
 ],
 "Automated installs are only available when downloading an image or using cloud-init.": [
  null,
  "Automatisierte Installationen sind nur verfügbar, wenn Sie ein Abbild herunterladen oder cloud-init verwenden."
 ],
 "Automatic": [
  null,
  "Automatisch"
 ],
 "Automation": [
  null,
  "Automatisierung"
 ],
 "Autostart": [
  null,
  "Autostart"
 ],
 "Block device": [
  null,
  "Blockorientiertes Gerät"
 ],
 "Blocked": [
  null,
  "Gesperrt"
 ],
 "Boot order": [
  null,
  "Boot-Reihenfolge"
 ],
 "Boot order settings could not be saved": [
  null,
  "Boot-Reihenfolge konnte nicht gespeichert werden"
 ],
 "Bus": [
  null,
  "Bus"
 ],
 "CD/DVD disc": [
  null,
  "CD/DVD"
 ],
 "CPU": [
  null,
  "Prozessor"
 ],
 "CPU mode could not be saved": [
  null,
  "CPU-Modus konnte nicht gespeichert werden"
 ],
 "Cache": [
  null,
  "Cache"
 ],
 "Cancel": [
  null,
  "Abbrechen"
 ],
 "Cannot edit vsock device on a transient VM": [
  null,
  "Bearbeiten des vsock-Geräts ist bei einer transienten VM nicht möglich"
 ],
 "Cannot edit watchdog device on a transient VM": [
  null,
  "Watchdog-Gerät einer transienten VM kann nicht bearbeitet werden"
 ],
 "Capacity": [
  null,
  "Kapazität"
 ],
 "Change boot order": [
  null,
  "Boot-Reihenfolge ändern"
 ],
 "Change firmware": [
  null,
  "Firmware ändern"
 ],
 "Changes pending": [
  null,
  "Änderungen ausstehend"
 ],
 "Changes will take effect after shutting down the VM": [
  null,
  "Änderungen werden nach dem Herunterfahren der VM wirksam"
 ],
 "Changing BIOS/EFI settings is specific to each manufacturer. It involves pressing a hotkey during boot (ESC, F1, F12, Del). Enable a setting called \"virtualization\", \"VM\", \"VMX\", \"SVM\", \"VTX\", \"VTD\". Consult your computer's manual for details.": [
  null,
  "Der Zugriff auf die BIOS/EFI Einstellungen ist herstellerabhängig. Dazu muss eine Taste während des Bootprozesses gedrückt werden (ESC, F1, F12, Entf). Aktivieren Sie die Einstellung für \"virtualization\", \"VM\", \"VMX\", \"SVM\", \"VTX\", \"VTD\". Weitere Details finden Sie in der Anleitung Ihres Computers."
 ],
 "Checking token validity...": [
  null,
  "Token-Gültigkeit wird geprüft ..."
 ],
 "Choose an operating system": [
  null,
  "Betriebssystem auswählen"
 ],
 "Class": [
  null,
  "Klasse"
 ],
 "Clicking \"Launch viewer\" will download a $0 file and launch the Remote Viewer application on your system.": [
  null,
  ""
 ],
 "Clone": [
  null,
  "Klonen"
 ],
 "Close": [
  null,
  "Schließen"
 ],
 "Cloud base image": [
  null,
  "Cloud-Basis-Image"
 ],
 "Compress": [
  null,
  "Komprimieren"
 ],
 "Concurrently writeable": [
  null,
  "Gleichzeitig schreibbar"
 ],
 "Confirm this action": [
  null,
  "Aktion bestätigen"
 ],
 "Connect": [
  null,
  "Verbinden"
 ],
 "Connection": [
  null,
  "Verbindung"
 ],
 "Console": [
  null,
  "Konsole"
 ],
 "Convert QXL video card to VGA": [
  null,
  "QXL-Grafikkarte in VGA konvertieren"
 ],
 "Convert SPICE graphics console to VNC": [
  null,
  "SPICE-Grafikkonsole in VNC konvertieren"
 ],
 "Copy storage": [
  null,
  "Speicher kopieren"
 ],
 "Copy to clipboard": [
  null,
  "In Zwischenablage kopieren"
 ],
 "Cores per socket": [
  null,
  "Kerne pro Socket"
 ],
 "Could not delete $0": [
  null,
  "$0 konnte nicht gelöscht werden"
 ],
 "Could not delete all storage for $0": [
  null,
  "Gesamter Speicher für $0 konnte nicht gelöscht werden"
 ],
 "Could not delete disk's storage": [
  null,
  "Festplattenspeicher konnte nicht gelöscht werden"
 ],
 "Could not dynamically add watchdog": [
  null,
  "Watchdog konnte nicht dynamisch hinzugefügt werden"
 ],
 "Could not revert to snapshot": [
  null,
  "Konnte den Schnappschuss nicht zurücksetzen"
 ],
 "Crashed": [
  null,
  "Abgestürzt"
 ],
 "Create": [
  null,
  "Erstellen"
 ],
 "Create VM": [
  null,
  "VM erstellen"
 ],
 "Create VM by importing a disk image of an existing VM installation": [
  null,
  "Erstellen einer VM durch Importieren eines Festplattenabbildes einer bestehenden VM-Installation"
 ],
 "Create VM from local or network installation medium": [
  null,
  "Erstellen einer VM von einem lokalen oder Netzwerk-Installationsmedium"
 ],
 "Create a clone VM based on $0": [
  null,
  "Eine Klon-VM basierend auf $0 erstellen"
 ],
 "Create and edit": [
  null,
  "Erstellen und bearbeiten"
 ],
 "Create and run": [
  null,
  "Erstellen und ausführen"
 ],
 "Create new": [
  null,
  "Neu erstellen"
 ],
 "Create new qcow2 volume": [
  null,
  "Neues qcow2-Volume ersttellen"
 ],
 "Create new raw volume": [
  null,
  "Neuen Raw Datenträger erstellen"
 ],
 "Create new virtual machine": [
  null,
  "Neue Virtuelle Maschine erstellen"
 ],
 "Create snapshot": [
  null,
  "Snapshot erzeugen"
 ],
 "Create storage pool": [
  null,
  "Erstellen Sie einen Speicherpool"
 ],
 "Create storage volume": [
  null,
  "Datenträger erstellen"
 ],
 "Create virtual network": [
  null,
  "Erstelle Virtuelles Netzwerk"
 ],
 "Create volume": [
  null,
  "Volume erzeugen"
 ],
 "Creating VM": [
  null,
  "VM erstellen"
 ],
 "Creating VM $0": [
  null,
  "VM $0 erstellen"
 ],
 "Creating snapshots of VMs with VFIO devices is not supported while they are running.": [
  null,
  "Das Erstellen von Schnappschüssen von VMs mit VFIO-Geräten wird nicht unterstützt, während sie ausgeführt werden."
 ],
 "Creation of VM $0 failed": [
  null,
  "Das Erstellen von VM $0 ist fehlgeschlagen"
 ],
 "Creation time": [
  null,
  "Erstellungszeit"
 ],
 "Ctrl+Alt+$0": [
  null,
  "Strg + Alt +$0"
 ],
 "Current": [
  null,
  "Aktuell"
 ],
 "Current allocation": [
  null,
  "aktuelle Zuweisung"
 ],
 "Custom firmware: $0": [
  null,
  "Benutzerdefinierte Firmware: $0"
 ],
 "Custom identifier": [
  null,
  "Benutzerdefinierter Bezeichner"
 ],
 "Custom path": [
  null,
  "Benutzerdefinierter Pfad"
 ],
 "DHCP Settings": [
  null,
  "DHCP-Einstellungen"
 ],
 "Deactivate": [
  null,
  "Deaktivieren"
 ],
 "Delete": [
  null,
  "Löschen"
 ],
 "Delete $0 VM?": [
  null,
  "$0 VM löschen?"
 ],
 "Delete $0 storage pool?": [
  null,
  "Speicher-Pool $0 löschen?"
 ],
 "Delete $0 volume": [
  null,
  "$0 Datenträger löschen",
  "Datenträger $0 löschen"
 ],
 "Delete associated storage files:": [
  null,
  "Verknüpfte Speicherdateien löschen:"
 ],
 "Delete network?": [
  null,
  "Netzwerk löschen?"
 ],
 "Delete snapshot?": [
  null,
  "Schnappschuss löschen?"
 ],
 "Deleting an inactive storage pool will only undefine the pool. Its content will not be deleted.": [
  null,
  "Das Löschen eines inaktiven Speicher-Pools entfernt nur seine Definition. Der Inhalt wird nicht gelöscht."
 ],
 "Deleting shared directories is possible only when the guest is shut off": [
  null,
  "Das Löschen von gemeinsamen Verzeichnissen ist nur möglich, wenn der Gast ausgeschaltet ist"
 ],
 "Description": [
  null,
  "Beschreibung"
 ],
 "Deselect others": [
  null,
  "Andere abwählen"
 ],
 "Destination URI": [
  null,
  "Ziel-URI"
 ],
 "Destination URI must not be empty": [
  null,
  "Ziel-URI darf nicht leer sein"
 ],
 "Detach the disks using this pool from any VMs before attempting deletion.": [
  null,
  "Entfernen der Festplatten, die diesen Pool verwenden, von allen VMs vor der Löschung."
 ],
 "Details": [
  null,
  "Details"
 ],
 "Device": [
  null,
  "Gerät"
 ],
 "Devices": [
  null,
  "Geräte"
 ],
 "Disconnect": [
  null,
  "Verbindung trennen"
 ],
 "Disconnected": [
  null,
  "Getrennt"
 ],
 "Disconnected from serial console. Click the connect button.": [
  null,
  "Verbindung zur seriellen Konsole getrennt Klicken Sie auf die Schaltfläche 'Neu verbinden'."
 ],
 "Disk": [
  null,
  "Festplatten"
 ],
 "Disk $0 could not be removed": [
  null,
  "Festplatte $0 konnte nicht entfernt werden"
 ],
 "Disk failed to be added": [
  null,
  "Festplatte konnte nicht hinzugefügt werden"
 ],
 "Disk identifier": [
  null,
  "Festplattenbezeichner"
 ],
 "Disk image": [
  null,
  "Festplattenabbild"
 ],
 "Disk image file": [
  null,
  "Festplattenabbilddatei"
 ],
 "Disk image path must not be empty": [
  null,
  "Festplattenabbildpfad darf nicht leer sein"
 ],
 "Disk images can be stored in user home directory": [
  null,
  "Festplattenabbilder können im Home-Verzeichnis des Benutzers gespeichert werden"
 ],
 "Disk settings could not be saved": [
  null,
  "Festplatten-Einstellungen konnten nicht gespeichert werden"
 ],
 "Disk-only snapshot": [
  null,
  "Nur-Festplatten-Schnappschuss"
 ],
 "Disks": [
  null,
  "Festplatten"
 ],
 "Do not run this VM on the origin and destination hosts at the same time.": [
  null,
  "Führen Sie diese VM nicht gleichzeitig auf dem Ursprungs- und dem Zielhost aus."
 ],
 "Do nothing": [
  null,
  "Nichts machen"
 ],
 "Domain has crashed": [
  null,
  "Domain ist abgestürzt"
 ],
 "Domain is blocked on resource": [
  null,
  "Domain ist durch Resource blockiert"
 ],
 "Download an OS": [
  null,
  "Ein Betriebssystem herunterladen"
 ],
 "Download progress": [
  null,
  "Fortschritt beim Herunterladen"
 ],
 "Download the MSI from $0": [
  null,
  "MSI von $0 herunterladen"
 ],
 "Downloading image for VM $0": [
  null,
  "Abbild für VM $0 wird heruntergeladen"
 ],
 "Downloading: $0%": [
  null,
  "Herunterladen: $0%"
 ],
 "Dump core": [
  null,
  "Coredump ausführen"
 ],
 "Duration": [
  null,
  "Dauer"
 ],
 "Dying": [
  null,
  "Sterbend"
 ],
 "Edit": [
  null,
  "Bearbeiten"
 ],
 "Edit $0 attributes": [
  null,
  "$0 Attribute bearbeiten"
 ],
 "Edit VNC settings": [
  null,
  "VNC-Einstellungen bearbeiten"
 ],
 "Edit description": [
  null,
  "Beschreibung bearbeiten"
 ],
 "Edit description of VM $0": [
  null,
  "Beschreibung VM $0 bearbeiten"
 ],
 "Edit vsock interface": [
  null,
  "vsock-Schnittstelle bearbeiten"
 ],
 "Edit watchdog device type": [
  null,
  "Watchdog Gerätetyp bearbeiten"
 ],
 "Editing network interfaces of transient guests is not allowed": [
  null,
  "Die Bearbeitung von Netzwerkschnittstellen vorübergehender Gäste ist nicht erlaubt"
 ],
 "Editing transient network interfaces is not allowed": [
  null,
  "Die Bearbeitung vorübergehender Netzwerkschnittstellen ist nicht erlaubt"
 ],
 "Eject": [
  null,
  "Auswerfen"
 ],
 "Eject disc from VM?": [
  null,
  "Disk aus VM auswerfen?"
 ],
 "Emulated machine": [
  null,
  "Emulierte Maschine"
 ],
 "Enable virtualization support in BIOS/EFI settings.": [
  null,
  "Aktivieren der Virtualisierungsunterstützung in den BIOS/EFI-Einstellungen."
 ],
 "End": [
  null,
  "Ende"
 ],
 "End should not be empty": [
  null,
  "Das Ende sollte nicht leer sein"
 ],
 "Enter root and/or user information to enable unattended installation.": [
  null,
  "Geben Sie root- und/oder Benutzerinformationen ein, um eine unbeaufsichtigte Installation zu aktivieren."
 ],
 "Error checking token": [
  null,
  "Fehler bei der Prüfung des Tokens"
 ],
 "Example, $0": [
  null,
  "Beispiel, $0"
 ],
 "Existing disk image on host's file system": [
  null,
  "Existierendes Festplattenabbild auf dem Dateisystem des Hosts"
 ],
 "Expand": [
  null,
  "Erweitern"
 ],
 "Extended attributes": [
  null,
  "Erweiterte Attribute"
 ],
 "Failed": [
  null,
  "Fehlgeschlagen"
 ],
 "Failed to add TPM to VM $0": [
  null,
  "Fehler beim Hinzufügen des TPM zur VM $0"
 ],
 "Failed to add VNC to VM $0": [
  null,
  "Fehler beim Hinzufügen von VNC zur VM $0"
 ],
 "Failed to add serial console to VM $0": [
  null,
  "Fehler beim Hinzufügen der seriellen Konsole zur VM $0"
 ],
 "Failed to add shared directory": [
  null,
  "Fehler beim Hinzufügen eines gemeinsamen Verzeichnisses"
 ],
 "Failed to change firmware": [
  null,
  "Firmware konnte nicht geändert werden"
 ],
 "Failed to clone VM $0": [
  null,
  "Fehler beim Klonen von VM $0"
 ],
 "Failed to configure vsock": [
  null,
  "Fehler beim Konfigurieren von vsock"
 ],
 "Failed to configure watchdog": [
  null,
  "Fehler bei der Watchdog-Konfiguration"
 ],
 "Failed to detach vsock": [
  null,
  "Fehler bei der Ablösung von vsock"
 ],
 "Failed to detach watchdog": [
  null,
  "Fehler bei der Abtrennung des Watchdogs"
 ],
 "Failed to fetch some resources": [
  null,
  "Fehler beim Abrufen einiger Ressourcen"
 ],
 "Failed to fetch the IP addresses of the interfaces present in $0": [
  null,
  "IP-Adresse der Schnittstellen in $0 können nicht bezogen werden"
 ],
 "Failed to rename VM $0": [
  null,
  "Fehler beim Umbenennen von VM $0"
 ],
 "Failed to replace SPICE devices": [
  null,
  "Fehler beim Ersetzen von SPICE-Geräten"
 ],
 "Failed to save network settings": [
  null,
  "Fehler beim Speichern der Netzwerkeinstellungen"
 ],
 "Failed to send key Ctrl+Alt+$0 to VM $1": [
  null,
  "Senden der Tastenkombination Strg+Alt+$0 an die VM $1 fehlgeschlagen"
 ],
 "Failed to set description of VM $0": [
  null,
  "Fehler beim Festlegen der Beschreibung von der VM $0"
 ],
 "Fewer than the maximum number of virtual CPUs should be enabled.": [
  null,
  "Es sollte weniger als die maximale Anzahl virtueller CPUs aktiviert sein."
 ],
 "File": [
  null,
  "Datei"
 ],
 "Filesystem $0 could not be removed": [
  null,
  "Dateisystem $0 konnte nicht entfernt werden"
 ],
 "Filesystem directory": [
  null,
  "Dateisystemverzeichnis"
 ],
 "Filter by name": [
  null,
  "Nach Namen filtern"
 ],
 "Firmware": [
  null,
  "Firmware"
 ],
 "Force eject": [
  null,
  "Auswerfen erzwingen"
 ],
 "Force reboot": [
  null,
  "Neustart erzwingen"
 ],
 "Force reboot $0?": [
  null,
  "Neustart von $0 erzwingen?"
 ],
 "Force revert": [
  null,
  "Rücknahme erzwingen"
 ],
 "Force shut down": [
  null,
  "Herunterfahren erzwingen"
 ],
 "Force shut down $0?": [
  null,
  "Herunterfahren von $0 erzwingen?"
 ],
 "Format": [
  null,
  "Formatieren"
 ],
 "Forward mode": [
  null,
  "Weiterleitungs-Modus"
 ],
 "Forwarding mode": [
  null,
  "Weiterleitungs-Modus"
 ],
 "Full disk images and the domain's memory will be migrated. Only non-shared, writable disk images will be transferred. Unused storage will remain on the origin after migration.": [
  null,
  "Es werden vollständige Festplattenabbilder und der Speicher der Domäne migriert. Es werden nur nicht gemeinsam genutzte, beschreibbare Festplattenabbilder übertragen. Ungenutzter Speicherplatz verbleibt nach der Migration auf dem Ursprung."
 ],
 "General": [
  null,
  "Allgemein"
 ],
 "Generate automatically": [
  null,
  "Automatisch generieren"
 ],
 "Get a new RHSM token.": [
  null,
  "Ein neues RHSM-Token erhalten."
 ],
 "GiB": [
  null,
  "GiB"
 ],
 "Go to VMs list": [
  null,
  "Zur VM-Liste gehen"
 ],
 "Good choice for desktop virtualization": [
  null,
  "Gute Wahl für die Desktop-Virtualisierung"
 ],
 "Gracefully shutdown": [
  null,
  "Anständig herunterfahren"
 ],
 "Graphical": [
  null,
  "Grafisch"
 ],
 "Graphical console support not enabled": [
  null,
  "Unterstützung der grafischen Konsole nicht aktiviert"
 ],
 "Hardware virtualization is disabled": [
  null,
  "Hardware-Virtualisierung ist deaktiviert"
 ],
 "Hide additional options": [
  null,
  "Zusätzlichen Einstellungen verstecken"
 ],
 "Host": [
  null,
  "Host"
 ],
 "Host device": [
  null,
  "Host-Gerät"
 ],
 "Host device could not be attached": [
  null,
  "Host-Gerät konnte nicht angehängt werden"
 ],
 "Host device will be removed from $0:": [
  null,
  "Das Host-Gerät wird von $0 entfernt:"
 ],
 "Host devices": [
  null,
  "Host-Geräte"
 ],
 "Host name": [
  null,
  "Rechnername"
 ],
 "Host should not be empty": [
  null,
  "Host sollte nicht leer sein"
 ],
 "Hypervisor details": [
  null,
  "Hypervisor-Details"
 ],
 "ID": [
  null,
  "ID"
 ],
 "IP": [
  null,
  "IP"
 ],
 "IP address": [
  null,
  "IP-Adresse"
 ],
 "IP address must not be empty": [
  null,
  "IP-Adresse darf nicht leer sein"
 ],
 "IP configuration": [
  null,
  "IP-Konfiguration"
 ],
 "IPv4 address": [
  null,
  "IPv4-Adresse"
 ],
 "IPv4 address cannot be same as the network's broadcast address": [
  null,
  "Die IPv4-Adresse darf nicht mit der Netzwerk-Broadcastadresse übereinstimmen"
 ],
 "IPv4 and IPv6": [
  null,
  "IPv4 und IPv6"
 ],
 "IPv4 network should not be empty": [
  null,
  "IPv4-Netzwerk sollte nicht leer sein"
 ],
 "IPv4 only": [
  null,
  "Nur IPv4"
 ],
 "IPv4 prefix length must be 24 or less": [
  null,
  "IPv4-Präfixlänge muss 24 oder weniger sein"
 ],
 "IPv4 prefix length must be a multiple of 8": [
  null,
  "IPv4-Präfixlänge muss ein Vielfaches von 8 sein"
 ],
 "IPv6 address": [
  null,
  "IPv6-Adresse"
 ],
 "IPv6 network should not be empty": [
  null,
  "IPv6-Netzwerk sollte nicht leer sein"
 ],
 "IPv6 only": [
  null,
  "Nur IPv6"
 ],
 "Ideal for server VMs": [
  null,
  "Ideal für Server-VMs"
 ],
 "Ideal networking support": [
  null,
  "Ideale Unterstützung bei der Vernetzung"
 ],
 "Identifier in use by $0. VMs with an identical identifier cannot run at the same time.": [
  null,
  "Kennung, die von $0 verwendet wird. VMs mit einer identischen Kennung können nicht gleichzeitig ausgeführt werden."
 ],
 "Identifier may be silently truncated to $0 characters ": [
  null,
  "Der Bezeichner kann stillschweigend auf $0 Zeichen gekürzt werden. "
 ],
 "Idle": [
  null,
  "Untätig"
 ],
 "Ignore": [
  null,
  "Ignorieren"
 ],
 "Import VM": [
  null,
  "VM importieren"
 ],
 "Import a virtual machine": [
  null,
  "Virtuelle Maschine importieren"
 ],
 "Import and edit": [
  null,
  "Importieren und bearbeiten"
 ],
 "Import and run": [
  null,
  "Importieren und ausführen"
 ],
 "Importing an image with a backing file is unsupported": [
  null,
  "Import eines Abbildes mit einer Backing-Datei wird nicht unterstützt"
 ],
 "In most configurations, macvtap does not work for host to guest network communication.": [
  null,
  "In den meisten Konfigurationen funktioniert macvtap nicht für die Kommunikation zwischen Host und Gast im Netzwerk."
 ],
 "Initiator": [
  null,
  "Initiator"
 ],
 "Initiator should not be empty": [
  null,
  "Initiator sollte nicht leer sein"
 ],
 "Inject a non-maskable interrupt": [
  null,
  "Nicht-maskierbaren Interrupt injizieren"
 ],
 "Insert": [
  null,
  "Einfügen"
 ],
 "Insert disc media": [
  null,
  "Disc-Medium einlegen"
 ],
 "Inside the VM": [
  null,
  "Innerhalb der VM"
 ],
 "Install": [
  null,
  "Installation"
 ],
 "Installation source": [
  null,
  "Installationsquelle"
 ],
 "Installation source must not be empty": [
  null,
  "Installationsquelle sollte nicht leer sein"
 ],
 "Installation type": [
  null,
  "Installationstyp"
 ],
 "Interface": [
  null,
  "Schnittstelle"
 ],
 "Interface type": [
  null,
  "Art der Schnittstelle"
 ],
 "Interface type help": [
  null,
  "Hilfe zum Schnittstellentyp"
 ],
 "Invalid IPv4 address": [
  null,
  "Ungültige IPv4-Adresse"
 ],
 "Invalid IPv4 mask or prefix length": [
  null,
  "Ungültige IPv4-Maske oder Prefix-Länge"
 ],
 "Invalid IPv6 address": [
  null,
  "Ungültige IPv6-Adresse"
 ],
 "Invalid IPv6 prefix": [
  null,
  "Ungültiger IPv6-Prefix"
 ],
 "Invalid filename": [
  null,
  "Ungültiger Dateiname"
 ],
 "Isolated network": [
  null,
  "Isoliertes Netzwerk"
 ],
 "It can also be used to enable the inline graphical console in the browser, which does not support SPICE.": [
  null,
  "Es kann auch verwendet werden, um die grafische Inline-Konsole im Browser zu aktivieren, die SPICE nicht unterstützt."
 ],
 "Keys are located in ~/.ssh/ and have a \".pub\" extension.": [
  null,
  "Die Schlüssel befinden sich in ~/.ssh/ und haben die Erweiterung „.pub“."
 ],
 "LVM volume group": [
  null,
  "LVM Speichergruppe (VG)"
 ],
 "Launch viewer": [
  null,
  "Betrachter starten"
 ],
 "Leave the password blank if you do not wish to have a root account created": [
  null,
  "Lassen Sie das Passwort leer, wenn Sie kein Root-Konto erstellen möchten"
 ],
 "Leave the password blank if you do not wish to have a user account created": [
  null,
  "Lassen Sie das Passwort leer, wenn Sie kein Benutzerkonto erstellen lassen möchten"
 ],
 "Leave the password blank if you do not wish to set a root password": [
  null,
  "Lassen Sie das Passwort leer, wenn Sie kein Root-Passwort festlegen möchten"
 ],
 "Libvirt did not detect any UEFI/OVMF firmware image installed on the host": [
  null,
  "Libvirt hat kein UEFI/OVMF Firmware-Abbild auf dem Host-System gefunden"
 ],
 "Libvirt or hypervisor does not support UEFI": [
  null,
  "Libvirt oder der Hypervisor unterstützen UEFI nicht"
 ],
 "Loading available network devices": [
  null,
  "Verfügbare Netzwerkgeräte werden geladen"
 ],
 "Loading resources": [
  null,
  "Ressourcen werden geladen"
 ],
 "Loading...": [
  null,
  "Wird geladen ..."
 ],
 "Local install media (ISO image or distro install tree)": [
  null,
  "Lokales Installationsmedium (ISO-Abbild oder Distro-Installationsbaum)"
 ],
 "Location": [
  null,
  "Ort"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "MAC address": [
  null,
  "MAC-Adresse"
 ],
 "MAC address already in use": [
  null,
  "Bereits verwendete MAC-Adresse"
 ],
 "MAC address must not be empty": [
  null,
  "MAC-Adresse darf nicht leer sein"
 ],
 "Machine must be shut off before changing bus type": [
  null,
  "Vor dem Wechsel des Bustyps muss die Maschine ausgeschaltet werden"
 ],
 "Machine must be shut off before changing cache mode": [
  null,
  "Zum Ändern des Cache-Mode muss die Maschine muss ausgeschaltet sein"
 ],
 "Mask or prefix length": [
  null,
  "Masken- oder Präfixlänge"
 ],
 "Mask or prefix length should not be empty": [
  null,
  "Masken- oder Präfixlänge sollte nicht leer sein"
 ],
 "Maximum allocation": [
  null,
  "Maximale Zuweisung"
 ],
 "Maximum memory could not be saved": [
  null,
  "Maximaler Speicher konnte nicht gespeichert werden"
 ],
 "Maximum number of virtual CPUs allocated for the guest OS": [
  null,
  "Maximale Anzahl der virtuellen CPUs, die dem Gast-BS zugewiesen werden"
 ],
 "Maximum number of virtual CPUs allocated for the guest OS, which must be between 1 and $0": [
  null,
  "Maximale Anzahl der für das Gastbetriebssystem zugewiesenen virtuellen CPUs, die zwischen 1 und 1 liegen muss $0"
 ],
 "Maximum transmission unit": [
  null,
  "Maximale Übertragungseinheit"
 ],
 "Media could not be ejected from $0": [
  null,
  "Medium konnte nicht aus $0 ausgeworfen werden"
 ],
 "Media will be ejected from $0:": [
  null,
  "Medium wird aus $0 ausgeworfen:"
 ],
 "Memory": [
  null,
  "Speicher"
 ],
 "Memory could not be saved": [
  null,
  "Speicher konnte nicht gespeichert werden"
 ],
 "Memory must not be 0": [
  null,
  "Speicher darf nicht 0 sein"
 ],
 "Memory save location can not be empty": [
  null,
  "Der Speicherort darf nicht leer sein"
 ],
 "Memory snapshot will use about $0.": [
  null,
  "Der Speicherschnappschuss verbraucht etwa $0."
 ],
 "Memory state path": [
  null,
  "Speicherstatuspfad"
 ],
 "MiB": [
  null,
  "MiB"
 ],
 "Migrate": [
  null,
  "Migrieren"
 ],
 "Migrate VM to another host": [
  null,
  "VM auf einen anderen Host migrieren"
 ],
 "Migration failed": [
  null,
  "Migration fehlgeschlagen"
 ],
 "Mode": [
  null,
  "Modus"
 ],
 "Mode help": [
  null,
  "Modus Hilfe"
 ],
 "Model": [
  null,
  "Modell"
 ],
 "Model type": [
  null,
  "Modelltyp"
 ],
 "More info": [
  null,
  "Weitere Infos"
 ],
 "Mount tag": [
  null,
  "Einbindemarkierung"
 ],
 "Mount tag must not be empty": [
  null,
  "Die Einbindemarkierung darf nicht leer sein"
 ],
 "Must be an address instead of the network identifier, such as $0": [
  null,
  "Muss eine Adresse anstelle der Netzwerkkennung sein, z. B. $0"
 ],
 "NAT to $0": [
  null,
  "NAT auf $0"
 ],
 "NIC $0 of VM $1 failed to change state": [
  null,
  "NIC $0 von VM $1 konnte den Status nicht ändern"
 ],
 "Name": [
  null,
  "Name"
 ],
 "Name already exists": [
  null,
  "Name existiert bereits"
 ],
 "Name can not be empty": [
  null,
  "Name darf nicht leer sein"
 ],
 "Name contains invalid characters": [
  null,
  "Name enthält ungültige Zeichen"
 ],
 "Name must not be empty": [
  null,
  "Name darf nicht leer sein"
 ],
 "Name should not be empty": [
  null,
  "Name sollte nicht leer sein"
 ],
 "Name: ": [
  null,
  "Name: "
 ],
 "Netmask": [
  null,
  "Netzmaske"
 ],
 "Network $0 could not be deleted": [
  null,
  "Netzwerk $0 konnte nicht gelöscht werden"
 ],
 "Network $0 failed to get activated": [
  null,
  "Netzwerk $0 konnte nicht aktiviert werden"
 ],
 "Network $0 failed to get deactivated": [
  null,
  "Netzwerk $0 konnte nicht deaktiviert werden"
 ],
 "Network $0 will be permanently deleted.": [
  null,
  "Netzwerk $0 wird dauerhaft gelöscht."
 ],
 "Network boot (PXE)": [
  null,
  "Netzwerk-Bootvorgang (PXE)"
 ],
 "Network file system": [
  null,
  "Netzwerkdateisystem"
 ],
 "Network interface": [
  null,
  "Netzwerkschnittstelle"
 ],
 "Network interface $0 could not be removed": [
  null,
  "Netzwerkschnittstelle $0 konnte nicht entfernt werden"
 ],
 "Network interface $0 will be removed from $1": [
  null,
  "Netzwerkschnittstelle $0 wird aus $1 entfernt"
 ],
 "Network interface settings could not be saved": [
  null,
  "Netzwerkadaptereinstellungen konnten nicht gespeichert werden"
 ],
 "Network interfaces": [
  null,
  "Netzwerkschnittstellen"
 ],
 "Network selection does not support PXE.": [
  null,
  "Netzwerkauswahl unterstützt PXE nicht."
 ],
 "Networks": [
  null,
  "Netzwerke"
 ],
 "New name": [
  null,
  "Neuer Name"
 ],
 "New name must not be empty": [
  null,
  "Neuer Name darf nicht leer sein"
 ],
 "New volume name": [
  null,
  "Neuer Volume-Name"
 ],
 "No SSH keys specified": [
  null,
  "Keine SSH-Schlüssel angegeben"
 ],
 "No VM is running or defined on this host": [
  null,
  "Auf diesem Host ist weder eine VM definiert, noch wird eine VM ausgeführt"
 ],
 "No boot device found": [
  null,
  "Kein Startgerät gefunden"
 ],
 "No description": [
  null,
  "Keine Beschreibung"
 ],
 "No directories shared between the host and this VM": [
  null,
  "Keine gemeinsamen Verzeichnisse zwischen dem Host und dieser VM"
 ],
 "No disks defined for this VM": [
  null,
  "Keine Festplatten für diese VM definiert"
 ],
 "No host device selected": [
  null,
  "Kein Host-Gerät ausgewählt"
 ],
 "No host devices assigned to this VM": [
  null,
  "Dieser VM sind keine Host-Geräte zugewiesen"
 ],
 "No network devices": [
  null,
  "Keine Netzwerkgeräte"
 ],
 "No network interfaces defined for this VM": [
  null,
  "Keine Netzwerkschnittstellen für diese VM definiert"
 ],
 "No network is defined on this host": [
  null,
  "Kein Netzwerk auf diesem Host definiert"
 ],
 "No networks available": [
  null,
  "Keine Netzwerke verfügbar"
 ],
 "No parent": [
  null,
  "Kein Elternteil"
 ],
 "No snapshots defined for this VM": [
  null,
  "Für diese VM sind keine Schnappschüsse definiert"
 ],
 "No state": [
  null,
  "Kein Status"
 ],
 "No storage": [
  null,
  "Kein Speicher"
 ],
 "No storage pool is defined on this host": [
  null,
  "Auf diesem Host ist kein Speicherpool definiert"
 ],
 "No storage pools available": [
  null,
  "Keine Speicherpools vorhanden"
 ],
 "No storage volumes defined for this storage pool": [
  null,
  "Für dieses Speicherpool sind keine Speichervolumes definiert"
 ],
 "No virtual networks": [
  null,
  "Keine virtuellen Netzwerke"
 ],
 "No volumes exist in this storage pool.": [
  null,
  "In diesem Speicher-Pool gibt es keine Datenträger."
 ],
 "Non-persistent network cannot be deleted. It ceases to exists when it's deactivated.": [
  null,
  "Ein nicht persistentes Netz kann nicht gelöscht werden. Es hört auf zu existieren, wenn es deaktiviert wird."
 ],
 "Non-persistent storage pool cannot be deleted. It ceases to exists when it's deactivated.": [
  null,
  "Ein nicht-beständiger Speicher-Pool kann nicht gelöscht werden. Er verschwindet beim Deaktivieren."
 ],
 "None": [
  null,
  "Kein"
 ],
 "None (isolated network)": [
  null,
  "Getrennt (Isoliertes Netzwerk)"
 ],
 "Offline token": [
  null,
  "Offline-Token"
 ],
 "Offline token must not be empty": [
  null,
  "Offline-Token darf nicht leer sein"
 ],
 "Old token expired": [
  null,
  "Altes Token ist abgelaufen"
 ],
 "On the host": [
  null,
  "Auf dem Host"
 ],
 "One or more selected volumes are used by domains. Detach the disks first to allow volume deletion.": [
  null,
  "Ein oder mehrere Datenträger werden von Domänen verwendet. Geben Sie die Festplatten zuerst frei, um die Datenträger zu löschen."
 ],
 "Only editable when the guest is shut off": [
  null,
  "Kann nur bearbeitet werden wenn Gast ausgeschaltet ist"
 ],
 "Open": [
  null,
  "Öffnen"
 ],
 "Operating system": [
  null,
  "Betriebssystem"
 ],
 "Operation is in progress": [
  null,
  "Vorgang läuft"
 ],
 "Other VMs using SPICE": [
  null,
  "Andere VMs mit SPICE"
 ],
 "Overview": [
  null,
  "Überblick"
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "Parent snapshot": [
  null,
  "Übergeordneter Schnappschuss"
 ],
 "Password": [
  null,
  "Passwort"
 ],
 "Password must be 8 characters or less. VNC passwords do not provide encryption and are generally cryptographically weak. They can not be used to secure connections in untrusted networks.": [
  null,
  "Das Passwort darf höchstens 8 Zeichen lang sein. VNC-Passwörter bieten keine Verschlüsselung und sind im Allgemeinen kryptografisch schwach. Sie können nicht verwendet werden, um Verbindungen in nicht vertrauenswürdigen Netzwerken zu sichern."
 ],
 "Password must be at most 8 characters.": [
  null,
  "Das Passwort darf höchstens 8 Zeichen lang sein."
 ],
 "Path": [
  null,
  "Pfad"
 ],
 "Path on host's filesystem": [
  null,
  "Pfad zum Dateisystem des Hosts"
 ],
 "Path to ISO file on host's file system": [
  null,
  "Pfad zur ISO-Datei im Dateisystem des Hosts"
 ],
 "Path to cloud image file on host's file system": [
  null,
  "Pfad zur Cloud-Abbilddatei im Dateisystem des Hosts"
 ],
 "Path to directory": [
  null,
  "Pfad zum Verzeichnis"
 ],
 "Path to file on host's file system": [
  null,
  "Pfad zur Datei im Dateisystem des Hosts"
 ],
 "Pause": [
  null,
  "Pause"
 ],
 "Paused": [
  null,
  "Pausiert"
 ],
 "Permanent (default)": [
  null,
  "Dauerhaft (Standard)"
 ],
 "Permissions denied for disk images in home directories": [
  null,
  "Berechtigung für Festplattenabbilder in Home-Verzeichnissen abgelehnt"
 ],
 "Persistence": [
  null,
  "Persistenz"
 ],
 "Persistent": [
  null,
  "Persistent"
 ],
 "Physical disk device": [
  null,
  "Physikalisches Festplattengerät"
 ],
 "Physical disk device on host": [
  null,
  "Physikalisches Festplattengerät auf dem Host"
 ],
 "Please choose a different MAC address": [
  null,
  "Bitte wählen Sie eine andere MAC-Adresse aus"
 ],
 "Please choose a storage pool": [
  null,
  "Bitte wählen Sie einen Speicher-Pool"
 ],
 "Please choose a volume": [
  null,
  "Bitte wählen Sie einen Datenträger"
 ],
 "Please enter new volume name": [
  null,
  "Bitte geben Sie den neuen Datenträgernamen ein"
 ],
 "Please see $0 how to reconfigure your VM manually.": [
  null,
  "Bitte beachten Sie $0 für die manuelle Neukonfiguration Ihrer VM."
 ],
 "Pool": [
  null,
  "Pool"
 ],
 "Pool needs to be active to create volume": [
  null,
  "Der Pool muss aktiviert werden, um einen Datenträger zu erstellen"
 ],
 "Pool type $0 does not support volume creation": [
  null,
  "Pool-Typ $0 unterstützt keine Datenträgererstellung"
 ],
 "Pool type doesn't support volume creation": [
  null,
  "Pool-Typ unterstützt keine Datenträgererstellung"
 ],
 "Pool's volumes are used by VMs ": [
  null,
  "Pool-Datenträger werden von VMs verwendet "
 ],
 "Port": [
  null,
  "Port"
 ],
 "Port must be 5900 or larger.": [
  null,
  "Der Port muss 5900 oder größer sein."
 ],
 "Port must be a number that is at least 5900. Leave empty to automatically assign a free port when the machine starts.": [
  null,
  "Der Port muss eine Nummer sein, die mindestens 5900 beträgt. Leer lassen, um beim Start der Maschine automatisch einen freien Port zuzuweisen."
 ],
 "Port must be a number.": [
  null,
  "Der Port muss eine Nummer sein."
 ],
 "Power off": [
  null,
  "Ausschalten"
 ],
 "Pre-formatted block device": [
  null,
  "Vorformatiertes Blockgerät"
 ],
 "Preferred number of sockets to expose to the guest.": [
  null,
  "Bevorzugte Anzahl von Sockets , die dem Gast zugänglich gemacht werden sollen."
 ],
 "Prefix": [
  null,
  "Präfix"
 ],
 "Prefix length": [
  null,
  "Präfixlänge"
 ],
 "Prefix length should not be empty": [
  null,
  "Präfixlänge sollte nicht leer sein"
 ],
 "Previously taken snapshots allow you to revert to an earlier state if something goes wrong": [
  null,
  "Zuvor erstellte Schnappschüsse ermöglichen es Ihnen, zu einem früheren Zustand zurückzukehren, wenn etwas schief geht"
 ],
 "Private": [
  null,
  "Privat"
 ],
 "Product": [
  null,
  "Produkt"
 ],
 "Profile": [
  null,
  "Profil"
 ],
 "Protocol": [
  null,
  "Protokoll"
 ],
 "Provides a bridge from the guest virtual machine directly onto the LAN. This needs a bridge device on the host with one or more physical NICs.": [
  null,
  "Bietet eine Brücke von der virtuellen Gastmaschine direkt zum LAN. Dazu ist ein Brückengerät auf dem Host mit einer oder mehreren physischen NICs erforderlich."
 ],
 "Provides a connection whose details are described by the named network definition.": [
  null,
  "Stellt eine Verbindung bereit, deren Details durch die benannte Netzwerkdefinition beschrieben werden."
 ],
 "Provides a virtual LAN with NAT to the outside world.": [
  null,
  "Stellt ein virtuelles LAN mit NAT zur Außenwelt bereit."
 ],
 "Public SSH key": [
  null,
  "Öffentlicher SSH-Schlüssel"
 ],
 "Public key": [
  null,
  "Öffentlicher Schlüssel"
 ],
 "Range": [
  null,
  "Bereich"
 ],
 "Read-only": [
  null,
  "Nur lesen"
 ],
 "Reboot": [
  null,
  "Neustart"
 ],
 "Reboot $0?": [
  null,
  "$0 neu starten?"
 ],
 "Recommended operating systems": [
  null,
  "Empfohlene Betriebssysteme"
 ],
 "Released $0": [
  null,
  "$0 freigegeben"
 ],
 "Remote URL": [
  null,
  "Remote-URL"
 ],
 "Remote Viewer is available for most operating systems. To install it, search for \"Remote Viewer\" in GNOME Software, KDE Discover, or run the following:": [
  null,
  ""
 ],
 "Remote viewer": [
  null,
  "Fernbetrachter"
 ],
 "Remote viewer applications can connect to the following address:": [
  null,
  ""
 ],
 "Remove": [
  null,
  "Entfernen"
 ],
 "Remove SPICE audio and host devices": [
  null,
  "SPICE-Audio- und Host-Geräte entfernen"
 ],
 "Remove and delete file": [
  null,
  "Datei entfernen und löschen"
 ],
 "Remove disk from VM?": [
  null,
  "Festplatte aus der VM entfernen?"
 ],
 "Remove filesystem?": [
  null,
  "Dateisystem entfernen?"
 ],
 "Remove host device from VM?": [
  null,
  "Host-Gerät aus VM entfernen?"
 ],
 "Remove item": [
  null,
  "Element entfernen"
 ],
 "Remove network interface?": [
  null,
  "Netzwerkschnittstelle entfernen?"
 ],
 "Remove static host from DHCP": [
  null,
  "Statischen Host aus DHCP entfernen"
 ],
 "Rename": [
  null,
  "Umbenennen"
 ],
 "Rename VM $0": [
  null,
  "VM $0 umbenennen"
 ],
 "Replace": [
  null,
  "Ersetzen"
 ],
 "Replace SPICE devices": [
  null,
  "SPICE-Geräte ersetzen"
 ],
 "Replace SPICE devices in VM $0": [
  null,
  "SPICE-Geräte in VM $0 ersetzen"
 ],
 "Replace SPICE on selected VMs.": [
  null,
  "SPICE auf ausgewählten VMs ersetzen."
 ],
 "Replace SPICE on the virtual machine.": [
  null,
  "SPICE auf der virtuellen Maschine ersetzen."
 ],
 "Replace with VNC": [
  null,
  "Mit VNC ersetzen"
 ],
 "Reset": [
  null,
  "Zurücksetzen"
 ],
 "Restart this virtual machine to access its graphical console": [
  null,
  "Starten Sie diese virtuelle Maschine neu, um auf ihre grafische Konsole zuzugreifen"
 ],
 "Restart this virtual machine to access its serial console": [
  null,
  "Starten Sie diese virtuelle Maschine neu, um auf ihre serielle Konsole zuzugreifen"
 ],
 "Restrictions in networking (SLIRP-based emulation) and PCI device assignment": [
  null,
  "Einschränkungen bei der Vernetzung (SLIRP-basierte Emulation) und PCI-Gerätezuweisung"
 ],
 "Resume": [
  null,
  "Fortfahren"
 ],
 "Revert": [
  null,
  "Zurückkehren"
 ],
 "Revert to snapshot $0": [
  null,
  "Zum Schnappschuss $0 zurückkehren"
 ],
 "Reverting to this snapshot will take the VM back to the time of the snapshot and the current state will be lost, along with any data not captured in a snapshot": [
  null,
  "Wenn Sie zu diesem Schnappschuss zurückkehren, wird die VM auf den Zeitpunkt des Schnappschusses zurückgesetzt und der aktuelle Zustand geht verloren, zusammen mit allen Daten, die nicht in einem Schnappschuss erfasst wurden"
 ],
 "Root password": [
  null,
  "Root-Passwort"
 ],
 "Route to $0": [
  null,
  "Route zu $0"
 ],
 "Routed network": [
  null,
  "Weitergeleitetes Netzwerk"
 ],
 "Row select": [
  null,
  "Zeilenauswahl"
 ],
 "Run": [
  null,
  "Ausführen"
 ],
 "Run when host boots": [
  null,
  "Starten wenn Host hochfährt"
 ],
 "Running": [
  null,
  "Läuft"
 ],
 "SPICE": [
  null,
  "SPICE"
 ],
 "SPICE conversion": [
  null,
  "SPICE-Konvertierung"
 ],
 "SPICE is not supported on this host and will cause this virtual machine to not boot.": [
  null,
  "SPICE wird auf diesem Host nicht unterstützt und führt dazu, dass diese virtuelle Maschine nicht startet."
 ],
 "SSH keys": [
  null,
  "SSH-Schlüssel"
 ],
 "Save": [
  null,
  "Speichern"
 ],
 "Select all": [
  null,
  "Alles auswählen"
 ],
 "Send key": [
  null,
  "Tastendruck senden"
 ],
 "Send non-maskable interrupt": [
  null,
  "Nicht maskierbare Unterbrechung senden"
 ],
 "Send non-maskable interrupt to $0?": [
  null,
  "Nicht-maskierbaren Interrupt an $0 senden?"
 ],
 "Serial": [
  null,
  "Seriell"
 ],
 "Serial ($0)": [
  null,
  "Seriell ($0)"
 ],
 "Serial console": [
  null,
  "Serielle Konsole"
 ],
 "Serial console support not enabled": [
  null,
  "Unterstützung der seriellen Konsole nicht aktiviert"
 ],
 "Set DHCP range": [
  null,
  "DHCP-Bereich festlegen"
 ],
 "Set manually": [
  null,
  "Manuell einstellen"
 ],
 "Setting the user passwords for unattended installation requires starting the VM when creating it": [
  null,
  "Das Festlegen der Benutzerpasswörter für die unbeaufsichtigte Installation erfordert das Starten der VM beim Erstellen"
 ],
 "Share": [
  null,
  "Freigabe"
 ],
 "Share a host directory with the guest": [
  null,
  "Ein Host-Verzeichnis mit dem Gast teilen"
 ],
 "Shared directories": [
  null,
  "Gemeinsame Verzeichnisse"
 ],
 "Shared host directories need to be manually mounted inside the VM": [
  null,
  "Gemeinsam genutzte Host-Verzeichnisse müssen innerhalb der VM manuell eingehängt werden"
 ],
 "Shared storage": [
  null,
  "Gemeinsamer Speicher"
 ],
 "Show additional options": [
  null,
  "Zusätzlicher Optionen anzeigen"
 ],
 "Show less": [
  null,
  "Weniger anzeigen"
 ],
 "Show more": [
  null,
  "Mehr anzeigen"
 ],
 "Shut down": [
  null,
  "Herunterfahren"
 ],
 "Shut down $0?": [
  null,
  "$0 herunterfahren?"
 ],
 "Shut off": [
  null,
  "Ausgeschaltet"
 ],
 "Shut off the VM in order to edit firmware configuration": [
  null,
  "Fahren Sie die VM herunter, um die Firmware-Konfiguration zu bearbeiten"
 ],
 "Shutting down": [
  null,
  "Wird heruntergefahren"
 ],
 "Size": [
  null,
  "Größe"
 ],
 "Slot": [
  null,
  "Slot"
 ],
 "Snapshot $0 could not be deleted": [
  null,
  "Schnappschuss $0 konnte nicht gelöscht werden"
 ],
 "Snapshot $0 will be deleted from $1. All of its captured content will be lost.": [
  null,
  "Schnappschuss $0 wird aus $1 gelöscht. Der gesamte erfasste Inhalt geht dabei verloren."
 ],
 "Snapshot failed to be created": [
  null,
  "Schnappschuss konnte nicht erstellt werden"
 ],
 "Snapshots": [
  null,
  "Schnappschüsse"
 ],
 "Sockets": [
  null,
  "Sockets"
 ],
 "Some configuration changes only take effect after a fresh boot:": [
  null,
  "Einige Konfigurationsänderungen werden erst nach einem Neustart wirksam:"
 ],
 "Source": [
  null,
  "Quelle"
 ],
 "Source format": [
  null,
  "Quellenformat"
 ],
 "Source must not be empty": [
  null,
  "Quelle darf nicht leer sein"
 ],
 "Source path": [
  null,
  "Quellpfad"
 ],
 "Source path should not be empty": [
  null,
  "Quellpfad sollte nicht leer sein"
 ],
 "Source should start with http, ftp or nfs protocol": [
  null,
  "Die Quelle sollte mit dem http,ftp oder nfs Protokoll starten"
 ],
 "Source volume group": [
  null,
  "Quellen-Datenträgergruppe"
 ],
 "Start": [
  null,
  "Starten"
 ],
 "Start pool when host boots": [
  null,
  "Starten Sie den Pool, wenn der Host bootet"
 ],
 "Start should not be empty": [
  null,
  "Start sollte nicht leer sein"
 ],
 "Start the virtual machine to access the console": [
  null,
  "Starten Sie die virtuelle Maschine, um auf die Konsole zuzugreifen"
 ],
 "Start the virtual machine to launch remote viewer.": [
  null,
  ""
 ],
 "Started": [
  null,
  "Gestartet"
 ],
 "Startup": [
  null,
  "Anlaufen"
 ],
 "State": [
  null,
  "Status"
 ],
 "Static host entries": [
  null,
  "Statische Host-Einträge"
 ],
 "Static host from DHCP could not be removed": [
  null,
  "Statischer Host aus DHCP konnte nicht entfernt werden"
 ],
 "Storage": [
  null,
  "Speicher"
 ],
 "Storage is at a shared location": [
  null,
  "Speicher ist an einem gemeinsamen Ort"
 ],
 "Storage limit": [
  null,
  "Speichergrenze"
 ],
 "Storage pool $0 failed to get activated": [
  null,
  "Fehler beim Aktivieren des Speicher-Pools $0"
 ],
 "Storage pool $0 failed to get deactivated": [
  null,
  "Fehler beim Deaktivieren des Speicher-Pools $0"
 ],
 "Storage pool failed to be created": [
  null,
  "Speicherpool konnte nicht erstellt werden"
 ],
 "Storage pool name": [
  null,
  "Speicherpoolname"
 ],
 "Storage pools": [
  null,
  "Speicherpools"
 ],
 "Storage pools could not be fetched": [
  null,
  "Fehler beim Abrufen der Speicher-Pools"
 ],
 "Storage size must not be 0": [
  null,
  "Speichergröße darf nicht 0 sein"
 ],
 "Storage volume": [
  null,
  "Speichervolumen"
 ],
 "Storage volume size must not exceed the storage pool's capacity ($0 $1)": [
  null,
  "Die Speicher-Datenträgergröße darf nicht die Kapazität des Speicher-Pools überschreiten ($0 $1)"
 ],
 "Storage volumes": [
  null,
  "Speichervolumen"
 ],
 "Storage volumes could not be deleted": [
  null,
  "Speichervolumen konnte nicht gelöscht werden"
 ],
 "Storage volumes must be shared between this host and the destination host.": [
  null,
  "Speichervolumes müssen von diesem Host und dem Zielhost gemeinsam genutzt werden."
 ],
 "Successfully copied to clipboard!": [
  null,
  "Erfolgreich in die Zwischenablage kopiert!"
 ],
 "Suspended (PM)": [
  null,
  "Angehalten (PM)"
 ],
 "Switch to VNC to continue using this machine.": [
  null,
  "Wechseln Sie zu VNC, um diese Maschine weiterzuverwenden."
 ],
 "System": [
  null,
  "System"
 ],
 "TAP device": [
  null,
  "TAP-Gerät"
 ],
 "TPM": [
  null,
  "TPM"
 ],
 "Table of selectable host devices": [
  null,
  "Tabelle der auswählbaren Host-Geräte"
 ],
 "Target": [
  null,
  "Ziel"
 ],
 "Target path": [
  null,
  "Zielpfad"
 ],
 "Target path should not be empty": [
  null,
  "Zielpfad sollte nicht leer sein"
 ],
 "Temporary": [
  null,
  "Temporär"
 ],
 "Temporary migration": [
  null,
  "Temporäre Migration"
 ],
 "The VM $0 is running and will be forced off before deletion.": [
  null,
  "Die VM $0 ist in Betrieb und wird vor dem Löschen zwangsweise abgeschaltet."
 ],
 "The VM needs to be running or shut off to detach this device": [
  null,
  "Um das Gerät zu entfernen muss die VM laufen oder ausgeschaltet sein"
 ],
 "The directory on the server being exported": [
  null,
  "Das Verzeichnis auf dem Server, der exportiert wird"
 ],
 "The host path that is to be exported.": [
  null,
  "Der zu exportierende Host-Pfad."
 ],
 "The migrated VM configuration is removed from the source host. The destination host is considered the new home of the VM.": [
  null,
  "Die migrierte VM-Konfiguration wird vom Quellhost entfernt. Der Zielhost wird als neues Zuhause der VM betrachtet."
 ],
 "The mode influences the delivery of packets.": [
  null,
  "Der Modus beeinflusst die Verteilung der Pakete."
 ],
 "The pool is empty": [
  null,
  "Der Pool ist leer"
 ],
 "The selected operating system has minimum memory requirement of $0 $1": [
  null,
  "Das ausgewählte Betriebssystem hat einen Mindestspeicherbedarf von $0 $1"
 ],
 "The selected operating system has minimum storage size requirement of $0 $1": [
  null,
  "Das ausgewählte Betriebssystem erfordert eine Mindestspeichergröße von $0 $1"
 ],
 "The static host entry for $0 will be removed:": [
  null,
  "Der statische Host-Eintrag für $0 wird entfernt:"
 ],
 "The storage pool could not be deleted": [
  null,
  "Der Speicher-Pool konnte nicht entfernt werden"
 ],
 "The tag name to be used by the guest to mount this export point.": [
  null,
  "Der Name der Markierung, die vom Gast zum Einbinden des Exportpunktes verwendet wird."
 ],
 "Then copy and paste it above.": [
  null,
  "Kopieren Sie es dann und fügen Sie es oben ein."
 ],
 "This VM is transient. Shut it down if you wish to delete it.": [
  null,
  "Diese VM ist vorübergehend. Schalten Sie sie ab, wenn Sie sie löschen möchten."
 ],
 "This disk will be removed from $0:": [
  null,
  "Diese Festplatte wird aus $0 entfernt:"
 ],
 "This filesystem will be removed from $0:": [
  null,
  "Dieses Dateisystem wird aus $0 entfernt:"
 ],
 "This is intended for a host which does not support SPICE due to upgrades or live migration.": [
  null,
  "Dies ist für einen Host gedacht, der SPICE aufgrund von Aktualisierungen oder Live-Migration nicht unterstützt."
 ],
 "This is the recommended type for general guest connectivity on hosts with dynamic / wireless networking configs.": [
  null,
  "Dies ist der empfohlene Typ für allgemeine Gastkonnektivität auf Hosts mit dynamischer / drahtloser Netzwerkkonfiguration."
 ],
 "This is the recommended type for general guest connectivity on hosts with static wired networking configs.": [
  null,
  "Dies ist der empfohlene Typ für die allgemeine Gastkonnektivität auf Hosts mit statischer kabelgebundener Netzwerkkonfiguration."
 ],
 "This is the recommended type for high performance or enhanced security.": [
  null,
  "Dies ist die empfohlene Typ für hohe Leistung oder erweiterte Sicherheit."
 ],
 "This machine has a SPICE graphical console that can not be shown here.": [
  null,
  "Diese Maschine hat eine grafische SPICE-Konsole, die hier nicht angezeigt werden kann."
 ],
 "This volume is already used by $0.": [
  null,
  "Dieses Volumen wird bereits von $0 verwendet."
 ],
 "This volume is already used by another VM.": [
  null,
  "Dieses Volumen wird bereits von einer anderen VM verwendet."
 ],
 "Threads per core": [
  null,
  "Fäden pro Kern"
 ],
 "Total space available: $0.": [
  null,
  "Verfügbarer Platz insgesamt: $0."
 ],
 "Transient VMs don't support editing firmware configuration": [
  null,
  "Vorübergehende VMs unterstützen die Bearbeitung der Firmware-Konfiguration nicht"
 ],
 "Troubleshoot": [
  null,
  "Fehlersuche"
 ],
 "Type": [
  null,
  "Typ"
 ],
 "URL (ISO image or distro install tree)": [
  null,
  "URL (ISO-Abbild oder Distro-Installationsbaum)"
 ],
 "USB": [
  null,
  "USB"
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Undefined": [
  null,
  "Undefiniert"
 ],
 "Unique name": [
  null,
  "Einzigartiger Name"
 ],
 "Unique name, default: $0": [
  null,
  "Eindeutiger Name, Standard: $0"
 ],
 "Unique network name": [
  null,
  "Eindeutiger Netzwerkname"
 ],
 "Unit": [
  null,
  "Einheit"
 ],
 "Unknown": [
  null,
  "Unbekannt"
 ],
 "Unknown firmware": [
  null,
  "Unbekannte Firmware"
 ],
 "Unspecified": [
  null,
  "Nicht spezifiziert"
 ],
 "Unsupported and older operating systems": [
  null,
  "Nicht unterstützte und ältere Betriebssysteme"
 ],
 "Url": [
  null,
  "Url"
 ],
 "Usage": [
  null,
  "Auslastung"
 ],
 "Use existing": [
  null,
  "Benutze existierendes"
 ],
 "Use extended attributes on files and directories": [
  null,
  "Erweiterte Attribute für Dateien und Verzeichnisse verwenden"
 ],
 "Use the same location on both the origin and destination hosts for your storage. This can be a shared storage pool, NFS, or any other method of sharing storage.": [
  null,
  "Verwenden Sie auf dem Ausgangs- und dem Zielhost denselben Ort für Ihren Speicher. Dies kann ein gemeinsamer Speicherpool, NFS oder eine andere Methode zur gemeinsamen Nutzung von Speicher sein."
 ],
 "Used": [
  null,
  "Benutzt"
 ],
 "Used by": [
  null,
  "Benutzt von"
 ],
 "User login": [
  null,
  "Benutzeranmeldung"
 ],
 "User login must not be empty when SSH keys are set": [
  null,
  "Benutzeranmeldung darf nicht leer sein, wenn SSH-Schlüssel festgelegt sind"
 ],
 "User login must not be empty when user password is set": [
  null,
  "Benutzeranmeldung darf nicht leer sein, wenn das Benutzerpasswort festgelegt ist"
 ],
 "User password": [
  null,
  "Benutzerpasswort"
 ],
 "User password must not be empty when user login is set": [
  null,
  "Benutzerpasswort darf nicht leer sein, wenn die Benutzeranmeldung festgelegt ist"
 ],
 "User session": [
  null,
  "Benutzersitzung"
 ],
 "Uses SPICE": [
  null,
  "Verwendet SPICE"
 ],
 "VM $0 Host Devices": [
  null,
  "VM $0 Host-Geräte"
 ],
 "VM $0 already exists": [
  null,
  "VM $0 existiert bereits"
 ],
 "VM $0 does not exist on $1 connection": [
  null,
  "VM $0 existiert nicht auf Verbindung $1"
 ],
 "VM $0 failed to force reboot": [
  null,
  "VM $0 konnte nicht zum Neustart gezwungen werden"
 ],
 "VM $0 failed to force shutdown": [
  null,
  "VM $0 konnte nicht zum Herunterfahren gezwungen werden"
 ],
 "VM $0 failed to get installed": [
  null,
  "VM$0 konnte nicht installiert werden"
 ],
 "VM $0 failed to pause": [
  null,
  "VM $0 konnte nicht pausiert werden"
 ],
 "VM $0 failed to reboot": [
  null,
  "VM $0 konnte nicht neugestartet werden"
 ],
 "VM $0 failed to resume": [
  null,
  "VM $0 konnte nicht fortgesetzt werden"
 ],
 "VM $0 failed to send NMI": [
  null,
  "NMI konnte nicht an VM $0 gesendet werden"
 ],
 "VM $0 failed to shutdown": [
  null,
  "VM $0 konnte nicht heruntergefahren werden"
 ],
 "VM $0 failed to start": [
  null,
  "VM $0 konnte nicht gestartet werden"
 ],
 "VM launched with unprivileged limited access, with the process and PTY owned by your user account": [
  null,
  "VM mit unprivilegiertem, eingeschränktem Zugriff gestartet, wobei der Prozess und PTY Ihrem Benutzerkonto gehören"
 ],
 "VM needs shutdown": [
  null,
  "VM muss heruntergefahren werden"
 ],
 "VM state": [
  null,
  "VM-Status"
 ],
 "VM will launch with root permissions": [
  null,
  "VM wird mit Root-Rechten gestartet"
 ],
 "VNC": [
  null,
  "VNC"
 ],
 "VNC settings could not be saved": [
  null,
  "VNC-Einstellungen konnten nicht gespeichert werden"
 ],
 "Valid token": [
  null,
  "Gültiges Token"
 ],
 "Vendor": [
  null,
  "Anbieter"
 ],
 "Vendor support ended $0": [
  null,
  "Unterstützung durch den Anbieter endet $0"
 ],
 "Virtual machines": [
  null,
  "Virtuelle Maschinen"
 ],
 "Virtual machines management": [
  null,
  "Verwaltung virtueller Maschinen"
 ],
 "Virtual network": [
  null,
  "Virtuelles Netzwerk"
 ],
 "Virtual network failed to be created": [
  null,
  "Virtuelles Netzwerk konnte nicht erstellt werden"
 ],
 "Virtual socket support enables communication between the host and guest over a socket. It still requires special vsock-aware software to communicate over the socket.": [
  null,
  "Die Unterstützung für virtuelle Sockets ermöglicht die Kommunikation zwischen Gast und Host über einen Socket. Dazu benötigt sie vsock-fähige Software."
 ],
 "Virtualization service (libvirt) is not active": [
  null,
  "Der Virtualisierungsdienst (libvirt) ist nicht aktiv"
 ],
 "Volume": [
  null,
  "Volume"
 ],
 "Volume failed to be created": [
  null,
  "Volumen konnte nicht erstellt werden"
 ],
 "Volume group name": [
  null,
  "Datenträgergruppenname"
 ],
 "Volume group name should not be empty": [
  null,
  "Der Datenträgergruppenname darf nicht leer sein"
 ],
 "Vsock": [
  null,
  "Vsock"
 ],
 "WWPN": [
  null,
  "WWPN"
 ],
 "Watchdog": [
  null,
  "Watchdog"
 ],
 "Watchdogs act when systems stop responding. To use this virtual watchdog device, the guest system also needs to have an additional driver and a running watchdog service.": [
  null,
  "Watchdogs reagieren, wenn das System nicht mehr antwortet. Um einen virtuellen Watchdog zu verwenden benötigt der Gast einen zusätzlichen Treiber und muss den Dienst laufen lassen."
 ],
 "Writeable": [
  null,
  "Beschreibbar"
 ],
 "You can mount the shared folder using:": [
  null,
  "Sie können den gemeinsamen Ordner einhängen mit:"
 ],
 "You need to select the most closely matching operating system": [
  null,
  "Bitte wählen sie das passende Betriebssystem aus"
 ],
 "active": [
  null,
  "Aktiv"
 ],
 "add": [
  null,
  "hinzufügen"
 ],
 "add entry": [
  null,
  "Eintrag hinzufügen"
 ],
 "bridge": [
  null,
  "Brücke"
 ],
 "cdrom": [
  null,
  "CD-ROM"
 ],
 "custom": [
  null,
  "Benutzerdefiniert"
 ],
 "direct": [
  null,
  "Direkte"
 ],
 "disabled": [
  null,
  "Aus"
 ],
 "disk": [
  null,
  "Festplatte"
 ],
 "down": [
  null,
  "runter"
 ],
 "edit": [
  null,
  "bearbeiten"
 ],
 "enabled": [
  null,
  "An"
 ],
 "ethernet": [
  null,
  "Ethernet"
 ],
 "host": [
  null,
  "host"
 ],
 "host device": [
  null,
  "Host-Gerät"
 ],
 "host passthrough": [
  null,
  "Host-Durchleitung"
 ],
 "hostdev": [
  null,
  "hostdev"
 ],
 "iSCSI direct target": [
  null,
  "iSCSI-Direktziel"
 ],
 "iSCSI initiator IQN": [
  null,
  "IQN des iSCSI-Initiators"
 ],
 "iSCSI target": [
  null,
  "iSCSI targets"
 ],
 "iSCSI target IQN": [
  null,
  "iSCSI Ziel IQN"
 ],
 "inactive": [
  null,
  "Inaktiv"
 ],
 "inet": [
  null,
  "inet"
 ],
 "inet6": [
  null,
  "inet6"
 ],
 "mcast": [
  null,
  "mcast"
 ],
 "more info": [
  null,
  "mehr Infos"
 ],
 "mount point: The mount point inside the guest": [
  null,
  "Einhängepunkt: Der Einhängepunkt innerhalb des Gastes"
 ],
 "mount tag: The tag associated to the exported mount point": [
  null,
  "mount tag: Der dem exportierten Mountpunkt zugewiesene Tag"
 ],
 "network": [
  null,
  "Netzwerk"
 ],
 "no": [
  null,
  "Nein"
 ],
 "no state saved": [
  null,
  "kein Zustand gespeichert"
 ],
 "none": [
  null,
  "keine"
 ],
 "redirected device": [
  null,
  "weitergeleitete Geräte"
 ],
 "remove": [
  null,
  "entfernen"
 ],
 "serial number": [
  null,
  "Seriennummer"
 ],
 "server": [
  null,
  "server"
 ],
 "udp": [
  null,
  "udp"
 ],
 "up": [
  null,
  "hoch"
 ],
 "user": [
  null,
  "Benutzer"
 ],
 "vCPU and CPU topology settings could not be saved": [
  null,
  "vCPU- und CPU-Topologieeinstellungen konnten nicht gespeichert werden"
 ],
 "vCPU count": [
  null,
  "Anzahl vCPUs"
 ],
 "vCPU maximum": [
  null,
  "vCPU-Maximum"
 ],
 "vCPUs": [
  null,
  "vCPUs"
 ],
 "vhostuser": [
  null,
  "vhostbenutzer"
 ],
 "view more...": [
  null,
  "mehr anzeigen..."
 ],
 "virt-install package needs to be installed on the system in order to clone VMs": [
  null,
  "Das Paket virt-install muss auf dem System installiert sein, um VMs klonen zu können"
 ],
 "virt-install package needs to be installed on the system in order to create new VMs": [
  null,
  "Das \"virt-install\" Paket muss auf dem System installiert werden, um neue VMs zu erstellen"
 ],
 "virt-install package needs to be installed on the system in order to edit this attribute": [
  null,
  "Das Paket virt-install muss auf dem System installiert sein, um dieses Attribut bearbeiten zu können"
 ],
 "vsock requires special software": [
  null,
  "vsock erfordert spezielle Software"
 ],
 "yes": [
  null,
  "Ja"
 ]
});
