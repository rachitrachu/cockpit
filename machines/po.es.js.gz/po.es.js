cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "es",
  "language-direction": "ltr"
 },
 "$0 $1 available at default location": [
  null,
  "$0 $1 disponibles en la localización por defecto"
 ],
 "$0 $1 available on host": [
  null,
  "$0 $1 disponibles en el anfitrión"
 ],
 "$0 CPU details": [
  null,
  "Detalles de CPU de $0"
 ],
 "$0 Network": [
  null,
  "$0 Red",
  "$0 Redes"
 ],
 "$0 Storage pool": [
  null,
  "$0 Grupo de almacenamiento",
  "$0 Grupos de almacenamiento"
 ],
 "$0 does not support unattended installation.": [
  null,
  "$0 no soporta una instalación desatendida."
 ],
 "$0 memory adjustment": [
  null,
  "$0 ajuste de memoria"
 ],
 "$0 network": [
  null,
  "$0 Red"
 ],
 "$0 vCPU": [
  null,
  "$0 vCPU",
  "$0 vCPUs"
 ],
 "$0 virtual network interface settings": [
  null,
  "$0 configuraciones de interfaz de red virtual"
 ],
 "A copy of the VM will run on the destination and will disappear when it is shut off. Meanwhile, the origin host keeps its copy of the VM configuration.": [
  null,
  "Se ejecutará una copia de la MV en el destino que desaparecerá al apagarse. Mientras tanto, el anfitrión de origen mantiene su copia de la configuración de la MV."
 ],
 "Access": [
  null,
  "Acceso"
 ],
 "Action": [
  null,
  "Acción"
 ],
 "Actions": [
  null,
  "Acciones"
 ],
 "Activate": [
  null,
  "Activar"
 ],
 "Activate the storage pool to administer volumes": [
  null,
  "Activar el grupo de almacenamiento para administrar volúmenes"
 ],
 "Add": [
  null,
  "Añadir"
 ],
 "Add SSH keys": [
  null,
  "Añadir claves SSH"
 ],
 "Add TPM": [
  null,
  "Añadir TPM"
 ],
 "Add VNC": [
  null,
  ""
 ],
 "Add a DHCP static host entry": [
  null,
  "Añadir una entrada de host estático DHCP"
 ],
 "Add disk": [
  null,
  "Añadir disco"
 ],
 "Add host device": [
  null,
  "Añadir dispositivo del anfitrión"
 ],
 "Add network interface": [
  null,
  "Añadir una interfaz de red"
 ],
 "Add shared directory": [
  null,
  "Añadir directorio compartido"
 ],
 "Add virtual network interface": [
  null,
  "Añadir una interfaz de red virtual"
 ],
 "Add vsock interface": [
  null,
  "Añadir una interfaz vsock"
 ],
 "Add watchdog device type": [
  null,
  "Añadir dispositivo de tipo watchdog"
 ],
 "Adding a watchdog will require a reboot to take effect.": [
  null,
  "Necesitará reiniciar para que un watchdog que añada tome efecto."
 ],
 "Adding shared directories is possible only when the guest is shut off": [
  null,
  "Sólo se pueden añadir directorios compartidos cuando el huésped esté apagado"
 ],
 "Additional": [
  null,
  "Adicional"
 ],
 "Address": [
  null,
  "Dirección"
 ],
 "Address not within subnet": [
  null,
  "La dirección no está dentro de una subred"
 ],
 "All": [
  null,
  "Todo"
 ],
 "All VM activity, including storage, will be temporary. This will result in data loss on the destination host.": [
  null,
  "Toda actividad de la máquina virtual, incluyendo su almacenamiento, será temporal. Esto causará pérdidas de información en el anfitrión de destino."
 ],
 "Allowed characters: basic Latin alphabet, numbers, and limited punctuation (-, _, +, .)": [
  null,
  "Caracteres permitidos: alfabeto latino básico, números, y puntuación limitada (-, _, +, .)"
 ],
 "Also delete all volumes inside this pool:": [
  null,
  "Eliminar también todos los volúmenes dentro de este grupo:"
 ],
 "Always attach": [
  null,
  "Siempre adjunto"
 ],
 "An example of vsock-aware software is socat": [
  null,
  "Un ejemplo de software compatible con vsock es socat"
 ],
 "Apply": [
  null,
  "Aplicar"
 ],
 "Apply on next boot": [
  null,
  "Aplicar en el siguiente arranque"
 ],
 "Assign automatically": [
  null,
  "Asignar automáticamente"
 ],
 "Automated installs are only available when downloading an image or using cloud-init.": [
  null,
  "Las instalaciones automatizadas solo están disponibles cuando se descarga una imagen o utilizando cloud-init."
 ],
 "Automatic": [
  null,
  "Automático"
 ],
 "Automation": [
  null,
  "Automatización"
 ],
 "Autostart": [
  null,
  "Inicio automático"
 ],
 "Block device": [
  null,
  "Dispositivo de bloque"
 ],
 "Blocked": [
  null,
  "Bloqueado"
 ],
 "Boot order": [
  null,
  "Orden de arranque"
 ],
 "Boot order settings could not be saved": [
  null,
  "La configuración del orden de arranque no se pudo guardar"
 ],
 "Bus": [
  null,
  "Bus"
 ],
 "CD/DVD disc": [
  null,
  "Disco CD/DVD"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "CPU mode could not be saved": [
  null,
  "No se pudo guardar el modo de la CPU"
 ],
 "Cache": [
  null,
  "Antememoria"
 ],
 "Cancel": [
  null,
  "Cancelar"
 ],
 "Cannot edit vsock device on a transient VM": [
  null,
  "No se puede editar el dispositivo vsock en una MV temporal"
 ],
 "Cannot edit watchdog device on a transient VM": [
  null,
  "No se puede editar el dispositivo watchdog en una MV temporal"
 ],
 "Capacity": [
  null,
  "Capacidad"
 ],
 "Change boot order": [
  null,
  "Cambiar orden de arranque"
 ],
 "Change firmware": [
  null,
  "Cambiar el firmware"
 ],
 "Changes pending": [
  null,
  "Hay cambios pendientes"
 ],
 "Changes will take effect after shutting down the VM": [
  null,
  "Los cambios entrarán en vigor después de apagar la máquina virtual"
 ],
 "Changing BIOS/EFI settings is specific to each manufacturer. It involves pressing a hotkey during boot (ESC, F1, F12, Del). Enable a setting called \"virtualization\", \"VM\", \"VMX\", \"SVM\", \"VTX\", \"VTD\". Consult your computer's manual for details.": [
  null,
  "Cambiar los parámetros de configuración de BIOS/EFI requiere seguir un método específico para cada fabricante. Este método incluye pulsar una tecla durante el arranque (Esc, F1, F12, Supr). Habilite un parámetro llamado \"virtualization\", \"VM\", \"VMX\", \"SVM\", \"VTX\" o \"VTD\". Consulte el manual de su equipo para más información."
 ],
 "Checking token validity...": [
  null,
  "Comprobando validez del token..."
 ],
 "Choose an operating system": [
  null,
  "Escoja un sistema operativo"
 ],
 "Class": [
  null,
  "Clase"
 ],
 "Clone": [
  null,
  "Clonar"
 ],
 "Close": [
  null,
  "Cerrar"
 ],
 "Cloud base image": [
  null,
  "Imágenes Cloud Base"
 ],
 "Compress": [
  null,
  ""
 ],
 "Concurrently writeable": [
  null,
  "Escribible concurentemente"
 ],
 "Confirm this action": [
  null,
  "Confirme esta acción"
 ],
 "Connect": [
  null,
  "Conectar"
 ],
 "Connection": [
  null,
  "Conexión"
 ],
 "Console": [
  null,
  "Consola"
 ],
 "Convert QXL video card to VGA": [
  null,
  "Convertir tarjetas de vídeo QXL a VGA"
 ],
 "Convert SPICE graphics console to VNC": [
  null,
  "Convertir consolas gráficas SPICE a VNC"
 ],
 "Copy storage": [
  null,
  "Copiar almacenamiento"
 ],
 "Copy to clipboard": [
  null,
  "Copiar al portapapeles"
 ],
 "Cores per socket": [
  null,
  "Núcleos por socket"
 ],
 "Could not delete $0": [
  null,
  "No se pudo eliminar $0"
 ],
 "Could not delete all storage for $0": [
  null,
  "No se pudo eliminar todo el almacenamiento de $0"
 ],
 "Could not delete disk's storage": [
  null,
  "No se pudo eliminar el almacenamiento del disco"
 ],
 "Could not dynamically add watchdog": [
  null,
  "No se pudo añadir el watchdog dinámicamente"
 ],
 "Could not revert to snapshot": [
  null,
  "No se ha podido revertir a la instantánea"
 ],
 "Crashed": [
  null,
  "Colgado"
 ],
 "Create": [
  null,
  "Crear"
 ],
 "Create VM": [
  null,
  "Crear una MV"
 ],
 "Create VM by importing a disk image of an existing VM installation": [
  null,
  "Crear una MV importando una imagen de disco de una instalación de MV existente"
 ],
 "Create VM from local or network installation medium": [
  null,
  "Crear una MV desde un medio de instalación local o en red"
 ],
 "Create a clone VM based on $0": [
  null,
  "Crear una máquina virtual clonada en $0"
 ],
 "Create and edit": [
  null,
  "Crear y editar"
 ],
 "Create and run": [
  null,
  "Crear y ejecutar"
 ],
 "Create new": [
  null,
  "Crear nuevo"
 ],
 "Create new qcow2 volume": [
  null,
  "Crear un volumen qcow2"
 ],
 "Create new raw volume": [
  null,
  "Crear un volumen raw"
 ],
 "Create new virtual machine": [
  null,
  "Crear una máquina virtual"
 ],
 "Create snapshot": [
  null,
  "Crear una instantánea"
 ],
 "Create storage pool": [
  null,
  "Crear un grupo de almacenamiento"
 ],
 "Create storage volume": [
  null,
  "Crear un volumen de almacenamiento"
 ],
 "Create virtual network": [
  null,
  "Crear una red virtual"
 ],
 "Create volume": [
  null,
  "Crear un volumen"
 ],
 "Creating VM": [
  null,
  "Creando MV"
 ],
 "Creating VM $0": [
  null,
  "Creando la MV $0"
 ],
 "Creating snapshots of VMs with VFIO devices is not supported while they are running.": [
  null,
  "Creando instantáneas de VMs con dispositivos VFIO no está admitido mientras estén en ejecución."
 ],
 "Creation of VM $0 failed": [
  null,
  "La creación de la MV $0 falló"
 ],
 "Creation time": [
  null,
  "Hora de creación"
 ],
 "Ctrl+Alt+$0": [
  null,
  "Ctrl+Alt+$0"
 ],
 "Current": [
  null,
  "Actual"
 ],
 "Current allocation": [
  null,
  "Asignación actual"
 ],
 "Custom firmware: $0": [
  null,
  "Firmware específico: $0"
 ],
 "Custom identifier": [
  null,
  "Identificador personalizado"
 ],
 "Custom path": [
  null,
  "Ruta personalizada"
 ],
 "DHCP Settings": [
  null,
  "Ajustes DHCP"
 ],
 "Deactivate": [
  null,
  "Desactivar"
 ],
 "Delete": [
  null,
  "Eliminar"
 ],
 "Delete $0 VM?": [
  null,
  "¿Eliminar la MV $0?"
 ],
 "Delete $0 storage pool?": [
  null,
  "¿Eliminar el grupo de almacenamiento $0?"
 ],
 "Delete $0 volume": [
  null,
  "Eliminar $0 volumen",
  "Eliminar $0 volúmenes"
 ],
 "Delete associated storage files:": [
  null,
  "Eliminar archivos de almacenamiento asociados:"
 ],
 "Delete network?": [
  null,
  "¿Eliminar la red?"
 ],
 "Delete snapshot?": [
  null,
  "¿Eliminar la instantánea?"
 ],
 "Deleting an inactive storage pool will only undefine the pool. Its content will not be deleted.": [
  null,
  "Eliminar un grupo de almacenamiento inactivo solo quitará la definición del conjunto. Su contenido no se eliminará."
 ],
 "Deleting shared directories is possible only when the guest is shut off": [
  null,
  "Sólo es posible borrar directorios compartidos cuando el huésped esté apagado"
 ],
 "Description": [
  null,
  "Descripción"
 ],
 "Deselect others": [
  null,
  "Quitar selección de otros"
 ],
 "Destination URI": [
  null,
  "URI de destino"
 ],
 "Destination URI must not be empty": [
  null,
  "La URI de destino no debe estar vacía"
 ],
 "Detach the disks using this pool from any VMs before attempting deletion.": [
  null,
  "Desmontando los discos utilizando este grupo desde cualquiera de las MVs antes de intentar eliminarlo."
 ],
 "Details": [
  null,
  "Detalles"
 ],
 "Device": [
  null,
  "Dispositivo"
 ],
 "Devices": [
  null,
  "Dispositivos"
 ],
 "Disconnect": [
  null,
  "Desconectar"
 ],
 "Disconnected": [
  null,
  "Desconectado"
 ],
 "Disconnected from serial console. Click the connect button.": [
  null,
  "Desconectado desde la consola serial. Haga clic en el botón de conectar."
 ],
 "Disk": [
  null,
  "Disco"
 ],
 "Disk $0 could not be removed": [
  null,
  "No se pudo eliminar el disco $0"
 ],
 "Disk failed to be added": [
  null,
  "El disco no se pudo añadir"
 ],
 "Disk identifier": [
  null,
  "Identificador del disco"
 ],
 "Disk image": [
  null,
  "Imagen del disco"
 ],
 "Disk image file": [
  null,
  "Archivo de imagen de disco"
 ],
 "Disk image path must not be empty": [
  null,
  "El camino a la imagen del disco no puede estar vacío"
 ],
 "Disk images can be stored in user home directory": [
  null,
  "Las imágenes de disco se pueden almacenar en la carpeta personal del usuario"
 ],
 "Disk settings could not be saved": [
  null,
  "Las configuraciones del disco no se pudieron guardar"
 ],
 "Disk-only snapshot": [
  null,
  "Instantánea sólo de disco"
 ],
 "Disks": [
  null,
  "Discos"
 ],
 "Do not run this VM on the origin and destination hosts at the same time.": [
  null,
  "No ejecute esta máquina virtual en los anfitriones de origen y destino al mismo tiempo."
 ],
 "Do nothing": [
  null,
  "No hacer nada"
 ],
 "Domain has crashed": [
  null,
  "El dominio se ha caído"
 ],
 "Domain is blocked on resource": [
  null,
  "El dominio está bloqueado en el recurso"
 ],
 "Download an OS": [
  null,
  "Descargar un SO"
 ],
 "Download progress": [
  null,
  "Progreso de descarga"
 ],
 "Downloading image for VM $0": [
  null,
  "Descargando imagen para la MV $0"
 ],
 "Downloading: $0%": [
  null,
  "Descargando: $0%"
 ],
 "Dump core": [
  null,
  "Volcar la memoria"
 ],
 "Duration": [
  null,
  "Duración"
 ],
 "Dying": [
  null,
  "Agonizando"
 ],
 "Edit": [
  null,
  "Editar"
 ],
 "Edit $0 attributes": [
  null,
  "Editar $0 atributos"
 ],
 "Edit description": [
  null,
  "Editar descripción"
 ],
 "Edit description of VM $0": [
  null,
  "Edita la descripción de VM $0"
 ],
 "Edit vsock interface": [
  null,
  "Editar interfaz vsock"
 ],
 "Edit watchdog device type": [
  null,
  "Editar tipo de dispositivo watchdog"
 ],
 "Editing network interfaces of transient guests is not allowed": [
  null,
  "Editar las interfaces de red de los huéspedes transitorios no está permitido"
 ],
 "Editing transient network interfaces is not allowed": [
  null,
  "Editar la interfaces de red transitorias no está permitido"
 ],
 "Eject": [
  null,
  "Expulsar"
 ],
 "Eject disc from VM?": [
  null,
  "¿Expulsar el disco de la MV?"
 ],
 "Emulated machine": [
  null,
  "Máquina emulada"
 ],
 "Enable virtualization support in BIOS/EFI settings.": [
  null,
  "Habilite el soporte de virtualización en la configuración de BIOS/EFI."
 ],
 "End": [
  null,
  "Terminar"
 ],
 "End should not be empty": [
  null,
  "El fin del rango no debe estar vacío"
 ],
 "Enter root and/or user information to enable unattended installation.": [
  null,
  "Introduzca la información de root y/o usuario para habilitar una instalación desatendida."
 ],
 "Error checking token": [
  null,
  "Error al comprobar el token"
 ],
 "Example, $0": [
  null,
  "Por ejemplo, $0"
 ],
 "Existing disk image on host's file system": [
  null,
  "Imagen de disco existente en el sistema de archivos del anfitrión"
 ],
 "Expand": [
  null,
  "Expandir"
 ],
 "Extended attributes": [
  null,
  "Atributos extendidos"
 ],
 "Failed": [
  null,
  "Falló"
 ],
 "Failed to add TPM to VM $0": [
  null,
  "Fallo al añadir TPM a VM $0"
 ],
 "Failed to add shared directory": [
  null,
  "Fallo al añadir el directorio compartido"
 ],
 "Failed to change firmware": [
  null,
  "Fallo al cambiar el firmware"
 ],
 "Failed to clone VM $0": [
  null,
  "Fallo al clonar la MV $0"
 ],
 "Failed to configure vsock": [
  null,
  "Fallo al configurar el vsock"
 ],
 "Failed to configure watchdog": [
  null,
  "Fallo al configurar el watchdog"
 ],
 "Failed to detach vsock": [
  null,
  "Fallo al desvincular el vsock"
 ],
 "Failed to detach watchdog": [
  null,
  "Fallo al desvincular el watchdog"
 ],
 "Failed to fetch some resources": [
  null,
  "Fallo al solicitar algunos recursos"
 ],
 "Failed to fetch the IP addresses of the interfaces present in $0": [
  null,
  "Fallo al obtener las direcciones IP de las interfaces presentes en $0"
 ],
 "Failed to rename VM $0": [
  null,
  "Fallo al renombrar la MV $0"
 ],
 "Failed to replace SPICE devices": [
  null,
  "Fallo al reemplazar dispositivos SPICE"
 ],
 "Failed to save network settings": [
  null,
  "Fallo al guardar los ajustes de red"
 ],
 "Failed to send key Ctrl+Alt+$0 to VM $1": [
  null,
  "Fallo al enviar las teclas Ctrl+Alt+$0 a la VM $1"
 ],
 "Failed to set description of VM $0": [
  null,
  "Fallo al establecer descripción de VM $0"
 ],
 "Fewer than the maximum number of virtual CPUs should be enabled.": [
  null,
  "Deben habilitarse menos CPU virtuales de las permitidas."
 ],
 "File": [
  null,
  "Archivo"
 ],
 "Filesystem $0 could not be removed": [
  null,
  "La $0 no se pudo eliminar"
 ],
 "Filesystem directory": [
  null,
  "Directorio del sistema de archivos"
 ],
 "Filter by name": [
  null,
  "Filtrar por nombre"
 ],
 "Firmware": [
  null,
  "Firmware"
 ],
 "Force eject": [
  null,
  "Forzar la expulsión"
 ],
 "Force reboot": [
  null,
  "Forzar el reinicio"
 ],
 "Force reboot $0?": [
  null,
  "¿Forzar el reinicio de $0?"
 ],
 "Force revert": [
  null,
  "Forzar reversión"
 ],
 "Force shut down": [
  null,
  "Forzar el apagado"
 ],
 "Force shut down $0?": [
  null,
  "¿Forzar el apagado de $0?"
 ],
 "Format": [
  null,
  "Formato"
 ],
 "Forward mode": [
  null,
  "Modo de redireccionamiento"
 ],
 "Forwarding mode": [
  null,
  "Modo de reenvío"
 ],
 "Full disk images and the domain's memory will be migrated. Only non-shared, writable disk images will be transferred. Unused storage will remain on the origin after migration.": [
  null,
  "Se migrarán las imágenes completas de disco y la memoria del dominio. Sólo los discos con escritura y no compartidos se transferirán. El almacenamiento no utilizado permanecerá en el origen tras la migración."
 ],
 "General": [
  null,
  "General"
 ],
 "Generate automatically": [
  null,
  "Generado automáticamente"
 ],
 "Get a new RHSM token.": [
  null,
  "Obtenga un nuevo token de RHSM."
 ],
 "GiB": [
  null,
  "GiB"
 ],
 "Go to VMs list": [
  null,
  "Ir a la lista de MVs"
 ],
 "Good choice for desktop virtualization": [
  null,
  "Buena opción para virtualización de escritorios"
 ],
 "Gracefully shutdown": [
  null,
  "Iniciar apagado normal"
 ],
 "Graphical": [
  null,
  ""
 ],
 "Graphical console support not enabled": [
  null,
  ""
 ],
 "Hardware virtualization is disabled": [
  null,
  "La virtualización por hardware está desactivada"
 ],
 "Hide additional options": [
  null,
  "Ocultar opciones adicionales"
 ],
 "Host": [
  null,
  "Anfitrión"
 ],
 "Host device": [
  null,
  "Dispositivo del anfitrión"
 ],
 "Host device could not be attached": [
  null,
  "No se pudo agregar el dispositivo del anfitrión"
 ],
 "Host device will be removed from $0:": [
  null,
  "El dispositivo del anfitrión se quitará de $0:"
 ],
 "Host devices": [
  null,
  "Dispositivos del anfitrión"
 ],
 "Host name": [
  null,
  "Nombre del anfitrión"
 ],
 "Host should not be empty": [
  null,
  "El anfitrión no debe estar vacío"
 ],
 "Hypervisor details": [
  null,
  "Detalles del hipervisor"
 ],
 "ID": [
  null,
  "ID"
 ],
 "IP": [
  null,
  "IP"
 ],
 "IP address": [
  null,
  "Dirección IP"
 ],
 "IP address must not be empty": [
  null,
  "La dirección IP no debe estar vacía"
 ],
 "IP configuration": [
  null,
  "Configuración de la IP"
 ],
 "IPv4 address": [
  null,
  "Dirección IPv4"
 ],
 "IPv4 address cannot be same as the network's broadcast address": [
  null,
  "La dirección IPv4 no puede ser la de broadcast de su red"
 ],
 "IPv4 and IPv6": [
  null,
  "IPv4 e IPv6"
 ],
 "IPv4 network should not be empty": [
  null,
  "La red IPv4 no debería estar vacía"
 ],
 "IPv4 only": [
  null,
  "Solo IPv4"
 ],
 "IPv4 prefix length must be 24 or less": [
  null,
  "La longitud del prefijo de IPv4 debe ser 24 o menos"
 ],
 "IPv4 prefix length must be a multiple of 8": [
  null,
  "La longitud de prefijo IPv4 debe ser un múltiplo de 8"
 ],
 "IPv6 address": [
  null,
  "Dirección IPv6"
 ],
 "IPv6 network should not be empty": [
  null,
  "La red IPv6 no debería estar vacía"
 ],
 "IPv6 only": [
  null,
  "Solo IPv6"
 ],
 "Ideal for server VMs": [
  null,
  "Idóneo para MV de servidores"
 ],
 "Ideal networking support": [
  null,
  "Soporte de redes ideal"
 ],
 "Identifier in use by $0. VMs with an identical identifier cannot run at the same time.": [
  null,
  "Identificador ya en uso por $0. No se pueden ejecutar a la vez MV con el mismo identificador."
 ],
 "Identifier may be silently truncated to $0 characters ": [
  null,
  "Puede que el identificador se acorte a $0 caracteres sin aviso "
 ],
 "Idle": [
  null,
  "Inactivo"
 ],
 "Ignore": [
  null,
  "Ignorar"
 ],
 "Import VM": [
  null,
  "Importar una MV"
 ],
 "Import a virtual machine": [
  null,
  "Importar una máquina virtual"
 ],
 "Import and edit": [
  null,
  "Importar y editar"
 ],
 "Import and run": [
  null,
  "Importar y ejecutar"
 ],
 "Importing an image with a backing file is unsupported": [
  null,
  "La importación de imágenes que contengan archivos de respaldo no está soportada"
 ],
 "In most configurations, macvtap does not work for host to guest network communication.": [
  null,
  "En muchas configuraciones, macvtap no funciona para un comunicación de red anfitrión-huésped."
 ],
 "Initiator": [
  null,
  "Iniciador"
 ],
 "Initiator should not be empty": [
  null,
  "El iniciador no debería estar vacío"
 ],
 "Inject a non-maskable interrupt": [
  null,
  "Enviar interrupción no enmascarable"
 ],
 "Insert": [
  null,
  "Insertar"
 ],
 "Insert disc media": [
  null,
  "Insertar disco"
 ],
 "Inside the VM": [
  null,
  "Dentro de la MV"
 ],
 "Install": [
  null,
  "Instalar"
 ],
 "Installation source": [
  null,
  "Origen de instalación"
 ],
 "Installation source must not be empty": [
  null,
  "La instalación del código no debería estar vacío"
 ],
 "Installation type": [
  null,
  "Tipo de instalación"
 ],
 "Interface": [
  null,
  "Interfaz"
 ],
 "Interface type": [
  null,
  "Tipo de interfaz"
 ],
 "Interface type help": [
  null,
  "Ayuda sobre el tipo de interfaz"
 ],
 "Invalid IPv4 address": [
  null,
  "Dirección IPv4 inválida"
 ],
 "Invalid IPv4 mask or prefix length": [
  null,
  "Máscara o longitud del prefijo de IPv4 inválidos"
 ],
 "Invalid IPv6 address": [
  null,
  "Dirección IPv6 inválida"
 ],
 "Invalid IPv6 prefix": [
  null,
  "Prefijo IPv6 inválido"
 ],
 "Invalid filename": [
  null,
  "Nombre de fichero no válido"
 ],
 "Isolated network": [
  null,
  "Red aislada"
 ],
 "It can also be used to enable the inline graphical console in the browser, which does not support SPICE.": [
  null,
  ""
 ],
 "Keys are located in ~/.ssh/ and have a \".pub\" extension.": [
  null,
  "Las claves se encuentran en ~/.ssh/ y tienen una extensión \".pub\"."
 ],
 "LVM volume group": [
  null,
  "Grupo de volumen de LVM"
 ],
 "Leave the password blank if you do not wish to have a root account created": [
  null,
  "Deje la contraseña en blanco si no quiere crear una cuenta de usuario root"
 ],
 "Leave the password blank if you do not wish to have a user account created": [
  null,
  "Deje la contraseña en blanco si no quiere crear una cuenta de usuario"
 ],
 "Leave the password blank if you do not wish to set a root password": [
  null,
  "Deje la contraseña en blanco si no quiere asignar una contraseña a root"
 ],
 "Libvirt did not detect any UEFI/OVMF firmware image installed on the host": [
  null,
  "Libvirt no detecta ninguna imagen de firmware de UEFI/OVMF instalada en el anfitrión"
 ],
 "Libvirt or hypervisor does not support UEFI": [
  null,
  "Libvirt o el hipervisor no soportan UEFI"
 ],
 "Loading available network devices": [
  null,
  "Cargando dispositivos de red disponibles"
 ],
 "Loading resources": [
  null,
  "Cargando recursos"
 ],
 "Loading...": [
  null,
  "Cargando..."
 ],
 "Local install media (ISO image or distro install tree)": [
  null,
  "Medio de instalación local (imagen ISO o lista de instalación de distribución)"
 ],
 "Location": [
  null,
  "Ubicación"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "MAC address": [
  null,
  "Dirección MAC"
 ],
 "MAC address already in use": [
  null,
  "La dirección MAC ya está en uso"
 ],
 "MAC address must not be empty": [
  null,
  "La dirección MAC no debe estar vacía"
 ],
 "Machine must be shut off before changing bus type": [
  null,
  "La máquina debe estar apagada antes de cambiar el tipo de bus"
 ],
 "Machine must be shut off before changing cache mode": [
  null,
  "La máquina debe estar apagada antes de modificar el tipo de caché"
 ],
 "Mask or prefix length": [
  null,
  "Máscara o longitud del prefijo"
 ],
 "Mask or prefix length should not be empty": [
  null,
  "La máscara o la longitud del prefijo no debería estar vacío"
 ],
 "Maximum allocation": [
  null,
  "Asignación máxima"
 ],
 "Maximum memory could not be saved": [
  null,
  "La memoria máxima no se pudo guardar"
 ],
 "Maximum number of virtual CPUs allocated for the guest OS": [
  null,
  "Número máximo de CPUs virtuales asignadas al SO huésped"
 ],
 "Maximum number of virtual CPUs allocated for the guest OS, which must be between 1 and $0": [
  null,
  "Número máximo de CPU virtuales asignadas al SO invitado, entre 1 y $0"
 ],
 "Maximum transmission unit": [
  null,
  "Unidad máxima de transmisión"
 ],
 "Media could not be ejected from $0": [
  null,
  "No se pudo expulsar de $0"
 ],
 "Media will be ejected from $0:": [
  null,
  "Se expulsará de $0:"
 ],
 "Memory": [
  null,
  "Memoria"
 ],
 "Memory could not be saved": [
  null,
  "La memoria no se pudo guardar"
 ],
 "Memory must not be 0": [
  null,
  "La memoria no debe ser 0"
 ],
 "Memory save location can not be empty": [
  null,
  "El lugar que guarda memoria puede no estar vacía"
 ],
 "Memory snapshot will use about $0.": [
  null,
  "La instantánea de memoria utilizará alrededor de $0."
 ],
 "Memory state path": [
  null,
  "Ruta de estado de memoria"
 ],
 "MiB": [
  null,
  "MiB"
 ],
 "Migrate": [
  null,
  "Migrar"
 ],
 "Migrate VM to another host": [
  null,
  "Migrar MV a otro anfitrión"
 ],
 "Migration failed": [
  null,
  "Falló la migración"
 ],
 "Mode": [
  null,
  "Modo"
 ],
 "Mode help": [
  null,
  "Modo de ayuda"
 ],
 "Model": [
  null,
  "Modelo"
 ],
 "Model type": [
  null,
  "Tipo de modelo"
 ],
 "More info": [
  null,
  "Más información"
 ],
 "Mount tag": [
  null,
  "Etiqueta de montaje"
 ],
 "Mount tag must not be empty": [
  null,
  "La etiqueta de montaje no debe estar vacía"
 ],
 "Must be an address instead of the network identifier, such as $0": [
  null,
  "Debe ser una dirección en lugar del identificador de red, como $0"
 ],
 "NAT to $0": [
  null,
  "NAT para $0"
 ],
 "NIC $0 of VM $1 failed to change state": [
  null,
  "NIC $0 de la VM $1 falló al cambiar de estado"
 ],
 "Name": [
  null,
  "Nombre"
 ],
 "Name already exists": [
  null,
  "El nombre ya existe"
 ],
 "Name can not be empty": [
  null,
  "El nombre no puede estar vacío"
 ],
 "Name contains invalid characters": [
  null,
  "El nombre contiene caracteres no válidos"
 ],
 "Name must not be empty": [
  null,
  "El nombre no debe estar vacío"
 ],
 "Name should not be empty": [
  null,
  "El nombre no debería estar vacío"
 ],
 "Name: ": [
  null,
  "Nombre: "
 ],
 "Netmask": [
  null,
  "Máscara de red"
 ],
 "Network $0 could not be deleted": [
  null,
  "No se pudo eliminar la red $0"
 ],
 "Network $0 failed to get activated": [
  null,
  "Falló al activarse la red $0"
 ],
 "Network $0 failed to get deactivated": [
  null,
  "Falló al activarse la red $0"
 ],
 "Network $0 will be permanently deleted.": [
  null,
  "La red $0 será eliminada permanentemente."
 ],
 "Network boot (PXE)": [
  null,
  "Arranque vía red (PXE)"
 ],
 "Network file system": [
  null,
  "Sistema de archivos de red"
 ],
 "Network interface": [
  null,
  "Interfaz de red"
 ],
 "Network interface $0 could not be removed": [
  null,
  "No se pudo quitar la interfaz de red $0"
 ],
 "Network interface $0 will be removed from $1": [
  null,
  "Se quitará la interfaz de red $0 de $1"
 ],
 "Network interface settings could not be saved": [
  null,
  "No se pudo guardar la configuración de la interfaz de red"
 ],
 "Network interfaces": [
  null,
  "Interfaces de red"
 ],
 "Network selection does not support PXE.": [
  null,
  "La red seleccionada no soporta PXE."
 ],
 "Networks": [
  null,
  "Redes"
 ],
 "New name": [
  null,
  "Nuevo nombre"
 ],
 "New name must not be empty": [
  null,
  "El nuevo nombre no debe estar vacío"
 ],
 "New volume name": [
  null,
  "Nuevo nombre para el volumen"
 ],
 "No SSH keys specified": [
  null,
  "No se han especificado claves SSH"
 ],
 "No VM is running or defined on this host": [
  null,
  "No hay ninguna MV en ejecución o definida en este anfitrión"
 ],
 "No boot device found": [
  null,
  "No se ha encontrado un dispositivo de arranque"
 ],
 "No description": [
  null,
  "Sin descripción"
 ],
 "No directories shared between the host and this VM": [
  null,
  "No hay directorios compartidos entre el anfitrión y esta MV"
 ],
 "No disks defined for this VM": [
  null,
  "No se han definido discos para esta MV"
 ],
 "No host device selected": [
  null,
  "No se ha seleccionado dispositivos del anfitrión"
 ],
 "No host devices assigned to this VM": [
  null,
  "No hay dispositivos del anfitrión asignados para esta MV"
 ],
 "No network devices": [
  null,
  "No hay dispositivos de red"
 ],
 "No network interfaces defined for this VM": [
  null,
  "No se han definido interfaces de red para esta MV"
 ],
 "No network is defined on this host": [
  null,
  "No hay una red definida en este anfitrión"
 ],
 "No networks available": [
  null,
  "No hay redes disponibles"
 ],
 "No parent": [
  null,
  "Sin padre"
 ],
 "No snapshots defined for this VM": [
  null,
  "No se han definido instantáneas para esta MV"
 ],
 "No state": [
  null,
  "Sin estado"
 ],
 "No storage": [
  null,
  "No hay almacenamiento"
 ],
 "No storage pool is defined on this host": [
  null,
  "No hay un grupo de almacenamiento definido en este anfitrión"
 ],
 "No storage pools available": [
  null,
  "No hay grupos de almacenamiento disponibles"
 ],
 "No storage volumes defined for this storage pool": [
  null,
  "No hay volúmenes de almacenamiento definidos para este grupo de almacenamiento"
 ],
 "No virtual networks": [
  null,
  "No hay redes virtuales"
 ],
 "No volumes exist in this storage pool.": [
  null,
  "No hay volúmenes en este grupo de almacenamiento."
 ],
 "Non-persistent network cannot be deleted. It ceases to exists when it's deactivated.": [
  null,
  "La red no persistente no se puede eliminar. Dejará de existir cuando está desactivado."
 ],
 "Non-persistent storage pool cannot be deleted. It ceases to exists when it's deactivated.": [
  null,
  "El grupo de almacenamiento no persistente no se puede eliminar. Dejará de existir cuando está desactivado."
 ],
 "None": [
  null,
  "Ninguno"
 ],
 "None (isolated network)": [
  null,
  "Ninguno (Red aislada)"
 ],
 "Offline token": [
  null,
  "Token sin conexión"
 ],
 "Offline token must not be empty": [
  null,
  "El Offline token no debe estar vacío"
 ],
 "Old token expired": [
  null,
  "El token ha caducado"
 ],
 "On the host": [
  null,
  "En el anfitrión"
 ],
 "One or more selected volumes are used by domains. Detach the disks first to allow volume deletion.": [
  null,
  "Hay dominios que están utilizando uno o más volúmenes de los que se han seleccionado. Desmonte primero los discos para poder eliminar los volúmenes."
 ],
 "Only editable when the guest is shut off": [
  null,
  "Solo se puede editar cuando el huésped esté apagado"
 ],
 "Open": [
  null,
  "Abierto"
 ],
 "Operating system": [
  null,
  "Sistema operativo"
 ],
 "Operation is in progress": [
  null,
  "La operación está en progreso"
 ],
 "Other VMs using SPICE": [
  null,
  "Otros VM utilizan SPICE"
 ],
 "Overview": [
  null,
  "Visión global"
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "Parent snapshot": [
  null,
  "Instantánea padre"
 ],
 "Password must be 8 characters or less. VNC passwords do not provide encryption and are generally cryptographically weak. They can not be used to secure connections in untrusted networks.": [
  null,
  ""
 ],
 "Password must be at most 8 characters.": [
  null,
  ""
 ],
 "Path": [
  null,
  "Ruta"
 ],
 "Path on host's filesystem": [
  null,
  "Ruta en el sistema de archivos del anfitrión"
 ],
 "Path to ISO file on host's file system": [
  null,
  "Ruta hacia la imagen ISO en el sistema de archivos del anfitrión"
 ],
 "Path to cloud image file on host's file system": [
  null,
  "Ruta a la imagen de nube en el sistema de archivos del anfitrión"
 ],
 "Path to directory": [
  null,
  "Ruta al directorio"
 ],
 "Path to file on host's file system": [
  null,
  "Ruta al archivo en el sistema de archivos del anfitrión"
 ],
 "Pause": [
  null,
  "Pausar"
 ],
 "Paused": [
  null,
  "Pausada"
 ],
 "Permanent (default)": [
  null,
  "Permanente (por defecto)"
 ],
 "Permissions denied for disk images in home directories": [
  null,
  "Sin permisos para imágenes de disco en carpetas personales"
 ],
 "Persistence": [
  null,
  "Persistencia"
 ],
 "Persistent": [
  null,
  "Persistente"
 ],
 "Physical disk device": [
  null,
  "Dispositivo de disco físico"
 ],
 "Physical disk device on host": [
  null,
  "Dispositivo de disco físico en el anfitrión"
 ],
 "Please choose a different MAC address": [
  null,
  "Por favor, escoja otra dirección MAC"
 ],
 "Please choose a storage pool": [
  null,
  "Escoja un grupo de almacenamiento"
 ],
 "Please choose a volume": [
  null,
  "Seleccione un volumen"
 ],
 "Please enter new volume name": [
  null,
  "Introduzca el nuevo nombre del volumen"
 ],
 "Please see $0 how to reconfigure your VM manually.": [
  null,
  "Por favor, consulte $0 para ver cómo reconfigurar su MV de forma manual."
 ],
 "Pool": [
  null,
  "Grupo"
 ],
 "Pool needs to be active to create volume": [
  null,
  "El grupo de almacenamiento debe estar activo para poder crear el volumen"
 ],
 "Pool type $0 does not support volume creation": [
  null,
  "El grupo de almacenamiento tipo $0 no soporta la creación de volúmenes"
 ],
 "Pool type doesn't support volume creation": [
  null,
  "El tipo de grupo no soporta la creación de volúmenes"
 ],
 "Pool's volumes are used by VMs ": [
  null,
  "Las MVs están utilizando un grupo de volúmenes: "
 ],
 "Port": [
  null,
  "Puerto"
 ],
 "Port must be 5900 or larger.": [
  null,
  ""
 ],
 "Port must be a number that is at least 5900. Leave empty to automatically assign a free port when the machine starts.": [
  null,
  ""
 ],
 "Power off": [
  null,
  "Apagar"
 ],
 "Pre-formatted block device": [
  null,
  "Dispositivo de bloques pre-formateado"
 ],
 "Preferred number of sockets to expose to the guest.": [
  null,
  "Número preferido de sockets para exponerle al huésped."
 ],
 "Prefix": [
  null,
  "Prefijo"
 ],
 "Prefix length": [
  null,
  "Longitud del prefijo"
 ],
 "Prefix length should not be empty": [
  null,
  "La longitud del prefijo no debe estar vacía"
 ],
 "Previously taken snapshots allow you to revert to an earlier state if something goes wrong": [
  null,
  "Las instantáneas guardadas con anterioridad le permiten revertir a un estado anterior si algo sale mal"
 ],
 "Private": [
  null,
  "Privado"
 ],
 "Product": [
  null,
  "Producto"
 ],
 "Profile": [
  null,
  "Perfil"
 ],
 "Protocol": [
  null,
  "Protocolo"
 ],
 "Provides a bridge from the guest virtual machine directly onto the LAN. This needs a bridge device on the host with one or more physical NICs.": [
  null,
  "Provee un puente entre el huésped de la MV directamente con la LAN. Se necesita un dispositivo de puente en el anfitrión con una o más tarjetas de red."
 ],
 "Provides a connection whose details are described by the named network definition.": [
  null,
  "Provee una conexión especificada según la convención de nombrado de redes."
 ],
 "Provides a virtual LAN with NAT to the outside world.": [
  null,
  "Provee una LAN virtual con una NAT al mundo exterior."
 ],
 "Public SSH key": [
  null,
  "Clave SSH pública"
 ],
 "Public key": [
  null,
  "Clave pública"
 ],
 "Range": [
  null,
  "Rango"
 ],
 "Read-only": [
  null,
  "Solo lectura"
 ],
 "Reboot": [
  null,
  "Reiniciar"
 ],
 "Reboot $0?": [
  null,
  "¿Reiniciar $0?"
 ],
 "Recommended operating systems": [
  null,
  "Sistema operativo recomendado"
 ],
 "Released $0": [
  null,
  "Publicado $0"
 ],
 "Remote URL": [
  null,
  "URL remota"
 ],
 "Remote viewer applications can connect to the following address:": [
  null,
  ""
 ],
 "Remove": [
  null,
  "Eliminar"
 ],
 "Remove SPICE audio and host devices": [
  null,
  "Eliminar sonido SPICE y dispositivos de host"
 ],
 "Remove and delete file": [
  null,
  "Quitar y eliminar fichero"
 ],
 "Remove disk from VM?": [
  null,
  "¿Quitar el disco de la MV?"
 ],
 "Remove filesystem?": [
  null,
  "¿Quitar el sistema de archivos?"
 ],
 "Remove host device from VM?": [
  null,
  "¿Quitar el dispositivo del anfitrión de la MV?"
 ],
 "Remove item": [
  null,
  "Eliminar elemento"
 ],
 "Remove network interface?": [
  null,
  "¿Quitar la interfaz de red?"
 ],
 "Remove static host from DHCP": [
  null,
  "Eliminar host estático de DHCP"
 ],
 "Rename": [
  null,
  "Renombrar"
 ],
 "Rename VM $0": [
  null,
  "Renombrar la MV $0"
 ],
 "Replace": [
  null,
  "Reemplazar"
 ],
 "Replace SPICE devices": [
  null,
  "Reemplazar los dispositivos SPICE"
 ],
 "Replace SPICE devices in VM $0": [
  null,
  "Reemplazar los dispositivos SPICE en la MV $0"
 ],
 "Replace SPICE on selected VMs.": [
  null,
  "Reemplazar SPICE en los VM seleccionados."
 ],
 "Replace SPICE on the virtual machine.": [
  null,
  "Sustituye SPICE en la máquina virtual."
 ],
 "Reset": [
  null,
  "Reiniciar"
 ],
 "Restrictions in networking (SLIRP-based emulation) and PCI device assignment": [
  null,
  "Restricciones de red (emulación basada en SLIRP) y de asignación de dispositivos PCI"
 ],
 "Resume": [
  null,
  "Reanudar"
 ],
 "Revert": [
  null,
  "Revertir"
 ],
 "Revert to snapshot $0": [
  null,
  "Revertir a la instantánea $0"
 ],
 "Reverting to this snapshot will take the VM back to the time of the snapshot and the current state will be lost, along with any data not captured in a snapshot": [
  null,
  "Revertir a esta instantánea llevará a la MV al momento de toma de la instantánea y se perderá el estado actual, además de cualquier información que no se almacene en las instantáneas"
 ],
 "Root password": [
  null,
  "Contraseña del usuario root"
 ],
 "Route to $0": [
  null,
  "Ruta para $0"
 ],
 "Routed network": [
  null,
  "Red enrutada"
 ],
 "Row select": [
  null,
  "Seleccione fila"
 ],
 "Run": [
  null,
  "Ejecutar"
 ],
 "Run when host boots": [
  null,
  "Ejecutar cuando el anfitrión arranque"
 ],
 "Running": [
  null,
  "Ejecutándose"
 ],
 "SPICE": [
  null,
  "SPICE"
 ],
 "SPICE conversion": [
  null,
  "Conversión SPICE"
 ],
 "SPICE is not supported on this host and will cause this virtual machine to not boot.": [
  null,
  "Este anfitrión no tiene soporte de SPICE, por lo que la maquina virtual no podrá arrancar."
 ],
 "SSH keys": [
  null,
  "Claves SSH"
 ],
 "Save": [
  null,
  "Guardar"
 ],
 "Select all": [
  null,
  "Seleccionar todo"
 ],
 "Send key": [
  null,
  "Enviar tecla"
 ],
 "Send non-maskable interrupt": [
  null,
  "Enviar interrupción no enmascarable"
 ],
 "Send non-maskable interrupt to $0?": [
  null,
  "¿Enviar interrupción no enmascarable a $0?"
 ],
 "Serial": [
  null,
  "Número de serie"
 ],
 "Serial console": [
  null,
  "Consola serie"
 ],
 "Serial console support not enabled": [
  null,
  ""
 ],
 "Set DHCP range": [
  null,
  "Establecer un rango DHCP"
 ],
 "Set manually": [
  null,
  "Establecer manualmente"
 ],
 "Setting the user passwords for unattended installation requires starting the VM when creating it": [
  null,
  "Establecer las contraseñas de usuario para la instalación desatendida requiere iniciar la MV al crearla"
 ],
 "Share": [
  null,
  "Compartir"
 ],
 "Share a host directory with the guest": [
  null,
  "Compartir un directorio del anfitrión con el huésped"
 ],
 "Shared directories": [
  null,
  "Directorios compartidos"
 ],
 "Shared host directories need to be manually mounted inside the VM": [
  null,
  "Los directorios compartidos deben ser montados manualmente dentro de la MV"
 ],
 "Shared storage": [
  null,
  "Almacenamiento compartido"
 ],
 "Show additional options": [
  null,
  "Mostrar opciones adicionales"
 ],
 "Show less": [
  null,
  "Mostrar menos"
 ],
 "Show more": [
  null,
  "Mostrar más"
 ],
 "Shut down": [
  null,
  "Apagar"
 ],
 "Shut down $0?": [
  null,
  "¿Apagar $0?"
 ],
 "Shut off": [
  null,
  "Apagada"
 ],
 "Shut off the VM in order to edit firmware configuration": [
  null,
  "Apague la MV para modificar la configuración del firmware"
 ],
 "Shutting down": [
  null,
  "Apagándose"
 ],
 "Size": [
  null,
  "Tamaño"
 ],
 "Slot": [
  null,
  "Ranura"
 ],
 "Snapshot $0 could not be deleted": [
  null,
  "No se pudo eliminar la instantánea $0"
 ],
 "Snapshot $0 will be deleted from $1. All of its captured content will be lost.": [
  null,
  "Se borrará la instantánea $0 de $1. Se perderá todo su contenido capturado."
 ],
 "Snapshot failed to be created": [
  null,
  "No se pudo crear la instantánea"
 ],
 "Snapshots": [
  null,
  "Instantáneas"
 ],
 "Sockets": [
  null,
  "Zócalos"
 ],
 "Some configuration changes only take effect after a fresh boot:": [
  null,
  "Algunos cambios de configuración sólo toman efecto tras un inicio desde cero:"
 ],
 "Source": [
  null,
  "Fuente"
 ],
 "Source format": [
  null,
  "Formato fuente"
 ],
 "Source must not be empty": [
  null,
  "El origen no debe estar vacío"
 ],
 "Source path": [
  null,
  "Dirección de origen"
 ],
 "Source path should not be empty": [
  null,
  "La ruta de origen no debe estar vacía"
 ],
 "Source should start with http, ftp or nfs protocol": [
  null,
  "La fuente debería empezar con http, ftp o protocolo nfs"
 ],
 "Source volume group": [
  null,
  "Origen del grupo de volumen"
 ],
 "Start": [
  null,
  "Iniciar"
 ],
 "Start pool when host boots": [
  null,
  "Iniciar el grupo cuando el anfitrión arranque"
 ],
 "Start should not be empty": [
  null,
  "El inicio del rango no debe estar vacío"
 ],
 "Started": [
  null,
  "Iniciado"
 ],
 "Startup": [
  null,
  "Puesta en marcha"
 ],
 "State": [
  null,
  "Estado"
 ],
 "Static host entries": [
  null,
  "Entradas de host estático"
 ],
 "Static host from DHCP could not be removed": [
  null,
  "No se pudo eliminar la entrada de host estático de DHCP"
 ],
 "Storage": [
  null,
  "Almacenamiento"
 ],
 "Storage is at a shared location": [
  null,
  "El almacenamiento se encuentra en una ubicación compartida"
 ],
 "Storage limit": [
  null,
  "Límite de almacenamiento"
 ],
 "Storage pool $0 failed to get activated": [
  null,
  "El grupo de almacenamiento $0 falló al activarse"
 ],
 "Storage pool $0 failed to get deactivated": [
  null,
  "El grupo de almacenamiento $0 falló al desactivarse"
 ],
 "Storage pool failed to be created": [
  null,
  "No se pudo crear el grupo de almacenamiento"
 ],
 "Storage pool name": [
  null,
  "Nombre del grupo de almacenamiento"
 ],
 "Storage pools": [
  null,
  "Grupos de almacenamiento"
 ],
 "Storage pools could not be fetched": [
  null,
  "No se pudo acceder a los grupos de almacenamiento"
 ],
 "Storage size must not be 0": [
  null,
  "El tamaño del almacenamiento no debe ser 0"
 ],
 "Storage volume": [
  null,
  "Volumen de almacenamiento"
 ],
 "Storage volume size must not exceed the storage pool's capacity ($0 $1)": [
  null,
  "El tamaño del volumen de almacenamiento no puede ser superior a la capacidad del grupo de almacenamiento ($0 $1)"
 ],
 "Storage volumes": [
  null,
  "Volúmenes de almacenamiento"
 ],
 "Storage volumes could not be deleted": [
  null,
  "Los volúmenes de almacenamiento no se pueden eliminar"
 ],
 "Storage volumes must be shared between this host and the destination host.": [
  null,
  "Los volúmenes de almacenamiento deben estar compartidos entre este anfitrión y el anfitrión de destino."
 ],
 "Suspended (PM)": [
  null,
  "suspendido (PM)"
 ],
 "Switch to VNC to continue using this machine.": [
  null,
  "Cambie a VNC para continuar usando esta máquina."
 ],
 "System": [
  null,
  "Sistema"
 ],
 "TAP device": [
  null,
  "Dispositivo TAP"
 ],
 "TPM": [
  null,
  "TPM"
 ],
 "Table of selectable host devices": [
  null,
  "Tabla con los dispositivos del anfitrión seleccionables"
 ],
 "Target": [
  null,
  "Objetivo"
 ],
 "Target path": [
  null,
  "Ruta de destino"
 ],
 "Target path should not be empty": [
  null,
  "La ruta de destino no debe estar vacía"
 ],
 "Temporary": [
  null,
  "Temporal"
 ],
 "Temporary migration": [
  null,
  "Migración temporal"
 ],
 "The VM $0 is running and will be forced off before deletion.": [
  null,
  "La MV $0 está ejecutándose y se forzará su apagado antes de la eliminación."
 ],
 "The VM needs to be running or shut off to detach this device": [
  null,
  "La máquina virtual necesita ejecutarse o apagarse para desmontar este dispositivo"
 ],
 "The directory on the server being exported": [
  null,
  "El directorio en el servidor se está exportando"
 ],
 "The host path that is to be exported.": [
  null,
  "La ruta del anfitrión a exportar."
 ],
 "The migrated VM configuration is removed from the source host. The destination host is considered the new home of the VM.": [
  null,
  "La configuración de la MV migrada se elimina del anfitrión de origen. El anfitrión de destino se considera el nuevo hogar de la MV."
 ],
 "The mode influences the delivery of packets.": [
  null,
  "El modo influye en la entrega de paquetes."
 ],
 "The pool is empty": [
  null,
  "El grupo está vacío"
 ],
 "The selected operating system has minimum memory requirement of $0 $1": [
  null,
  "El sistema operativo seleccionado tiene una memoria mínima necesaria de $0 $1"
 ],
 "The selected operating system has minimum storage size requirement of $0 $1": [
  null,
  "El sistema operativo tiene un almacenamiento mínimo que requerido de $0 $1"
 ],
 "The static host entry for $0 will be removed:": [
  null,
  "Se eliminará la entrada de host estático $0:"
 ],
 "The storage pool could not be deleted": [
  null,
  "No se pudo eliminar el grupo de almacenamiento"
 ],
 "The tag name to be used by the guest to mount this export point.": [
  null,
  "El nombre de la etiqueta usada por el huésped para montar esta ubicación exportada."
 ],
 "Then copy and paste it above.": [
  null,
  "Después copie y péguelo arriba."
 ],
 "This VM is transient. Shut it down if you wish to delete it.": [
  null,
  "Esta MV es temporal. Apáguela si desea eliminarla."
 ],
 "This disk will be removed from $0:": [
  null,
  "Este disco será quitado de $0:"
 ],
 "This filesystem will be removed from $0:": [
  null,
  "Este sistema de archivos será quitado de $0:"
 ],
 "This is intended for a host which does not support SPICE due to upgrades or live migration.": [
  null,
  "Esto se intenta para un host el cual no admite SPICE debido a mejoras o migraciones en vivo."
 ],
 "This is the recommended type for general guest connectivity on hosts with dynamic / wireless networking configs.": [
  null,
  "Este es el tipo recomendado para conectividad de huéspedes usual en anfitriones con configuraciones de red dinámica o inalámbrica."
 ],
 "This is the recommended type for general guest connectivity on hosts with static wired networking configs.": [
  null,
  "Esta es el tipo de configuración general de conectividad de huéspedes recomendada para anfitriones en redes fijas cableadas."
 ],
 "This is the recommended type for high performance or enhanced security.": [
  null,
  "Este es el tipo recomendado para rendimiento alto o seguridad mejorada."
 ],
 "This machine has a SPICE graphical console that can not be shown here.": [
  null,
  ""
 ],
 "This volume is already used by $0.": [
  null,
  "Este volumen ya lo utiliza $0."
 ],
 "This volume is already used by another VM.": [
  null,
  "Otra MV ya utiliza este volumen."
 ],
 "Threads per core": [
  null,
  "Hilos por núcleo"
 ],
 "Total space available: $0.": [
  null,
  "Espacio disponible total: $0."
 ],
 "Transient VMs don't support editing firmware configuration": [
  null,
  "Las MVs que son temporales no tienen soporte para editar la configuración del firmware"
 ],
 "Troubleshoot": [
  null,
  "Soporte"
 ],
 "Type": [
  null,
  "Tipo"
 ],
 "URL (ISO image or distro install tree)": [
  null,
  "URL (imagen ISO o lista de instalación de distribución)"
 ],
 "USB": [
  null,
  "USB"
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Undefined": [
  null,
  "Desconocido"
 ],
 "Unique name": [
  null,
  "Nombre único"
 ],
 "Unique name, default: $0": [
  null,
  "Nombre único, por defecto: $0"
 ],
 "Unique network name": [
  null,
  "Nombre único de red"
 ],
 "Unit": [
  null,
  "Unidad"
 ],
 "Unknown": [
  null,
  "Desconocido"
 ],
 "Unknown firmware": [
  null,
  "Firmware desconocido"
 ],
 "Unspecified": [
  null,
  "No especificada"
 ],
 "Unsupported and older operating systems": [
  null,
  "No mantenidos y sistema operativo más antiguo"
 ],
 "Url": [
  null,
  "URL"
 ],
 "Usage": [
  null,
  "Uso"
 ],
 "Use existing": [
  null,
  "Utilizar existente"
 ],
 "Use extended attributes on files and directories": [
  null,
  "Usar atributos extendidos en archivos y directorios"
 ],
 "Use the same location on both the origin and destination hosts for your storage. This can be a shared storage pool, NFS, or any other method of sharing storage.": [
  null,
  "Se utiliza la misma ubicación para el almacenamiento tanto en el anfitrión origen como destino. Esta ubicación puede ser un grupo de almacenamiento, NFS o cualquier otro método de almacenamiento compartido."
 ],
 "Used": [
  null,
  "Usado"
 ],
 "Used by": [
  null,
  "Usado por"
 ],
 "User login": [
  null,
  "Ingreso de usuario"
 ],
 "User login must not be empty when SSH keys are set": [
  null,
  "El usuario no debe estar vacío cuando se han asignado claves SSH"
 ],
 "User login must not be empty when user password is set": [
  null,
  "El usuario no debe estar vacío cuando se ha asignado la contraseña de usuario"
 ],
 "User password": [
  null,
  "Contraseña de usuario"
 ],
 "User password must not be empty when user login is set": [
  null,
  "La contraseña de usuario no debe estar vacía cuando se ha asignado el usuario"
 ],
 "User session": [
  null,
  "Sesión de usuario"
 ],
 "Uses SPICE": [
  null,
  "Usa SPICE"
 ],
 "VM $0 Host Devices": [
  null,
  "Dispositivos del anfitrión en la MV $0"
 ],
 "VM $0 already exists": [
  null,
  "La MV $0 ya existe"
 ],
 "VM $0 does not exist on $1 connection": [
  null,
  "La MV $0 no existe en la conexión $1"
 ],
 "VM $0 failed to force reboot": [
  null,
  "La MV $0 falló al forzar el reinicio"
 ],
 "VM $0 failed to force shutdown": [
  null,
  "La MV $0 falló al forzar un apagado"
 ],
 "VM $0 failed to get installed": [
  null,
  "La MV $0 falló al instalarse"
 ],
 "VM $0 failed to pause": [
  null,
  "La MV $0 falló al pausarse"
 ],
 "VM $0 failed to reboot": [
  null,
  "La MV $0 falló al reiniciarse"
 ],
 "VM $0 failed to resume": [
  null,
  "La MV $0 falló al despausarse"
 ],
 "VM $0 failed to send NMI": [
  null,
  "La MV $0 falló al enviar el NMI"
 ],
 "VM $0 failed to shutdown": [
  null,
  "La MV $0 falló al apagarse"
 ],
 "VM $0 failed to start": [
  null,
  "La MV $0 falló al arrancarse"
 ],
 "VM launched with unprivileged limited access, with the process and PTY owned by your user account": [
  null,
  "MV lanzada con acceso limitado sin privilegios, con tu usuario como propietario del proceso y PTY"
 ],
 "VM needs shutdown": [
  null,
  "La MV necesita apagarse"
 ],
 "VM state": [
  null,
  "Estado de la MV"
 ],
 "VM will launch with root permissions": [
  null,
  "MV lanzada con permisos de root"
 ],
 "VNC": [
  null,
  ""
 ],
 "Valid token": [
  null,
  "Token válido"
 ],
 "Vendor": [
  null,
  "Proveedor"
 ],
 "Vendor support ended $0": [
  null,
  "Soporte del proveedor finalizado $0"
 ],
 "Virtual machines": [
  null,
  "Máquinas virtuales"
 ],
 "Virtual machines management": [
  null,
  "Gestión de máquinas virtuales"
 ],
 "Virtual network": [
  null,
  "Red virtual"
 ],
 "Virtual network failed to be created": [
  null,
  "La red virtual falló al crearse"
 ],
 "Virtual socket support enables communication between the host and guest over a socket. It still requires special vsock-aware software to communicate over the socket.": [
  null,
  "El soporte para sockets virtuales (vsock) permite la comunicación entre anfitrión y huésped a través de un socket. Se requiere software especial compatible con vsock para comunicarse por el socket."
 ],
 "Virtualization service (libvirt) is not active": [
  null,
  "Servicio de virtualización (libvirt) no está activo"
 ],
 "Volume": [
  null,
  "Volumen"
 ],
 "Volume failed to be created": [
  null,
  "El volumen falló al crearse"
 ],
 "Volume group name": [
  null,
  "Nombre del grupo de volumen"
 ],
 "Volume group name should not be empty": [
  null,
  "El grupo de volumen no debe estar vacío"
 ],
 "Vsock": [
  null,
  "Vsock"
 ],
 "WWPN": [
  null,
  "WWPN"
 ],
 "Watchdog": [
  null,
  "Watchdog"
 ],
 "Watchdogs act when systems stop responding. To use this virtual watchdog device, the guest system also needs to have an additional driver and a running watchdog service.": [
  null,
  "Los watchdog actúan cuando los sistemas dejan de responder. Para usar este dispositivo watchdog virtual, el sistema anfitrión debe tener un driver adicional y ejecutar un servicio watchdog."
 ],
 "Writeable": [
  null,
  "Puede escribirse"
 ],
 "You can mount the shared folder using:": [
  null,
  "Puedes montar el directorio compartido usando:"
 ],
 "You need to select the most closely matching operating system": [
  null,
  "Debe seleccionar el sistema operativo que mejor se ajuste"
 ],
 "active": [
  null,
  "activo"
 ],
 "add": [
  null,
  "añadir"
 ],
 "add entry": [
  null,
  "añadir entrada"
 ],
 "bridge": [
  null,
  "puente"
 ],
 "cdrom": [
  null,
  "cdrom"
 ],
 "custom": [
  null,
  "personalizado"
 ],
 "direct": [
  null,
  "directo"
 ],
 "disabled": [
  null,
  "desactivado"
 ],
 "disk": [
  null,
  "disco"
 ],
 "down": [
  null,
  "apagado"
 ],
 "edit": [
  null,
  "editar"
 ],
 "enabled": [
  null,
  "activado"
 ],
 "ethernet": [
  null,
  "ethernet"
 ],
 "host": [
  null,
  "anfitrión"
 ],
 "host device": [
  null,
  "dispositivo del anfitrión"
 ],
 "host passthrough": [
  null,
  "traspaso del anfitrión"
 ],
 "hostdev": [
  null,
  "hostdev"
 ],
 "iSCSI direct target": [
  null,
  "Objetivo directo iSCI"
 ],
 "iSCSI initiator IQN": [
  null,
  "Iniciador de iSCSI IQN"
 ],
 "iSCSI target": [
  null,
  "Objetivo iSCSI"
 ],
 "iSCSI target IQN": [
  null,
  "Objetivo de iSCSI en IQN"
 ],
 "inactive": [
  null,
  "inactivo"
 ],
 "inet": [
  null,
  "inet"
 ],
 "inet6": [
  null,
  "inet6"
 ],
 "mcast": [
  null,
  "mcast"
 ],
 "more info": [
  null,
  "más información"
 ],
 "mount point: The mount point inside the guest": [
  null,
  "mount point: la ruta de montaje en el huésped"
 ],
 "mount tag: The tag associated to the exported mount point": [
  null,
  "mount tag: la etiqueta asociada a la ruta de montaje exportada"
 ],
 "network": [
  null,
  "red"
 ],
 "no": [
  null,
  "no"
 ],
 "no state saved": [
  null,
  "no hay estado almacenado"
 ],
 "none": [
  null,
  "ninguna"
 ],
 "redirected device": [
  null,
  "dispositivo redirigido"
 ],
 "remove": [
  null,
  "eliminar"
 ],
 "serial number": [
  null,
  "número de serie"
 ],
 "server": [
  null,
  "servidor"
 ],
 "udp": [
  null,
  "udp"
 ],
 "up": [
  null,
  "encendido"
 ],
 "user": [
  null,
  "usuario"
 ],
 "vCPU and CPU topology settings could not be saved": [
  null,
  "No se pudo guardar la configuración de topología de vCPU y CPU"
 ],
 "vCPU count": [
  null,
  "Número de vCPU"
 ],
 "vCPU maximum": [
  null,
  "Máximo de vCPU"
 ],
 "vCPUs": [
  null,
  "vCPUs"
 ],
 "vhostuser": [
  null,
  "vhostuser"
 ],
 "view more...": [
  null,
  "ver más..."
 ],
 "virt-install package needs to be installed on the system in order to clone VMs": [
  null,
  "Es necesario instalar el paquete virt-install para poder clonar MVs"
 ],
 "virt-install package needs to be installed on the system in order to create new VMs": [
  null,
  "Hay que instalar el paquete virt-install para poder crear nuevas máquinas virtuales"
 ],
 "virt-install package needs to be installed on the system in order to edit this attribute": [
  null,
  "Es necesario instalar el paquete virt-install para poder modificar este atributo"
 ],
 "vsock requires special software": [
  null,
  "vsock requiere software especial"
 ],
 "yes": [
  null,
  "sí"
 ]
});
