cockpit.locale({
 "": {
  "plural-forms": (n) => n==0 ? 0 : n==1 ? 1 : n==2 ? 2 : n%100>=3 && n%100<=10 ? 3 : n%100>=11 ? 4 : 5,
  "language": "ar",
  "language-direction": "rtl"
 },
 "$0 $1 available at default location": [
  null,
  "$0 $1 متاح في الموقع الافتراضي"
 ],
 "$0 $1 available on host": [
  null,
  "$0 $1 متاح على المضيف"
 ],
 "$0 CPU details": [
  null,
  "$0 تفاصيل المعالج"
 ],
 "$0 Network": [
  null,
  "بلا شبكة",
  "شبكة واحدة",
  "شبكتان",
  "$0 شبكات",
  "$0 شبكة",
  "$0 شبكة"
 ],
 "$0 Storage pool": [
  null,
  "بلا مجمع تخزين",
  "مجمع تخزين واحد",
  "مجمعا تخزين",
  "$0 مجمعاً للتخزين",
  "$0 مجمع تخزين",
  "$0 مجمع تخزين"
 ],
 "$0 does not support unattended installation.": [
  null,
  "لا يدعم $0 التثبيت بدون وجود مستخدم."
 ],
 "$0 memory adjustment": [
  null,
  "تعديل الذاكرة $0"
 ],
 "$0 network": [
  null,
  "الشبكة $0"
 ],
 "$0 vCPU": [
  null,
  "$0 نواة افتراضية",
  "نواة معالج افتراضية واحدة",
  "نواتنا معالج افتراضيتان",
  "$0 أنوية معالج افتراضية",
  "$0 نواة معالج افتراضية",
  "$0 نواة معالج افتراضية"
 ],
 "$0 virtual network interface settings": [
  null,
  "إعدادات واجهة الشبكة الافتراضية $0"
 ],
 "A copy of the VM will run on the destination and will disappear when it is shut off. Meanwhile, the origin host keeps its copy of the VM configuration.": [
  null,
  "سيتم تشغيل نسخة من الآلة الافتراضية على الوجهة وستختفي عند إيقاف تشغيلها. في الوقت نفسه:يحتفظ المضيف الأصلي بنسخته من تكوين الآلة الافتراضية."
 ],
 "Access": [
  null,
  "وصول"
 ],
 "Action": [
  null,
  "نشاط"
 ],
 "Actions": [
  null,
  "إجراءات"
 ],
 "Activate": [
  null,
  "التنشيط"
 ],
 "Activate the storage pool to administer volumes": [
  null,
  "تفعيل مجمّع التخزين لإدارة الوحدات التخزينية"
 ],
 "Add": [
  null,
  "إضافة"
 ],
 "Add SSH keys": [
  null,
  "أضف مفاتيح SSH"
 ],
 "Add TPM": [
  null,
  "أضف TPM"
 ],
 "Add VNC": [
  null,
  "إضافة VNC"
 ],
 "Add a DHCP static host entry": [
  null,
  "إضافة إدخال مضيف DHCP ثابت"
 ],
 "Add disk": [
  null,
  "إضافة قرص"
 ],
 "Add host device": [
  null,
  "إضافة جهاز مضيف"
 ],
 "Add network interface": [
  null,
  "إضافة واجهة شبكة"
 ],
 "Add shared directory": [
  null,
  "إضافة مجلد مشاركة"
 ],
 "Add virtual network interface": [
  null,
  "إضافة واجهة شبكية افتراضية"
 ],
 "Add vsock interface": [
  null,
  "إضافة واجهة vsock"
 ],
 "Add watchdog device type": [
  null,
  "إضافة جهاز Watchdog"
 ],
 "Adding a watchdog will require a reboot to take effect.": [
  null,
  "إضافة Watchdog ستتطلب إعادة تشغيل النظام لتصبح فعالة."
 ],
 "Adding shared directories is possible only when the guest is shut off": [
  null,
  "إضافة مجلدات مشتركة ممكنة فقط عندما يكون النظام الضيف مُطفأً"
 ],
 "Additional": [
  null,
  "إضافي"
 ],
 "Address": [
  null,
  "العنوان"
 ],
 "Address not within subnet": [
  null,
  "العنوان ليس ضمن الشبكة الفرعية"
 ],
 "All": [
  null,
  "الكل"
 ],
 "All VM activity, including storage, will be temporary. This will result in data loss on the destination host.": [
  null,
  "كل نشاطات الآلة الافتراضية - وتشمل التخزين - ستكون مؤقتة. سيؤدي هذا إلى فقدان البيانات على المضيف الهدف."
 ],
 "Allowed characters: basic Latin alphabet, numbers, and limited punctuation (-, _, +, .)": [
  null,
  "الأحرف المسموح بها: الحروف الأبجدية اللاتينية الأساسية، والأرقام، وعلامات الترقيم المحدودة (-, _، _، +، .)"
 ],
 "Also delete all volumes inside this pool:": [
  null,
  "احذف أيضاً جميع وحدات التخزين داخل هذا المجمع:"
 ],
 "Always attach": [
  null,
  "أرفق دائماً"
 ],
 "An example of vsock-aware software is socat": [
  null,
  "من الأمثلة على برمجيات تدعم vsock هو أداة socat"
 ],
 "Apply": [
  null,
  "تطبيق"
 ],
 "Apply on next boot": [
  null,
  "طبّق عند إقلاع النظام التالي"
 ],
 "Assign automatically": [
  null,
  "تعيين تلقائي"
 ],
 "Automated installs are only available when downloading an image or using cloud-init.": [
  null,
  "تتوفر التثبيتات التلقائية فقط عند تنزيل صورة أو استخدام cloud-init."
 ],
 "Automatic": [
  null,
  "تلقائي"
 ],
 "Automation": [
  null,
  "أتمتة"
 ],
 "Autostart": [
  null,
  "بدء تلقائي"
 ],
 "Block device": [
  null,
  "حجب الجحاز"
 ],
 "Blocked": [
  null,
  "محظور"
 ],
 "Boot order": [
  null,
  "طلب الإقلاع"
 ],
 "Boot order settings could not be saved": [
  null,
  "تعذّر حفظ إعدادات تسلسل الإقلاع"
 ],
 "Bus": [
  null,
  "ناقل"
 ],
 "CD/DVD disc": [
  null,
  "قرص CD/DVD"
 ],
 "CPU": [
  null,
  "المعالج"
 ],
 "CPU mode could not be saved": [
  null,
  "تعذر حفظ وضع وحدة المعالج"
 ],
 "Cache": [
  null,
  "ذاكرة التخزين المؤقت"
 ],
 "Cancel": [
  null,
  "إلغاء"
 ],
 "Cannot edit vsock device on a transient VM": [
  null,
  "لا يمكن تعديل جهاز vsock في آلة افتراضية عابرة (transient VM)"
 ],
 "Cannot edit watchdog device on a transient VM": [
  null,
  "لا يمكن تعديل جهاز watchdog في آلة افتراضية عابرة (transient VM)"
 ],
 "Capacity": [
  null,
  "السعة"
 ],
 "Change boot order": [
  null,
  "تغيير تسلسل الإقلاع"
 ],
 "Change firmware": [
  null,
  "تغيير البرنامج الثابت"
 ],
 "Changes pending": [
  null,
  "التغييرات قيد التنفيذ"
 ],
 "Changes will take effect after shutting down the VM": [
  null,
  "ستصبح التغييرات سارية المفعول بعد إيقاف تشغيل الجهاز الافتراضي"
 ],
 "Changing BIOS/EFI settings is specific to each manufacturer. It involves pressing a hotkey during boot (ESC, F1, F12, Del). Enable a setting called \"virtualization\", \"VM\", \"VMX\", \"SVM\", \"VTX\", \"VTD\". Consult your computer's manual for details.": [
  null,
  "تغيير إعدادات BIOS/EFI مختلف عند كل مصنع. يتضمن الضغط على أحد مفاتيح التشغيل السريع أثناء الإقلاع (ESC، F1، F12، Del). فعِّل إعداداً يسمى \"virtualization\"، \"VM\"، \"VMX\"، \"SVM\"، \"VTX\"، \"VTD\". راجع دليل جهازك للحصول على التفاصيل."
 ],
 "Checking token validity...": [
  null,
  "جاري التحقق من صلاحية الرمز الفريد..."
 ],
 "Choose an operating system": [
  null,
  "اختر نظام تشغيل"
 ],
 "Class": [
  null,
  "الصنف"
 ],
 "Clone": [
  null,
  "استنساخ"
 ],
 "Close": [
  null,
  "أغلق"
 ],
 "Cloud base image": [
  null,
  "صورة الأساس السحابية"
 ],
 "Compress": [
  null,
  "ضغط"
 ],
 "Concurrently writeable": [
  null,
  "قابل للكتابة بشكل متزامن"
 ],
 "Confirm this action": [
  null,
  "تأكيد هذا الإجراء"
 ],
 "Connect": [
  null,
  "اتصال"
 ],
 "Connection": [
  null,
  "الاتصال"
 ],
 "Console": [
  null,
  "وحدة تحكم"
 ],
 "Convert QXL video card to VGA": [
  null,
  "تحويل بطاقة الفيديو QXL إلى VGA"
 ],
 "Convert SPICE graphics console to VNC": [
  null,
  "تحويل وحدة تحكم رسوميات SPICE إلى VNC"
 ],
 "Copy storage": [
  null,
  "مخزن النسخ"
 ],
 "Copy to clipboard": [
  null,
  "نسخ للحافظة"
 ],
 "Cores per socket": [
  null,
  "النوى لكل مقبس"
 ],
 "Could not delete $0": [
  null,
  "تعذر حذف $0"
 ],
 "Could not delete all storage for $0": [
  null,
  "تعذر حذف كل التخزين لـ $0"
 ],
 "Could not delete disk's storage": [
  null,
  "تعذر حذف تخزين القرص"
 ],
 "Could not dynamically add watchdog": [
  null,
  "تعذر إضافة watchdog ديناميكيًا"
 ],
 "Could not revert to snapshot": [
  null,
  "تعذر الرجوع إلى اللقطة"
 ],
 "Crashed": [
  null,
  "تعطَّل"
 ],
 "Create": [
  null,
  "إنشاء"
 ],
 "Create VM": [
  null,
  "إنشاء جهاز افتراضي"
 ],
 "Create VM by importing a disk image of an existing VM installation": [
  null,
  "إنشاء آلة افتراضية عن طريق استيراد صورة قرص لتثبيت آلة افتراضية موجودة"
 ],
 "Create VM from local or network installation medium": [
  null,
  "إنشاء آلة افتراضية من وسيط التثبيت المحلي أو الشبكة"
 ],
 "Create a clone VM based on $0": [
  null,
  "إنشاء جهاز افتراضي مستنسخ على أساس $0"
 ],
 "Create and edit": [
  null,
  "إنشاء وتعديل"
 ],
 "Create and run": [
  null,
  "إنشاء ثم تشغيل"
 ],
 "Create new": [
  null,
  "إنشاء جديد"
 ],
 "Create new qcow2 volume": [
  null,
  "إنشاء قرص qcow2 جديد"
 ],
 "Create new raw volume": [
  null,
  "إنشاء قرص raw جديد"
 ],
 "Create new virtual machine": [
  null,
  "إنشاء جهاز افتراضي جديد"
 ],
 "Create snapshot": [
  null,
  "إنشاء لقطة"
 ],
 "Create storage pool": [
  null,
  "إنشاء مجمع تخزين"
 ],
 "Create storage volume": [
  null,
  "إنشاء وحدة تخزين"
 ],
 "Create virtual network": [
  null,
  "إنشاء شبكة افتراضية"
 ],
 "Create volume": [
  null,
  "إنشاء قرص تخزين"
 ],
 "Creating VM": [
  null,
  "قيد إنشاء جهاز افتراضي"
 ],
 "Creating VM $0": [
  null,
  "إنشاء الجهاز الافتراضي $0"
 ],
 "Creating snapshots of VMs with VFIO devices is not supported while they are running.": [
  null,
  "لا يتم دعم إنشاء لقطات للأجهزة الافتراضية مع أجهزة VFIO أثناء تشغيلها."
 ],
 "Creation of VM $0 failed": [
  null,
  "فشل إنشاء الجهاز الافتراضي $0"
 ],
 "Creation time": [
  null,
  "وقت الإنشاء"
 ],
 "Ctrl+Alt+$0": [
  null,
  "Ctrl+Alt+$0"
 ],
 "Current": [
  null,
  "(الحالي)"
 ],
 "Current allocation": [
  null,
  "التخصيص الحالي"
 ],
 "Custom firmware: $0": [
  null,
  "البرامج الثابتة المخصصة: $0"
 ],
 "Custom identifier": [
  null,
  "معرّف مخصص"
 ],
 "Custom path": [
  null,
  "مسار مخصص"
 ],
 "DHCP Settings": [
  null,
  "إعدادات DHCP"
 ],
 "Deactivate": [
  null,
  "إلغاء التنشيط"
 ],
 "Delete": [
  null,
  "حذف"
 ],
 "Delete $0 VM?": [
  null,
  "حذف الجهاز الافتراضي $0؟"
 ],
 "Delete $0 storage pool?": [
  null,
  "حذف مجمع التخزين $0؟"
 ],
 "Delete $0 volume": [
  null,
  "عدم حذف أي وحدة تحزين",
  "حذف وحدة تخزين واحدة",
  "حذف وحدتي تخزين",
  "حذف $0 وحدات تخزين",
  "حذف $0 وحدة تخزين",
  "حذف $0 وحدة تخزين"
 ],
 "Delete associated storage files:": [
  null,
  "حذف ملفات التخزين المرتبطة بها:"
 ],
 "Delete network?": [
  null,
  "حذف الشبكة؟"
 ],
 "Delete snapshot?": [
  null,
  "حذف اللقطة؟"
 ],
 "Deleting an inactive storage pool will only undefine the pool. Its content will not be deleted.": [
  null,
  "سيؤدي حذف مجمع تخزين غير نشط إلى إلغاء تعريف المجمع فقط. لن يتم حذف محتواه."
 ],
 "Deleting shared directories is possible only when the guest is shut off": [
  null,
  "يمكن حذف المجلدات المشتركة فقط عند إطفاء المستخدم الضيف"
 ],
 "Description": [
  null,
  "الوصف"
 ],
 "Deselect others": [
  null,
  "إلغاء تحديد البقية"
 ],
 "Destination URI": [
  null,
  "مصدر الوجهة"
 ],
 "Destination URI must not be empty": [
  null,
  "يجب ألا يكون عنوان الوجهة فارغاً"
 ],
 "Detach the disks using this pool from any VMs before attempting deletion.": [
  null,
  "افصل الأقراص باستخدام هذا المجمع من أي أجهزة افتراضية قبل محاولة الحذف."
 ],
 "Details": [
  null,
  "التفاصيل"
 ],
 "Device": [
  null,
  "جهاز"
 ],
 "Devices": [
  null,
  "الأجهزة"
 ],
 "Disconnect": [
  null,
  "قطع الاتصال"
 ],
 "Disconnected": [
  null,
  "مفصول"
 ],
 "Disconnected from serial console. Click the connect button.": [
  null,
  "مفصول عن وحدة التحكم التسلسلية. انقر فوق زر الاتصال."
 ],
 "Disk": [
  null,
  "قرص"
 ],
 "Disk $0 could not be removed": [
  null,
  "تعذر إزالة القرص $0"
 ],
 "Disk failed to be added": [
  null,
  "فشل إضافة القرص"
 ],
 "Disk identifier": [
  null,
  "معرف القرص"
 ],
 "Disk image": [
  null,
  "صورة القرص"
 ],
 "Disk image file": [
  null,
  "ملف صورة القرص"
 ],
 "Disk image path must not be empty": [
  null,
  "يجب ألا يكون مسار صورة القرص فارغاً"
 ],
 "Disk images can be stored in user home directory": [
  null,
  "يمكن تخزين صور القرص في المجلد الرئيسي للمستخدم"
 ],
 "Disk settings could not be saved": [
  null,
  "تعذر حفظ إعدادات القرص"
 ],
 "Disk-only snapshot": [
  null,
  "لقطة القرص فقط"
 ],
 "Disks": [
  null,
  "الأقراص"
 ],
 "Do not run this VM on the origin and destination hosts at the same time.": [
  null,
  "لا تقم بتشغيل هذا الجهاز الافتراضي على المضيفين الأصليين والوجهة في نفس الوقت."
 ],
 "Do nothing": [
  null,
  "لا تفعل شيئاً"
 ],
 "Domain has crashed": [
  null,
  "تعطل النطاق"
 ],
 "Domain is blocked on resource": [
  null,
  "النطاق محظور على المورد"
 ],
 "Download an OS": [
  null,
  "تنزيل نظام تشغيل"
 ],
 "Download progress": [
  null,
  "تقدم التنزيل"
 ],
 "Downloading image for VM $0": [
  null,
  "تنزيل صورة للجهاز الافتراضي $0"
 ],
 "Downloading: $0%": [
  null,
  "قيد التنزيل: $0%"
 ],
 "Dump core": [
  null,
  "قلب التفريغ"
 ],
 "Duration": [
  null,
  "المدة"
 ],
 "Dying": [
  null,
  "الموت"
 ],
 "Edit": [
  null,
  "عدِّل"
 ],
 "Edit $0 attributes": [
  null,
  "تعديل خصائص $0"
 ],
 "Edit description": [
  null,
  "تعديل الوصف"
 ],
 "Edit description of VM $0": [
  null,
  "تعديل الوصف للجهاز الافتراضي $0"
 ],
 "Edit vsock interface": [
  null,
  "تعديل واجهة vsock"
 ],
 "Edit watchdog device type": [
  null,
  "تعديل نوع جهاز watchdog"
 ],
 "Editing network interfaces of transient guests is not allowed": [
  null,
  "لا يُسمح بتعديل واجهات الشبكة الخاصة بالضيوف العابرين"
 ],
 "Editing transient network interfaces is not allowed": [
  null,
  "تعديل واجهات الشبكة العابرة غير مسموح به"
 ],
 "Eject": [
  null,
  "إخراج"
 ],
 "Eject disc from VM?": [
  null,
  "إخراج القرص من الجهاز الافتراضي؟"
 ],
 "Emulated machine": [
  null,
  "آلة مقلدة"
 ],
 "Enable virtualization support in BIOS/EFI settings.": [
  null,
  "تمكين دعم المحاكاة الافتراضية في إعدادات BIOS/EFI."
 ],
 "End": [
  null,
  "النهاية"
 ],
 "End should not be empty": [
  null,
  "يجب ألا تكون النهاية فارغة"
 ],
 "Enter root and/or user information to enable unattended installation.": [
  null,
  "أدخل معلومات الجذر و/أو المستخدم لتمكين التثبيت غير المراقب."
 ],
 "Error checking token": [
  null,
  "رمز التحقق من الخطأ"
 ],
 "Example, $0": [
  null,
  "على سبيل المثال، $0"
 ],
 "Existing disk image on host's file system": [
  null,
  "الصورة الموجودة على نظام الملفات للجهاز المضيف"
 ],
 "Expand": [
  null,
  "التوسعة"
 ],
 "Extended attributes": [
  null,
  "السمات الموسعة"
 ],
 "Failed": [
  null,
  "فشل"
 ],
 "Failed to add TPM to VM $0": [
  null,
  "لم يتم إضافة TPM إلى الجهاز الافتراضي $0"
 ],
 "Failed to add shared directory": [
  null,
  "فشل في إضافة مجلد مشترك"
 ],
 "Failed to change firmware": [
  null,
  "فشل في تغيير البرنامج الثابت"
 ],
 "Failed to clone VM $0": [
  null,
  "فشل في استنساخ الجهاز الافتراضي $0"
 ],
 "Failed to configure vsock": [
  null,
  "فشل في تهيئة vsock"
 ],
 "Failed to configure watchdog": [
  null,
  "فشل في تهيئة watchdog"
 ],
 "Failed to detach vsock": [
  null,
  "فشل في فصل vsock"
 ],
 "Failed to detach watchdog": [
  null,
  "فشل في فصل جهاز watchdog"
 ],
 "Failed to fetch some resources": [
  null,
  "فشل في جلب بعض الموارد"
 ],
 "Failed to fetch the IP addresses of the interfaces present in $0": [
  null,
  "فشل في جلب عناوين IP للواجهات الموجودة في $0"
 ],
 "Failed to rename VM $0": [
  null,
  "فشل في إعادا تسمية الجهاز الافتراضي $0"
 ],
 "Failed to replace SPICE devices": [
  null,
  "فشل في استبدال أجهزة SPICE"
 ],
 "Failed to save network settings": [
  null,
  "فشل فث حفظ إعدادات الشبكة"
 ],
 "Failed to send key Ctrl+Alt+$0 to VM $1": [
  null,
  "فشل في إرسال المفتاح Ctrl+Alt+$0 للجهاز الافتراضي $1"
 ],
 "Failed to set description of VM $0": [
  null,
  "فشل في تعيين وصف للجهاز الافتراضي $0"
 ],
 "Fewer than the maximum number of virtual CPUs should be enabled.": [
  null,
  "يجب تمكين عدد أقل من الحد الأقصى لعدد أنوية المعالج."
 ],
 "File": [
  null,
  "ملف"
 ],
 "Filesystem $0 could not be removed": [
  null,
  "تعذر إزالة نظام الملفات $0"
 ],
 "Filesystem directory": [
  null,
  "مجلد نظام الملفات"
 ],
 "Filter by name": [
  null,
  "التصفية حسب الاسم"
 ],
 "Firmware": [
  null,
  "برنامج ثابت"
 ],
 "Force eject": [
  null,
  "إخراج بالقوة"
 ],
 "Force reboot": [
  null,
  "إعادة تشغيل النظام بالقوة"
 ],
 "Force reboot $0?": [
  null,
  "إعادة تشغيل نظام $0 بالقوة؟"
 ],
 "Force revert": [
  null,
  "الإعادة بالقوة"
 ],
 "Force shut down": [
  null,
  "إيقاف التشغيل بالقوة"
 ],
 "Force shut down $0?": [
  null,
  "إيقاف تشغيل $0 بالقوة؟"
 ],
 "Format": [
  null,
  "تهيئة"
 ],
 "Forward mode": [
  null,
  "الوضع الأمامي"
 ],
 "Forwarding mode": [
  null,
  "وضع إعادة التوجيه"
 ],
 "Full disk images and the domain's memory will be migrated. Only non-shared, writable disk images will be transferred. Unused storage will remain on the origin after migration.": [
  null,
  "سيتم ترحيل صور القرص الكاملة وذاكرة النطاق. سيتم نقل صور الأقراص غير المشتركة والقابلة للكتابة فقط. ستبقى وحدات التخزين غير المستخدمة في الأصل بعد الترحيل."
 ],
 "General": [
  null,
  "عام"
 ],
 "Generate automatically": [
  null,
  "التوليد تلقائياً"
 ],
 "Get a new RHSM token.": [
  null,
  "احصل على رمز RHSM جديد."
 ],
 "GiB": [
  null,
  "GiB"
 ],
 "Go to VMs list": [
  null,
  "الذهاب للائحة الأجهزة الافتراضية"
 ],
 "Good choice for desktop virtualization": [
  null,
  "خيار جيد للمحاكاة الافتراضية لسطح المكتب"
 ],
 "Gracefully shutdown": [
  null,
  "إيقاف التشغيل الآمن"
 ],
 "Graphical": [
  null,
  "رسومي"
 ],
 "Graphical console support not enabled": [
  null,
  "لم يتم تمكين دعم وحدة التحكم الرسومية"
 ],
 "Hardware virtualization is disabled": [
  null,
  "المحاكاة الافتراضية للعتاد معطلة"
 ],
 "Hide additional options": [
  null,
  "إخفاء الخيارات الإضافية"
 ],
 "Host": [
  null,
  "المضيف"
 ],
 "Host device": [
  null,
  "جهاز مضيف"
 ],
 "Host device could not be attached": [
  null,
  "تعذّر توصيل الجهاز المضيف"
 ],
 "Host device will be removed from $0:": [
  null,
  "‏ستتم إزالة الجهاز المضيف من $0:"
 ],
 "Host devices": [
  null,
  "الأجهزة المضيفة"
 ],
 "Host name": [
  null,
  "اسم المضيف"
 ],
 "Host should not be empty": [
  null,
  "يجب ألا يكون المضيف فارغاً"
 ],
 "Hypervisor details": [
  null,
  "تفاصيل برنامج Hypervisor"
 ],
 "ID": [
  null,
  "المعرّف"
 ],
 "IP": [
  null,
  "IP"
 ],
 "IP address": [
  null,
  "عنوان IP"
 ],
 "IP address must not be empty": [
  null,
  "يجب ألا يكون حقل عنوان IP فارغاً"
 ],
 "IP configuration": [
  null,
  "إعداد الـ IP"
 ],
 "IPv4 address": [
  null,
  "عنوان IPv4"
 ],
 "IPv4 address cannot be same as the network's broadcast address": [
  null,
  "لا يمكن أن يكون عنوان IPv4 هو نفسه عنوان البث الخاص بالشبكة"
 ],
 "IPv4 and IPv6": [
  null,
  "IPv4 و IPv6"
 ],
 "IPv4 network should not be empty": [
  null,
  "يجب ألا يكون حقل شبكة IPv4 فارغاً"
 ],
 "IPv4 only": [
  null,
  "IPv4 فقط"
 ],
 "IPv4 prefix length must be 24 or less": [
  null,
  "يجب أن يكون طول بادئة IPv4 24 أو أقل"
 ],
 "IPv4 prefix length must be a multiple of 8": [
  null,
  "يجب أن يكون طول بادئة IPv4 من مضاعفات 8"
 ],
 "IPv6 address": [
  null,
  "عنوان IPv6"
 ],
 "IPv6 network should not be empty": [
  null,
  "يجب ألا يكون حقل شبكة IPv6 فارغاً"
 ],
 "IPv6 only": [
  null,
  "IPv6 فقط"
 ],
 "Ideal for server VMs": [
  null,
  "نموذجي لخادم VM's"
 ],
 "Ideal networking support": [
  null,
  "الدعم النموذجي للشبكات"
 ],
 "Identifier in use by $0. VMs with an identical identifier cannot run at the same time.": [
  null,
  "المعرف قيد الاستخدام من قبل $0. لا يمكن تشغيل الأجهزة الافتراضية ذات المعرف المتطابق في نفس الوقت."
 ],
 "Identifier may be silently truncated to $0 characters ": [
  null,
  "قد يتم اقتطاع المُعرف دون إشعار إلى $0 حرفًا "
 ],
 "Idle": [
  null,
  "خامل"
 ],
 "Ignore": [
  null,
  "تجاهل"
 ],
 "Import VM": [
  null,
  "استيراد VM"
 ],
 "Import a virtual machine": [
  null,
  "استيراد جهاز افتراضي"
 ],
 "Import and edit": [
  null,
  "استيراد وتعديل"
 ],
 "Import and run": [
  null,
  "استيراد وتشغيل"
 ],
 "Importing an image with a backing file is unsupported": [
  null,
  "استيراد صورة بملف استراجاع غير مدعوم"
 ],
 "In most configurations, macvtap does not work for host to guest network communication.": [
  null,
  "في معظم التكوينات، لا يعمل macvtap في اتصال الشبكة بين المضيف والضيف."
 ],
 "Initiator": [
  null,
  "البادئ"
 ],
 "Initiator should not be empty": [
  null,
  "يجب ألا يكون حقل البادئ فارغاً"
 ],
 "Inject a non-maskable interrupt": [
  null,
  "حقن المقاطعة الغير فابلة للتعطيل"
 ],
 "Insert": [
  null,
  "إدخال"
 ],
 "Insert disc media": [
  null,
  "إدخال وسائط القرص"
 ],
 "Inside the VM": [
  null,
  "داخل الجهاز الافتراضي"
 ],
 "Install": [
  null,
  "تثبيت"
 ],
 "Installation source": [
  null,
  "مصدر التثبيت"
 ],
 "Installation source must not be empty": [
  null,
  "يحب ألا يكون خقل مصدر التثبيت فارغاً"
 ],
 "Installation type": [
  null,
  "نوع التثبيت"
 ],
 "Interface": [
  null,
  "الواجهة"
 ],
 "Interface type": [
  null,
  "نوع الواجهة"
 ],
 "Interface type help": [
  null,
  "مساعدة في نوع الواجهة"
 ],
 "Invalid IPv4 address": [
  null,
  "عنوان IPv4 غير صالح"
 ],
 "Invalid IPv4 mask or prefix length": [
  null,
  "قناع IPv4 ، أو طول البادئة غير صحيح"
 ],
 "Invalid IPv6 address": [
  null,
  "عنوان IPv6 غير صالح"
 ],
 "Invalid IPv6 prefix": [
  null,
  "بادئة IPv6 غير صالحة"
 ],
 "Invalid filename": [
  null,
  "اسم ملف غير صالح"
 ],
 "Isolated network": [
  null,
  "شبكة معزولة"
 ],
 "It can also be used to enable the inline graphical console in the browser, which does not support SPICE.": [
  null,
  "يمكن استخدامه أيضًا لتمكين وحدة التحكم الرسومية المضمنة في المتصفح، والتي لا تدعم SPICE."
 ],
 "Keys are located in ~/.ssh/ and have a \".pub\" extension.": [
  null,
  "توجد المفاتيح في ~/.ssh/ وتكون بامتداد ”.pub“."
 ],
 "LVM volume group": [
  null,
  "مجموعة وحدة تخزين LVM"
 ],
 "Leave the password blank if you do not wish to have a root account created": [
  null,
  "اترك كلمة السر فارغة إذا كنت لا ترغب في إنشاء حساب جذر"
 ],
 "Leave the password blank if you do not wish to have a user account created": [
  null,
  "اترك كلمة السر فارغة إذا كنت لا ترغب في إنشاء حساب مستخدم"
 ],
 "Leave the password blank if you do not wish to set a root password": [
  null,
  "اترك كلمة السر فارغة إذا كنت لا ترغب في تعيين كلمة مرور الجذر"
 ],
 "Libvirt did not detect any UEFI/OVMF firmware image installed on the host": [
  null,
  "‍لم تكتشف libvirt أي صورة للبرامج الثابتة UEFI/OVMF مثبتة على المضيف"
 ],
 "Libvirt or hypervisor does not support UEFI": [
  null,
  "Libvirt أو برنامج Hypervisor لا يدعم UEFI"
 ],
 "Loading available network devices": [
  null,
  "تحميل أجهزة الشبكة المتاحة"
 ],
 "Loading resources": [
  null,
  "تحميل المصادر"
 ],
 "Loading...": [
  null,
  "قيد التحميل..."
 ],
 "Local install media (ISO image or distro install tree)": [
  null,
  "وسائط التثبيت المحلية (صورة ISO أو شجرة تثبيت التوزيعة)"
 ],
 "Location": [
  null,
  "الموقع"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "MAC address": [
  null,
  "عنوان MAC"
 ],
 "MAC address already in use": [
  null,
  "عنوان الـ MAC مستخدم بالفعل"
 ],
 "MAC address must not be empty": [
  null,
  "يجب ألا يكون حقل عنوان MAC فارغاً"
 ],
 "Machine must be shut off before changing bus type": [
  null,
  "يجب إيقاف تشغيل الجهاز قبل تغيير نوع الناقل"
 ],
 "Machine must be shut off before changing cache mode": [
  null,
  "يجب إيقاف تشغيل الجهاز قبل تغيير وضع التخزين المؤقت"
 ],
 "Mask or prefix length": [
  null,
  "قناع أو طول البادئة"
 ],
 "Mask or prefix length should not be empty": [
  null,
  "يجب ألا يكون حقل طول القناع أو البادئة فارغًا"
 ],
 "Maximum allocation": [
  null,
  "الحد الأقصى للتخصيص"
 ],
 "Maximum memory could not be saved": [
  null,
  "تعذر حفظ الذاكرة القصوى"
 ],
 "Maximum number of virtual CPUs allocated for the guest OS": [
  null,
  "الحد الأقصى لعدد أنوية المعالج الافتراضية المخصصة لنظام التشغيل الضيف"
 ],
 "Maximum number of virtual CPUs allocated for the guest OS, which must be between 1 and $0": [
  null,
  "الحد الأقصى لعدد أنوية المعالج الافتراضية المخصصة لنظام التشغيل الضيف، والتي يجب أن تكون بين 1 و$0"
 ],
 "Maximum transmission unit": [
  null,
  "وحدة النقل القصوى"
 ],
 "Media could not be ejected from $0": [
  null,
  "تعذر إخراج الوسائط من $0"
 ],
 "Media will be ejected from $0:": [
  null,
  "سيتم إخراج الوسائط من $0:"
 ],
 "Memory": [
  null,
  "الذاكرة"
 ],
 "Memory could not be saved": [
  null,
  "تعذر حفظ الذاكرة"
 ],
 "Memory must not be 0": [
  null,
  "يجب ألا تكون الذاكرة صفراً"
 ],
 "Memory save location can not be empty": [
  null,
  "لا يمكن أن يكون موقع حفظ الذاكرة فارغاً"
 ],
 "Memory snapshot will use about $0.": [
  null,
  "ستستخدم لقطة الذاكرة حوالي $0."
 ],
 "Memory state path": [
  null,
  "مسار حالة الذاكرة"
 ],
 "MiB": [
  null,
  "MiB"
 ],
 "Migrate": [
  null,
  "ترحيل"
 ],
 "Migrate VM to another host": [
  null,
  "ترحيل الجهاز الافتراضي لمضيف آخر"
 ],
 "Migration failed": [
  null,
  "فشل الترحيل"
 ],
 "Mode": [
  null,
  "الطور"
 ],
 "Mode help": [
  null,
  "مساعدة الطور"
 ],
 "Model": [
  null,
  "النموذج"
 ],
 "Model type": [
  null,
  "نوع النموذج"
 ],
 "More info": [
  null,
  "مزيد من المعلومات"
 ],
 "Mount tag": [
  null,
  "علامة التركيب"
 ],
 "Mount tag must not be empty": [
  null,
  "يجب ألا يكون حقل علامة التركيب فارغاً"
 ],
 "Must be an address instead of the network identifier, such as $0": [
  null,
  "يجب أن يكون عنواناً وليس مُعرّف الشبكة، مثل $0"
 ],
 "NAT to $0": [
  null,
  "NAT إلى $0"
 ],
 "NIC $0 of VM $1 failed to change state": [
  null,
  "فشلت بطاقة الشبكة (NIC) $0 للجهاز الافتراضي $1 في تغيير الحالة"
 ],
 "Name": [
  null,
  "الاسم"
 ],
 "Name already exists": [
  null,
  "الاسم موجود بالفعل"
 ],
 "Name can not be empty": [
  null,
  "لا يمكن ترك الاسم فارغاً"
 ],
 "Name contains invalid characters": [
  null,
  "الاسم يحوي أحرفاً غير صالحة"
 ],
 "Name must not be empty": [
  null,
  "يجب ألا يكون الاسم فارغاً"
 ],
 "Name should not be empty": [
  null,
  "ينبغي ألا يكون الاسم فارغاً"
 ],
 "Name: ": [
  null,
  "الاسم: "
 ],
 "Netmask": [
  null,
  "قناع الشبكة"
 ],
 "Network $0 could not be deleted": [
  null,
  "لا يمكن حذف الشبكة $0"
 ],
 "Network $0 failed to get activated": [
  null,
  "فشل تنشيط الشبكة $0"
 ],
 "Network $0 failed to get deactivated": [
  null,
  "فشل إلغاء تنشيط الشبكة $0"
 ],
 "Network $0 will be permanently deleted.": [
  null,
  "سيتم حذف الشبكة $0 نهائياً."
 ],
 "Network boot (PXE)": [
  null,
  "الإقلاع عبر الشبكة (PXE)"
 ],
 "Network file system": [
  null,
  "نظام ملفات الشبكة"
 ],
 "Network interface": [
  null,
  "واجهة الشبكة"
 ],
 "Network interface $0 could not be removed": [
  null,
  "لا يمكن إزالة واجهة الشبكة $0"
 ],
 "Network interface $0 will be removed from $1": [
  null,
  "سيتم إزالة واجهة الشبكة $0 من $1"
 ],
 "Network interface settings could not be saved": [
  null,
  "تعذر حفظ إعدادات واجهة الشبكة"
 ],
 "Network interfaces": [
  null,
  "واجهات الشبكة"
 ],
 "Network selection does not support PXE.": [
  null,
  "اختيار الشبكة الحالي لا يدعم التمهيد عبر الشبكة (PXE)."
 ],
 "Networks": [
  null,
  "الشبكات"
 ],
 "New name": [
  null,
  "اسم جديد"
 ],
 "New name must not be empty": [
  null,
  "حقل الاسم الجديد يجب ألا يكون فارغاً"
 ],
 "New volume name": [
  null,
  "اسم وحدة تخزين جديد"
 ],
 "No SSH keys specified": [
  null,
  "لم يتم تحديد مفاتيح SSH"
 ],
 "No VM is running or defined on this host": [
  null,
  "لم يتم تشغيل أو تعريف أي جهاز افتراضي على هذا المضيف"
 ],
 "No boot device found": [
  null,
  "لم يعثر على جهاز إقلاع"
 ],
 "No description": [
  null,
  "لا وصف"
 ],
 "No directories shared between the host and this VM": [
  null,
  "لا توجد أدلة مشتركة بين المضيف وهذا الجهاز الافتراضي"
 ],
 "No disks defined for this VM": [
  null,
  "لا توجد أقراص محددة لهذا الجهاز الافتراضي"
 ],
 "No host device selected": [
  null,
  "لم يتم تحديد جهاز مضيف"
 ],
 "No host devices assigned to this VM": [
  null,
  "لا توجد أجهزة مضيفة مخصصة لهذا الجهاز الافتراضي"
 ],
 "No network devices": [
  null,
  "لا توجد أجهزة شبكة"
 ],
 "No network interfaces defined for this VM": [
  null,
  "لا توجد واجهات شبكة معرَّفة لهذا الجهاز الافتراضي"
 ],
 "No network is defined on this host": [
  null,
  "لم يتم تحديد أي شبكة على هذا المضيف"
 ],
 "No networks available": [
  null,
  "لا شبكات متاحة"
 ],
 "No parent": [
  null,
  "غير مرتبط بأصل"
 ],
 "No snapshots defined for this VM": [
  null,
  "لا توجد لقطات محددة لهذا الجهاز الافتراضي"
 ],
 "No state": [
  null,
  "لا حالة"
 ],
 "No storage": [
  null,
  "لا تخزين"
 ],
 "No storage pool is defined on this host": [
  null,
  "لا مجمع تخزين تم تحديده لهذا المضيف"
 ],
 "No storage pools available": [
  null,
  "لا مجاميع تخزين متاحة"
 ],
 "No storage volumes defined for this storage pool": [
  null,
  "لا وحدات تخزين تم تحديدها لمجمع التخزين هذا"
 ],
 "No virtual networks": [
  null,
  "لا شبكات افتراضية"
 ],
 "No volumes exist in this storage pool.": [
  null,
  "لا وحدات تخزين موجودة في مجمع التخزين هذا."
 ],
 "Non-persistent network cannot be deleted. It ceases to exists when it's deactivated.": [
  null,
  "لا يمكن حذف الشبكة غير الدائمة. فهي تختفي تلقائيًا عند إيقاف تفعيلها."
 ],
 "Non-persistent storage pool cannot be deleted. It ceases to exists when it's deactivated.": [
  null,
  "لا يمكن حذف مجمع التخزين غير الدائم. فهو يختفي تلقائيًا عند إيقاف تفعيله."
 ],
 "None": [
  null,
  "لا شيء"
 ],
 "None (isolated network)": [
  null,
  "لا شيء (شبكة معزولة)"
 ],
 "Offline token": [
  null,
  "رمز مصادقة غير متصل بالشبكة"
 ],
 "Offline token must not be empty": [
  null,
  "رمز المصادقة المستخدم في حال عدم الاتصال بالشبكة يجب ألا يترك فارغاً"
 ],
 "Old token expired": [
  null,
  "انتهت صلاحية الرمز القديم"
 ],
 "On the host": [
  null,
  "على المضيف"
 ],
 "One or more selected volumes are used by domains. Detach the disks first to allow volume deletion.": [
  null,
  "وحدة تخزين أو أكثر من المحددة قيد الاستخدام من قبل النطاقات. افصل الأقراص أولاً للسماح بحذف وحدة التخزين."
 ],
 "Only editable when the guest is shut off": [
  null,
  "قابل للتعديل فقط عند إيقاف تشغيل الضيف"
 ],
 "Open": [
  null,
  "فتح"
 ],
 "Operating system": [
  null,
  "نظام التشغيل"
 ],
 "Operation is in progress": [
  null,
  "العملية قد المعالجة"
 ],
 "Other VMs using SPICE": [
  null,
  "الأجهزة الافتراضية الأخرى التي تستخدم SPICE"
 ],
 "Overview": [
  null,
  "نظرة عامة"
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "Parent snapshot": [
  null,
  "لقطة النسخة الأصلية"
 ],
 "Password must be 8 characters or less. VNC passwords do not provide encryption and are generally cryptographically weak. They can not be used to secure connections in untrusted networks.": [
  null,
  "يجب أن تتكون كلمة المرور من 8 أحرف أو أقل. لا توفر كلمات مرور VNC تشفيرًا وهي ضعيفة التشفير بشكل عام. لا يمكن استخدامها لتأمين الاتصالات في الشبكات غير الموثوق بها."
 ],
 "Password must be at most 8 characters.": [
  null,
  "يجب أن تتكون كلمة السر من 8 أحرف على الأكثر."
 ],
 "Path": [
  null,
  "مسار"
 ],
 "Path on host's filesystem": [
  null,
  "المسار على نظام ملفات المضيف"
 ],
 "Path to ISO file on host's file system": [
  null,
  "المسار إلى ملف ISO على نظام ملفات المضيف"
 ],
 "Path to cloud image file on host's file system": [
  null,
  "المسار إلى ملف الصورة السحابية على نظام ملفات المضيف"
 ],
 "Path to directory": [
  null,
  "المسار إلى المجلد"
 ],
 "Path to file on host's file system": [
  null,
  "المسار إلى الملف على نظام ملفات المضيف"
 ],
 "Pause": [
  null,
  "إيقاف مؤقَّت"
 ],
 "Paused": [
  null,
  "تم إيقافه مؤقتاً"
 ],
 "Permanent (default)": [
  null,
  "دائم (افتراضي)"
 ],
 "Permissions denied for disk images in home directories": [
  null,
  "الصلاحيات غير كافية لصور القرص في دلائل /home"
 ],
 "Persistence": [
  null,
  "الاستدامة"
 ],
 "Persistent": [
  null,
  "استدامة"
 ],
 "Physical disk device": [
  null,
  "جهاز القرص الفعلي"
 ],
 "Physical disk device on host": [
  null,
  "جهاز قرص فعلي على المضيف"
 ],
 "Please choose a different MAC address": [
  null,
  "يُرجى اختيار عنوان MAC مختلف"
 ],
 "Please choose a storage pool": [
  null,
  "يُرجى اختيار مجمع تخزين"
 ],
 "Please choose a volume": [
  null,
  "يُرجى اختيار وحدة تخزين"
 ],
 "Please enter new volume name": [
  null,
  "يُرجى إدخال اسم وحدة تخزين جديد"
 ],
 "Please see $0 how to reconfigure your VM manually.": [
  null,
  "يرجى النظر في $0 لمعرفة كيفية إعادة تكوين جهازك الافتراضي يدوياً."
 ],
 "Pool": [
  null,
  "مجمع"
 ],
 "Pool needs to be active to create volume": [
  null,
  "المجمع يحتاج أن يكون مفعّلاً لإنشاء وحدة تخزين"
 ],
 "Pool type $0 does not support volume creation": [
  null,
  "نوع المجمع $0 لا يدعم إنشاء وحدة تخزين"
 ],
 "Pool type doesn't support volume creation": [
  null,
  "نوع المجمع لا يدعم إنشاء وحدة تخزين"
 ],
 "Pool's volumes are used by VMs ": [
  null,
  "وحدات تحزين المجمعقيد الاستخدام من قبل الاجهزة الافتراضية "
 ],
 "Port": [
  null,
  "منفذ"
 ],
 "Port must be 5900 or larger.": [
  null,
  "يجب أن يكون رقم المنفذ 5900 أو أكبر."
 ],
 "Port must be a number that is at least 5900. Leave empty to automatically assign a free port when the machine starts.": [
  null,
  "يجب أن يكون المنفذ رقماً لا يقل عن 5900. اتركه فارغاً لتعيين منفذ متاح تلقائياً عند بدء تشغيل الجهاز."
 ],
 "Port must be a number.": [
  null,
  "يجب أن يكون المنفذ رقماً."
 ],
 "Power off": [
  null,
  "فصل مصدر الطاقة"
 ],
 "Pre-formatted block device": [
  null,
  "جهاز كتلي مُهيأ مسبقًا"
 ],
 "Preferred number of sockets to expose to the guest.": [
  null,
  "العدد المفضل للمقابس (Sockets) لعرضها على النظام الضيف."
 ],
 "Prefix": [
  null,
  "بادئة"
 ],
 "Prefix length": [
  null,
  "طول البادئة"
 ],
 "Prefix length should not be empty": [
  null,
  "طول البادئة ينبغي ألا يترك فارغاً"
 ],
 "Previously taken snapshots allow you to revert to an earlier state if something goes wrong": [
  null,
  "تُمكّنك اللقطات المحفوظة مسبقاً من العودة إلى حالة سابقة في حال حدث خطأ ما"
 ],
 "Private": [
  null,
  "خاص"
 ],
 "Product": [
  null,
  "منتج"
 ],
 "Profile": [
  null,
  "ملف التعريف"
 ],
 "Protocol": [
  null,
  "بروتوكول"
 ],
 "Provides a bridge from the guest virtual machine directly onto the LAN. This needs a bridge device on the host with one or more physical NICs.": [
  null,
  "يوفِّر جسرًا يربط الآلة الافتراضية للضيف مباشرةً بشبكة LAN. يتطلب هذا جهاز جسر على المضيف يحوي على بطاقة شبكة فعلية (NIC) واحدة أو أكثر."
 ],
 "Provides a connection whose details are described by the named network definition.": [
  null,
  "يوفر اتصالاً يتم وصف تفاصيله عبر تعريف الشبكة المسماة."
 ],
 "Provides a virtual LAN with NAT to the outside world.": [
  null,
  "توفير شبكة LAN افتراضية مع NAT للعالم الخارجي."
 ],
 "Public SSH key": [
  null,
  "متفاح SSH عام"
 ],
 "Public key": [
  null,
  "مفتاح عام"
 ],
 "Range": [
  null,
  "المدى"
 ],
 "Read-only": [
  null,
  "القراءة-فقط"
 ],
 "Reboot": [
  null,
  "إعادة تشغيل"
 ],
 "Reboot $0?": [
  null,
  "إعادة تشغيل $0؟"
 ],
 "Recommended operating systems": [
  null,
  "أنظمة التشغيل الموصى بها"
 ],
 "Released $0": [
  null,
  "تم الإصدار $0"
 ],
 "Remote URL": [
  null,
  "عنوان URL عن بُعد"
 ],
 "Remote viewer applications can connect to the following address:": [
  null,
  "يمكن لتطبيقات العرض عن بُعد الاتصال بالعنوان التالي:"
 ],
 "Remove": [
  null,
  "إزالة"
 ],
 "Remove SPICE audio and host devices": [
  null,
  "إزالة أجهزة الصوت SPICE والأجهزة المضيفة"
 ],
 "Remove and delete file": [
  null,
  "إزالة وحذف ملف"
 ],
 "Remove disk from VM?": [
  null,
  "إزالة قرص من الجهاز الافتراضي؟"
 ],
 "Remove filesystem?": [
  null,
  "إزالة نظام الملفات؟"
 ],
 "Remove host device from VM?": [
  null,
  "إزالة جهاز مضيف من الجهاز الافتراضي؟"
 ],
 "Remove item": [
  null,
  "إزالة العنصر"
 ],
 "Remove network interface?": [
  null,
  "إزالة واجهة شبكة؟"
 ],
 "Remove static host from DHCP": [
  null,
  "إزالة المضيف الثابت من DHCP"
 ],
 "Rename": [
  null,
  "أعد التسمية"
 ],
 "Rename VM $0": [
  null,
  "إعادة تسمية الجهاز الافتراضي $0"
 ],
 "Replace": [
  null,
  "استبدل"
 ],
 "Replace SPICE devices": [
  null,
  "استبدل أجهزة SPICE"
 ],
 "Replace SPICE devices in VM $0": [
  null,
  "استبدل أجهزة SPICE في الجهاز الافتراضي $0"
 ],
 "Replace SPICE on selected VMs.": [
  null,
  "استبدل SPICE على الأجهزة الافتراضية المحددة."
 ],
 "Replace SPICE on the virtual machine.": [
  null,
  "استبدل SPICE على الجهاز الافتراضي."
 ],
 "Reset": [
  null,
  "صفر"
 ],
 "Restrictions in networking (SLIRP-based emulation) and PCI device assignment": [
  null,
  "قيود في الشبكات (المحاكاة المعتمدة على SLIRP) وتعيين أجهزة PCI"
 ],
 "Resume": [
  null,
  "استئناف"
 ],
 "Revert": [
  null,
  "أرجع"
 ],
 "Revert to snapshot $0": [
  null,
  "الرجوع إلى اللقطة $0"
 ],
 "Reverting to this snapshot will take the VM back to the time of the snapshot and the current state will be lost, along with any data not captured in a snapshot": [
  null,
  "سيؤدي العودة إلى لقطة النظام هذه إلى إعادة الآلة الافتراضية إلى وقت أخذ اللقطة، مع فقدان الحالة الحالية وأي بيانات غير مضمنة في اللقطة"
 ],
 "Root password": [
  null,
  "كلمة سر الجذر"
 ],
 "Route to $0": [
  null,
  "التوجيه إلى $0"
 ],
 "Routed network": [
  null,
  "الشبكة الموجّهة"
 ],
 "Row select": [
  null,
  "حدد الصف"
 ],
 "Run": [
  null,
  "شغِّل"
 ],
 "Run when host boots": [
  null,
  "التشغيل عند بدء إقلاع المضيف"
 ],
 "Running": [
  null,
  "التشغيل"
 ],
 "SPICE": [
  null,
  "SPICE"
 ],
 "SPICE conversion": [
  null,
  "تحويل SPICE"
 ],
 "SPICE is not supported on this host and will cause this virtual machine to not boot.": [
  null,
  "SPICE غير معتمد على هذا المضيف وسيؤدي إلى عدم إقلاع هذا الجهاز الافتراضي."
 ],
 "SSH keys": [
  null,
  "مفاتيح SSH"
 ],
 "Save": [
  null,
  "حفظ"
 ],
 "Select all": [
  null,
  "حدد الكل"
 ],
 "Send key": [
  null,
  "إرسال مفتاح"
 ],
 "Send non-maskable interrupt": [
  null,
  "إرسال مقاطعة غير قابلة للإلغاء (NMI)"
 ],
 "Send non-maskable interrupt to $0?": [
  null,
  "إرسال مقاطعة غير قابلة للإلغاء (NMI) للقطة $0؟"
 ],
 "Serial": [
  null,
  "تسلسل"
 ],
 "Serial console": [
  null,
  "وحدة التحكم المتسلسلة"
 ],
 "Serial console support not enabled": [
  null,
  "لم يتم تمكين دعم وحدة التحكم التسلسلية"
 ],
 "Set DHCP range": [
  null,
  "عيّن مدى DHCP"
 ],
 "Set manually": [
  null,
  "عيّن يدوياً"
 ],
 "Setting the user passwords for unattended installation requires starting the VM when creating it": [
  null,
  "يتطلب تعيين كلمات سر المستخدم للتثبيت غير المراقب بدء تشغيل الجهاز الافتراضي عند إنشائه"
 ],
 "Share": [
  null,
  "مشاركة"
 ],
 "Share a host directory with the guest": [
  null,
  "‍شارك مجلد المضيف مع الضيف"
 ],
 "Shared directories": [
  null,
  "المجلدات المشتركة"
 ],
 "Shared host directories need to be manually mounted inside the VM": [
  null,
  "يجب تركيب مجلدات المضيف المشتركة يدوياً داخل الجهاز الافتراضي"
 ],
 "Shared storage": [
  null,
  "التخزين المشترك"
 ],
 "Show additional options": [
  null,
  "إظهار خيارات إضافية"
 ],
 "Show less": [
  null,
  "عرض أقل"
 ],
 "Show more": [
  null,
  "أظهر المزيد"
 ],
 "Shut down": [
  null,
  "أوقف التشغيل"
 ],
 "Shut down $0?": [
  null,
  "إيقاف تشغيل $0؟"
 ],
 "Shut off": [
  null,
  "أطفئ"
 ],
 "Shut off the VM in order to edit firmware configuration": [
  null,
  "يجب إيقاف تشغيل الآلة الافتراضية لتعديل إعدادات البرنامج الثابت"
 ],
 "Shutting down": [
  null,
  "جاري إيقاف التشغيل"
 ],
 "Size": [
  null,
  "الحجم"
 ],
 "Slot": [
  null,
  "الفتحة"
 ],
 "Snapshot $0 could not be deleted": [
  null,
  "اللقطة $0 لا يمكن حذفها"
 ],
 "Snapshot $0 will be deleted from $1. All of its captured content will be lost.": [
  null,
  "سيتم حذف اللقطة $0 من $1. ستفقد جميع محتوياتها الملتقطة."
 ],
 "Snapshot failed to be created": [
  null,
  "تعذر إنشاء اللقطة"
 ],
 "Snapshots": [
  null,
  "اللقطات"
 ],
 "Sockets": [
  null,
  "مقابس التوصيل"
 ],
 "Some configuration changes only take effect after a fresh boot:": [
  null,
  "لا تسري بعض تغييرات التهيئة إلا بعد إقلاع جديد:"
 ],
 "Source": [
  null,
  "مصدر"
 ],
 "Source format": [
  null,
  "تهيئة المصدر"
 ],
 "Source must not be empty": [
  null,
  "يجب ألا يترك المصدر فارغاً"
 ],
 "Source path": [
  null,
  "مسار المصدر"
 ],
 "Source path should not be empty": [
  null,
  "يجب ألا يترك مسار المصدر فارغاً"
 ],
 "Source should start with http, ftp or nfs protocol": [
  null,
  "المصدر يجب أن يبدأ ببروتوكول http, ftp، أو nfs"
 ],
 "Source volume group": [
  null,
  "مجموعة وحدة تخزين المصدر"
 ],
 "Start": [
  null,
  "بدء"
 ],
 "Start pool when host boots": [
  null,
  "بدء المجمع مع إقلاع المضيف"
 ],
 "Start should not be empty": [
  null,
  "البدء يجب ألا يترك فارغاً"
 ],
 "Started": [
  null,
  "بدأ"
 ],
 "Startup": [
  null,
  "بدء التشغيل"
 ],
 "State": [
  null,
  "حالة"
 ],
 "Static host entries": [
  null,
  "إدخالات المضيف الثابت"
 ],
 "Static host from DHCP could not be removed": [
  null,
  "تعذرت إزالة المضيف الثابت من DHCP"
 ],
 "Storage": [
  null,
  "التخزين"
 ],
 "Storage is at a shared location": [
  null,
  "التخزين في الموقع المشترك"
 ],
 "Storage limit": [
  null,
  "حد التخزين"
 ],
 "Storage pool $0 failed to get activated": [
  null,
  "فشل تنشيط مجمع التخزين $0"
 ],
 "Storage pool $0 failed to get deactivated": [
  null,
  "فشل إلغاء تنشيط مجمع التخزين $0"
 ],
 "Storage pool failed to be created": [
  null,
  "فشل إنشاء مجمع تخزين"
 ],
 "Storage pool name": [
  null,
  "اسم مجمع التخزين"
 ],
 "Storage pools": [
  null,
  "مجاميع التخزين"
 ],
 "Storage pools could not be fetched": [
  null,
  "تعذر جلب مجاميع التخزين"
 ],
 "Storage size must not be 0": [
  null,
  "حجم التجزين يجب ألا يكون صفراً"
 ],
 "Storage volume": [
  null,
  "وحدة تخزينية"
 ],
 "Storage volume size must not exceed the storage pool's capacity ($0 $1)": [
  null,
  "يجب ألا يتجاوز حجم الوحدة التخزينية سعة مجمع التخزين ($0$1)"
 ],
 "Storage volumes": [
  null,
  "الوحدات التخزينية"
 ],
 "Storage volumes could not be deleted": [
  null,
  "تعذر حذف وحدات التخزين"
 ],
 "Storage volumes must be shared between this host and the destination host.": [
  null,
  "يجب مشاركة الوحدات التخزينية بين هذا المضيف والمضيف الذي يمثل الوجهة."
 ],
 "Successfully copied to clipboard!": [
  null,
  "تم النسخ بنجاح إلى الحافظة!"
 ],
 "Suspended (PM)": [
  null,
  "موقوف عن العمل (PM)"
 ],
 "Switch to VNC to continue using this machine.": [
  null,
  "حوِّل إلى بروتوكول VNC لمواصلة استخدام هذه الآلة."
 ],
 "System": [
  null,
  "النظام"
 ],
 "TAP device": [
  null,
  "جهاز TAP"
 ],
 "TPM": [
  null,
  "TPM"
 ],
 "Table of selectable host devices": [
  null,
  "جدول الأجهزة المضيفة القابلة للتحديد"
 ],
 "Target": [
  null,
  "الهدف"
 ],
 "Target path": [
  null,
  "المسار الهدف"
 ],
 "Target path should not be empty": [
  null,
  "المسار الهدف يجب ألا يكون فارغاً"
 ],
 "Temporary": [
  null,
  "مؤقت"
 ],
 "Temporary migration": [
  null,
  "الترحيل المؤقَّت"
 ],
 "The VM $0 is running and will be forced off before deletion.": [
  null,
  "الجهاز الافتراضي $0 قيد التشغيل وسيتم إطفاؤه بالقوة قبل الحذف."
 ],
 "The VM needs to be running or shut off to detach this device": [
  null,
  "يجب أن يكون الجهاز الافتراضي قيد التشغيل أو الإيقاف لفصل هذا الجهاز"
 ],
 "The directory on the server being exported": [
  null,
  "المجلد المُصدَّر من الخادم"
 ],
 "The host path that is to be exported.": [
  null,
  "مسار المضيف الذي سيتم تصديره."
 ],
 "The migrated VM configuration is removed from the source host. The destination host is considered the new home of the VM.": [
  null,
  "تتم إزالة تكوين الأجهزة الافتراضية المنتقلة من المضيف المصدر. يعتبر المضيف الوجهة الموطن الجديد للجهاز الافتراضي."
 ],
 "The mode influences the delivery of packets.": [
  null,
  "يؤثر الوضع على تسليم الحزم."
 ],
 "The pool is empty": [
  null,
  "المجمع فارغ"
 ],
 "The selected operating system has minimum memory requirement of $0 $1": [
  null,
  "نظام التشغيل المحدد يتطلب على الأقل من الذاكرة $0$1"
 ],
 "The selected operating system has minimum storage size requirement of $0 $1": [
  null,
  "نظام التشغيل المحدد يتطلب على الأقل من مساحة التخزين $0 $1"
 ],
 "The static host entry for $0 will be removed:": [
  null,
  "ستتم إزالة إدخال المضيف الثابت لـ$0:"
 ],
 "The storage pool could not be deleted": [
  null,
  "لا يمكن حذف مجمع التخزين"
 ],
 "The tag name to be used by the guest to mount this export point.": [
  null,
  "اسم العلامة الذي سيستخدمها الضيف لتركيب نقطة التصدير هذه."
 ],
 "Then copy and paste it above.": [
  null,
  "ثم انسخها وألصقها أعلاه."
 ],
 "This VM is transient. Shut it down if you wish to delete it.": [
  null,
  "هذه الآلة الافتراضية مؤقتة. أوقف تشغيلها إذا أردت حذفها."
 ],
 "This disk will be removed from $0:": [
  null,
  "ستتم إزالة هذا القرص من $0:"
 ],
 "This filesystem will be removed from $0:": [
  null,
  "سيتم إزالة نظام الملفات هذا من $0:"
 ],
 "This is intended for a host which does not support SPICE due to upgrades or live migration.": [
  null,
  "هذا مخصص للمضيف الذي لا يدعم SPICE بسبب التحديثات أو الترحيل المباشر."
 ],
 "This is the recommended type for general guest connectivity on hosts with dynamic / wireless networking configs.": [
  null,
  "هذا هو النوع الموصى به لاتصال الضيف العام على المضيفين ذوي تكوينات الشبكات الديناميكية/اللاسلكية."
 ],
 "This is the recommended type for general guest connectivity on hosts with static wired networking configs.": [
  null,
  "هذا هو النوع الموصى به لاتصال الضيف العام على المضيفين الذين لديهم تكوينات شبكات سلكية ثابتة."
 ],
 "This is the recommended type for high performance or enhanced security.": [
  null,
  "هذا هو النوع الموصى به للأداء العالي أو الأمان المعزز."
 ],
 "This machine has a SPICE graphical console that can not be shown here.": [
  null,
  "يحتوي هذا الجهاز على وحدة تحكم رسومية SPICE لا يمكن عرضها هنا."
 ],
 "This volume is already used by $0.": [
  null,
  "وحدة التخزين هذه قيد الاستخدام بالفعل من قبل $0."
 ],
 "This volume is already used by another VM.": [
  null,
  "وحدة التخزين هذه مستخدمة بالفعل من قبل جهاز افتراضي آخر."
 ],
 "Threads per core": [
  null,
  "خيوط لكل نواة"
 ],
 "Total space available: $0.": [
  null,
  "إجمالي المساحة المتاحة:$0."
 ],
 "Transient VMs don't support editing firmware configuration": [
  null,
  "الأجهزة الافتراضية المؤقتة لا تدعم تعديل تكوين البرنامج الثابت"
 ],
 "Troubleshoot": [
  null,
  "استكشاف الأخطاء وإصلاحها"
 ],
 "Type": [
  null,
  "النوع"
 ],
 "URL (ISO image or distro install tree)": [
  null,
  "URL ( صورة ISO أو شجرة تثبيت توزيعة)"
 ],
 "USB": [
  null,
  "USB"
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Undefined": [
  null,
  "غير معرَّف"
 ],
 "Unique name": [
  null,
  "اسم فريد"
 ],
 "Unique name, default: $0": [
  null,
  "اسم فريد، الافتراضي:$0"
 ],
 "Unique network name": [
  null,
  "اسم شبكة فريد"
 ],
 "Unit": [
  null,
  "وحدة"
 ],
 "Unknown": [
  null,
  "غير معروف"
 ],
 "Unknown firmware": [
  null,
  "برنامج ثابت غير معروف"
 ],
 "Unspecified": [
  null,
  "غير محدد"
 ],
 "Unsupported and older operating systems": [
  null,
  "أنظمة تشغيل قديمة وغير مدعومة"
 ],
 "Url": [
  null,
  "Url"
 ],
 "Usage": [
  null,
  "الاستخدام"
 ],
 "Use existing": [
  null,
  "استخدم الموجود"
 ],
 "Use extended attributes on files and directories": [
  null,
  "استخدام السمات الموسعة على الملفات والمجلدات"
 ],
 "Use the same location on both the origin and destination hosts for your storage. This can be a shared storage pool, NFS, or any other method of sharing storage.": [
  null,
  "استخدم نفس مسار التخزين على خوادم المصدر والوجهة. يمكن أن يكون هذا مجمع تخزين مشترك، نظام ملفات الشبكة (NFS)، أو أي طريقة أُخرى لمشاركة التخزين."
 ],
 "Used": [
  null,
  "تم استخدامه"
 ],
 "Used by": [
  null,
  "مستخدم من قبل"
 ],
 "User login": [
  null,
  "تسجيل دخول المستخدم"
 ],
 "User login must not be empty when SSH keys are set": [
  null,
  "يجب ألا يكون حقل تسجيل دخول المستخدم فارغاً عند تعيين مفاتيح SSH"
 ],
 "User login must not be empty when user password is set": [
  null,
  "يجب ألا يكون حقل تسجيل دخول المستخدم فارغاً عند تعيين كلمة سر المستخدم"
 ],
 "User password": [
  null,
  "كلمة سر المستخدم"
 ],
 "User password must not be empty when user login is set": [
  null,
  "يجب ألا تكون كلمة مرور المستخدم فارغة عند تعيين تسجيل دخول المستخدم"
 ],
 "User session": [
  null,
  "جلسة المستخدم"
 ],
 "Uses SPICE": [
  null,
  "استخدم SPICE"
 ],
 "VM $0 Host Devices": [
  null,
  "أجهزة المضيف للآلة الافتراضية $0"
 ],
 "VM $0 already exists": [
  null,
  "الجهاز الافتراضي $0 موجود بالفعل"
 ],
 "VM $0 does not exist on $1 connection": [
  null,
  "الجهاز الافتراضي $0 غير موجود على الاتصال $1"
 ],
 "VM $0 failed to force reboot": [
  null,
  "فشل إعادة التشغيل الإجباري للجهاز الافتراضي $0"
 ],
 "VM $0 failed to force shutdown": [
  null,
  "فشل إيقاف التشغيل الإجباري للجهاز الافتراضي $0"
 ],
 "VM $0 failed to get installed": [
  null,
  "فشل تثبيت الجهاز الافتراضي $0"
 ],
 "VM $0 failed to pause": [
  null,
  "فشل الإيقاف المؤقت للجهاز الافتراضي $0"
 ],
 "VM $0 failed to reboot": [
  null,
  "فشل إعادة تشغيل الجهاز الافتراضي $0"
 ],
 "VM $0 failed to resume": [
  null,
  "فشل الجهاز الافتراضي $0 في الاستئناف"
 ],
 "VM $0 failed to send NMI": [
  null,
  "فشل الجهاز الافتراضي $0 في إرسال مُقاطعة غير قابلة للإلغاء (NMI)"
 ],
 "VM $0 failed to shutdown": [
  null,
  "فشل إيقاف تشغيل الجهاز الافتراضي $0"
 ],
 "VM $0 failed to start": [
  null,
  "فشل بدء الجهاز الافتراضي $0"
 ],
 "VM launched with unprivileged limited access, with the process and PTY owned by your user account": [
  null,
  "تم تشغيل الآلة الافتراضية بصلاحيات محدودة غير مميزة، حيث تكون العملية والطرفية (PTY) مملوكة لحساب المستخدم الخاص بك"
 ],
 "VM needs shutdown": [
  null,
  "يحتاج الجهاز الافتراضي إلى إيقاف التشغيل"
 ],
 "VM state": [
  null,
  "حالة الجهاز الافتراضي"
 ],
 "VM will launch with root permissions": [
  null,
  "الجهاز الافتراضي سيبدأ بالعمل مع صلاحيات الجذر"
 ],
 "VNC": [
  null,
  "VNC"
 ],
 "Valid token": [
  null,
  "رمز غير صالح"
 ],
 "Vendor": [
  null,
  "المُنتِج"
 ],
 "Vendor support ended $0": [
  null,
  "انتهى دعم الشركة المصنّعة في $0"
 ],
 "Virtual machines": [
  null,
  "أجهزة افتراضية"
 ],
 "Virtual machines management": [
  null,
  "إدارة الآلات افتراضية"
 ],
 "Virtual network": [
  null,
  "شبكة افتراضية"
 ],
 "Virtual network failed to be created": [
  null,
  "فشل إنشاء شبكة افتراضية"
 ],
 "Virtual socket support enables communication between the host and guest over a socket. It still requires special vsock-aware software to communicate over the socket.": [
  null,
  "يتيح دعم المقبس الافتراضي الاتصال بين المضيف والضيف عبر مقبس. لا يزال يتطلب برنامجاً خاصاً مدركاً للمقبس الافتراضي للاتصال عبر المقبس."
 ],
 "Virtualization service (libvirt) is not active": [
  null,
  "خدمة المحاكاة (libvirt) غير نشطة"
 ],
 "Volume": [
  null,
  "وحدة تخزين"
 ],
 "Volume failed to be created": [
  null,
  "فشل إنشاء وحدة تخزين"
 ],
 "Volume group name": [
  null,
  "اسم مجموعة وحدة التخزين"
 ],
 "Volume group name should not be empty": [
  null,
  "ينبغي ألا يترك اسم مجموعة وحدة التخزين فارغاً"
 ],
 "Vsock": [
  null,
  "مقبس الجهاز الافتراضي"
 ],
 "WWPN": [
  null,
  "WWPN"
 ],
 "Watchdog": [
  null,
  "watchdog"
 ],
 "Watchdogs act when systems stop responding. To use this virtual watchdog device, the guest system also needs to have an additional driver and a running watchdog service.": [
  null,
  "تعمل أنظمة المراقبة (Watchdogs) عند توقف الاستجابة من الأنظمة. لاستخدام جهاز المراقبة الافتراضي هذا، يحتاج نظام الضيف إلى برنامج تشغيل إضافي وخدمة مراقبة قيد التشغيل."
 ],
 "Writeable": [
  null,
  "قابل-للكتابة"
 ],
 "You can mount the shared folder using:": [
  null,
  "يمكنك تركيب مجلد النشاركة باستخدام:"
 ],
 "You need to select the most closely matching operating system": [
  null,
  "تحتاج إلى تحديد نظام التشغيل الأكثر توافقاً"
 ],
 "active": [
  null,
  "نشِط"
 ],
 "add": [
  null,
  "إضافة"
 ],
 "add entry": [
  null,
  "إضافة إدخال"
 ],
 "bridge": [
  null,
  "جسر"
 ],
 "cdrom": [
  null,
  "cdrom"
 ],
 "custom": [
  null,
  "مخصّص"
 ],
 "direct": [
  null,
  "مباشر"
 ],
 "disabled": [
  null,
  "معطّل"
 ],
 "disk": [
  null,
  "قرص"
 ],
 "down": [
  null,
  "أسفل"
 ],
 "edit": [
  null,
  "عدِّل"
 ],
 "enabled": [
  null,
  "مفعَّل"
 ],
 "ethernet": [
  null,
  "إيثرنت"
 ],
 "host": [
  null,
  "مضيف"
 ],
 "host device": [
  null,
  "جهاز مضيف"
 ],
 "host passthrough": [
  null,
  "مرور المضيف من خلال المضيف"
 ],
 "hostdev": [
  null,
  ""
 ],
 "iSCSI direct target": [
  null,
  "هدف iSCSI المباشر"
 ],
 "iSCSI initiator IQN": [
  null,
  "المُبتدئ iSCSI (IQN)"
 ],
 "iSCSI target": [
  null,
  "هدف iSCSI"
 ],
 "iSCSI target IQN": [
  null,
  "الهدف iSCSI (IQN)"
 ],
 "inactive": [
  null,
  "غير نشط"
 ],
 "inet": [
  null,
  ""
 ],
 "inet6": [
  null,
  ""
 ],
 "mcast": [
  null,
  ""
 ],
 "more info": [
  null,
  "مزيد من المعلومات"
 ],
 "mount point: The mount point inside the guest": [
  null,
  ""
 ],
 "mount tag: The tag associated to the exported mount point": [
  null,
  ""
 ],
 "network": [
  null,
  "الشَبكة"
 ],
 "no": [
  null,
  "لا"
 ],
 "no state saved": [
  null,
  "لا توجد حالة محفوظة"
 ],
 "none": [
  null,
  "لا شيء"
 ],
 "redirected device": [
  null,
  "جهاز مُحوَّل"
 ],
 "remove": [
  null,
  "إزالة"
 ],
 "serial number": [
  null,
  "الرقم التسلسلي"
 ],
 "server": [
  null,
  "خادم"
 ],
 "udp": [
  null,
  "udp"
 ],
 "up": [
  null,
  "أعلى"
 ],
 "user": [
  null,
  "المُستخدم"
 ],
 "vCPU and CPU topology settings could not be saved": [
  null,
  "تعذّر حفظ إعدادات وحدات المعالجة الافتراضية (vCPU) وهيكلية المعالج"
 ],
 "vCPU count": [
  null,
  "عدد وحدات المعالجة المركزية الافتراضية"
 ],
 "vCPU maximum": [
  null,
  "الحد الأقصى لوحدة المعالجة المركزية الافتراضية"
 ],
 "vCPUs": [
  null,
  "وحدات المعالجة المركزية الافتراضية"
 ],
 "vhostuser": [
  null,
  "واجهة المستخدم الافتراضية للمضيف"
 ],
 "view more...": [
  null,
  "عرض المزيد.."
 ],
 "virt-install package needs to be installed on the system in order to clone VMs": [
  null,
  "يجب تثبيت حزمة virt-install على النظام لاستنساخ الآلات الافتراضية"
 ],
 "virt-install package needs to be installed on the system in order to create new VMs": [
  null,
  "يجب تثبيت حزمة virt-install على النظام لإنشاء أجهزة افتراضية جديدة"
 ],
 "virt-install package needs to be installed on the system in order to edit this attribute": [
  null,
  "يجب أن تكون حزمة virt-install مثبتة على النظام لتحرير هذه السمة"
 ],
 "vsock requires special software": [
  null,
  "يتطلب vsock برنامجاً خاصاً"
 ],
 "yes": [
  null,
  "نعم"
 ]
});
