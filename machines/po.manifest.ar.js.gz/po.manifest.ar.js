cockpit.locale({
 "": {
  "plural-forms": (n) => n==0 ? 0 : n==1 ? 1 : n==2 ? 2 : n%100>=3 && n%100<=10 ? 3 : n%100>=11 ? 4 : 5,
  "language": "ar",
  "language-direction": "rtl"
 },
 "Managing virtual machines": [
  null,
  "إدارة الأجهزة الافتراضية"
 ],
 "Virtual machines": [
  null,
  "أجهزة افتراضية"
 ],
 "iso": [
  null,
  "iso"
 ],
 "libvirt": [
  null,
  ""
 ],
 "pxe": [
  null,
  ""
 ],
 "qcow2": [
  null,
  ""
 ],
 "qemu": [
  null,
  ""
 ],
 "vm": [
  null,
  "VM"
 ]
});
