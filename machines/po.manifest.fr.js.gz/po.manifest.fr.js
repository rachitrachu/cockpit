cockpit.locale({
 "": {
  "plural-forms": (n) => n > 1,
  "language": "fr",
  "language-direction": "ltr"
 },
 "Managing virtual machines": [
  null,
  "Gestion des machines virtuelles"
 ],
 "Virtual machines": [
  null,
  "Machines virtuelles"
 ],
 "iso": [
  null,
  "iso"
 ],
 "libvirt": [
  null,
  "libvirt"
 ],
 "pxe": [
  null,
  "pxe"
 ],
 "qcow2": [
  null,
  "qcow2"
 ],
 "qemu": [
  null,
  "qemu"
 ],
 "vm": [
  null,
  "machine virtuelle"
 ]
});
