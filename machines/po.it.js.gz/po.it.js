cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "it",
  "language-direction": "ltr"
 },
 "$0 $1 available at default location": [
  null,
  "$0 $1 disponibile nella posizione predefinita"
 ],
 "$0 $1 available on host": [
  null,
  "$0 $1 disponibile nel host"
 ],
 "$0 CPU details": [
  null,
  "$0 dettagli CPU"
 ],
 "$0 Network": [
  null,
  "Rete $0",
  "Reti $0"
 ],
 "$0 Storage pool": [
  null,
  "$0 Pool di archiviazione",
  "$0 Pool di archiviazioni"
 ],
 "$0 does not support unattended installation.": [
  null,
  "$0 supporta l'installazione automatica."
 ],
 "$0 memory adjustment": [
  null,
  "$0 regolazione della memoria"
 ],
 "$0 network": [
  null,
  "Rete $0"
 ],
 "$0 vCPU": [
  null,
  "$0 vCPU",
  "$0 vCPU"
 ],
 "$0 virtual network interface settings": [
  null,
  "$0 impostazioni dell'interfaccia di rete virtuale"
 ],
 "A copy of the VM will run on the destination and will disappear when it is shut off. Meanwhile, the origin host keeps its copy of the VM configuration.": [
  null,
  "Una copia della macchina virtuale verrà eseguita sulla destinazione e scomparirà quando questa verrà spenta. Nel frattempo, l'host di origine mantiene la sua copia della configurazione della macchina virtuale."
 ],
 "Access": [
  null,
  "Accesso"
 ],
 "Action": [
  null,
  "Azione"
 ],
 "Actions": [
  null,
  "Azioni"
 ],
 "Activate": [
  null,
  "Attiva"
 ],
 "Activate the storage pool to administer volumes": [
  null,
  "Attiva il pool di storage per amministrare i volumi"
 ],
 "Add": [
  null,
  "Aggiungi"
 ],
 "Add SSH keys": [
  null,
  "Aggiungi chiavi SSH"
 ],
 "Add TPM": [
  null,
  "Aggiungi TPM"
 ],
 "Add VNC": [
  null,
  "Aggiungi VNC"
 ],
 "Add a DHCP static host entry": [
  null,
  "Aggiungi una voce di host statico DHCP"
 ],
 "Add disk": [
  null,
  "Aggiungi disco"
 ],
 "Add host device": [
  null,
  "Aggiungi dispositivo host"
 ],
 "Add network interface": [
  null,
  "Aggiungi interfaccia di rete"
 ],
 "Add serial console": [
  null,
  "Aggiungi console seriale"
 ],
 "Add shared directory": [
  null,
  "Aggiungi directory condivisa"
 ],
 "Add virtual network interface": [
  null,
  "Aggiungi interfaccia di rete virtuale"
 ],
 "Add vsock interface": [
  null,
  "Aggiungi interfaccia vsock"
 ],
 "Add watchdog device type": [
  null,
  "Aggiungi un tipo di dispositivo watchdog"
 ],
 "Adding a watchdog will require a reboot to take effect.": [
  null,
  "L'aggiunta di un watchdog richiederà un riavvio per avere effetto."
 ],
 "Adding shared directories is possible only when the guest is shut off": [
  null,
  "L'aggiunta di directory condivise è possibile solo quando il guest è spento"
 ],
 "Additional": [
  null,
  "Aggiuntivo"
 ],
 "Address": [
  null,
  "Indirizzo"
 ],
 "Address not within subnet": [
  null,
  "L'indirizzo non è nella sottorete"
 ],
 "All": [
  null,
  "Tutti"
 ],
 "All VM activity, including storage, will be temporary. This will result in data loss on the destination host.": [
  null,
  "Tutte le attività della macchina virtuale, compreso lo storage, saranno temporanee. Ciò comporterà una perdita di dati sull'host di destinazione."
 ],
 "Allowed characters: basic Latin alphabet, numbers, and limited punctuation (-, _, +, .)": [
  null,
  "Caratteri consentiti: alfabeto latino di base, numeri e punteggiatura limitata (-, _, +, .)"
 ],
 "Also delete all volumes inside this pool:": [
  null,
  "Elimina anche tutti i volumi all'interno di questo pool:"
 ],
 "Always attach": [
  null,
  "Allega sempre"
 ],
 "An example of vsock-aware software is socat": [
  null,
  "Un esempio di software compatibile con vsock è socat"
 ],
 "Apply": [
  null,
  "Applica"
 ],
 "Apply on next boot": [
  null,
  "Applica al prossimo boot"
 ],
 "Assign automatically": [
  null,
  "Assegna automaticamente"
 ],
 "Automated installs are only available when downloading an image or using cloud-init.": [
  null,
  "Le installazioni automatiche sono disponibili solo quando si scarica un'immagine o si utilizza cloud-init."
 ],
 "Automatic": [
  null,
  "Automatico"
 ],
 "Automation": [
  null,
  "Automazione"
 ],
 "Autostart": [
  null,
  "Avvio automatico"
 ],
 "Block device": [
  null,
  "blocca il dispositivo"
 ],
 "Blocked": [
  null,
  "Bloccato"
 ],
 "Boot order": [
  null,
  "Ordine di Avvio"
 ],
 "Boot order settings could not be saved": [
  null,
  "Impossibile salvare le impostazioni dell'ordine di avvio"
 ],
 "Bus": [
  null,
  "Bus"
 ],
 "CD/DVD disc": [
  null,
  "Disco CD/DVD"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "CPU mode could not be saved": [
  null,
  "Impossibile salvare la modalità CPU"
 ],
 "Cache": [
  null,
  "Cache"
 ],
 "Cancel": [
  null,
  "Annulla"
 ],
 "Cannot edit vsock device on a transient VM": [
  null,
  "Impossibile modificare il dispositivo vsock su una VM transitoria"
 ],
 "Cannot edit watchdog device on a transient VM": [
  null,
  "Impossibile modificare il dispositivo watchdog su una VM transitoria"
 ],
 "Capacity": [
  null,
  "Capacità"
 ],
 "Change boot order": [
  null,
  "Modifica l'ordine di avvio"
 ],
 "Change firmware": [
  null,
  "Cambia firmware"
 ],
 "Changes pending": [
  null,
  "Modifiche pendenti"
 ],
 "Changes will take effect after shutting down the VM": [
  null,
  "Le modifiche avranno effetto dopo lo spegnimento della VM"
 ],
 "Changing BIOS/EFI settings is specific to each manufacturer. It involves pressing a hotkey during boot (ESC, F1, F12, Del). Enable a setting called \"virtualization\", \"VM\", \"VMX\", \"SVM\", \"VTX\", \"VTD\". Consult your computer's manual for details.": [
  null,
  "La modifica delle impostazioni del BIOS/EFI è specifica per ogni produttore. Si tratta di premere un tasto di scelta rapida durante l'avvio (ESC, F1, F12, Del). Abilita un'impostazione chiamata \"virtualizzazione\", \"VM\", \"VMX\", \"SVM\", \"VTX\", \"VTD\". Consulta il manuale del tuo computer per maggiori dettagli."
 ],
 "Checking token validity...": [
  null,
  "Controllo la validità del token..."
 ],
 "Choose an operating system": [
  null,
  "Scegli un sistema operativo"
 ],
 "Class": [
  null,
  "classe"
 ],
 "Clicking \"Launch viewer\" will download a $0 file and launch the Remote Viewer application on your system.": [
  null,
  "Facendo clic su \"Avvia visualizzatore\" verrà scaricato un file $0 e verrà avviata l'applicazione Remote Viewer sul sistema."
 ],
 "Clone": [
  null,
  "Clona"
 ],
 "Close": [
  null,
  "Chiudi"
 ],
 "Cloud base image": [
  null,
  "Immagine base cloud"
 ],
 "Compress": [
  null,
  "Comprimi"
 ],
 "Concurrently writeable": [
  null,
  "Scrivibile contemporaneamente"
 ],
 "Confirm this action": [
  null,
  "Conferma questa azione"
 ],
 "Connect": [
  null,
  "Connetti"
 ],
 "Connection": [
  null,
  "Connessione"
 ],
 "Console": [
  null,
  "Console"
 ],
 "Convert QXL video card to VGA": [
  null,
  "Converti la scheda video QXL in VGA"
 ],
 "Convert SPICE graphics console to VNC": [
  null,
  "Converti la console grafica SPICE in VNC"
 ],
 "Copy storage": [
  null,
  "Copia di un archivio"
 ],
 "Copy to clipboard": [
  null,
  "Copia negli appunti"
 ],
 "Cores per socket": [
  null,
  "Core per socket"
 ],
 "Could not delete $0": [
  null,
  "$0 non può essere eliminato"
 ],
 "Could not delete all storage for $0": [
  null,
  "Impossibile eliminare tutto lo spazio di archiviazione per $0"
 ],
 "Could not delete disk's storage": [
  null,
  "Impossibile eliminare la memoria del disco"
 ],
 "Could not dynamically add watchdog": [
  null,
  "Impossibile aggiungere dinamicamente il watchdog"
 ],
 "Could not revert to snapshot": [
  null,
  "Impossibile ripristinare lo snapshot"
 ],
 "Crashed": [
  null,
  "Arrestato in modo anomalo"
 ],
 "Create": [
  null,
  "Crea"
 ],
 "Create VM": [
  null,
  "Crea VM"
 ],
 "Create VM by importing a disk image of an existing VM installation": [
  null,
  "Crea una macchina virtuale importando un'immagine disco di un'installazione VM esistente"
 ],
 "Create VM from local or network installation medium": [
  null,
  "Crea una macchina virtuale da un supporto di installazione locale o di rete"
 ],
 "Create a clone VM based on $0": [
  null,
  "Crea un clone della VM basata su $0"
 ],
 "Create and edit": [
  null,
  "Crea e modifica"
 ],
 "Create and run": [
  null,
  "Crea ed esegui"
 ],
 "Create new": [
  null,
  "Crea nuovo"
 ],
 "Create new qcow2 volume": [
  null,
  "Crea un nuovo volume qcow2"
 ],
 "Create new raw volume": [
  null,
  "Crea un nuovo volume raw"
 ],
 "Create new virtual machine": [
  null,
  "Crea nuova macchina virtuale"
 ],
 "Create snapshot": [
  null,
  "Crea snapshot"
 ],
 "Create storage pool": [
  null,
  "Crea pool di archiviazione"
 ],
 "Create storage volume": [
  null,
  "Crea volume di archiviazione"
 ],
 "Create virtual network": [
  null,
  "Crea rete virtuale"
 ],
 "Create volume": [
  null,
  "Crea volume"
 ],
 "Creating VM": [
  null,
  "Creazione VM"
 ],
 "Creating VM $0": [
  null,
  "Creazione della VM $0"
 ],
 "Creating snapshots of VMs with VFIO devices is not supported while they are running.": [
  null,
  "La creazione di snapshot di macchine virtuali con dispositivi VFIO non è supportata mentre sono in esecuzione."
 ],
 "Creation of VM $0 failed": [
  null,
  "Creazione della VM $0 non riuscita"
 ],
 "Creation time": [
  null,
  "Data di creazione"
 ],
 "Ctrl+Alt+$0": [
  null,
  "Ctrl+Alt+$0"
 ],
 "Current": [
  null,
  "Attuale"
 ],
 "Current allocation": [
  null,
  "Allocazione corrente"
 ],
 "Custom firmware: $0": [
  null,
  "Firmware personalizzato: $0"
 ],
 "Custom identifier": [
  null,
  "Identificatore personalizzato"
 ],
 "Custom path": [
  null,
  "Percorso personalizzato"
 ],
 "DHCP Settings": [
  null,
  "Impostazioni DHCP"
 ],
 "Deactivate": [
  null,
  "Disattiva"
 ],
 "Delete": [
  null,
  "Elimina"
 ],
 "Delete $0 VM?": [
  null,
  "Eliminare la VM $0?"
 ],
 "Delete $0 storage pool?": [
  null,
  "Eliminare il pool di archiviazione $0?"
 ],
 "Delete $0 volume": [
  null,
  "Elimina il volume $0",
  "Elimina i volumi $0"
 ],
 "Delete associated storage files:": [
  null,
  "Elimina i file di archiviazione associati:"
 ],
 "Delete network?": [
  null,
  "Eliminare la rete?"
 ],
 "Delete snapshot?": [
  null,
  "Eliminare l'istantanea?"
 ],
 "Deleting an inactive storage pool will only undefine the pool. Its content will not be deleted.": [
  null,
  "L'eliminazione di un pool di archiviazione inattivo annullerà soltanto la definizione del pool. Il suo contenuto non verrà eliminato."
 ],
 "Deleting shared directories is possible only when the guest is shut off": [
  null,
  "La cancellazione delle directory condivise è possibile solo quando il guest è spento"
 ],
 "Description": [
  null,
  "Descrizione"
 ],
 "Deselect others": [
  null,
  "Deseleziona gli altri"
 ],
 "Destination URI": [
  null,
  "URI di destinazione"
 ],
 "Destination URI must not be empty": [
  null,
  "L'URI di destinazione non deve essere vuoto"
 ],
 "Detach the disks using this pool from any VMs before attempting deletion.": [
  null,
  "Scollegare i dischi utilizzando questo pool da qualsiasi VM prima di tentare l'eliminazione."
 ],
 "Details": [
  null,
  "Dettagli"
 ],
 "Device": [
  null,
  "Dispositivo"
 ],
 "Devices": [
  null,
  "Dispositivi"
 ],
 "Disconnect": [
  null,
  "Disconnetti"
 ],
 "Disconnected": [
  null,
  "Disconnesso"
 ],
 "Disconnected from serial console. Click the connect button.": [
  null,
  "Disconnesso dalla console seriale. Fai clic sul pulsante Connetti."
 ],
 "Disk": [
  null,
  "Disco"
 ],
 "Disk $0 could not be removed": [
  null,
  "Impossibile rimuovere il disco $0"
 ],
 "Disk failed to be added": [
  null,
  "Impossibile aggiungere il disco"
 ],
 "Disk identifier": [
  null,
  "Identificatore del disco"
 ],
 "Disk image": [
  null,
  "Immagine del disco"
 ],
 "Disk image file": [
  null,
  "File immagine del disco"
 ],
 "Disk image path must not be empty": [
  null,
  "Il percorso dell'immagine del disco non deve essere vuoto"
 ],
 "Disk images can be stored in user home directory": [
  null,
  "Le immagini del disco possono essere memorizzate nella home directory dell'utente"
 ],
 "Disk settings could not be saved": [
  null,
  "Impossibile salvare le impostazioni del disco"
 ],
 "Disk-only snapshot": [
  null,
  "Solo snapshot del disco"
 ],
 "Disks": [
  null,
  "Dischi"
 ],
 "Do not run this VM on the origin and destination hosts at the same time.": [
  null,
  "Non eseguire questa macchina virtuale contemporaneamente sugli host di origine e di destinazione."
 ],
 "Do nothing": [
  null,
  "Non fare nulla"
 ],
 "Domain has crashed": [
  null,
  "Il dominio è andato in crash"
 ],
 "Domain is blocked on resource": [
  null,
  "Il dominio è bloccato sulla risorsa"
 ],
 "Download an OS": [
  null,
  "Scarica un OS"
 ],
 "Download progress": [
  null,
  "Progresso download"
 ],
 "Download the MSI from $0": [
  null,
  "Scarica l'MSI da $0"
 ],
 "Downloading image for VM $0": [
  null,
  "Download dell'immagine per VM $0"
 ],
 "Downloading: $0%": [
  null,
  "Download: $0%"
 ],
 "Dump core": [
  null,
  "Dump core"
 ],
 "Duration": [
  null,
  "Durata"
 ],
 "Dying": [
  null,
  "In chiusura"
 ],
 "Edit": [
  null,
  "Modifica"
 ],
 "Edit $0 attributes": [
  null,
  "Modifica $0 attributi"
 ],
 "Edit VNC settings": [
  null,
  "Modifica le impostazioni VNC"
 ],
 "Edit description": [
  null,
  "Modifica descrizione"
 ],
 "Edit description of VM $0": [
  null,
  "Modifica la descrizione della VM $0"
 ],
 "Edit vsock interface": [
  null,
  "Modifica l'interfaccia vsock"
 ],
 "Edit watchdog device type": [
  null,
  "Modifica il tipo di dispositivo watchdog"
 ],
 "Editing network interfaces of transient guests is not allowed": [
  null,
  "La modifica delle interfacce di rete degli ospiti transitori non è consentita"
 ],
 "Editing transient network interfaces is not allowed": [
  null,
  "Non è consentita la modifica delle interfacce di rete temporanee"
 ],
 "Eject": [
  null,
  "Espellere"
 ],
 "Eject disc from VM?": [
  null,
  "Espellere il disco dalla VM?"
 ],
 "Emulated machine": [
  null,
  "Macchina emulata"
 ],
 "Enable virtualization support in BIOS/EFI settings.": [
  null,
  "Abilita il supporto della virtualizzazione nelle impostazioni BIOS/EFI."
 ],
 "End": [
  null,
  "Fine"
 ],
 "End should not be empty": [
  null,
  "La fine non può essere vuota"
 ],
 "Enter root and/or user information to enable unattended installation.": [
  null,
  "Immettere le informazioni root e/o utente per abilitare l'installazione automatica."
 ],
 "Error checking token": [
  null,
  "Errore durante il controllo del token"
 ],
 "Example, $0": [
  null,
  "Esempio, $0"
 ],
 "Existing disk image on host's file system": [
  null,
  "Immagine del disco esistente sul file system dell'host"
 ],
 "Expand": [
  null,
  "Espandi"
 ],
 "Extended attributes": [
  null,
  "Attributi estesi"
 ],
 "Failed": [
  null,
  "Fallito"
 ],
 "Failed to add TPM to VM $0": [
  null,
  "Impossibile aggiungere il TPM alla VM $0"
 ],
 "Failed to add VNC to VM $0": [
  null,
  "Impossibile aggiungere VNC alla VM $0"
 ],
 "Failed to add serial console to VM $0": [
  null,
  "Impossibile aggiungere la console seriale alla VM $0"
 ],
 "Failed to add shared directory": [
  null,
  "Impossibile aggiungere la directory condivisa"
 ],
 "Failed to change firmware": [
  null,
  "Impossibile cambiare il firmware"
 ],
 "Failed to clone VM $0": [
  null,
  "Impossibile clonare la VM $0"
 ],
 "Failed to configure vsock": [
  null,
  "Impossibile configurare vsock"
 ],
 "Failed to configure watchdog": [
  null,
  "Impossibile configurare il watchdog"
 ],
 "Failed to detach vsock": [
  null,
  "Impossibile staccare il vsock"
 ],
 "Failed to detach watchdog": [
  null,
  "Impossibile scollegare il watchdog"
 ],
 "Failed to fetch some resources": [
  null,
  "Impossibile recuperare alcune risorse"
 ],
 "Failed to fetch the IP addresses of the interfaces present in $0": [
  null,
  "Impossibile recuperare gli indirizzi IP delle interfacce presenti in $0"
 ],
 "Failed to rename VM $0": [
  null,
  "Impossibile rinominare la VM $0"
 ],
 "Failed to replace SPICE devices": [
  null,
  "Impossibile sostituire i dispositivi SPICE"
 ],
 "Failed to save network settings": [
  null,
  "Impossibile salvare le impostazioni di rete"
 ],
 "Failed to send key Ctrl+Alt+$0 to VM $1": [
  null,
  "Impossibile inviare la combinazione Ctrl+Alt+$0 alla VM $1"
 ],
 "Failed to set description of VM $0": [
  null,
  "Impossibile impostare la descrizione della VM $0"
 ],
 "Fewer than the maximum number of virtual CPUs should be enabled.": [
  null,
  "Un numero massimo inferiore di CPU virtuali dovrebbe essere abilitato."
 ],
 "File": [
  null,
  "File"
 ],
 "Filesystem $0 could not be removed": [
  null,
  "Il filesystem $0 non può essere rimosso"
 ],
 "Filesystem directory": [
  null,
  "Cartella dei file system"
 ],
 "Filter by name": [
  null,
  "Filtra per nome"
 ],
 "Firmware": [
  null,
  "Firmware"
 ],
 "Force eject": [
  null,
  "Espulsione forzata"
 ],
 "Force reboot": [
  null,
  "Forza riavvio"
 ],
 "Force reboot $0?": [
  null,
  "Forzare il riavvio di $0?"
 ],
 "Force revert": [
  null,
  "Forza ripristino"
 ],
 "Force shut down": [
  null,
  "Forza spegnimento"
 ],
 "Force shut down $0?": [
  null,
  "Forzare l'arresto di $0?"
 ],
 "Format": [
  null,
  "Formatta"
 ],
 "Forward mode": [
  null,
  "Modalità di reindirizzamento"
 ],
 "Forwarding mode": [
  null,
  "Modalità di inoltro"
 ],
 "Full disk images and the domain's memory will be migrated. Only non-shared, writable disk images will be transferred. Unused storage will remain on the origin after migration.": [
  null,
  "Le immagini disco complete e la memoria del dominio saranno migrate. Solo le immagini disco scrivibili non condivise saranno trasferite. Lo spazio di archiviazione non utilizzato rimarrà sull'origine dopo la migrazione."
 ],
 "General": [
  null,
  "Generale"
 ],
 "Generate automatically": [
  null,
  "Genera automaticamente"
 ],
 "Get a new RHSM token.": [
  null,
  "Ottieni un nuovo token RHSM."
 ],
 "GiB": [
  null,
  "GiB"
 ],
 "Go to VMs list": [
  null,
  "Vai all'elenco delle VM"
 ],
 "Good choice for desktop virtualization": [
  null,
  "Buona scelta per la virtualizzazione desktop"
 ],
 "Gracefully shutdown": [
  null,
  "Arresto controllato"
 ],
 "Graphical": [
  null,
  "Grafica"
 ],
 "Graphical console support not enabled": [
  null,
  "Supporto della console grafica non abilitato"
 ],
 "Hardware virtualization is disabled": [
  null,
  "La virtualizzazione hardware è disabilitata"
 ],
 "Hide additional options": [
  null,
  "Nascondi opzioni aggiuntive"
 ],
 "Host": [
  null,
  "Host"
 ],
 "Host device": [
  null,
  "Dispositivo host"
 ],
 "Host device could not be attached": [
  null,
  "Impossibile collegare il dispositivo host"
 ],
 "Host device will be removed from $0:": [
  null,
  "Il dispositivo host sarà rimosso da $0:"
 ],
 "Host devices": [
  null,
  "Dispositivi host"
 ],
 "Host name": [
  null,
  "Nome dell'host"
 ],
 "Host should not be empty": [
  null,
  "L'host non deve essere vuoto"
 ],
 "Hypervisor details": [
  null,
  "Dettagli Hypervisor"
 ],
 "ID": [
  null,
  "ID"
 ],
 "IP": [
  null,
  "IP"
 ],
 "IP address": [
  null,
  "Indirizzo IP"
 ],
 "IP address must not be empty": [
  null,
  "L'indirizzo IP non può essere vuoto"
 ],
 "IP configuration": [
  null,
  "Configurazione IP"
 ],
 "IPv4 address": [
  null,
  "Indirizzo IPv4"
 ],
 "IPv4 address cannot be same as the network's broadcast address": [
  null,
  "L'indirizzo IPv4 non può essere uguale all'indirizzo di broadcast della rete"
 ],
 "IPv4 and IPv6": [
  null,
  "IPv4 e IPv6"
 ],
 "IPv4 network should not be empty": [
  null,
  "La rete IPv4 non può essere vuota"
 ],
 "IPv4 only": [
  null,
  "Solo IPv4"
 ],
 "IPv4 prefix length must be 24 or less": [
  null,
  "La lunghezza del prefisso IPv4 deve essere 24 o inferiore"
 ],
 "IPv4 prefix length must be a multiple of 8": [
  null,
  "La lunghezza del prefisso IPv4 deve essere un multiplo di 8"
 ],
 "IPv6 address": [
  null,
  "Indirizzo IPv6"
 ],
 "IPv6 network should not be empty": [
  null,
  "La rete IPv6 non può essere vuota"
 ],
 "IPv6 only": [
  null,
  "Solo IPv6"
 ],
 "Ideal for server VMs": [
  null,
  "Ideale per VM server"
 ],
 "Ideal networking support": [
  null,
  "Supporto di rete ideale"
 ],
 "Identifier in use by $0. VMs with an identical identifier cannot run at the same time.": [
  null,
  "Identificatore in uso da $0. Le VM con un identificatore identico non possono essere eseguite contemporaneamente."
 ],
 "Identifier may be silently truncated to $0 characters ": [
  null,
  "L'identificatore potrebbe essere troncato silenziosamente a $0 caratteri "
 ],
 "Idle": [
  null,
  "Inattivo"
 ],
 "Ignore": [
  null,
  "Ignora"
 ],
 "Import VM": [
  null,
  "Importa VM"
 ],
 "Import a virtual machine": [
  null,
  "Importa una macchina virtuale"
 ],
 "Import and edit": [
  null,
  "Importa e modifica"
 ],
 "Import and run": [
  null,
  "Importa ed esegui"
 ],
 "Importing an image with a backing file is unsupported": [
  null,
  "L'importazione di un'immagine con un backing file non è supportata"
 ],
 "In most configurations, macvtap does not work for host to guest network communication.": [
  null,
  "Nella maggior parte delle configurazioni, macvtap non funziona per le comunicazioni di rete da host a guest."
 ],
 "Initiator": [
  null,
  "Iniziatore"
 ],
 "Initiator should not be empty": [
  null,
  "L'iniziatore non dovrebbe essere vuoto"
 ],
 "Inject a non-maskable interrupt": [
  null,
  "Invia interruzione non mascherabile"
 ],
 "Insert": [
  null,
  "Inserisci"
 ],
 "Insert disc media": [
  null,
  "Inserisci supporto disco"
 ],
 "Inside the VM": [
  null,
  "All'interno della VM"
 ],
 "Install": [
  null,
  "Installa"
 ],
 "Installation source": [
  null,
  "Origine installazione"
 ],
 "Installation source must not be empty": [
  null,
  "L'origine dell'installazione non può essere vuota"
 ],
 "Installation type": [
  null,
  "Tipo di installazione"
 ],
 "Interface": [
  null,
  "Interfaccia"
 ],
 "Interface type": [
  null,
  "Tipo di interfaccia"
 ],
 "Interface type help": [
  null,
  "Aiuto sul tipo di interfaccia"
 ],
 "Invalid IPv4 address": [
  null,
  "Indirizzo IPv4 non valido"
 ],
 "Invalid IPv4 mask or prefix length": [
  null,
  "Lunghezza maschera o prefisso IPv4 non valido"
 ],
 "Invalid IPv6 address": [
  null,
  "Indirizzo IPv6 non valido"
 ],
 "Invalid IPv6 prefix": [
  null,
  "Prefisso IPv6 non valido"
 ],
 "Invalid filename": [
  null,
  "Nome file non valido"
 ],
 "Isolated network": [
  null,
  "Rete isolata"
 ],
 "It can also be used to enable the inline graphical console in the browser, which does not support SPICE.": [
  null,
  "Può essere utilizzato anche per abilitare la console grafica in linea nel browser, che non supporta SPICE."
 ],
 "Keys are located in ~/.ssh/ and have a \".pub\" extension.": [
  null,
  "Le chiavi si trovano in ~/.ssh/ e hanno estensione \".pub\"."
 ],
 "LVM volume group": [
  null,
  "Gruppo di volumi LVM"
 ],
 "Launch viewer": [
  null,
  "Avvia il visualizzatore"
 ],
 "Leave the password blank if you do not wish to have a root account created": [
  null,
  "Lascia vuota la password se non si desidera creare un account root"
 ],
 "Leave the password blank if you do not wish to have a user account created": [
  null,
  "Lasciare vuota la password se non si desidera creare un account utente"
 ],
 "Leave the password blank if you do not wish to set a root password": [
  null,
  "Lascia vuota la password se non desideri impostare una password di root"
 ],
 "Libvirt did not detect any UEFI/OVMF firmware image installed on the host": [
  null,
  "Libvirt non ha rilevato alcuna immagine del firmware UEFI/OVMF installata sull'host"
 ],
 "Libvirt or hypervisor does not support UEFI": [
  null,
  "Libvirt o hypervisor non supporta UEFI"
 ],
 "Loading available network devices": [
  null,
  "Caricamento dei dispositivi di rete disponibili"
 ],
 "Loading resources": [
  null,
  "Caricamento delle risorse"
 ],
 "Loading...": [
  null,
  "Caricamento in corso..."
 ],
 "Local install media (ISO image or distro install tree)": [
  null,
  "Supporto di installazione locale (immagine ISO o albero di installazione della distribuzione)"
 ],
 "Location": [
  null,
  "Posizione"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "MAC address": [
  null,
  "Indirizzo MAC"
 ],
 "MAC address already in use": [
  null,
  "Indirizzo MAC già in uso"
 ],
 "MAC address must not be empty": [
  null,
  "L'indirizzo MAC non può essere vuoto"
 ],
 "Machine must be shut off before changing bus type": [
  null,
  "La macchina deve essere spenta prima di cambiare il tipo di bus"
 ],
 "Machine must be shut off before changing cache mode": [
  null,
  "La macchina deve essere spenta prima di cambiare la modalità cache"
 ],
 "Mask or prefix length": [
  null,
  "Maschera o lunghezza prefisso"
 ],
 "Mask or prefix length should not be empty": [
  null,
  "La maschera o la lunghezza del prefisso non può essere vuota"
 ],
 "Maximum allocation": [
  null,
  "Allocazione massima"
 ],
 "Maximum memory could not be saved": [
  null,
  "Non è stato possibile salvare la memoria massima"
 ],
 "Maximum number of virtual CPUs allocated for the guest OS": [
  null,
  "Numero massimo di CPU virtuali allocate per il sistema operativo guest"
 ],
 "Maximum number of virtual CPUs allocated for the guest OS, which must be between 1 and $0": [
  null,
  "Numero massimo di CPU virtuali allocate per il sistema operativo guest, che deve essere compreso tra 1 e $0"
 ],
 "Maximum transmission unit": [
  null,
  "Unità di trasmissione massima (MTU)"
 ],
 "Media could not be ejected from $0": [
  null,
  "Impossibile espellere il supporto da $0"
 ],
 "Media will be ejected from $0:": [
  null,
  "Il supporto sarà espulso da $0:"
 ],
 "Memory": [
  null,
  "Memoria"
 ],
 "Memory could not be saved": [
  null,
  "Non è stato possibile salvare la memoria"
 ],
 "Memory must not be 0": [
  null,
  "La memoria non può essere 0"
 ],
 "Memory save location can not be empty": [
  null,
  "La posizione di salvataggio della memoria non può essere vuota"
 ],
 "Memory snapshot will use about $0.": [
  null,
  "L'istantanea della memoria utilizzerà circa $0."
 ],
 "Memory state path": [
  null,
  "Percorso stato memoria"
 ],
 "MiB": [
  null,
  "MiB"
 ],
 "Migrate": [
  null,
  "Migra"
 ],
 "Migrate VM to another host": [
  null,
  "Migra VM su un altro host"
 ],
 "Migration failed": [
  null,
  "Migrazione fallita"
 ],
 "Mode": [
  null,
  "Modalità"
 ],
 "Mode help": [
  null,
  "Modalità aiuto"
 ],
 "Model": [
  null,
  "Modello"
 ],
 "Model type": [
  null,
  "Tipo di modello"
 ],
 "More info": [
  null,
  "maggiori info"
 ],
 "Mount tag": [
  null,
  "Tag di mount"
 ],
 "Mount tag must not be empty": [
  null,
  "Il tag di mount non può essere vuoto"
 ],
 "Must be an address instead of the network identifier, such as $0": [
  null,
  "Deve essere un indirizzo invece dell'identificatore di rete, come $0"
 ],
 "NAT to $0": [
  null,
  "NAT su $0"
 ],
 "NIC $0 of VM $1 failed to change state": [
  null,
  "NIC $0 di VM $1 non è riuscito a cambiare stato"
 ],
 "Name": [
  null,
  "Nome"
 ],
 "Name already exists": [
  null,
  "Nome già esistente"
 ],
 "Name can not be empty": [
  null,
  "Il nome non può essere vuoto"
 ],
 "Name contains invalid characters": [
  null,
  "Il nome contiene caratteri non validi"
 ],
 "Name must not be empty": [
  null,
  "Il nome non può essere vuoto"
 ],
 "Name should not be empty": [
  null,
  "Il nome non deve essere vuoto"
 ],
 "Name: ": [
  null,
  "Nome: "
 ],
 "Netmask": [
  null,
  "Maschera di rete"
 ],
 "Network $0 could not be deleted": [
  null,
  "La rete $0 non può essere eliminata"
 ],
 "Network $0 failed to get activated": [
  null,
  "Impossibile attivare la rete $0"
 ],
 "Network $0 failed to get deactivated": [
  null,
  "Impossibile disattivare la rete $0"
 ],
 "Network $0 will be permanently deleted.": [
  null,
  "La rete $0 sarà eliminata permanentemente."
 ],
 "Network boot (PXE)": [
  null,
  "Avvio da rete (PXE)"
 ],
 "Network file system": [
  null,
  "File system di rete"
 ],
 "Network interface": [
  null,
  "Interfaccia di rete"
 ],
 "Network interface $0 could not be removed": [
  null,
  "L'interfaccia di rete $0 non può essere rimossa"
 ],
 "Network interface $0 will be removed from $1": [
  null,
  "L'interfaccia di rete $0 sarà rimossa da $1"
 ],
 "Network interface settings could not be saved": [
  null,
  "Impossibile salvare le impostazioni dell'interfaccia di rete"
 ],
 "Network interfaces": [
  null,
  "Interfacce di rete"
 ],
 "Network selection does not support PXE.": [
  null,
  "La selezione della rete non supporta PXE."
 ],
 "Networks": [
  null,
  "Reti"
 ],
 "New name": [
  null,
  "Nuovo nome"
 ],
 "New name must not be empty": [
  null,
  "Il nuovo nome non può essere vuoto"
 ],
 "New volume name": [
  null,
  "Nuovo nome del volume"
 ],
 "No SSH keys specified": [
  null,
  "Nessuna chiave SSH specificata"
 ],
 "No VM is running or defined on this host": [
  null,
  "Nessuna VM è in esecuzione o definita su questo host"
 ],
 "No boot device found": [
  null,
  "Nessun dispositivo di avvio trovato"
 ],
 "No description": [
  null,
  "Nessuna descrizione"
 ],
 "No directories shared between the host and this VM": [
  null,
  "Nessuna directory condivisa tra l'host e questa VM"
 ],
 "No disks defined for this VM": [
  null,
  "Nessun disco definito per questa VM"
 ],
 "No host device selected": [
  null,
  "Nessun dispositivo host selezionato"
 ],
 "No host devices assigned to this VM": [
  null,
  "Nessun dispositivo host assegnato a questa VM"
 ],
 "No network devices": [
  null,
  "Nessun dispositivo di rete"
 ],
 "No network interfaces defined for this VM": [
  null,
  "Nessuna interfaccia di rete definita per questa macchina virtuale"
 ],
 "No network is defined on this host": [
  null,
  "Nessuna rete definita su questo host"
 ],
 "No networks available": [
  null,
  "Nessuna rete disponibile"
 ],
 "No parent": [
  null,
  "Nessun genitore"
 ],
 "No snapshots defined for this VM": [
  null,
  "Nessuna istantanea definita per questa VM"
 ],
 "No state": [
  null,
  "Nessuno stato"
 ],
 "No storage": [
  null,
  "Nessuna archiviazione"
 ],
 "No storage pool is defined on this host": [
  null,
  "Nessun pool di archiviazione è definito su questo host"
 ],
 "No storage pools available": [
  null,
  "Nessun pool di archiviazione disponibile"
 ],
 "No storage volumes defined for this storage pool": [
  null,
  "Nessun Volume di archiviazione definito per questo pool di archiviazione"
 ],
 "No virtual networks": [
  null,
  "Nessuna rete virtuale"
 ],
 "No volumes exist in this storage pool.": [
  null,
  "Nessun volume esiste in questo pool di archiviazione."
 ],
 "Non-persistent network cannot be deleted. It ceases to exists when it's deactivated.": [
  null,
  "La rete non persistente non può essere eliminata. Cessa di esistere quando viene disattivata."
 ],
 "Non-persistent storage pool cannot be deleted. It ceases to exists when it's deactivated.": [
  null,
  "Il pool di archiviazione non persistente non può essere eliminato. Cessa di esistere quando è disattivato."
 ],
 "None": [
  null,
  "Nessuno"
 ],
 "None (isolated network)": [
  null,
  "Nessuno (Rete Isolata)"
 ],
 "Offline token": [
  null,
  "Token offline"
 ],
 "Offline token must not be empty": [
  null,
  "Il token offline non può essere vuoto"
 ],
 "Old token expired": [
  null,
  "Vecchio token scaduto"
 ],
 "On the host": [
  null,
  "Sull'host"
 ],
 "One or more selected volumes are used by domains. Detach the disks first to allow volume deletion.": [
  null,
  "Uno o più volumi selezionati sono utilizzati dai domini. Scollegare prima i dischi per consentire l'eliminazione del volume."
 ],
 "Only editable when the guest is shut off": [
  null,
  "Modificabile solo quando il guest è spento"
 ],
 "Open": [
  null,
  "Apri"
 ],
 "Operating system": [
  null,
  "Sistema operativo"
 ],
 "Operation is in progress": [
  null,
  "Operazione in corso"
 ],
 "Other VMs using SPICE": [
  null,
  "Altre VM che utilizzano SPICE"
 ],
 "Overview": [
  null,
  "Panoramica"
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "Parent snapshot": [
  null,
  "Istantanea genitore"
 ],
 "Password": [
  null,
  "Password"
 ],
 "Password must be 8 characters or less. VNC passwords do not provide encryption and are generally cryptographically weak. They can not be used to secure connections in untrusted networks.": [
  null,
  "La password deve essere lunga al massimo 8 caratteri. Le password VNC non forniscono crittografia e sono generalmente deboli dal punto di vista crittografico. Non possono essere utilizzate per proteggere connessioni in reti non affidabili."
 ],
 "Password must be at most 8 characters.": [
  null,
  "La password deve essere composta al massimo da 8 caratteri."
 ],
 "Path": [
  null,
  "Percorso"
 ],
 "Path on host's filesystem": [
  null,
  "Percorso sul file system dell'host"
 ],
 "Path to ISO file on host's file system": [
  null,
  "Percorso del file ISO sul file system dell'host"
 ],
 "Path to cloud image file on host's file system": [
  null,
  "Percorso del file immagine cloud sul file system dell'host"
 ],
 "Path to directory": [
  null,
  "Percorso della directory"
 ],
 "Path to file on host's file system": [
  null,
  "Percorso del file sul file system dell'host"
 ],
 "Pause": [
  null,
  "Metti in pausa"
 ],
 "Paused": [
  null,
  "In pausa"
 ],
 "Permanent (default)": [
  null,
  "Permanente (predefinito)"
 ],
 "Permissions denied for disk images in home directories": [
  null,
  "Permessi negati per le immagini disco nelle directory home"
 ],
 "Persistence": [
  null,
  "Persistenza"
 ],
 "Persistent": [
  null,
  "Persistente"
 ],
 "Physical disk device": [
  null,
  "Dispositivo disco fisico"
 ],
 "Physical disk device on host": [
  null,
  "Dispositivo disco fisico sull'host"
 ],
 "Please choose a different MAC address": [
  null,
  "Scegliere un indirizzo MAC diverso"
 ],
 "Please choose a storage pool": [
  null,
  "Scegli un pool di archiviazione"
 ],
 "Please choose a volume": [
  null,
  "Scegli un volume"
 ],
 "Please enter new volume name": [
  null,
  "Inserisci il nuovo nome del volume"
 ],
 "Please see $0 how to reconfigure your VM manually.": [
  null,
  "Consultare $0 per riconfigurare manualmente la VM."
 ],
 "Pool": [
  null,
  "Pool"
 ],
 "Pool needs to be active to create volume": [
  null,
  "Il pool deve essere attivo per creare il volume"
 ],
 "Pool type $0 does not support volume creation": [
  null,
  "Il tipo di pool $0 non supporta la creazione di volumi"
 ],
 "Pool type doesn't support volume creation": [
  null,
  "Il tipo di pool non supporta la creazione di volumi"
 ],
 "Pool's volumes are used by VMs ": [
  null,
  "I volumi del pool vengono utilizzati dalle VM "
 ],
 "Port": [
  null,
  "Porta"
 ],
 "Port must be 5900 or larger.": [
  null,
  "La porta deve essere 5900 o superiore."
 ],
 "Port must be a number that is at least 5900. Leave empty to automatically assign a free port when the machine starts.": [
  null,
  "La porta deve essere un numero pari almeno a 5900. Lasciare vuoto per assegnare automaticamente una porta libera all'avvio della macchina."
 ],
 "Port must be a number.": [
  null,
  "La porta deve essere un numero."
 ],
 "Power off": [
  null,
  "Spegni"
 ],
 "Pre-formatted block device": [
  null,
  "Dispositivo a blocchi pre-formattato"
 ],
 "Preferred number of sockets to expose to the guest.": [
  null,
  "Numero preferito di socket da esporre al guest."
 ],
 "Prefix": [
  null,
  "Prefisso"
 ],
 "Prefix length": [
  null,
  "Lunghezza prefisso"
 ],
 "Prefix length should not be empty": [
  null,
  "La lunghezza del prefisso non può essere vuota"
 ],
 "Previously taken snapshots allow you to revert to an earlier state if something goes wrong": [
  null,
  "Gli snapshot eseguiti in precedenza consentono di tornare a uno stato precedente se qualcosa va storto"
 ],
 "Private": [
  null,
  "Privato"
 ],
 "Product": [
  null,
  "Prodotto"
 ],
 "Profile": [
  null,
  "Profilo"
 ],
 "Protocol": [
  null,
  "Protocollo"
 ],
 "Provides a bridge from the guest virtual machine directly onto the LAN. This needs a bridge device on the host with one or more physical NICs.": [
  null,
  "Fornisce un bridge dalla macchina virtuale guest direttamente sulla LAN. Ciò richiede un dispositivo bridge sull'host con una o più NIC fisiche."
 ],
 "Provides a connection whose details are described by the named network definition.": [
  null,
  "Fornisce una connessione i cui dettagli sono descritti dalla definizione di rete specificata."
 ],
 "Provides a virtual LAN with NAT to the outside world.": [
  null,
  "Fornisce una LAN virtuale con NAT verso il mondo esterno."
 ],
 "Public SSH key": [
  null,
  "Chiave SSH pubblica"
 ],
 "Public key": [
  null,
  "Chiave pubblica"
 ],
 "Range": [
  null,
  "Intervallo"
 ],
 "Read-only": [
  null,
  "Sola lettura"
 ],
 "Reboot": [
  null,
  "Riavvia"
 ],
 "Reboot $0?": [
  null,
  "Riavviare $0?"
 ],
 "Recommended operating systems": [
  null,
  "Sistemi operativi consigliati"
 ],
 "Released $0": [
  null,
  "Rilasciato $0"
 ],
 "Remote URL": [
  null,
  "URL remoto"
 ],
 "Remote Viewer is available for most operating systems. To install it, search for \"Remote Viewer\" in GNOME Software, KDE Discover, or run the following:": [
  null,
  "Remote Viewer è disponibile per la maggior parte dei sistemi operativi. Per installarlo, cerca \"Remote Viewer\" in GNOME Software, KDE Discover oppure esegui il comando seguente:"
 ],
 "Remote viewer": [
  null,
  "Visualizzatore remoto"
 ],
 "Remote viewer applications can connect to the following address:": [
  null,
  "Le applicazioni di visualizzazione remota possono connettersi al seguente indirizzo:"
 ],
 "Remove": [
  null,
  "Rimuovi"
 ],
 "Remove SPICE audio and host devices": [
  null,
  "Rimuovi dispositivi audio e host SPICE"
 ],
 "Remove and delete file": [
  null,
  "Rimuovi ed elimina file"
 ],
 "Remove disk from VM?": [
  null,
  "Rimuovere il disco dalla VM?"
 ],
 "Remove filesystem?": [
  null,
  "Rimuovere il filesystem?"
 ],
 "Remove host device from VM?": [
  null,
  "Rimuovere il dispositivo host dalla VM?"
 ],
 "Remove item": [
  null,
  "Rimuovi elemento"
 ],
 "Remove network interface?": [
  null,
  "Rimuovere l'interfaccia di rete?"
 ],
 "Remove static host from DHCP": [
  null,
  "Rimuovi host statico da DHCP"
 ],
 "Rename": [
  null,
  "Rinomina"
 ],
 "Rename VM $0": [
  null,
  "Rinomina VM $0"
 ],
 "Replace": [
  null,
  "Sostituisci"
 ],
 "Replace SPICE devices": [
  null,
  "Sostituisci dispositivi SPICE"
 ],
 "Replace SPICE devices in VM $0": [
  null,
  "Sostituisci dispositivi SPICE nella VM $0"
 ],
 "Replace SPICE on selected VMs.": [
  null,
  "Sostituisci SPICE nelle VM selezionate."
 ],
 "Replace SPICE on the virtual machine.": [
  null,
  "Sostituisci SPICE sulla macchina virtuale."
 ],
 "Replace with VNC": [
  null,
  "Sostituisci con VNC"
 ],
 "Reset": [
  null,
  "Ripristina"
 ],
 "Restart this virtual machine to access its graphical console": [
  null,
  "Riavvia questa macchina virtuale per accedere alla sua console grafica"
 ],
 "Restart this virtual machine to access its serial console": [
  null,
  "Riavvia questa macchina virtuale per accedere alla sua console seriale"
 ],
 "Restrictions in networking (SLIRP-based emulation) and PCI device assignment": [
  null,
  "Restrizioni nella rete (emulazione basata su SLIRP) e nell'assegnazione di dispositivi PCI"
 ],
 "Resume": [
  null,
  "Riprendi"
 ],
 "Revert": [
  null,
  "Ripristina"
 ],
 "Revert to snapshot $0": [
  null,
  "Ripristina allo snapshot $0"
 ],
 "Reverting to this snapshot will take the VM back to the time of the snapshot and the current state will be lost, along with any data not captured in a snapshot": [
  null,
  "Il ripristino di questa istantanea riporterà la VM al momento dell'istantanea e lo stato corrente andrà perso, insieme a tutti i dati non acquisiti in un'istantanea"
 ],
 "Root password": [
  null,
  "Password di root"
 ],
 "Route to $0": [
  null,
  "Rotta verso $0"
 ],
 "Routed network": [
  null,
  "Rete instradata"
 ],
 "Row select": [
  null,
  "Selezione riga"
 ],
 "Run": [
  null,
  "Esegui"
 ],
 "Run when host boots": [
  null,
  "Esegui all'avvio dell'host"
 ],
 "Running": [
  null,
  "In esecuzione"
 ],
 "SPICE": [
  null,
  "SPICE"
 ],
 "SPICE conversion": [
  null,
  "Conversione SPICE"
 ],
 "SPICE is not supported on this host and will cause this virtual machine to not boot.": [
  null,
  "SPICE non è supportato su questo host e impedirà l'avvio di questa macchina virtuale."
 ],
 "SSH keys": [
  null,
  "Chiavi SSH"
 ],
 "Save": [
  null,
  "Salva"
 ],
 "Select all": [
  null,
  "Seleziona tutto"
 ],
 "Send key": [
  null,
  "Invia tasto"
 ],
 "Send non-maskable interrupt": [
  null,
  "Invia interruzione non mascherabile"
 ],
 "Send non-maskable interrupt to $0?": [
  null,
  "Inviare interrupt non mascherabile a $0?"
 ],
 "Serial": [
  null,
  "Seriale"
 ],
 "Serial ($0)": [
  null,
  "Seriale ($0)"
 ],
 "Serial console": [
  null,
  "Console seriale"
 ],
 "Serial console support not enabled": [
  null,
  "Supporto console seriale non abilitato"
 ],
 "Set DHCP range": [
  null,
  "Imposta intervallo DHCP"
 ],
 "Set manually": [
  null,
  "Imposta manualmente"
 ],
 "Setting the user passwords for unattended installation requires starting the VM when creating it": [
  null,
  "L'impostazione delle password utente per l'installazione automatica richiede l'avvio della VM durante la sua creazione"
 ],
 "Share": [
  null,
  "Condividi"
 ],
 "Share a host directory with the guest": [
  null,
  "Condividi una directory dell'host con il guest"
 ],
 "Shared directories": [
  null,
  "Directory condivise"
 ],
 "Shared host directories need to be manually mounted inside the VM": [
  null,
  "Le directory host condivise devono essere montate manualmente all'interno della VM"
 ],
 "Shared storage": [
  null,
  "Archiviazione condivisa"
 ],
 "Show additional options": [
  null,
  "Mostra opzioni aggiuntive"
 ],
 "Show less": [
  null,
  "Mostra meno"
 ],
 "Show more": [
  null,
  "Mostra di più"
 ],
 "Shut down": [
  null,
  "Arresto"
 ],
 "Shut down $0?": [
  null,
  "Arrestare $0?"
 ],
 "Shut off": [
  null,
  "Arresto"
 ],
 "Shut off the VM in order to edit firmware configuration": [
  null,
  "Spegni la VM per modificare la configurazione del firmware"
 ],
 "Shutting down": [
  null,
  "Spegnimento"
 ],
 "Size": [
  null,
  "Dimensione"
 ],
 "Slot": [
  null,
  "Slot"
 ],
 "Snapshot $0 could not be deleted": [
  null,
  "L'istantanea $0 non può essere eliminata"
 ],
 "Snapshot $0 will be deleted from $1. All of its captured content will be lost.": [
  null,
  "L'istantanea $0 sarà eliminata da $1. Tutto il suo contenuto acquisito andrà perso."
 ],
 "Snapshot failed to be created": [
  null,
  "Impossibile creare lo snapshot"
 ],
 "Snapshots": [
  null,
  "Snapshot"
 ],
 "Sockets": [
  null,
  "Socket"
 ],
 "Some configuration changes only take effect after a fresh boot:": [
  null,
  "Alcune modifiche alla configurazione hanno effetto solo dopo un riavvio completo:"
 ],
 "Source": [
  null,
  "Sorgente"
 ],
 "Source format": [
  null,
  "Formato sorgente"
 ],
 "Source must not be empty": [
  null,
  "L'origine non può essere vuota"
 ],
 "Source path": [
  null,
  "Percorso della sorgente"
 ],
 "Source path should not be empty": [
  null,
  "Il percorso della sorgente non deve essere vuoto"
 ],
 "Source should start with http, ftp or nfs protocol": [
  null,
  "La sorgente deve iniziare con il protocollo http, ftp o nfs"
 ],
 "Source volume group": [
  null,
  "Sorgente del gruppo di volumi"
 ],
 "Start": [
  null,
  "Avvia"
 ],
 "Start pool when host boots": [
  null,
  "Avvia il pool all'avvio dell'host"
 ],
 "Start should not be empty": [
  null,
  "L'inizio non può essere vuoto"
 ],
 "Start the virtual machine to access the console": [
  null,
  "Avviare la macchina virtuale per accedere alla console"
 ],
 "Start the virtual machine to launch remote viewer.": [
  null,
  "Avviare la macchina virtuale per avviare il visualizzatore remoto."
 ],
 "Started": [
  null,
  "Avviato"
 ],
 "Startup": [
  null,
  "Avvio"
 ],
 "State": [
  null,
  "Stato"
 ],
 "Static host entries": [
  null,
  "Voci host statiche"
 ],
 "Static host from DHCP could not be removed": [
  null,
  "L'host statico da DHCP non può essere rimosso"
 ],
 "Storage": [
  null,
  "Archiviazione"
 ],
 "Storage is at a shared location": [
  null,
  "L'archiviazione si trova in una posizione condivisa"
 ],
 "Storage limit": [
  null,
  "Limite di archiviazione"
 ],
 "Storage pool $0 failed to get activated": [
  null,
  "Impossibile attivare il pool di archiviazione $0"
 ],
 "Storage pool $0 failed to get deactivated": [
  null,
  "Impossibile disattivare il pool di archiviazione $0"
 ],
 "Storage pool failed to be created": [
  null,
  "Impossibile creare il pool di archiviazione"
 ],
 "Storage pool name": [
  null,
  "Nome del pool di archiviazione"
 ],
 "Storage pools": [
  null,
  "Pool di Archiviazione"
 ],
 "Storage pools could not be fetched": [
  null,
  "Impossibile recuperare i pool di archiviazione"
 ],
 "Storage size must not be 0": [
  null,
  "Le dimensioni di archiviazione non possono essere 0"
 ],
 "Storage volume": [
  null,
  "Volume di Archiviazione"
 ],
 "Storage volume size must not exceed the storage pool's capacity ($0 $1)": [
  null,
  "Il volume di archiviazione non deve eccedere il volume del pool di archiviazione ($0 $1)"
 ],
 "Storage volumes": [
  null,
  "Volumi di Archiviazione"
 ],
 "Storage volumes could not be deleted": [
  null,
  "I Volumi di Archiviazione non possono essere eliminati"
 ],
 "Storage volumes must be shared between this host and the destination host.": [
  null,
  "I volumi di archiviazione devono essere condivisi tra questo host e l'host di destinazione."
 ],
 "Successfully copied to clipboard!": [
  null,
  "Copiato correttamente negli appunti!"
 ],
 "Suspended (PM)": [
  null,
  "Sospesi (PM)"
 ],
 "Switch to VNC to continue using this machine.": [
  null,
  "Passa a VNC per continuare a utilizzare questa macchina."
 ],
 "System": [
  null,
  "Sistema"
 ],
 "TAP device": [
  null,
  "Dispositivo TAP"
 ],
 "TPM": [
  null,
  "TPM"
 ],
 "Table of selectable host devices": [
  null,
  "Tabella dei dispositivi host selezionabili"
 ],
 "Target": [
  null,
  "Target"
 ],
 "Target path": [
  null,
  "Percorso di destinazione"
 ],
 "Target path should not be empty": [
  null,
  "Il percorso di destinazione non deve essere vuoto"
 ],
 "Temporary": [
  null,
  "Temporaneo"
 ],
 "Temporary migration": [
  null,
  "Migrazione temporanea"
 ],
 "The VM $0 is running and will be forced off before deletion.": [
  null,
  "La VM $0 è in esecuzione e sarà spenta forzatamente prima dell'eliminazione."
 ],
 "The VM needs to be running or shut off to detach this device": [
  null,
  "La VM deve essere in esecuzione o spenta per rimuovere questo dispositivo"
 ],
 "The directory on the server being exported": [
  null,
  "La directory sul server da esportare"
 ],
 "The host path that is to be exported.": [
  null,
  "Il percorso host che deve essere esportato."
 ],
 "The migrated VM configuration is removed from the source host. The destination host is considered the new home of the VM.": [
  null,
  "La configurazione della VM migrata viene rimossa dall'host di origine. L'host di destinazione è considerato la nuova sede della VM."
 ],
 "The mode influences the delivery of packets.": [
  null,
  "La modalità influenza la consegna dei pacchetti."
 ],
 "The pool is empty": [
  null,
  "Il pool è vuoto"
 ],
 "The selected operating system has minimum memory requirement of $0 $1": [
  null,
  "Il sistema operativo selezionato ha un requisito di memoria minimo di $0 $1"
 ],
 "The selected operating system has minimum storage size requirement of $0 $1": [
  null,
  "Il sistema operativo selezionato ha un requisito di dimensione minima di archiviazione di $0 $1"
 ],
 "The static host entry for $0 will be removed:": [
  null,
  "La voce host statica per $0 sarà rimossa:"
 ],
 "The storage pool could not be deleted": [
  null,
  "Impossibile eliminare il pool di archiviazione"
 ],
 "The tag name to be used by the guest to mount this export point.": [
  null,
  "Il nome del tag da utilizzare dal guest per montare questo punto di esportazione."
 ],
 "Then copy and paste it above.": [
  null,
  "Quindi copialo e incollalo sopra."
 ],
 "This VM is transient. Shut it down if you wish to delete it.": [
  null,
  "Questa VM è temporanea. Chiudila se desideri cancellarla."
 ],
 "This disk will be removed from $0:": [
  null,
  "Questo disco sarà rimosso da $0:"
 ],
 "This filesystem will be removed from $0:": [
  null,
  "Questo filesystem sarà rimosso da $0:"
 ],
 "This is intended for a host which does not support SPICE due to upgrades or live migration.": [
  null,
  "Questo è inteso per un host che non supporta SPICE a causa di aggiornamenti o migrazione live."
 ],
 "This is the recommended type for general guest connectivity on hosts with dynamic / wireless networking configs.": [
  null,
  "Questo è il tipo consigliato per la connettività generale degli ospiti su host con configurazioni di rete dinamiche/wireless."
 ],
 "This is the recommended type for general guest connectivity on hosts with static wired networking configs.": [
  null,
  "Questo è il tipo consigliato per la connettività generale degli ospiti su host con configurazioni di rete cablate statiche."
 ],
 "This is the recommended type for high performance or enhanced security.": [
  null,
  "Questa è la tipologia consigliata per prestazioni elevate o maggiore sicurezza."
 ],
 "This machine has a SPICE graphical console that can not be shown here.": [
  null,
  "Questa macchina ha una console grafica SPICE che non può essere mostrata qui."
 ],
 "This volume is already used by $0.": [
  null,
  "Questo volume è già utilizzato da $0."
 ],
 "This volume is already used by another VM.": [
  null,
  "Questo volume è già utilizzato da un'altra VM."
 ],
 "Threads per core": [
  null,
  "Threads per core"
 ],
 "Total space available: $0.": [
  null,
  "Spazio totale disponibile: $0."
 ],
 "Transient VMs don't support editing firmware configuration": [
  null,
  "Le VM non persistenti non supportano la modifica della configurazione firmware"
 ],
 "Troubleshoot": [
  null,
  "Risoluzione problemi"
 ],
 "Type": [
  null,
  "Tipo"
 ],
 "URL (ISO image or distro install tree)": [
  null,
  "URL (immagine ISO o albero di installazione della distribuzione)"
 ],
 "USB": [
  null,
  "USB"
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Undefined": [
  null,
  "Non definito"
 ],
 "Unique name": [
  null,
  "Nome univoco"
 ],
 "Unique name, default: $0": [
  null,
  "Nome univoco, predefinito: $0"
 ],
 "Unique network name": [
  null,
  "Nome di rete univoco"
 ],
 "Unit": [
  null,
  "Unità"
 ],
 "Unknown": [
  null,
  "Sconosciuto"
 ],
 "Unknown firmware": [
  null,
  "Firmware sconosciuto"
 ],
 "Unspecified": [
  null,
  "Non specificato"
 ],
 "Unsupported and older operating systems": [
  null,
  "Sistemi operativi non supportati e obsoleti"
 ],
 "Url": [
  null,
  "URL"
 ],
 "Usage": [
  null,
  "Utilizzo"
 ],
 "Use existing": [
  null,
  "Usa esistente"
 ],
 "Use extended attributes on files and directories": [
  null,
  "Usa attributi estesi su file e directory"
 ],
 "Use the same location on both the origin and destination hosts for your storage. This can be a shared storage pool, NFS, or any other method of sharing storage.": [
  null,
  "Usa la stessa posizione sia sull'host di origine che su quello di destinazione per la tua archiviazione. Può trattarsi di un pool di archiviazione condiviso, NFS o qualsiasi altro metodo di condivisione dell'archiviazione."
 ],
 "Used": [
  null,
  "Usato"
 ],
 "Used by": [
  null,
  "Utilizzato da"
 ],
 "User login": [
  null,
  "Login utente"
 ],
 "User login must not be empty when SSH keys are set": [
  null,
  "Il login utente non può essere vuoto quando sono impostate le chiavi SSH"
 ],
 "User login must not be empty when user password is set": [
  null,
  "Il login utente non può essere vuoto quando è impostata la password utente"
 ],
 "User password": [
  null,
  "Password utente"
 ],
 "User password must not be empty when user login is set": [
  null,
  "La password utente non può essere vuota quando è impostato il login utente"
 ],
 "User session": [
  null,
  "Sessione utente"
 ],
 "Uses SPICE": [
  null,
  "Usa SPICE"
 ],
 "VM $0 Host Devices": [
  null,
  "Dispositivi Host VM $0"
 ],
 "VM $0 already exists": [
  null,
  "La VM $0 esiste già"
 ],
 "VM $0 does not exist on $1 connection": [
  null,
  "La VM $0 non esiste sulla connessione $1"
 ],
 "VM $0 failed to force reboot": [
  null,
  "Impossibile riavviare forzatamente la VM $0"
 ],
 "VM $0 failed to force shutdown": [
  null,
  "Impossibile spegnere forzatamente la VM $0"
 ],
 "VM $0 failed to get installed": [
  null,
  "Impossibile installare la VM $0"
 ],
 "VM $0 failed to pause": [
  null,
  "Impossibile mettere in pausa la VM $0"
 ],
 "VM $0 failed to reboot": [
  null,
  "Impossibile Riavviare la VM $0"
 ],
 "VM $0 failed to resume": [
  null,
  "Impossibile riprendere la VM $0"
 ],
 "VM $0 failed to send NMI": [
  null,
  "La VM $0 non è riuscita a inviare l'NMI"
 ],
 "VM $0 failed to shutdown": [
  null,
  "Impossibile spegnere la VM $0"
 ],
 "VM $0 failed to start": [
  null,
  "Impossibile avviare la VM $0"
 ],
 "VM launched with unprivileged limited access, with the process and PTY owned by your user account": [
  null,
  "VM avviata con accesso limitato non privilegiato, con il processo e il PTY di proprietà del tuo account utente"
 ],
 "VM needs shutdown": [
  null,
  "La VM necessita di arresto"
 ],
 "VM state": [
  null,
  "Stato VM"
 ],
 "VM will launch with root permissions": [
  null,
  "La VM verrà avviata con permessi di root"
 ],
 "VNC": [
  null,
  "VNC"
 ],
 "VNC settings could not be saved": [
  null,
  "Impossibile salvare le impostazioni VNC"
 ],
 "Valid token": [
  null,
  "Token valido"
 ],
 "Vendor": [
  null,
  "Rivenditore"
 ],
 "Vendor support ended $0": [
  null,
  "Supporto del produttore terminato $0"
 ],
 "Virtual machines": [
  null,
  "Macchine virtuali"
 ],
 "Virtual machines management": [
  null,
  "Gestione macchine virtuali"
 ],
 "Virtual network": [
  null,
  "Rete virtuale"
 ],
 "Virtual network failed to be created": [
  null,
  "Impossibile creare la rete virtuale"
 ],
 "Virtual socket support enables communication between the host and guest over a socket. It still requires special vsock-aware software to communicate over the socket.": [
  null,
  "Il supporto per i socket virtuali abilita la comunicazione tra l'host e il guest tramite un socket. Richiede comunque software specifico compatibile con vsock per comunicare tramite il socket."
 ],
 "Virtualization service (libvirt) is not active": [
  null,
  "Il servizio di virtualizzazione (libvirt) non è attivo"
 ],
 "Volume": [
  null,
  "Volume"
 ],
 "Volume failed to be created": [
  null,
  "Impossibile creare il volume"
 ],
 "Volume group name": [
  null,
  "Nome del gruppo di volumi"
 ],
 "Volume group name should not be empty": [
  null,
  "Il nome del gruppo di volumi non può essere vuoto"
 ],
 "Vsock": [
  null,
  "Vsock"
 ],
 "WWPN": [
  null,
  "WWPN"
 ],
 "Watchdog": [
  null,
  "Watchdog"
 ],
 "Watchdogs act when systems stop responding. To use this virtual watchdog device, the guest system also needs to have an additional driver and a running watchdog service.": [
  null,
  "I watchdog agiscono quando i sistemi smettono di rispondere. Per utilizzare questo dispositivo watchdog virtuale, il sistema guest necessita anche di un driver aggiuntivo e di un servizio watchdog in esecuzione."
 ],
 "Writeable": [
  null,
  "Scrivibile"
 ],
 "You can mount the shared folder using:": [
  null,
  "Puoi montare la cartella condivisa usando:"
 ],
 "You need to select the most closely matching operating system": [
  null,
  "È necessario selezionare il sistema operativo più prossimo"
 ],
 "active": [
  null,
  "attivo"
 ],
 "add": [
  null,
  "aggiungi"
 ],
 "add entry": [
  null,
  "aggiungi voce"
 ],
 "bridge": [
  null,
  "bridge"
 ],
 "cdrom": [
  null,
  "cdrom"
 ],
 "custom": [
  null,
  "personalizzato"
 ],
 "direct": [
  null,
  "diretto"
 ],
 "disabled": [
  null,
  "disabilitato"
 ],
 "disk": [
  null,
  "disco"
 ],
 "down": [
  null,
  "giù"
 ],
 "edit": [
  null,
  "modifica"
 ],
 "enabled": [
  null,
  "abilitato"
 ],
 "ethernet": [
  null,
  "ethernet"
 ],
 "host": [
  null,
  "host"
 ],
 "host device": [
  null,
  "dispositivo host"
 ],
 "host passthrough": [
  null,
  "host passthrough"
 ],
 "hostdev": [
  null,
  "hostdev"
 ],
 "iSCSI direct target": [
  null,
  "Target iSCSI diretto"
 ],
 "iSCSI initiator IQN": [
  null,
  "Iniziatore iSCSI IQN"
 ],
 "iSCSI target": [
  null,
  "Target iSCSI"
 ],
 "iSCSI target IQN": [
  null,
  "Target iSCSI IQN"
 ],
 "inactive": [
  null,
  "inattivo"
 ],
 "inet": [
  null,
  "inet"
 ],
 "inet6": [
  null,
  "inet6"
 ],
 "mcast": [
  null,
  "mcast"
 ],
 "more info": [
  null,
  "maggiori info"
 ],
 "mount point: The mount point inside the guest": [
  null,
  "punto di mount: Il punto di mount all'interno del guest"
 ],
 "mount tag: The tag associated to the exported mount point": [
  null,
  "tag di mount: Il tag associato al punto di mount esportato"
 ],
 "network": [
  null,
  "rete"
 ],
 "no": [
  null,
  "no"
 ],
 "no state saved": [
  null,
  "nessuno stato salvato"
 ],
 "none": [
  null,
  "nessuno"
 ],
 "redirected device": [
  null,
  "dispositivo reindirizzato"
 ],
 "remove": [
  null,
  "rimuovi"
 ],
 "serial number": [
  null,
  "numero di serie"
 ],
 "server": [
  null,
  "server"
 ],
 "udp": [
  null,
  "udp"
 ],
 "up": [
  null,
  "su"
 ],
 "user": [
  null,
  "utente"
 ],
 "vCPU and CPU topology settings could not be saved": [
  null,
  "Impossibile salvare le impostazioni della topologia vCPU e CPU"
 ],
 "vCPU count": [
  null,
  "conteggio vCPU"
 ],
 "vCPU maximum": [
  null,
  "vCPU Massimo"
 ],
 "vCPUs": [
  null,
  "vCPU"
 ],
 "vhostuser": [
  null,
  "vhostuser"
 ],
 "view more...": [
  null,
  "vedere di più..."
 ],
 "virt-install package needs to be installed on the system in order to clone VMs": [
  null,
  "Il pacchetto virt-install deve essere installato sul sistema per clonare le macchine virtuali"
 ],
 "virt-install package needs to be installed on the system in order to create new VMs": [
  null,
  "Il pacchetto virt-install deve essere installato sul sistema per creare nuove macchine virtuali"
 ],
 "virt-install package needs to be installed on the system in order to edit this attribute": [
  null,
  "Il pacchetto virt-install deve essere installato sul sistema per modificare questo attributo"
 ],
 "vsock requires special software": [
  null,
  "vsock richiede software speciale"
 ],
 "yes": [
  null,
  "si"
 ]
});
