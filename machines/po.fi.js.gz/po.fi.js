cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "fi",
  "language-direction": "ltr"
 },
 "$0 $1 available at default location": [
  null,
  "$0 $1 käytettävissä oletussijainnissa"
 ],
 "$0 $1 available on host": [
  null,
  "$0 $1 käytettävissä isännässä"
 ],
 "$0 CPU details": [
  null,
  "$0 CPU:n yksityiskohdat"
 ],
 "$0 Network": [
  null,
  "$0 verkko",
  "$0 verkkoa"
 ],
 "$0 Storage pool": [
  null,
  "$0 tallennustilavaranto",
  "$0 tallennustilavarantoa"
 ],
 "$0 does not support unattended installation.": [
  null,
  "$0 ei tue valvomatonta asennusta."
 ],
 "$0 memory adjustment": [
  null,
  "$0 muistin säätö"
 ],
 "$0 network": [
  null,
  "$0 verkko"
 ],
 "$0 vCPU": [
  null,
  "$0 vCPU",
  "$0 vCPU:ta"
 ],
 "$0 virtual network interface settings": [
  null,
  "$0 virtuaalisen verkkoliitännän asetukset"
 ],
 "A copy of the VM will run on the destination and will disappear when it is shut off. Meanwhile, the origin host keeps its copy of the VM configuration.": [
  null,
  "Kopio virtuaalikoneesta suoritetaan kohteessa ja katoaa, kun se sammutetaan. Samaan aikaan isäntäkone säilyttää kopion virtuaalikoneen kokoonpanosta."
 ],
 "Access": [
  null,
  "Pääsy"
 ],
 "Action": [
  null,
  "Toiminto"
 ],
 "Actions": [
  null,
  "Toimet"
 ],
 "Activate": [
  null,
  "Aktivoi"
 ],
 "Activate the storage pool to administer volumes": [
  null,
  "Aktivoi varastointivaranto taltioiden hallitsemiseksi"
 ],
 "Add": [
  null,
  "Lisää"
 ],
 "Add SSH keys": [
  null,
  "Lisää SSH-avaimet"
 ],
 "Add TPM": [
  null,
  "Lisää TPM"
 ],
 "Add VNC": [
  null,
  ""
 ],
 "Add a DHCP static host entry": [
  null,
  "Lisää staattinen DHCP-merkintä"
 ],
 "Add disk": [
  null,
  "Lisää levy"
 ],
 "Add host device": [
  null,
  "Lisää isäntälaite"
 ],
 "Add network interface": [
  null,
  "Lisää verkkoliitäntä"
 ],
 "Add shared directory": [
  null,
  "Lisää jaettu kansio"
 ],
 "Add virtual network interface": [
  null,
  "Lisää virtuaalinen verkkoliitäntä"
 ],
 "Add vsock interface": [
  null,
  "Lisää vsock-verkkoliitäntä"
 ],
 "Add watchdog device type": [
  null,
  "Lisää vahtikoiran laitetyyppi"
 ],
 "Adding a watchdog will require a reboot to take effect.": [
  null,
  "Watchdogin lisääminen vaatii uudelleenkäynnistyksen, jotta se tulee voimaan."
 ],
 "Adding shared directories is possible only when the guest is shut off": [
  null,
  "Jaettujen kansioiden lisääminen on mahdollista vain, kun vieras on sammutettuna"
 ],
 "Additional": [
  null,
  "Ylimääräinen"
 ],
 "Address": [
  null,
  "Osoite"
 ],
 "Address not within subnet": [
  null,
  "Osoite ei aliverkossa"
 ],
 "All": [
  null,
  "Kaikki"
 ],
 "All VM activity, including storage, will be temporary. This will result in data loss on the destination host.": [
  null,
  "Kaikki virtuaalikoneen toiminnot, mukaan lukien tallennustila, ovat väliaikaisia. Tämä johtaa tietojen menetykseen kohdepalvelimessa."
 ],
 "Allowed characters: basic Latin alphabet, numbers, and limited punctuation (-, _, +, .)": [
  null,
  "Sallitut merkit: latinalaiset perusaakkoset, numerot ja vain nämä välimerkit (-, _, +, .)"
 ],
 "Also delete all volumes inside this pool:": [
  null,
  "Poista myös tämän varannon sisäiset taltiot:"
 ],
 "Always attach": [
  null,
  "Kiinnitä aina"
 ],
 "An example of vsock-aware software is socat": [
  null,
  "Esimerkki vsock-tietoisista ohjelmistoista on socat"
 ],
 "Apply": [
  null,
  "Toteuta"
 ],
 "Apply on next boot": [
  null,
  "Käytä seuraavassa käynnistyksessä"
 ],
 "Assign automatically": [
  null,
  "Määritä automaattisesti"
 ],
 "Automated installs are only available when downloading an image or using cloud-init.": [
  null,
  "Automaattiset asennukset ovat käytettävissä vain ladattaessa levykuvaa tai käytettäessä pilvisovellusta."
 ],
 "Automatic": [
  null,
  "Automaattinen"
 ],
 "Automation": [
  null,
  "Automatisointi"
 ],
 "Autostart": [
  null,
  "Automaattikäynnistys"
 ],
 "Block device": [
  null,
  "lohkolaite"
 ],
 "Blocked": [
  null,
  "Estetty"
 ],
 "Boot order": [
  null,
  "Käynnistysjärjestys"
 ],
 "Boot order settings could not be saved": [
  null,
  "Käynnistysjärjestysasetuksia ei voitu tallentaa"
 ],
 "Bus": [
  null,
  "Väylä"
 ],
 "CD/DVD disc": [
  null,
  "CD/DVD-levy"
 ],
 "CPU": [
  null,
  "Suoritin"
 ],
 "CPU mode could not be saved": [
  null,
  "CPU:n moodia ei voitu tallentaa"
 ],
 "Cache": [
  null,
  "Välimuisti"
 ],
 "Cancel": [
  null,
  "Peru"
 ],
 "Cannot edit vsock device on a transient VM": [
  null,
  "Vsock-laitetta ei voi muokata väliaikaisessa virtuaalikoneessa"
 ],
 "Cannot edit watchdog device on a transient VM": [
  null,
  "Watchdog-laitetta ei voi muokata väliaikaisessa virtuaalikoneessa"
 ],
 "Capacity": [
  null,
  "Koko"
 ],
 "Change boot order": [
  null,
  "Vaihda käynnistysjärjestystä"
 ],
 "Change firmware": [
  null,
  "Vaihda laiteohjelmisto"
 ],
 "Changes pending": [
  null,
  "Muutokset odottavat"
 ],
 "Changes will take effect after shutting down the VM": [
  null,
  "Muutokset tulevat voimaan virtuaalikoneen sammuttamisen jälkeen"
 ],
 "Changing BIOS/EFI settings is specific to each manufacturer. It involves pressing a hotkey during boot (ESC, F1, F12, Del). Enable a setting called \"virtualization\", \"VM\", \"VMX\", \"SVM\", \"VTX\", \"VTD\". Consult your computer's manual for details.": [
  null,
  "BIOS/EFI-asetusten muuttaminen on valmistajakohtaista. Siihen kuuluu pikanäppäimen painaminen käynnistyksen aikana (ESC, F1, F12, Del). Ota käyttöön asetus nimeltä \"virtualisointi\", \"VM\", \"VMX\", \"SVM\", \"VTX\", \"VTD\". Katso lisätietoja tietokoneesi käyttöoppaasta."
 ],
 "Checking token validity...": [
  null,
  "Tarkistetaan tokenin kelpoisuutta..."
 ],
 "Choose an operating system": [
  null,
  "Valitse käyttöjärjestelmä"
 ],
 "Class": [
  null,
  "Luokka"
 ],
 "Clone": [
  null,
  "Kloonaa"
 ],
 "Close": [
  null,
  "Sulje"
 ],
 "Cloud base image": [
  null,
  "Pilvipohjainen levykuva"
 ],
 "Compress": [
  null,
  ""
 ],
 "Concurrently writeable": [
  null,
  ""
 ],
 "Confirm this action": [
  null,
  "Vahvista tämä toimi"
 ],
 "Connect": [
  null,
  "Yhdistä"
 ],
 "Connection": [
  null,
  "Yhteys"
 ],
 "Console": [
  null,
  "Konsoli"
 ],
 "Convert QXL video card to VGA": [
  null,
  "Muunna QXL-näytönohjain VGA:ksi"
 ],
 "Convert SPICE graphics console to VNC": [
  null,
  "Muunna SPICE-grafiikkakonsoli VNC:ksi"
 ],
 "Copy storage": [
  null,
  "Kopioi tallennustila"
 ],
 "Copy to clipboard": [
  null,
  "Kopioi leikepöydälle"
 ],
 "Cores per socket": [
  null,
  "Ytimiä per kanta"
 ],
 "Could not delete $0": [
  null,
  "$0 ei voitu poistaa"
 ],
 "Could not delete all storage for $0": [
  null,
  "Ei voitu poistaa kaikkea tallennustilaa $0:lle"
 ],
 "Could not delete disk's storage": [
  null,
  "Ei voitu poistaa levyn tallennustilaa"
 ],
 "Could not dynamically add watchdog": [
  null,
  "Watchdogia ei voitu lisätä dynaamisesti"
 ],
 "Could not revert to snapshot": [
  null,
  "Tilannevedoksen palauttaminen epäonnistui"
 ],
 "Crashed": [
  null,
  "Kaatui"
 ],
 "Create": [
  null,
  "Luo"
 ],
 "Create VM": [
  null,
  "Luo VM"
 ],
 "Create VM by importing a disk image of an existing VM installation": [
  null,
  "Luo VM tuomalla levykuva olemassa olevasta VM-asennuksesta"
 ],
 "Create VM from local or network installation medium": [
  null,
  "Luo VM paikalliselta tai verkon asennusvälineeltä"
 ],
 "Create a clone VM based on $0": [
  null,
  "Luo $0:een perustuva klooninen virtuaalikone"
 ],
 "Create and edit": [
  null,
  "Luo ja muokkaa"
 ],
 "Create and run": [
  null,
  "Luo ja suorita"
 ],
 "Create new": [
  null,
  "Luo uusi"
 ],
 "Create new qcow2 volume": [
  null,
  "Luo uusi qcow2-taltio"
 ],
 "Create new raw volume": [
  null,
  "Luo uusi raaka-taltio"
 ],
 "Create new virtual machine": [
  null,
  "Luo uusi virtuaalikone"
 ],
 "Create snapshot": [
  null,
  "Luo tilannevedos"
 ],
 "Create storage pool": [
  null,
  "Luo varastointivaranto"
 ],
 "Create storage volume": [
  null,
  "Luo varastointitaltio"
 ],
 "Create virtual network": [
  null,
  "Luo virtuaaliverkko"
 ],
 "Create volume": [
  null,
  "Luo taltio"
 ],
 "Creating VM": [
  null,
  "Virtuaalikoneen luominen"
 ],
 "Creating VM $0": [
  null,
  "Luodaan virtuaalikone $0"
 ],
 "Creating snapshots of VMs with VFIO devices is not supported while they are running.": [
  null,
  "Tilannekuvien luomista virtuaalikoneista VFIO-laitteilla ei tueta niiden ollessa käynnissä."
 ],
 "Creation of VM $0 failed": [
  null,
  "Virtuaalikoneen $0 luominen epäonnistui"
 ],
 "Creation time": [
  null,
  "Luomisaika"
 ],
 "Ctrl+Alt+$0": [
  null,
  "Ctrl+Alt+$0"
 ],
 "Current": [
  null,
  "Nykyinen"
 ],
 "Current allocation": [
  null,
  "Nykyinen kohdentaminen"
 ],
 "Custom firmware: $0": [
  null,
  "Mukautettu laiteohjelmisto: $0"
 ],
 "Custom identifier": [
  null,
  "Muokattu tunniste"
 ],
 "Custom path": [
  null,
  "Mukautettu polku"
 ],
 "DHCP Settings": [
  null,
  "DHCP-asetukset"
 ],
 "Deactivate": [
  null,
  "Deaktivoi"
 ],
 "Delete": [
  null,
  "Poista"
 ],
 "Delete $0 VM?": [
  null,
  "Poista $0 VM?"
 ],
 "Delete $0 storage pool?": [
  null,
  "Poista varastointivaranto $0?"
 ],
 "Delete $0 volume": [
  null,
  "Poista $0 taltio",
  "Poista $0 taltiota"
 ],
 "Delete associated storage files:": [
  null,
  "Poista liittyvät tallennustiedostot:"
 ],
 "Delete network?": [
  null,
  "Poista verkko ?"
 ],
 "Delete snapshot?": [
  null,
  "Poistetaanko tilannevedos?"
 ],
 "Deleting an inactive storage pool will only undefine the pool. Its content will not be deleted.": [
  null,
  "Passiivisen varastointivarannon poistaminen poistaa vain määrittelyn varannosta. Sen sisältöä ei poisteta."
 ],
 "Deleting shared directories is possible only when the guest is shut off": [
  null,
  "Jaettujen kansioiden poistaminen on mahdollista vain, kun vieras on sammutettuna"
 ],
 "Description": [
  null,
  "Kuvaus"
 ],
 "Deselect others": [
  null,
  "Poista muut valinnat"
 ],
 "Destination URI": [
  null,
  "Kohde URI"
 ],
 "Destination URI must not be empty": [
  null,
  "Kohde URI ei voi olla tyhjä"
 ],
 "Detach the disks using this pool from any VMs before attempting deletion.": [
  null,
  "Irrota tätä varantoa käyttävät levyt kaikista virtuaalikoneista ennen poistoyritystä."
 ],
 "Details": [
  null,
  "Yksityiskohdat"
 ],
 "Device": [
  null,
  "Laite"
 ],
 "Devices": [
  null,
  "Laitteet"
 ],
 "Disconnect": [
  null,
  "Katkaise yhteys"
 ],
 "Disconnected": [
  null,
  "Yhteys katkaistu"
 ],
 "Disconnected from serial console. Click the connect button.": [
  null,
  "Irrotettu sarjakonsolista. Napsauta yhdistä-painiketta."
 ],
 "Disk": [
  null,
  "Levy"
 ],
 "Disk $0 could not be removed": [
  null,
  "Levyä $0 ei voitu poistaa"
 ],
 "Disk failed to be added": [
  null,
  "Levyn liittäminen epäonnistui"
 ],
 "Disk identifier": [
  null,
  "Levyn tunniste"
 ],
 "Disk image": [
  null,
  "Levykuva"
 ],
 "Disk image file": [
  null,
  "Levykuvatiedosto"
 ],
 "Disk image path must not be empty": [
  null,
  "Levykuvan polku ei voi olla tyhjä"
 ],
 "Disk images can be stored in user home directory": [
  null,
  "Levykuvat voidaan tallentaa käyttäjän kotihakemistoon"
 ],
 "Disk settings could not be saved": [
  null,
  "Levyn asetuksia ei voitu tallentaa"
 ],
 "Disk-only snapshot": [
  null,
  "Vain levy -tilannevedos"
 ],
 "Disks": [
  null,
  "Levyt"
 ],
 "Do not run this VM on the origin and destination hosts at the same time.": [
  null,
  "Älä suorita tätä virtuaalikonetta alkuperä- ja kohdepalvelimissa samanaikaisesti."
 ],
 "Do nothing": [
  null,
  "Älä tee mitään"
 ],
 "Domain has crashed": [
  null,
  "Toimialue on kaatunut"
 ],
 "Domain is blocked on resource": [
  null,
  "Toimialue on estetty resurssilla"
 ],
 "Download an OS": [
  null,
  "Lataa käyttöjärjestelmä"
 ],
 "Download progress": [
  null,
  "Latauksen edistyminen"
 ],
 "Downloading image for VM $0": [
  null,
  "Ladataan levykuvaa VM:lle $0"
 ],
 "Downloading: $0%": [
  null,
  "Ladataan: $0%"
 ],
 "Dump core": [
  null,
  "Dumppaa ydin"
 ],
 "Duration": [
  null,
  "Kesto"
 ],
 "Dying": [
  null,
  "Kuolemassa"
 ],
 "Edit": [
  null,
  "Muokkaa"
 ],
 "Edit $0 attributes": [
  null,
  "Muokkaa $0 attribuuttia"
 ],
 "Edit description": [
  null,
  "Muokkaa kuvausta"
 ],
 "Edit description of VM $0": [
  null,
  "Muokkaa virtuaalikoneen $0 kuvausta"
 ],
 "Edit vsock interface": [
  null,
  "Muokkaa vsock-verkkoliitäntää"
 ],
 "Edit watchdog device type": [
  null,
  "Muokkaa vahtikoiran laitetyyppiä"
 ],
 "Editing network interfaces of transient guests is not allowed": [
  null,
  "Väliaikaisten vieraskoneiden verkkoliitäntöjen muokkaaminen ei ole sallittua"
 ],
 "Editing transient network interfaces is not allowed": [
  null,
  "Väliaikaisten verkkoliitäntöjen muokkaaminen ei ole sallittua"
 ],
 "Eject": [
  null,
  "Poista"
 ],
 "Eject disc from VM?": [
  null,
  "Poistetaanko levy VM:stä?"
 ],
 "Emulated machine": [
  null,
  "Sulautettu kone"
 ],
 "Enable virtualization support in BIOS/EFI settings.": [
  null,
  "Ota virtualisointituki käyttöön BIOS:in/EFI:n asetuksissa."
 ],
 "End": [
  null,
  "Loppu"
 ],
 "End should not be empty": [
  null,
  "Loppu ei saa olla tyhjä"
 ],
 "Enter root and/or user information to enable unattended installation.": [
  null,
  "Anna pääkäyttäjän ja/tai käyttäjän tiedot salliaksesi valvomattoman asennuksen."
 ],
 "Error checking token": [
  null,
  "Virhe tokenin tarkistuksessa"
 ],
 "Example, $0": [
  null,
  "Esimerkki, $0"
 ],
 "Existing disk image on host's file system": [
  null,
  "Poistutaan levykuvasta isännän tiedostojärjestelmässä"
 ],
 "Expand": [
  null,
  "Laajenna"
 ],
 "Extended attributes": [
  null,
  "Laajennetut määreet"
 ],
 "Failed": [
  null,
  "Epäonnistui"
 ],
 "Failed to add TPM to VM $0": [
  null,
  "TPM:n lisäminen virtuaalikoneeseen $0 epäonnistui"
 ],
 "Failed to add shared directory": [
  null,
  "Jaetun hakemiston lisäys epäonnistui"
 ],
 "Failed to change firmware": [
  null,
  "Laiteohjelmiston vaihtaminen epäonnistui"
 ],
 "Failed to clone VM $0": [
  null,
  "VM:n $0 kloonaus epäonnistui"
 ],
 "Failed to configure vsock": [
  null,
  "vsockin määritys epäonnistui"
 ],
 "Failed to configure watchdog": [
  null,
  "Vahtikoiran määritys epäonnistui"
 ],
 "Failed to detach vsock": [
  null,
  "vsockin irrottaminen epäonnistui"
 ],
 "Failed to detach watchdog": [
  null,
  "Vahtikoiran irrottaminen epäonnistui"
 ],
 "Failed to fetch some resources": [
  null,
  "Joidenkin resurssien hakeminen epäonnistui"
 ],
 "Failed to fetch the IP addresses of the interfaces present in $0": [
  null,
  "$0:ssa olevien liitäntöjen IP-osoitteiden noutaminen epäonnistui"
 ],
 "Failed to rename VM $0": [
  null,
  "VM:n $0 nimen vaihto epäonnistui"
 ],
 "Failed to replace SPICE devices": [
  null,
  "SPICE-laitteiden vaihtaminen epäonnistui"
 ],
 "Failed to save network settings": [
  null,
  "Verkkoasetusten tallentaminen epäonnistui"
 ],
 "Failed to send key Ctrl+Alt+$0 to VM $1": [
  null,
  "Näppäimen Ctrl+Alt+$0 lähettäminen virtuaalikoneeseen $1 epäonnistui"
 ],
 "Failed to set description of VM $0": [
  null,
  "Virtuaalikoneen $0 kuvauksen asettaminen epäonnistui"
 ],
 "Fewer than the maximum number of virtual CPUs should be enabled.": [
  null,
  "Alle virtuaalisten suorittimien enimmäismäärän tulisi olla käytössä."
 ],
 "File": [
  null,
  "Tiedosto"
 ],
 "Filesystem $0 could not be removed": [
  null,
  "Tiedostojärjestelmää $0 ei voitu poistaa"
 ],
 "Filesystem directory": [
  null,
  "Tiedostojärjestelmän hakemisto"
 ],
 "Filter by name": [
  null,
  "Suodata nimen mukaan"
 ],
 "Firmware": [
  null,
  "Laiteohjelmisto"
 ],
 "Force eject": [
  null,
  "Pakota poisto"
 ],
 "Force reboot": [
  null,
  "Pakota uudelleenkäynnistys"
 ],
 "Force reboot $0?": [
  null,
  "Pakota $0 uudelleenkäynnistys?"
 ],
 "Force revert": [
  null,
  "Pakota palautus"
 ],
 "Force shut down": [
  null,
  "Pakota sammutus"
 ],
 "Force shut down $0?": [
  null,
  "Pakota $0 sammutus?"
 ],
 "Format": [
  null,
  "Alusta"
 ],
 "Forward mode": [
  null,
  "Eteenpäin-tila"
 ],
 "Forwarding mode": [
  null,
  "Edelleenlähetystila"
 ],
 "Full disk images and the domain's memory will be migrated. Only non-shared, writable disk images will be transferred. Unused storage will remain on the origin after migration.": [
  null,
  "Kokonaiset levykuvat ja toimialueen muisti siirretään. Vain jakamattomat, kirjoitettavat levykuvat siirretään. Käyttämätön tallennustila pysyy alkuperäisenä siirron jälkeen."
 ],
 "General": [
  null,
  "Yleinen"
 ],
 "Generate automatically": [
  null,
  "Luo automaattisesti"
 ],
 "Get a new RHSM token.": [
  null,
  "Hanki uusi RHSM-tokeni."
 ],
 "GiB": [
  null,
  "Git"
 ],
 "Go to VMs list": [
  null,
  "Siirry virtuaalikoneiden luetteloon"
 ],
 "Good choice for desktop virtualization": [
  null,
  "Hyvä valinta työpöydän virtualisointiin"
 ],
 "Gracefully shutdown": [
  null,
  "Sammuta hallitusti"
 ],
 "Graphical": [
  null,
  ""
 ],
 "Graphical console support not enabled": [
  null,
  ""
 ],
 "Hardware virtualization is disabled": [
  null,
  "Laitteistovirtualisointi on pois käytöstä"
 ],
 "Hide additional options": [
  null,
  "Piilota lisävaihtoehdot"
 ],
 "Host": [
  null,
  "Kone"
 ],
 "Host device": [
  null,
  "Isäntälaite"
 ],
 "Host device could not be attached": [
  null,
  "Isäntälaitetta ei voitu liittää"
 ],
 "Host device will be removed from $0:": [
  null,
  "Isäntälaite poistetaan $0:sta:"
 ],
 "Host devices": [
  null,
  "Isäntälaite"
 ],
 "Host name": [
  null,
  "Isäntänimi"
 ],
 "Host should not be empty": [
  null,
  "Nimen ei saa olla tyhjä"
 ],
 "Hypervisor details": [
  null,
  "Hypervisorin yksityiskohdat"
 ],
 "ID": [
  null,
  "Tunniste"
 ],
 "IP": [
  null,
  "IP"
 ],
 "IP address": [
  null,
  "IP-osoite"
 ],
 "IP address must not be empty": [
  null,
  "IP-osoite ei saa olla tyhjä"
 ],
 "IP configuration": [
  null,
  "IP-määritykset"
 ],
 "IPv4 address": [
  null,
  "IPv4-osoite"
 ],
 "IPv4 address cannot be same as the network's broadcast address": [
  null,
  "IPv4-osoite ei voi olla sama kuin verkon kaikkilähetysosoite"
 ],
 "IPv4 and IPv6": [
  null,
  "IPv4 ja IPv6"
 ],
 "IPv4 network should not be empty": [
  null,
  "IPv4-verkko ei tulisi olla tyhjä"
 ],
 "IPv4 only": [
  null,
  "IPv4 vain"
 ],
 "IPv4 prefix length must be 24 or less": [
  null,
  "IPv4-etuliitteen pituus saa olla enintään 24 merkkiä"
 ],
 "IPv4 prefix length must be a multiple of 8": [
  null,
  "IPv4-etuliitteen merkkimäärän on oltava 8:n kerrannainen"
 ],
 "IPv6 address": [
  null,
  "IPv6-osoite"
 ],
 "IPv6 network should not be empty": [
  null,
  "IPv6-verkko ei tulisi olla tyhjä"
 ],
 "IPv6 only": [
  null,
  "IPv6 vain"
 ],
 "Ideal for server VMs": [
  null,
  "Ihanteellinen palvelin-VM:ille"
 ],
 "Ideal networking support": [
  null,
  "Erinomainen verkkotuki"
 ],
 "Identifier in use by $0. VMs with an identical identifier cannot run at the same time.": [
  null,
  "$0 käyttää tunnistetta. VM:t, joilla on sama tunniste, eivät voi toimia samanaikaisesti."
 ],
 "Identifier may be silently truncated to $0 characters ": [
  null,
  "Tunniste voidaan katkaista siitä erikseen kertomatta $0 merkkiin "
 ],
 "Idle": [
  null,
  "Jouten"
 ],
 "Ignore": [
  null,
  "Ohita"
 ],
 "Import VM": [
  null,
  "Tuo virtuaalikone"
 ],
 "Import a virtual machine": [
  null,
  "Tuo virtuaalikone"
 ],
 "Import and edit": [
  null,
  "Tuo ja muokkaa"
 ],
 "Import and run": [
  null,
  "Tuo ja suorita"
 ],
 "Importing an image with a backing file is unsupported": [
  null,
  "Levykuvan tuontia varmistustiedoston kanssa ei tueta"
 ],
 "In most configurations, macvtap does not work for host to guest network communication.": [
  null,
  "Useimmissa kokoonpanoissa macvtap ei toimi isäntä-vieras-verkkoyhteydessä."
 ],
 "Initiator": [
  null,
  "Aloittaja"
 ],
 "Initiator should not be empty": [
  null,
  "Aloittaja ei saa olla tyhjä"
 ],
 "Inject a non-maskable interrupt": [
  null,
  "Lisää ei-maskattava keskeytys"
 ],
 "Insert": [
  null,
  "Insert"
 ],
 "Insert disc media": [
  null,
  "Aseta levyasema"
 ],
 "Inside the VM": [
  null,
  "VM:n sisällä"
 ],
 "Install": [
  null,
  "Asennus"
 ],
 "Installation source": [
  null,
  "Asennuslähde"
 ],
 "Installation source must not be empty": [
  null,
  "Asennuslähteen ei tulisi olla tyhjä"
 ],
 "Installation type": [
  null,
  "Asennustyyppi"
 ],
 "Interface": [
  null,
  "Liitäntä"
 ],
 "Interface type": [
  null,
  "Liitäntätyyppi"
 ],
 "Interface type help": [
  null,
  "Liitäntätyypin ohjeet"
 ],
 "Invalid IPv4 address": [
  null,
  "Ei kelvollinen IPv4-osoite"
 ],
 "Invalid IPv4 mask or prefix length": [
  null,
  "Virheellinen IPv4-peitteen tai etuliitteen pituus"
 ],
 "Invalid IPv6 address": [
  null,
  "Ei kelvollinen IPv6-osoite"
 ],
 "Invalid IPv6 prefix": [
  null,
  "Virheellinen IPv6-etuliite"
 ],
 "Invalid filename": [
  null,
  "Virheellinen tiedostonimi"
 ],
 "Isolated network": [
  null,
  "Eristetty verkko"
 ],
 "It can also be used to enable the inline graphical console in the browser, which does not support SPICE.": [
  null,
  ""
 ],
 "Keys are located in ~/.ssh/ and have a \".pub\" extension.": [
  null,
  "Avaimet sijaitsevat hakemistossa ~/.ssh/ ja ne tunnistetaan niiden \".pub\"-laajennuksesta."
 ],
 "LVM volume group": [
  null,
  "LVM-taltioryhmä"
 ],
 "Leave the password blank if you do not wish to have a root account created": [
  null,
  "Jätä salasana tyhjäksi, jos et halua root:n tilin luomista"
 ],
 "Leave the password blank if you do not wish to have a user account created": [
  null,
  "Jätä salasana tyhjäksi, jos et halua käyttäjätilin luomista"
 ],
 "Leave the password blank if you do not wish to set a root password": [
  null,
  "Jätä salasana tyhjäksi, jos et halua root:n tilin luomista"
 ],
 "Libvirt did not detect any UEFI/OVMF firmware image installed on the host": [
  null,
  "Libvirt ei havainnut isäntään asennettuja UEFI/OVMF-laiteohjelmistokuvia"
 ],
 "Libvirt or hypervisor does not support UEFI": [
  null,
  "Libvirt tai hypervisori ei tue UEFI:a"
 ],
 "Loading available network devices": [
  null,
  "Ladataan käytettävissä olevat verkkolaitteet"
 ],
 "Loading resources": [
  null,
  "Ladataan resursseja"
 ],
 "Loading...": [
  null,
  "Ladataan..."
 ],
 "Local install media (ISO image or distro install tree)": [
  null,
  "Paikallinen asennusmedia (ISO-kuvan tai jakelun asennuspuu)"
 ],
 "Location": [
  null,
  "Sijainti"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "MAC address": [
  null,
  "MAC-osoite"
 ],
 "MAC address already in use": [
  null,
  "MAC-osoite on jo käytössä"
 ],
 "MAC address must not be empty": [
  null,
  "MAC-osoite ei saa olla tyhjä"
 ],
 "Machine must be shut off before changing bus type": [
  null,
  "Kone on sammutettava ennen väylätyypin vaihtamista"
 ],
 "Machine must be shut off before changing cache mode": [
  null,
  "Kone on sammutettava ennen välimuistiin tilan vaihtamista"
 ],
 "Mask or prefix length": [
  null,
  "Peitteen tai etuliitteen pituus"
 ],
 "Mask or prefix length should not be empty": [
  null,
  "Peitteen tai etuliitteen pituus ei tulisi olla tyhjä"
 ],
 "Maximum allocation": [
  null,
  "Enimmäisvaraus"
 ],
 "Maximum memory could not be saved": [
  null,
  "Enimmäismuistia ei voitu tallentaa"
 ],
 "Maximum number of virtual CPUs allocated for the guest OS": [
  null,
  "Vieraskäyttöjärjestelmälle varattu virtuaalisten suorittimien enimmäismäärä"
 ],
 "Maximum number of virtual CPUs allocated for the guest OS, which must be between 1 and $0": [
  null,
  "Vieraskäyttöjärjestelmälle varattu virtuaalisten suorittimien enimmäismäärä, jonka on oltava välillä 1 ja $0"
 ],
 "Maximum transmission unit": [
  null,
  "Enimmäislähetysyksikkö"
 ],
 "Media could not be ejected from $0": [
  null,
  "Mediaa ei voitu poistaa $0:sta"
 ],
 "Media will be ejected from $0:": [
  null,
  "Media poistetaan $0:sta:"
 ],
 "Memory": [
  null,
  "Muisti"
 ],
 "Memory could not be saved": [
  null,
  "Muistia ei voitu tallentaa"
 ],
 "Memory must not be 0": [
  null,
  "Muisti ei saa olla 0"
 ],
 "Memory save location can not be empty": [
  null,
  "Muistin tallennuspaikka ei voi olla tyhjä"
 ],
 "Memory snapshot will use about $0.": [
  null,
  "Muistin tilannevedos käyttää noin $0."
 ],
 "Memory state path": [
  null,
  "Muistin tilan polku"
 ],
 "MiB": [
  null,
  "Mit"
 ],
 "Migrate": [
  null,
  "Migratoi"
 ],
 "Migrate VM to another host": [
  null,
  "Siirrä virtuaalikone toiseen koneeseen"
 ],
 "Migration failed": [
  null,
  "Migraatio epäonnistui"
 ],
 "Mode": [
  null,
  "Tila"
 ],
 "Model": [
  null,
  "Malli"
 ],
 "Model type": [
  null,
  "Mallityyppi"
 ],
 "Mount tag": [
  null,
  "Liitostunniste"
 ],
 "Mount tag must not be empty": [
  null,
  "Liitostunnus ei voi olla tyhjä"
 ],
 "Must be an address instead of the network identifier, such as $0": [
  null,
  "On oltava osoite verkkotunnuksen sijaan, kuten $0"
 ],
 "NAT to $0": [
  null,
  "NAT $0:een"
 ],
 "NIC $0 of VM $1 failed to change state": [
  null,
  "Virtuaalikoneen $1 verkkokortti $0 ei muuttanut tilaa"
 ],
 "Name": [
  null,
  "Nimi"
 ],
 "Name already exists": [
  null,
  "Nimi on jo olemassa"
 ],
 "Name can not be empty": [
  null,
  "Nimi ei voi olla tyhjä"
 ],
 "Name contains invalid characters": [
  null,
  "Nimi sisältää laittomia merkkejä"
 ],
 "Name must not be empty": [
  null,
  "Nimi ei saa olla tyhjä"
 ],
 "Name should not be empty": [
  null,
  "Nime ei tulisi olla tyhjä"
 ],
 "Name: ": [
  null,
  "Nimi: "
 ],
 "Netmask": [
  null,
  "Verkkopeite"
 ],
 "Network $0 could not be deleted": [
  null,
  "Verkkoa $0 ei voitu poistaa"
 ],
 "Network $0 failed to get activated": [
  null,
  "Verkkoa $0 ei voitu aktivoida"
 ],
 "Network $0 failed to get deactivated": [
  null,
  "Verkkoa $0 ei voitu poistaa käytöstä"
 ],
 "Network $0 will be permanently deleted.": [
  null,
  "Verkko $0 poistetaan pysyvästi."
 ],
 "Network boot (PXE)": [
  null,
  "Verkkokäynnistys (PXE)"
 ],
 "Network file system": [
  null,
  "Verkkotiedostojärjestelmä"
 ],
 "Network interface": [
  null,
  "verkkoliitäntä"
 ],
 "Network interface $0 could not be removed": [
  null,
  "Verkkoliitäntää $0 ei voitu poistaa"
 ],
 "Network interface $0 will be removed from $1": [
  null,
  "Verkkoliitäntä $0 poistetaan kohdasta $1"
 ],
 "Network interface settings could not be saved": [
  null,
  "Verkkoliitännän asetuksia ei voitu tallentaa"
 ],
 "Network interfaces": [
  null,
  "Verkkoliitännät"
 ],
 "Network selection does not support PXE.": [
  null,
  "Verkon valinta ei tue PXE:ta."
 ],
 "Networks": [
  null,
  "Verkot"
 ],
 "New name": [
  null,
  "Uusi nimi"
 ],
 "New name must not be empty": [
  null,
  "Uusi nimi ei saa olla tyhjä"
 ],
 "New volume name": [
  null,
  "Uusi taltion nimi"
 ],
 "No SSH keys specified": [
  null,
  "SSH-avaimia ei määritetty"
 ],
 "No VM is running or defined on this host": [
  null,
  "Mikään virtuaalikone ei ole käynnissä tai määritelty tässä isännässä"
 ],
 "No boot device found": [
  null,
  "Käynnistyslaitetta ei löytynyt"
 ],
 "No description": [
  null,
  "Ei kuvausta"
 ],
 "No directories shared between the host and this VM": [
  null,
  "Isäntäkoneen ja tämän virtuaalikoneen välillä ei ole jaettuja hakemistoja"
 ],
 "No disks defined for this VM": [
  null,
  "Tälle virtuaalikoneelle ei ole määritetty levyjä"
 ],
 "No host device selected": [
  null,
  "Isäntälaitetta ei valittu"
 ],
 "No host devices assigned to this VM": [
  null,
  "Tälle virtuaalikoneelle ei ole määritetty isäntälaitteita"
 ],
 "No network devices": [
  null,
  "Ei verkkolaitteita"
 ],
 "No network interfaces defined for this VM": [
  null,
  "Tälle virtuaalikoneelle ei ole määritetty verkkoliitäntöjä"
 ],
 "No network is defined on this host": [
  null,
  "Tälle isännälle ei ole määritetty verkkoa"
 ],
 "No networks available": [
  null,
  "Verkkoja ei ole käytettävissä"
 ],
 "No parent": [
  null,
  "Ei vanhempi"
 ],
 "No snapshots defined for this VM": [
  null,
  "Tälle virtuaalikoneelle ei ole määritetty tilannevedoksia"
 ],
 "No state": [
  null,
  "Ei tilaa"
 ],
 "No storage": [
  null,
  "Ei tallennustilaa"
 ],
 "No storage pool is defined on this host": [
  null,
  "Tälle isännälle ei ole määritetty varastointivarantoa"
 ],
 "No storage pools available": [
  null,
  "Ei varastointivarantoja saatavilla"
 ],
 "No storage volumes defined for this storage pool": [
  null,
  "Tälle varastointivarannolle ei ole määritetty varastointitaltioita"
 ],
 "No virtual networks": [
  null,
  "Ei virtuaaliverkkoja"
 ],
 "No volumes exist in this storage pool.": [
  null,
  "Tässä tallennusvarannossa ei ole taltioita."
 ],
 "Non-persistent network cannot be deleted. It ceases to exists when it's deactivated.": [
  null,
  "Ei-pysyvää verkkoa ei voida poistaa. Se lakkaa olemasta, kun se deaktivoidaan."
 ],
 "Non-persistent storage pool cannot be deleted. It ceases to exists when it's deactivated.": [
  null,
  "Ei-pysyvää varastointivarantoa ei voida poistaa. Se lakkaa olemasta, kun se deaktivoidaan."
 ],
 "None": [
  null,
  "Ei yhtään"
 ],
 "None (isolated network)": [
  null,
  "Ei-eristetty verkko"
 ],
 "Offline token": [
  null,
  "Ei-verkkotilassa oleva poletti"
 ],
 "Offline token must not be empty": [
  null,
  "Ei-verkkotilassa oleva poletti ei saa olla tyhjä"
 ],
 "Old token expired": [
  null,
  "Token on vanhentunut"
 ],
 "On the host": [
  null,
  "Isännässä"
 ],
 "One or more selected volumes are used by domains. Detach the disks first to allow volume deletion.": [
  null,
  "Toimialueet käyttävät yhtä tai useampaa valittua taltiota. Irrota levyt ensin, jotta taltio voidaan poistaa."
 ],
 "Only editable when the guest is shut off": [
  null,
  "Muokattavissa vain, kun vieras on sammutettuna"
 ],
 "Open": [
  null,
  "Avaa"
 ],
 "Operating system": [
  null,
  "Käyttöjärjestelmä"
 ],
 "Operation is in progress": [
  null,
  "Toiminto käynnissä"
 ],
 "Other VMs using SPICE": [
  null,
  "Muut SPICEa käyttävät virtuaalikoneet"
 ],
 "Overview": [
  null,
  "Esittely"
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "Parent snapshot": [
  null,
  "Vanhempi-tilannevedos"
 ],
 "Password must be 8 characters or less. VNC passwords do not provide encryption and are generally cryptographically weak. They can not be used to secure connections in untrusted networks.": [
  null,
  ""
 ],
 "Password must be at most 8 characters.": [
  null,
  ""
 ],
 "Path": [
  null,
  "Polku"
 ],
 "Path on host's filesystem": [
  null,
  "Polku isännän tiedostojärjestelmässä"
 ],
 "Path to ISO file on host's file system": [
  null,
  "Polku ISO-tiedostoon isännän tiedostojärjestelmässä"
 ],
 "Path to cloud image file on host's file system": [
  null,
  "Polku pilvipohjaiseen tiedostoon isännän tiedostojärjestelmässä"
 ],
 "Path to directory": [
  null,
  "Polku hakemistoon"
 ],
 "Path to file on host's file system": [
  null,
  "Polku tiedostoon isännän tiedostojärjestelmässä"
 ],
 "Pause": [
  null,
  "Keskeytä"
 ],
 "Paused": [
  null,
  "Keskeytetty"
 ],
 "Permanent (default)": [
  null,
  "Pysyvä (oletus)"
 ],
 "Permissions denied for disk images in home directories": [
  null,
  "Kotihakemistojen levykuvien käyttöoikeudet estetty"
 ],
 "Persistence": [
  null,
  "Pysyvyys"
 ],
 "Persistent": [
  null,
  "Pysyvä"
 ],
 "Physical disk device": [
  null,
  "Fyysinen levylaite"
 ],
 "Physical disk device on host": [
  null,
  "Fyysinen levylaite isännässä"
 ],
 "Please choose a different MAC address": [
  null,
  "Valitse toinen MAC-osoite"
 ],
 "Please choose a storage pool": [
  null,
  "Valitse tallennusvaranto"
 ],
 "Please choose a volume": [
  null,
  "Valitse taltio"
 ],
 "Please enter new volume name": [
  null,
  "Anna uusi taltion nimi"
 ],
 "Please see $0 how to reconfigure your VM manually.": [
  null,
  "Katso $0 kuinka voit määrittää virtuaalikoneen uudelleen manuaalisesti."
 ],
 "Pool": [
  null,
  "Varanto"
 ],
 "Pool needs to be active to create volume": [
  null,
  "Varannon on oltava aktiivinen taltion luomiseksi"
 ],
 "Pool type $0 does not support volume creation": [
  null,
  "Varannon tyyppi $0 ei tue taltion luomista"
 ],
 "Pool type doesn't support volume creation": [
  null,
  "Varannon tyyppi ei tue taltion luomista"
 ],
 "Pool's volumes are used by VMs ": [
  null,
  "Varannon taltioita käyttävät virtuaalikoneet "
 ],
 "Port": [
  null,
  "Portti"
 ],
 "Port must be 5900 or larger.": [
  null,
  ""
 ],
 "Port must be a number that is at least 5900. Leave empty to automatically assign a free port when the machine starts.": [
  null,
  ""
 ],
 "Power off": [
  null,
  "Sammuta virta"
 ],
 "Pre-formatted block device": [
  null,
  "Esialustettu lohkolaite"
 ],
 "Preferred number of sockets to expose to the guest.": [
  null,
  "Vieraalle altistettavaksi haluttu pistokkeiden määrä ."
 ],
 "Prefix": [
  null,
  "Etuliite"
 ],
 "Prefix length": [
  null,
  "Etuliitteen pituus"
 ],
 "Prefix length should not be empty": [
  null,
  "Etuliitteen pituuss ei tulisi olla tyhjä"
 ],
 "Previously taken snapshots allow you to revert to an earlier state if something goes wrong": [
  null,
  "Aiemmin otettujen tilannevedoksien avulla voit palata aikaisempaan tilaan, jos jokin menee pieleen"
 ],
 "Private": [
  null,
  "Yksityinen"
 ],
 "Product": [
  null,
  "Tuote"
 ],
 "Profile": [
  null,
  "Profiili"
 ],
 "Protocol": [
  null,
  "Protokolla"
 ],
 "Provides a bridge from the guest virtual machine directly onto the LAN. This needs a bridge device on the host with one or more physical NICs.": [
  null,
  "Tarjoaa sillan vierasvirtuaalikoneesta suoraan lähiverkkoon. Tämä vaatii isäntälaitteen, jolla on yksi tai useampi fyysinen verkkokortti."
 ],
 "Provides a connection whose details are described by the named network definition.": [
  null,
  "Tarjoaa yhteyden, jonka tiedot kuvataan nimetyllä verkon määritelmällä."
 ],
 "Provides a virtual LAN with NAT to the outside world.": [
  null,
  "Tarjoaa virtuaalisen lähiverkon NATin kanssa ulkomaailmaan."
 ],
 "Public SSH key": [
  null,
  "Julkinen SSH-avain"
 ],
 "Public key": [
  null,
  "Julkinen avain"
 ],
 "Range": [
  null,
  "Alue"
 ],
 "Read-only": [
  null,
  "Vain luku"
 ],
 "Reboot": [
  null,
  "Käynnistä uudelleen"
 ],
 "Reboot $0?": [
  null,
  "Käynnistä $0 uudelleen?"
 ],
 "Recommended operating systems": [
  null,
  "Suositellut käyttöjärjestelmät"
 ],
 "Released $0": [
  null,
  "Julkaistu $0"
 ],
 "Remote URL": [
  null,
  "Etä-URL"
 ],
 "Remote viewer applications can connect to the following address:": [
  null,
  ""
 ],
 "Remove": [
  null,
  "Poista"
 ],
 "Remove SPICE audio and host devices": [
  null,
  "Poista SPICE-ääni- ja isäntälaitteet"
 ],
 "Remove and delete file": [
  null,
  "Poista ja poista tiedosto"
 ],
 "Remove disk from VM?": [
  null,
  "Poistetaanko levy VM:stä?"
 ],
 "Remove filesystem?": [
  null,
  "Poista tiedostojärjestelmä?"
 ],
 "Remove host device from VM?": [
  null,
  "Poista isäntälaite VM:stä?"
 ],
 "Remove item": [
  null,
  "Poista kohde"
 ],
 "Remove network interface?": [
  null,
  "Poista verkkoliitäntä?"
 ],
 "Remove static host from DHCP": [
  null,
  "Poista staattinen isäntä DHCP:stä"
 ],
 "Rename": [
  null,
  "Nimeä uudelleen"
 ],
 "Rename VM $0": [
  null,
  "Nimeä uudelleen VM $0"
 ],
 "Replace": [
  null,
  "Vaihda"
 ],
 "Replace SPICE devices": [
  null,
  "Vaihda SPICE-laitteet"
 ],
 "Replace SPICE devices in VM $0": [
  null,
  "Vaihda SPICE-laitteet virtuaalikoneessa $0"
 ],
 "Replace SPICE on selected VMs.": [
  null,
  "Vaihda SPICE valituissa virtuaalikoneissa."
 ],
 "Replace SPICE on the virtual machine.": [
  null,
  "Vaihda SPICE virtuaalikoneessa."
 ],
 "Reset": [
  null,
  "Nollaa"
 ],
 "Restrictions in networking (SLIRP-based emulation) and PCI device assignment": [
  null,
  "Rajoitukset verkkotoiminnassa (SLIRP-pohjainen emulointi) ja PCI-laitteiden määrittämisessä"
 ],
 "Resume": [
  null,
  "Palauta"
 ],
 "Revert": [
  null,
  "Palaa"
 ],
 "Revert to snapshot $0": [
  null,
  "Palaa tilannevedokseen $0"
 ],
 "Reverting to this snapshot will take the VM back to the time of the snapshot and the current state will be lost, along with any data not captured in a snapshot": [
  null,
  "Palautus tähän tilannevedokseen palauttaa virtuaalikoneen tilannevedoksen aikaan ja nykyinen tila häviää, samoin kuin kaikki tiedot, joita ei ole siepattu tilannevedoksessa"
 ],
 "Root password": [
  null,
  "Root:n salasana"
 ],
 "Route to $0": [
  null,
  "Reitti $0:een"
 ],
 "Routed network": [
  null,
  "Reititetty verkko"
 ],
 "Row select": [
  null,
  "Rivin valinta"
 ],
 "Run": [
  null,
  "Suorita"
 ],
 "Run when host boots": [
  null,
  "Suorita, kun isäntä käynnistyy"
 ],
 "Running": [
  null,
  "Käynnissä"
 ],
 "SPICE": [
  null,
  "SPICE"
 ],
 "SPICE conversion": [
  null,
  "SPICE-muunnos"
 ],
 "SPICE is not supported on this host and will cause this virtual machine to not boot.": [
  null,
  "SPICEa ei tueta tällä isännällä, ja se aiheuttaa sen, että tämä virtuaalikone ei käynnisty."
 ],
 "SSH keys": [
  null,
  "SSH-avaimet"
 ],
 "Save": [
  null,
  "Tallenna"
 ],
 "Select all": [
  null,
  "Valitse kaikki"
 ],
 "Send key": [
  null,
  "Lähetä avain"
 ],
 "Send non-maskable interrupt": [
  null,
  "Lähetä ei-peitettävä keskeytys"
 ],
 "Send non-maskable interrupt to $0?": [
  null,
  "Lähetä kohteeseen $0 ei-peitettävä keskeytys?"
 ],
 "Serial": [
  null,
  "Sarjanumero"
 ],
 "Serial console": [
  null,
  "Sarjakonsoli"
 ],
 "Serial console support not enabled": [
  null,
  ""
 ],
 "Set DHCP range": [
  null,
  "Määritä DHCP-alue"
 ],
 "Set manually": [
  null,
  "Aseta käsin"
 ],
 "Setting the user passwords for unattended installation requires starting the VM when creating it": [
  null,
  "Käyttäjän salasanojen asettaminen valvomatonta asennusta varten edellyttää virtuaalikoneen käynnistämistä sen luomisen yhteydessä"
 ],
 "Share": [
  null,
  "Jako"
 ],
 "Share a host directory with the guest": [
  null,
  "Jaa isäntähakemisto vieraalle"
 ],
 "Shared directories": [
  null,
  "Jaetut hakemistot"
 ],
 "Shared host directories need to be manually mounted inside the VM": [
  null,
  "Jaetut isäntähakemistot on liitettävä manuaalisesti virtuaalikoneessa"
 ],
 "Shared storage": [
  null,
  "Jaettu tallennustila"
 ],
 "Show additional options": [
  null,
  "Näytä lisävaihtoehdot"
 ],
 "Show less": [
  null,
  "Näytä vähemmän"
 ],
 "Show more": [
  null,
  "Näytä lisää"
 ],
 "Shut down": [
  null,
  "Sammuta"
 ],
 "Shut down $0?": [
  null,
  "Sammuta $0?"
 ],
 "Shut off": [
  null,
  "Sammuta"
 ],
 "Shut off the VM in order to edit firmware configuration": [
  null,
  "Sammuta virtuaalikone, jotta voit muokata laiteohjelmiston kokoonpanoa"
 ],
 "Shutting down": [
  null,
  "Sammutetaan"
 ],
 "Size": [
  null,
  "Koko"
 ],
 "Slot": [
  null,
  "Aukko"
 ],
 "Snapshot $0 could not be deleted": [
  null,
  "Tilannevedosta $0 ei voitu poistaa"
 ],
 "Snapshot $0 will be deleted from $1. All of its captured content will be lost.": [
  null,
  "Tilannevedos $0 poistetaan kohteesta $1. Kaikki sen kaapattu sisältö menetetään."
 ],
 "Snapshot failed to be created": [
  null,
  "Tilannevedoksen luominen epäonnistui"
 ],
 "Snapshots": [
  null,
  "Tilannevedokset"
 ],
 "Sockets": [
  null,
  "Pistokkeet"
 ],
 "Some configuration changes only take effect after a fresh boot:": [
  null,
  "Jotkut asetusmuutokset tulevat voimaan vasta uuden käynnistyksen jälkeen:"
 ],
 "Source": [
  null,
  "Lähde"
 ],
 "Source format": [
  null,
  "Lähteen muoto"
 ],
 "Source must not be empty": [
  null,
  "Lähde ei saa olla tyhjä"
 ],
 "Source path": [
  null,
  "Lähteen polku"
 ],
 "Source path should not be empty": [
  null,
  "Lähdepolku ei saa olla tyhjä"
 ],
 "Source should start with http, ftp or nfs protocol": [
  null,
  "Lähteen tulisi alkaa http-, ftp- tai nfs-protokollalla"
 ],
 "Source volume group": [
  null,
  "Lähteen taltioryhmä"
 ],
 "Start": [
  null,
  "Käynnistä"
 ],
 "Start pool when host boots": [
  null,
  "Käynnistä varanto, kun isäntä käynnistyy"
 ],
 "Start should not be empty": [
  null,
  "Käynnistys ei tulisi olla tyhjä"
 ],
 "Started": [
  null,
  "Käynnistetty"
 ],
 "Startup": [
  null,
  "Aloittaa"
 ],
 "State": [
  null,
  "Tila"
 ],
 "Static host entries": [
  null,
  "Staattiset laitemerkinnät"
 ],
 "Static host from DHCP could not be removed": [
  null,
  "Staattista isäntää ei voitu poistaa DHCP:stä"
 ],
 "Storage": [
  null,
  "Tallennustila"
 ],
 "Storage is at a shared location": [
  null,
  "Tallennustila on jaetussa paikassa"
 ],
 "Storage limit": [
  null,
  "Tallennustilan raja"
 ],
 "Storage pool $0 failed to get activated": [
  null,
  "Tallennusvarannon $0 aktivointi epäonnistui"
 ],
 "Storage pool $0 failed to get deactivated": [
  null,
  "Tallennusvarannon $0 aktivoinnin poisto epäonnistui"
 ],
 "Storage pool failed to be created": [
  null,
  "Varastointivarannon luominen epäonnistui"
 ],
 "Storage pool name": [
  null,
  "Varastointivarannon nimi"
 ],
 "Storage pools": [
  null,
  "Tallennustilavarannot"
 ],
 "Storage pools could not be fetched": [
  null,
  "Tallennusvarantoja ei voitu hakea"
 ],
 "Storage size must not be 0": [
  null,
  "Tallennuskoko ei saa olla 0"
 ],
 "Storage volume": [
  null,
  "Varastointivarannon taltio"
 ],
 "Storage volume size must not exceed the storage pool's capacity ($0 $1)": [
  null,
  "Tallennustaltion koko ei saa ylittää tallennusvarannon kapasiteettia ($0 $1)"
 ],
 "Storage volumes": [
  null,
  "Varastoinnin taltiot"
 ],
 "Storage volumes could not be deleted": [
  null,
  "Varastointitaltioita ei voitu poistaa"
 ],
 "Storage volumes must be shared between this host and the destination host.": [
  null,
  "Tallennustilat on pakko jakaa tämän isännän ja kohdepalvelimen kesken."
 ],
 "Suspended (PM)": [
  null,
  "Pysäytetty (PM)"
 ],
 "Switch to VNC to continue using this machine.": [
  null,
  "Vaihda VNC:hen jatkaaksesi tämän koneen käyttöä."
 ],
 "System": [
  null,
  "Järjestelmä"
 ],
 "TAP device": [
  null,
  "TAP-laite"
 ],
 "TPM": [
  null,
  "TPM"
 ],
 "Table of selectable host devices": [
  null,
  "Taulukko valittavista olevista isäntälaitteista"
 ],
 "Target": [
  null,
  "Kohde"
 ],
 "Target path": [
  null,
  "Kohteen polku"
 ],
 "Target path should not be empty": [
  null,
  "Kohdepolku ei saa olla tyhjä"
 ],
 "Temporary": [
  null,
  "Väliaikainen"
 ],
 "Temporary migration": [
  null,
  "Väliaikainen migraatio"
 ],
 "The VM $0 is running and will be forced off before deletion.": [
  null,
  "Virtuaalikone $0 on käynnissä ja se pakotetaan pois päältä ennen poistamista."
 ],
 "The VM needs to be running or shut off to detach this device": [
  null,
  "Virtuaalikoneen on oltava käynnissä tai sammutettuna laitteen irrottamiseksi"
 ],
 "The directory on the server being exported": [
  null,
  "Viedyn palvelimen hakemisto"
 ],
 "The host path that is to be exported.": [
  null,
  "Vietävä isäntäpolku."
 ],
 "The migrated VM configuration is removed from the source host. The destination host is considered the new home of the VM.": [
  null,
  "Siirretty virtuaalikoneen kokoonpano poistetaan lähdekoneesta. Kohdekonetta pidetään virtuaalikoneen uutena kotina."
 ],
 "The mode influences the delivery of packets.": [
  null,
  ""
 ],
 "The pool is empty": [
  null,
  "Varanto on tyhjä"
 ],
 "The selected operating system has minimum memory requirement of $0 $1": [
  null,
  "Valitulla käyttöjärjestelmällä on vähimmäismäärä muistia $0 $1"
 ],
 "The selected operating system has minimum storage size requirement of $0 $1": [
  null,
  "Valitun käyttöjärjestelmän tallennustilan vähimmäisvaatimus on $0 $1"
 ],
 "The static host entry for $0 will be removed:": [
  null,
  "Staattinen isäntämerkintä $0:lle poistetaan:"
 ],
 "The storage pool could not be deleted": [
  null,
  "Tallennusvarantoa ei voitu poistaa"
 ],
 "The tag name to be used by the guest to mount this export point.": [
  null,
  "Tunnisteen nimi, jota vieras käyttää tämän vientipisteen liittämiseen."
 ],
 "Then copy and paste it above.": [
  null,
  "Kopioi ja liitä se sitten yläpuolelle."
 ],
 "This VM is transient. Shut it down if you wish to delete it.": [
  null,
  "Tämä virtuaalikone on ohimenevä. Sammuta se, jos haluat poistaa sen."
 ],
 "This disk will be removed from $0:": [
  null,
  "Tämä levy poistetaan $0:sta:"
 ],
 "This filesystem will be removed from $0:": [
  null,
  "Tämä tiedostojärjestelmä poistetaan $0:sta:"
 ],
 "This is intended for a host which does not support SPICE due to upgrades or live migration.": [
  null,
  "Tämä on tarkoitettu isännälle, joka ei tue SPICEa päivitysten tai reaaliaikaisen siirron vuoksi."
 ],
 "This machine has a SPICE graphical console that can not be shown here.": [
  null,
  ""
 ],
 "This volume is already used by $0.": [
  null,
  "Tätä taltiota käyttää jo $0."
 ],
 "This volume is already used by another VM.": [
  null,
  "Tätä taltiota käyttää jo toinen virtuaalikone."
 ],
 "Threads per core": [
  null,
  "Säikeitä per ydin"
 ],
 "Total space available: $0.": [
  null,
  "Tilaa yhteensä: $0."
 ],
 "Transient VMs don't support editing firmware configuration": [
  null,
  "Ohimenevät virtuaalikoneet eivät tue laiteohjelmiston kokoonpanon muokkaamista"
 ],
 "Troubleshoot": [
  null,
  "Vianetsintä"
 ],
 "Type": [
  null,
  "Tyyppi"
 ],
 "URL (ISO image or distro install tree)": [
  null,
  "URL (ISO-kuvan tai jakelun asennuspuu)"
 ],
 "USB": [
  null,
  "USB"
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Undefined": [
  null,
  "Määrittämätön"
 ],
 "Unique name": [
  null,
  "Ainutlaatuinen nimi"
 ],
 "Unique name, default: $0": [
  null,
  "Ainutlaatuinen nimi, oletusarvo: $0"
 ],
 "Unique network name": [
  null,
  "Ainutlaatuinen verkon nimi"
 ],
 "Unit": [
  null,
  "Yksikkö"
 ],
 "Unknown": [
  null,
  "Tuntematon"
 ],
 "Unknown firmware": [
  null,
  "Tuntematon laiteohjelmisto"
 ],
 "Unspecified": [
  null,
  "Määrittämätön"
 ],
 "Unsupported and older operating systems": [
  null,
  "Ei tuetut ja vanhemmat käyttöjärjestelmät"
 ],
 "Url": [
  null,
  "Url"
 ],
 "Usage": [
  null,
  "Käyttö"
 ],
 "Use existing": [
  null,
  "Käytä olemassaolevaa"
 ],
 "Use extended attributes on files and directories": [
  null,
  "Käytä laajennettuja määritteitä tiedostoissa ja hakemistoissa"
 ],
 "Use the same location on both the origin and destination hosts for your storage. This can be a shared storage pool, NFS, or any other method of sharing storage.": [
  null,
  "Käytä samaa sijaintia sekä lähtö- että kohdekoneiden tallennustilassa. Tämä voi olla jaettu tallennustila, NFS tai mikä tahansa muu tapa jakaa tallennustilaa."
 ],
 "Used": [
  null,
  "Käytetty"
 ],
 "Used by": [
  null,
  "Käyttävä"
 ],
 "User login": [
  null,
  "Käyttäjän sisäänkirjautuminen"
 ],
 "User login must not be empty when SSH keys are set": [
  null,
  "Käyttäjän sisäänkirjautumistunnus ei saa olla tyhjä, kun SSH-avaimet on asetettu"
 ],
 "User login must not be empty when user password is set": [
  null,
  "Käyttäjän sisäänkirjautuminen ei saa olla tyhjä, kun käyttäjän salasana on asetettu"
 ],
 "User password": [
  null,
  "Käyttäjäsalasana"
 ],
 "User password must not be empty when user login is set": [
  null,
  "Käyttäjän salasana ei saa olla tyhjä, kun käyttäjän sisäänkirjautuminen on asetettu"
 ],
 "User session": [
  null,
  "Käyttäjäistunto"
 ],
 "Uses SPICE": [
  null,
  "Käyttää SPICEä"
 ],
 "VM $0 Host Devices": [
  null,
  "VM $0 isäntälaitteet"
 ],
 "VM $0 already exists": [
  null,
  "Virtuaalikone $0 on jo olemassa"
 ],
 "VM $0 does not exist on $1 connection": [
  null,
  "Virtuaalikone $0 ei ole olemassa yhteydellä $1"
 ],
 "VM $0 failed to force reboot": [
  null,
  "Virtuaalikoneen $0 uudelleenkäynnistyksen pakottaminen epäonnistui"
 ],
 "VM $0 failed to force shutdown": [
  null,
  "Virtuaalikone $0 epäonnistui pakottamaan sammutus"
 ],
 "VM $0 failed to get installed": [
  null,
  "Virtuaalikone $0 epäonnistui saamaan itse asennetuksi"
 ],
 "VM $0 failed to pause": [
  null,
  "Virtuaalikone $0 epäonnistui keskeytymään"
 ],
 "VM $0 failed to reboot": [
  null,
  "Virtuaalikone $0 epäonnistui käynnistymään uudelleen"
 ],
 "VM $0 failed to resume": [
  null,
  "Virtuaalikone $0 epäonnistui palautumaan"
 ],
 "VM $0 failed to send NMI": [
  null,
  "Virtuaalikone $0 epäonnistui lähettämään NMI"
 ],
 "VM $0 failed to shutdown": [
  null,
  "Virtuaalikone $0 epäonnistui sammuttamaan"
 ],
 "VM $0 failed to start": [
  null,
  "Virtuaalikone $0 epäonnistui käynnistymään"
 ],
 "VM launched with unprivileged limited access, with the process and PTY owned by your user account": [
  null,
  "VM julkaistiin etuoikeutetulla rajoitetulla pääsyllä, jossa prosessin ja PTY:n omistaa käyttäjätilisi"
 ],
 "VM needs shutdown": [
  null,
  "Virtuaalikone vaatii sammutuksen"
 ],
 "VM state": [
  null,
  "Virtuaalikoneen tila"
 ],
 "VM will launch with root permissions": [
  null,
  "VM käynnistyy pääkäyttäjän oikeuksin"
 ],
 "VNC": [
  null,
  ""
 ],
 "Valid token": [
  null,
  "Kelvollinen tokeni"
 ],
 "Vendor": [
  null,
  "Toimittaja"
 ],
 "Vendor support ended $0": [
  null,
  "Toimittajatuki päättyi $0"
 ],
 "Virtual machines": [
  null,
  "Virtuaalikoneet"
 ],
 "Virtual machines management": [
  null,
  "Virtuaalikoneiden hallinta"
 ],
 "Virtual network": [
  null,
  "Virtuaaliverkko"
 ],
 "Virtual network failed to be created": [
  null,
  "Virtuaaliverkon luominen epäonnistui"
 ],
 "Virtual socket support enables communication between the host and guest over a socket. It still requires special vsock-aware software to communicate over the socket.": [
  null,
  "Virtuaalisen pistokkeen tuki mahdollistaa isännän ja vieraan välisen viestinnän pistokkeen kautta. Se vaatii edelleen erityistä vsock-tietoista ohjelmistoa kommunikoidakseen pistokkeen kautta."
 ],
 "Virtualization service (libvirt) is not active": [
  null,
  "Virtualisointipalvelu (libvirt) ei ole aktiivinen"
 ],
 "Volume": [
  null,
  "Taltio"
 ],
 "Volume failed to be created": [
  null,
  "Taltion luominen epäonnnistui"
 ],
 "Volume group name": [
  null,
  "Taltioryhmän nimi"
 ],
 "Volume group name should not be empty": [
  null,
  "Taltioryhmän nimi ei tulisi olla tyhjä"
 ],
 "Vsock": [
  null,
  "Vsock"
 ],
 "WWPN": [
  null,
  "WWPN"
 ],
 "Watchdog": [
  null,
  "Vahtikoira"
 ],
 "Watchdogs act when systems stop responding. To use this virtual watchdog device, the guest system also needs to have an additional driver and a running watchdog service.": [
  null,
  "Vahtikoira reagoi, kun järjestelmät lakkaavat vastaamasta. Tämän virtuaalisen vahtikoiralaitteen käyttämiseksi vierasjärjestelmässä on oltava myös ylimääräinen ajuri ja käynnissä oleva vahtikoirapalvelu."
 ],
 "Writeable": [
  null,
  "Kirjoitettava"
 ],
 "You can mount the shared folder using:": [
  null,
  "Voit liittää jaetun kansion seuraavasti:"
 ],
 "You need to select the most closely matching operating system": [
  null,
  "Sinun on valittava parhaiten vastaava käyttöjärjestelmä"
 ],
 "active": [
  null,
  "aktiivinen"
 ],
 "add": [
  null,
  "lisää"
 ],
 "add entry": [
  null,
  "lisää merkintä"
 ],
 "bridge": [
  null,
  "silta"
 ],
 "cdrom": [
  null,
  "cd-rom"
 ],
 "custom": [
  null,
  "mukautettu"
 ],
 "direct": [
  null,
  "suora"
 ],
 "disabled": [
  null,
  "pois käytöstä"
 ],
 "disk": [
  null,
  "levy"
 ],
 "down": [
  null,
  "alas"
 ],
 "edit": [
  null,
  "muokkaa"
 ],
 "enabled": [
  null,
  "käytössä"
 ],
 "ethernet": [
  null,
  "ethernet"
 ],
 "host": [
  null,
  "isäntä"
 ],
 "host device": [
  null,
  "isäntälaite"
 ],
 "host passthrough": [
  null,
  "isännän läpivienti"
 ],
 "hostdev": [
  null,
  "isäntälaite"
 ],
 "iSCSI direct target": [
  null,
  "iSCSI -suora kohde"
 ],
 "iSCSI initiator IQN": [
  null,
  "iSCSI-aloittaja IQN"
 ],
 "iSCSI target": [
  null,
  "iSCSI-kohde"
 ],
 "iSCSI target IQN": [
  null,
  "iSCSI-kohteen IQN"
 ],
 "inactive": [
  null,
  "ei aktiivinen"
 ],
 "inet": [
  null,
  "inet"
 ],
 "inet6": [
  null,
  "inet6"
 ],
 "mcast": [
  null,
  "monilähetys"
 ],
 "more info": [
  null,
  "lisätietoja"
 ],
 "mount point: The mount point inside the guest": [
  null,
  "liitoskohta: liitoskohta vieraskoneessa"
 ],
 "mount tag: The tag associated to the exported mount point": [
  null,
  "liitostunniste: vietyyn liitoskohtaan liittyvä tunniste"
 ],
 "network": [
  null,
  "verkko"
 ],
 "no": [
  null,
  "ei"
 ],
 "no state saved": [
  null,
  "ei tilaa tallennettuna"
 ],
 "none": [
  null,
  "Ei mitään"
 ],
 "redirected device": [
  null,
  "uudelleenohjattu laite"
 ],
 "remove": [
  null,
  "poista"
 ],
 "serial number": [
  null,
  "sarjanumero"
 ],
 "server": [
  null,
  "palvelin"
 ],
 "udp": [
  null,
  "udp"
 ],
 "up": [
  null,
  "ylös"
 ],
 "user": [
  null,
  "käyttäjä"
 ],
 "vCPU and CPU topology settings could not be saved": [
  null,
  "vCPU- ja CPU-topologia-asetuksia ei voitu tallentaa"
 ],
 "vCPU count": [
  null,
  "vCPU-lasku"
 ],
 "vCPU maximum": [
  null,
  "vCPU enintään"
 ],
 "vCPUs": [
  null,
  "vCPU:t"
 ],
 "vhostuser": [
  null,
  "virtuaali-isännän käyttäjä"
 ],
 "view more...": [
  null,
  "Katso lisää..."
 ],
 "virt-install package needs to be installed on the system in order to clone VMs": [
  null,
  "Paketti virt-install on asennettava järjestelmään virtuaalikoneiden kloonaamiseksi"
 ],
 "virt-install package needs to be installed on the system in order to create new VMs": [
  null,
  "Paketti virt-install on asennettava järjestelmään uusien virtuaalikoneiden luomiseksi"
 ],
 "virt-install package needs to be installed on the system in order to edit this attribute": [
  null,
  "Paketti virt-install on asennettava järjestelmään tämän attribuutin muokkaamiseksi"
 ],
 "vsock requires special software": [
  null,
  "vsock vaatii erikoisohjelmiston"
 ],
 "yes": [
  null,
  "kyllä"
 ]
});
