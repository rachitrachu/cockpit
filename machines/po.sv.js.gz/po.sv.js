cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "sv",
  "language-direction": "ltr"
 },
 "$0 $1 available at default location": [
  null,
  "$0 $1 tillgängligt på standardplatsen"
 ],
 "$0 $1 available on host": [
  null,
  "$0 $1 tillgängligt på värden"
 ],
 "$0 CPU details": [
  null,
  "$0 CPU-detaljer"
 ],
 "$0 Network": [
  null,
  "$0 Nätverk",
  "$0 Nätverk"
 ],
 "$0 Storage pool": [
  null,
  "$0 Lagringspool",
  "$0 Lagringspooler"
 ],
 "$0 does not support unattended installation.": [
  null,
  "$0 stöder inte installation utan tillsyn."
 ],
 "$0 memory adjustment": [
  null,
  "$0 minnesjustering"
 ],
 "$0 network": [
  null,
  "$0 Nätverk"
 ],
 "$0 vCPU": [
  null,
  "$0 vCPU",
  "$0 vCPU:er"
 ],
 "$0 virtual network interface settings": [
  null,
  "$0 virtuella nätverksgränssnittsinställningar"
 ],
 "A copy of the VM will run on the destination and will disappear when it is shut off. Meanwhile, the origin host keeps its copy of the VM configuration.": [
  null,
  "En kopia av VM:en kommer köra på destinationen och kommer försvinna när den stängs av. Under tiden behåller ursprungsvärden sitt exemplar av VM-konfigurationen."
 ],
 "Access": [
  null,
  "Åtkomst"
 ],
 "Action": [
  null,
  "Åtgärd"
 ],
 "Actions": [
  null,
  "Åtgärder"
 ],
 "Activate": [
  null,
  "Aktivera"
 ],
 "Activate the storage pool to administer volumes": [
  null,
  "Aktivera lagringspoolen för att administrera volymer"
 ],
 "Add": [
  null,
  "Lägg till"
 ],
 "Add SSH keys": [
  null,
  "Lägg till SSH nycklar"
 ],
 "Add TPM": [
  null,
  "Lägg till TPM"
 ],
 "Add VNC": [
  null,
  "Lägg till VNC"
 ],
 "Add a DHCP static host entry": [
  null,
  "Lägg till en statisk DHCP-värdpost"
 ],
 "Add disk": [
  null,
  "Lägg till disk"
 ],
 "Add host device": [
  null,
  "Lägg till värdenhet"
 ],
 "Add network interface": [
  null,
  "Lägg till nätverksport"
 ],
 "Add serial console": [
  null,
  "Lägg till seriekonsol"
 ],
 "Add shared directory": [
  null,
  "Lägg till delad katalog"
 ],
 "Add virtual network interface": [
  null,
  "Lägg till virtuell nätverksport"
 ],
 "Add vsock interface": [
  null,
  "Lägg til vsock gränssnitt"
 ],
 "Add watchdog device type": [
  null,
  "Lägg till en vakthundsenhetstyp"
 ],
 "Adding a watchdog will require a reboot to take effect.": [
  null,
  "Att lägga till en vakthund kommer att kräva en omstart för att träda i kraft."
 ],
 "Adding shared directories is possible only when the guest is shut off": [
  null,
  "Att lägga till delade kataloger är endast möjligt när gästen är avstängd"
 ],
 "Additional": [
  null,
  "Ytterligare"
 ],
 "Address": [
  null,
  "Adress"
 ],
 "Address not within subnet": [
  null,
  "Adress inte inom subnät"
 ],
 "All": [
  null,
  "Alla"
 ],
 "All VM activity, including storage, will be temporary. This will result in data loss on the destination host.": [
  null,
  "All VM-aktivitet, inklusive lagring, kommer vara tillfällig. Detta kommer resultera i dataförlust på destinationsvärden."
 ],
 "Allowed characters: basic Latin alphabet, numbers, and limited punctuation (-, _, +, .)": [
  null,
  "Tillåtna tecken: grundläggande latinska alfabet, siffror och begränsad skiljetecken (-, _, +, .)"
 ],
 "Also delete all volumes inside this pool:": [
  null,
  "Ta också bort alla volymer i denna pool:"
 ],
 "Always attach": [
  null,
  "Anslut alltid"
 ],
 "An example of vsock-aware software is socat": [
  null,
  "Ett exempel på vsock-medveten programvara är socat"
 ],
 "Apply": [
  null,
  "Lägg på"
 ],
 "Apply on next boot": [
  null,
  "Applicera vid nästa uppstart"
 ],
 "Assign automatically": [
  null,
  "Tilldela automatiskt"
 ],
 "Automated installs are only available when downloading an image or using cloud-init.": [
  null,
  "Automatiserade installationer är endast tillgängliga ner en avbild hämtas eller cloud-init används."
 ],
 "Automatic": [
  null,
  "Automatisk"
 ],
 "Automation": [
  null,
  "Automatisering"
 ],
 "Autostart": [
  null,
  "Starta automatiskt"
 ],
 "Block device": [
  null,
  "Blockenhet"
 ],
 "Blocked": [
  null,
  "Blockerat"
 ],
 "Boot order": [
  null,
  "Uppstartsordning"
 ],
 "Boot order settings could not be saved": [
  null,
  "Uppstartsordningen kunde inte sparas"
 ],
 "Bus": [
  null,
  "Buss"
 ],
 "CD/DVD disc": [
  null,
  "CD/DVD skiva"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "CPU mode could not be saved": [
  null,
  "CPU-läget kunde inte sparas"
 ],
 "Cache": [
  null,
  "Cache"
 ],
 "Cancel": [
  null,
  "Avbryt"
 ],
 "Cannot edit vsock device on a transient VM": [
  null,
  "Kan inte redigera vsock enhet på en transient VM"
 ],
 "Cannot edit watchdog device on a transient VM": [
  null,
  "Kan inte redigera vakthundsenhet på en transient VM"
 ],
 "Capacity": [
  null,
  "Kapacitet"
 ],
 "Change boot order": [
  null,
  "Ändra uppstartsordning"
 ],
 "Change firmware": [
  null,
  "Ändra hårdvarufirmware"
 ],
 "Changes pending": [
  null,
  "Ändringar väntar"
 ],
 "Changes will take effect after shutting down the VM": [
  null,
  "Ändringar kommer verkställas efter att VM:en stängs av"
 ],
 "Changing BIOS/EFI settings is specific to each manufacturer. It involves pressing a hotkey during boot (ESC, F1, F12, Del). Enable a setting called \"virtualization\", \"VM\", \"VMX\", \"SVM\", \"VTX\", \"VTD\". Consult your computer's manual for details.": [
  null,
  "Att ändra BIOS/EFI-inställningarna är specifikt för varje tillverkare. Det innebär att man trycker på en snabbtangent under uppstart (ESC, F1, F12, Del). Aktivera en inställning som heter \"virtualisering\", \"VM\", \"VMX\", \"SVM\", \"VTX\", \"VTD\". Se din dators manual för detaljer."
 ],
 "Checking token validity...": [
  null,
  "Kontrollerar tokens giltighet..."
 ],
 "Choose an operating system": [
  null,
  "Välj ett operativsystem"
 ],
 "Class": [
  null,
  "Klass"
 ],
 "Clicking \"Launch viewer\" will download a $0 file and launch the Remote Viewer application on your system.": [
  null,
  "Om du klickar på \"Starta visningsprogram\" laddas en $0-fil ner och visningsprogrammet startas på ditt system."
 ],
 "Clone": [
  null,
  "Klona"
 ],
 "Close": [
  null,
  "Stäng"
 ],
 "Cloud base image": [
  null,
  "Molnbasavbilder"
 ],
 "Compress": [
  null,
  "Komprimera"
 ],
 "Concurrently writeable": [
  null,
  "Samtidigt skrivbar"
 ],
 "Confirm this action": [
  null,
  "Bekräfta den här åtgärden"
 ],
 "Connect": [
  null,
  "Anslut"
 ],
 "Connection": [
  null,
  "Anslutning"
 ],
 "Console": [
  null,
  "Konsol"
 ],
 "Convert QXL video card to VGA": [
  null,
  "Konvertera QXL grafikkort till VGA"
 ],
 "Convert SPICE graphics console to VNC": [
  null,
  "Konvertera SPICE grafikkonsol till VNC"
 ],
 "Copy storage": [
  null,
  "Kopiera lagring"
 ],
 "Copy to clipboard": [
  null,
  "Kopiera till urklipp"
 ],
 "Cores per socket": [
  null,
  "Kärnor per sockel"
 ],
 "Could not delete $0": [
  null,
  "Det gick inte att radera $0"
 ],
 "Could not delete all storage for $0": [
  null,
  "Det gick inte att radera all lagring för $0"
 ],
 "Could not delete disk's storage": [
  null,
  "Kunde inte ta bort diskens lagring"
 ],
 "Could not dynamically add watchdog": [
  null,
  "Kunde inte lägga till vakthund dynamiskt"
 ],
 "Could not revert to snapshot": [
  null,
  "Kunde inte återgå till ögonblicksbilden"
 ],
 "Crashed": [
  null,
  "Kraschad"
 ],
 "Create": [
  null,
  "Skapa"
 ],
 "Create VM": [
  null,
  "Skapa en VM"
 ],
 "Create VM by importing a disk image of an existing VM installation": [
  null,
  "Skapa en VM genom att importera en diskavbild av en befintlig VM-installation"
 ],
 "Create VM from local or network installation medium": [
  null,
  "Skapa en VM från ett lokalt eller nätverksinstallationsmedium"
 ],
 "Create a clone VM based on $0": [
  null,
  "Skapa en klon-VM baserad på $0"
 ],
 "Create and edit": [
  null,
  "Skapa och redigera"
 ],
 "Create and run": [
  null,
  "Skapa och kör"
 ],
 "Create new": [
  null,
  "Skapa ny"
 ],
 "Create new qcow2 volume": [
  null,
  "Skapa ny qcow2-volym"
 ],
 "Create new raw volume": [
  null,
  "Skapa ny rå volym"
 ],
 "Create new virtual machine": [
  null,
  "Skapa en ny virtuell maskin"
 ],
 "Create snapshot": [
  null,
  "Skapa en ögonblicksbild"
 ],
 "Create storage pool": [
  null,
  "Skapa en lagringspool"
 ],
 "Create storage volume": [
  null,
  "Skapa lagringsvolym"
 ],
 "Create virtual network": [
  null,
  "Skapa virtuellt nätverk"
 ],
 "Create volume": [
  null,
  "Skapa volym"
 ],
 "Creating VM": [
  null,
  "Skapar VM"
 ],
 "Creating VM $0": [
  null,
  "Skapar VM $0"
 ],
 "Creating snapshots of VMs with VFIO devices is not supported while they are running.": [
  null,
  "Att skapa ögonblicksbilder av VM:ar med VFIO-enheter stödjs inte medan de kör."
 ],
 "Creation of VM $0 failed": [
  null,
  "Misslyckades att skapa VM $0"
 ],
 "Creation time": [
  null,
  "Skapandetidpunkt"
 ],
 "Ctrl+Alt+$0": [
  null,
  "Ctrl+Alt+$0"
 ],
 "Current": [
  null,
  "Nuvarande"
 ],
 "Current allocation": [
  null,
  "Nuvarande indelning"
 ],
 "Custom firmware: $0": [
  null,
  "Eget hårdvaruprogram: $0"
 ],
 "Custom identifier": [
  null,
  "Anpassad identifierare"
 ],
 "Custom path": [
  null,
  "Anpassad sökväg"
 ],
 "DHCP Settings": [
  null,
  "DHCP Inställningar"
 ],
 "Deactivate": [
  null,
  "Avaktivera"
 ],
 "Delete": [
  null,
  "Ta bort"
 ],
 "Delete $0 VM?": [
  null,
  "Ta bort VM $0?"
 ],
 "Delete $0 storage pool?": [
  null,
  "Ta bort lagringspoolen $0?"
 ],
 "Delete $0 volume": [
  null,
  "Ta bort volymen $0",
  "Ta bort volymerna $0"
 ],
 "Delete associated storage files:": [
  null,
  "Ta bort assoicierade lagringsfiler:"
 ],
 "Delete network?": [
  null,
  "Ta bort nätverket?"
 ],
 "Delete snapshot?": [
  null,
  "Ta bort ögonblicksbild?"
 ],
 "Deleting an inactive storage pool will only undefine the pool. Its content will not be deleted.": [
  null,
  "Att ta bort en inaktiv lagringspool kommer bara att odefiniera poolen. Dess innehåll kommer inte att raderas."
 ],
 "Deleting shared directories is possible only when the guest is shut off": [
  null,
  "Att ta bort delade kataloger är endast möjligt när gästen är avstängd"
 ],
 "Description": [
  null,
  "Beskrivning"
 ],
 "Deselect others": [
  null,
  "Avmarkera andra"
 ],
 "Destination URI": [
  null,
  "Destinations-URI"
 ],
 "Destination URI must not be empty": [
  null,
  "Destinations-URI kan inte vara tom"
 ],
 "Detach the disks using this pool from any VMs before attempting deletion.": [
  null,
  "Koppla bort diskarna från VM:er som använder denna pool innan du försöker ta bort poolen."
 ],
 "Details": [
  null,
  "Detaljer"
 ],
 "Device": [
  null,
  "Enhet"
 ],
 "Devices": [
  null,
  "Enheter"
 ],
 "Disconnect": [
  null,
  "Koppla ifrån"
 ],
 "Disconnected": [
  null,
  "Frånkopplad"
 ],
 "Disconnected from serial console. Click the connect button.": [
  null,
  "Frånkopplad från seriekonsolen. Klicka på Anslut."
 ],
 "Disk": [
  null,
  "Disk"
 ],
 "Disk $0 could not be removed": [
  null,
  "Disk $0 kunde inte tas bort"
 ],
 "Disk failed to be added": [
  null,
  "Disken misslyckades då den skulle läggas till"
 ],
 "Disk identifier": [
  null,
  "Diskidentifierare"
 ],
 "Disk image": [
  null,
  "Diskavbild"
 ],
 "Disk image file": [
  null,
  "Diskavbilds fil"
 ],
 "Disk image path must not be empty": [
  null,
  "Diskavbildningssökväg får inte vara tom"
 ],
 "Disk images can be stored in user home directory": [
  null,
  "Diskavbildningar kan lagras i användarens hemkatalog"
 ],
 "Disk settings could not be saved": [
  null,
  "Inställningarna för disken kunde inte sparas"
 ],
 "Disk-only snapshot": [
  null,
  "Endast diskögonblicksbild"
 ],
 "Disks": [
  null,
  "Diskar"
 ],
 "Do not run this VM on the origin and destination hosts at the same time.": [
  null,
  "Kör inte denna VM på ursprungs- och destinationsvärdarna samtidigt."
 ],
 "Do nothing": [
  null,
  "Gör ingenting"
 ],
 "Domain has crashed": [
  null,
  "Domänen har kraschat"
 ],
 "Domain is blocked on resource": [
  null,
  "Domänen är blockerad av en resurs"
 ],
 "Download an OS": [
  null,
  "Ladda ner ett OS"
 ],
 "Download progress": [
  null,
  "Hämtningsförlopp"
 ],
 "Download the MSI from $0": [
  null,
  "Ladda ner MSI från $0"
 ],
 "Downloading image for VM $0": [
  null,
  "Hämtar avbilden för VM $0"
 ],
 "Downloading: $0%": [
  null,
  "Hämtar: $0 %"
 ],
 "Dump core": [
  null,
  "Dumpa minnet"
 ],
 "Duration": [
  null,
  "Varaktighet"
 ],
 "Dying": [
  null,
  "Döende"
 ],
 "Edit": [
  null,
  "Redigera"
 ],
 "Edit $0 attributes": [
  null,
  "Redigera $0 attribut"
 ],
 "Edit VNC settings": [
  null,
  "Redigera VNC Inställningar"
 ],
 "Edit description": [
  null,
  "Redigera beskrivning"
 ],
 "Edit description of VM $0": [
  null,
  "Redigera beskrivning av VM $0"
 ],
 "Edit vsock interface": [
  null,
  "Redigera vsock gränssnitt"
 ],
 "Edit watchdog device type": [
  null,
  "Redigera vakthundsenhetstypen"
 ],
 "Editing network interfaces of transient guests is not allowed": [
  null,
  "Att redigera nätverksgränssnitt för transienta gäster är inte tillåtet"
 ],
 "Editing transient network interfaces is not allowed": [
  null,
  "Att redigera transienta nätverksgränssnit är inte tillåtet"
 ],
 "Eject": [
  null,
  "Mata ut"
 ],
 "Eject disc from VM?": [
  null,
  "Ta bort disk från VM?"
 ],
 "Emulated machine": [
  null,
  "Emulerad maskin"
 ],
 "Enable virtualization support in BIOS/EFI settings.": [
  null,
  "Aktivera virtualiseringsstöd i BIOS/EFI-inställningar."
 ],
 "End": [
  null,
  "Slut"
 ],
 "End should not be empty": [
  null,
  "Slutet kan inte vara tomt"
 ],
 "Enter root and/or user information to enable unattended installation.": [
  null,
  "Ange root och/eller användarinformation för att möjliggöra obevakad installation."
 ],
 "Error checking token": [
  null,
  "Fel vid kontroll av token"
 ],
 "Example, $0": [
  null,
  "Exempel, $0"
 ],
 "Existing disk image on host's file system": [
  null,
  "En annan disk på den här datorns filsystem"
 ],
 "Expand": [
  null,
  "Expandera"
 ],
 "Extended attributes": [
  null,
  "Utökade attribut"
 ],
 "Failed": [
  null,
  "Misslyckades"
 ],
 "Failed to add TPM to VM $0": [
  null,
  "Misslyckades att lägga till TPM för VM $0"
 ],
 "Failed to add VNC to VM $0": [
  null,
  "Misslyckades med att lägga till VNC till VM $0"
 ],
 "Failed to add serial console to VM $0": [
  null,
  "Misslyckades med att lägga till seriekonsol till den virtuella maskinen $0"
 ],
 "Failed to add shared directory": [
  null,
  "Misslyckades att lägga till delad katalog"
 ],
 "Failed to change firmware": [
  null,
  "Misslyckades att ändra hårdvaruprogram"
 ],
 "Failed to clone VM $0": [
  null,
  "Misslyckades att klona VM $0"
 ],
 "Failed to configure vsock": [
  null,
  "Misslyckades att konfigurera vsock"
 ],
 "Failed to configure watchdog": [
  null,
  "Misslyckades att konfigurera watchdog"
 ],
 "Failed to detach vsock": [
  null,
  "Misslyckades att koppla ifrån vsock"
 ],
 "Failed to detach watchdog": [
  null,
  "Misslyckades att koppla ifrån vakthunden"
 ],
 "Failed to fetch some resources": [
  null,
  "Misslyckades att hämta några resurser"
 ],
 "Failed to fetch the IP addresses of the interfaces present in $0": [
  null,
  "Kunde inte hämta IP-adresser från portar i $0"
 ],
 "Failed to rename VM $0": [
  null,
  "Misslyckades att byta namn på VM $0"
 ],
 "Failed to replace SPICE devices": [
  null,
  "Misslyckades att ersätta SPICE-enheter"
 ],
 "Failed to save network settings": [
  null,
  "Misslyckades att spara nätverksinställningar"
 ],
 "Failed to send key Ctrl+Alt+$0 to VM $1": [
  null,
  "Kunde inte skicka Ctrl+Alt+$0 till VM $1"
 ],
 "Failed to set description of VM $0": [
  null,
  "Misslyckades med att spara en beskrivning för VM $0"
 ],
 "Fewer than the maximum number of virtual CPUs should be enabled.": [
  null,
  "Färre än det maximala antalet virtuella CPU:er skall vara aktiverade."
 ],
 "File": [
  null,
  "Arkiv"
 ],
 "Filesystem $0 could not be removed": [
  null,
  "Filsystem $0 kunde inte raderas"
 ],
 "Filesystem directory": [
  null,
  "Filsystemskatalog"
 ],
 "Filter by name": [
  null,
  "Filtrera efter namn"
 ],
 "Firmware": [
  null,
  "Hårdvaruprogram"
 ],
 "Force eject": [
  null,
  "Tvinga utmatning"
 ],
 "Force reboot": [
  null,
  "Tvinga omstart"
 ],
 "Force reboot $0?": [
  null,
  "Tvinga omstart $0?"
 ],
 "Force revert": [
  null,
  "Framtvinga återställning"
 ],
 "Force shut down": [
  null,
  "Framtvinga avstängning"
 ],
 "Force shut down $0?": [
  null,
  "Framtvinga avstängning $0?"
 ],
 "Format": [
  null,
  "Formater"
 ],
 "Forward mode": [
  null,
  "Vidarebefordransläge"
 ],
 "Forwarding mode": [
  null,
  "Vidarebefordransläge"
 ],
 "Full disk images and the domain's memory will be migrated. Only non-shared, writable disk images will be transferred. Unused storage will remain on the origin after migration.": [
  null,
  "Hela diskbilder och domänens minne kommer att migreras. Endast icke-delade, skrivbara diskbilder kommer att överföras. Oanvänd lagring kommer att finnas kvar på ursprunget efter migreringen."
 ],
 "General": [
  null,
  "Allmänt"
 ],
 "Generate automatically": [
  null,
  "Skapa automatiskt"
 ],
 "Get a new RHSM token.": [
  null,
  "Hämta ett nytt RHSM-bevis (token)."
 ],
 "GiB": [
  null,
  "GiB"
 ],
 "Go to VMs list": [
  null,
  "Gå till VM-listan"
 ],
 "Good choice for desktop virtualization": [
  null,
  "Bra val för skrivbordsvirtualisering"
 ],
 "Gracefully shutdown": [
  null,
  "Graciös avstängning"
 ],
 "Graphical": [
  null,
  "Grafisk"
 ],
 "Graphical console support not enabled": [
  null,
  "Stöd för grafisk konsol är inte aktiverat"
 ],
 "Hardware virtualization is disabled": [
  null,
  "Hårdvaruvirtualisering är inaktiverad"
 ],
 "Hide additional options": [
  null,
  "Göm ytterligare inställningar"
 ],
 "Host": [
  null,
  "Värd"
 ],
 "Host device": [
  null,
  "Värdenhet"
 ],
 "Host device could not be attached": [
  null,
  "Värdenheten kunde inte anslutas"
 ],
 "Host device will be removed from $0:": [
  null,
  "Värdenheter kommer tas bort från $0:"
 ],
 "Host devices": [
  null,
  "Värdenheter"
 ],
 "Host name": [
  null,
  "Värdnamn"
 ],
 "Host should not be empty": [
  null,
  "Värden får inte vara tom"
 ],
 "Hypervisor details": [
  null,
  "Detaljer om hypervisorn"
 ],
 "ID": [
  null,
  "ID"
 ],
 "IP": [
  null,
  "IP"
 ],
 "IP address": [
  null,
  "IP-adress"
 ],
 "IP address must not be empty": [
  null,
  "IP address kan inte vara tomt"
 ],
 "IP configuration": [
  null,
  "IP-konfiguration"
 ],
 "IPv4 address": [
  null,
  "IPv4-adress"
 ],
 "IPv4 address cannot be same as the network's broadcast address": [
  null,
  "IPv4-adressen kan inte vara densamma som nätverkets broadcast-adress"
 ],
 "IPv4 and IPv6": [
  null,
  "IPv4 och IPv6"
 ],
 "IPv4 network should not be empty": [
  null,
  "IPv4 nätverk kan inte vara tom"
 ],
 "IPv4 only": [
  null,
  "IPv4 enbart"
 ],
 "IPv4 prefix length must be 24 or less": [
  null,
  "IPv4-prefixlängden måste vara 24 eller mindre"
 ],
 "IPv4 prefix length must be a multiple of 8": [
  null,
  "IPv4-prefixlängden måste vara en multipel av 8"
 ],
 "IPv6 address": [
  null,
  "IPv6-adress"
 ],
 "IPv6 network should not be empty": [
  null,
  "IPv6 nätverk kan inte vara tom"
 ],
 "IPv6 only": [
  null,
  "IPv6 enbart"
 ],
 "Ideal for server VMs": [
  null,
  "Idealis för server-VM:ar"
 ],
 "Ideal networking support": [
  null,
  "Idealisk för nätversstöd"
 ],
 "Identifier in use by $0. VMs with an identical identifier cannot run at the same time.": [
  null,
  "Identifierare som används av $0. VMs med en identisk identifierare kan inte köras samtidigt."
 ],
 "Identifier may be silently truncated to $0 characters ": [
  null,
  "Identifierare kan tyst avkortas till $0 tecken "
 ],
 "Idle": [
  null,
  "Overksam"
 ],
 "Ignore": [
  null,
  "Ignorera"
 ],
 "Import VM": [
  null,
  "Importera VM"
 ],
 "Import a virtual machine": [
  null,
  "Importera en virtuell maskin"
 ],
 "Import and edit": [
  null,
  "Importera och redigera"
 ],
 "Import and run": [
  null,
  "Importera och kör"
 ],
 "Importing an image with a backing file is unsupported": [
  null,
  "Import av en avbild med en bakomliggande fil stödjs inte"
 ],
 "In most configurations, macvtap does not work for host to guest network communication.": [
  null,
  "I de flesta fall kan man inte använda macvtap för att kommunicera mellan host och VM."
 ],
 "Initiator": [
  null,
  "Initierare"
 ],
 "Initiator should not be empty": [
  null,
  "Initieraren skall inte vara tom"
 ],
 "Inject a non-maskable interrupt": [
  null,
  "Injicera ett ej maskerbart avbrott"
 ],
 "Insert": [
  null,
  "Insert"
 ],
 "Insert disc media": [
  null,
  "Sätt i skivmedia"
 ],
 "Inside the VM": [
  null,
  "Inuti VM"
 ],
 "Install": [
  null,
  "Installera"
 ],
 "Installation source": [
  null,
  "Installationskälla"
 ],
 "Installation source must not be empty": [
  null,
  "Installationskällan kan inte vara tom"
 ],
 "Installation type": [
  null,
  "Installationstyp"
 ],
 "Interface": [
  null,
  "Gränssnitt"
 ],
 "Interface type": [
  null,
  "Gränssnittstyp"
 ],
 "Interface type help": [
  null,
  "Gränssnittstyp hjälp"
 ],
 "Invalid IPv4 address": [
  null,
  "Felaktig IPv4-adress"
 ],
 "Invalid IPv4 mask or prefix length": [
  null,
  "Felaktig IPv4 nätverksmask eller prefix"
 ],
 "Invalid IPv6 address": [
  null,
  "Felaktig IPv6-adress"
 ],
 "Invalid IPv6 prefix": [
  null,
  "Felaktigt IPv6-prefix"
 ],
 "Invalid filename": [
  null,
  "Felaktigt filnamn"
 ],
 "Isolated network": [
  null,
  "Isolerat nätverk"
 ],
 "It can also be used to enable the inline graphical console in the browser, which does not support SPICE.": [
  null,
  "Den kan också användas för att aktivera den inbyggda grafiska konsolen i webbläsaren, som inte stöder SPICE."
 ],
 "Keys are located in ~/.ssh/ and have a \".pub\" extension.": [
  null,
  "Nycklar finns i ~/.ssh/ och har filtillägget \".pub\"."
 ],
 "LVM volume group": [
  null,
  "LVM Volymgrupp"
 ],
 "Launch viewer": [
  null,
  "Starta visare"
 ],
 "Leave the password blank if you do not wish to have a root account created": [
  null,
  "Lämna lösenordet tomt om du inte vill skapa en superanvändare"
 ],
 "Leave the password blank if you do not wish to have a user account created": [
  null,
  "Lämna lösenordet tomt om du inte vill skapa en användare"
 ],
 "Leave the password blank if you do not wish to set a root password": [
  null,
  "Lämna lösenordet tomt om du inte vill skapa en rootanvändare"
 ],
 "Libvirt did not detect any UEFI/OVMF firmware image installed on the host": [
  null,
  "Libvirt hittade inte något UEFI/OVMF hårdvaruprogram installerat på värden"
 ],
 "Libvirt or hypervisor does not support UEFI": [
  null,
  "Libvirt eller hypervisor stödjer inte UEFI"
 ],
 "Loading available network devices": [
  null,
  "Laddar tillgängliga nätverksenheter"
 ],
 "Loading resources": [
  null,
  "Laddar resurser"
 ],
 "Loading...": [
  null,
  "Läser in …"
 ],
 "Local install media (ISO image or distro install tree)": [
  null,
  "Lokalt installationsmedia (ISO avbild eller distro installationsträd)"
 ],
 "Location": [
  null,
  "Plats"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "MAC address": [
  null,
  "MAC-adress"
 ],
 "MAC address already in use": [
  null,
  "MAC-adress används redan"
 ],
 "MAC address must not be empty": [
  null,
  "MAC-adress kan inte vara tomt"
 ],
 "Machine must be shut off before changing bus type": [
  null,
  "Maskinen måste vara avstängd innan det går att ändra busstyp"
 ],
 "Machine must be shut off before changing cache mode": [
  null,
  "Maskinen måste vara avstängd innan det går att ändra cacheläge"
 ],
 "Mask or prefix length": [
  null,
  "Mask eller prefixlängd"
 ],
 "Mask or prefix length should not be empty": [
  null,
  "Mask eller prefixlängd kan inte vara tom"
 ],
 "Maximum allocation": [
  null,
  "Maximal tilldelning"
 ],
 "Maximum memory could not be saved": [
  null,
  "Maximalt minne kunde inte sparas"
 ],
 "Maximum number of virtual CPUs allocated for the guest OS": [
  null,
  "Maximalt antal virtuella CPU:er allokerade till gäst-OS:et"
 ],
 "Maximum number of virtual CPUs allocated for the guest OS, which must be between 1 and $0": [
  null,
  "Maximalt antal virtuella CPU:er allokerade till gäst-OS:et, vilket måste vara mellan 1 och $0"
 ],
 "Maximum transmission unit": [
  null,
  "Maximal överföringsstorlek"
 ],
 "Media could not be ejected from $0": [
  null,
  "Media kunde inte matas ut från $0"
 ],
 "Media will be ejected from $0:": [
  null,
  "Media kommer att matas ut från $0:"
 ],
 "Memory": [
  null,
  "Minne"
 ],
 "Memory could not be saved": [
  null,
  "Minnet kunde inte sparas"
 ],
 "Memory must not be 0": [
  null,
  "Minne kan inte vara 0"
 ],
 "Memory save location can not be empty": [
  null,
  "Minnessparplatsen kan inte vara tom"
 ],
 "Memory snapshot will use about $0.": [
  null,
  "Minnesögonblicksbild kommer att använda ungefär $0."
 ],
 "Memory state path": [
  null,
  "Minnesstatussökväg"
 ],
 "MiB": [
  null,
  "MiB"
 ],
 "Migrate": [
  null,
  "Migrera"
 ],
 "Migrate VM to another host": [
  null,
  "Migrera VM till en annan värd"
 ],
 "Migration failed": [
  null,
  "Migreringen misslyckades"
 ],
 "Mode": [
  null,
  "Läge"
 ],
 "Mode help": [
  null,
  "Lägeshjälp"
 ],
 "Model": [
  null,
  "Modell"
 ],
 "Model type": [
  null,
  "Modelltyp"
 ],
 "More info": [
  null,
  "Mer information"
 ],
 "Mount tag": [
  null,
  "Monteringstagg"
 ],
 "Mount tag must not be empty": [
  null,
  "Monteringstaggen får inte vara tom"
 ],
 "Must be an address instead of the network identifier, such as $0": [
  null,
  "Måste vara en adress istället för nätverksidentifieraren, till exempel $0"
 ],
 "NAT to $0": [
  null,
  "NAT till $0"
 ],
 "NIC $0 of VM $1 failed to change state": [
  null,
  "NIC $0 på VM $1 kunde inte ändra läge"
 ],
 "Name": [
  null,
  "Namn"
 ],
 "Name already exists": [
  null,
  "Namnet finns redan"
 ],
 "Name can not be empty": [
  null,
  "Namnet får inte vara tomt"
 ],
 "Name contains invalid characters": [
  null,
  "Namnet innehåller ogiltiga tecken"
 ],
 "Name must not be empty": [
  null,
  "Namnet kan inte vara tomt"
 ],
 "Name should not be empty": [
  null,
  "Namnet får inte vara tomt"
 ],
 "Name: ": [
  null,
  "Namn: "
 ],
 "Netmask": [
  null,
  "Nätmask"
 ],
 "Network $0 could not be deleted": [
  null,
  "Nätverk $0 kunde inte raderas"
 ],
 "Network $0 failed to get activated": [
  null,
  "Kunde inte starta nätverk $0"
 ],
 "Network $0 failed to get deactivated": [
  null,
  "Kunde inte stoppa nätverk $0"
 ],
 "Network $0 will be permanently deleted.": [
  null,
  "Nätverk $0 kommer att raderas permanent."
 ],
 "Network boot (PXE)": [
  null,
  "Nätverksboot (PXE)"
 ],
 "Network file system": [
  null,
  "Nätverksfilsystem"
 ],
 "Network interface": [
  null,
  "Nätverksgränssnitt"
 ],
 "Network interface $0 could not be removed": [
  null,
  "Nätverksgränssnitt $0 kunde inte tas bort"
 ],
 "Network interface $0 will be removed from $1": [
  null,
  "Nätverksgränssnitt $0 kommer tas bort från $1"
 ],
 "Network interface settings could not be saved": [
  null,
  "Inställningar för nätverksgränssnitt kunde inte sparas"
 ],
 "Network interfaces": [
  null,
  "Nätverksgränssnitt"
 ],
 "Network selection does not support PXE.": [
  null,
  "Nätverksvalet tillåter inte PXE."
 ],
 "Networks": [
  null,
  "Nätverk"
 ],
 "New name": [
  null,
  "Nytt namn"
 ],
 "New name must not be empty": [
  null,
  "Namnet får inte vara tomt"
 ],
 "New volume name": [
  null,
  "Nytt volymnamn"
 ],
 "No SSH keys specified": [
  null,
  "Inga SSH-nycklar specificerade"
 ],
 "No VM is running or defined on this host": [
  null,
  "Ingen VM kör eller är definierad på denna värd"
 ],
 "No boot device found": [
  null,
  "Ingen startenhet hittades"
 ],
 "No description": [
  null,
  "Ingen beskrivning"
 ],
 "No directories shared between the host and this VM": [
  null,
  "Inga kataloger delade mellan värden och denna VM"
 ],
 "No disks defined for this VM": [
  null,
  "Inga diskar är definerade för denna VM"
 ],
 "No host device selected": [
  null,
  "Ingen värdenhet vald"
 ],
 "No host devices assigned to this VM": [
  null,
  "Inga värd enheter är definerade för denna VM"
 ],
 "No network devices": [
  null,
  "Inga nätverksenheter"
 ],
 "No network interfaces defined for this VM": [
  null,
  "Inga nätverksgränssnitt är definierade för denna VM"
 ],
 "No network is defined on this host": [
  null,
  "Inget nätverk är definierat på den här värden"
 ],
 "No networks available": [
  null,
  "Inga nätverk tillgängliga"
 ],
 "No parent": [
  null,
  "Ingen förälder"
 ],
 "No snapshots defined for this VM": [
  null,
  "Inga ögonblicksbilder har definierats för denna VM"
 ],
 "No state": [
  null,
  "Inget tillstånd"
 ],
 "No storage": [
  null,
  "Ingen lagring"
 ],
 "No storage pool is defined on this host": [
  null,
  "Ingen lagringspool är definierad på denna värd"
 ],
 "No storage pools available": [
  null,
  "Inga lagringspooler tillgängliga"
 ],
 "No storage volumes defined for this storage pool": [
  null,
  "Inga lagringsvolymer är definierade för denna lagringspool"
 ],
 "No virtual networks": [
  null,
  "Inga virtuella nätverk"
 ],
 "No volumes exist in this storage pool.": [
  null,
  "Inga volymer finns i denna lagringspool."
 ],
 "Non-persistent network cannot be deleted. It ceases to exists when it's deactivated.": [
  null,
  "Icke varaktiga nätverk kan inte raderas. Det slutar att finnas när det deaktiveras."
 ],
 "Non-persistent storage pool cannot be deleted. It ceases to exists when it's deactivated.": [
  null,
  "Icke varaktig lagringspool kan inte raderas. Den slutar att finnas när den deaktiveras."
 ],
 "None": [
  null,
  "Inga"
 ],
 "None (isolated network)": [
  null,
  "Ingen (isolerat nätverk)"
 ],
 "Offline token": [
  null,
  "Bevis frånkopplad"
 ],
 "Offline token must not be empty": [
  null,
  "Offlinetoken får inte vara tom"
 ],
 "Old token expired": [
  null,
  "Gammal token har gått ut"
 ],
 "On the host": [
  null,
  "På värden"
 ],
 "One or more selected volumes are used by domains. Detach the disks first to allow volume deletion.": [
  null,
  "En eller flera valda volymer används av domäner. Koppla loss diskarna först för att tillåta radering av volymer."
 ],
 "Only editable when the guest is shut off": [
  null,
  "Kan endast redigeras när gästen är avstängd"
 ],
 "Open": [
  null,
  "Öppna"
 ],
 "Operating system": [
  null,
  "Operativsystem"
 ],
 "Operation is in progress": [
  null,
  "Operation pågår"
 ],
 "Other VMs using SPICE": [
  null,
  "Andra VMs använder SPICE"
 ],
 "Overview": [
  null,
  "Översikt"
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "Parent snapshot": [
  null,
  "Föräldraögonblicksbild"
 ],
 "Password": [
  null,
  "Lösenord"
 ],
 "Password must be 8 characters or less. VNC passwords do not provide encryption and are generally cryptographically weak. They can not be used to secure connections in untrusted networks.": [
  null,
  "Lösenordet måste vara högst 8 tecken långt. VNC-lösenord erbjuder inte kryptering och är generellt kryptografiskt svaga. De kan inte användas för att säkra anslutningar i opålitliga nätverk."
 ],
 "Password must be at most 8 characters.": [
  null,
  "Lösenordet får vara högst 8 tecken långt."
 ],
 "Path": [
  null,
  "Sökväg"
 ],
 "Path on host's filesystem": [
  null,
  "Sökväg på värdens filsystem"
 ],
 "Path to ISO file on host's file system": [
  null,
  "Sökväg till ISO-fil på värdens filsystem"
 ],
 "Path to cloud image file on host's file system": [
  null,
  "Sökväg till molnavbildsfilen värdens filsystem"
 ],
 "Path to directory": [
  null,
  "Sökväg till katalog"
 ],
 "Path to file on host's file system": [
  null,
  "Sökväg till fil på värdens filsystem"
 ],
 "Pause": [
  null,
  "Pausa"
 ],
 "Paused": [
  null,
  "Pausad"
 ],
 "Permanent (default)": [
  null,
  "Permanent (standard)"
 ],
 "Permissions denied for disk images in home directories": [
  null,
  "Behörigheter nekades för diskavbildningar i hemkataloger"
 ],
 "Persistence": [
  null,
  "Varaktighet"
 ],
 "Persistent": [
  null,
  "Varaktig"
 ],
 "Physical disk device": [
  null,
  "Fysisk diskenhet"
 ],
 "Physical disk device on host": [
  null,
  "Fysisk diskenhet på värd"
 ],
 "Please choose a different MAC address": [
  null,
  "Vänligen välj en annan MAC-adress"
 ],
 "Please choose a storage pool": [
  null,
  "Välj en lagringspool"
 ],
 "Please choose a volume": [
  null,
  "Välj en volym"
 ],
 "Please enter new volume name": [
  null,
  "Ange ett nytt volymnamn"
 ],
 "Please see $0 how to reconfigure your VM manually.": [
  null,
  "Se $0 hur du konfigurerar om din VM manuellt."
 ],
 "Pool": [
  null,
  "Pool"
 ],
 "Pool needs to be active to create volume": [
  null,
  "Poolen måste vara aktiv för att skapa volym"
 ],
 "Pool type $0 does not support volume creation": [
  null,
  "Pooltyp $0 stödjer inte att skapa volymer"
 ],
 "Pool type doesn't support volume creation": [
  null,
  "Pooltyp stödjer inte att skapa volymer"
 ],
 "Pool's volumes are used by VMs ": [
  null,
  "Poolens volymer används av VM:ar "
 ],
 "Port": [
  null,
  "Port"
 ],
 "Port must be 5900 or larger.": [
  null,
  "Port måste vara 5900 eller större."
 ],
 "Port must be a number that is at least 5900. Leave empty to automatically assign a free port when the machine starts.": [
  null,
  "Port måste vara ett tal som är minst 5900. Lämna tomt för att automatiskt tilldela en ledig port när maskinen startar."
 ],
 "Port must be a number.": [
  null,
  "Port måste vara ett nummer."
 ],
 "Power off": [
  null,
  "Stäng av"
 ],
 "Pre-formatted block device": [
  null,
  "För-formaterad blockenhet"
 ],
 "Preferred number of sockets to expose to the guest.": [
  null,
  "Föredraget antal uttag att exponera för gästen."
 ],
 "Prefix": [
  null,
  "Prefix"
 ],
 "Prefix length": [
  null,
  "Prefixlängd"
 ],
 "Prefix length should not be empty": [
  null,
  "Prefixlängden ska inte vara tom"
 ],
 "Previously taken snapshots allow you to revert to an earlier state if something goes wrong": [
  null,
  "Med tidigare tagna ögonblicksbilder kan du återgå till ett tidigare läge om något går fel"
 ],
 "Private": [
  null,
  "Privat"
 ],
 "Product": [
  null,
  "Produkt"
 ],
 "Profile": [
  null,
  "Profil"
 ],
 "Protocol": [
  null,
  "Protokoll"
 ],
 "Provides a bridge from the guest virtual machine directly onto the LAN. This needs a bridge device on the host with one or more physical NICs.": [
  null,
  "Tillhandahåller en brygga från den virtuella gästmaskinen direkt till LAN:et. Detta kräver en bryggenhet på hävrden med en eller flera fysiska NIC:er."
 ],
 "Provides a connection whose details are described by the named network definition.": [
  null,
  "Tillhandahåller en anslutning vars detaljer beskrivs av den namngivna nätverksdefinitionen."
 ],
 "Provides a virtual LAN with NAT to the outside world.": [
  null,
  "Tillhandahåller ett virtuellt LAN med NAT till omvärlden."
 ],
 "Public SSH key": [
  null,
  "Publik SSH nyckel"
 ],
 "Public key": [
  null,
  "Publik nyckel"
 ],
 "Range": [
  null,
  "Räckvidd"
 ],
 "Read-only": [
  null,
  "Skrivskyddad"
 ],
 "Reboot": [
  null,
  "Starta om"
 ],
 "Reboot $0?": [
  null,
  "Starta om $0?"
 ],
 "Recommended operating systems": [
  null,
  "Rekommenderade operativsystem"
 ],
 "Released $0": [
  null,
  "Släppt $0"
 ],
 "Remote URL": [
  null,
  "Fjärr-URL"
 ],
 "Remote Viewer is available for most operating systems. To install it, search for \"Remote Viewer\" in GNOME Software, KDE Discover, or run the following:": [
  null,
  "Fjärrvisningsprogram är tillgängligt för de flesta operativsystem. För att installera det, sök efter \"Fjärrvisningsprogram\" i GNOME-programvara, KDE Discover eller kör följande:"
 ],
 "Remote viewer": [
  null,
  "Fjärrvisare"
 ],
 "Remote viewer applications can connect to the following address:": [
  null,
  "Fjärrvisningsprogram kan ansluta till följande adress:"
 ],
 "Remove": [
  null,
  "Avlägsna"
 ],
 "Remove SPICE audio and host devices": [
  null,
  "Ta bort SPICE-ljud- och värdenheter"
 ],
 "Remove and delete file": [
  null,
  "Ta bort och radera fil"
 ],
 "Remove disk from VM?": [
  null,
  "Ta bort en disk från VM:en?"
 ],
 "Remove filesystem?": [
  null,
  "Ta bort filsysteme?"
 ],
 "Remove host device from VM?": [
  null,
  "Ta bort värdenhet från VM:en?"
 ],
 "Remove item": [
  null,
  "Ta bort objekt"
 ],
 "Remove network interface?": [
  null,
  "Ta bort nätverksgränssnittet?"
 ],
 "Remove static host from DHCP": [
  null,
  "Ta bort statiska värdposter från DHCP"
 ],
 "Rename": [
  null,
  "Byt namn"
 ],
 "Rename VM $0": [
  null,
  "Byt namn på VM $0"
 ],
 "Replace": [
  null,
  "Ersätt"
 ],
 "Replace SPICE devices": [
  null,
  "Ersätt SPICE enheter"
 ],
 "Replace SPICE devices in VM $0": [
  null,
  "Ersätt SPICE enheter i VM $0"
 ],
 "Replace SPICE on selected VMs.": [
  null,
  "Ersätt SPICE på valda VMs."
 ],
 "Replace SPICE on the virtual machine.": [
  null,
  "Ersätt SPICE på den virtuella maskinen."
 ],
 "Replace with VNC": [
  null,
  "Ersätt med VNC"
 ],
 "Reset": [
  null,
  "Återställ"
 ],
 "Restart this virtual machine to access its graphical console": [
  null,
  "Starta om den här virtuella maskinen för att komma åt dess grafiska konsol"
 ],
 "Restart this virtual machine to access its serial console": [
  null,
  "Starta om den här virtuella maskinen för att komma åt dess seriekonsol"
 ],
 "Restrictions in networking (SLIRP-based emulation) and PCI device assignment": [
  null,
  "Begränsningar i nätverkande (SLIRP-baserad emulering) och PCI-enhetstilldelning"
 ],
 "Resume": [
  null,
  "Återuppta"
 ],
 "Revert": [
  null,
  "Återställ"
 ],
 "Revert to snapshot $0": [
  null,
  "Återgå till ögonblicksbild $0"
 ],
 "Reverting to this snapshot will take the VM back to the time of the snapshot and the current state will be lost, along with any data not captured in a snapshot": [
  null,
  "Om du återgår till den här ögonblicksbilden kommer den virtuella datorn att återgå till tiden för ögonblicksbilden och det aktuella tillståndet kommer att gå förlorat, tillsammans med all data som inte fångats i en ögonblicksbild"
 ],
 "Root password": [
  null,
  "Root-lösenord"
 ],
 "Route to $0": [
  null,
  "Rutt till $0"
 ],
 "Routed network": [
  null,
  "Ruttlagt nätverk"
 ],
 "Row select": [
  null,
  "Radval"
 ],
 "Run": [
  null,
  "Kör"
 ],
 "Run when host boots": [
  null,
  "Kör när värd startar"
 ],
 "Running": [
  null,
  "Kör"
 ],
 "SPICE": [
  null,
  "SPICE"
 ],
 "SPICE conversion": [
  null,
  "SPICE konvertering"
 ],
 "SPICE is not supported on this host and will cause this virtual machine to not boot.": [
  null,
  "SPICE stöds inte på denna värd och kommer att göra att den här virtuella maskinen inte startar."
 ],
 "SSH keys": [
  null,
  "SSH-nycklar"
 ],
 "Save": [
  null,
  "Spara"
 ],
 "Select all": [
  null,
  "Välj alla"
 ],
 "Send key": [
  null,
  "Skicka tangenttryck"
 ],
 "Send non-maskable interrupt": [
  null,
  "Skicka ej maskerbart avbrott"
 ],
 "Send non-maskable interrupt to $0?": [
  null,
  "Skicka ej maskerbart avbrott till $0?"
 ],
 "Serial": [
  null,
  "Seriell"
 ],
 "Serial ($0)": [
  null,
  "Seriell ($0)"
 ],
 "Serial console": [
  null,
  "Seriekonsol"
 ],
 "Serial console support not enabled": [
  null,
  "Stöd för seriell konsol är inte aktiverat"
 ],
 "Set DHCP range": [
  null,
  "Ställ in DHCP-intervall"
 ],
 "Set manually": [
  null,
  "Ställ in manuellt"
 ],
 "Setting the user passwords for unattended installation requires starting the VM when creating it": [
  null,
  "Att sätta användarlösenordet för oövervakad installation kräver att man startar VM:en när den skapas"
 ],
 "Share": [
  null,
  "Dela"
 ],
 "Share a host directory with the guest": [
  null,
  "Dela en värdkatalog med gäst"
 ],
 "Shared directories": [
  null,
  "Delade kataloger"
 ],
 "Shared host directories need to be manually mounted inside the VM": [
  null,
  "Delade värdkataloger behöver monteras manuellt inuti VM:en"
 ],
 "Shared storage": [
  null,
  "Delad lagring"
 ],
 "Show additional options": [
  null,
  "Visa ytterligare åtgärder"
 ],
 "Show less": [
  null,
  "Visa mindre"
 ],
 "Show more": [
  null,
  "Visa mer"
 ],
 "Shut down": [
  null,
  "Stäng av"
 ],
 "Shut down $0?": [
  null,
  "Stäng av $0?"
 ],
 "Shut off": [
  null,
  "Stäng av"
 ],
 "Shut off the VM in order to edit firmware configuration": [
  null,
  "Stäng av VM:en för att redigera konfigurationen av den fasta programvaran"
 ],
 "Shutting down": [
  null,
  "Stänger av"
 ],
 "Size": [
  null,
  "Storlek"
 ],
 "Slot": [
  null,
  "Plats"
 ],
 "Snapshot $0 could not be deleted": [
  null,
  "Ögonblicksbild $0 kunde inte raderas"
 ],
 "Snapshot $0 will be deleted from $1. All of its captured content will be lost.": [
  null,
  "Ögonblicksbilden $0 kommer raderas från $1. All dess fångade innehåll kommer att gå förlorat."
 ],
 "Snapshot failed to be created": [
  null,
  "Misslyckades att skapa ögonblicksbild"
 ],
 "Snapshots": [
  null,
  "Ögonblicksbilder"
 ],
 "Sockets": [
  null,
  "Uttag"
 ],
 "Some configuration changes only take effect after a fresh boot:": [
  null,
  "Vissa konfigurationsändringar träder bara i kraft efter en fräsch uppstart:"
 ],
 "Source": [
  null,
  "Källa"
 ],
 "Source format": [
  null,
  "Källformat"
 ],
 "Source must not be empty": [
  null,
  "Källa kan inte vara tomt"
 ],
 "Source path": [
  null,
  "Källsökväg"
 ],
 "Source path should not be empty": [
  null,
  "Källsökvägen får inte vara tom"
 ],
 "Source should start with http, ftp or nfs protocol": [
  null,
  "Källan skall börja med ett av protokollen http, ftp eller nfs"
 ],
 "Source volume group": [
  null,
  "Källvolymgrupp"
 ],
 "Start": [
  null,
  "Starta"
 ],
 "Start pool when host boots": [
  null,
  "Starta poolen när värden startar upp"
 ],
 "Start should not be empty": [
  null,
  "Start ska inte vara tomt"
 ],
 "Start the virtual machine to access the console": [
  null,
  "Starta den virtuella maskinen för att komma åt konsolen"
 ],
 "Start the virtual machine to launch remote viewer.": [
  null,
  "Starta den virtuella maskinen för att starta fjärrvisaren."
 ],
 "Started": [
  null,
  "Startad"
 ],
 "Startup": [
  null,
  "Uppstart"
 ],
 "State": [
  null,
  "Tillstånd"
 ],
 "Static host entries": [
  null,
  "Statiska värdposter"
 ],
 "Static host from DHCP could not be removed": [
  null,
  "Statiska värdposter från DHCP kunde inte tas bort"
 ],
 "Storage": [
  null,
  "Lagring"
 ],
 "Storage is at a shared location": [
  null,
  "Lagring är på en delad plats"
 ],
 "Storage limit": [
  null,
  "Lagringsgräns"
 ],
 "Storage pool $0 failed to get activated": [
  null,
  "Lagringspool $0 kunde inte aktiveras"
 ],
 "Storage pool $0 failed to get deactivated": [
  null,
  "Lagringspool $0 kunde inte inaktiveras"
 ],
 "Storage pool failed to be created": [
  null,
  "Lagringspoolen kunde inte skapas"
 ],
 "Storage pool name": [
  null,
  "Lagringspoolsnamn"
 ],
 "Storage pools": [
  null,
  "Lagringspooler"
 ],
 "Storage pools could not be fetched": [
  null,
  "Lagringspooler kunde inte hämtas"
 ],
 "Storage size must not be 0": [
  null,
  "Lagringsstorleken får inte vara 0"
 ],
 "Storage volume": [
  null,
  "Lagringsvolym"
 ],
 "Storage volume size must not exceed the storage pool's capacity ($0 $1)": [
  null,
  "Lagringsvolymstorleken får inte överstiga lagringspoolens kapacitet ($0 $1)"
 ],
 "Storage volumes": [
  null,
  "Lagringsvolymer"
 ],
 "Storage volumes could not be deleted": [
  null,
  "Lagringsvolymer kunde inte raderas"
 ],
 "Storage volumes must be shared between this host and the destination host.": [
  null,
  "Lagringsvolymer måste delas mellan denna värd och destinationsvärden."
 ],
 "Successfully copied to clipboard!": [
  null,
  "Framgångsrikt kopierat till urklipp!"
 ],
 "Suspended (PM)": [
  null,
  "vilande (SH)"
 ],
 "Switch to VNC to continue using this machine.": [
  null,
  "Byt till VNC för att fortsätta använda den här maskinen."
 ],
 "System": [
  null,
  "System"
 ],
 "TAP device": [
  null,
  "TAP-enhet"
 ],
 "TPM": [
  null,
  "TPM"
 ],
 "Table of selectable host devices": [
  null,
  "Tabell över valbara värdenheter"
 ],
 "Target": [
  null,
  "Mål"
 ],
 "Target path": [
  null,
  "Målsökväg"
 ],
 "Target path should not be empty": [
  null,
  "Målsökvägen får inte vara tom"
 ],
 "Temporary": [
  null,
  "Temporär"
 ],
 "Temporary migration": [
  null,
  "Tillfällig migration"
 ],
 "The VM $0 is running and will be forced off before deletion.": [
  null,
  "VM:en $0 kör och kommer tvingande stängas av före den tas bort."
 ],
 "The VM needs to be running or shut off to detach this device": [
  null,
  "VM:en behöver köra eller vara avstängd för att koppla ifrån denna enhet"
 ],
 "The directory on the server being exported": [
  null,
  "Katalogen på servern exporteras"
 ],
 "The host path that is to be exported.": [
  null,
  "Värdsökvägen som ska exporteras."
 ],
 "The migrated VM configuration is removed from the source host. The destination host is considered the new home of the VM.": [
  null,
  "Den migrerade VM-konfigurationen tas bårt från källvärden. Destinationsvärden anses vara det nya hemmet för VM:en."
 ],
 "The mode influences the delivery of packets.": [
  null,
  "Läget påverkar leveransen av paket."
 ],
 "The pool is empty": [
  null,
  "Poolen är tom"
 ],
 "The selected operating system has minimum memory requirement of $0 $1": [
  null,
  "Det valda operativsystemet har ett minsta minneskrav på $0 $1"
 ],
 "The selected operating system has minimum storage size requirement of $0 $1": [
  null,
  "Det valda operativsystemet har ett minsta lagringskrav på $0 $1"
 ],
 "The static host entry for $0 will be removed:": [
  null,
  "Den statiska värdposten för $0 kommer att tas bort:"
 ],
 "The storage pool could not be deleted": [
  null,
  "Lagringspoolen kunde inte raderas"
 ],
 "The tag name to be used by the guest to mount this export point.": [
  null,
  "Taggnamnet som gästen skall använda för att montera denna exporteringspunkt."
 ],
 "Then copy and paste it above.": [
  null,
  "Kopiera och klistra sedan in det ovan."
 ],
 "This VM is transient. Shut it down if you wish to delete it.": [
  null,
  "Denna VM är transient. Stäng av den om du vill radera den."
 ],
 "This disk will be removed from $0:": [
  null,
  "Denna disk kommer tas bort från $0:"
 ],
 "This filesystem will be removed from $0:": [
  null,
  "Detta filsystem kommer tas bort från $0:"
 ],
 "This is intended for a host which does not support SPICE due to upgrades or live migration.": [
  null,
  "Detta är avsett för en värd som inte stöder SPICE på grund av uppgraderingar eller livemigrering."
 ],
 "This is the recommended type for general guest connectivity on hosts with dynamic / wireless networking configs.": [
  null,
  "Detta är den rekommenderade typen för allmän gästanslutning på värdar med dynamiska/trådlösa nätverkskonfigurationer."
 ],
 "This is the recommended type for general guest connectivity on hosts with static wired networking configs.": [
  null,
  "Detta är den rekommenderade typen för allmän gästanslutning på värdar med statiska trådbundna nätverkskonfigurationer."
 ],
 "This is the recommended type for high performance or enhanced security.": [
  null,
  "Detta är den rekommenderade typen för hög prestanda eller förbättrad säkerhet."
 ],
 "This machine has a SPICE graphical console that can not be shown here.": [
  null,
  "Den här maskinen har en SPICE grafisk konsol som inte kan visas här."
 ],
 "This volume is already used by $0.": [
  null,
  "Denna volym används redan av $0."
 ],
 "This volume is already used by another VM.": [
  null,
  "Den här volymen används redan av en annan VM."
 ],
 "Threads per core": [
  null,
  "Trådar per kärna"
 ],
 "Total space available: $0.": [
  null,
  "Total storlek tillgänglig: $0."
 ],
 "Transient VMs don't support editing firmware configuration": [
  null,
  "Transienta VM:ar stödjer inte att redigera konfigurationen av den fasta programvaran"
 ],
 "Troubleshoot": [
  null,
  "Felsök"
 ],
 "Type": [
  null,
  "Typ"
 ],
 "URL (ISO image or distro install tree)": [
  null,
  "URL (ISO avbild eller distro install träd)"
 ],
 "USB": [
  null,
  "USB"
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Undefined": [
  null,
  "Odefinierad"
 ],
 "Unique name": [
  null,
  "Unikt namn"
 ],
 "Unique name, default: $0": [
  null,
  "Unikt namn, standard $0"
 ],
 "Unique network name": [
  null,
  "Unikt nätverksnamn"
 ],
 "Unit": [
  null,
  "Enhet"
 ],
 "Unknown": [
  null,
  "Okänd"
 ],
 "Unknown firmware": [
  null,
  "Okänt firmware"
 ],
 "Unspecified": [
  null,
  "Ospecificerad"
 ],
 "Unsupported and older operating systems": [
  null,
  "Ostödda och äldre operativsystem"
 ],
 "Url": [
  null,
  "Url"
 ],
 "Usage": [
  null,
  "Användning"
 ],
 "Use existing": [
  null,
  "Använd befintlig"
 ],
 "Use extended attributes on files and directories": [
  null,
  "Använd utökade attribut på filer och kataloger"
 ],
 "Use the same location on both the origin and destination hosts for your storage. This can be a shared storage pool, NFS, or any other method of sharing storage.": [
  null,
  "Använd samma plats för lagringen på ursprungs- och destinationsvärden. Detta kan vara en delad lagringspool, NFS eller någon annan metod att dela lagring."
 ],
 "Used": [
  null,
  "Använt"
 ],
 "Used by": [
  null,
  "Används av"
 ],
 "User login": [
  null,
  "Användarinloggning"
 ],
 "User login must not be empty when SSH keys are set": [
  null,
  "Användarinloggning får inte vara tom när SSH-nycklar är inställda"
 ],
 "User login must not be empty when user password is set": [
  null,
  "Användarinloggningen får inte vara tom när användarlösenordet är inställt"
 ],
 "User password": [
  null,
  "Användarens lösenord"
 ],
 "User password must not be empty when user login is set": [
  null,
  "Användarlösenordet får inte vara tomt när användarinloggning är inställd"
 ],
 "User session": [
  null,
  "Användarsession"
 ],
 "Uses SPICE": [
  null,
  "Använder SPICE"
 ],
 "VM $0 Host Devices": [
  null,
  "VM $0 VärdEnheter"
 ],
 "VM $0 already exists": [
  null,
  "VM $0 existerar redan"
 ],
 "VM $0 does not exist on $1 connection": [
  null,
  "VM $0 finns inte på $1 -anslutning"
 ],
 "VM $0 failed to force reboot": [
  null,
  "VM $0 misslyckades med att tvinga omstart"
 ],
 "VM $0 failed to force shutdown": [
  null,
  "VM:en $0 kunde inte tvingande stängas av"
 ],
 "VM $0 failed to get installed": [
  null,
  "VM:en $0 kunde inte installeras"
 ],
 "VM $0 failed to pause": [
  null,
  "VM:en $0 kunde inte pausa"
 ],
 "VM $0 failed to reboot": [
  null,
  "VM:en $0 kunde inte starta om"
 ],
 "VM $0 failed to resume": [
  null,
  "VM:en $0 kunde inte återuppta"
 ],
 "VM $0 failed to send NMI": [
  null,
  "VM:en $0 kunde inte skicka NMI"
 ],
 "VM $0 failed to shutdown": [
  null,
  "VM $0 kunde inte stängas av"
 ],
 "VM $0 failed to start": [
  null,
  "VM:en $0 kunde inte starta"
 ],
 "VM launched with unprivileged limited access, with the process and PTY owned by your user account": [
  null,
  "VM:en startad med opriviligierad begränsad åtkomst, med processen och PTY:n ägda av ditt användarkonto"
 ],
 "VM needs shutdown": [
  null,
  "VM behöver stängas av"
 ],
 "VM state": [
  null,
  "VM-tillstånd"
 ],
 "VM will launch with root permissions": [
  null,
  "VM kommer att starta med root-behörigheter"
 ],
 "VNC": [
  null,
  "VNC"
 ],
 "VNC settings could not be saved": [
  null,
  "VNC-inställningarna kunde inte sparas"
 ],
 "Valid token": [
  null,
  "Giltig token"
 ],
 "Vendor": [
  null,
  "Leverantör"
 ],
 "Vendor support ended $0": [
  null,
  "Leverantörssupport slutade $0"
 ],
 "Virtual machines": [
  null,
  "Virtuella maskiner"
 ],
 "Virtual machines management": [
  null,
  "Hantering av virtuella maskiner"
 ],
 "Virtual network": [
  null,
  "Virtuellt nätverk"
 ],
 "Virtual network failed to be created": [
  null,
  "Det gick inte att skapa ett virtuellt nätverk"
 ],
 "Virtual socket support enables communication between the host and guest over a socket. It still requires special vsock-aware software to communicate over the socket.": [
  null,
  "Stöd för virtuella sockets möjliggör kommunikation mellan värden och gästen via en socket. Det kräver fortfarande speciell vsock-medveten programvara för att kommunicera över socketen."
 ],
 "Virtualization service (libvirt) is not active": [
  null,
  "Virtualiseringstjänsten (libvirt) är inte aktiv"
 ],
 "Volume": [
  null,
  "Volym"
 ],
 "Volume failed to be created": [
  null,
  "Volymen kunde inte skapas"
 ],
 "Volume group name": [
  null,
  "Volym gruppnamn"
 ],
 "Volume group name should not be empty": [
  null,
  "Volymgruppens namn ska inte vara tomt"
 ],
 "Vsock": [
  null,
  "Vsock"
 ],
 "WWPN": [
  null,
  "WWPN"
 ],
 "Watchdog": [
  null,
  "Vakthund"
 ],
 "Watchdogs act when systems stop responding. To use this virtual watchdog device, the guest system also needs to have an additional driver and a running watchdog service.": [
  null,
  "Vakthundar agerar när system slutar svara. För att använda denna virtuella vakthundsenhet behöver gästsystemet även ha en ytterligare drivrutin och en körande vakthundstjänst."
 ],
 "Writeable": [
  null,
  "Skrivbar"
 ],
 "You can mount the shared folder using:": [
  null,
  "Du kan montera den delade mappen med:"
 ],
 "You need to select the most closely matching operating system": [
  null,
  "Du behöver välja det operativsystem som stämmer bäst"
 ],
 "active": [
  null,
  "aktiv"
 ],
 "add": [
  null,
  "lägg till"
 ],
 "add entry": [
  null,
  "lägg till post"
 ],
 "bridge": [
  null,
  "brygga"
 ],
 "cdrom": [
  null,
  "cdrom"
 ],
 "custom": [
  null,
  "anpassad"
 ],
 "direct": [
  null,
  "direkt"
 ],
 "disabled": [
  null,
  "avaktiverat"
 ],
 "disk": [
  null,
  "disk"
 ],
 "down": [
  null,
  "nere"
 ],
 "edit": [
  null,
  "redigera"
 ],
 "enabled": [
  null,
  "aktiverat"
 ],
 "ethernet": [
  null,
  "ethernet"
 ],
 "host": [
  null,
  "värd"
 ],
 "host device": [
  null,
  "värdenhet"
 ],
 "host passthrough": [
  null,
  "genomgång till värd"
 ],
 "hostdev": [
  null,
  "värdenhet"
 ],
 "iSCSI direct target": [
  null,
  "iSCSI direktmål"
 ],
 "iSCSI initiator IQN": [
  null,
  "iSCSI initierar-IQN"
 ],
 "iSCSI target": [
  null,
  "iSCSI-mål"
 ],
 "iSCSI target IQN": [
  null,
  "iSCSI mål IQN"
 ],
 "inactive": [
  null,
  "inaktiv"
 ],
 "inet": [
  null,
  "inet"
 ],
 "inet6": [
  null,
  "inet6"
 ],
 "mcast": [
  null,
  "mcast"
 ],
 "more info": [
  null,
  "mer information"
 ],
 "mount point: The mount point inside the guest": [
  null,
  "monteringspunkt: monteringspunkten inuti gästen"
 ],
 "mount tag: The tag associated to the exported mount point": [
  null,
  "monteringstagg: taggen associerad med den exporterade monteringspunkten"
 ],
 "network": [
  null,
  "nätverk"
 ],
 "no": [
  null,
  "nej"
 ],
 "no state saved": [
  null,
  "inget tillstånd sparat"
 ],
 "none": [
  null,
  "inget"
 ],
 "redirected device": [
  null,
  "omdirigerad enhet"
 ],
 "remove": [
  null,
  "ta bort"
 ],
 "serial number": [
  null,
  "serienummer"
 ],
 "server": [
  null,
  "server"
 ],
 "udp": [
  null,
  "udp"
 ],
 "up": [
  null,
  "uppe"
 ],
 "user": [
  null,
  "användare"
 ],
 "vCPU and CPU topology settings could not be saved": [
  null,
  "vCPU och CPU-topologiinställningarna kunde inte sparas"
 ],
 "vCPU count": [
  null,
  "vCPU-antal"
 ],
 "vCPU maximum": [
  null,
  "vCPU-maximum"
 ],
 "vCPUs": [
  null,
  "vCPU:er"
 ],
 "vhostuser": [
  null,
  "vhost-användare"
 ],
 "view more...": [
  null,
  "visa mer..."
 ],
 "virt-install package needs to be installed on the system in order to clone VMs": [
  null,
  "virt-install-paketet måste installeras på systemet för att kunna klona virtuella datorer"
 ],
 "virt-install package needs to be installed on the system in order to create new VMs": [
  null,
  "virt-install-paketet måste installeras på systemet för att kunna skapa nya virtuella datorer"
 ],
 "virt-install package needs to be installed on the system in order to edit this attribute": [
  null,
  "virt-install-paketet måste installeras på systemet för att kunna redigera detta attribut"
 ],
 "vsock requires special software": [
  null,
  "vsock kräver speciell programvara"
 ],
 "yes": [
  null,
  "ja"
 ]
});
