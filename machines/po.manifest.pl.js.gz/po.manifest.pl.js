cockpit.locale({
 "": {
  "plural-forms": (n) => n==1 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "pl",
  "language-direction": "ltr"
 },
 "Managing virtual machines": [
  null,
  "Zarządzanie maszynami wirtualnymi"
 ],
 "Virtual machines": [
  null,
  "Maszyny wirtualne"
 ],
 "iso": [
  null,
  "ISO"
 ],
 "libvirt": [
  null,
  "libvirt"
 ],
 "pxe": [
  null,
  "PXE"
 ],
 "qcow2": [
  null,
  "qcow2"
 ],
 "qemu": [
  null,
  "QEMU"
 ],
 "vm": [
  null,
  "maszyna wirtualna"
 ]
});
