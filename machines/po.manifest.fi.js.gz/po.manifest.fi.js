cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "fi",
  "language-direction": "ltr"
 },
 "Managing virtual machines": [
  null,
  "Virtuaalikoneiden hallinta"
 ],
 "Virtual machines": [
  null,
  "Virtuaalikoneet"
 ],
 "iso": [
  null,
  "iso"
 ],
 "libvirt": [
  null,
  "libvirt"
 ],
 "pxe": [
  null,
  "pxe"
 ],
 "qcow2": [
  null,
  "qcow2"
 ],
 "qemu": [
  null,
  "qemu"
 ],
 "vm": [
  null,
  "vm"
 ]
});
