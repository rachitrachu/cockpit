cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "ja",
  "language-direction": "ltr"
 },
 "Managing virtual machines": [
  null,
  "仮想マシン管理"
 ],
 "Virtual machines": [
  null,
  "仮想マシン"
 ],
 "iso": [
  null,
  "iso"
 ],
 "libvirt": [
  null,
  "libvirt"
 ],
 "pxe": [
  null,
  "pxe"
 ],
 "qcow2": [
  null,
  "qcow2"
 ],
 "qemu": [
  null,
  "qemu"
 ],
 "vm": [
  null,
  "vm"
 ]
});
