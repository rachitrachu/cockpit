cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "zh_TW",
  "language-direction": "ltr"
 },
 "$0 $1 available at default location": [
  null,
  "$0 $1 於預設位置可用"
 ],
 "$0 $1 available on host": [
  null,
  "$0 $1 於主機上可用"
 ],
 "$0 CPU details": [
  null,
  "$0 CPU 詳細資訊"
 ],
 "$0 Network": [
  null,
  "$0 個網路"
 ],
 "$0 Storage pool": [
  null,
  "$0 個儲存集區"
 ],
 "$0 does not support unattended installation.": [
  null,
  "$0 不支援無人值守的安裝模式。"
 ],
 "$0 memory adjustment": [
  null,
  "$0 記憶體調整"
 ],
 "$0 network": [
  null,
  "$0 網路"
 ],
 "$0 vCPU": [
  null,
  "$0 個虛擬CPU"
 ],
 "$0 virtual network interface settings": [
  null,
  "$0 虛擬網路介面設定"
 ],
 "A copy of the VM will run on the destination and will disappear when it is shut off. Meanwhile, the origin host keeps its copy of the VM configuration.": [
  null,
  "虛擬機器的副本將在目的地上執行，且將在虛擬機器關閉後消失。同時，原本的主機會保留其原有虛擬機器的設定值。"
 ],
 "Access": [
  null,
  "存取"
 ],
 "Action": [
  null,
  "動作"
 ],
 "Actions": [
  null,
  "動作"
 ],
 "Activate": [
  null,
  "啟用"
 ],
 "Activate the storage pool to administer volumes": [
  null,
  "啟用儲存空間集區以管理磁碟區"
 ],
 "Add": [
  null,
  "新增"
 ],
 "Add SSH keys": [
  null,
  "新增 SSH 金鑰"
 ],
 "Add TPM": [
  null,
  "新增 TPM"
 ],
 "Add VNC": [
  null,
  ""
 ],
 "Add a DHCP static host entry": [
  null,
  "新增 DHCP 靜態主機項目"
 ],
 "Add disk": [
  null,
  "新增磁碟"
 ],
 "Add host device": [
  null,
  "新增主機裝置"
 ],
 "Add network interface": [
  null,
  "新增網路介面"
 ],
 "Add shared directory": [
  null,
  "新增共享目錄"
 ],
 "Add virtual network interface": [
  null,
  "新增虛擬網路介面"
 ],
 "Add vsock interface": [
  null,
  "新增 vsock 介面"
 ],
 "Add watchdog device type": [
  null,
  "新增 watchdog 裝置類型"
 ],
 "Adding a watchdog will require a reboot to take effect.": [
  null,
  "新增 watchdog 須重新開機才會生效。"
 ],
 "Adding shared directories is possible only when the guest is shut off": [
  null,
  "只有在客體已關閉時才能新增共享目錄"
 ],
 "Additional": [
  null,
  "額外"
 ],
 "Address": [
  null,
  "位址"
 ],
 "Address not within subnet": [
  null,
  "位址不在子網路內"
 ],
 "All": [
  null,
  "全部"
 ],
 "All VM activity, including storage, will be temporary. This will result in data loss on the destination host.": [
  null,
  "所有虛擬機器的活動、包含儲存空間，將都是暫時的。這將會導致在目的地主機上的資料遺失。"
 ],
 "Allowed characters: basic Latin alphabet, numbers, and limited punctuation (-, _, +, .)": [
  null,
  "允許的字元：基本拉丁字母、數字、與有限的標點 (-, _, +, .)"
 ],
 "Also delete all volumes inside this pool:": [
  null,
  "同時將這個集區內的所有磁碟區刪除："
 ],
 "Always attach": [
  null,
  "每次都附加"
 ],
 "An example of vsock-aware software is socat": [
  null,
  "能適用於 vsock 的軟體其中一個例子是 socat"
 ],
 "Apply": [
  null,
  "套用"
 ],
 "Apply on next boot": [
  null,
  "下次開機時套用"
 ],
 "Assign automatically": [
  null,
  "自動指派"
 ],
 "Automated installs are only available when downloading an image or using cloud-init.": [
  null,
  "自動安裝只在下載映像檔或使用 cloud-init 時可供使用。"
 ],
 "Automatic": [
  null,
  "自動"
 ],
 "Automation": [
  null,
  "自動化"
 ],
 "Autostart": [
  null,
  "自動啟動"
 ],
 "Block device": [
  null,
  "區塊裝置"
 ],
 "Blocked": [
  null,
  "受到阻擋"
 ],
 "Boot order": [
  null,
  "開機順序"
 ],
 "Boot order settings could not be saved": [
  null,
  "無法儲存開機順序"
 ],
 "Bus": [
  null,
  "匯流排"
 ],
 "CD/DVD disc": [
  null,
  "CD/DVD 光碟"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "CPU mode could not be saved": [
  null,
  "無法儲存 CPU 模式"
 ],
 "Cache": [
  null,
  "快取"
 ],
 "Cancel": [
  null,
  "取消"
 ],
 "Cannot edit vsock device on a transient VM": [
  null,
  "無法修改暫時性虛擬機器的 vsock 裝置"
 ],
 "Cannot edit watchdog device on a transient VM": [
  null,
  "無法編輯暫時性虛擬機器上的 watchdog 裝置"
 ],
 "Capacity": [
  null,
  "容量"
 ],
 "Change boot order": [
  null,
  "變更開機順序"
 ],
 "Change firmware": [
  null,
  "變更韌體"
 ],
 "Changes pending": [
  null,
  "未套用的變更"
 ],
 "Changes will take effect after shutting down the VM": [
  null,
  "變更將於虛擬機器關機後生效"
 ],
 "Changing BIOS/EFI settings is specific to each manufacturer. It involves pressing a hotkey during boot (ESC, F1, F12, Del). Enable a setting called \"virtualization\", \"VM\", \"VMX\", \"SVM\", \"VTX\", \"VTD\". Consult your computer's manual for details.": [
  null,
  "變更 BIOS/EFI 設定的流程依每個製造商而有所不同。其需要在開機時按下熱鍵 (ESC、F1、F12、Del)。啟用一個名為 \"虛擬化 (virtualization)\"、\"VM\"、\"VMX\"、\"SVM\"、\"VTX\"、\"VTD\" 的設定。詳情請參閱您的電腦使用手冊。"
 ],
 "Checking token validity...": [
  null,
  "正在檢查權杖的有效性…"
 ],
 "Choose an operating system": [
  null,
  "選擇作業系統"
 ],
 "Class": [
  null,
  "類別"
 ],
 "Clone": [
  null,
  "複製"
 ],
 "Close": [
  null,
  "關閉"
 ],
 "Cloud base image": [
  null,
  "雲端基礎 (Cloud base) 映像"
 ],
 "Compress": [
  null,
  ""
 ],
 "Concurrently writeable": [
  null,
  "可同時寫入"
 ],
 "Confirm this action": [
  null,
  "確認此動作"
 ],
 "Connect": [
  null,
  "連線"
 ],
 "Connection": [
  null,
  "連線"
 ],
 "Console": [
  null,
  "控制台"
 ],
 "Convert QXL video card to VGA": [
  null,
  "將 QXL 顯示卡轉換為 VGA"
 ],
 "Convert SPICE graphics console to VNC": [
  null,
  "將 SPICE 圖形控制台轉換成 VNC"
 ],
 "Copy storage": [
  null,
  "複製儲存空間"
 ],
 "Copy to clipboard": [
  null,
  ""
 ],
 "Cores per socket": [
  null,
  "每個插槽的核心數"
 ],
 "Could not delete $0": [
  null,
  "無法刪除 $0"
 ],
 "Could not delete all storage for $0": [
  null,
  "無法刪除 $0 的所有儲存空間"
 ],
 "Could not delete disk's storage": [
  null,
  "無法刪除磁碟的儲存空間"
 ],
 "Could not dynamically add watchdog": [
  null,
  "無法動態新增 watchdog"
 ],
 "Could not revert to snapshot": [
  null,
  "無法還原至快照"
 ],
 "Crashed": [
  null,
  "已當機"
 ],
 "Create": [
  null,
  "建立"
 ],
 "Create VM": [
  null,
  "建立虛擬機器"
 ],
 "Create VM by importing a disk image of an existing VM installation": [
  null,
  "透過匯入既有虛擬機器的磁碟映像檔建立虛擬機器"
 ],
 "Create VM from local or network installation medium": [
  null,
  "透過本機或網路上的安裝媒介建立虛擬機器"
 ],
 "Create a clone VM based on $0": [
  null,
  "透過拓製 $0 建立虛擬機器"
 ],
 "Create and edit": [
  null,
  "建立並編輯"
 ],
 "Create and run": [
  null,
  "建立並執行"
 ],
 "Create new": [
  null,
  "新建"
 ],
 "Create new qcow2 volume": [
  null,
  "建立新的 qcow2 磁碟區"
 ],
 "Create new raw volume": [
  null,
  "建立新的未格式化磁碟區"
 ],
 "Create new virtual machine": [
  null,
  "建立新虛擬機器"
 ],
 "Create snapshot": [
  null,
  "建立快照"
 ],
 "Create storage pool": [
  null,
  "建立儲存空間集區"
 ],
 "Create storage volume": [
  null,
  "建立儲存空間磁碟區"
 ],
 "Create virtual network": [
  null,
  "建立虛擬網路"
 ],
 "Create volume": [
  null,
  "建立磁碟分區"
 ],
 "Creating VM": [
  null,
  "正在建立 VM"
 ],
 "Creating VM $0": [
  null,
  "正在建立虛擬機器 $0"
 ],
 "Creating snapshots of VMs with VFIO devices is not supported while they are running.": [
  null,
  "不支援在具有 VFIO 裝置的虛擬機器運作中時建立快照。"
 ],
 "Creation of VM $0 failed": [
  null,
  "建立虛擬機器 $0 失敗"
 ],
 "Creation time": [
  null,
  "建立時間"
 ],
 "Ctrl+Alt+$0": [
  null,
  "Ctrl+Alt+$0"
 ],
 "Current": [
  null,
  "目前"
 ],
 "Current allocation": [
  null,
  "目前分配"
 ],
 "Custom firmware: $0": [
  null,
  "自訂的韌體：$0"
 ],
 "Custom identifier": [
  null,
  "自訂識別碼"
 ],
 "Custom path": [
  null,
  "自訂路徑"
 ],
 "DHCP Settings": [
  null,
  "DHCP 設定"
 ],
 "Deactivate": [
  null,
  "停用"
 ],
 "Delete": [
  null,
  "刪除"
 ],
 "Delete $0 VM?": [
  null,
  "刪除 $0 虛擬機器？"
 ],
 "Delete $0 storage pool?": [
  null,
  "刪除 $0 儲存集區？"
 ],
 "Delete $0 volume": [
  null,
  "刪除 $0 個磁碟區"
 ],
 "Delete associated storage files:": [
  null,
  "刪除相關的儲存空間檔案："
 ],
 "Delete network?": [
  null,
  "刪除網路？"
 ],
 "Delete snapshot?": [
  null,
  "刪除快照？"
 ],
 "Deleting an inactive storage pool will only undefine the pool. Its content will not be deleted.": [
  null,
  "刪除一個已停用的儲存空間集區將只會解除定義該集區。其內容物將不會被刪除。"
 ],
 "Deleting shared directories is possible only when the guest is shut off": [
  null,
  "刪除共享目錄只在客體已關閉時可執行"
 ],
 "Description": [
  null,
  "描述"
 ],
 "Deselect others": [
  null,
  "取消其他選擇的"
 ],
 "Destination URI": [
  null,
  "目的地 URI"
 ],
 "Destination URI must not be empty": [
  null,
  "目的地 URI 不可為空白"
 ],
 "Detach the disks using this pool from any VMs before attempting deletion.": [
  null,
  "在嘗試刪除前，從所有使用此集區中磁碟的虛擬機器上拆離這個集區的磁碟。"
 ],
 "Details": [
  null,
  "詳細資訊"
 ],
 "Device": [
  null,
  "裝置"
 ],
 "Devices": [
  null,
  "裝置"
 ],
 "Disconnect": [
  null,
  "中斷連線"
 ],
 "Disconnected": [
  null,
  "已斷線"
 ],
 "Disconnected from serial console. Click the connect button.": [
  null,
  "序列控制台連線中斷。請按連線按鈕。"
 ],
 "Disk": [
  null,
  "磁碟"
 ],
 "Disk $0 could not be removed": [
  null,
  "無法移除磁碟 $0"
 ],
 "Disk failed to be added": [
  null,
  "新增磁碟失敗"
 ],
 "Disk identifier": [
  null,
  "磁碟識別碼"
 ],
 "Disk image": [
  null,
  "磁碟映像"
 ],
 "Disk image file": [
  null,
  "磁碟映像檔"
 ],
 "Disk image path must not be empty": [
  null,
  "磁碟映像路徑不可為空值"
 ],
 "Disk images can be stored in user home directory": [
  null,
  "磁碟映像檔可以被儲存在使用者的家目錄"
 ],
 "Disk settings could not be saved": [
  null,
  "磁碟設定無法儲存"
 ],
 "Disk-only snapshot": [
  null,
  "僅磁碟的快照"
 ],
 "Disks": [
  null,
  "磁碟"
 ],
 "Do not run this VM on the origin and destination hosts at the same time.": [
  null,
  "請勿在原本、與目的地的主機上同時執行此虛擬機器。"
 ],
 "Do nothing": [
  null,
  "什麼都不做"
 ],
 "Domain has crashed": [
  null,
  "虛擬機器 (Domain) 已當機"
 ],
 "Domain is blocked on resource": [
  null,
  "虛擬機器 (Domain) 因資源問題被阻擋"
 ],
 "Download an OS": [
  null,
  "下載作業系統"
 ],
 "Download progress": [
  null,
  "下載進度"
 ],
 "Downloading image for VM $0": [
  null,
  "正在為虛擬機器 $0 下載映像"
 ],
 "Downloading: $0%": [
  null,
  "正在下載： $0%"
 ],
 "Dump core": [
  null,
  "傾印核心"
 ],
 "Duration": [
  null,
  "持續時間"
 ],
 "Dying": [
  null,
  "垂死"
 ],
 "Edit": [
  null,
  "編輯"
 ],
 "Edit $0 attributes": [
  null,
  "編輯 $0 屬性"
 ],
 "Edit description": [
  null,
  "編輯描述"
 ],
 "Edit description of VM $0": [
  null,
  "編輯虛擬機器 $0 的描述"
 ],
 "Edit vsock interface": [
  null,
  "編輯 vsock 介面"
 ],
 "Edit watchdog device type": [
  null,
  "編輯 watchdog 裝置類型"
 ],
 "Editing network interfaces of transient guests is not allowed": [
  null,
  "不允許編輯暫時性客體的網路介面"
 ],
 "Editing transient network interfaces is not allowed": [
  null,
  "不允許編輯暫時性網路介面"
 ],
 "Eject": [
  null,
  "退出"
 ],
 "Eject disc from VM?": [
  null,
  "從虛擬機器將光碟退片嗎？"
 ],
 "Emulated machine": [
  null,
  "模擬的機器"
 ],
 "Enable virtualization support in BIOS/EFI settings.": [
  null,
  "於 BIOS/EFI 設定啟用虛擬化支援。"
 ],
 "End": [
  null,
  "結束"
 ],
 "End should not be empty": [
  null,
  "結束不應為空值"
 ],
 "Enter root and/or user information to enable unattended installation.": [
  null,
  "輸入 root 和/或使用者資訊以啟用無人式安裝。"
 ],
 "Error checking token": [
  null,
  "檢查權杖時發生問題"
 ],
 "Example, $0": [
  null,
  "例如， $0"
 ],
 "Existing disk image on host's file system": [
  null,
  "已存在於主機檔案系統上的磁碟映像檔"
 ],
 "Expand": [
  null,
  "展開"
 ],
 "Extended attributes": [
  null,
  "延伸屬性"
 ],
 "Failed": [
  null,
  "失敗"
 ],
 "Failed to add TPM to VM $0": [
  null,
  "為虛擬機器 $0 新增 TPM 失敗"
 ],
 "Failed to add shared directory": [
  null,
  "新增共享目錄失敗"
 ],
 "Failed to change firmware": [
  null,
  "變更韌體失敗"
 ],
 "Failed to clone VM $0": [
  null,
  "拓製虛擬機器 $0 失敗"
 ],
 "Failed to configure vsock": [
  null,
  "設定 vsock 失敗"
 ],
 "Failed to configure watchdog": [
  null,
  "設定 watchdog 失敗"
 ],
 "Failed to detach vsock": [
  null,
  "拆離 vsock 失敗"
 ],
 "Failed to detach watchdog": [
  null,
  "拆離 watchdog 失敗"
 ],
 "Failed to fetch some resources": [
  null,
  "取得某些資源失敗"
 ],
 "Failed to fetch the IP addresses of the interfaces present in $0": [
  null,
  "未能取得 $0 中介面的 IP 位址"
 ],
 "Failed to rename VM $0": [
  null,
  "重新命名虛擬機器 $0 失敗"
 ],
 "Failed to replace SPICE devices": [
  null,
  "取代 SPICE 裝置失敗"
 ],
 "Failed to save network settings": [
  null,
  "儲存網路設定失敗"
 ],
 "Failed to send key Ctrl+Alt+$0 to VM $1": [
  null,
  "傳送 Ctrl+Alt+$0 按鍵至虛擬機器 $1 失敗"
 ],
 "Failed to set description of VM $0": [
  null,
  "設定虛擬機器 $0 的描述失敗"
 ],
 "Fewer than the maximum number of virtual CPUs should be enabled.": [
  null,
  "啟用的虛擬 CPU 數量應少於虛擬 CPU 數量的最大值。"
 ],
 "File": [
  null,
  "檔案"
 ],
 "Filesystem $0 could not be removed": [
  null,
  "檔案系統 $0 無法被移除"
 ],
 "Filesystem directory": [
  null,
  "檔案系統目錄"
 ],
 "Filter by name": [
  null,
  "以名稱篩選"
 ],
 "Firmware": [
  null,
  "韌體"
 ],
 "Force eject": [
  null,
  "強制退出"
 ],
 "Force reboot": [
  null,
  "強制重開機"
 ],
 "Force reboot $0?": [
  null,
  "強制把 $0 重開機嗎？"
 ],
 "Force revert": [
  null,
  "強制還原"
 ],
 "Force shut down": [
  null,
  "強制關機"
 ],
 "Force shut down $0?": [
  null,
  "將 $0 強制關機嗎？"
 ],
 "Format": [
  null,
  "格式"
 ],
 "Forward mode": [
  null,
  "轉發模式"
 ],
 "Forwarding mode": [
  null,
  "轉發模式"
 ],
 "Full disk images and the domain's memory will be migrated. Only non-shared, writable disk images will be transferred. Unused storage will remain on the origin after migration.": [
  null,
  "完整的磁碟映像檔與該虛擬機器 (domain) 的記憶體將被遷移。將只有非共享、可寫入的磁碟被傳輸。在遷移後未使用的儲存空間會留在原本的主機上。"
 ],
 "General": [
  null,
  "一般"
 ],
 "Generate automatically": [
  null,
  "自動產生"
 ],
 "Get a new RHSM token.": [
  null,
  "取得一個新的 RHSM 權杖。"
 ],
 "GiB": [
  null,
  "GiB"
 ],
 "Go to VMs list": [
  null,
  "移動至虛擬機器清單"
 ],
 "Good choice for desktop virtualization": [
  null,
  "桌面虛擬化的好選擇"
 ],
 "Gracefully shutdown": [
  null,
  "正常關機"
 ],
 "Graphical": [
  null,
  ""
 ],
 "Graphical console support not enabled": [
  null,
  ""
 ],
 "Hardware virtualization is disabled": [
  null,
  "硬體虛擬化已被停用"
 ],
 "Hide additional options": [
  null,
  "隱藏額外動作"
 ],
 "Host": [
  null,
  "主機"
 ],
 "Host device": [
  null,
  "主機裝置"
 ],
 "Host device could not be attached": [
  null,
  "主機裝置無法被附加"
 ],
 "Host device will be removed from $0:": [
  null,
  "主機裝置將從 $0 被移除："
 ],
 "Host devices": [
  null,
  "主機裝置"
 ],
 "Host name": [
  null,
  "主機名稱"
 ],
 "Host should not be empty": [
  null,
  "主機不應為空值"
 ],
 "Hypervisor details": [
  null,
  "虛擬機器管理程式詳細資料"
 ],
 "ID": [
  null,
  "ID"
 ],
 "IP": [
  null,
  "IP"
 ],
 "IP address": [
  null,
  "IP 位址"
 ],
 "IP address must not be empty": [
  null,
  "IP 位址不能為空值"
 ],
 "IP configuration": [
  null,
  "IP 設定"
 ],
 "IPv4 address": [
  null,
  "IPv4 位址"
 ],
 "IPv4 address cannot be same as the network's broadcast address": [
  null,
  "IPv4 位址不能與該網路的廣播位址相同"
 ],
 "IPv4 and IPv6": [
  null,
  "IPv4 與 IPv6"
 ],
 "IPv4 network should not be empty": [
  null,
  "IPv4 網路不應留白"
 ],
 "IPv4 only": [
  null,
  "僅 IPv4"
 ],
 "IPv4 prefix length must be 24 or less": [
  null,
  "IPv4 前綴長度須為 24 或更小"
 ],
 "IPv4 prefix length must be a multiple of 8": [
  null,
  "IPv4 前綴長度須為 8 的倍數"
 ],
 "IPv6 address": [
  null,
  "IPv6 位址"
 ],
 "IPv6 network should not be empty": [
  null,
  "IPv6 網路不能是空值"
 ],
 "IPv6 only": [
  null,
  "僅 IPv6"
 ],
 "Ideal for server VMs": [
  null,
  "適合作為伺服器的虛擬機器"
 ],
 "Ideal networking support": [
  null,
  "理想的網路支援"
 ],
 "Identifier in use by $0. VMs with an identical identifier cannot run at the same time.": [
  null,
  "識別碼正被 $0 使用。無法在同時間執行多個具有相同識別碼的虛擬機器。"
 ],
 "Identifier may be silently truncated to $0 characters ": [
  null,
  "識別碼可能會不經提醒就被截斷至 $0 個字元。 "
 ],
 "Idle": [
  null,
  "閒置"
 ],
 "Ignore": [
  null,
  "忽略"
 ],
 "Import VM": [
  null,
  "匯入虛擬機器"
 ],
 "Import a virtual machine": [
  null,
  "匯入一部虛擬機器"
 ],
 "Import and edit": [
  null,
  "匯入並編輯"
 ],
 "Import and run": [
  null,
  "匯入並執行"
 ],
 "Importing an image with a backing file is unsupported": [
  null,
  "不支援匯入含基底檔案的映像"
 ],
 "In most configurations, macvtap does not work for host to guest network communication.": [
  null,
  "在大多數的設定中，macvtap 無法提供主機到客體間的網路通訊。"
 ],
 "Initiator": [
  null,
  "啟動器"
 ],
 "Initiator should not be empty": [
  null,
  "起動器不應該留白"
 ],
 "Inject a non-maskable interrupt": [
  null,
  "注入非可遮蔽中斷"
 ],
 "Insert": [
  null,
  "插入"
 ],
 "Insert disc media": [
  null,
  "插入光碟媒體"
 ],
 "Inside the VM": [
  null,
  "於虛擬機器內"
 ],
 "Install": [
  null,
  "安裝"
 ],
 "Installation source": [
  null,
  "安裝來源"
 ],
 "Installation source must not be empty": [
  null,
  "安裝來源不得為空值"
 ],
 "Installation type": [
  null,
  "安裝類型"
 ],
 "Interface": [
  null,
  "介面"
 ],
 "Interface type": [
  null,
  "介面類型"
 ],
 "Interface type help": [
  null,
  "介面類型說明"
 ],
 "Invalid IPv4 address": [
  null,
  "無效的 IPv4 位址"
 ],
 "Invalid IPv4 mask or prefix length": [
  null,
  "無效的 IPv4 遮罩或前綴長度"
 ],
 "Invalid IPv6 address": [
  null,
  "無效的 IPv6 位址"
 ],
 "Invalid IPv6 prefix": [
  null,
  "無效的 IPv6 前綴"
 ],
 "Invalid filename": [
  null,
  "無效的檔名"
 ],
 "Isolated network": [
  null,
  "隔離的網路"
 ],
 "It can also be used to enable the inline graphical console in the browser, which does not support SPICE.": [
  null,
  ""
 ],
 "Keys are located in ~/.ssh/ and have a \".pub\" extension.": [
  null,
  "金鑰位於 ~/.ssh/ 且會有 \".pub\" 副檔名。"
 ],
 "LVM volume group": [
  null,
  "LVM 磁碟區群組"
 ],
 "Leave the password blank if you do not wish to have a root account created": [
  null,
  "如果您不想要建立 root 帳號可將密碼留白"
 ],
 "Leave the password blank if you do not wish to have a user account created": [
  null,
  "如果您不想要建立使用者帳號可將密碼留白"
 ],
 "Leave the password blank if you do not wish to set a root password": [
  null,
  "如果您不想要設定 root 密碼可將密碼留白"
 ],
 "Libvirt did not detect any UEFI/OVMF firmware image installed on the host": [
  null,
  "Libvirt 未偵測到主機上有安裝任何 UEFI/OVMF 韌體映像檔"
 ],
 "Libvirt or hypervisor does not support UEFI": [
  null,
  "Libvirt 或虛擬機器管理程式不支援 UEFI"
 ],
 "Loading available network devices": [
  null,
  "正在載入可用的網路裝置"
 ],
 "Loading resources": [
  null,
  "正在載入資源"
 ],
 "Loading...": [
  null,
  "正在載入..."
 ],
 "Local install media (ISO image or distro install tree)": [
  null,
  "本機安裝媒體 (ISO 映像檔或發行版 install tree)"
 ],
 "Location": [
  null,
  "位置"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "MAC address": [
  null,
  "MAC 位址"
 ],
 "MAC address already in use": [
  null,
  "MAC 位址已被使用"
 ],
 "MAC address must not be empty": [
  null,
  "MAC 位址不得為空值"
 ],
 "Machine must be shut off before changing bus type": [
  null,
  "必須先將機器關機才能變更匯流排類型"
 ],
 "Machine must be shut off before changing cache mode": [
  null,
  "必須先將機器關機才能變更快取模式"
 ],
 "Mask or prefix length": [
  null,
  "遮罩或前綴長度"
 ],
 "Mask or prefix length should not be empty": [
  null,
  "遮罩或前綴長度不應為空值"
 ],
 "Maximum allocation": [
  null,
  "最大分配"
 ],
 "Maximum memory could not be saved": [
  null,
  "最大記憶體無法被儲存"
 ],
 "Maximum number of virtual CPUs allocated for the guest OS": [
  null,
  "為客體虛擬機器作業系統所分配的最大虛擬 CPU 數量"
 ],
 "Maximum number of virtual CPUs allocated for the guest OS, which must be between 1 and $0": [
  null,
  "分配給客體作業系統的最大虛擬 CPU 數量，須介於 1 和 $0 之間"
 ],
 "Maximum transmission unit": [
  null,
  "最大傳輸單元"
 ],
 "Media could not be ejected from $0": [
  null,
  "無法從 $0 退出媒體"
 ],
 "Media will be ejected from $0:": [
  null,
  "媒體將從 $0 被退出："
 ],
 "Memory": [
  null,
  "記憶體"
 ],
 "Memory could not be saved": [
  null,
  "記憶體無法被儲存"
 ],
 "Memory must not be 0": [
  null,
  "記憶體不可為 0"
 ],
 "Memory save location can not be empty": [
  null,
  "記憶體儲存位置不得為空值"
 ],
 "Memory snapshot will use about $0.": [
  null,
  "記憶體快照將使用約 $0 。"
 ],
 "Memory state path": [
  null,
  "記憶體狀態路徑"
 ],
 "MiB": [
  null,
  "MiB"
 ],
 "Migrate": [
  null,
  "遷移"
 ],
 "Migrate VM to another host": [
  null,
  "遷移虛擬機器至另一主機"
 ],
 "Migration failed": [
  null,
  "遷移失敗"
 ],
 "Mode": [
  null,
  "模式"
 ],
 "Mode help": [
  null,
  "模式說明"
 ],
 "Model": [
  null,
  "型號"
 ],
 "Model type": [
  null,
  "型號類型"
 ],
 "More info": [
  null,
  "更多資訊"
 ],
 "Mount tag": [
  null,
  "掛載標籤"
 ],
 "Mount tag must not be empty": [
  null,
  "掛載標籤不得為空值"
 ],
 "Must be an address instead of the network identifier, such as $0": [
  null,
  "須為位址而非網路辨識碼，例如 $0"
 ],
 "NAT to $0": [
  null,
  "NAT 至 $0"
 ],
 "NIC $0 of VM $1 failed to change state": [
  null,
  "虛擬機器 $1 的網路卡 $0 變更狀態失敗"
 ],
 "Name": [
  null,
  "名稱"
 ],
 "Name already exists": [
  null,
  "名稱已經存在"
 ],
 "Name can not be empty": [
  null,
  "名稱不得為空值"
 ],
 "Name contains invalid characters": [
  null,
  "名稱含有無效的字元"
 ],
 "Name must not be empty": [
  null,
  "名稱不能為空值"
 ],
 "Name should not be empty": [
  null,
  "名稱不應為空"
 ],
 "Name: ": [
  null,
  "名稱： "
 ],
 "Netmask": [
  null,
  "網路遮罩"
 ],
 "Network $0 could not be deleted": [
  null,
  "網路 $0 無法被刪除"
 ],
 "Network $0 failed to get activated": [
  null,
  "網路 $0 無法被啟用"
 ],
 "Network $0 failed to get deactivated": [
  null,
  "網路 $0 無法被停用"
 ],
 "Network $0 will be permanently deleted.": [
  null,
  "網路 $0 將被永遠刪除。"
 ],
 "Network boot (PXE)": [
  null,
  "網路開機 (PXE)"
 ],
 "Network file system": [
  null,
  "網絡檔案系統"
 ],
 "Network interface": [
  null,
  "網路介面"
 ],
 "Network interface $0 could not be removed": [
  null,
  "網路介面 $0 無法被移除"
 ],
 "Network interface $0 will be removed from $1": [
  null,
  "網路界面 $0 將被從 $1 移除"
 ],
 "Network interface settings could not be saved": [
  null,
  "網路介面設定無法被儲存"
 ],
 "Network interfaces": [
  null,
  "網路介面"
 ],
 "Network selection does not support PXE.": [
  null,
  "所選網路不支援 PXE。"
 ],
 "Networks": [
  null,
  "網路"
 ],
 "New name": [
  null,
  "新名稱"
 ],
 "New name must not be empty": [
  null,
  "新名稱不得為空值"
 ],
 "New volume name": [
  null,
  "新磁碟區名稱"
 ],
 "No SSH keys specified": [
  null,
  "沒有指定 SSH 金鑰"
 ],
 "No VM is running or defined on this host": [
  null,
  "此主機上沒有已定義或執行中的虛擬機器"
 ],
 "No boot device found": [
  null,
  "找不到開機裝置"
 ],
 "No description": [
  null,
  "無描述"
 ],
 "No directories shared between the host and this VM": [
  null,
  "主機與此虛擬機器之間沒有共享目錄"
 ],
 "No disks defined for this VM": [
  null,
  "沒有為此虛擬機器定義磁碟"
 ],
 "No host device selected": [
  null,
  "未選擇主機裝置"
 ],
 "No host devices assigned to this VM": [
  null,
  "未指派主機裝置給此虛擬機器"
 ],
 "No network devices": [
  null,
  "沒有網路裝置"
 ],
 "No network interfaces defined for this VM": [
  null,
  "沒有為此虛擬機器定義的網路介面"
 ],
 "No network is defined on this host": [
  null,
  "此主機上沒有定義網路"
 ],
 "No networks available": [
  null,
  "沒有可用的網路"
 ],
 "No parent": [
  null,
  "無上層"
 ],
 "No snapshots defined for this VM": [
  null,
  "此虛擬機器沒有已定義的快照"
 ],
 "No state": [
  null,
  "沒有狀態"
 ],
 "No storage": [
  null,
  "沒有儲存空間"
 ],
 "No storage pool is defined on this host": [
  null,
  "此主機上沒有已定義的儲存集區"
 ],
 "No storage pools available": [
  null,
  "沒有可用的儲存集區"
 ],
 "No storage volumes defined for this storage pool": [
  null,
  "此儲存集區沒有已定義的儲存磁碟區"
 ],
 "No virtual networks": [
  null,
  "沒有虛擬網路"
 ],
 "No volumes exist in this storage pool.": [
  null,
  "此儲存集區沒有既存的磁碟區。"
 ],
 "Non-persistent network cannot be deleted. It ceases to exists when it's deactivated.": [
  null,
  "非持續性的網路不能被刪除。它會在被停用後自然消失。"
 ],
 "Non-persistent storage pool cannot be deleted. It ceases to exists when it's deactivated.": [
  null,
  "非持續性的儲存集區不能被刪除。它會在被停用後自然消失。"
 ],
 "None": [
  null,
  "無"
 ],
 "None (isolated network)": [
  null,
  "無 （隔離的網路）"
 ],
 "Offline token": [
  null,
  "離線權杖"
 ],
 "Offline token must not be empty": [
  null,
  "離線權杖不得為空值"
 ],
 "Old token expired": [
  null,
  "舊的權杖已過期"
 ],
 "On the host": [
  null,
  "於主機上"
 ],
 "One or more selected volumes are used by domains. Detach the disks first to allow volume deletion.": [
  null,
  "一或多個所選的磁碟區正在被虛擬機器使用。先將磁碟拆離以允許刪除磁碟區。"
 ],
 "Only editable when the guest is shut off": [
  null,
  "只有在客體被關閉後才能編輯"
 ],
 "Open": [
  null,
  "開放"
 ],
 "Operating system": [
  null,
  "作業系統"
 ],
 "Operation is in progress": [
  null,
  "作業正在進行"
 ],
 "Other VMs using SPICE": [
  null,
  "其他使用 SPICE 的虛擬機器"
 ],
 "Overview": [
  null,
  "概覽"
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "Parent snapshot": [
  null,
  "上層快照"
 ],
 "Password must be 8 characters or less. VNC passwords do not provide encryption and are generally cryptographically weak. They can not be used to secure connections in untrusted networks.": [
  null,
  ""
 ],
 "Password must be at most 8 characters.": [
  null,
  ""
 ],
 "Path": [
  null,
  "路徑"
 ],
 "Path on host's filesystem": [
  null,
  "主機檔案系統上的路徑"
 ],
 "Path to ISO file on host's file system": [
  null,
  "主機檔案系統上 ISO 檔案的路徑"
 ],
 "Path to cloud image file on host's file system": [
  null,
  "主機檔案系統上雲端映像 (cloud image) 檔案的路徑"
 ],
 "Path to directory": [
  null,
  "目錄的路徑"
 ],
 "Path to file on host's file system": [
  null,
  "主機檔案系統上檔案的路徑"
 ],
 "Pause": [
  null,
  "暫停"
 ],
 "Paused": [
  null,
  "已暫停"
 ],
 "Permanent (default)": [
  null,
  "永久（預設）"
 ],
 "Permissions denied for disk images in home directories": [
  null,
  "存取家目錄中的磁碟映像檔時權限被拒"
 ],
 "Persistence": [
  null,
  "持續性"
 ],
 "Persistent": [
  null,
  "持續的"
 ],
 "Physical disk device": [
  null,
  "實體磁碟裝置"
 ],
 "Physical disk device on host": [
  null,
  "主機上的實體磁碟裝置"
 ],
 "Please choose a different MAC address": [
  null,
  "請選擇一個不同的 MAC 位址"
 ],
 "Please choose a storage pool": [
  null,
  "請選擇一個儲存集區"
 ],
 "Please choose a volume": [
  null,
  "請選擇一個磁碟區"
 ],
 "Please enter new volume name": [
  null,
  "請輸入新的磁碟區名稱"
 ],
 "Please see $0 how to reconfigure your VM manually.": [
  null,
  "請參閱 $0 以了解如何手動重新設定您的虛擬機器。"
 ],
 "Pool": [
  null,
  "集區"
 ],
 "Pool needs to be active to create volume": [
  null,
  "集區須為啟用狀態才能建立磁碟區"
 ],
 "Pool type $0 does not support volume creation": [
  null,
  "集區類型 $0 不支援建立磁碟區"
 ],
 "Pool type doesn't support volume creation": [
  null,
  "集區類型不支援建立磁碟區"
 ],
 "Pool's volumes are used by VMs ": [
  null,
  "集區的磁碟區正被用於虛擬機器 "
 ],
 "Port": [
  null,
  "連接埠"
 ],
 "Port must be 5900 or larger.": [
  null,
  ""
 ],
 "Port must be a number that is at least 5900. Leave empty to automatically assign a free port when the machine starts.": [
  null,
  ""
 ],
 "Power off": [
  null,
  "電源關閉"
 ],
 "Pre-formatted block device": [
  null,
  "已預先格式化的區塊裝置"
 ],
 "Preferred number of sockets to expose to the guest.": [
  null,
  "要向客體虛擬機公開的 socket 數量。"
 ],
 "Prefix": [
  null,
  "前綴"
 ],
 "Prefix length": [
  null,
  "前綴長度"
 ],
 "Prefix length should not be empty": [
  null,
  "前綴長度不應為空值"
 ],
 "Previously taken snapshots allow you to revert to an earlier state if something goes wrong": [
  null,
  "先前建立的快照允許您在發生意外時還原到先前的狀態"
 ],
 "Private": [
  null,
  "私有"
 ],
 "Product": [
  null,
  "產品"
 ],
 "Profile": [
  null,
  "設定檔"
 ],
 "Protocol": [
  null,
  "協定"
 ],
 "Provides a bridge from the guest virtual machine directly onto the LAN. This needs a bridge device on the host with one or more physical NICs.": [
  null,
  "提供一個從虛擬機器客端直接連至區域網路的橋接。需要一個於主機上具一或多個實體網路卡的橋接裝置。"
 ],
 "Provides a connection whose details are described by the named network definition.": [
  null,
  "提供一個由指定名稱網路定義描述詳細資料的連線。"
 ],
 "Provides a virtual LAN with NAT to the outside world.": [
  null,
  "提供一個具可連線至外界的 NAT 的虛擬區域網路。"
 ],
 "Public SSH key": [
  null,
  "公開 SSH 金鑰"
 ],
 "Public key": [
  null,
  "公鑰"
 ],
 "Range": [
  null,
  "範圍"
 ],
 "Read-only": [
  null,
  "唯讀"
 ],
 "Reboot": [
  null,
  "重新開機"
 ],
 "Reboot $0?": [
  null,
  "將 $0 重新開機？"
 ],
 "Recommended operating systems": [
  null,
  "推薦的作業系統"
 ],
 "Released $0": [
  null,
  "於 $0 發行"
 ],
 "Remote URL": [
  null,
  "遠端 URL"
 ],
 "Remote viewer applications can connect to the following address:": [
  null,
  ""
 ],
 "Remove": [
  null,
  "移除"
 ],
 "Remove SPICE audio and host devices": [
  null,
  "移除 SPICE 音訊與主機裝置"
 ],
 "Remove and delete file": [
  null,
  "移除並刪除檔案"
 ],
 "Remove disk from VM?": [
  null,
  "從虛擬機器移除磁碟？"
 ],
 "Remove filesystem?": [
  null,
  "移除檔案系統？"
 ],
 "Remove host device from VM?": [
  null,
  "從虛擬機器移除主機裝置？"
 ],
 "Remove item": [
  null,
  "移除項目"
 ],
 "Remove network interface?": [
  null,
  "移除網路介面？"
 ],
 "Remove static host from DHCP": [
  null,
  "從 DHCP 移除靜態主機"
 ],
 "Rename": [
  null,
  "重新命名"
 ],
 "Rename VM $0": [
  null,
  "重新命名虛擬機器 $0"
 ],
 "Replace": [
  null,
  "取代"
 ],
 "Replace SPICE devices": [
  null,
  "取代 SPICE 裝置"
 ],
 "Replace SPICE devices in VM $0": [
  null,
  "取代虛擬機器 $0 中的 SPICE 裝置"
 ],
 "Replace SPICE on selected VMs.": [
  null,
  "取代所選擇虛擬機器中的 SPICE。"
 ],
 "Replace SPICE on the virtual machine.": [
  null,
  "取代虛擬機器上的 SPICE。"
 ],
 "Reset": [
  null,
  "重置"
 ],
 "Restrictions in networking (SLIRP-based emulation) and PCI device assignment": [
  null,
  "網路實作 (基於 SLIRP 的模擬方式) 與 PCI 裝置指派的限制"
 ],
 "Resume": [
  null,
  "恢復執行"
 ],
 "Revert": [
  null,
  "還原"
 ],
 "Revert to snapshot $0": [
  null,
  "還原至快照 $0"
 ],
 "Reverting to this snapshot will take the VM back to the time of the snapshot and the current state will be lost, along with any data not captured in a snapshot": [
  null,
  "還原至此快照將把虛擬機器倒退回快照當時的狀態，且會遺失目前的狀態與任何未儲存於快照的資料"
 ],
 "Root password": [
  null,
  "Root 密碼"
 ],
 "Route to $0": [
  null,
  "路由到 $0"
 ],
 "Routed network": [
  null,
  "經路由的網路"
 ],
 "Row select": [
  null,
  "選擇列"
 ],
 "Run": [
  null,
  "執行"
 ],
 "Run when host boots": [
  null,
  "在主機開機時執行"
 ],
 "Running": [
  null,
  "執行中"
 ],
 "SPICE": [
  null,
  "SPICE"
 ],
 "SPICE conversion": [
  null,
  "SPICE 轉換"
 ],
 "SPICE is not supported on this host and will cause this virtual machine to not boot.": [
  null,
  "此主機不支援 SPICE 且將會使此虛擬機器無法開機。"
 ],
 "SSH keys": [
  null,
  "SSH 金鑰"
 ],
 "Save": [
  null,
  "儲存"
 ],
 "Select all": [
  null,
  "全選"
 ],
 "Send key": [
  null,
  "傳送按鍵"
 ],
 "Send non-maskable interrupt": [
  null,
  "發送不可屏蔽中斷"
 ],
 "Send non-maskable interrupt to $0?": [
  null,
  "對 $0 送出非可遮蔽中斷？"
 ],
 "Serial": [
  null,
  "序號"
 ],
 "Serial console": [
  null,
  "序列控制台"
 ],
 "Serial console support not enabled": [
  null,
  ""
 ],
 "Set DHCP range": [
  null,
  "設定 DHCP 範圍"
 ],
 "Set manually": [
  null,
  "手動設定"
 ],
 "Setting the user passwords for unattended installation requires starting the VM when creating it": [
  null,
  "欲設定無人式安裝時的使用者密碼，需要在建立虛擬機器時即啟動它"
 ],
 "Share": [
  null,
  "共享"
 ],
 "Share a host directory with the guest": [
  null,
  "與客體共享主機的目錄"
 ],
 "Shared directories": [
  null,
  "共享的目錄"
 ],
 "Shared host directories need to be manually mounted inside the VM": [
  null,
  "共享的主機目錄須手動於虛擬機器內掛載"
 ],
 "Shared storage": [
  null,
  "共享儲存裝置"
 ],
 "Show additional options": [
  null,
  "顯示額外選項"
 ],
 "Show less": [
  null,
  "顯示較少"
 ],
 "Show more": [
  null,
  "顯示更多"
 ],
 "Shut down": [
  null,
  "關機"
 ],
 "Shut down $0?": [
  null,
  "將 $0 關機？"
 ],
 "Shut off": [
  null,
  "已關閉"
 ],
 "Shut off the VM in order to edit firmware configuration": [
  null,
  "將虛擬機器關機以編輯韌體設定"
 ],
 "Shutting down": [
  null,
  "正在關機"
 ],
 "Size": [
  null,
  "大小"
 ],
 "Slot": [
  null,
  "插槽"
 ],
 "Snapshot $0 could not be deleted": [
  null,
  "快照 $0 無法被刪除"
 ],
 "Snapshot $0 will be deleted from $1. All of its captured content will be lost.": [
  null,
  "快照 $0 將被從 $1 刪除。所有其儲存的內容將會遺失。"
 ],
 "Snapshot failed to be created": [
  null,
  "快照建立失敗"
 ],
 "Snapshots": [
  null,
  "快照"
 ],
 "Sockets": [
  null,
  "插槽"
 ],
 "Some configuration changes only take effect after a fresh boot:": [
  null,
  "部份設定變更僅在下一次完整重新開機後生效："
 ],
 "Source": [
  null,
  "來源"
 ],
 "Source format": [
  null,
  "來源格式"
 ],
 "Source must not be empty": [
  null,
  "來源不可為空值"
 ],
 "Source path": [
  null,
  "來源路徑"
 ],
 "Source path should not be empty": [
  null,
  "來源路徑不應為空"
 ],
 "Source should start with http, ftp or nfs protocol": [
  null,
  "來源應為 http、ftp 或 nfs 協定開頭"
 ],
 "Source volume group": [
  null,
  "來源磁碟區群組"
 ],
 "Start": [
  null,
  "開始"
 ],
 "Start pool when host boots": [
  null,
  "主機開機時就啟動集區"
 ],
 "Start should not be empty": [
  null,
  "開始不得為空值"
 ],
 "Started": [
  null,
  "已啟動"
 ],
 "Startup": [
  null,
  "啟動"
 ],
 "State": [
  null,
  "狀態"
 ],
 "Static host entries": [
  null,
  "靜態主機項目"
 ],
 "Static host from DHCP could not be removed": [
  null,
  "來自 DHCP 的靜態主機無法被移除"
 ],
 "Storage": [
  null,
  "儲存空間"
 ],
 "Storage is at a shared location": [
  null,
  "儲存空間位於共享的位置"
 ],
 "Storage limit": [
  null,
  "儲存空間限制"
 ],
 "Storage pool $0 failed to get activated": [
  null,
  "儲存集區 $0 啟用失敗"
 ],
 "Storage pool $0 failed to get deactivated": [
  null,
  "儲存集區 $0 停用失敗"
 ],
 "Storage pool failed to be created": [
  null,
  "儲存集區建立失敗"
 ],
 "Storage pool name": [
  null,
  "儲存集區名稱"
 ],
 "Storage pools": [
  null,
  "儲存集區"
 ],
 "Storage pools could not be fetched": [
  null,
  "無法取得儲存集區"
 ],
 "Storage size must not be 0": [
  null,
  "儲存空間大小必須不為 0"
 ],
 "Storage volume": [
  null,
  "儲存磁碟區"
 ],
 "Storage volume size must not exceed the storage pool's capacity ($0 $1)": [
  null,
  "儲存磁碟區大小必須不超過儲存集區的容量 ($0 $1)"
 ],
 "Storage volumes": [
  null,
  "儲存空間磁碟區"
 ],
 "Storage volumes could not be deleted": [
  null,
  "儲存磁碟區無法被刪除"
 ],
 "Storage volumes must be shared between this host and the destination host.": [
  null,
  "儲存磁碟區必須於此主機與目標主機間共享。"
 ],
 "Successfully copied to clipboard!": [
  null,
  ""
 ],
 "Suspended (PM)": [
  null,
  "暫停中（PM）"
 ],
 "Switch to VNC to continue using this machine.": [
  null,
  "切換至 VNC 以繼續使用此機器。"
 ],
 "System": [
  null,
  "系統"
 ],
 "TAP device": [
  null,
  "TAP 裝置"
 ],
 "TPM": [
  null,
  "TPM"
 ],
 "Table of selectable host devices": [
  null,
  "可選擇的主機裝置列表"
 ],
 "Target": [
  null,
  "目標"
 ],
 "Target path": [
  null,
  "目標路徑"
 ],
 "Target path should not be empty": [
  null,
  "目標路徑不應為空"
 ],
 "Temporary": [
  null,
  "暫時的"
 ],
 "Temporary migration": [
  null,
  "暫時性遷移"
 ],
 "The VM $0 is running and will be forced off before deletion.": [
  null,
  "虛擬機器 $0 正在執行中，將在刪除前被強制關閉。"
 ],
 "The VM needs to be running or shut off to detach this device": [
  null,
  "虛擬機器須為執行中或已關閉，才能拆離此裝置"
 ],
 "The directory on the server being exported": [
  null,
  "正被匯出的伺服器上的目錄"
 ],
 "The host path that is to be exported.": [
  null,
  "要被匯出的主機路徑。"
 ],
 "The migrated VM configuration is removed from the source host. The destination host is considered the new home of the VM.": [
  null,
  "將從來源主機移除被遷移的虛擬機器設定。目標主機將會被作為虛擬機器的新家。"
 ],
 "The mode influences the delivery of packets.": [
  null,
  "模式會影響封包的傳遞。"
 ],
 "The pool is empty": [
  null,
  "集區是空的"
 ],
 "The selected operating system has minimum memory requirement of $0 $1": [
  null,
  "所選擇的作業系統有著最低 $0 $1 的記憶體要求"
 ],
 "The selected operating system has minimum storage size requirement of $0 $1": [
  null,
  "所選擇的作業系統有著最低 $0 $1 儲存空間大小的需求"
 ],
 "The static host entry for $0 will be removed:": [
  null,
  "$0 的靜態主機項目將會被移除："
 ],
 "The storage pool could not be deleted": [
  null,
  "儲存集區無法被刪除"
 ],
 "The tag name to be used by the guest to mount this export point.": [
  null,
  "用於讓客體掛載此匯出點的標籤名稱。"
 ],
 "Then copy and paste it above.": [
  null,
  "然後複製並於上方貼上。"
 ],
 "This VM is transient. Shut it down if you wish to delete it.": [
  null,
  "此虛擬機器是暫時的。如果想要刪除它，將其關機即可。"
 ],
 "This disk will be removed from $0:": [
  null,
  "此磁碟將從 $0 被移除："
 ],
 "This filesystem will be removed from $0:": [
  null,
  "此檔案系統將從 $0 被移除："
 ],
 "This is intended for a host which does not support SPICE due to upgrades or live migration.": [
  null,
  "這適用於因為升級或動態遷移後不支援 SPICE 的主機。"
 ],
 "This is the recommended type for general guest connectivity on hosts with dynamic / wireless networking configs.": [
  null,
  "這是在具動態或無線網路的主機上提供一般客體連線能力的建議類型。"
 ],
 "This is the recommended type for general guest connectivity on hosts with static wired networking configs.": [
  null,
  "這是在具靜態有線網路主機上提供一般客體連線能力的建議類型。"
 ],
 "This is the recommended type for high performance or enhanced security.": [
  null,
  "這是為了高效能或更佳安全性的建議類型。"
 ],
 "This machine has a SPICE graphical console that can not be shown here.": [
  null,
  ""
 ],
 "This volume is already used by $0.": [
  null,
  "此磁碟區已被用於 $0 。"
 ],
 "This volume is already used by another VM.": [
  null,
  "此磁碟區已被用於其他虛擬機器。"
 ],
 "Threads per core": [
  null,
  "每個核心的執行緒數量"
 ],
 "Total space available: $0.": [
  null,
  "總共可用空間： $0 。"
 ],
 "Transient VMs don't support editing firmware configuration": [
  null,
  "暫時性虛擬機器不支援修改韌體設定"
 ],
 "Troubleshoot": [
  null,
  "疑難排解"
 ],
 "Type": [
  null,
  "類型"
 ],
 "URL (ISO image or distro install tree)": [
  null,
  "URL (ISO 映像或發行版 install tree)"
 ],
 "USB": [
  null,
  "USB"
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Undefined": [
  null,
  "未定義"
 ],
 "Unique name": [
  null,
  "唯一名稱"
 ],
 "Unique name, default: $0": [
  null,
  "具唯一性名稱，預設： $0"
 ],
 "Unique network name": [
  null,
  "唯一的網路名稱"
 ],
 "Unit": [
  null,
  "單位"
 ],
 "Unknown": [
  null,
  "不明"
 ],
 "Unknown firmware": [
  null,
  "未知韌體"
 ],
 "Unspecified": [
  null,
  "未指定"
 ],
 "Unsupported and older operating systems": [
  null,
  "未受支援與舊版作業系統"
 ],
 "Url": [
  null,
  "Url"
 ],
 "Usage": [
  null,
  "使用率"
 ],
 "Use existing": [
  null,
  "利用現有的"
 ],
 "Use extended attributes on files and directories": [
  null,
  "於檔案與目錄使用延伸屬性"
 ],
 "Use the same location on both the origin and destination hosts for your storage. This can be a shared storage pool, NFS, or any other method of sharing storage.": [
  null,
  "在來源與目標主機上使用相同的位址作為儲存空間。可以是共享儲存集區、NFS 或任何其他共享儲存空間的方式。"
 ],
 "Used": [
  null,
  "已使用"
 ],
 "Used by": [
  null,
  "使用於"
 ],
 "User login": [
  null,
  "使用者登入"
 ],
 "User login must not be empty when SSH keys are set": [
  null,
  "當SSH 金鑰已設定時，使用者登入不可為空值"
 ],
 "User login must not be empty when user password is set": [
  null,
  "當使用者密碼已設定時，使用者登入不可為空值"
 ],
 "User password": [
  null,
  "使用者密碼"
 ],
 "User password must not be empty when user login is set": [
  null,
  "當使用者登入已設定時，使用者密碼不可為空值"
 ],
 "User session": [
  null,
  "使用者工作階段"
 ],
 "Uses SPICE": [
  null,
  "使用 SPICE"
 ],
 "VM $0 Host Devices": [
  null,
  "虛擬機器 $0 的主機裝置"
 ],
 "VM $0 already exists": [
  null,
  "虛擬機器 $0 已經存在"
 ],
 "VM $0 does not exist on $1 connection": [
  null,
  "虛擬機器 $0 不存在於 $1 連線"
 ],
 "VM $0 failed to force reboot": [
  null,
  "虛擬機器 $0 強制重開機失敗"
 ],
 "VM $0 failed to force shutdown": [
  null,
  "虛擬機器 $0 強制關機失敗"
 ],
 "VM $0 failed to get installed": [
  null,
  "虛擬機器 $0 安裝失敗"
 ],
 "VM $0 failed to pause": [
  null,
  "虛擬機器 $0 暫停失敗"
 ],
 "VM $0 failed to reboot": [
  null,
  "虛擬機器 $0 重新開機失敗"
 ],
 "VM $0 failed to resume": [
  null,
  "虛擬機器 $0 恢復執行失敗"
 ],
 "VM $0 failed to send NMI": [
  null,
  "虛擬機器 $0 發送 NMI 失敗"
 ],
 "VM $0 failed to shutdown": [
  null,
  "虛擬機器 $0 關機失敗"
 ],
 "VM $0 failed to start": [
  null,
  "虛擬機器 $0 啟動失敗"
 ],
 "VM launched with unprivileged limited access, with the process and PTY owned by your user account": [
  null,
  "虛擬機器以無特權的限制存取模式啟動，其處理程序及 PTY 皆由您的使用者帳號所擁有"
 ],
 "VM needs shutdown": [
  null,
  "虛擬機器需要關機"
 ],
 "VM state": [
  null,
  "虛擬機器狀態"
 ],
 "VM will launch with root permissions": [
  null,
  "虛擬機器將以 root 權限啟動"
 ],
 "VNC": [
  null,
  ""
 ],
 "Valid token": [
  null,
  "有效的權杖"
 ],
 "Vendor": [
  null,
  "供應商"
 ],
 "Vendor support ended $0": [
  null,
  "原廠支援已於 $0 終止"
 ],
 "Virtual machines": [
  null,
  "虛擬機器"
 ],
 "Virtual machines management": [
  null,
  "虛擬機器管理"
 ],
 "Virtual network": [
  null,
  "虛擬網路"
 ],
 "Virtual network failed to be created": [
  null,
  "虛擬網路建立失敗"
 ],
 "Virtual socket support enables communication between the host and guest over a socket. It still requires special vsock-aware software to communicate over the socket.": [
  null,
  "虛擬 socket 支援可讓主機與客體透過一個 socket 溝通。仍需要支援 vock 的特殊軟體以在 socket 上通訊。"
 ],
 "Virtualization service (libvirt) is not active": [
  null,
  "虛擬化服務（libvirt）未啟動"
 ],
 "Volume": [
  null,
  "磁碟區"
 ],
 "Volume failed to be created": [
  null,
  "建立磁碟區失敗"
 ],
 "Volume group name": [
  null,
  "磁碟區群組名稱"
 ],
 "Volume group name should not be empty": [
  null,
  "磁碟區群組名稱不得為空值"
 ],
 "Vsock": [
  null,
  "Vsock"
 ],
 "WWPN": [
  null,
  "WWPN"
 ],
 "Watchdog": [
  null,
  "看門狗"
 ],
 "Watchdogs act when systems stop responding. To use this virtual watchdog device, the guest system also needs to have an additional driver and a running watchdog service.": [
  null,
  "看門狗將在系統停止回應時採取行動。若要使用此虛擬 watchdog 裝置，客體作業系統也需要有額外的驅動程式與執行中的 watchdog 服務。"
 ],
 "Writeable": [
  null,
  "可寫入"
 ],
 "You can mount the shared folder using:": [
  null,
  "您可以用以下指令掛載共享資料夾："
 ],
 "You need to select the most closely matching operating system": [
  null,
  "您需要選擇最相近的作業系統"
 ],
 "active": [
  null,
  "已啟用"
 ],
 "add": [
  null,
  "新增"
 ],
 "add entry": [
  null,
  "新增項目"
 ],
 "bridge": [
  null,
  "橋接"
 ],
 "cdrom": [
  null,
  "cdrom光碟"
 ],
 "custom": [
  null,
  "自訂"
 ],
 "direct": [
  null,
  "直接"
 ],
 "disabled": [
  null,
  "已停用"
 ],
 "disk": [
  null,
  "磁碟"
 ],
 "down": [
  null,
  "已切斷"
 ],
 "edit": [
  null,
  "編輯"
 ],
 "enabled": [
  null,
  "已啟用"
 ],
 "ethernet": [
  null,
  "乙太網路"
 ],
 "host": [
  null,
  "主機"
 ],
 "host device": [
  null,
  "主機裝置"
 ],
 "host passthrough": [
  null,
  "主機直通"
 ],
 "hostdev": [
  null,
  "hostdev"
 ],
 "iSCSI direct target": [
  null,
  "iSCSI direct target"
 ],
 "iSCSI initiator IQN": [
  null,
  "iSCSI initiator IQN"
 ],
 "iSCSI target": [
  null,
  "iSCSI target"
 ],
 "iSCSI target IQN": [
  null,
  "iSCSI target IQN"
 ],
 "inactive": [
  null,
  "已停用"
 ],
 "inet": [
  null,
  "inet"
 ],
 "inet6": [
  null,
  "inet6"
 ],
 "mcast": [
  null,
  "mcast"
 ],
 "more info": [
  null,
  "更多資訊"
 ],
 "mount point: The mount point inside the guest": [
  null,
  "掛載點： 客體內的掛載點"
 ],
 "mount tag: The tag associated to the exported mount point": [
  null,
  "掛載標籤： 與匯出的掛載點相連的標籤"
 ],
 "network": [
  null,
  "網絡"
 ],
 "no": [
  null,
  "否"
 ],
 "no state saved": [
  null,
  "沒有已儲存的狀態"
 ],
 "none": [
  null,
  "無"
 ],
 "redirected device": [
  null,
  "重新導向的裝置"
 ],
 "remove": [
  null,
  "移除"
 ],
 "serial number": [
  null,
  "序號"
 ],
 "server": [
  null,
  "伺服器"
 ],
 "udp": [
  null,
  "udp"
 ],
 "up": [
  null,
  "已連線"
 ],
 "user": [
  null,
  "使用者"
 ],
 "vCPU and CPU topology settings could not be saved": [
  null,
  "無法儲存 vCPU 與 CPU 拓樸設定"
 ],
 "vCPU count": [
  null,
  "vCPU 數量"
 ],
 "vCPU maximum": [
  null,
  "vCPU 最大值"
 ],
 "vCPUs": [
  null,
  "vCPUs"
 ],
 "vhostuser": [
  null,
  "vhostuser"
 ],
 "view more...": [
  null,
  "檢視更多..."
 ],
 "virt-install package needs to be installed on the system in order to clone VMs": [
  null,
  "須在系統上安裝 virt-install 軟體包以拓製虛擬機器"
 ],
 "virt-install package needs to be installed on the system in order to create new VMs": [
  null,
  "須在系統上安裝 virt-install 軟體包以建立新的虛擬機器"
 ],
 "virt-install package needs to be installed on the system in order to edit this attribute": [
  null,
  "須在系統上安裝 virt-install 軟體包以編輯此特性"
 ],
 "vsock requires special software": [
  null,
  "vsock 需要特殊的軟體"
 ],
 "yes": [
  null,
  "是"
 ]
});
