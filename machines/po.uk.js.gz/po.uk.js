cockpit.locale({
 "": {
  "plural-forms": (n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "uk",
  "language-direction": "ltr"
 },
 "$0 $1 available at default location": [
  null,
  "$0 $1 доступно у типовому місці"
 ],
 "$0 $1 available on host": [
  null,
  "$0 $1 доступно в основній системі"
 ],
 "$0 CPU details": [
  null,
  "Подробиці щодо процесора $0"
 ],
 "$0 Network": [
  null,
  "$0 мережа",
  "$0 мережі",
  "$0 мереж"
 ],
 "$0 Storage pool": [
  null,
  "$0 буфер сховища",
  "$0 буфери сховищ",
  "$0 буферів сховищ"
 ],
 "$0 does not support unattended installation.": [
  null,
  "Для $0 не передбачено підтримки автоматичного встановлення."
 ],
 "$0 memory adjustment": [
  null,
  "Коригування пам'яті $0"
 ],
 "$0 network": [
  null,
  "Мережа $0"
 ],
 "$0 vCPU": [
  null,
  "$0 вірт. проц.",
  "$0 вірт. проц.",
  "$0 вірт. проц."
 ],
 "$0 virtual network interface settings": [
  null,
  "Параметри інтерфейсу віртуальної мережі $0"
 ],
 "A copy of the VM will run on the destination and will disappear when it is shut off. Meanwhile, the origin host keeps its copy of the VM configuration.": [
  null,
  "Копія ВМ працюватиме у системі призначення і зникне, коли її буде вимкнено. Тим часом основна система походження зберігатиме власну копію налаштувань ВМ."
 ],
 "Access": [
  null,
  "Доступ"
 ],
 "Action": [
  null,
  "Дія"
 ],
 "Actions": [
  null,
  "Дії"
 ],
 "Activate": [
  null,
  "Задіяти"
 ],
 "Activate the storage pool to administer volumes": [
  null,
  "Активувати буфер зберігання даних для адміністрування томів"
 ],
 "Add": [
  null,
  "Додати"
 ],
 "Add SSH keys": [
  null,
  "Додати ключі SSH"
 ],
 "Add TPM": [
  null,
  "Додати TPM"
 ],
 "Add VNC": [
  null,
  "Додати VNC"
 ],
 "Add a DHCP static host entry": [
  null,
  "Додати запис статичного вузла DHCP"
 ],
 "Add disk": [
  null,
  "Додати диск"
 ],
 "Add host device": [
  null,
  "Додати пристрій основної системи"
 ],
 "Add network interface": [
  null,
  "Додати інтерфейс мережі"
 ],
 "Add serial console": [
  null,
  "Додати послідовну консоль"
 ],
 "Add shared directory": [
  null,
  "Додати спільний каталог"
 ],
 "Add virtual network interface": [
  null,
  "Додати інтерфейс віртуальної мережі"
 ],
 "Add vsock interface": [
  null,
  "Додати інтерфейс vsock"
 ],
 "Add watchdog device type": [
  null,
  "Додати тип пристрою нагляду"
 ],
 "Adding a watchdog will require a reboot to take effect.": [
  null,
  "Для набуття чинності додавання засобу спостереження систему слід перезавантажити."
 ],
 "Adding shared directories is possible only when the guest is shut off": [
  null,
  "Додавання спільних каталогів можливе, лише якщо гостьову систему вимкнено"
 ],
 "Additional": [
  null,
  "Додаткові"
 ],
 "Address": [
  null,
  "Адреса"
 ],
 "Address not within subnet": [
  null,
  "Адреса поза межами підмережі"
 ],
 "All": [
  null,
  "Всі"
 ],
 "All VM activity, including storage, will be temporary. This will result in data loss on the destination host.": [
  null,
  "Уся робота ВМ, зокрема зі сховищем даних, буде тимчасовою. Це призведе до втрати даних на основній системі призначення."
 ],
 "Allowed characters: basic Latin alphabet, numbers, and limited punctuation (-, _, +, .)": [
  null,
  "Дозволені символи: основна латинка, цифри та деякі символи пунктуації (-, _, +, .)"
 ],
 "Also delete all volumes inside this pool:": [
  null,
  "Також вилучити усі томи у цьому буфері:"
 ],
 "Always attach": [
  null,
  "Завжди долучати"
 ],
 "An example of vsock-aware software is socat": [
  null,
  "Прикладом сумісного з vsock програмного забезпечення є socat"
 ],
 "Apply": [
  null,
  "Застосувати"
 ],
 "Apply on next boot": [
  null,
  "Застосувати під час наступного завантаження"
 ],
 "Assign automatically": [
  null,
  "Призначити автоматично"
 ],
 "Automated installs are only available when downloading an image or using cloud-init.": [
  null,
  "Автоматичне встановлення є доступним лише при отримання образу або використанні cloud-init."
 ],
 "Automatic": [
  null,
  "Автоматично"
 ],
 "Automation": [
  null,
  "Автоматизація"
 ],
 "Autostart": [
  null,
  "Автозапуск"
 ],
 "Block device": [
  null,
  "Блоковий пристрій"
 ],
 "Blocked": [
  null,
  "Заблоковано"
 ],
 "Boot order": [
  null,
  "Порядок завантаження"
 ],
 "Boot order settings could not be saved": [
  null,
  "Не вдалося зберегти параметри порядку завантаження"
 ],
 "Bus": [
  null,
  "Канал"
 ],
 "CD/DVD disc": [
  null,
  "Диск CD/DVD"
 ],
 "CPU": [
  null,
  "Процесор"
 ],
 "CPU mode could not be saved": [
  null,
  "Не вдалося зберегти режим процесора"
 ],
 "Cache": [
  null,
  "Кеш"
 ],
 "Cancel": [
  null,
  "Скасувати"
 ],
 "Cannot edit vsock device on a transient VM": [
  null,
  "Не можна редагувати пристрій vsock на проміжній ВМ"
 ],
 "Cannot edit watchdog device on a transient VM": [
  null,
  "Не можна редагувати пристрій watchdog на проміжній ВМ"
 ],
 "Capacity": [
  null,
  "Місткість"
 ],
 "Change boot order": [
  null,
  "Змінити порядок завантаження"
 ],
 "Change firmware": [
  null,
  "Змінити мікропрограму"
 ],
 "Changes pending": [
  null,
  "Зміни у черзі"
 ],
 "Changes will take effect after shutting down the VM": [
  null,
  "Зміни буде застосовано після завершення роботи ВМ"
 ],
 "Changing BIOS/EFI settings is specific to each manufacturer. It involves pressing a hotkey during boot (ESC, F1, F12, Del). Enable a setting called \"virtualization\", \"VM\", \"VMX\", \"SVM\", \"VTX\", \"VTD\". Consult your computer's manual for details.": [
  null,
  "Спосіб зміни параметрів BIOS/EFI є специфічним для кожного окремого виробника. Треба натиснути якусь клавішу під час завантаження (ESC, F1, F12, Del). Потім слід увімкнути параметр, який має назву «virtualization», «VM», «VMX», «SVM», «VTX», «VTD». Подробиці можна знайти у підручнику до вашого комп'ютера."
 ],
 "Checking token validity...": [
  null,
  "Перевірка чинності жетона…"
 ],
 "Choose an operating system": [
  null,
  "Виберіть операційну систему"
 ],
 "Class": [
  null,
  "Клас"
 ],
 "Clicking \"Launch viewer\" will download a $0 file and launch the Remote Viewer application on your system.": [
  null,
  "У результаті натискання «Запустити переглядач» буде отримано файл $0 і у вашій системі запущено програму «Віддалений переглядач»."
 ],
 "Clone": [
  null,
  "Клонувати"
 ],
 "Close": [
  null,
  "Закрити"
 ],
 "Cloud base image": [
  null,
  "Базовий образ хмари"
 ],
 "Compress": [
  null,
  "Стиснути"
 ],
 "Concurrently writeable": [
  null,
  "Придатний до паралельного запису"
 ],
 "Confirm this action": [
  null,
  "Підтвердьте цю дію"
 ],
 "Connect": [
  null,
  "З'єднатися"
 ],
 "Connection": [
  null,
  "З’єднання"
 ],
 "Console": [
  null,
  "Консоль"
 ],
 "Convert QXL video card to VGA": [
  null,
  "Перетворити відеокарту QXL на VGA"
 ],
 "Convert SPICE graphics console to VNC": [
  null,
  "Перетворити графічну консоль SPICE на VNC"
 ],
 "Copy storage": [
  null,
  "Копіювати сховище даних"
 ],
 "Copy to clipboard": [
  null,
  "Копіювати до буфера"
 ],
 "Cores per socket": [
  null,
  "Кількість ядер на сокет"
 ],
 "Could not delete $0": [
  null,
  "Не вдалося вилучити $0"
 ],
 "Could not delete all storage for $0": [
  null,
  "Не вдалося вилучити усе сховище для $0"
 ],
 "Could not delete disk's storage": [
  null,
  "Не вдалося вилучити сховище даних диска"
 ],
 "Could not dynamically add watchdog": [
  null,
  "Не вдалося динамічно додати засіб спостереження"
 ],
 "Could not revert to snapshot": [
  null,
  "Не вдалося скинути систему до знімка"
 ],
 "Crashed": [
  null,
  "Аварійне завершення"
 ],
 "Create": [
  null,
  "Створити"
 ],
 "Create VM": [
  null,
  "Створення ВМ"
 ],
 "Create VM by importing a disk image of an existing VM installation": [
  null,
  "Створити ВМ імпортуванням образу диска наявної встановленої ВМ"
 ],
 "Create VM from local or network installation medium": [
  null,
  "Створити ВМ на основі локального або мережевого носія для встановлення"
 ],
 "Create a clone VM based on $0": [
  null,
  "Створити клон ВМ на основі $0"
 ],
 "Create and edit": [
  null,
  "Створити і редагувати"
 ],
 "Create and run": [
  null,
  "Створити і запустити"
 ],
 "Create new": [
  null,
  "Створити"
 ],
 "Create new qcow2 volume": [
  null,
  "Створити том qcow2"
 ],
 "Create new raw volume": [
  null,
  "Створити том raw"
 ],
 "Create new virtual machine": [
  null,
  "Створити віртуальну машину"
 ],
 "Create snapshot": [
  null,
  "Створення знімка"
 ],
 "Create storage pool": [
  null,
  "Створити резервне сховище"
 ],
 "Create storage volume": [
  null,
  "Створити том сховища даних"
 ],
 "Create virtual network": [
  null,
  "Створити віртуальну мережу"
 ],
 "Create volume": [
  null,
  "Створити том"
 ],
 "Creating VM": [
  null,
  "створення ВМ"
 ],
 "Creating VM $0": [
  null,
  "Створення ВМ $0"
 ],
 "Creating snapshots of VMs with VFIO devices is not supported while they are running.": [
  null,
  "Не передбачено можливості створення знімків ВМ з пристроями VFIO, доки машину запущено."
 ],
 "Creation of VM $0 failed": [
  null,
  "Не вдалося створити ВМ $0"
 ],
 "Creation time": [
  null,
  "Час створення"
 ],
 "Ctrl+Alt+$0": [
  null,
  "Ctrl+Alt+$0"
 ],
 "Current": [
  null,
  "Поточне"
 ],
 "Current allocation": [
  null,
  "Поточне отримання"
 ],
 "Custom firmware: $0": [
  null,
  "Нетипова мікропрограма: $0"
 ],
 "Custom identifier": [
  null,
  "Нетиповий ідентифікатор"
 ],
 "Custom path": [
  null,
  "Нетиповий шлях"
 ],
 "DHCP Settings": [
  null,
  "Параметри DHCP"
 ],
 "Deactivate": [
  null,
  "Вимкнути"
 ],
 "Delete": [
  null,
  "Вилучити"
 ],
 "Delete $0 VM?": [
  null,
  "Вилучити ВМ $0?"
 ],
 "Delete $0 storage pool?": [
  null,
  "Вилучити буфер зберігання даних $0?"
 ],
 "Delete $0 volume": [
  null,
  "Вилучити $0 том",
  "Вилучити $0 томи",
  "Вилучити $0 томів"
 ],
 "Delete associated storage files:": [
  null,
  "Вилучити пов’язані файли у сховищі даних:"
 ],
 "Delete network?": [
  null,
  "Вилучити мережу?"
 ],
 "Delete snapshot?": [
  null,
  "Вилучити знімок?"
 ],
 "Deleting an inactive storage pool will only undefine the pool. Its content will not be deleted.": [
  null,
  "Вилучення неактивного буфера зберігання даних призведе лише до скасування визначення буфера. Вміст буфера вилучено не буде."
 ],
 "Deleting shared directories is possible only when the guest is shut off": [
  null,
  "Вилучення спільних каталогів можливе, лише якщо гостьову систему вимкнено"
 ],
 "Description": [
  null,
  "Опис"
 ],
 "Deselect others": [
  null,
  "Скасувати позначення інших"
 ],
 "Destination URI": [
  null,
  "Адреса призначення"
 ],
 "Destination URI must not be empty": [
  null,
  "Адреса призначення не може бути порожньою"
 ],
 "Detach the disks using this pool from any VMs before attempting deletion.": [
  null,
  "Від'єднайте диски, які використовують цей буфер від усіх віртуальних машин, перш ніж намагатися їх вилучити."
 ],
 "Details": [
  null,
  "Подробиці"
 ],
 "Device": [
  null,
  "Пристрій"
 ],
 "Devices": [
  null,
  "Пристрої"
 ],
 "Disconnect": [
  null,
  "Від’єднатися"
 ],
 "Disconnected": [
  null,
  "Від'єднано"
 ],
 "Disconnected from serial console. Click the connect button.": [
  null,
  "Від'єднано від послідовної консолі. Натисніть кнопку «З'єднатися»."
 ],
 "Disk": [
  null,
  "Диск"
 ],
 "Disk $0 could not be removed": [
  null,
  "Не вдалося вилучити диск $0"
 ],
 "Disk failed to be added": [
  null,
  "Не вдалося додати диск"
 ],
 "Disk identifier": [
  null,
  "Ідентифікатор диска"
 ],
 "Disk image": [
  null,
  "Образ диска"
 ],
 "Disk image file": [
  null,
  "Файл образу диска"
 ],
 "Disk image path must not be empty": [
  null,
  "Шлях до образу диска не може бути порожнім"
 ],
 "Disk images can be stored in user home directory": [
  null,
  "Образи дисків можуть зберігатися у домашньому каталозі користувача"
 ],
 "Disk settings could not be saved": [
  null,
  "Не вдалося зберегти параметри диска"
 ],
 "Disk-only snapshot": [
  null,
  "Знімок лише на диску"
 ],
 "Disks": [
  null,
  "Диски"
 ],
 "Do not run this VM on the origin and destination hosts at the same time.": [
  null,
  "Не запускайте цю ВМ на початковій основній системі і основній системі призначення одночасно."
 ],
 "Do nothing": [
  null,
  "Нічого не робити"
 ],
 "Domain has crashed": [
  null,
  "Домен завершив роботу аварійно"
 ],
 "Domain is blocked on resource": [
  null,
  "Домен заблоковано на ресурсі"
 ],
 "Download an OS": [
  null,
  "Отримати операційну систему"
 ],
 "Download progress": [
  null,
  "Поступ отримання"
 ],
 "Download the MSI from $0": [
  null,
  "Отримати MSI з $0"
 ],
 "Downloading image for VM $0": [
  null,
  "Отримуємо образ для ВМ $0"
 ],
 "Downloading: $0%": [
  null,
  "Отримуємо: $0%"
 ],
 "Dump core": [
  null,
  "Створити дамп ядра"
 ],
 "Duration": [
  null,
  "Тривалість"
 ],
 "Dying": [
  null,
  "Вмирає"
 ],
 "Edit": [
  null,
  "Змінити"
 ],
 "Edit $0 attributes": [
  null,
  "Редагувати атрибути $0"
 ],
 "Edit VNC settings": [
  null,
  "Редагувати параметри VNC"
 ],
 "Edit description": [
  null,
  "Редагувати опис"
 ],
 "Edit description of VM $0": [
  null,
  "Редагувати опис ВМ $0"
 ],
 "Edit vsock interface": [
  null,
  "Редагувати інтерфейс vsock"
 ],
 "Edit watchdog device type": [
  null,
  "Змінити тип пристрою нагляду"
 ],
 "Editing network interfaces of transient guests is not allowed": [
  null,
  "Редагування інтерфейсів мережі проміжних гостьових систем заборонено"
 ],
 "Editing transient network interfaces is not allowed": [
  null,
  "Редагування проміжних інтерфейсів мережі заборонено"
 ],
 "Eject": [
  null,
  "Виштовхнути"
 ],
 "Eject disc from VM?": [
  null,
  "Виштовхнути диск з ВМ?"
 ],
 "Emulated machine": [
  null,
  "Емульована машина"
 ],
 "Enable virtualization support in BIOS/EFI settings.": [
  null,
  "Увімкніть підтримку віртуалізації у параметрах BIOS/EFI."
 ],
 "End": [
  null,
  "Кінець"
 ],
 "End should not be empty": [
  null,
  "Кінець не може бути порожнім"
 ],
 "Enter root and/or user information to enable unattended installation.": [
  null,
  "Введіть дані root і/або користувача, щоб увімкнути автоматичне встановлення."
 ],
 "Error checking token": [
  null,
  "Помилка перевірки токена"
 ],
 "Example, $0": [
  null,
  "Приклад, $0"
 ],
 "Existing disk image on host's file system": [
  null,
  "Наявний образ диска у файловій системі основної системи"
 ],
 "Expand": [
  null,
  "Розгорнути"
 ],
 "Extended attributes": [
  null,
  "Розширені атрибути"
 ],
 "Failed": [
  null,
  "Помилка"
 ],
 "Failed to add TPM to VM $0": [
  null,
  "Не вдалося додати TPM до ВМ $0"
 ],
 "Failed to add VNC to VM $0": [
  null,
  "Не вдалося додати VNC до ВМ $0"
 ],
 "Failed to add serial console to VM $0": [
  null,
  "Не вдалося додати послідовну консоль до ВМ $0"
 ],
 "Failed to add shared directory": [
  null,
  "Не вдалося додати спільний каталог"
 ],
 "Failed to change firmware": [
  null,
  "Не вдалося змінити мікропрограму"
 ],
 "Failed to clone VM $0": [
  null,
  "Не вдалося клонувати ВМ $0"
 ],
 "Failed to configure vsock": [
  null,
  "Не вдалося налаштувати vsock"
 ],
 "Failed to configure watchdog": [
  null,
  "Не вдалося налаштувати спостереження"
 ],
 "Failed to detach vsock": [
  null,
  "Не вдалося від'єднати vsock"
 ],
 "Failed to detach watchdog": [
  null,
  "Не вдалося від'єднати спостереження"
 ],
 "Failed to fetch some resources": [
  null,
  "Не вдалося отримати деякі ресурси"
 ],
 "Failed to fetch the IP addresses of the interfaces present in $0": [
  null,
  "Не вдалося отримати IP-адреси інтерфейсів, які є у $0"
 ],
 "Failed to rename VM $0": [
  null,
  "Не вдалося перейменувати ВМ $0"
 ],
 "Failed to replace SPICE devices": [
  null,
  "Не вдалося замінити пристрої SPICE"
 ],
 "Failed to save network settings": [
  null,
  "Не вдалося зберегти параметри мережі"
 ],
 "Failed to send key Ctrl+Alt+$0 to VM $1": [
  null,
  "Не вдалося надіслати комбінацію клавіш Ctrl+Alt+$0 до ВМ $1"
 ],
 "Failed to set description of VM $0": [
  null,
  "Не вдалося встановити опис ВМ $0"
 ],
 "Fewer than the maximum number of virtual CPUs should be enabled.": [
  null,
  "Має бути увімкнено менше за максимальну кількість віртуальних процесорів."
 ],
 "File": [
  null,
  "Файл"
 ],
 "Filesystem $0 could not be removed": [
  null,
  "Не вдалося вилучити файлову систему $0"
 ],
 "Filesystem directory": [
  null,
  "Каталог файлової системи"
 ],
 "Filter by name": [
  null,
  "Фільтрувати за назвою"
 ],
 "Firmware": [
  null,
  "Мікропрограма"
 ],
 "Force eject": [
  null,
  "Примусове виштовхування"
 ],
 "Force reboot": [
  null,
  "Примусове перезавантаження"
 ],
 "Force reboot $0?": [
  null,
  "Примусово перезавантажити $0?"
 ],
 "Force revert": [
  null,
  "Примусове повернення"
 ],
 "Force shut down": [
  null,
  "Примусово вимкнути"
 ],
 "Force shut down $0?": [
  null,
  "Примусово вимкнути $0?"
 ],
 "Format": [
  null,
  "Формат"
 ],
 "Forward mode": [
  null,
  "Режим переспрямовування"
 ],
 "Forwarding mode": [
  null,
  "Режим переспрямовування"
 ],
 "Full disk images and the domain's memory will be migrated. Only non-shared, writable disk images will be transferred. Unused storage will remain on the origin after migration.": [
  null,
  "Перенесенню підлягатимуть усі образи дисків і пам'ять домену. Перенесено буде лише неспільні придатні до запису образи дисків. Невикористаний обсяг сховища даних після перенесення лишатиметься у початковій системі."
 ],
 "General": [
  null,
  "Загальний"
 ],
 "Generate automatically": [
  null,
  "Створити автоматично"
 ],
 "Get a new RHSM token.": [
  null,
  "Отримати новий жетон RHSM."
 ],
 "GiB": [
  null,
  "ГіБ"
 ],
 "Go to VMs list": [
  null,
  "Перейти до списку ВМ"
 ],
 "Good choice for desktop virtualization": [
  null,
  "Чудовий вибір для стільничної віртуалізації"
 ],
 "Gracefully shutdown": [
  null,
  "Штатно вимкнути"
 ],
 "Graphical": [
  null,
  "Графіка"
 ],
 "Graphical console support not enabled": [
  null,
  "Підтримку графічної консолі не увімкнено"
 ],
 "Hardware virtualization is disabled": [
  null,
  "Апаратну віртуалізацію вимкнено"
 ],
 "Hide additional options": [
  null,
  "Приховати додаткові параметри"
 ],
 "Host": [
  null,
  "Вузол"
 ],
 "Host device": [
  null,
  "Пристрій основної системи"
 ],
 "Host device could not be attached": [
  null,
  "Не вдалося долучити пристрій основної системи"
 ],
 "Host device will be removed from $0:": [
  null,
  "Пристрій основної буде вилучено з $0:"
 ],
 "Host devices": [
  null,
  "Пристрої основної системи"
 ],
 "Host name": [
  null,
  "Назва вузла"
 ],
 "Host should not be empty": [
  null,
  "Вузол не повинен бути порожнім"
 ],
 "Hypervisor details": [
  null,
  "Докладніше про гіпервізор"
 ],
 "ID": [
  null,
  "Ід."
 ],
 "IP": [
  null,
  "IP"
 ],
 "IP address": [
  null,
  "IP-адреса"
 ],
 "IP address must not be empty": [
  null,
  "IP-адреса має бути непорожньою"
 ],
 "IP configuration": [
  null,
  "Налаштування IP"
 ],
 "IPv4 address": [
  null,
  "Адреса IPv4"
 ],
 "IPv4 address cannot be same as the network's broadcast address": [
  null,
  "Адреса IPv4 не може бути тою самою, що і адреса трансляції мережі"
 ],
 "IPv4 and IPv6": [
  null,
  "IPv4 і IPv6"
 ],
 "IPv4 network should not be empty": [
  null,
  "Мережа IPv4 не повинна бути порожньою"
 ],
 "IPv4 only": [
  null,
  "Лише IPv4"
 ],
 "IPv4 prefix length must be 24 or less": [
  null,
  "Довжина префікса IPv4 не повинна перевищувати 24 символи"
 ],
 "IPv4 prefix length must be a multiple of 8": [
  null,
  "Довжина префікса IPv4 повинна бути кратною до 8"
 ],
 "IPv6 address": [
  null,
  "Адреса IPv6"
 ],
 "IPv6 network should not be empty": [
  null,
  "Мережа IPv6 не повинна бути порожньою"
 ],
 "IPv6 only": [
  null,
  "Лише IPv6"
 ],
 "Ideal for server VMs": [
  null,
  "Ідеальний для серверних ВМ"
 ],
 "Ideal networking support": [
  null,
  "Ідеальна підтримка роботи у мережі"
 ],
 "Identifier in use by $0. VMs with an identical identifier cannot run at the same time.": [
  null,
  "Ідентифікатор використано $0. ВМ із однаковими ідентифікаторами не можна запускати одночасно."
 ],
 "Identifier may be silently truncated to $0 characters ": [
  null,
  "Ідентифікатор може бути без повідомлень обрізано до $0 символів "
 ],
 "Idle": [
  null,
  "Бездіяльність"
 ],
 "Ignore": [
  null,
  "Ігнорувати"
 ],
 "Import VM": [
  null,
  "Імпортувати ВМ"
 ],
 "Import a virtual machine": [
  null,
  "Імпортувати віртуальну машину"
 ],
 "Import and edit": [
  null,
  "Імпортувати і редагувати"
 ],
 "Import and run": [
  null,
  "Імпортувати і запустити"
 ],
 "Importing an image with a backing file is unsupported": [
  null,
  "Підтримки імпортування образу із базовим файлом не передбачено"
 ],
 "In most configurations, macvtap does not work for host to guest network communication.": [
  null,
  "У більшості конфігурацій macvtap не працює для обміну мережею між основною і гостьовою системами."
 ],
 "Initiator": [
  null,
  "Ініціатор"
 ],
 "Initiator should not be empty": [
  null,
  "Ініціатор має бути непорожнім"
 ],
 "Inject a non-maskable interrupt": [
  null,
  "Вставити немасковане переривання"
 ],
 "Insert": [
  null,
  "Вставити"
 ],
 "Insert disc media": [
  null,
  "Вставте дисковий носій даних"
 ],
 "Inside the VM": [
  null,
  "Всередині ВМ"
 ],
 "Install": [
  null,
  "Встановити"
 ],
 "Installation source": [
  null,
  "Джерело для встановлення"
 ],
 "Installation source must not be empty": [
  null,
  "Запис джерела встановлення не може бути порожнім"
 ],
 "Installation type": [
  null,
  "Тип встановлення"
 ],
 "Interface": [
  null,
  "Інтерфейс"
 ],
 "Interface type": [
  null,
  "Тип інтерфейсу"
 ],
 "Interface type help": [
  null,
  "Довідка щодо типу інтерфейсу"
 ],
 "Invalid IPv4 address": [
  null,
  "Некоректна адреса IPv4"
 ],
 "Invalid IPv4 mask or prefix length": [
  null,
  "Некоректна довжина маски IPv4 або префікса"
 ],
 "Invalid IPv6 address": [
  null,
  "Некоректна адреса IPv6"
 ],
 "Invalid IPv6 prefix": [
  null,
  "Некоректний префікс IPv6"
 ],
 "Invalid filename": [
  null,
  "Некоректна назва файла"
 ],
 "Isolated network": [
  null,
  "Ізольована мережа"
 ],
 "It can also be used to enable the inline graphical console in the browser, which does not support SPICE.": [
  null,
  "Цим також можна скористатися для вмикання вбудованої графічної консолі у браузері, де не буде підтримки SPICE."
 ],
 "Keys are located in ~/.ssh/ and have a \".pub\" extension.": [
  null,
  "Ключі зберігаються у ~/.ssh/ і мають суфікс назви «.pub»."
 ],
 "LVM volume group": [
  null,
  "Група томів LVM"
 ],
 "Launch viewer": [
  null,
  "Запустити переглядач"
 ],
 "Leave the password blank if you do not wish to have a root account created": [
  null,
  "Не заповнюйте поле пароля, якщо ви не хочете, щоб було створено обліковий запис root"
 ],
 "Leave the password blank if you do not wish to have a user account created": [
  null,
  "Не заповнюйте поле пароля, якщо ви не хочете, щоб було створено обліковий запис користувача"
 ],
 "Leave the password blank if you do not wish to set a root password": [
  null,
  "Не заповнюйте поле пароля, якщо ви не хочете встановлювати пароль root"
 ],
 "Libvirt did not detect any UEFI/OVMF firmware image installed on the host": [
  null,
  "Libvirt не вдалося виявити жодного образу мікропрограми UEFI/OVMF, встановлено у основній системі"
 ],
 "Libvirt or hypervisor does not support UEFI": [
  null,
  "У libvirt або гіпервізорі не передбачено підтримки UEFI"
 ],
 "Loading available network devices": [
  null,
  "Завантажуємо доступні мережеві пристрої"
 ],
 "Loading resources": [
  null,
  "Завантаження ресурсів"
 ],
 "Loading...": [
  null,
  "Завантаження…"
 ],
 "Local install media (ISO image or distro install tree)": [
  null,
  "Локальний носій даних для встановлення (образ ISO або ієрархія каталогів встановлення дистрибутиву)"
 ],
 "Location": [
  null,
  "Адреса"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "MAC address": [
  null,
  "MAC-адреса"
 ],
 "MAC address already in use": [
  null,
  "MAC-адресу вже використано"
 ],
 "MAC address must not be empty": [
  null,
  "MAC-адреса має бути непорожньою"
 ],
 "Machine must be shut off before changing bus type": [
  null,
  "До внесення змін до типу каналу машину слід вимкнути"
 ],
 "Machine must be shut off before changing cache mode": [
  null,
  "До внесення змін до режиму кешування машину слід вимкнути"
 ],
 "Mask or prefix length": [
  null,
  "Довжина маски або префікса"
 ],
 "Mask or prefix length should not be empty": [
  null,
  "Довжина маски або префікса повинна бути непорожньою"
 ],
 "Maximum allocation": [
  null,
  "Максимальне отримання"
 ],
 "Maximum memory could not be saved": [
  null,
  "Не вдалося зберегти дані щодо максимального обсягу пам'яті"
 ],
 "Maximum number of virtual CPUs allocated for the guest OS": [
  null,
  "Максимальна кількість віртуальних процесорів, наданих для гостьової операційної системи"
 ],
 "Maximum number of virtual CPUs allocated for the guest OS, which must be between 1 and $0": [
  null,
  "Максимальна кількість віртуальних процесорів, наданих для гостьової операційної системи, має бути у межах від 1 до $0"
 ],
 "Maximum transmission unit": [
  null,
  "Максимальна одиниця передавання"
 ],
 "Media could not be ejected from $0": [
  null,
  "Не вдалося виштовхнути носій даних з $0"
 ],
 "Media will be ejected from $0:": [
  null,
  "Носій даних буде виштовхнуто з $0:"
 ],
 "Memory": [
  null,
  "Пам'ять"
 ],
 "Memory could not be saved": [
  null,
  "Не вдалося зберегти дані щодо обсягу пам'яті"
 ],
 "Memory must not be 0": [
  null,
  "Об'єм пам'яті не може бути нульовим"
 ],
 "Memory save location can not be empty": [
  null,
  "Місце зберігання у пам'яті не може бути порожнім"
 ],
 "Memory snapshot will use about $0.": [
  null,
  "Знімок пам'яті використовуватиме приблизно $0."
 ],
 "Memory state path": [
  null,
  "Шлях до стану пам'яті"
 ],
 "MiB": [
  null,
  "МіБ"
 ],
 "Migrate": [
  null,
  "Перенести"
 ],
 "Migrate VM to another host": [
  null,
  "Перенести ВМ на іншу основну систему"
 ],
 "Migration failed": [
  null,
  "Помилка під час перенесення"
 ],
 "Mode": [
  null,
  "Режим"
 ],
 "Mode help": [
  null,
  "Довідка щодо режиму"
 ],
 "Model": [
  null,
  "Модель"
 ],
 "Model type": [
  null,
  "Тип моделі"
 ],
 "More info": [
  null,
  "Додаткова інформація"
 ],
 "Mount tag": [
  null,
  "Мітка монтування"
 ],
 "Mount tag must not be empty": [
  null,
  "Мітка монтування не може бути порожньою"
 ],
 "Must be an address instead of the network identifier, such as $0": [
  null,
  "Має бути адресою, а не ідентифікатором мережі, приклад: $0"
 ],
 "NAT to $0": [
  null,
  "NAT до $0"
 ],
 "NIC $0 of VM $1 failed to change state": [
  null,
  "NIC $0 ВМ $1, не вдалося змінити стан"
 ],
 "Name": [
  null,
  "Назва"
 ],
 "Name already exists": [
  null,
  "Таку назву вже використано"
 ],
 "Name can not be empty": [
  null,
  "Назва не може бути порожньою"
 ],
 "Name contains invalid characters": [
  null,
  "У назві містяться некоректні символи"
 ],
 "Name must not be empty": [
  null,
  "Запис назви не може бути порожнім"
 ],
 "Name should not be empty": [
  null,
  "Назва має бути непорожньою"
 ],
 "Name: ": [
  null,
  "Назва: "
 ],
 "Netmask": [
  null,
  "Маска мережі"
 ],
 "Network $0 could not be deleted": [
  null,
  "Не вдалося вилучити мережу $0"
 ],
 "Network $0 failed to get activated": [
  null,
  "Не вдалося активувати мережу $0"
 ],
 "Network $0 failed to get deactivated": [
  null,
  "Не вдалося деактивувати мережу $0"
 ],
 "Network $0 will be permanently deleted.": [
  null,
  "Мережу $0 буде остаточно вилучено."
 ],
 "Network boot (PXE)": [
  null,
  "Мережеве завантаження (PXE)"
 ],
 "Network file system": [
  null,
  "Мережева файлова система"
 ],
 "Network interface": [
  null,
  "Інтерфейс мережі"
 ],
 "Network interface $0 could not be removed": [
  null,
  "Не вдалося вилучити інтерфейс мережі $0"
 ],
 "Network interface $0 will be removed from $1": [
  null,
  "Інтерфейс мережі $0 буде вилучено з $1"
 ],
 "Network interface settings could not be saved": [
  null,
  "Не вдалося зберегти параметри інтерфейсу мережі"
 ],
 "Network interfaces": [
  null,
  "Інтерфейси мережі"
 ],
 "Network selection does not support PXE.": [
  null,
  "Для вибору мережі не передбачено підтримки PXE."
 ],
 "Networks": [
  null,
  "Мережі"
 ],
 "New name": [
  null,
  "Нова назва"
 ],
 "New name must not be empty": [
  null,
  "Нова назва не може бути порожньою"
 ],
 "New volume name": [
  null,
  "Назва нового тому"
 ],
 "No SSH keys specified": [
  null,
  "Не вказано ключів SSH"
 ],
 "No VM is running or defined on this host": [
  null,
  "У цій основній системі не запущено або не визначено віртуальних машин"
 ],
 "No boot device found": [
  null,
  "Не знайдено пристрою для завантаження"
 ],
 "No description": [
  null,
  "Немає опису"
 ],
 "No directories shared between the host and this VM": [
  null,
  "У основної системи і цієї ВМ немає спільних каталогів"
 ],
 "No disks defined for this VM": [
  null,
  "Для цієї ВМ не визначено дисків"
 ],
 "No host device selected": [
  null,
  "Не вибрано пристрою основної системи"
 ],
 "No host devices assigned to this VM": [
  null,
  "Із цією ВМ не пов'язано жодних пристроїв основної системи"
 ],
 "No network devices": [
  null,
  "Немає пристроїв мережі"
 ],
 "No network interfaces defined for this VM": [
  null,
  "Немає інтерфейсів мережі, які визначено для цієї ВМ"
 ],
 "No network is defined on this host": [
  null,
  "У цій основній системі мережу не визначено"
 ],
 "No networks available": [
  null,
  "Немає доступних мереж"
 ],
 "No parent": [
  null,
  "Немає батьківського запису"
 ],
 "No snapshots defined for this VM": [
  null,
  "Для цієї ВМ не визначено знімків"
 ],
 "No state": [
  null,
  "Немає стану"
 ],
 "No storage": [
  null,
  "Немає сховища даних"
 ],
 "No storage pool is defined on this host": [
  null,
  "На цьому вузлі не визначено буфера зберігання даних"
 ],
 "No storage pools available": [
  null,
  "Немає доступних буферів зберігання даних"
 ],
 "No storage volumes defined for this storage pool": [
  null,
  "Для цього буфера зберігання сховища не визначено томів сховища"
 ],
 "No virtual networks": [
  null,
  "Немає віртуальних мереж"
 ],
 "No volumes exist in this storage pool.": [
  null,
  "У цьому буфері сховища даних не існує томів."
 ],
 "Non-persistent network cannot be deleted. It ceases to exists when it's deactivated.": [
  null,
  "Несталу мережу не можна вилучати. Вона просто зникне, якщо її вимкнути."
 ],
 "Non-persistent storage pool cannot be deleted. It ceases to exists when it's deactivated.": [
  null,
  "Несталий буфер зберігання даних не можна вилучати. Він просто зникне, якщо його вимкнути."
 ],
 "None": [
  null,
  "Немає"
 ],
 "None (isolated network)": [
  null,
  "Немає (ізольована мережа)"
 ],
 "Offline token": [
  null,
  "Автономний жетон"
 ],
 "Offline token must not be empty": [
  null,
  "Автономний жетон не може бути порожнім"
 ],
 "Old token expired": [
  null,
  "Термін дії старого жетона сплив"
 ],
 "On the host": [
  null,
  "На основній системі"
 ],
 "One or more selected volumes are used by domains. Detach the disks first to allow volume deletion.": [
  null,
  "Один або декілька позначених томів використовуються доменами. Щоб уможливити вилучення цих томів, спочатку від'єднайте диски."
 ],
 "Only editable when the guest is shut off": [
  null,
  "Можна редагувати, лише якщо гостьову систему вимкнено"
 ],
 "Open": [
  null,
  "Відкрита"
 ],
 "Operating system": [
  null,
  "Операційна система"
 ],
 "Operation is in progress": [
  null,
  "Виконується дія"
 ],
 "Other VMs using SPICE": [
  null,
  "Інші ВМ з використанням SPICE"
 ],
 "Overview": [
  null,
  "Огляд"
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "Parent snapshot": [
  null,
  "Батьківський знімок"
 ],
 "Password": [
  null,
  "Пароль"
 ],
 "Password must be 8 characters or less. VNC passwords do not provide encryption and are generally cryptographically weak. They can not be used to secure connections in untrusted networks.": [
  null,
  "Пароль має складатися з 8 або меншої кількості символів. Паролі VNC не забезпечують шифрування і, загалом, є криптографічно нестійкими. Ними можна скористатися для захисту з'єднань у ненадійних мережах."
 ],
 "Password must be at most 8 characters.": [
  null,
  "Кількість символів у паролі не повинна перевищувати 8."
 ],
 "Path": [
  null,
  "Шлях"
 ],
 "Path on host's filesystem": [
  null,
  "Шлях у файловій системі вузла"
 ],
 "Path to ISO file on host's file system": [
  null,
  "Шлях до ISO у файловій системі основної системи"
 ],
 "Path to cloud image file on host's file system": [
  null,
  "Шлях до файла образу хмари у файловій системі основної системи"
 ],
 "Path to directory": [
  null,
  "Шлях до каталогу"
 ],
 "Path to file on host's file system": [
  null,
  "Шлях до файла у файловій системі основної системи"
 ],
 "Pause": [
  null,
  "Призупинити"
 ],
 "Paused": [
  null,
  "Призупинено"
 ],
 "Permanent (default)": [
  null,
  "Сталий (типовий)"
 ],
 "Permissions denied for disk images in home directories": [
  null,
  "Доступ заборонено для образів дисків у домашніх каталогах"
 ],
 "Persistence": [
  null,
  "Сталість"
 ],
 "Persistent": [
  null,
  "Постійний"
 ],
 "Physical disk device": [
  null,
  "Фізичний пристрій диска"
 ],
 "Physical disk device on host": [
  null,
  "Фізичний пристрій у основній системі"
 ],
 "Please choose a different MAC address": [
  null,
  "Будь ласка, виберіть іншу MAC-адресу"
 ],
 "Please choose a storage pool": [
  null,
  "Будь ласка, виберіть буфер зберігання даних"
 ],
 "Please choose a volume": [
  null,
  "Будь ласка, виберіть том"
 ],
 "Please enter new volume name": [
  null,
  "Будь ласка, введіть назву нового тому"
 ],
 "Please see $0 how to reconfigure your VM manually.": [
  null,
  "Будь ласка, ознайомтеся із $0, щоб дізнатися про те, як змінити налаштування вашої ВМ вручну."
 ],
 "Pool": [
  null,
  "Буфер"
 ],
 "Pool needs to be active to create volume": [
  null,
  "Для створення тому буфер має бути активним"
 ],
 "Pool type $0 does not support volume creation": [
  null,
  "Для типу буфера $0 не передбачено підтримки створення томів"
 ],
 "Pool type doesn't support volume creation": [
  null,
  "Для типу буфера не пердебачено підтримки створення томів"
 ],
 "Pool's volumes are used by VMs ": [
  null,
  "Томи буфера використовуються ВМ "
 ],
 "Port": [
  null,
  "Порт"
 ],
 "Port must be 5900 or larger.": [
  null,
  "Номер порту має бути не меншим за 5900."
 ],
 "Port must be a number that is at least 5900. Leave empty to automatically assign a free port when the machine starts.": [
  null,
  "Номер порту повинен бути не меншим за 5900. Не заповнюйте, щоб програма автоматично призначила вільний порт при запуску машини."
 ],
 "Port must be a number.": [
  null,
  "Порт має бути вказано числом."
 ],
 "Power off": [
  null,
  "Вимкнути живлення"
 ],
 "Pre-formatted block device": [
  null,
  "Попередньо форматований блоковий пристрій"
 ],
 "Preferred number of sockets to expose to the guest.": [
  null,
  "Бажана кількість сокетів, які слід надавати гостьовій системі."
 ],
 "Prefix": [
  null,
  "Префікс"
 ],
 "Prefix length": [
  null,
  "Довжина префікса"
 ],
 "Prefix length should not be empty": [
  null,
  "Довжина префікса повинна бути непорожньою"
 ],
 "Previously taken snapshots allow you to revert to an earlier state if something goes wrong": [
  null,
  "За допомогою раніше зроблених знімків ви зможете повернутися до попереднього стану, якщо щось піде не так"
 ],
 "Private": [
  null,
  "Закрита"
 ],
 "Product": [
  null,
  "Продукт"
 ],
 "Profile": [
  null,
  "Профіль"
 ],
 "Protocol": [
  null,
  "Протокол"
 ],
 "Provides a bridge from the guest virtual machine directly onto the LAN. This needs a bridge device on the host with one or more physical NICs.": [
  null,
  "Забезпечує роботу містка з гостьової віртуальної машини безпосередньо до LAN. Потребує пристрою містка у основній системі із одним або декількома фізичними NIC."
 ],
 "Provides a connection whose details are described by the named network definition.": [
  null,
  "Надає з'єднання, параметри якого описано іменованим визначенням мережі."
 ],
 "Provides a virtual LAN with NAT to the outside world.": [
  null,
  "Надає віртуальну LAN з NAT для зовнішнього світу."
 ],
 "Public SSH key": [
  null,
  "Відкритий ключ SSH"
 ],
 "Public key": [
  null,
  "Відкритий ключ"
 ],
 "Range": [
  null,
  "Діапазон"
 ],
 "Read-only": [
  null,
  "Лише читання"
 ],
 "Reboot": [
  null,
  "Перезавантажити"
 ],
 "Reboot $0?": [
  null,
  "Перезавантажити $0?"
 ],
 "Recommended operating systems": [
  null,
  "Рекомендовані операційні системи"
 ],
 "Released $0": [
  null,
  "Випущено $0"
 ],
 "Remote URL": [
  null,
  "Віддалена адреса"
 ],
 "Remote Viewer is available for most operating systems. To install it, search for \"Remote Viewer\" in GNOME Software, KDE Discover, or run the following:": [
  null,
  "«Віддаленим переглядачем» можна користуватися у більшості операційних систем. Щоб встановити пакунок із програмою, знайдіть «Віддалений переглядач» у Програмних засобах GNOME, KDE Discover або віддайте таку команду:"
 ],
 "Remote viewer": [
  null,
  "Віддалений переглядач"
 ],
 "Remote viewer applications can connect to the following address:": [
  null,
  "Програми для віддаленого перегляду можуть встановлювати з'єднання за такою адресою:"
 ],
 "Remove": [
  null,
  "Вилучити"
 ],
 "Remove SPICE audio and host devices": [
  null,
  "Вилучити звукові пристрої SPICE та пристрої основної системи"
 ],
 "Remove and delete file": [
  null,
  "Вилучити і витерти файл"
 ],
 "Remove disk from VM?": [
  null,
  "Вилучити диск з ВМ?"
 ],
 "Remove filesystem?": [
  null,
  "Вилучити файлову систему?"
 ],
 "Remove host device from VM?": [
  null,
  "Вилучити пристрій основної системи з ВМ?"
 ],
 "Remove item": [
  null,
  "Вилучити запис"
 ],
 "Remove network interface?": [
  null,
  "Вилучити інтерфейс мережі?"
 ],
 "Remove static host from DHCP": [
  null,
  "Вилучити статичний вузол з DHCP"
 ],
 "Rename": [
  null,
  "Перейменувати"
 ],
 "Rename VM $0": [
  null,
  "Перейменувати ВМ $0"
 ],
 "Replace": [
  null,
  "Замінити"
 ],
 "Replace SPICE devices": [
  null,
  "Замінити пристрої SPICE"
 ],
 "Replace SPICE devices in VM $0": [
  null,
  "Замінити пристрої SPICE у ВМ $0"
 ],
 "Replace SPICE on selected VMs.": [
  null,
  "Замінити SPICE на вибраних ВМ."
 ],
 "Replace SPICE on the virtual machine.": [
  null,
  "Замінити SPICE у віртуальній машині."
 ],
 "Replace with VNC": [
  null,
  "Замінити на VNC"
 ],
 "Reset": [
  null,
  "Скинути"
 ],
 "Restart this virtual machine to access its graphical console": [
  null,
  "Перезапустіть цю віртуальну машину, щоб отримати доступ до її графічної консолі"
 ],
 "Restart this virtual machine to access its serial console": [
  null,
  "Перезапустіть цю віртуальну машину, щоб отримати доступ до її послідовної консолі"
 ],
 "Restrictions in networking (SLIRP-based emulation) and PCI device assignment": [
  null,
  "Обмеження для мережі (заснована на SLIRP емуляція) і призначення пристроїв PCI"
 ],
 "Resume": [
  null,
  "Відновити"
 ],
 "Revert": [
  null,
  "Повернутися"
 ],
 "Revert to snapshot $0": [
  null,
  "Повернутися до знімка $0"
 ],
 "Reverting to this snapshot will take the VM back to the time of the snapshot and the current state will be lost, along with any data not captured in a snapshot": [
  null,
  "Повернення до цього знімка переведе віртуальну машину до стану на момент створення знімка — поточний стан буде втрачено разом із усіма даними, які не захоплено до знімка"
 ],
 "Root password": [
  null,
  "Пароль root"
 ],
 "Route to $0": [
  null,
  "Маршрут до $0"
 ],
 "Routed network": [
  null,
  "Маршрутизована мережа"
 ],
 "Row select": [
  null,
  "Вибір рядка"
 ],
 "Run": [
  null,
  "Запустити"
 ],
 "Run when host boots": [
  null,
  "Запустити під час завантаження основної системи"
 ],
 "Running": [
  null,
  "Працює"
 ],
 "SPICE": [
  null,
  "SPICE"
 ],
 "SPICE conversion": [
  null,
  "Перетворення SPICE"
 ],
 "SPICE is not supported on this host and will cause this virtual machine to not boot.": [
  null,
  "На цій основній системі не передбачено підтримки SPICE, її використання призведе до неможливості завантажити віртуальну машину."
 ],
 "SSH keys": [
  null,
  "Ключі SSH"
 ],
 "Save": [
  null,
  "Зберегти"
 ],
 "Select all": [
  null,
  "Вибрати все"
 ],
 "Send key": [
  null,
  "Надіслати ключ"
 ],
 "Send non-maskable interrupt": [
  null,
  "Надіслати немасковане переривання"
 ],
 "Send non-maskable interrupt to $0?": [
  null,
  "Надіслати немасковане переривання на $0?"
 ],
 "Serial": [
  null,
  "Серійний номер"
 ],
 "Serial ($0)": [
  null,
  "Послідовна ($0)"
 ],
 "Serial console": [
  null,
  "Послідовна консоль"
 ],
 "Serial console support not enabled": [
  null,
  "Підтримку послідовної консолі не увімкнено"
 ],
 "Set DHCP range": [
  null,
  "Встановити діапазон DHCP"
 ],
 "Set manually": [
  null,
  "Встановити вручну"
 ],
 "Setting the user passwords for unattended installation requires starting the VM when creating it": [
  null,
  "Встановлення паролів користувачів для автоматичного встановлення потребує запуску віртуальної машини при створенні системи"
 ],
 "Share": [
  null,
  "Оприлюднити"
 ],
 "Share a host directory with the guest": [
  null,
  "Надати каталог основної системи у спільне користування гостьовій системі"
 ],
 "Shared directories": [
  null,
  "Спільні каталоги"
 ],
 "Shared host directories need to be manually mounted inside the VM": [
  null,
  "Спільні каталоги основної системи має бути змонтовано вручну у ВМ"
 ],
 "Shared storage": [
  null,
  "Спільне сховище даних"
 ],
 "Show additional options": [
  null,
  "Показати додаткові параметри"
 ],
 "Show less": [
  null,
  "Показати менше"
 ],
 "Show more": [
  null,
  "Показати більше"
 ],
 "Shut down": [
  null,
  "Вимкнути"
 ],
 "Shut down $0?": [
  null,
  "Вимкнути $0?"
 ],
 "Shut off": [
  null,
  "Вимкнути"
 ],
 "Shut off the VM in order to edit firmware configuration": [
  null,
  "Вимкніть віртуальну машину, щоб розпочати редагування налаштувань мікропрограми"
 ],
 "Shutting down": [
  null,
  "Вимикання"
 ],
 "Size": [
  null,
  "Розмір"
 ],
 "Slot": [
  null,
  "Слот"
 ],
 "Snapshot $0 could not be deleted": [
  null,
  "Не вдалося вилучити знімок $0"
 ],
 "Snapshot $0 will be deleted from $1. All of its captured content will be lost.": [
  null,
  "Знімок $0 буде вилучено з $1. Усі захоплені у ньому дані буде втрачено."
 ],
 "Snapshot failed to be created": [
  null,
  "Не вдалося створити знімок"
 ],
 "Snapshots": [
  null,
  "Знімки"
 ],
 "Sockets": [
  null,
  "Сокети"
 ],
 "Some configuration changes only take effect after a fresh boot:": [
  null,
  "Деякі зміни у налаштуваннях набудуть чинності лише після перезавантаження:"
 ],
 "Source": [
  null,
  "Джерело"
 ],
 "Source format": [
  null,
  "Початковий формат"
 ],
 "Source must not be empty": [
  null,
  "Джерело має бути непорожнім"
 ],
 "Source path": [
  null,
  "Шлях до джерела"
 ],
 "Source path should not be empty": [
  null,
  "Шлях до джерела не може бути порожнім"
 ],
 "Source should start with http, ftp or nfs protocol": [
  null,
  "Адреса джерела має починатися із назви протоколу — http, ftp або nfs"
 ],
 "Source volume group": [
  null,
  "Початкова група томів"
 ],
 "Start": [
  null,
  "Почати"
 ],
 "Start pool when host boots": [
  null,
  "Запускати резервне сховище після завантаження вузла"
 ],
 "Start should not be empty": [
  null,
  "Початок повинен бути непорожнім"
 ],
 "Start the virtual machine to access the console": [
  null,
  "Запустіть віртуальну машину, щоб отримати доступ до її консолі"
 ],
 "Start the virtual machine to launch remote viewer.": [
  null,
  "Запустіть віртуальну машину, щоб запустити віддалений переглядач."
 ],
 "Started": [
  null,
  "Почато"
 ],
 "Startup": [
  null,
  "Запуск"
 ],
 "State": [
  null,
  "Стан"
 ],
 "Static host entries": [
  null,
  "Записи статичних вузлів"
 ],
 "Static host from DHCP could not be removed": [
  null,
  "Не вдалося вилучити статичний вузол з DHCP"
 ],
 "Storage": [
  null,
  "Сховище даних"
 ],
 "Storage is at a shared location": [
  null,
  "Сховище даних є адресою спільного користування"
 ],
 "Storage limit": [
  null,
  "Обмеження сховища даних"
 ],
 "Storage pool $0 failed to get activated": [
  null,
  "Не вдалося активувати буфер сховища $0"
 ],
 "Storage pool $0 failed to get deactivated": [
  null,
  "Не вдалося деактивувати буфер сховища $0"
 ],
 "Storage pool failed to be created": [
  null,
  "Не вдалося створити резервне сховище"
 ],
 "Storage pool name": [
  null,
  "Назва резервного сховища"
 ],
 "Storage pools": [
  null,
  "Буфери даних"
 ],
 "Storage pools could not be fetched": [
  null,
  "Не вдалося отримати буфери сховища даних"
 ],
 "Storage size must not be 0": [
  null,
  "Розмір сховища має бути ненульовим"
 ],
 "Storage volume": [
  null,
  "Том сховища даних"
 ],
 "Storage volume size must not exceed the storage pool's capacity ($0 $1)": [
  null,
  "Розмір тому сховища даних не повинен перевищувати місткість буфера сховища даних ($0 $1)"
 ],
 "Storage volumes": [
  null,
  "Томи даних"
 ],
 "Storage volumes could not be deleted": [
  null,
  "Не вдалося вилучити томи сховища даних"
 ],
 "Storage volumes must be shared between this host and the destination host.": [
  null,
  "Томи сховища даних мають бути спільними між цією основною системою та основною системою призначення."
 ],
 "Successfully copied to clipboard!": [
  null,
  "Успішно скопійовано до буфера!"
 ],
 "Suspended (PM)": [
  null,
  "призупинено (PM)"
 ],
 "Switch to VNC to continue using this machine.": [
  null,
  "Перемкніться на VNC, щоб продовжити користування цією машиною."
 ],
 "System": [
  null,
  "Система"
 ],
 "TAP device": [
  null,
  "Пристрій TAP"
 ],
 "TPM": [
  null,
  "TPM"
 ],
 "Table of selectable host devices": [
  null,
  "Таблиця придатних для вибору пристроїв основної системи"
 ],
 "Target": [
  null,
  "Призначення"
 ],
 "Target path": [
  null,
  "Шлях призначення"
 ],
 "Target path should not be empty": [
  null,
  "Шлях призначення не може бути порожнім"
 ],
 "Temporary": [
  null,
  "Тимчасове"
 ],
 "Temporary migration": [
  null,
  "Тимчасове перенесення"
 ],
 "The VM $0 is running and will be forced off before deletion.": [
  null,
  "Запущено віртуальну машину $0. Її буде примусово зупинено перед вилученням."
 ],
 "The VM needs to be running or shut off to detach this device": [
  null,
  "Віртуальну машину має бути запущено або вимкнено, щоб можна було від'єднати цей пристрій"
 ],
 "The directory on the server being exported": [
  null,
  "Каталог на сервері, який експортується"
 ],
 "The host path that is to be exported.": [
  null,
  "Шлях у основній системі, який має бути експортовано."
 ],
 "The migrated VM configuration is removed from the source host. The destination host is considered the new home of the VM.": [
  null,
  "Налаштування перенесеної ВМ вилучено з основної системи джерела. Основна система призначення тепер вважається новою домівкою ВМ."
 ],
 "The mode influences the delivery of packets.": [
  null,
  "Режим впливає на отримання пакетів."
 ],
 "The pool is empty": [
  null,
  "Буфер порожній"
 ],
 "The selected operating system has minimum memory requirement of $0 $1": [
  null,
  "Для вибраної операційної системи мінімальним обсягом пам'яті є $0 $1"
 ],
 "The selected operating system has minimum storage size requirement of $0 $1": [
  null,
  "Для вибраної операційної системи мінімальним об'ємом пристрою накопичення даних є $0 $1"
 ],
 "The static host entry for $0 will be removed:": [
  null,
  "Статичний запис вузла для $0 буде вилучено:"
 ],
 "The storage pool could not be deleted": [
  null,
  "Не вдалося вилучити буфер сховища даних"
 ],
 "The tag name to be used by the guest to mount this export point.": [
  null,
  "Назва мітки, яку буде використано гостьовою системою для монтування цієї точки експортування."
 ],
 "Then copy and paste it above.": [
  null,
  "Потім скопіюйте та вставте його вище."
 ],
 "This VM is transient. Shut it down if you wish to delete it.": [
  null,
  "Ця віртуальна машина є тимчасовою. Вимкніть її, якщо хочете її вилучити."
 ],
 "This disk will be removed from $0:": [
  null,
  "Цей диск буде вилучено з $0:"
 ],
 "This filesystem will be removed from $0:": [
  null,
  "Цю файлову систему буде вилучено з $0:"
 ],
 "This is intended for a host which does not support SPICE due to upgrades or live migration.": [
  null,
  "Призначено для основної системи, у якій не передбачено підтримки SPICE через оновлення або інтерактивному перенесенню."
 ],
 "This is the recommended type for general guest connectivity on hosts with dynamic / wireless networking configs.": [
  null,
  "Це рекомендований тип для загальної можливості з'єднань у гостьовій системі на основних системах із динамічними/бездротовими налаштуваннями мережі."
 ],
 "This is the recommended type for general guest connectivity on hosts with static wired networking configs.": [
  null,
  "Це рекомендований тип для загальної можливості з'єднань у гостьовій системі на основних системах зі статичними дротовими налаштуваннями мережі."
 ],
 "This is the recommended type for high performance or enhanced security.": [
  null,
  "Це рекомендований тип для високої швидкодії і додаткового захисту."
 ],
 "This machine has a SPICE graphical console that can not be shown here.": [
  null,
  "У цій машині є графічна консоль SPICE, яку тут не може бути показано."
 ],
 "This volume is already used by $0.": [
  null,
  "Цей том вже використано $0."
 ],
 "This volume is already used by another VM.": [
  null,
  "Цей том вже використано іншою ВМ."
 ],
 "Threads per core": [
  null,
  "Потоків на ядро"
 ],
 "Total space available: $0.": [
  null,
  "Загалом доступного місця: $0."
 ],
 "Transient VMs don't support editing firmware configuration": [
  null,
  "Для тимчасових віртуальних машин не передбачено підтримки редагування налаштувань мікропрограми"
 ],
 "Troubleshoot": [
  null,
  "Діагностика проблем"
 ],
 "Type": [
  null,
  "Тип"
 ],
 "URL (ISO image or distro install tree)": [
  null,
  "Адреса (образ ISO або ієрархія каталогів встановлення дистрибутиву)"
 ],
 "USB": [
  null,
  "USB"
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Undefined": [
  null,
  "Не визначено"
 ],
 "Unique name": [
  null,
  "Унікальна назва"
 ],
 "Unique name, default: $0": [
  null,
  "Унікальна назва, типовий варіант: $0"
 ],
 "Unique network name": [
  null,
  "Унікальна назва мережі"
 ],
 "Unit": [
  null,
  "Модуль"
 ],
 "Unknown": [
  null,
  "Невідомий"
 ],
 "Unknown firmware": [
  null,
  "Невідома мікропрограма"
 ],
 "Unspecified": [
  null,
  "Не вказано"
 ],
 "Unsupported and older operating systems": [
  null,
  "Непідтримувані і застарілі операційні системи"
 ],
 "Url": [
  null,
  "Адреса"
 ],
 "Usage": [
  null,
  "Використання"
 ],
 "Use existing": [
  null,
  "Використати наявний"
 ],
 "Use extended attributes on files and directories": [
  null,
  "Використати розширені атрибути для файлів і каталогів"
 ],
 "Use the same location on both the origin and destination hosts for your storage. This can be a shared storage pool, NFS, or any other method of sharing storage.": [
  null,
  "Використати те саме місце на початковій основній системі і основній системі призначення для вашого сховища даних. Це може бути спільний буфер сховища даних, NFS або будь-який інший метод створення спільного сховища даних."
 ],
 "Used": [
  null,
  "Використано"
 ],
 "Used by": [
  null,
  "Використовується"
 ],
 "User login": [
  null,
  "Користувач"
 ],
 "User login must not be empty when SSH keys are set": [
  null,
  "Якщо встановлено використання ключів SSH, ім'я користувача не може бути порожнім"
 ],
 "User login must not be empty when user password is set": [
  null,
  "Якщо встановлено пароль користувача, ім'я користувача не може бути порожнім"
 ],
 "User password": [
  null,
  "Пароль користувача"
 ],
 "User password must not be empty when user login is set": [
  null,
  "Якщо встановлено ім'я користувача, пароль користувача не може бути порожнім"
 ],
 "User session": [
  null,
  "Сеанс користувача"
 ],
 "Uses SPICE": [
  null,
  "Використовує SPICE"
 ],
 "VM $0 Host Devices": [
  null,
  "Пристрої основної системи ВМ $0"
 ],
 "VM $0 already exists": [
  null,
  "ВМ із назвою $0 вже існує"
 ],
 "VM $0 does not exist on $1 connection": [
  null,
  "На з'єднання $1 не існує ВМ $0"
 ],
 "VM $0 failed to force reboot": [
  null,
  "Не вдалося примусово перезавантажити віртуальну машину $0"
 ],
 "VM $0 failed to force shutdown": [
  null,
  "Не вдалося примусово вимкнути віртуальну машину $0"
 ],
 "VM $0 failed to get installed": [
  null,
  "Не вдалося встановити віртуальну машину $0"
 ],
 "VM $0 failed to pause": [
  null,
  "Не вдалося призупинити віртуальну машину $0"
 ],
 "VM $0 failed to reboot": [
  null,
  "Не вдалося перезавантажити віртуальну машину $0"
 ],
 "VM $0 failed to resume": [
  null,
  "Не вдалося відновити роботу віртуальної машини $0"
 ],
 "VM $0 failed to send NMI": [
  null,
  "Не вдалося надіслати NMI віртуальній машині $0"
 ],
 "VM $0 failed to shutdown": [
  null,
  "Не вдалося вимкнути віртуальну машину $0"
 ],
 "VM $0 failed to start": [
  null,
  "Не вдалося запустити віртуальну машину $0"
 ],
 "VM launched with unprivileged limited access, with the process and PTY owned by your user account": [
  null,
  "ВМ запущено із непривілейованим обмеженим доступом з процесом і PTY, власником яких є в ваш обліковий запис користувача"
 ],
 "VM needs shutdown": [
  null,
  "ВМ потребує вимикання"
 ],
 "VM state": [
  null,
  "Стан ВМ"
 ],
 "VM will launch with root permissions": [
  null,
  "ВМ буде запущено із правами доступу root"
 ],
 "VNC": [
  null,
  "VNC"
 ],
 "VNC settings could not be saved": [
  null,
  "Не вдалося зберегти параметри VNC"
 ],
 "Valid token": [
  null,
  "Чинний жетон"
 ],
 "Vendor": [
  null,
  "Постачальник"
 ],
 "Vendor support ended $0": [
  null,
  "Постачальником припинено підтримку $0"
 ],
 "Virtual machines": [
  null,
  "Віртуальні машини"
 ],
 "Virtual machines management": [
  null,
  "Керування віртуальними машинами"
 ],
 "Virtual network": [
  null,
  "Віртуальна мережа"
 ],
 "Virtual network failed to be created": [
  null,
  "Не вдалося створити віртуальну мережу"
 ],
 "Virtual socket support enables communication between the host and guest over a socket. It still requires special vsock-aware software to communicate over the socket.": [
  null,
  "Підтримка віртуальних сокетів уможливолює обмін даними між основною і гостьовою системою за допомогою сокетів. Такий обмін потребує спеціалізованого сумісного з vsock програмного забезпечення для обміну даними крізь сокет."
 ],
 "Virtualization service (libvirt) is not active": [
  null,
  "Служба віртуалізації (libvirt) не є активною"
 ],
 "Volume": [
  null,
  "Том"
 ],
 "Volume failed to be created": [
  null,
  "Не вдалося створити том"
 ],
 "Volume group name": [
  null,
  "Назва групи томів"
 ],
 "Volume group name should not be empty": [
  null,
  "Назва групи томів має бути непорожньою"
 ],
 "Vsock": [
  null,
  "Vsock"
 ],
 "WWPN": [
  null,
  "WWPN"
 ],
 "Watchdog": [
  null,
  "Сторожовик"
 ],
 "Watchdogs act when systems stop responding. To use this virtual watchdog device, the guest system also needs to have an additional driver and a running watchdog service.": [
  null,
  "Засоби нагляду (сторожовики) працюють, коли системи припиняють відповідати на запити. Щоб скористатися цим віртуальним пристроєм нагляду, у гостьовій системі також має бути додатковий драйвер і запущена служба нагляду."
 ],
 "Writeable": [
  null,
  "Придатний до запису"
 ],
 "You can mount the shared folder using:": [
  null,
  "Змонтувати спільну теку можна за допомогою такої команди:"
 ],
 "You need to select the most closely matching operating system": [
  null,
  "Вам слід вибрати найвідповіднішу операційну систему"
 ],
 "active": [
  null,
  "активний"
 ],
 "add": [
  null,
  "додати"
 ],
 "add entry": [
  null,
  "додати запис"
 ],
 "bridge": [
  null,
  "місток"
 ],
 "cdrom": [
  null,
  "cdrom"
 ],
 "custom": [
  null,
  "нетиповий"
 ],
 "direct": [
  null,
  "безпосередньо"
 ],
 "disabled": [
  null,
  "вимкнено"
 ],
 "disk": [
  null,
  "диск"
 ],
 "down": [
  null,
  "нижче"
 ],
 "edit": [
  null,
  "редагувати"
 ],
 "enabled": [
  null,
  "увімкнено"
 ],
 "ethernet": [
  null,
  "ethernet"
 ],
 "host": [
  null,
  "вузол"
 ],
 "host device": [
  null,
  "пристрій основної системи"
 ],
 "host passthrough": [
  null,
  "передавання вузла"
 ],
 "hostdev": [
  null,
  "пристрій осн. системи"
 ],
 "iSCSI direct target": [
  null,
  "Безпосереднє призначення iSCSI"
 ],
 "iSCSI initiator IQN": [
  null,
  "IQN ініціатора iSCSI"
 ],
 "iSCSI target": [
  null,
  "Ціль iSCSI"
 ],
 "iSCSI target IQN": [
  null,
  "IQN цілі iSCSI"
 ],
 "inactive": [
  null,
  "неактивний"
 ],
 "inet": [
  null,
  "inet"
 ],
 "inet6": [
  null,
  "inet6"
 ],
 "mcast": [
  null,
  "mcast"
 ],
 "more info": [
  null,
  "додаткова інформація"
 ],
 "mount point: The mount point inside the guest": [
  null,
  "точка монтування: точка монтування всередині гостьової системи"
 ],
 "mount tag: The tag associated to the exported mount point": [
  null,
  "мітка монтування: мітка, яку пов'язано із експортованою точкою монтування"
 ],
 "network": [
  null,
  "мережа"
 ],
 "no": [
  null,
  "ні"
 ],
 "no state saved": [
  null,
  "немає збережених станів"
 ],
 "none": [
  null,
  "немає"
 ],
 "redirected device": [
  null,
  "переспрямований пристрій"
 ],
 "remove": [
  null,
  "вилучити"
 ],
 "serial number": [
  null,
  "серійний номер"
 ],
 "server": [
  null,
  "сервер"
 ],
 "udp": [
  null,
  "udp"
 ],
 "up": [
  null,
  "вище"
 ],
 "user": [
  null,
  "користувач"
 ],
 "vCPU and CPU topology settings could not be saved": [
  null,
  "Не вдалося зберегти параметри топології віртуальних і звичайних процесорів"
 ],
 "vCPU count": [
  null,
  "К-ть вірт. процесорів"
 ],
 "vCPU maximum": [
  null,
  "Макс. вірт. процесорів"
 ],
 "vCPUs": [
  null,
  "Вірт. проц."
 ],
 "vhostuser": [
  null,
  "vhostuser"
 ],
 "view more...": [
  null,
  "докладніше…"
 ],
 "virt-install package needs to be installed on the system in order to clone VMs": [
  null,
  "Для клонування віртуальних машин у системі має бути встановлено пакунок virt-install"
 ],
 "virt-install package needs to be installed on the system in order to create new VMs": [
  null,
  "Для створення нових віртуальних машин у системі має бути встановлено пакунок virt-install"
 ],
 "virt-install package needs to be installed on the system in order to edit this attribute": [
  null,
  "Для редагування цього атрибута у системі має бути встановлено пакунок virt-install"
 ],
 "vsock requires special software": [
  null,
  "vsock потребує спеціалізованого програмного забезпечення"
 ],
 "yes": [
  null,
  "так"
 ]
});
