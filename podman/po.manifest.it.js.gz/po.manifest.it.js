cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "it",
  "language-direction": "ltr"
 },
 "Podman containers": [
  null,
  "Container Podman"
 ],
 "container": [
  null,
  "container"
 ],
 "image": [
  null,
  "immagine"
 ],
 "podman": [
  null,
  "podman"
 ]
});
