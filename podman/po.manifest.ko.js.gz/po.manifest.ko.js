cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "ko",
  "language-direction": "ltr"
 },
 "Podman containers": [
  null,
  "포드맨 컨테이너"
 ],
 "container": [
  null,
  "컨테이너"
 ],
 "image": [
  null,
  "이미지"
 ],
 "podman": [
  null,
  "포드맨"
 ]
});
