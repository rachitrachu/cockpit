cockpit.locale({
 "": {
  "plural-forms": (n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "uk",
  "language-direction": "ltr"
 },
 "$0 container": [
  null,
  "$0 контейнер",
  "$0 контейнери",
  "$0 контейнерів"
 ],
 "$0 image total, $1": [
  null,
  "$0 образ загалом, $1",
  "$0 образи загалом, $1",
  "$0 образів загалом, $1"
 ],
 "$0 second": [
  null,
  "$0 секунда",
  "$0 секунди",
  "$0 секунд"
 ],
 "$0 unused image, $1": [
  null,
  "$0 невикористаний образ, $1",
  "$0 невикористані образи, $1",
  "$0 невикористаних образів, $1"
 ],
 "$0% of $1 limit": [
  null,
  "$0% o з обмеження у $1"
 ],
 "1 to 65535": [
  null,
  "від 1 до 65535"
 ],
 "Action to take once the container transitions to an unhealthy state.": [
  null,
  "Дія, яку слід виконати після переходу контейнера у небезпечний стан."
 ],
 "Actions": [
  null,
  "Дії"
 ],
 "Add port mapping": [
  null,
  "Додати прив'язку портів"
 ],
 "Add variable": [
  null,
  "Додати змінну"
 ],
 "Add volume": [
  null,
  "Додати том"
 ],
 "All": [
  null,
  "Усі"
 ],
 "All registries": [
  null,
  "Усі реєстри"
 ],
 "Always": [
  null,
  "Завжди"
 ],
 "An error occurred": [
  null,
  "Сталася помилка"
 ],
 "Author": [
  null,
  "Автор"
 ],
 "CPU": [
  null,
  "Процесор"
 ],
 "CPU Shares help": [
  null,
  "Довідка щодо спільних процесорів"
 ],
 "CPU shares": [
  null,
  "Спільне використання процесора"
 ],
 "CPU shares determine the priority of running containers. Default priority is 1024. A higher number prioritizes this container. A lower number decreases priority.": [
  null,
  "Спільні процесори визначають пріоритетність запуску контейнерів. Типовою пріоритетністю є 1024. Більші числа роблять контейнер пріоритетнішим. Менші числа зменшують пріоритетність."
 ],
 "Cancel": [
  null,
  "Скасувати"
 ],
 "Checking health": [
  null,
  "Перевіряємо працездатність"
 ],
 "Checkpoint": [
  null,
  "Контрольна точка"
 ],
 "Checkpoint and restore support": [
  null,
  "Підтримка контрольних точок і відновлення"
 ],
 "Checkpoint container $0": [
  null,
  "Контрольна точка контейнера $0"
 ],
 "Click to see published ports": [
  null,
  "Натисніть, щоб переглянути оприлюднені порти"
 ],
 "Click to see volumes": [
  null,
  "Натисніть, щоб переглянути томи"
 ],
 "Command": [
  null,
  "Команда"
 ],
 "Comments": [
  null,
  "Коментарі"
 ],
 "Commit": [
  null,
  "Надіслати"
 ],
 "Commit container": [
  null,
  "Внести контейнер"
 ],
 "Configured": [
  null,
  "Налаштовано"
 ],
 "Console": [
  null,
  "Консоль"
 ],
 "Container": [
  null,
  "Контейнер"
 ],
 "Container failed to be created": [
  null,
  "Не вдалося створити контейнер"
 ],
 "Container failed to be started": [
  null,
  "Не вдалося запустити контейнер"
 ],
 "Container is not running": [
  null,
  "Контейнер не запущено"
 ],
 "Container name": [
  null,
  "Назва контейнера"
 ],
 "Container name is required.": [
  null,
  "Слід вказати назву контейнера."
 ],
 "Container path": [
  null,
  "Шлях до контейнера"
 ],
 "Container path must not be empty": [
  null,
  "Шлях до контейнера має бути непорожнім"
 ],
 "Container port": [
  null,
  "Порт контейнера"
 ],
 "Container port must not be empty": [
  null,
  "Порт контейнера має бути непорожнім"
 ],
 "Containers": [
  null,
  "Контейнери"
 ],
 "Create": [
  null,
  "Створити"
 ],
 "Create a new image based on the current state of the $0 container.": [
  null,
  "Створити образ на основі поточного стану контейнера $0."
 ],
 "Create and run": [
  null,
  "Створити і запустити"
 ],
 "Create container": [
  null,
  "Створити контейнер"
 ],
 "Create container in $0": [
  null,
  "Створити контейнер у $0"
 ],
 "Create container in pod": [
  null,
  "Створити контейнер у стручку"
 ],
 "Create pod": [
  null,
  "Створити стручок"
 ],
 "Created": [
  null,
  "Створено"
 ],
 "Created by": [
  null,
  "Створено"
 ],
 "Decrease CPU shares": [
  null,
  "Зменшити спільне використання процесора"
 ],
 "Decrease interval": [
  null,
  "Зменшити інтервал"
 ],
 "Decrease maximum retries": [
  null,
  "Зменшити максимум повторних спроб"
 ],
 "Decrease memory": [
  null,
  "Зменшити пам'ять"
 ],
 "Decrease retries": [
  null,
  "Зменшити кількість повторних спроб"
 ],
 "Decrease start period": [
  null,
  "Зменшити період запуску"
 ],
 "Decrease timeout": [
  null,
  "Зменшити час очікування"
 ],
 "Delete": [
  null,
  "Вилучити"
 ],
 "Delete $0 image?": [
  null,
  "Вилучити образ $0?"
 ],
 "Delete $0?": [
  null,
  "Вилучити $0?"
 ],
 "Delete image": [
  null,
  "Вилучити образ"
 ],
 "Delete pod $0?": [
  null,
  "Вилучити кокон $0?"
 ],
 "Delete tagged images": [
  null,
  "Вилучити позначені міткою образи"
 ],
 "Delete unused images of user $0:": [
  null,
  "Вилучити невикористані образи користувача $0:"
 ],
 "Delete unused system images:": [
  null,
  "Вилучити невикористані образи системи:"
 ],
 "Deleting a container will erase all data in it.": [
  null,
  "Вилучення контейнера призведе до витирання усіх даних, що на ньому зберігаються."
 ],
 "Deleting a running container will erase all data in it.": [
  null,
  "Вилучення запущеного контейнера призведе до витирання усіх даних, що на ньому зберігаються."
 ],
 "Deleting this pod will remove the following containers:": [
  null,
  "Вилучення цього кокону призведе до вилучення таких контейнерів:"
 ],
 "Details": [
  null,
  "Подробиці"
 ],
 "Disk space": [
  null,
  "Місце на диску"
 ],
 "Docker format is useful when sharing the image with Docker or Moby Engine": [
  null,
  "Формат Docker корисний, якщо ви захочете використовувати образ спільно у середовищах Docker або Moby Engine"
 ],
 "Download": [
  null,
  "Отримати"
 ],
 "Download new image": [
  null,
  "Отримати новий образ"
 ],
 "Empty pod $0 will be permanently removed.": [
  null,
  "Порожній кокон $0 буде остаточно вилучено."
 ],
 "Entrypoint": [
  null,
  "Точка входження"
 ],
 "Environment variables": [
  null,
  "Змінні середовища"
 ],
 "Error": [
  null,
  "Помилка"
 ],
 "Error message": [
  null,
  "Повідомлення про помилку"
 ],
 "Error occurred while connecting console": [
  null,
  "Під час спроби встановити з'єднання з консоллю сталася помилка"
 ],
 "Example, Your Name <yourname@example.com>": [
  null,
  "Приклад: Ваше Ім'я <vasheimya@example.com>"
 ],
 "Example: $0": [
  null,
  "Приклад: $0"
 ],
 "Exited": [
  null,
  "Вийшов"
 ],
 "Failed health run": [
  null,
  "Не вдалося запустити перевірку працездатності"
 ],
 "Failed to checkpoint container $0": [
  null,
  "Не вдалося створити контрольну точку контейнера $0"
 ],
 "Failed to clean up container": [
  null,
  "Не вдалося очистити контейнер"
 ],
 "Failed to commit container $0": [
  null,
  "Не вдалося надіслати на обробку контейнер $0"
 ],
 "Failed to create container $0": [
  null,
  "Не вдалося створити контейнер $0"
 ],
 "Failed to download image $0:$1": [
  null,
  "Не вдалося отримати образ $0:$1"
 ],
 "Failed to force remove container $0": [
  null,
  "Не вдалося примусово вилучити контейнер $0"
 ],
 "Failed to force remove image $0": [
  null,
  "Не вдалося примусово вилучити образ $0"
 ],
 "Failed to force restart pod $0": [
  null,
  "Не вдалося примусово перезапустити кокон $0"
 ],
 "Failed to force stop pod $0": [
  null,
  "Не вдалося примусово зупинити кокон $0"
 ],
 "Failed to pause container $0": [
  null,
  "Не вдалося призупинити роботу контейнера $0"
 ],
 "Failed to pause pod $0": [
  null,
  "Не вдалося призупинити кокон $0"
 ],
 "Failed to prune unused containers": [
  null,
  "Не вдалося позбутися невикористаних контейнерів"
 ],
 "Failed to prune unused images": [
  null,
  "Не вдалося позбутися невикористаних образів"
 ],
 "Failed to pull image $0": [
  null,
  "Не вдалося отримати образ $0"
 ],
 "Failed to remove container $0": [
  null,
  "Не вдалося вилучити контейнер $0"
 ],
 "Failed to remove image $0": [
  null,
  "Не вдалося вилучити образ $0"
 ],
 "Failed to rename container $0": [
  null,
  "Не вдалося перейменувати контейнер $0"
 ],
 "Failed to restart container $0": [
  null,
  "Не вдалося перезапустити контейнер $0"
 ],
 "Failed to restart pod $0": [
  null,
  "Не вдалося перезапустити кокон $0"
 ],
 "Failed to restore container $0": [
  null,
  "Не вдалося відновити контейнер $0"
 ],
 "Failed to resume container $0": [
  null,
  "Не вдалося відновити роботу контейнера $0"
 ],
 "Failed to resume pod $0": [
  null,
  "Не вдалося відновити кокон $0"
 ],
 "Failed to run container $0": [
  null,
  "Не вдалося запустити контейнер $0"
 ],
 "Failed to run health check on container $0": [
  null,
  "Не вдалося запустити перевірку працездатності контейнера $0"
 ],
 "Failed to search for images.": [
  null,
  "Не вдалося виконати пошук образів."
 ],
 "Failed to search for images: $0": [
  null,
  "Не вдалося виконати пошук образів: $0"
 ],
 "Failed to search for new images": [
  null,
  "Не вдалося виконати пошук нових образів"
 ],
 "Failed to start container $0": [
  null,
  "Не вдалося запустити роботу контейнера $0"
 ],
 "Failed to start pod $0": [
  null,
  "Не вдалося запустити кокон $0"
 ],
 "Failed to stop container $0": [
  null,
  "Не вдалося зупинити роботу контейнера $0"
 ],
 "Failed to stop pod $0": [
  null,
  "Не вдалося зупинити кокон $0"
 ],
 "Failing streak": [
  null,
  "Помилкова смужка"
 ],
 "Force commit": [
  null,
  "Примусово внести"
 ],
 "Force delete": [
  null,
  "Примусове вилучення"
 ],
 "Force delete pod $0?": [
  null,
  "Примусово вилучити кокон $0?"
 ],
 "Force restart": [
  null,
  "Примусовий перезапуск"
 ],
 "Force stop": [
  null,
  "Примусово зупинити"
 ],
 "GB": [
  null,
  "ГБ"
 ],
 "Gateway": [
  null,
  "Шлюз"
 ],
 "Health check": [
  null,
  "Перевірка працездатності"
 ],
 "Health check interval help": [
  null,
  "Довідка з інтервалу перевірки працездатності"
 ],
 "Health check retries help": [
  null,
  "Довідка з повторних спроб перевірки працездатності"
 ],
 "Health check start period help": [
  null,
  "Довідка із початкового періоду перевірки працездатності"
 ],
 "Health check timeout help": [
  null,
  "Довідка з часу очікування перевірки працездатності"
 ],
 "Health failure check action help": [
  null,
  "Довідка щодо дії при перевірці небезпечності стану"
 ],
 "Healthy": [
  null,
  "Працездатний"
 ],
 "Hide images": [
  null,
  "Приховати образи"
 ],
 "Hide intermediate images": [
  null,
  "Приховати проміжні образи"
 ],
 "History": [
  null,
  "Журнал"
 ],
 "Host path": [
  null,
  "Шлях у основній системі"
 ],
 "Host port": [
  null,
  "Порт в основній системі"
 ],
 "Host port help": [
  null,
  "Довідка щодо порту в основній системі"
 ],
 "ID": [
  null,
  "Ід."
 ],
 "IP address": [
  null,
  "IP-адреса"
 ],
 "IP address help": [
  null,
  "Довідка щодо IP-адреси"
 ],
 "Ideal for development": [
  null,
  "Ідеальне для розробки"
 ],
 "Ideal for running services": [
  null,
  "Ідеальне для запуску служб"
 ],
 "If host IP is set to 0.0.0.0 or not set at all, the port will be bound on all IPs on the host.": [
  null,
  "Якщо встановлено IP-адресу основної системи 0.0.0.0 або адресу не встановлено взагалі, порт буде пов'язано із усіма IP-адресами в основній системі."
 ],
 "If the host port is not set the container port will be randomly assigned a port on the host.": [
  null,
  "Якщо порт в основній системі не встановлено, порт контейнера буде випадковим чином пов'язано із портом в основній системі."
 ],
 "Ignore IP address if set statically": [
  null,
  "Ігнорувати IP-адресу, якщо її встановлено статично"
 ],
 "Ignore MAC address if set statically": [
  null,
  "Ігнорувати MAC-адресу, якщо її встановлено статично"
 ],
 "Image": [
  null,
  "Образ"
 ],
 "Image name is not unique": [
  null,
  "Назва образу не є унікальною"
 ],
 "Image name is required": [
  null,
  "Слід вказати назву образу"
 ],
 "Image selection help": [
  null,
  "Довідка щодо вибору образу"
 ],
 "Images": [
  null,
  "Образи"
 ],
 "Increase CPU shares": [
  null,
  "Збільшити спільне використання процесора"
 ],
 "Increase interval": [
  null,
  "Збільшити інтервал"
 ],
 "Increase maximum retries": [
  null,
  "Збільшити максимум повторних спроб"
 ],
 "Increase memory": [
  null,
  "Збільшити пам'ять"
 ],
 "Increase retries": [
  null,
  "Збільшити кількість повторних спроб"
 ],
 "Increase start period": [
  null,
  "Збільшити початковий період"
 ],
 "Increase timeout": [
  null,
  "Збільшити час очікування"
 ],
 "Integration": [
  null,
  "Інтеграція"
 ],
 "Interval": [
  null,
  "Інтервал"
 ],
 "Interval how often health check is run.": [
  null,
  "Частота запуску перевірки працездатності."
 ],
 "Invalid characters. Name can only contain letters, numbers, and certain punctuation (_ . -).": [
  null,
  "Некоректні символи. Назва може складатися лише з літер, цифр та деяких символів пунктуації (_ . -)."
 ],
 "KB": [
  null,
  "кБ"
 ],
 "Keep all temporary checkpoint files": [
  null,
  "Зберігати усі тимчасові файли контрольних точок"
 ],
 "Key": [
  null,
  "Ключ"
 ],
 "Key contains invalid characters": [
  null,
  "Ключ містить некоректні символи"
 ],
 "Key must not be empty": [
  null,
  "Ключ має бути непорожнім"
 ],
 "Key must not begin with a digit": [
  null,
  "Ключ не повинен починатися з цифри"
 ],
 "Last 5 runs": [
  null,
  "Останні 5 запусків"
 ],
 "Latest checkpoint": [
  null,
  "Найсвіжіша контрольна точка"
 ],
 "Leave running after writing checkpoint to disk": [
  null,
  "Лишати запущеним після запису контрольної точки на диск"
 ],
 "Loading details...": [
  null,
  "Завантаження подробиць…"
 ],
 "Loading logs...": [
  null,
  "Завантаження журналу…"
 ],
 "Loading...": [
  null,
  "Завантаження…"
 ],
 "Local": [
  null,
  "Локальний"
 ],
 "Local images": [
  null,
  "Локальні образи"
 ],
 "Logs": [
  null,
  "Журнал"
 ],
 "MAC address": [
  null,
  "MAC-адреса"
 ],
 "MB": [
  null,
  "МБ"
 ],
 "Maximum retries": [
  null,
  "Максимум повторних спроб"
 ],
 "Memory": [
  null,
  "Пам'ять"
 ],
 "Memory limit": [
  null,
  "Обмеження пам’яті"
 ],
 "Memory unit": [
  null,
  "Одиниця пам’яті"
 ],
 "Mode": [
  null,
  "Режим"
 ],
 "Multiple tags exist for this image. Select the tagged images to delete.": [
  null,
  "Для цього образу існує декілька міток. Виберіть позначені міткою образи для вилучення."
 ],
 "Must be a valid IP address": [
  null,
  "Має бути коректною IP-адресою"
 ],
 "Name": [
  null,
  "Назва"
 ],
 "Name already in use": [
  null,
  "Назву вже використано"
 ],
 "New container name": [
  null,
  "Назва нового контейнера"
 ],
 "New image name": [
  null,
  "Назва нового образу"
 ],
 "No": [
  null,
  "Ні"
 ],
 "No action": [
  null,
  "Без дії"
 ],
 "No containers": [
  null,
  "Немає контейнерів"
 ],
 "No containers are using this image": [
  null,
  "Цей образ не використовує жоден контейнер"
 ],
 "No containers in this pod": [
  null,
  "У цьому коконі немає контейнерів"
 ],
 "No containers that match the current filter": [
  null,
  "Немає контейнерів, які проходять поточні умови фільтрування"
 ],
 "No environment variables specified": [
  null,
  "Змінних середовища не визначено"
 ],
 "No images": [
  null,
  "Немає образів"
 ],
 "No images found": [
  null,
  "Образів не знайдено"
 ],
 "No images that match the current filter": [
  null,
  "Немає образів, які проходять поточні умови фільтрування"
 ],
 "No label": [
  null,
  "Немає мітки"
 ],
 "No ports exposed": [
  null,
  "Не відкрито жодного порту"
 ],
 "No results for $0": [
  null,
  "Немає результатів, що відповідають $0"
 ],
 "No running containers": [
  null,
  "Немає запущених контейнерів"
 ],
 "No volumes specified": [
  null,
  "Томів не визначено"
 ],
 "On failure": [
  null,
  "При помилці"
 ],
 "Only running": [
  null,
  "Лише запущені"
 ],
 "Options": [
  null,
  "Параметри"
 ],
 "Owner": [
  null,
  "Власник"
 ],
 "Owner help": [
  null,
  "Довідка щодо власника"
 ],
 "Passed health run": [
  null,
  "Перевірку працездатності пройдено"
 ],
 "Paste one or more lines of key=value pairs into any field for bulk import": [
  null,
  "Вставте один або декілька рядків у форматі парт «ключ=значення» до будь-якого поля для пакетного імпортування"
 ],
 "Pause": [
  null,
  "Призупинити"
 ],
 "Pause container when creating image": [
  null,
  "Призупинити роботу контейнера при створенні образу"
 ],
 "Paused": [
  null,
  "Призупинено"
 ],
 "Pod failed to be created": [
  null,
  "Не вдалося створити стручок"
 ],
 "Pod name": [
  null,
  "Назва стручка"
 ],
 "Podman service failed": [
  null,
  "Помилка служби Podman"
 ],
 "Port mapping": [
  null,
  "Прив'язка портів"
 ],
 "Ports": [
  null,
  "Порти"
 ],
 "Ports under 1024 can be mapped": [
  null,
  "Можна прив'язувати порти нижче 1024"
 ],
 "Private": [
  null,
  "Приватний"
 ],
 "Protocol": [
  null,
  "Протокол"
 ],
 "Prune": [
  null,
  "Позбутися"
 ],
 "Prune unused containers": [
  null,
  "Позбутися невикористаних контейнерів"
 ],
 "Prune unused images": [
  null,
  "Позбутися невикористаних образів"
 ],
 "Pruning containers": [
  null,
  "Очищуємо контейнери"
 ],
 "Pruning images": [
  null,
  "Позбуваємося образів"
 ],
 "Pull": [
  null,
  "Отримати"
 ],
 "Pull all images": [
  null,
  "Отримати усі образи"
 ],
 "Pull latest image": [
  null,
  "Отримати найсвіжіший образ"
 ],
 "Pulling": [
  null,
  "Отримання даних"
 ],
 "Read-only access": [
  null,
  "Доступ лише до читання"
 ],
 "Read-write access": [
  null,
  "Доступ до читання і запису"
 ],
 "Remove item": [
  null,
  "Вилучити запис"
 ],
 "Removes selected non-running containers": [
  null,
  "Вилучає позначені незапущені контейнери"
 ],
 "Removing": [
  null,
  "Вилучення"
 ],
 "Rename": [
  null,
  "Перейменувати"
 ],
 "Rename container $0": [
  null,
  "Перейменувати контейнер $0"
 ],
 "Resource limits can be set": [
  null,
  "Можна встановлювати обмеження на ресурси"
 ],
 "Restart": [
  null,
  "Перезапустити"
 ],
 "Restart policy": [
  null,
  "Правила перезапуску"
 ],
 "Restart policy help": [
  null,
  "Довідка щодо правил перезапуску"
 ],
 "Restart policy to follow when containers exit.": [
  null,
  "Правила перезапуску, які слід виконувати при виході з контейнерів."
 ],
 "Restart policy to follow when containers exit. Using linger for auto-starting containers may not work in some circumstances, such as when ecryptfs, systemd-homed, NFS, or 2FA are used on a user account.": [
  null,
  "Перезапускати правила після виходу з контейнерів. Використання очікування для автозапуску контейнерів може за певних обставин не працювати, зокрема воно не працює, якщо для облікового запису користувача використано ecryptfs, systemd-homed, NFS або 2FA."
 ],
 "Restore": [
  null,
  "Відновити"
 ],
 "Restore container $0": [
  null,
  "Відновити контейнер $0"
 ],
 "Restore with established TCP connections": [
  null,
  "Відновити із встановленими з'єднаннями TCP"
 ],
 "Restricted by user account permissions": [
  null,
  "Обмежено правами доступу до облікового запису користувача"
 ],
 "Resume": [
  null,
  "Продовжити"
 ],
 "Retries": [
  null,
  "Повторні спроби"
 ],
 "Retry another term.": [
  null,
  "Повторіть спробу із іншим ключем пошуку."
 ],
 "Run health check": [
  null,
  "Виконати перевірку працездатності"
 ],
 "Running": [
  null,
  "Запущено"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Search by name or description": [
  null,
  "Шукати за назвою і описом"
 ],
 "Search by registry": [
  null,
  "Шукати за реєстром"
 ],
 "Search for": [
  null,
  "Шукати"
 ],
 "Search for an image": [
  null,
  "Шукати образ"
 ],
 "Search string or container location": [
  null,
  "Рядок для пошуку або розташування контейнера"
 ],
 "Searching...": [
  null,
  "Пошук…"
 ],
 "Searching: $0": [
  null,
  "Шукаємо: $0"
 ],
 "Shared": [
  null,
  "Спільний"
 ],
 "Show": [
  null,
  "Показати"
 ],
 "Show images": [
  null,
  "Показати образи"
 ],
 "Show intermediate images": [
  null,
  "Показати проміжні образи"
 ],
 "Show less": [
  null,
  "Стислий показ"
 ],
 "Show more": [
  null,
  "Додаткові відомості"
 ],
 "Size": [
  null,
  "Розмір"
 ],
 "Start": [
  null,
  "Запустити"
 ],
 "Start period": [
  null,
  "Початковий період"
 ],
 "Start typing to look for images.": [
  null,
  "Почніть щось вводити, щоб виконати пошук образів."
 ],
 "Started at": [
  null,
  "Запущено"
 ],
 "State": [
  null,
  "Стан"
 ],
 "Status": [
  null,
  "Стан"
 ],
 "Stop": [
  null,
  "Зупинити"
 ],
 "Stopped": [
  null,
  "Зупинено"
 ],
 "Support preserving established TCP connections": [
  null,
  "Підтримка збереження встановлених з'єднань TCP"
 ],
 "System": [
  null,
  "Система"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "Tag": [
  null,
  "Мітка"
 ],
 "Tags": [
  null,
  "Мітки"
 ],
 "The initialization time needed for a container to bootstrap.": [
  null,
  "Час ініціалізації, потрібний контейнеру для самозапуску."
 ],
 "The maximum time allowed to complete the health check before an interval is considered failed.": [
  null,
  "Максимальний припустимий час для завершення перевірки працездатності до моменту реєстрації помилки."
 ],
 "The number of retries allowed before a healthcheck is considered to be unhealthy.": [
  null,
  "Кількість повторних спроб, якими можна скористатися, доки перевірка працездатності вважатиметься непройденою."
 ],
 "Timeout": [
  null,
  "Час очікування"
 ],
 "Troubleshoot": [
  null,
  "Діагностика проблем"
 ],
 "Type to filter…": [
  null,
  "Введіть щось для фільтрування…"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Unable to load image history": [
  null,
  "Не вдалося завантажити журнал образу"
 ],
 "Unhealthy": [
  null,
  "Непрацездатний"
 ],
 "Up since:": [
  null,
  "Працює з:"
 ],
 "Use legacy Docker format": [
  null,
  "Скористатися застарілим форматом Docker"
 ],
 "Used by": [
  null,
  "Використовується"
 ],
 "User": [
  null,
  "Користувач"
 ],
 "User:": [
  null,
  "Користувач:"
 ],
 "Value": [
  null,
  "Значення"
 ],
 "View $0": [
  null,
  "Перегляд $0"
 ],
 "View $0 logs": [
  null,
  "Перегляд журналу $0"
 ],
 "Volumes": [
  null,
  "Томи"
 ],
 "When unhealthy": [
  null,
  "Якщо непрацездатні"
 ],
 "With terminal": [
  null,
  "За допомогою термінала"
 ],
 "Writable": [
  null,
  "Придатний до запису"
 ],
 "downloading": [
  null,
  "отримання"
 ],
 "host[:port]/[user]/container[:tag]": [
  null,
  "вузол[:порт]/[користувач]/контейнер[:мітка]"
 ],
 "in": [
  null,
  "у"
 ],
 "intermediate": [
  null,
  "проміжний"
 ],
 "intermediate image": [
  null,
  "проміжний образ"
 ],
 "n/a": [
  null,
  "н/д"
 ],
 "not available": [
  null,
  "не доступне"
 ],
 "pod": [
  null,
  "кокон"
 ],
 "ports": [
  null,
  "порти"
 ],
 "seconds": [
  null,
  "секунд"
 ],
 "service": [
  null,
  "служба"
 ],
 "system": [
  null,
  "система"
 ],
 "systemd service": [
  null,
  "служба systemd"
 ],
 "unused": [
  null,
  "не використано"
 ],
 "user": [
  null,
  "користувач"
 ],
 "user:": [
  null,
  "користувач:"
 ],
 "volumes": [
  null,
  "томи"
 ]
});
