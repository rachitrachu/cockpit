cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "fi",
  "language-direction": "ltr"
 },
 "$0 container": [
  null,
  "$0 kontti",
  "$0 konttia"
 ],
 "$0 image total, $1": [
  null,
  "$0 levykuva yhteensä, $1",
  "$0 levykuvaa yhteensä, $1"
 ],
 "$0 second": [
  null,
  "$0 sekunti",
  "$0 sekuntia"
 ],
 "$0 unused image, $1": [
  null,
  "$0 käyttämätön levykuva, $1",
  "$0 käyttämätöntä levykuvaa, $1"
 ],
 "$0% of $1 limit": [
  null,
  "$0 % $1 rajasta"
 ],
 "1 to 65535": [
  null,
  "1–65535"
 ],
 "Action to take once the container transitions to an unhealthy state.": [
  null,
  "Toimenpiteet, kun kontti siirtyy epäterveelliseen tilaan."
 ],
 "Actions": [
  null,
  "Toimet"
 ],
 "Add port mapping": [
  null,
  "Lisää porttiassosiaatio"
 ],
 "Add variable": [
  null,
  "Lisää muuttuja"
 ],
 "Add volume": [
  null,
  "Lisää taltio"
 ],
 "All": [
  null,
  "Kaikki"
 ],
 "All registries": [
  null,
  "Kaikki rekisterit"
 ],
 "Always": [
  null,
  "Aina"
 ],
 "An error occurred": [
  null,
  "Tapahtui virhe"
 ],
 "Author": [
  null,
  "Tekijä"
 ],
 "CPU": [
  null,
  "Suoritin"
 ],
 "CPU Shares help": [
  null,
  "Ohjeita CPU-osuuksista"
 ],
 "CPU shares": [
  null,
  "Suoritinosuus"
 ],
 "CPU shares determine the priority of running containers. Default priority is 1024. A higher number prioritizes this container. A lower number decreases priority.": [
  null,
  "CPU-osuudet määrittävät käynnissä olevien konttien prioriteetin. Oletusprioriteetti on 1024. Suurempi numero priorisoi tätä konttia. Pienempi numero laskee prioriteettia."
 ],
 "Cancel": [
  null,
  "Peru"
 ],
 "Checking health": [
  null,
  "Tarkistetaan tilaa"
 ],
 "Checkpoint": [
  null,
  "Tarkistuspiste"
 ],
 "Checkpoint and restore support": [
  null,
  "Tarkistuspisteen ja palautuksen tuki"
 ],
 "Checkpoint container $0": [
  null,
  "Luo tarkistuspiste kontista $0"
 ],
 "Click to see published ports": [
  null,
  "Napsauta nähdäksesi julkaistut portit"
 ],
 "Click to see volumes": [
  null,
  "Napsauta nähdäksesi taltiot"
 ],
 "Command": [
  null,
  "Komento"
 ],
 "Comments": [
  null,
  "Kommentit"
 ],
 "Commit": [
  null,
  "Kommitoi"
 ],
 "Commit container": [
  null,
  "Kommitoi kontti"
 ],
 "Configured": [
  null,
  "Asetukset asetettu"
 ],
 "Console": [
  null,
  "Konsoli"
 ],
 "Container": [
  null,
  "Kontti"
 ],
 "Container failed to be created": [
  null,
  "Kontin luonti epäonnistui"
 ],
 "Container failed to be started": [
  null,
  "Kontin käynnistys epäonnistui"
 ],
 "Container is not running": [
  null,
  "Kontti ei ole käynnissä"
 ],
 "Container name": [
  null,
  "Kontin nimi"
 ],
 "Container name is required.": [
  null,
  "Kontin nimi vaaditaan."
 ],
 "Container path": [
  null,
  "Kontin polku"
 ],
 "Container path must not be empty": [
  null,
  "Kontin polku ei saa olla tyhjä"
 ],
 "Container port": [
  null,
  "Kontin portti"
 ],
 "Container port must not be empty": [
  null,
  "Kontin portti ei saa olla tyhjä"
 ],
 "Containers": [
  null,
  "Kontit"
 ],
 "Create": [
  null,
  "Luo"
 ],
 "Create a new image based on the current state of the $0 container.": [
  null,
  "Luo uusi levykuva $0-kontin nykyisen tilan perusteella."
 ],
 "Create and run": [
  null,
  "Luo ja suorita"
 ],
 "Create container": [
  null,
  "Luo kontti"
 ],
 "Create container in $0": [
  null,
  "Luo kontti kohteeseen $0"
 ],
 "Create container in pod": [
  null,
  "Luo kontti podiin"
 ],
 "Create pod": [
  null,
  "Luo podi"
 ],
 "Created": [
  null,
  "Luotu"
 ],
 "Created by": [
  null,
  "Tekijä"
 ],
 "Decrease CPU shares": [
  null,
  "Vähennä suoritinosuuksia"
 ],
 "Decrease interval": [
  null,
  "Pienennä väliä"
 ],
 "Decrease maximum retries": [
  null,
  "Pienennä uudelleenyritysten enimmäismäärää"
 ],
 "Decrease memory": [
  null,
  "Vähennä muistia"
 ],
 "Decrease retries": [
  null,
  "Vähennä uudelleenyrityksiä"
 ],
 "Decrease start period": [
  null,
  "Pienennä aloitusaikaa"
 ],
 "Decrease timeout": [
  null,
  "Pienennä aikakatkaisua"
 ],
 "Delete": [
  null,
  "Poista"
 ],
 "Delete $0 image?": [
  null,
  "Poistetaanko $0 kuva?"
 ],
 "Delete $0?": [
  null,
  "Poista $0?"
 ],
 "Delete image": [
  null,
  "Poista levykuva"
 ],
 "Delete pod $0?": [
  null,
  "Poista podi $0?"
 ],
 "Delete tagged images": [
  null,
  "Poista merkityt kuvat"
 ],
 "Delete unused images of user $0:": [
  null,
  "Poista käyttäjän $0 käyttämättömät levykuvat:"
 ],
 "Delete unused system images:": [
  null,
  "Poista käyttämättömät järjestelmälevykuvat:"
 ],
 "Deleting a container will erase all data in it.": [
  null,
  "Kontin poistaminen tuhoaa kaiken sillä olevan datan."
 ],
 "Deleting a running container will erase all data in it.": [
  null,
  "Käynnissä olevan kontin poistaminen tuhoaa kaiken sillä olevan datan."
 ],
 "Deleting this pod will remove the following containers:": [
  null,
  "Tämän podin poisto poistaa seuraavat kontit:"
 ],
 "Details": [
  null,
  "Yksityiskohdat"
 ],
 "Disk space": [
  null,
  "Levytila"
 ],
 "Docker format is useful when sharing the image with Docker or Moby Engine": [
  null,
  "Docker-muoto on hyödyllinen, kun levykuvaa jaetaan Dockerin tai Moby Enginen kanssa"
 ],
 "Download": [
  null,
  "Lataa"
 ],
 "Download new image": [
  null,
  "Lataa uusi levykuva"
 ],
 "Empty pod $0 will be permanently removed.": [
  null,
  "Tyhjä podi $0 poistetaan pysyvästi."
 ],
 "Entrypoint": [
  null,
  "Sisääntulokohta"
 ],
 "Environment variables": [
  null,
  "Ympäristömuuttujat"
 ],
 "Error": [
  null,
  "Virhe"
 ],
 "Error message": [
  null,
  "Virheviesti"
 ],
 "Error occurred while connecting console": [
  null,
  "Virhe konsolia liitettäessä"
 ],
 "Example, Your Name <yourname@example.com>": [
  null,
  "Esimerkki: Nimesi <nimesi@esimerkki.fi>"
 ],
 "Example: $0": [
  null,
  "Esimerkki: $0"
 ],
 "Exited": [
  null,
  "Päättyi"
 ],
 "Failed health run": [
  null,
  "Epäonnistunut eheysajo"
 ],
 "Failed to checkpoint container $0": [
  null,
  "Kontin $0 tarkistuspisteen luominen epäonnistui"
 ],
 "Failed to clean up container": [
  null,
  "Kontin poistaminen epäonnistui"
 ],
 "Failed to commit container $0": [
  null,
  "Kontin $0 kommitointi epäonnistui"
 ],
 "Failed to create container $0": [
  null,
  "Kontin $0 luominen epäonnistui"
 ],
 "Failed to download image $0:$1": [
  null,
  "Levykuvan lataaminen epäonnistui $0:$1"
 ],
 "Failed to force remove container $0": [
  null,
  "Kontin $0 pakotettu poistaminen epäonnistui"
 ],
 "Failed to force remove image $0": [
  null,
  "Levykuvan $0 pakotettu poistaminen epäonnistui"
 ],
 "Failed to force restart pod $0": [
  null,
  "Podin $0 pakotettu uudelleenkäynnistäminen epäonnistui"
 ],
 "Failed to force stop pod $0": [
  null,
  "Podin $0 pakotettu pysäyttäminen epäonnistui"
 ],
 "Failed to pause container $0": [
  null,
  "Kontin $0 keskeyttäminen epäonnistui"
 ],
 "Failed to pause pod $0": [
  null,
  "Podin $0 keskeyttäminen epäonnistui"
 ],
 "Failed to prune unused containers": [
  null,
  "Käyttämättömien konttien poisto epäonnistui"
 ],
 "Failed to prune unused images": [
  null,
  "Käyttämättömien levykuvien karsiminen epäonnistui"
 ],
 "Failed to pull image $0": [
  null,
  "Levykuvan $0 hakeminen epäonnistui"
 ],
 "Failed to remove container $0": [
  null,
  "Kontin $0 poistaminen epäonnistui"
 ],
 "Failed to remove image $0": [
  null,
  "Levykuvan $0 poistaminen epäonnistui"
 ],
 "Failed to rename container $0": [
  null,
  "Kontin $0 uudelleennimeäminen epäonnistui"
 ],
 "Failed to restart container $0": [
  null,
  "Kontin $0 uudelleenkäynnistäminen epäonnistui"
 ],
 "Failed to restart pod $0": [
  null,
  "Podin $0 uudelleenkäynnistäminen epäonnistui"
 ],
 "Failed to restore container $0": [
  null,
  "Kontin $0 palauttaminen epäonnistui"
 ],
 "Failed to resume container $0": [
  null,
  "Kontin $0 palauttaminen epäonnistui"
 ],
 "Failed to resume pod $0": [
  null,
  "Podin $0 käytön jatkaminen epäonnistui"
 ],
 "Failed to run container $0": [
  null,
  "Kontin $0 suorittaminen epäonnistui"
 ],
 "Failed to run health check on container $0": [
  null,
  "Kontin $0 eheystarkastus epäonnistui"
 ],
 "Failed to search for images.": [
  null,
  "Levykuvien etsintä epäonnistui."
 ],
 "Failed to search for images: $0": [
  null,
  "Levykuvien etsintä epäonnistui: $0"
 ],
 "Failed to search for new images": [
  null,
  "Uusien levykuvien etsintä epäonnistui"
 ],
 "Failed to start container $0": [
  null,
  "Kontin $0 käynnistäminen epäonnistui"
 ],
 "Failed to start pod $0": [
  null,
  "Podin $0 käynnistäminen epäonnistui"
 ],
 "Failed to stop container $0": [
  null,
  "Kontin $0 pysäyttäminen epäonnistui"
 ],
 "Failed to stop pod $0": [
  null,
  "Podin $0 pysäyttäminen epäonnistui"
 ],
 "Failing streak": [
  null,
  "Epäonnistunut sarja"
 ],
 "Force commit": [
  null,
  "Pakota kommitti"
 ],
 "Force delete": [
  null,
  "Pakota poisto"
 ],
 "Force delete pod $0?": [
  null,
  "Pakota podin $0 poisto?"
 ],
 "Force restart": [
  null,
  "Pakota uudelleenkäynnistys"
 ],
 "Force stop": [
  null,
  "Pakota pysäytys"
 ],
 "GB": [
  null,
  "Gt"
 ],
 "Gateway": [
  null,
  "Yhdyskäytävä"
 ],
 "Health check": [
  null,
  "Eheystarkistus"
 ],
 "Health check interval help": [
  null,
  "Tietoa eheystarkistuksen aikavälistä"
 ],
 "Health check retries help": [
  null,
  "Tietoa eheystarkistuksen uudelleenyrityksistä"
 ],
 "Health check start period help": [
  null,
  "Tietoa eheystarkistuksen aloitusjaksosta"
 ],
 "Health check timeout help": [
  null,
  "Tietoa eheystarkistuksen aikakatkaisusta"
 ],
 "Health failure check action help": [
  null,
  "Tietoa terveystarkistuksen virhetilan toimenpiteistä"
 ],
 "Healthy": [
  null,
  "Ehjä"
 ],
 "Hide images": [
  null,
  "Piilota levykuvat"
 ],
 "Hide intermediate images": [
  null,
  "Piilota välivaiheen levykuvat"
 ],
 "History": [
  null,
  "Historia"
 ],
 "Host path": [
  null,
  "Koneen polku"
 ],
 "Host port": [
  null,
  "Koneen portti"
 ],
 "Host port help": [
  null,
  "Ohjeita koneen portista"
 ],
 "ID": [
  null,
  "TUNNISTE"
 ],
 "IP address": [
  null,
  "IP-osoite"
 ],
 "IP address help": [
  null,
  "Ohjeita IP-osoitteesta"
 ],
 "Ideal for development": [
  null,
  "Ihanteellinen kehittämiseen"
 ],
 "Ideal for running services": [
  null,
  "Ihanteellinen palvelujen suorittamiseen"
 ],
 "If host IP is set to 0.0.0.0 or not set at all, the port will be bound on all IPs on the host.": [
  null,
  "Jos isäntäkoneen IP-osoitteeksi on asetettu 0.0.0.0 tai sitä ei ole määritetty lainkaan, portti sidotaan kaikkiin isäntäkoneen IP-osoitteisiin."
 ],
 "If the host port is not set the container port will be randomly assigned a port on the host.": [
  null,
  "Jos isäntäporttia ei ole asetettu, konttiportille määritetään satunnainen isäntäportti."
 ],
 "Ignore IP address if set statically": [
  null,
  "Ohita IP-osoite, jos se on asetettu staattisesti"
 ],
 "Ignore MAC address if set statically": [
  null,
  "Ohita MAC-osoite, jos se on asetettu staattisesti"
 ],
 "Image": [
  null,
  "Levykuva"
 ],
 "Image name is not unique": [
  null,
  "Kevykuvan nimi ei ole ainutlaatuinen"
 ],
 "Image name is required": [
  null,
  "Levykuvan nimi vaaditaan"
 ],
 "Image selection help": [
  null,
  "Ohjeita levykuvan valintaan"
 ],
 "Images": [
  null,
  "Levykuvat"
 ],
 "Increase CPU shares": [
  null,
  "Lisää suoritinosuuksia"
 ],
 "Increase interval": [
  null,
  "Suurenna väliä"
 ],
 "Increase maximum retries": [
  null,
  "Lisää uudelleenyritysten enimmäismäärää"
 ],
 "Increase memory": [
  null,
  "Lisää muistia"
 ],
 "Increase retries": [
  null,
  "Lisää uudelleenyrityksiä"
 ],
 "Increase start period": [
  null,
  "Pidennä aloitusjaksoa"
 ],
 "Increase timeout": [
  null,
  "Nosta aikakatkaisua"
 ],
 "Integration": [
  null,
  "Integraatio"
 ],
 "Interval": [
  null,
  "Aikaväli"
 ],
 "Interval how often health check is run.": [
  null,
  "Eheystarkistusten aikaväli."
 ],
 "Invalid characters. Name can only contain letters, numbers, and certain punctuation (_ . -).": [
  null,
  "Virheellisiä merkkejä. Nimi voi sisältää vain kirjaimia, numeroita ja tiettyjä välimerkkejä (_ . -)."
 ],
 "KB": [
  null,
  "Kt"
 ],
 "Keep all temporary checkpoint files": [
  null,
  "Säilytä kaikki väliaikaiset tarkistuspistetiedostot"
 ],
 "Key": [
  null,
  "Avain"
 ],
 "Key contains invalid characters": [
  null,
  "Avain sisältää virheellisiä merkkejä"
 ],
 "Key must not be empty": [
  null,
  "Avain ei saa olla tyhjä"
 ],
 "Key must not begin with a digit": [
  null,
  "Avain ei saa alkaa numerolla"
 ],
 "Last 5 runs": [
  null,
  "Viimeiset 5 ajoa"
 ],
 "Latest checkpoint": [
  null,
  "Viimeisin tarkistuspiste"
 ],
 "Leave running after writing checkpoint to disk": [
  null,
  "Jätä käyntiin tarkistuspisteen levylle kirjoittamisen jälkeen"
 ],
 "Loading details...": [
  null,
  "Ladataan tietoja..."
 ],
 "Loading logs...": [
  null,
  "Ladataan lokeja..."
 ],
 "Loading...": [
  null,
  "Ladataan..."
 ],
 "Local": [
  null,
  "Paikallinen"
 ],
 "Local images": [
  null,
  "Paikallisia levykuvia"
 ],
 "Logs": [
  null,
  "Lokit"
 ],
 "MAC address": [
  null,
  "MAC-osoite"
 ],
 "MB": [
  null,
  "Mt"
 ],
 "Maximum retries": [
  null,
  "Uudelleenyritysten enimmäismäärä"
 ],
 "Memory": [
  null,
  "Muisti"
 ],
 "Memory limit": [
  null,
  "Muistiraja"
 ],
 "Memory unit": [
  null,
  "Muistiyksikkö"
 ],
 "Mode": [
  null,
  "Tila"
 ],
 "Multiple tags exist for this image. Select the tagged images to delete.": [
  null,
  "Tälle levykuvalle on useita tunnisteita. Valitse tunnisteelliset levykuvat jotka poistetaan."
 ],
 "Must be a valid IP address": [
  null,
  "On oltava kelvollinen IP-osoite"
 ],
 "Name": [
  null,
  "Nimi"
 ],
 "Name already in use": [
  null,
  "Nimi on jo käytössä"
 ],
 "New container name": [
  null,
  "Kontin uusi nimi"
 ],
 "New image name": [
  null,
  "Uusi levykuvan nimi"
 ],
 "No": [
  null,
  "Ei"
 ],
 "No action": [
  null,
  "Ei toimintoa"
 ],
 "No containers": [
  null,
  "Ei kontteja"
 ],
 "No containers are using this image": [
  null,
  "Yksikään kontti ei käytä tätä levykuvaa"
 ],
 "No containers in this pod": [
  null,
  "Tässä podissa ei ole kontteja"
 ],
 "No containers that match the current filter": [
  null,
  "Ei nykyistä suodatusta vastaavia kontteja"
 ],
 "No environment variables specified": [
  null,
  "Ympäristömuuttujia ei ole määritetty"
 ],
 "No images": [
  null,
  "Ei levykuvia"
 ],
 "No images found": [
  null,
  "Levykuvia ei löytynyt"
 ],
 "No images that match the current filter": [
  null,
  "Ei nykyistä suodatusta vastaavia levykuvia"
 ],
 "No label": [
  null,
  "Ei nimiötä"
 ],
 "No ports exposed": [
  null,
  "Ei paljastettuja portteja"
 ],
 "No results for $0": [
  null,
  "Ei tuloksia hakusanalle $0"
 ],
 "No running containers": [
  null,
  "Ei käynnissä olevia kontteja"
 ],
 "No volumes specified": [
  null,
  "Taltiota ei ole määritelty"
 ],
 "On failure": [
  null,
  "Epäonnistumisesta"
 ],
 "Only running": [
  null,
  "Vain käynnissä olevat"
 ],
 "Options": [
  null,
  "Valinnat"
 ],
 "Owner": [
  null,
  "omistaja"
 ],
 "Owner help": [
  null,
  "Omistajan ohjeet"
 ],
 "Passed health run": [
  null,
  "Onnistunut eheysajo"
 ],
 "Paste one or more lines of key=value pairs into any field for bulk import": [
  null,
  "Liitä yksi tai useampi rivi avain=arvo-pareja mihin tahansa kenttään joukkotuontia varten"
 ],
 "Pause": [
  null,
  "Keskeytä"
 ],
 "Pause container when creating image": [
  null,
  "Pysäytä kontti levykuvan luomisen ajaksi"
 ],
 "Paused": [
  null,
  "Keskeytetty"
 ],
 "Pod failed to be created": [
  null,
  "Podin luonti epäonnistui"
 ],
 "Pod name": [
  null,
  "Podin nimi"
 ],
 "Podman service failed": [
  null,
  "Podman-palvelu epäonnistui"
 ],
 "Port mapping": [
  null,
  "Porttiassosiaatio"
 ],
 "Ports": [
  null,
  "Portit"
 ],
 "Ports under 1024 can be mapped": [
  null,
  "Portit alle 1024 voidaan kartoittaa"
 ],
 "Private": [
  null,
  "Yksityinen"
 ],
 "Protocol": [
  null,
  "Protokolla"
 ],
 "Prune": [
  null,
  "Karsi"
 ],
 "Prune unused containers": [
  null,
  "Poista käyttämättömiä kontteja"
 ],
 "Prune unused images": [
  null,
  "Karsi käyttämättömät levykuvat"
 ],
 "Pruning containers": [
  null,
  "Siivotaan kontteja"
 ],
 "Pruning images": [
  null,
  "Karsitaan levykuvia"
 ],
 "Pull": [
  null,
  "Vedä"
 ],
 "Pull all images": [
  null,
  "Vedä kaikki kuvat"
 ],
 "Pull latest image": [
  null,
  "Hae viimeisin levykuva"
 ],
 "Pulling": [
  null,
  "Haetaan"
 ],
 "Read-only access": [
  null,
  "Vain luku-käyttöoikeus"
 ],
 "Read-write access": [
  null,
  "Luku-kirjoitusoikeus"
 ],
 "Remove item": [
  null,
  "Poista kohde"
 ],
 "Removes selected non-running containers": [
  null,
  "Poistaa valitut ei käynnissä olevat kontit"
 ],
 "Removing": [
  null,
  "Poistetaan"
 ],
 "Rename": [
  null,
  "Nimeä uudelleen"
 ],
 "Rename container $0": [
  null,
  "Nimeä kontti $0 uudelleen"
 ],
 "Resource limits can be set": [
  null,
  "Resurssirajoja voidaan asettaa"
 ],
 "Restart": [
  null,
  "Käynnistä uudelleen"
 ],
 "Restart policy": [
  null,
  "Uudelleenkäynnistyksen käytäntö"
 ],
 "Restart policy help": [
  null,
  "Ohjeita uudelleenkäynnistyksen käytännöstä"
 ],
 "Restart policy to follow when containers exit.": [
  null,
  "Noudata uudelleenkäynnistyskäytäntöä, kun kontit poistuvat."
 ],
 "Restart policy to follow when containers exit. Using linger for auto-starting containers may not work in some circumstances, such as when ecryptfs, systemd-homed, NFS, or 2FA are used on a user account.": [
  null,
  "Käytettävä uudelleenkäynnistyskäytäntö, kun kontit poistuvat. Viivyttämisen käyttäminen konttien automaattiseen käynnistykseen ei välttämättä toimi joissain olosuhteissa, kuten kun käyttäjätilillä on käytössä ecryptfs, systemd-homed, NFS tai 2FA."
 ],
 "Restore": [
  null,
  "Palauta"
 ],
 "Restore container $0": [
  null,
  "Palauta kontti $0"
 ],
 "Restore with established TCP connections": [
  null,
  "Palauta käyttäen luotuja TCP-yhteyksiä"
 ],
 "Restricted by user account permissions": [
  null,
  "Rajoitettu käyttäjätilin käyttöoikeuksilla"
 ],
 "Resume": [
  null,
  "Jatka"
 ],
 "Retries": [
  null,
  "Uudelleenyritykset"
 ],
 "Retry another term.": [
  null,
  "Yritä toisella termillä uudelleen."
 ],
 "Run health check": [
  null,
  "Aja eheystarkistus"
 ],
 "Running": [
  null,
  "Käynnissä"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Search by name or description": [
  null,
  "Hae nimen tai kuvauksen perusteella"
 ],
 "Search by registry": [
  null,
  "Haku rekisterin perusteella"
 ],
 "Search for": [
  null,
  "Etsittävä"
 ],
 "Search for an image": [
  null,
  "Etsi levykuvaa"
 ],
 "Search string or container location": [
  null,
  "Hae merkkijonon tai kontin sijaintia"
 ],
 "Searching...": [
  null,
  "Etsitään..."
 ],
 "Searching: $0": [
  null,
  "Etsitään: $0"
 ],
 "Shared": [
  null,
  "Jaettu"
 ],
 "Show": [
  null,
  "Näytä"
 ],
 "Show images": [
  null,
  "Näytä levykuvat"
 ],
 "Show intermediate images": [
  null,
  "Näytä välivaiheen levykuvat"
 ],
 "Show less": [
  null,
  "Näytä vähemmän"
 ],
 "Show more": [
  null,
  "Näytä lisää"
 ],
 "Size": [
  null,
  "Koko"
 ],
 "Start": [
  null,
  "Käynnistä"
 ],
 "Start period": [
  null,
  "Aloitusjakso"
 ],
 "Start typing to look for images.": [
  null,
  "Aloita kirjoittaminen etsiäksesi levykuvia."
 ],
 "Started at": [
  null,
  "Käynnistetty klo"
 ],
 "State": [
  null,
  "Tila"
 ],
 "Status": [
  null,
  "Tila"
 ],
 "Stop": [
  null,
  "Pysäytä"
 ],
 "Stopped": [
  null,
  "Pysäytetty"
 ],
 "Support preserving established TCP connections": [
  null,
  "Tue jo luotujen TCP -yhteyksien säilyttämistä"
 ],
 "System": [
  null,
  "Järjestelmä"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "Tag": [
  null,
  "Tunniste"
 ],
 "Tags": [
  null,
  "Tunnisteet"
 ],
 "The initialization time needed for a container to bootstrap.": [
  null,
  "Alustusaika, joka tarvitaan kontin käynnistymiseen."
 ],
 "The maximum time allowed to complete the health check before an interval is considered failed.": [
  null,
  "Enimmäisaika, joka on sallittu eheystarkastuksen suorittamiseen ennen kuin se katsotaan epäonnistuneeksi."
 ],
 "The number of retries allowed before a healthcheck is considered to be unhealthy.": [
  null,
  "Yritysten enimmäismäärä, joka on sallittu eheystarkastuksen suorittamiseen ennen kuin se katsotaan epäonnistuneeksi."
 ],
 "Timeout": [
  null,
  "Aikakatkaisu"
 ],
 "Troubleshoot": [
  null,
  "Vianetsintä"
 ],
 "Type to filter…": [
  null,
  "Kirjoita suodattaaksesi…"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Unable to load image history": [
  null,
  "Levykuvan historian lataaminen epäonnistui"
 ],
 "Unhealthy": [
  null,
  "Rikki"
 ],
 "Up since:": [
  null,
  "Käynnissä lähtien:"
 ],
 "Use legacy Docker format": [
  null,
  "Käytä vanhaa Docker-muotoa"
 ],
 "Used by": [
  null,
  "Käyttää"
 ],
 "User": [
  null,
  "Käyttäjä"
 ],
 "User:": [
  null,
  "Käyttäjä:"
 ],
 "Value": [
  null,
  "Arvo"
 ],
 "View $0": [
  null,
  "Näytä $0"
 ],
 "Volumes": [
  null,
  "Taltiot"
 ],
 "When unhealthy": [
  null,
  "Kun rikki"
 ],
 "With terminal": [
  null,
  "Päätteen kanssa"
 ],
 "Writable": [
  null,
  "Kirjoitettavissa"
 ],
 "downloading": [
  null,
  "ladataan"
 ],
 "host[:port]/[user]/container[:tag]": [
  null,
  "isäntä[:portti]/[käyttäjä]/kontti[:tag]"
 ],
 "in": [
  null,
  "sijainnissa"
 ],
 "intermediate": [
  null,
  "välitaso"
 ],
 "intermediate image": [
  null,
  "välitasoinen levykuva"
 ],
 "n/a": [
  null,
  "ei sovellu"
 ],
 "not available": [
  null,
  "ei käytettävissä"
 ],
 "pod": [
  null,
  "podi"
 ],
 "ports": [
  null,
  "portit"
 ],
 "seconds": [
  null,
  "sekuntia"
 ],
 "service": [
  null,
  "palvelu"
 ],
 "system": [
  null,
  "järjestelmä"
 ],
 "systemd service": [
  null,
  "systemd palvelu"
 ],
 "unused": [
  null,
  "ei käytössä"
 ],
 "user": [
  null,
  "käyttäjä"
 ],
 "user:": [
  null,
  "käyttäjä:"
 ],
 "volumes": [
  null,
  "taltiot"
 ]
});
