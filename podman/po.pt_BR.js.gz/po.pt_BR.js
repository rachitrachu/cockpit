cockpit.locale({
 "": {
  "plural-forms": (n) => n > 1,
  "language": "pt_BR",
  "language-direction": "ltr"
 },
 "$0 container": [
  null,
  "$0 contêiner",
  "$0 contêineres"
 ],
 "$0 image total, $1": [
  null,
  "$0 imagem no total, $1",
  "$0 imagens no total, $1"
 ],
 "$0 second": [
  null,
  "$0 segundo",
  "$0 segundos"
 ],
 "$0 unused image, $1": [
  null,
  "$0 imagem não usada, $1",
  "$0 imagens não usadas, $1"
 ],
 "$0% of $1 limit": [
  null,
  "$0% do limite de $1"
 ],
 "1 to 65535": [
  null,
  "1 para 65535"
 ],
 "Action to take once the container transitions to an unhealthy state.": [
  null,
  "Ação a ser tomada quando o contêiner passa para um estado não íntegra."
 ],
 "Actions": [
  null,
  "Ações"
 ],
 "Add port mapping": [
  null,
  "Adicionar mapeamento de porta"
 ],
 "Add variable": [
  null,
  "Adicionar variável"
 ],
 "Add volume": [
  null,
  "Adicionar volume"
 ],
 "All": [
  null,
  "Todos"
 ],
 "All registries": [
  null,
  "Todos os registros"
 ],
 "Always": [
  null,
  "Sempre"
 ],
 "An error occurred": [
  null,
  "Ocorreu um erro"
 ],
 "Author": [
  null,
  "Autor"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "CPU Shares help": [
  null,
  "Ajuda sobre o compartilhamento de CPU"
 ],
 "CPU shares": [
  null,
  "Compartilhamento de CPU"
 ],
 "CPU shares determine the priority of running containers. Default priority is 1024. A higher number prioritizes this container. A lower number decreases priority.": [
  null,
  "O compartilhamento de CPU determina a prioridade de execução de contêineres. A prioridade padrão é 1024. Um número maior prioriza este contêiner. Um número menor diminui a prioridade."
 ],
 "Cancel": [
  null,
  "Cancelar"
 ],
 "Checking health": [
  null,
  "Verificando a saúde"
 ],
 "Checkpoint": [
  null,
  "Criar checkpoint"
 ],
 "Checkpoint and restore support": [
  null,
  "Suporte a checkpoint e restauração"
 ],
 "Checkpoint container $0": [
  null,
  "Criar checkpoint do contêiner $0"
 ],
 "Click to see published ports": [
  null,
  "Clique para ver portas publicadas"
 ],
 "Click to see volumes": [
  null,
  "Clique para ver volumes"
 ],
 "Command": [
  null,
  "Comando"
 ],
 "Comments": [
  null,
  "Comentários"
 ],
 "Commit": [
  null,
  "Commit"
 ],
 "Configured": [
  null,
  "Configurado"
 ],
 "Console": [
  null,
  "Console"
 ],
 "Container": [
  null,
  "Contêiner"
 ],
 "Container failed to be created": [
  null,
  "Criação do contêiner falhou"
 ],
 "Container failed to be started": [
  null,
  "Inicialização do contêiner falhou"
 ],
 "Container is not running": [
  null,
  "Contêiner não está em execução"
 ],
 "Container name": [
  null,
  "Nome do contêiner"
 ],
 "Container name is required.": [
  null,
  "Nome do contêiner é requerido."
 ],
 "Container path": [
  null,
  "Caminho do contêiner"
 ],
 "Container path must not be empty": [
  null,
  "O caminho do contêiner não pode estar vazio"
 ],
 "Container port": [
  null,
  "Porta do contêiner"
 ],
 "Container port must not be empty": [
  null,
  "A porta do contêiner não pode estar vazia"
 ],
 "Containers": [
  null,
  "Contêineres"
 ],
 "Create": [
  null,
  "Criar"
 ],
 "Create a new image based on the current state of the $0 container.": [
  null,
  "Crie uma nova imagem com base no estado atual do contêiner $0."
 ],
 "Create and run": [
  null,
  "Criar e executar"
 ],
 "Create container": [
  null,
  "Criar contêiner"
 ],
 "Create container in $0": [
  null,
  "Criar contêiner em $0"
 ],
 "Create container in pod": [
  null,
  "Criar contêiner no pod"
 ],
 "Create pod": [
  null,
  "Criar pod"
 ],
 "Created by": [
  null,
  "Criada por"
 ],
 "Decrease CPU shares": [
  null,
  "Diminuir a divisão de CPU"
 ],
 "Decrease interval": [
  null,
  "Diminuir o intervalo"
 ],
 "Decrease maximum retries": [
  null,
  "Diminuir o número máximo de tentativas"
 ],
 "Decrease memory": [
  null,
  "Diminuir a memória"
 ],
 "Decrease retries": [
  null,
  "Diminuir as tentativas"
 ],
 "Decrease start period": [
  null,
  "Diminuir o período de início"
 ],
 "Decrease timeout": [
  null,
  "Diminuir o tempo limite"
 ],
 "Delete": [
  null,
  "Excluir"
 ],
 "Delete $0 image?": [
  null,
  "Excluir a imagem $0?"
 ],
 "Delete $0?": [
  null,
  "Excluir $0?"
 ],
 "Delete image": [
  null,
  "Excluir imagem"
 ],
 "Delete pod $0?": [
  null,
  "Excluir pod $0?"
 ],
 "Delete tagged images": [
  null,
  "Excluir imagens com etiquetas"
 ],
 "Delete unused images of user $0:": [
  null,
  "Excluir imagens não usadas do usuário $0:"
 ],
 "Delete unused system images:": [
  null,
  "Excluir imagens de sistema não usadas:"
 ],
 "Deleting a container will erase all data in it.": [
  null,
  "Excluir um contêiner irá apagar todos os dados que ele contém."
 ],
 "Deleting a running container will erase all data in it.": [
  null,
  "Excluir um contêiner em execução irá apagar todos os dados dentro dele."
 ],
 "Deleting this pod will remove the following containers:": [
  null,
  "Excluir este pod irá remover os seguintes contêineres:"
 ],
 "Details": [
  null,
  "Detalhes"
 ],
 "Disk space": [
  null,
  "Espaço em disco"
 ],
 "Docker format is useful when sharing the image with Docker or Moby Engine": [
  null,
  "O formato Docker é útil ao compartilhar a imagem com o Docker ou Moby Engine"
 ],
 "Download": [
  null,
  "Baixar"
 ],
 "Download new image": [
  null,
  "Baixar nova imagem"
 ],
 "Empty pod $0 will be permanently removed.": [
  null,
  "O pod vazio $0 será removido permanentemente."
 ],
 "Entrypoint": [
  null,
  "Ponto de entrada"
 ],
 "Environment variables": [
  null,
  "Variáveis de ambiente"
 ],
 "Error": [
  null,
  "Erro"
 ],
 "Error message": [
  null,
  "Mensagem de erro"
 ],
 "Error occurred while connecting console": [
  null,
  "Ocorreu um erro ao conectar ao console"
 ],
 "Example, Your Name <yourname@example.com>": [
  null,
  "Exemplo, Seu Nome <seunome@example.com>"
 ],
 "Example: $0": [
  null,
  "Exemplo: $0"
 ],
 "Exited": [
  null,
  "Encerrado"
 ],
 "Failed health run": [
  null,
  "Falhou na execução de verificação de saúde"
 ],
 "Failed to checkpoint container $0": [
  null,
  "Falha ao criar checkpoint do contêiner $0"
 ],
 "Failed to clean up container": [
  null,
  "Falha ao limpar o contêiner"
 ],
 "Failed to commit container $0": [
  null,
  "Falha ao efetivar contêiner $0"
 ],
 "Failed to create container $0": [
  null,
  "Falha ao criar o contêiner $0"
 ],
 "Failed to download image $0:$1": [
  null,
  "Falha ao baixar a imagem $0:$1"
 ],
 "Failed to force remove container $0": [
  null,
  "Falha ao forçar a remoção do contêiner $0"
 ],
 "Failed to force remove image $0": [
  null,
  "Falha ao forçar a remoção da imagem $0"
 ],
 "Failed to force restart pod $0": [
  null,
  "Falha ao forçar a reinicialização do pod $0"
 ],
 "Failed to force stop pod $0": [
  null,
  "Falha ao forçar a parada do pod $0"
 ],
 "Failed to pause container $0": [
  null,
  "Falha ao pausar o contêiner $0"
 ],
 "Failed to pause pod $0": [
  null,
  "Falha ao pausar o pod $0"
 ],
 "Failed to prune unused containers": [
  null,
  "Falha ao expurgar contêineres não usados"
 ],
 "Failed to prune unused images": [
  null,
  "Falha ao expurgar imagens não usadas"
 ],
 "Failed to pull image $0": [
  null,
  "Falha ao baixar a imagem $0"
 ],
 "Failed to remove container $0": [
  null,
  "Falha ao remover o contêiner $0"
 ],
 "Failed to remove image $0": [
  null,
  "Falha ao remover a imagem $0"
 ],
 "Failed to rename container $0": [
  null,
  "Falha ao renomear o contêiner $0"
 ],
 "Failed to restart container $0": [
  null,
  "Falha ao reiniciar o contêiner $0"
 ],
 "Failed to restart pod $0": [
  null,
  "Falha ao reiniciar o pod $0"
 ],
 "Failed to restore container $0": [
  null,
  "Falha ao restaurar o contêiner $0"
 ],
 "Failed to resume container $0": [
  null,
  "Falha ao retomar o contêiner $0"
 ],
 "Failed to resume pod $0": [
  null,
  "Falha ao retomar o pod $0"
 ],
 "Failed to run container $0": [
  null,
  "Falha ao executar o contêiner $0"
 ],
 "Failed to run health check on container $0": [
  null,
  "Falha ao executar uma verificação de integridade do contêiner $0"
 ],
 "Failed to search for images.": [
  null,
  "Falha ao buscar imagens."
 ],
 "Failed to search for images: $0": [
  null,
  "Falha ao buscar imagens: $0"
 ],
 "Failed to search for new images": [
  null,
  "Falha ao buscar novas imagens"
 ],
 "Failed to start container $0": [
  null,
  "Falha ao iniciar o contêiner $0"
 ],
 "Failed to start pod $0": [
  null,
  "Falha ao iniciar o pod $0"
 ],
 "Failed to stop container $0": [
  null,
  "Falha ao parar o contêiner $0"
 ],
 "Failed to stop pod $0": [
  null,
  "Falha ao parar o pod $0"
 ],
 "Failing streak": [
  null,
  "Sequência de falhas"
 ],
 "Force delete": [
  null,
  "Forçar exclusão"
 ],
 "Force delete pod $0?": [
  null,
  "Forçar exclusão do pod $0?"
 ],
 "Force restart": [
  null,
  "Forçar reinicialização"
 ],
 "Force stop": [
  null,
  "Forçar parada"
 ],
 "GB": [
  null,
  "GB"
 ],
 "Gateway": [
  null,
  "Gateway"
 ],
 "Health check": [
  null,
  "Verificação de integridade"
 ],
 "Health check interval help": [
  null,
  "Ajuda sobre o intervalo de verificação de integridade"
 ],
 "Health check retries help": [
  null,
  "Ajuda sobre as tentativas de verificação de integridade"
 ],
 "Health check start period help": [
  null,
  "Ajuda sobre o período de início de verificação de integridade"
 ],
 "Health check timeout help": [
  null,
  "Ajuda sobre o tempo limite da verificação de integridade"
 ],
 "Health failure check action help": [
  null,
  "Ajuda sobre a ação de verificação de falha da saúde"
 ],
 "Healthy": [
  null,
  "Íntegra"
 ],
 "Hide images": [
  null,
  "Ocultar imagens"
 ],
 "Hide intermediate images": [
  null,
  "Ocultar imagens intermediárias"
 ],
 "History": [
  null,
  "História"
 ],
 "Host path": [
  null,
  "Caminho do host"
 ],
 "Host port": [
  null,
  "Porta do host"
 ],
 "Host port help": [
  null,
  "Ajuda sobre o caminho do host"
 ],
 "ID": [
  null,
  "ID"
 ],
 "IP address": [
  null,
  "Endereço IP"
 ],
 "IP address help": [
  null,
  "Ajuda sobre o endereço IP"
 ],
 "Ideal for development": [
  null,
  "Ideal para desenvolvimento"
 ],
 "Ideal for running services": [
  null,
  "Ideal para executar serviços"
 ],
 "If host IP is set to 0.0.0.0 or not set at all, the port will be bound on all IPs on the host.": [
  null,
  "Se o IP do host for definido como 0.0.0.0 ou não for definido, a porta será vinculada a todos os IPs no host."
 ],
 "If the host port is not set the container port will be randomly assigned a port on the host.": [
  null,
  "Se a porta do host não estiver definida, a porta do contêiner receberá aleatoriamente uma porta no host."
 ],
 "Ignore IP address if set statically": [
  null,
  "Ignorar endereço IP se definido estaticamente"
 ],
 "Ignore MAC address if set statically": [
  null,
  "Ignorar endereço MAC se definido estaticamente"
 ],
 "Image": [
  null,
  "Imagem"
 ],
 "Image name is not unique": [
  null,
  "O nome da imagem não é único"
 ],
 "Image name is required": [
  null,
  "Nome da imagem é obrigatória"
 ],
 "Image selection help": [
  null,
  "Ajuda sobre a seleção de imagem"
 ],
 "Images": [
  null,
  "Imagens"
 ],
 "Increase CPU shares": [
  null,
  "Aumentar a divisão de CPU"
 ],
 "Increase interval": [
  null,
  "Aumentar o intervalo"
 ],
 "Increase maximum retries": [
  null,
  "Aumentar o número máximo de tentativas"
 ],
 "Increase memory": [
  null,
  "Aumentar a memória"
 ],
 "Increase retries": [
  null,
  "Aumentar as tentativas"
 ],
 "Increase start period": [
  null,
  "Aumentar o período de início"
 ],
 "Increase timeout": [
  null,
  "Aumentar o tempo limite"
 ],
 "Integration": [
  null,
  "Integração"
 ],
 "Interval": [
  null,
  "Intervalo"
 ],
 "Interval how often health check is run.": [
  null,
  "Intervalo com que frequência a verificação de integridade é executada."
 ],
 "Invalid characters. Name can only contain letters, numbers, and certain punctuation (_ . -).": [
  null,
  "Caracteres inválidos. O nome pode conter apenas letras, números e determinadas pontuações (_ . -)."
 ],
 "KB": [
  null,
  "KB"
 ],
 "Keep all temporary checkpoint files": [
  null,
  "Manter todos os arquivos temporários de checkpoint"
 ],
 "Key": [
  null,
  "Chave"
 ],
 "Key contains invalid characters": [
  null,
  "A chave contém caracteres inválidos"
 ],
 "Key must not be empty": [
  null,
  "A chave não pode estar vazia"
 ],
 "Key must not begin with a digit": [
  null,
  "A chave não pode iniciar com um dígito"
 ],
 "Last 5 runs": [
  null,
  "Últimas 5 verificações"
 ],
 "Latest checkpoint": [
  null,
  "Último checkpoint"
 ],
 "Leave running after writing checkpoint to disk": [
  null,
  "Deixar em execução após gravar o checkpoint no disco"
 ],
 "Loading details...": [
  null,
  "Carregando detalhes..."
 ],
 "Loading logs...": [
  null,
  "Carregando logs..."
 ],
 "Loading...": [
  null,
  "Carregando..."
 ],
 "Local": [
  null,
  "Local"
 ],
 "Local images": [
  null,
  "Imagens locais"
 ],
 "Logs": [
  null,
  "Logs"
 ],
 "MAC address": [
  null,
  "Endereço MAC"
 ],
 "MB": [
  null,
  "MB"
 ],
 "Maximum retries": [
  null,
  "Número máximo de tentativas"
 ],
 "Memory": [
  null,
  "Memória"
 ],
 "Memory limit": [
  null,
  "Limite de memória"
 ],
 "Memory unit": [
  null,
  "Unidade de memória"
 ],
 "Mode": [
  null,
  "Modo"
 ],
 "Multiple tags exist for this image. Select the tagged images to delete.": [
  null,
  "Existem várias tags para esta imagem. Selecione as imagens marcadas para excluir."
 ],
 "Must be a valid IP address": [
  null,
  "Deve ser um endereço IP válido"
 ],
 "Name": [
  null,
  "Nome"
 ],
 "Name already in use": [
  null,
  "Nome já em uso"
 ],
 "New container name": [
  null,
  "Novo nome do contêiner"
 ],
 "New image name": [
  null,
  "Nome da nova imagem"
 ],
 "No": [
  null,
  "Não"
 ],
 "No action": [
  null,
  "Nenhuma ação"
 ],
 "No containers": [
  null,
  "Nenhum contêiner"
 ],
 "No containers are using this image": [
  null,
  "Nenhum contêiner está usando está imagem"
 ],
 "No containers in this pod": [
  null,
  "Nenhum contêiner neste pod"
 ],
 "No containers that match the current filter": [
  null,
  "Nenhum contêiner corresponde ao filtro atual"
 ],
 "No environment variables specified": [
  null,
  "Nenhuma variável de ambiente especificada"
 ],
 "No images": [
  null,
  "Nenhuma imagem"
 ],
 "No images found": [
  null,
  "Nenhuma imagem encontrada"
 ],
 "No images that match the current filter": [
  null,
  "Nenhuma imagem corresponde ao filtro atual"
 ],
 "No label": [
  null,
  "Nenhum rótulo"
 ],
 "No ports exposed": [
  null,
  "Nenhuma porta exposta"
 ],
 "No results for $0": [
  null,
  "Nenhum resultado para $0"
 ],
 "No running containers": [
  null,
  "Nenhum contêiner em execução"
 ],
 "No volumes specified": [
  null,
  "Nenhum volume especificado"
 ],
 "On failure": [
  null,
  "Em falha"
 ],
 "Only running": [
  null,
  "Somente em execução"
 ],
 "Options": [
  null,
  "Opções"
 ],
 "Owner": [
  null,
  "Proprietário"
 ],
 "Owner help": [
  null,
  "Ajuda sobre o proprietário"
 ],
 "Passed health run": [
  null,
  "Passou na verificação de saúde"
 ],
 "Paste one or more lines of key=value pairs into any field for bulk import": [
  null,
  "Cole uma ou mais linhas de pares chave=valor em qualquer campo para importação em massa"
 ],
 "Pause": [
  null,
  "Pausar"
 ],
 "Pause container when creating image": [
  null,
  "Pausar o contêiner ao criar a imagem"
 ],
 "Paused": [
  null,
  "Pausado"
 ],
 "Pod failed to be created": [
  null,
  "Criação do pod falhou"
 ],
 "Pod name": [
  null,
  "Nome do pod"
 ],
 "Podman service failed": [
  null,
  "Serviço do Podman falhou"
 ],
 "Port mapping": [
  null,
  "Mapeamento de porta"
 ],
 "Ports": [
  null,
  "Portas"
 ],
 "Ports under 1024 can be mapped": [
  null,
  "Portas sob 1024 podem ser mapeadas"
 ],
 "Private": [
  null,
  "Privado"
 ],
 "Protocol": [
  null,
  "Protocolo"
 ],
 "Prune": [
  null,
  "Expurgar"
 ],
 "Prune unused containers": [
  null,
  "Expurgar contêineres não usados"
 ],
 "Prune unused images": [
  null,
  "Expurgar imagens não usadas"
 ],
 "Pruning containers": [
  null,
  "Expurgando contêineres"
 ],
 "Pruning images": [
  null,
  "Expurgando imagens"
 ],
 "Pull": [
  null,
  "Baixar"
 ],
 "Pull all images": [
  null,
  "Baixar novas imagens"
 ],
 "Pull latest image": [
  null,
  "Baixar a última imagem"
 ],
 "Pulling": [
  null,
  "Baixando"
 ],
 "Read-only access": [
  null,
  "Acesso somente leitura"
 ],
 "Read-write access": [
  null,
  "Acesso leitura e gravação"
 ],
 "Remove item": [
  null,
  "Remover item"
 ],
 "Removes selected non-running containers": [
  null,
  "Remove contêineres selecionadas que não estão em execução"
 ],
 "Removing": [
  null,
  "Removendo"
 ],
 "Rename": [
  null,
  "Renomear"
 ],
 "Rename container $0": [
  null,
  "Renomear contêiner $0"
 ],
 "Resource limits can be set": [
  null,
  "Limites de recursos podem ser definidos"
 ],
 "Restart": [
  null,
  "Reiniciar"
 ],
 "Restart policy": [
  null,
  "Política de reinicialização"
 ],
 "Restart policy help": [
  null,
  "Ajuda sobre a política de reinicialização"
 ],
 "Restart policy to follow when containers exit.": [
  null,
  "Política de reinicialização para seguir quando contêineres são encerrados."
 ],
 "Restart policy to follow when containers exit. Using linger for auto-starting containers may not work in some circumstances, such as when ecryptfs, systemd-homed, NFS, or 2FA are used on a user account.": [
  null,
  "Política de reinicialização a ser seguida quando os contêineres são encerrados. Usar linger para contêineres de inicialização automática pode não funcionar em algumas circunstâncias, como quando ecryptfs, systemd-homed, NFS ou 2FA são usados em uma conta de usuário."
 ],
 "Restore": [
  null,
  "Restaurar"
 ],
 "Restore container $0": [
  null,
  "Restaurar contêiner $0"
 ],
 "Restore with established TCP connections": [
  null,
  "Restaurar com conexões TCP estabelecidas"
 ],
 "Restricted by user account permissions": [
  null,
  "Restrito pelas permissões da conta do usuário"
 ],
 "Resume": [
  null,
  "Retomar"
 ],
 "Retries": [
  null,
  "Tentativas"
 ],
 "Retry another term.": [
  null,
  "Tente outro termo."
 ],
 "Run health check": [
  null,
  "Executar verificação de integridade"
 ],
 "Running": [
  null,
  "Em execução"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Search by name or description": [
  null,
  "Pesquisar por nome ou descrição"
 ],
 "Search by registry": [
  null,
  "Pesquisar por registro"
 ],
 "Search for": [
  null,
  "Pesquisar por"
 ],
 "Search for an image": [
  null,
  "Pesquisar por uma imagem"
 ],
 "Search string or container location": [
  null,
  "Pesquisar string ou local do contêiner"
 ],
 "Searching...": [
  null,
  "Pesquisando..."
 ],
 "Searching: $0": [
  null,
  "Pesquisando: $0"
 ],
 "Shared": [
  null,
  "Compartilhado"
 ],
 "Show": [
  null,
  "Mostrar"
 ],
 "Show images": [
  null,
  "Mostrar imagens"
 ],
 "Show intermediate images": [
  null,
  "Mostrar imagens intermediárias"
 ],
 "Show less": [
  null,
  "Mostrar menos"
 ],
 "Show more": [
  null,
  "Mostrar mais"
 ],
 "Size": [
  null,
  "Tamanho"
 ],
 "Start": [
  null,
  "Iniciar"
 ],
 "Start period": [
  null,
  "Período de início"
 ],
 "Start typing to look for images.": [
  null,
  "Comece a digitar para procurar por imagens."
 ],
 "Started at": [
  null,
  "Iniciado em"
 ],
 "State": [
  null,
  "Estado"
 ],
 "Status": [
  null,
  "Estado"
 ],
 "Stop": [
  null,
  "Parar"
 ],
 "Stopped": [
  null,
  "Parado"
 ],
 "Support preserving established TCP connections": [
  null,
  "Adicionar suporte à preservação de conexões TCP estabelecidas"
 ],
 "System": [
  null,
  "Sistema"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "Tag": [
  null,
  "Etiqueta"
 ],
 "Tags": [
  null,
  "Etiquetas"
 ],
 "The initialization time needed for a container to bootstrap.": [
  null,
  "O tempo de inicialização necessário para um contêiner ser inicializado."
 ],
 "The maximum time allowed to complete the health check before an interval is considered failed.": [
  null,
  "O tempo máximo permitido para concluir a verificação de integridade antes que um intervalo seja considerado reprovado."
 ],
 "The number of retries allowed before a healthcheck is considered to be unhealthy.": [
  null,
  "O número de tentativas permitidas antes que uma verificação de integridade seja considerada não íntegra."
 ],
 "Timeout": [
  null,
  "Tempo de limite"
 ],
 "Troubleshoot": [
  null,
  "Solução de problemas"
 ],
 "Type to filter…": [
  null,
  "Digite para filtrar…"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Unable to load image history": [
  null,
  "Não foi possível carregar o histórico da imagem"
 ],
 "Unhealthy": [
  null,
  "Não íntegra"
 ],
 "Up since:": [
  null,
  "Ligado desde:"
 ],
 "Use legacy Docker format": [
  null,
  "Usar formato legado do Docker"
 ],
 "Used by": [
  null,
  "Usado por"
 ],
 "User": [
  null,
  "Usuário"
 ],
 "User:": [
  null,
  "Usuário:"
 ],
 "Value": [
  null,
  "Valor"
 ],
 "View $0": [
  null,
  ""
 ],
 "View $0 logs": [
  null,
  ""
 ],
 "Volumes": [
  null,
  "Volumes"
 ],
 "When unhealthy": [
  null,
  "Quando não íntegro"
 ],
 "With terminal": [
  null,
  "Com terminal"
 ],
 "Writable": [
  null,
  "Gravável"
 ],
 "downloading": [
  null,
  "baixando"
 ],
 "host[:port]/[user]/container[:tag]": [
  null,
  "host[:porta]/[usuário]/contêiner[:etiqueta]"
 ],
 "in": [
  null,
  "em"
 ],
 "intermediate": [
  null,
  "intermediária"
 ],
 "intermediate image": [
  null,
  "imagem intermediária"
 ],
 "n/a": [
  null,
  "n/d"
 ],
 "not available": [
  null,
  "indisponível"
 ],
 "pod": [
  null,
  "pod"
 ],
 "ports": [
  null,
  "portas"
 ],
 "seconds": [
  null,
  "segundos"
 ],
 "service": [
  null,
  "serviço"
 ],
 "system": [
  null,
  "sistema"
 ],
 "unused": [
  null,
  "não usada"
 ],
 "user": [
  null,
  "usuário"
 ],
 "user:": [
  null,
  "usuário:"
 ],
 "volumes": [
  null,
  "volumes"
 ]
});
