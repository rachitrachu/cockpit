cockpit.locale({
 "": {
  "plural-forms": (n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2,
  "language": "cs",
  "language-direction": "ltr"
 },
 "$0 container": [
  null,
  "$0 kontejner",
  "$0 kontejnery",
  "$0 kontejnerů"
 ],
 "$0 image total, $1": [
  null,
  "$0 obraz celkem, $1",
  "$0 obrazy celkem, $1",
  "$0 obrazů celkem, $1"
 ],
 "$0 second": [
  null,
  "$0 sekunda",
  "$0 sekundy",
  "$0 sekund"
 ],
 "$0 unused image, $1": [
  null,
  "$0 nepoužitý obraz, $1",
  "$0 nepoužité obrazy, $1",
  "$0 nepoužitých obrazů, $1"
 ],
 "$0% of $1 limit": [
  null,
  "$0% z limitu $1"
 ],
 "1 to 65535": [
  null,
  "1 až 65535"
 ],
 "Action to take once the container transitions to an unhealthy state.": [
  null,
  "Akce kterou podniknout jakmile kontejner přejde do stavu, kdy nebude v pořádku."
 ],
 "Actions": [
  null,
  "Akce"
 ],
 "Add port mapping": [
  null,
  "Přidat mapování portů"
 ],
 "Add variable": [
  null,
  "Přidat proměnnou prostředí"
 ],
 "Add volume": [
  null,
  "Přidat svazek"
 ],
 "All": [
  null,
  "Vše"
 ],
 "All registries": [
  null,
  "Všechny registry"
 ],
 "Always": [
  null,
  "Vždy"
 ],
 "An error occurred": [
  null,
  "Došlo k chybě"
 ],
 "Author": [
  null,
  "Autor"
 ],
 "CPU": [
  null,
  "Procesor"
 ],
 "CPU Shares help": [
  null,
  "Nápověda k podílům na procesoru"
 ],
 "CPU shares": [
  null,
  "Podílů na procesoru"
 ],
 "CPU shares determine the priority of running containers. Default priority is 1024. A higher number prioritizes this container. A lower number decreases priority.": [
  null,
  "Podíly na procesoru určují prioritu spuštěných kontejnerů. Výchozí priorita je 1024. Vyšší číslo vede k vyšší prioritě takového kontejneru. Nižší číslo ji snižuje."
 ],
 "Cancel": [
  null,
  "Storno"
 ],
 "Checking health": [
  null,
  "Kontroluje se stav"
 ],
 "Checkpoint": [
  null,
  "Kontrolní bod"
 ],
 "Checkpoint and restore support": [
  null,
  "Podpora kontrolních bodů a obnovování"
 ],
 "Checkpoint container $0": [
  null,
  "Kontejner kontrolního bodu $0"
 ],
 "Click to see published ports": [
  null,
  "Kliknutím zobrazíte publikované porty"
 ],
 "Click to see volumes": [
  null,
  "Kliknutím zobrazíte svazky"
 ],
 "Command": [
  null,
  "Příkaz"
 ],
 "Comments": [
  null,
  "Komentáře"
 ],
 "Commit": [
  null,
  "Odeslat"
 ],
 "Commit container": [
  null,
  "Odeslat kontejner"
 ],
 "Configured": [
  null,
  "Nastaveno"
 ],
 "Console": [
  null,
  "Konzole"
 ],
 "Container": [
  null,
  "Kontejner"
 ],
 "Container failed to be created": [
  null,
  "Kontejner se nepodařilo vytvořit"
 ],
 "Container failed to be started": [
  null,
  "Kontejner se nepodařilo spustit"
 ],
 "Container is not running": [
  null,
  "Kontejner není spuštěný"
 ],
 "Container name": [
  null,
  "Název kontejneru"
 ],
 "Container name is required.": [
  null,
  "Je třeba zadat název kontejneru."
 ],
 "Container path": [
  null,
  "Popis umístění kontejneru"
 ],
 "Container path must not be empty": [
  null,
  "Je třeba vyplnit popis umístění kontejneru"
 ],
 "Container port": [
  null,
  "Port kontejneru"
 ],
 "Container port must not be empty": [
  null,
  "Je třeba vyplnit port kontejneru"
 ],
 "Containers": [
  null,
  "Kontejnery"
 ],
 "Create": [
  null,
  "Vytvořit"
 ],
 "Create a new image based on the current state of the $0 container.": [
  null,
  "Vytvořit nový obraz založený na stávajícím stavu kontejneru $0."
 ],
 "Create and run": [
  null,
  "Vytvořit a spustit"
 ],
 "Create container": [
  null,
  "Vytvořit kontejner"
 ],
 "Create container in $0": [
  null,
  "Vytvořit kontejner v $0"
 ],
 "Create container in pod": [
  null,
  "Vytvořit kontejner v podu"
 ],
 "Create pod": [
  null,
  "Vytvořit pod"
 ],
 "Created": [
  null,
  "Vytvořeno"
 ],
 "Created by": [
  null,
  "Vytvořil"
 ],
 "Decrease CPU shares": [
  null,
  "Snížit podíl na procesoru"
 ],
 "Decrease interval": [
  null,
  "Snížit interval"
 ],
 "Decrease maximum retries": [
  null,
  "Snížit limit počtu opětovných pokusů"
 ],
 "Decrease memory": [
  null,
  "Zmenšit paměť"
 ],
 "Decrease retries": [
  null,
  "Snížit počet opakovaných pokusů"
 ],
 "Decrease start period": [
  null,
  "Snížit periodu startu"
 ],
 "Decrease timeout": [
  null,
  "Snížit časový limit"
 ],
 "Delete": [
  null,
  "Smazat"
 ],
 "Delete $0 image?": [
  null,
  "Smazat obraz $0?"
 ],
 "Delete $0?": [
  null,
  "Smazat $0?"
 ],
 "Delete image": [
  null,
  "Smazat obraz"
 ],
 "Delete pod $0?": [
  null,
  "Smazat pod $0?"
 ],
 "Delete tagged images": [
  null,
  "Smazat štítkem označené obrazy"
 ],
 "Delete unused images of user $0:": [
  null,
  "Smazat nepoužité obrazy uživatele $0:"
 ],
 "Delete unused system images:": [
  null,
  "Smazat nepoužívané systémové obrazy:"
 ],
 "Deleting a container will erase all data in it.": [
  null,
  "Smazání kontejneru smaže veškerá data v něm."
 ],
 "Deleting a running container will erase all data in it.": [
  null,
  "Smazání spuštěného kontejneru smaže veškerá data v něm."
 ],
 "Deleting this pod will remove the following containers:": [
  null,
  "Smazání tohoto podu odebere následující kontejnery:"
 ],
 "Details": [
  null,
  "Podrobnosti"
 ],
 "Disk space": [
  null,
  "Prostor na disku"
 ],
 "Docker format is useful when sharing the image with Docker or Moby Engine": [
  null,
  "Formát Docker se hodí pro sdílení obrazu s enginem Docker nebo Moby"
 ],
 "Download": [
  null,
  "Stáhnout"
 ],
 "Download new image": [
  null,
  "Stáhnout si nový obraz"
 ],
 "Empty pod $0 will be permanently removed.": [
  null,
  "Prázdný pod $0 bude nevratně odebrán."
 ],
 "Entrypoint": [
  null,
  "Vstupní bod"
 ],
 "Environment variables": [
  null,
  "Proměnné prostředí"
 ],
 "Error": [
  null,
  "Chyba"
 ],
 "Error message": [
  null,
  "Chybové hlášení"
 ],
 "Error occurred while connecting console": [
  null,
  "Nastala chyba při připojování ke konzoli"
 ],
 "Example, Your Name <yourname@example.com>": [
  null,
  "Příklad, vaše jméno <vasejmeno@example.com>"
 ],
 "Example: $0": [
  null,
  "Příklad: $0"
 ],
 "Exited": [
  null,
  "Skončilo"
 ],
 "Failed health run": [
  null,
  "Nepodařilo se spustit kontrolu vitálnosti"
 ],
 "Failed to checkpoint container $0": [
  null,
  "Kontejner $0 se nepodařilo opatřit kontrolním bodem"
 ],
 "Failed to clean up container": [
  null,
  "Nepodařilo se vyčistit kontejner"
 ],
 "Failed to commit container $0": [
  null,
  "Nepodařilo se odeslat kontejner $0"
 ],
 "Failed to create container $0": [
  null,
  "Nepodařilo se vytvořit kontejner $0"
 ],
 "Failed to download image $0:$1": [
  null,
  "Nepodařilo se stáhnout obraz $0:$1"
 ],
 "Failed to force remove container $0": [
  null,
  "Nepodařilo se vynutit odebrání kontejneru $0"
 ],
 "Failed to force remove image $0": [
  null,
  "Nepodařilo se vynutit odebrání obrazu $0"
 ],
 "Failed to force restart pod $0": [
  null,
  "Nepodařilo se vynutit restart podu $0"
 ],
 "Failed to force stop pod $0": [
  null,
  "Nepodařilo se vynutit zastavení podu $0"
 ],
 "Failed to pause container $0": [
  null,
  "Nepodařilo se pozastavit kontejner $0"
 ],
 "Failed to pause pod $0": [
  null,
  "Nepodařilo se pozastavit pod $0"
 ],
 "Failed to prune unused containers": [
  null,
  "Nepodařilo se prořezat nepoužívané kontejnery"
 ],
 "Failed to prune unused images": [
  null,
  "Nepodařilo se prořezat nepoužívané obrazy"
 ],
 "Failed to pull image $0": [
  null,
  "Nepodařilo se natáhnout obraz $0"
 ],
 "Failed to remove container $0": [
  null,
  "Nepodařilo se odebrat kontejner $0"
 ],
 "Failed to remove image $0": [
  null,
  "Nepodařilo se odebrat obraz $0"
 ],
 "Failed to rename container $0": [
  null,
  "Nepodařilo se přejmenovat kontejner $0"
 ],
 "Failed to restart container $0": [
  null,
  "Nepodařilo se restartovat kontejner $0"
 ],
 "Failed to restart pod $0": [
  null,
  "Nepodařilo se restartovat pod $0"
 ],
 "Failed to restore container $0": [
  null,
  "Nepodařilo se obnovit kontejner $0"
 ],
 "Failed to resume container $0": [
  null,
  "Nepodařilo se navázat v chodu kontejneru $0"
 ],
 "Failed to resume pod $0": [
  null,
  "Nepodařilo se navázat v chodu podu $0"
 ],
 "Failed to run container $0": [
  null,
  "Nepodařilo se spustit kontejner $0"
 ],
 "Failed to run health check on container $0": [
  null,
  "Nepodařilo se zkontrolovat vitálnost kontejneru $0"
 ],
 "Failed to search for images.": [
  null,
  "Nepodařilo se vyhledat obrazy."
 ],
 "Failed to search for images: $0": [
  null,
  "Nepodařilo se vyhledat obrazy: $0"
 ],
 "Failed to search for new images": [
  null,
  "Nepodařilo se vyhledat nové obrazy"
 ],
 "Failed to start container $0": [
  null,
  "Nepodařilo se spustit kontejner $0"
 ],
 "Failed to start pod $0": [
  null,
  "Nepodařilo se spustit pod $0"
 ],
 "Failed to stop container $0": [
  null,
  "Nepodařilo se zastavit kontejner $0"
 ],
 "Failed to stop pod $0": [
  null,
  "Nepodařilo se zastavit pod $0"
 ],
 "Failing streak": [
  null,
  "Selhávající streak"
 ],
 "Force commit": [
  null,
  "Vynutit odeslání"
 ],
 "Force delete": [
  null,
  "Vynutit smazání"
 ],
 "Force delete pod $0?": [
  null,
  "Vynutit smazání podu $0?"
 ],
 "Force restart": [
  null,
  "Vynutit restart"
 ],
 "Force stop": [
  null,
  "Vynutit zastavení"
 ],
 "GB": [
  null,
  "GB"
 ],
 "Gateway": [
  null,
  "Brána"
 ],
 "Health check": [
  null,
  "Kontrola vitálnosti"
 ],
 "Health check interval help": [
  null,
  "Nápověda k intervalu kontroly vitálnosti"
 ],
 "Health check retries help": [
  null,
  "Nápověda k opakovaným pokusům o kontrolu vitálnosti"
 ],
 "Health check start period help": [
  null,
  "Nápověda k periodě startu kontroly vitálnosti"
 ],
 "Health check timeout help": [
  null,
  "Nápověda k časovému limitu kontroly vitálnosti"
 ],
 "Health failure check action help": [
  null,
  "Nápověda k akci kontroly selhání"
 ],
 "Healthy": [
  null,
  "V pořádku"
 ],
 "Hide images": [
  null,
  "Skrýt obrazy"
 ],
 "Hide intermediate images": [
  null,
  "Skrýt obrazy mezi tím"
 ],
 "History": [
  null,
  "Historie"
 ],
 "Host path": [
  null,
  "Popis umístění hostitele"
 ],
 "Host port": [
  null,
  "Port hostitele"
 ],
 "Host port help": [
  null,
  "Nápověda k portu hostitele"
 ],
 "ID": [
  null,
  "Identif."
 ],
 "IP address": [
  null,
  "IP adresa"
 ],
 "IP address help": [
  null,
  "Nápověda k IP adrese"
 ],
 "Ideal for development": [
  null,
  "Ideální pro vývoj"
 ],
 "Ideal for running services": [
  null,
  "Ideální pro provozování služeb"
 ],
 "If host IP is set to 0.0.0.0 or not set at all, the port will be bound on all IPs on the host.": [
  null,
  "Pokud je IP adresa hostitele nastavena na 0.0.0.0 nebo vůbec nenastavena, port bude navázán na všechny IP adresy hostitele."
 ],
 "If the host port is not set the container port will be randomly assigned a port on the host.": [
  null,
  "Pokud port hostitele není nastavený, port kontejneru bude náhodně přiřazen na port hostitele."
 ],
 "Ignore IP address if set statically": [
  null,
  "Pokud je nastavená staticky, IP adresu ignorovat"
 ],
 "Ignore MAC address if set statically": [
  null,
  "Pokud je nastavená staticky, MAC adresu ignorovat"
 ],
 "Image": [
  null,
  "Obraz"
 ],
 "Image name is not unique": [
  null,
  "Název obrazu už je použit"
 ],
 "Image name is required": [
  null,
  "Je třeba zadat název obrazu"
 ],
 "Image selection help": [
  null,
  "Nápověda k výběru obrazu"
 ],
 "Images": [
  null,
  "Obrazy"
 ],
 "Increase CPU shares": [
  null,
  "Zvýšit podíl na procesoru"
 ],
 "Increase interval": [
  null,
  "Prodloužit interval"
 ],
 "Increase maximum retries": [
  null,
  "Zvýšit počet opětovných pokusů"
 ],
 "Increase memory": [
  null,
  "Zvětšit paměť"
 ],
 "Increase retries": [
  null,
  "Zvýšit počet opakování pokusů"
 ],
 "Increase start period": [
  null,
  "Zvýšit periodu startu"
 ],
 "Increase timeout": [
  null,
  "Prodloužit časový limit"
 ],
 "Integration": [
  null,
  "Napojení"
 ],
 "Interval": [
  null,
  "Interval"
 ],
 "Interval how often health check is run.": [
  null,
  "Jak často spouštět kontrolu vitálnosti."
 ],
 "Invalid characters. Name can only contain letters, numbers, and certain punctuation (_ . -).": [
  null,
  "Neplatné znaky. Název může obsahovat pouze písmena, číslice a vybranou interpunkci (_.-)."
 ],
 "KB": [
  null,
  "KB"
 ],
 "Keep all temporary checkpoint files": [
  null,
  "Ponechat všechny dočasné soubory kontrolních bodů"
 ],
 "Key": [
  null,
  "Klíč"
 ],
 "Key contains invalid characters": [
  null,
  "Klíč obsahuje neplatné znaky"
 ],
 "Key must not be empty": [
  null,
  "Je třeba vyplnit klíč"
 ],
 "Key must not begin with a digit": [
  null,
  "Klíč nemůže začínat na číslici"
 ],
 "Last 5 runs": [
  null,
  "Minulých 5 spuštění"
 ],
 "Latest checkpoint": [
  null,
  "Nejnovější kontrolní bod"
 ],
 "Leave running after writing checkpoint to disk": [
  null,
  "Po zapsání kontrolního bodu na disk ponechat spuštěné"
 ],
 "Loading details...": [
  null,
  "Načítání podrobností…"
 ],
 "Loading logs...": [
  null,
  "Načítání záznamů událostí…"
 ],
 "Loading...": [
  null,
  "Načítání…"
 ],
 "Local": [
  null,
  "Lokální"
 ],
 "Local images": [
  null,
  "Lokální obrazy"
 ],
 "Logs": [
  null,
  "Záznamy událostí"
 ],
 "MAC address": [
  null,
  "MAC adresa"
 ],
 "MB": [
  null,
  "MB"
 ],
 "Maximum retries": [
  null,
  "Maximální počet opětovných pokusů"
 ],
 "Memory": [
  null,
  "Operační paměť"
 ],
 "Memory limit": [
  null,
  "Limit operační paměti"
 ],
 "Memory unit": [
  null,
  "Jednotka operační paměti"
 ],
 "Mode": [
  null,
  "Režim"
 ],
 "Multiple tags exist for this image. Select the tagged images to delete.": [
  null,
  "Pro tento obraz existuje vícero štítků. Vyberte oštítkované obrazy, které smazat."
 ],
 "Must be a valid IP address": [
  null,
  "Je třeba, aby byla platná IP adresa"
 ],
 "Name": [
  null,
  "Název"
 ],
 "Name already in use": [
  null,
  "Název je už používán"
 ],
 "New container name": [
  null,
  "Nový název pro kontejner"
 ],
 "New image name": [
  null,
  "Název nového obrazu"
 ],
 "No": [
  null,
  "Ne"
 ],
 "No action": [
  null,
  "Žádná akce"
 ],
 "No containers": [
  null,
  "Žádné kontejnery"
 ],
 "No containers are using this image": [
  null,
  "Tento obraz není používán žádným kontejnerem"
 ],
 "No containers in this pod": [
  null,
  "V tomto podu nejsou žádné kontejnery"
 ],
 "No containers that match the current filter": [
  null,
  "Stávajícímu filtru neodpovídají žádné kontejnery"
 ],
 "No environment variables specified": [
  null,
  "Nezadány žádné proměnné prostředí"
 ],
 "No images": [
  null,
  "Žádné obrazy"
 ],
 "No images found": [
  null,
  "Nenalezeny žádné obrazy"
 ],
 "No images that match the current filter": [
  null,
  "Žádné obrazy které by odpovídaly stávajícímu filtru"
 ],
 "No label": [
  null,
  "Žádný štítek"
 ],
 "No ports exposed": [
  null,
  "Nejsou vystavené žádné porty"
 ],
 "No results for $0": [
  null,
  "Žádné výsledky pro $0"
 ],
 "No running containers": [
  null,
  "Žádné spuštěné kontejnery"
 ],
 "No volumes specified": [
  null,
  "Nejsou určeny žádné svazky"
 ],
 "On failure": [
  null,
  "Při nezdaru"
 ],
 "Only running": [
  null,
  "Pouze spuštěné"
 ],
 "Options": [
  null,
  "Volby"
 ],
 "Owner": [
  null,
  "Vlastník"
 ],
 "Owner help": [
  null,
  "Nápověda k vlastníkovi"
 ],
 "Passed health run": [
  null,
  "Prošlo kontrolou vitálnosti"
 ],
 "Paste one or more lines of key=value pairs into any field for bulk import": [
  null,
  "Pokud chcete hromadně naimportovat, zadejte do libovolné kolonky jeden či více řádků s dvojicemi klíč=hodnota"
 ],
 "Pause": [
  null,
  "Pozastavit"
 ],
 "Pause container when creating image": [
  null,
  "Při vytváření obrazu pozastavit kontejner"
 ],
 "Paused": [
  null,
  "Pozastaveno"
 ],
 "Pod failed to be created": [
  null,
  "Pod se nepodařilo vytvořit"
 ],
 "Pod name": [
  null,
  "Název pro pod"
 ],
 "Podman service failed": [
  null,
  "Služba podman selhala"
 ],
 "Port mapping": [
  null,
  "Mapování portů"
 ],
 "Ports": [
  null,
  "Porty"
 ],
 "Ports under 1024 can be mapped": [
  null,
  "Je možné mapovat na porty nižší než 1024"
 ],
 "Private": [
  null,
  "Soukromé"
 ],
 "Protocol": [
  null,
  "Protokol"
 ],
 "Prune": [
  null,
  "Prořezat"
 ],
 "Prune unused containers": [
  null,
  "Prořezat nepoužívané kontejnery"
 ],
 "Prune unused images": [
  null,
  "Prořezat nepoužívané obrazy"
 ],
 "Pruning containers": [
  null,
  "Prořezávají se kontejnery"
 ],
 "Pruning images": [
  null,
  "Prořezávají se obrazy"
 ],
 "Pull": [
  null,
  "Natáhnout"
 ],
 "Pull all images": [
  null,
  "Natáhnout veškeré obrazy"
 ],
 "Pull latest image": [
  null,
  "Stáhnout si nejnovější obraz"
 ],
 "Pulling": [
  null,
  "Stahování"
 ],
 "Read-only access": [
  null,
  "Přístup pouze pro čtení"
 ],
 "Read-write access": [
  null,
  "Přístup pro čtení i zápis"
 ],
 "Remove item": [
  null,
  "Odebrat položku"
 ],
 "Removes selected non-running containers": [
  null,
  "Odebere označené (a nespuštěné) kontejnery"
 ],
 "Removing": [
  null,
  "Odebírá se"
 ],
 "Rename": [
  null,
  "Přejmenovat"
 ],
 "Rename container $0": [
  null,
  "Přejmenovat kontejner $0"
 ],
 "Resource limits can be set": [
  null,
  "Je možné nastavit limity prostředků"
 ],
 "Restart": [
  null,
  "Restart"
 ],
 "Restart policy": [
  null,
  "Pravidlo restartování"
 ],
 "Restart policy help": [
  null,
  "Nápověda k pravidlu restartování"
 ],
 "Restart policy to follow when containers exit.": [
  null,
  "Které pravidlo ohledně restartování následovat když se kontejnery ukončují."
 ],
 "Restart policy to follow when containers exit. Using linger for auto-starting containers may not work in some circumstances, such as when ecryptfs, systemd-homed, NFS, or 2FA are used on a user account.": [
  null,
  "Pravidlo ohledně restartování kterým se řídit při ukončení kontejnerů. Pokud je v rámci uživatelského účtu používán např. ecryptfs, systemd-homed, NFS nebo 2FA, pak se může stávat, že automatické spouštění pomocí linger za určitých podmínek nemusí zafungovat."
 ],
 "Restore": [
  null,
  "Obnovit"
 ],
 "Restore container $0": [
  null,
  "Obnovit kontejner $0"
 ],
 "Restore with established TCP connections": [
  null,
  "Obnovit s navázanými TCP spojeními"
 ],
 "Restricted by user account permissions": [
  null,
  "Omezeno oprávněními uživatelského účtu"
 ],
 "Resume": [
  null,
  "Navázat v chodu"
 ],
 "Retries": [
  null,
  "Opětovných pokusů"
 ],
 "Retry another term.": [
  null,
  "Zkusit znovu jiný pojem."
 ],
 "Run health check": [
  null,
  "Zkontrolovat vitálnost"
 ],
 "Running": [
  null,
  "Spuštěné"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Search by name or description": [
  null,
  "Hledat podle názvu nebo popisu"
 ],
 "Search by registry": [
  null,
  "Hledat podle registru (repozitáře)"
 ],
 "Search for": [
  null,
  "Hledat"
 ],
 "Search for an image": [
  null,
  "Hledat obraz"
 ],
 "Search string or container location": [
  null,
  "Hledat řetězec nebo umístění kontejneru"
 ],
 "Searching...": [
  null,
  "Vyhledávání..."
 ],
 "Searching: $0": [
  null,
  "Vyhledávání: $0"
 ],
 "Shared": [
  null,
  "Sdílené"
 ],
 "Show": [
  null,
  "Zobrazit"
 ],
 "Show images": [
  null,
  "Zobrazit obrazy"
 ],
 "Show intermediate images": [
  null,
  "Zobrazit obrazy mezi tím"
 ],
 "Show less": [
  null,
  "Zobrazit méně"
 ],
 "Show more": [
  null,
  "Zobrazit více"
 ],
 "Size": [
  null,
  "Velikost"
 ],
 "Start": [
  null,
  "Spustit"
 ],
 "Start period": [
  null,
  "Perioda startu"
 ],
 "Start typing to look for images.": [
  null,
  "Vyhledávání obrazů zahájíte psaním."
 ],
 "Started at": [
  null,
  "Spuštěno v"
 ],
 "State": [
  null,
  "Stav"
 ],
 "Status": [
  null,
  "Stav"
 ],
 "Stop": [
  null,
  "Zastavit"
 ],
 "Stopped": [
  null,
  "Zastaveno"
 ],
 "Support preserving established TCP connections": [
  null,
  "Podpora pro zachování navázaných TCP spojení"
 ],
 "System": [
  null,
  "Systém"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "Tag": [
  null,
  "Štítek"
 ],
 "Tags": [
  null,
  "Štítky"
 ],
 "The initialization time needed for a container to bootstrap.": [
  null,
  "Doba potřebná pro inicializaci zavádění kontejneru."
 ],
 "The maximum time allowed to complete the health check before an interval is considered failed.": [
  null,
  "Nejdelší přijatelná doba pro dokončení kontroly vitálnosti, než bude interval považován za nezdařilý."
 ],
 "The number of retries allowed before a healthcheck is considered to be unhealthy.": [
  null,
  "Umožněný počet opětovných pokusů než bude výsledek kontroly vitálnosti považován za negativní."
 ],
 "Timeout": [
  null,
  "Časový limit"
 ],
 "Troubleshoot": [
  null,
  "Řešení problémů"
 ],
 "Type to filter…": [
  null,
  "Filtrujte psaním…"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Unable to load image history": [
  null,
  "Nepodařilo se načíst historii obrazu"
 ],
 "Unhealthy": [
  null,
  "Není v pořádku"
 ],
 "Up since:": [
  null,
  "V chodu od:"
 ],
 "Use legacy Docker format": [
  null,
  "Použít původní Docker formát"
 ],
 "Used by": [
  null,
  "Používáno"
 ],
 "User": [
  null,
  "Uživatel"
 ],
 "User:": [
  null,
  "Uživatel:"
 ],
 "Value": [
  null,
  "Hodnota"
 ],
 "View $0": [
  null,
  "Zobrazit $0"
 ],
 "View $0 logs": [
  null,
  "Zobrazit $0 záznamů událostí"
 ],
 "Volumes": [
  null,
  "Svazky"
 ],
 "When unhealthy": [
  null,
  "Pokud v nepořádku"
 ],
 "With terminal": [
  null,
  "S terminálem"
 ],
 "Writable": [
  null,
  "Zapisovatelné"
 ],
 "downloading": [
  null,
  "stahuje se"
 ],
 "host[:port]/[user]/container[:tag]": [
  null,
  "hostitel[:port]/[uživatel]/kontejner[:štítek]"
 ],
 "in": [
  null,
  "v"
 ],
 "intermediate": [
  null,
  "mezi tím"
 ],
 "intermediate image": [
  null,
  "Obraz mezi tím"
 ],
 "n/a": [
  null,
  "n/a"
 ],
 "not available": [
  null,
  "není k dispozici"
 ],
 "pod": [
  null,
  "pod"
 ],
 "ports": [
  null,
  "porty"
 ],
 "seconds": [
  null,
  "sekund"
 ],
 "service": [
  null,
  "služba"
 ],
 "system": [
  null,
  "systém"
 ],
 "systemd service": [
  null,
  "systemd služba"
 ],
 "unused": [
  null,
  "nepoužito"
 ],
 "user": [
  null,
  "uživatel"
 ],
 "user:": [
  null,
  "uživatel:"
 ],
 "volumes": [
  null,
  "svazky"
 ]
});
