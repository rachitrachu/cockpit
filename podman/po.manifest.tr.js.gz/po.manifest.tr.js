cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "tr",
  "language-direction": "ltr"
 },
 "Podman containers": [
  null,
  "Podman kapsayıcıları"
 ],
 "container": [
  null,
  "kapsayıcı"
 ],
 "image": [
  null,
  "kalıp"
 ],
 "podman": [
  null,
  "podman"
 ]
});
