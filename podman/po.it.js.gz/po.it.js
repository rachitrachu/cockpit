cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "it",
  "language-direction": "ltr"
 },
 "$0 container": [
  null,
  "$0 container",
  "$0 container"
 ],
 "$0 image total, $1": [
  null,
  "$0 immagine totale, $1",
  "$0 immagini totali, $1"
 ],
 "$0 second": [
  null,
  "$0 secondo",
  "$0 secondi"
 ],
 "$0 unused image, $1": [
  null,
  "$0 immagine non utilizzata, $1",
  "$0 immagini non utilizzate, $1"
 ],
 "$0% of $1 limit": [
  null,
  "$0% del limite di $1"
 ],
 "1 to 65535": [
  null,
  "Da 1 a 65535"
 ],
 "Action to take once the container transitions to an unhealthy state.": [
  null,
  "Azione da intraprendere quando il container passa a uno stato non integro."
 ],
 "Actions": [
  null,
  "Azioni"
 ],
 "Add port mapping": [
  null,
  "Aggiungi mappatura porta"
 ],
 "Add variable": [
  null,
  "Aggiungi variabile"
 ],
 "Add volume": [
  null,
  "Aggiungi volume"
 ],
 "All": [
  null,
  "Tutti"
 ],
 "All registries": [
  null,
  "Tutti i registri"
 ],
 "Always": [
  null,
  "Sempre"
 ],
 "An error occurred": [
  null,
  "Si è verificato un errore"
 ],
 "Author": [
  null,
  "Autore"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "CPU Shares help": [
  null,
  "Guida per le quote CPU"
 ],
 "CPU shares": [
  null,
  "Quote CPU"
 ],
 "CPU shares determine the priority of running containers. Default priority is 1024. A higher number prioritizes this container. A lower number decreases priority.": [
  null,
  "Le quote CPU determinano la priorità dei container in esecuzione. La priorità predefinita è 1024. Un numero più alto dà priorità a questo container. Un numero più basso ne diminuisce la priorità."
 ],
 "Cancel": [
  null,
  "Annulla"
 ],
 "Checking health": [
  null,
  "Controllo dello stato di salute"
 ],
 "Checkpoint": [
  null,
  "Checkpoint"
 ],
 "Checkpoint and restore support": [
  null,
  "Supporto per checkpoint e ripristino"
 ],
 "Checkpoint container $0": [
  null,
  "Esegui checkpoint del container $0"
 ],
 "Click to see published ports": [
  null,
  "Fai clic per vedere le porte pubblicate"
 ],
 "Click to see volumes": [
  null,
  "Fai clic per vedere i volumi"
 ],
 "Command": [
  null,
  "Comando"
 ],
 "Comments": [
  null,
  "Commenti"
 ],
 "Commit": [
  null,
  "Commit"
 ],
 "Commit container": [
  null,
  "Esegui commit del container"
 ],
 "Configured": [
  null,
  "Configurato"
 ],
 "Console": [
  null,
  "Console"
 ],
 "Container": [
  null,
  "Container"
 ],
 "Container failed to be created": [
  null,
  "Creazione del container non riuscita"
 ],
 "Container failed to be started": [
  null,
  "Avvio del container non riuscito"
 ],
 "Container is not running": [
  null,
  "Il container non è in esecuzione"
 ],
 "Container name": [
  null,
  "Nome container"
 ],
 "Container name is required.": [
  null,
  "Il nome del container è obbligatorio."
 ],
 "Container path": [
  null,
  "Percorso container"
 ],
 "Container path must not be empty": [
  null,
  "Il percorso del container non deve essere vuoto"
 ],
 "Container port": [
  null,
  "Porta container"
 ],
 "Container port must not be empty": [
  null,
  "La porta del container non deve essere vuota"
 ],
 "Containers": [
  null,
  "Container"
 ],
 "Create": [
  null,
  "Crea"
 ],
 "Create a new image based on the current state of the $0 container.": [
  null,
  "Crea una nuova immagine basata sullo stato corrente del container $0."
 ],
 "Create and run": [
  null,
  "Crea ed esegui"
 ],
 "Create container": [
  null,
  "Crea container"
 ],
 "Create container in $0": [
  null,
  "Crea container in $0"
 ],
 "Create container in pod": [
  null,
  "Crea container nel pod"
 ],
 "Create pod": [
  null,
  "Crea pod"
 ],
 "Created": [
  null,
  "Creato"
 ],
 "Created by": [
  null,
  "Creato da"
 ],
 "Decrease CPU shares": [
  null,
  "Diminuisci quote CPU"
 ],
 "Decrease interval": [
  null,
  "Diminuisci intervallo"
 ],
 "Decrease maximum retries": [
  null,
  "Diminuisci tentativi massimi"
 ],
 "Decrease memory": [
  null,
  "Diminuisci memoria"
 ],
 "Decrease retries": [
  null,
  "Diminuisci tentativi"
 ],
 "Decrease start period": [
  null,
  "Diminuisci periodo di avvio"
 ],
 "Decrease timeout": [
  null,
  "Diminuisci timeout"
 ],
 "Delete": [
  null,
  "Elimina"
 ],
 "Delete $0 image?": [
  null,
  "Eliminare l'immagine $0?"
 ],
 "Delete $0?": [
  null,
  "Eliminare $0?"
 ],
 "Delete image": [
  null,
  "Elimina immagine"
 ],
 "Delete pod $0?": [
  null,
  "Eliminare il pod $0?"
 ],
 "Delete tagged images": [
  null,
  "Elimina immagini con tag"
 ],
 "Delete unused images of user $0:": [
  null,
  "Elimina immagini non utilizzate dell'utente $0:"
 ],
 "Delete unused system images:": [
  null,
  "Elimina immagini di sistema non utilizzate:"
 ],
 "Deleting a container will erase all data in it.": [
  null,
  "L'eliminazione di un container cancellerà tutti i dati al suo interno."
 ],
 "Deleting a running container will erase all data in it.": [
  null,
  "L'eliminazione di un container in esecuzione cancellerà tutti i dati al suo interno."
 ],
 "Deleting this pod will remove the following containers:": [
  null,
  "L'eliminazione di questo pod rimuoverà i seguenti container:"
 ],
 "Details": [
  null,
  "Dettagli"
 ],
 "Disk space": [
  null,
  "Spazio su disco"
 ],
 "Docker format is useful when sharing the image with Docker or Moby Engine": [
  null,
  "Il formato Docker è utile quando si condivide l'immagine con Docker o Moby Engine"
 ],
 "Download": [
  null,
  "Scarica"
 ],
 "Download new image": [
  null,
  "Scarica nuova immagine"
 ],
 "Empty pod $0 will be permanently removed.": [
  null,
  "Il pod vuoto $0 sarà rimosso permanentemente."
 ],
 "Entrypoint": [
  null,
  "Entrypoint"
 ],
 "Environment variables": [
  null,
  "Variabili d'ambiente"
 ],
 "Error": [
  null,
  "Errore"
 ],
 "Error message": [
  null,
  "Messaggio di errore"
 ],
 "Error occurred while connecting console": [
  null,
  "Errore durante la connessione alla console"
 ],
 "Example, Your Name <yourname@example.com>": [
  null,
  "Esempio, Il Tuo Nome <tuonome@example.com>"
 ],
 "Example: $0": [
  null,
  "Esempio: $0"
 ],
 "Exited": [
  null,
  "Terminato"
 ],
 "Failed health run": [
  null,
  "Esecuzione controllo di salute fallita"
 ],
 "Failed to checkpoint container $0": [
  null,
  "Checkpoint del container $0 non riuscito"
 ],
 "Failed to clean up container": [
  null,
  "Pulizia del container non riuscita"
 ],
 "Failed to commit container $0": [
  null,
  "Commit del container $0 non riuscito"
 ],
 "Failed to create container $0": [
  null,
  "Creazione del container $0 non riuscita"
 ],
 "Failed to download image $0:$1": [
  null,
  "Scaricamento dell'immagine $0:$1 non riuscito"
 ],
 "Failed to force remove container $0": [
  null,
  "Rimozione forzata del container $0 non riuscita"
 ],
 "Failed to force remove image $0": [
  null,
  "Rimozione forzata dell'immagine $0 non riuscita"
 ],
 "Failed to force restart pod $0": [
  null,
  "Riavvio forzato del pod $0 non riuscito"
 ],
 "Failed to force stop pod $0": [
  null,
  "Arresto forzato del pod $0 non riuscito"
 ],
 "Failed to pause container $0": [
  null,
  "Messa in pausa del container $0 non riuscita"
 ],
 "Failed to pause pod $0": [
  null,
  "Messa in pausa del pod $0 non riuscita"
 ],
 "Failed to prune unused containers": [
  null,
  "Eliminazione dei container non utilizzati non riuscita"
 ],
 "Failed to prune unused images": [
  null,
  "Eliminazione delle immagini non utilizzate non riuscita"
 ],
 "Failed to pull image $0": [
  null,
  "Pull dell'immagine $0 non riuscito"
 ],
 "Failed to remove container $0": [
  null,
  "Rimozione del container $0 non riuscita"
 ],
 "Failed to remove image $0": [
  null,
  "Rimozione dell'immagine $0 non riuscita"
 ],
 "Failed to rename container $0": [
  null,
  "Ridenominazione del container $0 non riuscita"
 ],
 "Failed to restart container $0": [
  null,
  "Riavvio del container $0 non riuscito"
 ],
 "Failed to restart pod $0": [
  null,
  "Riavvio del pod $0 non riuscito"
 ],
 "Failed to restore container $0": [
  null,
  "Ripristino del container $0 non riuscito"
 ],
 "Failed to resume container $0": [
  null,
  "Ripresa del container $0 non riuscita"
 ],
 "Failed to resume pod $0": [
  null,
  "Ripresa del pod $0 non riuscita"
 ],
 "Failed to run container $0": [
  null,
  "Esecuzione del container $0 non riuscita"
 ],
 "Failed to run health check on container $0": [
  null,
  "Esecuzione del controllo di salute sul container $0 non riuscita"
 ],
 "Failed to search for images.": [
  null,
  "Ricerca immagini non riuscita."
 ],
 "Failed to search for images: $0": [
  null,
  "Ricerca immagini non riuscita: $0"
 ],
 "Failed to search for new images": [
  null,
  "Ricerca di nuove immagini non riuscita"
 ],
 "Failed to start container $0": [
  null,
  "Avvio del container $0 non riuscito"
 ],
 "Failed to start pod $0": [
  null,
  "Avvio del pod $0 non riuscito"
 ],
 "Failed to stop container $0": [
  null,
  "Arresto del container $0 non riuscito"
 ],
 "Failed to stop pod $0": [
  null,
  "Arresto del pod $0 non riuscito"
 ],
 "Failing streak": [
  null,
  "Serie di fallimenti"
 ],
 "Force commit": [
  null,
  "Forza commit"
 ],
 "Force delete": [
  null,
  "Forza eliminazione"
 ],
 "Force delete pod $0?": [
  null,
  "Forzare l'eliminazione del pod $0?"
 ],
 "Force restart": [
  null,
  "Forza riavvio"
 ],
 "Force stop": [
  null,
  "Forza arresto"
 ],
 "GB": [
  null,
  "GB"
 ],
 "Gateway": [
  null,
  "Gateway"
 ],
 "Health check": [
  null,
  "Controllo di salute"
 ],
 "Health check interval help": [
  null,
  "Guida per l'intervallo del controllo di salute"
 ],
 "Health check retries help": [
  null,
  "Guida per i tentativi del controllo di salute"
 ],
 "Health check start period help": [
  null,
  "Guida per il periodo di avvio del controllo di salute"
 ],
 "Health check timeout help": [
  null,
  "Guida per il timeout del controllo di salute"
 ],
 "Health failure check action help": [
  null,
  "Guida per l'azione di controllo del fallimento di salute"
 ],
 "Healthy": [
  null,
  "Integro"
 ],
 "Hide images": [
  null,
  "Nascondi immagini"
 ],
 "Hide intermediate images": [
  null,
  "Nascondi immagini intermedie"
 ],
 "History": [
  null,
  "Cronologia"
 ],
 "Host path": [
  null,
  "Percorso host"
 ],
 "Host port": [
  null,
  "Porta host"
 ],
 "Host port help": [
  null,
  "Guida porta host"
 ],
 "ID": [
  null,
  "ID"
 ],
 "IP address": [
  null,
  "Indirizzo IP"
 ],
 "IP address help": [
  null,
  "Guida indirizzo IP"
 ],
 "Ideal for development": [
  null,
  "Ideale per lo sviluppo"
 ],
 "Ideal for running services": [
  null,
  "Ideale per l'esecuzione di servizi"
 ],
 "If host IP is set to 0.0.0.0 or not set at all, the port will be bound on all IPs on the host.": [
  null,
  "Se l'IP host è impostato a 0.0.0.0 o non è impostato affatto, la porta sarà associata a tutti gli IP sull'host."
 ],
 "If the host port is not set the container port will be randomly assigned a port on the host.": [
  null,
  "Se la porta host non è impostata, alla porta del container verrà assegnata casualmente una porta sull'host."
 ],
 "Ignore IP address if set statically": [
  null,
  "Ignora indirizzo IP se impostato staticamente"
 ],
 "Ignore MAC address if set statically": [
  null,
  "Ignora indirizzo MAC se impostato staticamente"
 ],
 "Image": [
  null,
  "Immagine"
 ],
 "Image name is not unique": [
  null,
  "Il nome dell'immagine non è univoco"
 ],
 "Image name is required": [
  null,
  "Il nome dell'immagine è obbligatorio"
 ],
 "Image selection help": [
  null,
  "Guida selezione immagine"
 ],
 "Images": [
  null,
  "Immagini"
 ],
 "Increase CPU shares": [
  null,
  "Aumenta quote CPU"
 ],
 "Increase interval": [
  null,
  "Aumenta intervallo"
 ],
 "Increase maximum retries": [
  null,
  "Aumenta tentativi massimi"
 ],
 "Increase memory": [
  null,
  "Aumenta memoria"
 ],
 "Increase retries": [
  null,
  "Aumenta tentativi"
 ],
 "Increase start period": [
  null,
  "Aumenta periodo di avvio"
 ],
 "Increase timeout": [
  null,
  "Aumenta timeout"
 ],
 "Integration": [
  null,
  "Integrazione"
 ],
 "Interval": [
  null,
  "Intervallo"
 ],
 "Interval how often health check is run.": [
  null,
  "Intervallo di esecuzione del controllo di salute."
 ],
 "Invalid characters. Name can only contain letters, numbers, and certain punctuation (_ . -).": [
  null,
  "Caratteri non validi. Il nome può contenere solo lettere, numeri e alcuni segni di punteggiatura (_ . -)."
 ],
 "KB": [
  null,
  "KB"
 ],
 "Keep all temporary checkpoint files": [
  null,
  "Conserva tutti i file di checkpoint temporanei"
 ],
 "Key": [
  null,
  "Chiave"
 ],
 "Key contains invalid characters": [
  null,
  "La chiave contiene caratteri non validi"
 ],
 "Key must not be empty": [
  null,
  "La chiave non deve essere vuota"
 ],
 "Key must not begin with a digit": [
  null,
  "La chiave non deve iniziare con una cifra"
 ],
 "Last 5 runs": [
  null,
  "Ultime 5 esecuzioni"
 ],
 "Latest checkpoint": [
  null,
  "Ultimo checkpoint"
 ],
 "Leave running after writing checkpoint to disk": [
  null,
  "Lascia in esecuzione dopo aver scritto il checkpoint su disco"
 ],
 "Loading details...": [
  null,
  "Caricamento dettagli in corso..."
 ],
 "Loading logs...": [
  null,
  "Caricamento log in corso..."
 ],
 "Loading...": [
  null,
  "Caricamento in corso..."
 ],
 "Local": [
  null,
  "Locale"
 ],
 "Local images": [
  null,
  "Immagini locali"
 ],
 "Logs": [
  null,
  "Log"
 ],
 "MAC address": [
  null,
  "Indirizzo MAC"
 ],
 "MB": [
  null,
  "MB"
 ],
 "Maximum retries": [
  null,
  "Tentativi massimi"
 ],
 "Memory": [
  null,
  "Memoria"
 ],
 "Memory limit": [
  null,
  "Limite memoria"
 ],
 "Memory unit": [
  null,
  "Unità di memoria"
 ],
 "Mode": [
  null,
  "Modalità"
 ],
 "Multiple tags exist for this image. Select the tagged images to delete.": [
  null,
  "Esistono più tag per questa immagine. Seleziona le immagini con tag da eliminare."
 ],
 "Must be a valid IP address": [
  null,
  "Deve essere un indirizzo IP valido"
 ],
 "Name": [
  null,
  "Nome"
 ],
 "Name already in use": [
  null,
  "Nome già in uso"
 ],
 "New container name": [
  null,
  "Nuovo nome container"
 ],
 "New image name": [
  null,
  "Nuovo nome immagine"
 ],
 "No": [
  null,
  "No"
 ],
 "No action": [
  null,
  "Nessuna azione"
 ],
 "No containers": [
  null,
  "Nessun container"
 ],
 "No containers are using this image": [
  null,
  "Nessun container sta usando questa immagine"
 ],
 "No containers in this pod": [
  null,
  "Nessun container in questo pod"
 ],
 "No containers that match the current filter": [
  null,
  "Nessun container corrisponde al filtro corrente"
 ],
 "No environment variables specified": [
  null,
  "Nessuna variabile d'ambiente specificata"
 ],
 "No images": [
  null,
  "Nessuna immagine"
 ],
 "No images found": [
  null,
  "Nessuna immagine trovata"
 ],
 "No images that match the current filter": [
  null,
  "Nessuna immagine corrisponde al filtro corrente"
 ],
 "No label": [
  null,
  "Nessuna etichetta"
 ],
 "No ports exposed": [
  null,
  "Nessuna porta esposta"
 ],
 "No results for $0": [
  null,
  "Nessun risultato per $0"
 ],
 "No running containers": [
  null,
  "Nessun container in esecuzione"
 ],
 "No volumes specified": [
  null,
  "Nessun volume specificato"
 ],
 "On failure": [
  null,
  "In caso di fallimento"
 ],
 "Only running": [
  null,
  "Solo in esecuzione"
 ],
 "Options": [
  null,
  "Opzioni"
 ],
 "Owner": [
  null,
  "Proprietario"
 ],
 "Owner help": [
  null,
  "Guida proprietario"
 ],
 "Passed health run": [
  null,
  "Esecuzione controllo di salute superata"
 ],
 "Paste one or more lines of key=value pairs into any field for bulk import": [
  null,
  "Incolla una o più righe di coppie chiave=valore in qualsiasi campo per l'importazione massiva"
 ],
 "Pause": [
  null,
  "Metti in pausa"
 ],
 "Pause container when creating image": [
  null,
  "Metti in pausa il container durante la creazione dell'immagine"
 ],
 "Paused": [
  null,
  "In pausa"
 ],
 "Pod failed to be created": [
  null,
  "Creazione del pod non riuscita"
 ],
 "Pod name": [
  null,
  "Nome pod"
 ],
 "Podman service failed": [
  null,
  "Servizio Podman non riuscito"
 ],
 "Port mapping": [
  null,
  "Mappatura porta"
 ],
 "Ports": [
  null,
  "Porte"
 ],
 "Ports under 1024 can be mapped": [
  null,
  "Le porte inferiori a 1024 possono essere mappate"
 ],
 "Private": [
  null,
  "Privato"
 ],
 "Protocol": [
  null,
  "Protocollo"
 ],
 "Prune": [
  null,
  "Elimina"
 ],
 "Prune unused containers": [
  null,
  "Elimina container non utilizzati"
 ],
 "Prune unused images": [
  null,
  "Elimina immagini non utilizzate"
 ],
 "Pruning containers": [
  null,
  "Eliminazione container in corso"
 ],
 "Pruning images": [
  null,
  "Eliminazione immagini in corso"
 ],
 "Pull": [
  null,
  "Pull"
 ],
 "Pull all images": [
  null,
  "Fai il pull di tutte le immagini"
 ],
 "Pull latest image": [
  null,
  "Fai il pull dell'immagine più recente"
 ],
 "Pulling": [
  null,
  "Pull in corso"
 ],
 "Read-only access": [
  null,
  "Accesso in sola lettura"
 ],
 "Read-write access": [
  null,
  "Accesso in lettura-scrittura"
 ],
 "Remove item": [
  null,
  "Rimuovi elemento"
 ],
 "Removes selected non-running containers": [
  null,
  "Rimuove i container selezionati non in esecuzione"
 ],
 "Removing": [
  null,
  "Rimozione in corso"
 ],
 "Rename": [
  null,
  "Rinomina"
 ],
 "Rename container $0": [
  null,
  "Rinomina container $0"
 ],
 "Resource limits can be set": [
  null,
  "È possibile impostare limiti di risorse"
 ],
 "Restart": [
  null,
  "Riavvia"
 ],
 "Restart policy": [
  null,
  "Politica di riavvio"
 ],
 "Restart policy help": [
  null,
  "Guida politica di riavvio"
 ],
 "Restart policy to follow when containers exit.": [
  null,
  "Politica di riavvio da seguire quando i container terminano."
 ],
 "Restart policy to follow when containers exit. Using linger for auto-starting containers may not work in some circumstances, such as when ecryptfs, systemd-homed, NFS, or 2FA are used on a user account.": [
  null,
  "Politica di riavvio da seguire quando i container terminano. L'uso del linger per l'avvio automatico dei container potrebbe non funzionare in alcune circostanze, ad esempio quando si utilizzano ecryptfs, systemd-homed, NFS o 2FA su un account utente."
 ],
 "Restore": [
  null,
  "Ripristina"
 ],
 "Restore container $0": [
  null,
  "Ripristina container $0"
 ],
 "Restore with established TCP connections": [
  null,
  "Ripristina con connessioni TCP stabilite"
 ],
 "Restricted by user account permissions": [
  null,
  "Limitato dai permessi dell'account utente"
 ],
 "Resume": [
  null,
  "Riprendi"
 ],
 "Retries": [
  null,
  "Tentativi"
 ],
 "Retry another term.": [
  null,
  "Riprova con un altro termine."
 ],
 "Run health check": [
  null,
  "Esegui controllo di salute"
 ],
 "Running": [
  null,
  "In esecuzione"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Search by name or description": [
  null,
  "Cerca per nome o descrizione"
 ],
 "Search by registry": [
  null,
  "Cerca per registro"
 ],
 "Search for": [
  null,
  "Cerca"
 ],
 "Search for an image": [
  null,
  "Cerca un'immagine"
 ],
 "Search string or container location": [
  null,
  "Stringa di ricerca o posizione del container"
 ],
 "Searching...": [
  null,
  "Ricerca in corso..."
 ],
 "Searching: $0": [
  null,
  "Ricerca: $0"
 ],
 "Shared": [
  null,
  "Condiviso"
 ],
 "Show": [
  null,
  "Mostra"
 ],
 "Show images": [
  null,
  "Mostra immagini"
 ],
 "Show intermediate images": [
  null,
  "Mostra immagini intermedie"
 ],
 "Show less": [
  null,
  "Mostra meno"
 ],
 "Show more": [
  null,
  "Mostra di più"
 ],
 "Size": [
  null,
  "Dimensione"
 ],
 "Start": [
  null,
  "Avvia"
 ],
 "Start period": [
  null,
  "Periodo di avvio"
 ],
 "Start typing to look for images.": [
  null,
  "Inizia a digitare per cercare immagini."
 ],
 "Started at": [
  null,
  "Avviato alle"
 ],
 "State": [
  null,
  "Stato"
 ],
 "Status": [
  null,
  "Stato"
 ],
 "Stop": [
  null,
  "Arresta"
 ],
 "Stopped": [
  null,
  "Arrestato"
 ],
 "Support preserving established TCP connections": [
  null,
  "Supporta la conservazione delle connessioni TCP stabilite"
 ],
 "System": [
  null,
  "Sistema"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "Tag": [
  null,
  "Tag"
 ],
 "Tags": [
  null,
  "Tag"
 ],
 "The initialization time needed for a container to bootstrap.": [
  null,
  "Il tempo di inizializzazione necessario a un container per avviarsi."
 ],
 "The maximum time allowed to complete the health check before an interval is considered failed.": [
  null,
  "Il tempo massimo consentito per completare il controllo di salute prima che un intervallo sia considerato fallito."
 ],
 "The number of retries allowed before a healthcheck is considered to be unhealthy.": [
  null,
  "Il numero di tentativi consentiti prima che un controllo di salute sia considerato non integro."
 ],
 "Timeout": [
  null,
  "Timeout"
 ],
 "Troubleshoot": [
  null,
  "Risoluzione problemi"
 ],
 "Type to filter…": [
  null,
  "Digita per filtrare…"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Unable to load image history": [
  null,
  "Impossibile caricare la cronologia dell'immagine"
 ],
 "Unhealthy": [
  null,
  "Non integro"
 ],
 "Up since:": [
  null,
  "Attivo da:"
 ],
 "Use legacy Docker format": [
  null,
  "Usa formato Docker legacy"
 ],
 "Used by": [
  null,
  "Utilizzato da"
 ],
 "User": [
  null,
  "Utente"
 ],
 "User:": [
  null,
  "Utente:"
 ],
 "Value": [
  null,
  "Valore"
 ],
 "View $0": [
  null,
  "Visualizza $0"
 ],
 "View $0 logs": [
  null,
  "Visualizza $0 log"
 ],
 "Volumes": [
  null,
  "Volumi"
 ],
 "When unhealthy": [
  null,
  "Quando non integro"
 ],
 "With terminal": [
  null,
  "Con terminale"
 ],
 "Writable": [
  null,
  "Scrivibile"
 ],
 "downloading": [
  null,
  "scaricamento in corso"
 ],
 "host[:port]/[user]/container[:tag]": [
  null,
  "host[:porta]/[utente]/container[:tag]"
 ],
 "in": [
  null,
  "in"
 ],
 "intermediate": [
  null,
  "intermedio"
 ],
 "intermediate image": [
  null,
  "immagine intermedia"
 ],
 "n/a": [
  null,
  "n/d"
 ],
 "not available": [
  null,
  "non disponibile"
 ],
 "pod": [
  null,
  "pod"
 ],
 "ports": [
  null,
  "porte"
 ],
 "seconds": [
  null,
  "secondi"
 ],
 "service": [
  null,
  "servizio"
 ],
 "system": [
  null,
  "sistema"
 ],
 "systemd service": [
  null,
  "servizio systemd"
 ],
 "unused": [
  null,
  "non utilizzato"
 ],
 "user": [
  null,
  "utente"
 ],
 "user:": [
  null,
  "utente:"
 ],
 "volumes": [
  null,
  "volumi"
 ]
});
