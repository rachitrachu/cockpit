cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "zh_Hant",
  "language-direction": "ltr"
 },
 "$0 container": [
  null,
  "$0 個容器"
 ],
 "$0 image total, $1": [
  null,
  "$0 個映像檔總計 , $1"
 ],
 "$0 second": [
  null,
  "$0 秒"
 ],
 "$0 unused image, $1": [
  null,
  "$0 個未使用的映像檔 , $1"
 ],
 "$0% of $1 limit": [
  null,
  "$1 限制的 $0"
 ],
 "1 to 65535": [
  null,
  "1 到 65535"
 ],
 "Action to take once the container transitions to an unhealthy state.": [
  null,
  "容器轉換到不健康狀態時得要採取的動作。"
 ],
 "Actions": [
  null,
  "動作"
 ],
 "Add port mapping": [
  null,
  "新增通訊埠映射"
 ],
 "Add variable": [
  null,
  "新增變數"
 ],
 "Add volume": [
  null,
  "新增分卷"
 ],
 "All": [
  null,
  "全部"
 ],
 "All registries": [
  null,
  "所有註冊"
 ],
 "Always": [
  null,
  "總是"
 ],
 "An error occurred": [
  null,
  "發生錯誤"
 ],
 "Author": [
  null,
  "作者"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "CPU Shares help": [
  null,
  "CPU 共享協助"
 ],
 "CPU shares": [
  null,
  "CPU 共享"
 ],
 "CPU shares determine the priority of running containers. Default priority is 1024. A higher number prioritizes this container. A lower number decreases priority.": [
  null,
  "CPU 共享決定執行中容器的優先順序。 預設優先順序為 1024。 數字越大，此容器的優先順序越高。 數字越小，優先順序越低。"
 ],
 "Cancel": [
  null,
  "取消"
 ],
 "Checking health": [
  null,
  "檢查健康狀態"
 ],
 "Checkpoint": [
  null,
  "檢查點"
 ],
 "Checkpoint and restore support": [
  null,
  "檢查點與還原支援"
 ],
 "Checkpoint container $0": [
  null,
  "檢查點容器 $0"
 ],
 "Click to see published ports": [
  null,
  "按一下以查看已發布使用的通訊埠"
 ],
 "Click to see volumes": [
  null,
  "點擊查看分區(卷)"
 ],
 "Command": [
  null,
  "指令"
 ],
 "Comments": [
  null,
  "評論"
 ],
 "Commit": [
  null,
  "承載"
 ],
 "Commit container": [
  null,
  "承載容器"
 ],
 "Configured": [
  null,
  "已設定"
 ],
 "Console": [
  null,
  "控制台"
 ],
 "Container": [
  null,
  "容器"
 ],
 "Container failed to be created": [
  null,
  "容器建立失敗"
 ],
 "Container failed to be started": [
  null,
  "容器啟動失敗"
 ],
 "Container is not running": [
  null,
  "容器未執行"
 ],
 "Container name": [
  null,
  "容器名稱"
 ],
 "Container name is required.": [
  null,
  "必須填寫容器名稱。"
 ],
 "Container path": [
  null,
  "容器路徑"
 ],
 "Container path must not be empty": [
  null,
  "容器路徑不得為空白"
 ],
 "Container port": [
  null,
  "容器通訊埠"
 ],
 "Container port must not be empty": [
  null,
  "容器通訊埠不得為空白"
 ],
 "Containers": [
  null,
  "容器"
 ],
 "Create": [
  null,
  "建立"
 ],
 "Create a new image based on the current state of the $0 container.": [
  null,
  "根據 $0 容器的目前狀態建立新映像檔。"
 ],
 "Create and run": [
  null,
  "建立並執行"
 ],
 "Create container": [
  null,
  "建立容器"
 ],
 "Create container in $0": [
  null,
  "以 $0 建立容器"
 ],
 "Create container in pod": [
  null,
  "在 pod 中建立容器"
 ],
 "Create pod": [
  null,
  "建立 pod"
 ],
 "Created": [
  null,
  "己建立"
 ],
 "Created by": [
  null,
  "己建立於"
 ],
 "Decrease CPU shares": [
  null,
  "減少 CPU 共享"
 ],
 "Decrease interval": [
  null,
  "減少間隔"
 ],
 "Decrease maximum retries": [
  null,
  "減少最大重試次數"
 ],
 "Decrease memory": [
  null,
  "減少記憶"
 ],
 "Decrease retries": [
  null,
  "減少重複嘗試"
 ],
 "Decrease start period": [
  null,
  "縮短開始時間"
 ],
 "Decrease timeout": [
  null,
  "減少超時"
 ],
 "Delete": [
  null,
  "刪除"
 ],
 "Delete $0 image?": [
  null,
  "刪除 $0 映像檔?"
 ],
 "Delete $0?": [
  null,
  "刪除 $0?"
 ],
 "Delete image": [
  null,
  "刪除映像檔"
 ],
 "Delete pod $0?": [
  null,
  "刪除 pod $0?"
 ],
 "Delete tagged images": [
  null,
  "刪除已標記的映像檔"
 ],
 "Delete unused images of user $0:": [
  null,
  "刪除使用者 $0 未使用的映像檔："
 ],
 "Delete unused system images:": [
  null,
  "刪除未使用的系統映像檔："
 ],
 "Deleting a container will erase all data in it.": [
  null,
  "刪除容器會刪除其中的所有資料。"
 ],
 "Deleting a running container will erase all data in it.": [
  null,
  "刪除執行中的容器會刪除其中的所有資料。"
 ],
 "Deleting this pod will remove the following containers:": [
  null,
  "刪除此 pod 將移除下列容器："
 ],
 "Details": [
  null,
  "詳情"
 ],
 "Disk space": [
  null,
  "磁碟空間"
 ],
 "Docker format is useful when sharing the image with Docker or Moby Engine": [
  null,
  "Docker 格式在與 Docker 或 Moby Engine 分享映像檔時非常有用"
 ],
 "Download": [
  null,
  "下載"
 ],
 "Download new image": [
  null,
  "下載新的映像檔"
 ],
 "Empty pod $0 will be permanently removed.": [
  null,
  "空的 pod $0 將被永久移除。"
 ],
 "Entrypoint": [
  null,
  "切入點"
 ],
 "Environment variables": [
  null,
  "環境變數"
 ],
 "Error": [
  null,
  "錯誤"
 ],
 "Error message": [
  null,
  "錯誤訊息"
 ],
 "Error occurred while connecting console": [
  null,
  "連接控制台時發生錯誤"
 ],
 "Example, Your Name <yourname@example.com>": [
  null,
  "範例，您的姓名 <yourname@example.com>"
 ],
 "Example: $0": [
  null,
  "範例: $0"
 ],
 "Exited": [
  null,
  "已退出"
 ],
 "Failed health run": [
  null,
  "健康測試己失敗"
 ],
 "Failed to checkpoint container $0": [
  null,
  "檢查點的容器 $0 己失敗"
 ],
 "Failed to clean up container": [
  null,
  "未能清理容器"
 ],
 "Failed to commit container $0": [
  null,
  "提交容器失敗 $0"
 ],
 "Failed to create container $0": [
  null,
  "建立容器 $0 己失敗"
 ],
 "Failed to download image $0:$1": [
  null,
  "下載映像檔己失敗 $0:$1"
 ],
 "Failed to force remove container $0": [
  null,
  "強制移除容器己失敗 $0"
 ],
 "Failed to force remove image $0": [
  null,
  "強制移除映像檔己失敗 $0"
 ],
 "Failed to force restart pod $0": [
  null,
  "強制重新啟動 Pod $0 己失敗"
 ],
 "Failed to force stop pod $0": [
  null,
  "強制停止 Pod $0 己失敗"
 ],
 "Failed to pause container $0": [
  null,
  "暫停容器己失敗 $0"
 ],
 "Failed to pause pod $0": [
  null,
  "暫停 Pod 己失敗 $0"
 ],
 "Failed to prune unused containers": [
  null,
  "未能修復未使用的容器"
 ],
 "Failed to prune unused images": [
  null,
  "修復未使用的映像檔己失敗"
 ],
 "Failed to pull image $0": [
  null,
  "擷取映像檔失敗 $0"
 ],
 "Failed to remove container $0": [
  null,
  "移除容器失敗 $0"
 ],
 "Failed to remove image $0": [
  null,
  "移除映像檔失敗 $0"
 ],
 "Failed to rename container $0": [
  null,
  "重新命名容器 $0 失敗"
 ],
 "Failed to restart container $0": [
  null,
  "重新啟動容器 $0 失敗"
 ],
 "Failed to restart pod $0": [
  null,
  "重新啟動 Pod $0 失敗"
 ],
 "Failed to restore container $0": [
  null,
  "還原容器 $0 失敗"
 ],
 "Failed to resume container $0": [
  null,
  "恢復容器失敗 $0"
 ],
 "Failed to resume pod $0": [
  null,
  "恢復 Pod 失敗 $0"
 ],
 "Failed to run container $0": [
  null,
  "執行容器 $0 失敗"
 ],
 "Failed to run health check on container $0": [
  null,
  "對容器 $0 執行健康檢查失敗"
 ],
 "Failed to search for images.": [
  null,
  "搜尋映像檔失敗。"
 ],
 "Failed to search for images: $0": [
  null,
  "搜尋映像檔失敗： $0"
 ],
 "Failed to search for new images": [
  null,
  "搜尋新的映像檔失敗"
 ],
 "Failed to start container $0": [
  null,
  "啟動容器 $0 失敗"
 ],
 "Failed to start pod $0": [
  null,
  "啟動 Pod 失敗 $0"
 ],
 "Failed to stop container $0": [
  null,
  "停止容器失敗 $0"
 ],
 "Failed to stop pod $0": [
  null,
  "無法停止 pod $0"
 ],
 "Failing streak": [
  null,
  "連續失敗"
 ],
 "Force commit": [
  null,
  "強制提交"
 ],
 "Force delete": [
  null,
  "強制刪除"
 ],
 "Force delete pod $0?": [
  null,
  "強制刪除 pod $0?"
 ],
 "Force restart": [
  null,
  "強制重新啟動"
 ],
 "Force stop": [
  null,
  "強制停止"
 ],
 "GB": [
  null,
  "GB"
 ],
 "Gateway": [
  null,
  "閘道器"
 ],
 "Health check": [
  null,
  "健康狀態檢查"
 ],
 "Health check interval help": [
  null,
  "健康狀態檢查間隔幫助"
 ],
 "Health check retries help": [
  null,
  "健康檢查重試說明"
 ],
 "Health check start period help": [
  null,
  "健康狀態檢查開始期間的幫助"
 ],
 "Health check timeout help": [
  null,
  "健康狀態檢查超時說明"
 ],
 "Health failure check action help": [
  null,
  "健康失敗檢查行動幫助"
 ],
 "Healthy": [
  null,
  "健康"
 ],
 "Hide images": [
  null,
  "隱藏映像檔"
 ],
 "Hide intermediate images": [
  null,
  "隱藏中介映像檔"
 ],
 "History": [
  null,
  "歷史"
 ],
 "Host path": [
  null,
  "主機路徑"
 ],
 "Host port": [
  null,
  "主機通訊埠"
 ],
 "Host port help": [
  null,
  "主機通訊埠協助"
 ],
 "ID": [
  null,
  "ID"
 ],
 "IP address": [
  null,
  "IP 地址"
 ],
 "IP address help": [
  null,
  "IP 地址協助"
 ],
 "Ideal for development": [
  null,
  "開發的理想選擇"
 ],
 "Ideal for running services": [
  null,
  "運行服務的理想選擇"
 ],
 "If host IP is set to 0.0.0.0 or not set at all, the port will be bound on all IPs on the host.": [
  null,
  "如果主機 IP 設定為 0.0.0.0 或完全未設定，則通訊埠會綁定在主機上的所有 IP 上。"
 ],
 "If the host port is not set the container port will be randomly assigned a port on the host.": [
  null,
  "如果未設定主機通訊埠，則容器連接埠會隨機分配給主機上的一個通訊埠。"
 ],
 "Ignore IP address if set statically": [
  null,
  "忽略靜態設定的 IP 位址"
 ],
 "Ignore MAC address if set statically": [
  null,
  "忽略靜態設定的 MAC 位址"
 ],
 "Image": [
  null,
  "映像檔"
 ],
 "Image name is not unique": [
  null,
  "映像檔名稱不唯一"
 ],
 "Image name is required": [
  null,
  "必須填寫映像檔名稱"
 ],
 "Image selection help": [
  null,
  "映像檔選擇說明"
 ],
 "Images": [
  null,
  "映像檔"
 ],
 "Increase CPU shares": [
  null,
  "增加 CPU 共享"
 ],
 "Increase interval": [
  null,
  "增加間隔"
 ],
 "Increase maximum retries": [
  null,
  "增加最大重試次數"
 ],
 "Increase memory": [
  null,
  "增加記憶體"
 ],
 "Increase retries": [
  null,
  "增加重試"
 ],
 "Increase start period": [
  null,
  "增加開始期間"
 ],
 "Increase timeout": [
  null,
  "增加超時"
 ],
 "Integration": [
  null,
  "整合"
 ],
 "Interval": [
  null,
  "間隔"
 ],
 "Interval how often health check is run.": [
  null,
  "執行健康狀態檢查的間隔時間。"
 ],
 "Invalid characters. Name can only contain letters, numbers, and certain punctuation (_ . -).": [
  null,
  "無效字符。 名稱只能包含字母、數字和某些標點符號 (_ . -)."
 ],
 "KB": [
  null,
  "KB"
 ],
 "Keep all temporary checkpoint files": [
  null,
  "保留所有臨時檢查點檔案"
 ],
 "Key": [
  null,
  "密鑰"
 ],
 "Key contains invalid characters": [
  null,
  "金鑰包含無效的字元"
 ],
 "Key must not be empty": [
  null,
  "金鑰不可為空"
 ],
 "Key must not begin with a digit": [
  null,
  "金鑰不得以數字開頭"
 ],
 "Last 5 runs": [
  null,
  "最近 5 次的運行過程"
 ],
 "Latest checkpoint": [
  null,
  "最新檢查點"
 ],
 "Leave running after writing checkpoint to disk": [
  null,
  "將檢查點寫入磁碟後繼續執行"
 ],
 "Loading details...": [
  null,
  "正在載入詳細資料中..."
 ],
 "Loading logs...": [
  null,
  "正在載入記錄檔中..."
 ],
 "Loading...": [
  null,
  "正在載入中..."
 ],
 "Local": [
  null,
  "本地"
 ],
 "Local images": [
  null,
  "本地映像檔"
 ],
 "Logs": [
  null,
  "記錄檔"
 ],
 "MAC address": [
  null,
  "MAC 地址"
 ],
 "MB": [
  null,
  "MB"
 ],
 "Maximum retries": [
  null,
  "最大重試次數"
 ],
 "Memory": [
  null,
  "記憶體"
 ],
 "Memory limit": [
  null,
  "記憶體上限"
 ],
 "Memory unit": [
  null,
  "記憶體單元"
 ],
 "Mode": [
  null,
  "模式"
 ],
 "Multiple tags exist for this image. Select the tagged images to delete.": [
  null,
  "此映像檔存在多個標記。 選取要刪除的標記的映像檔。"
 ],
 "Must be a valid IP address": [
  null,
  "必須是有效的 IP 位址"
 ],
 "Name": [
  null,
  "名稱"
 ],
 "Name already in use": [
  null,
  "已使用的名稱"
 ],
 "New container name": [
  null,
  "新容器名稱"
 ],
 "New image name": [
  null,
  "新映像檔名稱"
 ],
 "No": [
  null,
  "無"
 ],
 "No action": [
  null,
  "無動作"
 ],
 "No containers": [
  null,
  "無容器"
 ],
 "No containers are using this image": [
  null,
  "沒有容器使用此映像檔"
 ],
 "No containers in this pod": [
  null,
  "此 pod 中沒有容器"
 ],
 "No containers that match the current filter": [
  null,
  "沒有符合目前篩選條件的容器"
 ],
 "No environment variables specified": [
  null,
  "未指定環境變數"
 ],
 "No images": [
  null,
  "無映像檔"
 ],
 "No images found": [
  null,
  "無找到映像檔"
 ],
 "No images that match the current filter": [
  null,
  "沒有符合目前篩選條件的映像檔"
 ],
 "No label": [
  null,
  "無標記"
 ],
 "No ports exposed": [
  null,
  "無通訊埠外露"
 ],
 "No results for $0": [
  null,
  "沒有 $0 的結果"
 ],
 "No running containers": [
  null,
  "無執行中容器"
 ],
 "No volumes specified": [
  null,
  "未指定分區(卷)容量"
 ],
 "On failure": [
  null,
  "關於失敗"
 ],
 "Only running": [
  null,
  "僅運行"
 ],
 "Options": [
  null,
  "選項"
 ],
 "Owner": [
  null,
  "所有人"
 ],
 "Owner help": [
  null,
  "所有人協助"
 ],
 "Passed health run": [
  null,
  "通過健康狀態測試"
 ],
 "Paste one or more lines of key=value pairs into any field for bulk import": [
  null,
  "將一或多行 key=value 對貼到任何欄位，以進行大量匯入"
 ],
 "Pause": [
  null,
  "暫停"
 ],
 "Pause container when creating image": [
  null,
  "建立映像檔時暫停容器"
 ],
 "Paused": [
  null,
  "已暫停"
 ],
 "Pod failed to be created": [
  null,
  "Pod 建立己失敗"
 ],
 "Pod name": [
  null,
  "Pod 名稱"
 ],
 "Podman service failed": [
  null,
  "Podman 服務啟動失敗"
 ],
 "Port mapping": [
  null,
  "通訊埠映射"
 ],
 "Ports": [
  null,
  "通訊埠"
 ],
 "Ports under 1024 can be mapped": [
  null,
  "可以映射 1024 以下的連接埠"
 ],
 "Private": [
  null,
  "私有"
 ],
 "Protocol": [
  null,
  "通訊協定"
 ],
 "Prune": [
  null,
  "修復"
 ],
 "Prune unused containers": [
  null,
  "修復未使用容器"
 ],
 "Prune unused images": [
  null,
  "修復未使用映像檔"
 ],
 "Pruning containers": [
  null,
  "正在修復容器"
 ],
 "Pruning images": [
  null,
  "正在修復映像檔"
 ],
 "Pull": [
  null,
  "拉取"
 ],
 "Pull all images": [
  null,
  "拉取全部映像檔"
 ],
 "Pull latest image": [
  null,
  "拉取最新映像檔"
 ],
 "Pulling": [
  null,
  "正在拉取"
 ],
 "Read-only access": [
  null,
  "唯讀存取"
 ],
 "Read-write access": [
  null,
  "讀寫存取"
 ],
 "Remove item": [
  null,
  "移除項目"
 ],
 "Removes selected non-running containers": [
  null,
  "移除己選取的非執行中容器"
 ],
 "Removing": [
  null,
  "移除"
 ],
 "Rename": [
  null,
  "重新命名"
 ],
 "Rename container $0": [
  null,
  "重新命名容器 $0"
 ],
 "Resource limits can be set": [
  null,
  "可設定系統資源限制"
 ],
 "Restart": [
  null,
  "重新啟動"
 ],
 "Restart policy": [
  null,
  "重新啟動政策"
 ],
 "Restart policy help": [
  null,
  "重新啟動政策說明"
 ],
 "Restart policy to follow when containers exit.": [
  null,
  "容器退出時要遵循的重新啟動原則。"
 ],
 "Restart policy to follow when containers exit. Using linger for auto-starting containers may not work in some circumstances, such as when ecryptfs, systemd-homed, NFS, or 2FA are used on a user account.": [
  null,
  "容器退出時要遵循的重新啟動原則。 使用 linger 自動啟動容器在某些情況下可能無法運作，例如當使用者帳戶使用 ecryptfs、systemd-homed、NFS 或 2FA 時。"
 ],
 "Restore": [
  null,
  "還原"
 ],
 "Restore container $0": [
  null,
  "還原容器 $0"
 ],
 "Restore with established TCP connections": [
  null,
  "使用已建立的 TCP 連線進行還原"
 ],
 "Restricted by user account permissions": [
  null,
  "受使用者帳戶權限限制"
 ],
 "Resume": [
  null,
  "繼續"
 ],
 "Retries": [
  null,
  "重試"
 ],
 "Retry another term.": [
  null,
  "重試另一個期限。"
 ],
 "Run health check": [
  null,
  "執行健康狀態檢查"
 ],
 "Running": [
  null,
  "執行中"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Search by name or description": [
  null,
  "依名稱或描述搜尋"
 ],
 "Search by registry": [
  null,
  "依註冊表搜尋"
 ],
 "Search for": [
  null,
  "搜尋"
 ],
 "Search for an image": [
  null,
  "搜尋映像檔"
 ],
 "Search string or container location": [
  null,
  "搜尋字串或容器位置"
 ],
 "Searching...": [
  null,
  "正在搜尋中..."
 ],
 "Searching: $0": [
  null,
  "正在搜尋: $0"
 ],
 "Shared": [
  null,
  "共享"
 ],
 "Show": [
  null,
  "顯示"
 ],
 "Show images": [
  null,
  "顯示映像檔"
 ],
 "Show intermediate images": [
  null,
  "顯示中介映像檔"
 ],
 "Show less": [
  null,
  "顯示更少"
 ],
 "Show more": [
  null,
  "顯示更多"
 ],
 "Size": [
  null,
  "占用大小"
 ],
 "Start": [
  null,
  "啟動"
 ],
 "Start period": [
  null,
  "啟動期間"
 ],
 "Start typing to look for images.": [
  null,
  "開始輸入尋找映像檔。"
 ],
 "Started at": [
  null,
  "己啟動於"
 ],
 "State": [
  null,
  "狀態"
 ],
 "Status": [
  null,
  "狀態"
 ],
 "Stop": [
  null,
  "停止"
 ],
 "Stopped": [
  null,
  "己停止"
 ],
 "Support preserving established TCP connections": [
  null,
  "支援保留已建立的 TCP 連線"
 ],
 "System": [
  null,
  "系統"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "Tag": [
  null,
  "標籤"
 ],
 "Tags": [
  null,
  "標籤"
 ],
 "The initialization time needed for a container to bootstrap.": [
  null,
  "容器開機所需的初始化時間。"
 ],
 "The maximum time allowed to complete the health check before an interval is considered failed.": [
  null,
  "在間隔被視為失敗之前，完成健康狀態檢查所允許的最長時間。"
 ],
 "The number of retries allowed before a healthcheck is considered to be unhealthy.": [
  null,
  "在健康狀態檢查被視為不健康之前允許的重試次數。"
 ],
 "Timeout": [
  null,
  "超時"
 ],
 "Troubleshoot": [
  null,
  "疑難排解"
 ],
 "Type to filter…": [
  null,
  "特定類型過濾…"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Unable to load image history": [
  null,
  "無法載入映像檔歷史記錄"
 ],
 "Unhealthy": [
  null,
  "不健康"
 ],
 "Up since:": [
  null,
  "自此上線："
 ],
 "Use legacy Docker format": [
  null,
  "使用傳統的 Docker 格式"
 ],
 "Used by": [
  null,
  "已使用"
 ],
 "User": [
  null,
  "使用者"
 ],
 "User:": [
  null,
  "使用者:"
 ],
 "Value": [
  null,
  "值"
 ],
 "View $0": [
  null,
  ""
 ],
 "View $0 logs": [
  null,
  ""
 ],
 "Volumes": [
  null,
  "分區(卷)"
 ],
 "When unhealthy": [
  null,
  "不健康時"
 ],
 "With terminal": [
  null,
  "配備終端機"
 ],
 "Writable": [
  null,
  "可寫"
 ],
 "downloading": [
  null,
  "正在下載"
 ],
 "host[:port]/[user]/container[:tag]": [
  null,
  "主機[:通訊埠]/[使用者]/容器[:標籤]"
 ],
 "in": [
  null,
  "在"
 ],
 "intermediate": [
  null,
  "中介"
 ],
 "intermediate image": [
  null,
  "中介映像檔"
 ],
 "n/a": [
  null,
  "n/a"
 ],
 "not available": [
  null,
  "不提供"
 ],
 "pod": [
  null,
  "pod"
 ],
 "ports": [
  null,
  "通訊埠"
 ],
 "seconds": [
  null,
  "秒"
 ],
 "service": [
  null,
  "服務"
 ],
 "system": [
  null,
  "系統"
 ],
 "unused": [
  null,
  "未使用"
 ],
 "user": [
  null,
  "使用者"
 ],
 "user:": [
  null,
  "使用者:"
 ],
 "volumes": [
  null,
  "分區(卷)"
 ]
});
