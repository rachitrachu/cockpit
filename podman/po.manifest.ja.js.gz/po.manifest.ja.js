cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "ja",
  "language-direction": "ltr"
 },
 "Podman containers": [
  null,
  "Podman コンテナー"
 ],
 "container": [
  null,
  "コンテナー"
 ],
 "image": [
  null,
  "イメージ"
 ],
 "podman": [
  null,
  "Podman"
 ]
});
