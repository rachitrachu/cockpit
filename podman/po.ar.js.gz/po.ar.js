cockpit.locale({
 "": {
  "plural-forms": (n) => n==0 ? 0 : n==1 ? 1 : n==2 ? 2 : n%100>=3 && n%100<=10 ? 3 : n%100>=11 ? 4 : 5,
  "language": "ar",
  "language-direction": "rtl"
 },
 "$0 container": [
  null,
  "لا حاويات",
  "حاوية واحدة",
  "حاويتان",
  "$0 حاويات",
  "$0 حاوية",
  "$0 حاوية"
 ],
 "$0 image total, $1": [
  null,
  "بلا صورة في المجموع، $1",
  "صورة واحدة في المجموع، $1",
  "صورتان في المجموع، $1",
  "$0 صور في المجموع، $1",
  "$0 صورة في المجموع، $1",
  "$0 صورة في المجموع، $1"
 ],
 "$0 second": [
  null,
  "$0 ثانية",
  "ثانية واحدة",
  "ثانيتان",
  "$0 ثوانِ",
  "$0 ثانية",
  "$0 ثانية"
 ],
 "$0 unused image, $1": [
  null,
  "لا توجد صور غير مستخدمة، $1",
  "توجد صورة واحدة غير مستخدمة،$1",
  "توجد صورتان غير مستخدمتان، $1",
  "توجد $0 صور غير مستخدمة، $1",
  "توجد $0 صورة غير مستخدمة، $1",
  "توجد $0 صورة غير مستخدمة، $1"
 ],
 "$0% of $1 limit": [
  null,
  "$0 من $1 حد"
 ],
 "1 to 65535": [
  null,
  "1 إلى 65535"
 ],
 "Action to take once the container transitions to an unhealthy state.": [
  null,
  "الإجراء الذي يجب اتخاذه بمجرد انتقال الحاوية إلى حالة غير صحية."
 ],
 "Actions": [
  null,
  "إجراءات"
 ],
 "Add port mapping": [
  null,
  "إضافة تخطيط المنفذ"
 ],
 "Add variable": [
  null,
  "إضافة متغير"
 ],
 "Add volume": [
  null,
  "إضافة وحدة تخزين"
 ],
 "All": [
  null,
  "الكل"
 ],
 "All registries": [
  null,
  "كافة السجلات"
 ],
 "Always": [
  null,
  "دائماً"
 ],
 "An error occurred": [
  null,
  "حدث خطأ ما"
 ],
 "Author": [
  null,
  "آخر"
 ],
 "CPU": [
  null,
  "المعالج"
 ],
 "CPU Shares help": [
  null,
  "مساعدة أسهم وحدة المعالجة المركزية (CPU)"
 ],
 "CPU shares": [
  null,
  "أسهم وحدة المعالجة المركزية (CPU)"
 ],
 "CPU shares determine the priority of running containers. Default priority is 1024. A higher number prioritizes this container. A lower number decreases priority.": [
  null,
  "مشاركات وحدة المعالجة المركزية (CPU) تحدد أولوية تشغيل الحاويات. الأولوية الافتراضية هي 1024. الرقم الأعلى يعطي الأولوية لهذه الحاوية. الرقم الأقل يقلل من الأولوية."
 ],
 "Cancel": [
  null,
  "إلغاء"
 ],
 "Checking health": [
  null,
  "فحص الصحة"
 ],
 "Checkpoint": [
  null,
  "نقطة الفحص"
 ],
 "Checkpoint and restore support": [
  null,
  "دعم نقاط التحقق والاستعادة"
 ],
 "Checkpoint container $0": [
  null,
  "نقطة استعادة الحاوية $0"
 ],
 "Click to see published ports": [
  null,
  "انقر للاطلاع على المنافذ التي تم نشرها"
 ],
 "Click to see volumes": [
  null,
  "انقر لرؤية وحدات التخزين"
 ],
 "Command": [
  null,
  "أمر"
 ],
 "Comments": [
  null,
  "تعليقات"
 ],
 "Commit": [
  null,
  "إيداع"
 ],
 "Commit container": [
  null,
  "أودع حاوية"
 ],
 "Configured": [
  null,
  "تم تكوينه"
 ],
 "Console": [
  null,
  "وحدة تحكم"
 ],
 "Container": [
  null,
  "حاوية"
 ],
 "Container failed to be created": [
  null,
  "فشل إنشاء الحاوية"
 ],
 "Container failed to be started": [
  null,
  "فشل بدء الحاوية"
 ],
 "Container is not running": [
  null,
  "الحاوية لا تعمل"
 ],
 "Container name": [
  null,
  "اسم الحاوية"
 ],
 "Container name is required.": [
  null,
  "اسم الحاوية مطلوب."
 ],
 "Container path": [
  null,
  "مسار الحاوية"
 ],
 "Container path must not be empty": [
  null,
  "بجب ألا يكون مسار الحاوية فارغاً"
 ],
 "Container port": [
  null,
  "منفذ الحاوية"
 ],
 "Container port must not be empty": [
  null,
  "يجب ألا يكةن منفذ الحاوية فارغاً"
 ],
 "Containers": [
  null,
  "الحاويات"
 ],
 "Create": [
  null,
  "إنشاء"
 ],
 "Create a new image based on the current state of the $0 container.": [
  null,
  "إنشاء صورة جديدة بناءً على الحالة الحالية للحاوية $0."
 ],
 "Create and run": [
  null,
  "إنشاء ثم تشغيل"
 ],
 "Create container": [
  null,
  "إنشاء حاوية"
 ],
 "Create container in $0": [
  null,
  "إنشاء حاوية في $0"
 ],
 "Create container in pod": [
  null,
  "إنشاء حاوية ضمن pod"
 ],
 "Create pod": [
  null,
  "إنشاء pod"
 ],
 "Created": [
  null,
  "تم إنشاؤه"
 ],
 "Created by": [
  null,
  "تم إنشاؤه بواسطة"
 ],
 "Decrease CPU shares": [
  null,
  "تقليل مشاركة CPU"
 ],
 "Decrease interval": [
  null,
  "تقليل الفترة"
 ],
 "Decrease maximum retries": [
  null,
  "تقليل الحد الأقصى لإعادة المحاولة"
 ],
 "Decrease memory": [
  null,
  "تقليل الذاكرة"
 ],
 "Decrease retries": [
  null,
  "تقليل عدد مرات إعادة المحاولة"
 ],
 "Decrease start period": [
  null,
  "تقليل فترة البدء"
 ],
 "Decrease timeout": [
  null,
  "تقليل المهلة"
 ],
 "Delete": [
  null,
  "حذف"
 ],
 "Delete $0 image?": [
  null,
  "حذف الصورة $0؟"
 ],
 "Delete $0?": [
  null,
  "حذف $0؟"
 ],
 "Delete image": [
  null,
  "حذف صورة"
 ],
 "Delete pod $0?": [
  null,
  "حذف الـ pod $0؟"
 ],
 "Delete tagged images": [
  null,
  "حذف الصور الموسومة"
 ],
 "Delete unused images of user $0:": [
  null,
  "حذف الصور غير المستخدمة للمستخدم $0:"
 ],
 "Delete unused system images:": [
  null,
  "حذف صور النظام غير المستخدمة:"
 ],
 "Deleting a container will erase all data in it.": [
  null,
  "سيؤدي حذف حاوية إلى مسح جميع البيانات الموجودة فيها."
 ],
 "Deleting a running container will erase all data in it.": [
  null,
  "سيؤدي حذف حاوية قيد التشغيل إلى مسح جميع البيانات الموجودة فيها."
 ],
 "Deleting this pod will remove the following containers:": [
  null,
  "سيؤدي حذف هذا الـ pod إلى إزالة الحاويات التالية:"
 ],
 "Details": [
  null,
  "التفاصيل"
 ],
 "Disk space": [
  null,
  "مساحة القرص"
 ],
 "Docker format is useful when sharing the image with Docker or Moby Engine": [
  null,
  "تنسيق Docker مفيد عند مشاركة الصورة مع Docker أو Moby Engine"
 ],
 "Download": [
  null,
  "نزِّل"
 ],
 "Download new image": [
  null,
  "نزِّل صورة جديدة"
 ],
 "Empty pod $0 will be permanently removed.": [
  null,
  "ستتم إزالة الـ pod: $0 بشكل دائم."
 ],
 "Entrypoint": [
  null,
  "نقطة الدخول"
 ],
 "Environment variables": [
  null,
  "متغيرات البيئة"
 ],
 "Error": [
  null,
  "خطأ"
 ],
 "Error message": [
  null,
  "رسالة خطأ"
 ],
 "Error occurred while connecting console": [
  null,
  "حدث خطأ أثناء توصيل وحدة التحكم"
 ],
 "Example, Your Name <yourname@example.com>": [
  null,
  "على سبيل المثال، اسمك <yourname@example.com>"
 ],
 "Example: $0": [
  null,
  "على سبيل المثال: $0"
 ],
 "Exited": [
  null,
  "تم الخروج"
 ],
 "Failed health run": [
  null,
  "فشل التشغيل الصحي"
 ],
 "Failed to checkpoint container $0": [
  null,
  "فشل التحقق من الحاوية $0"
 ],
 "Failed to clean up container": [
  null,
  "فشل في تنظيف الحاوية"
 ],
 "Failed to commit container $0": [
  null,
  "فشل في إيداع الحاوية $0"
 ],
 "Failed to create container $0": [
  null,
  "فشل في إنشاء الحاوية $0"
 ],
 "Failed to download image $0:$1": [
  null,
  "فشل في تنزيل الصورة $0:$1"
 ],
 "Failed to force remove container $0": [
  null,
  "فشل في الإزالة الإجبارية للحاوية $0"
 ],
 "Failed to force remove image $0": [
  null,
  "فشل في الإزالة الإجبارية للصورة $0"
 ],
 "Failed to force restart pod $0": [
  null,
  "فشل في إعادة التشغيل الإجبارية للـ pod: $0"
 ],
 "Failed to force stop pod $0": [
  null,
  "فشل في الإيقاف الإجباري للـ pod: $0"
 ],
 "Failed to pause container $0": [
  null,
  "فشل في الإيقاف المؤقت للحاوية $0"
 ],
 "Failed to pause pod $0": [
  null,
  "فشل في الإيقاف المؤقت للـ pod: $0"
 ],
 "Failed to prune unused containers": [
  null,
  "فشل تقليم الحاويات غير المستخدمة"
 ],
 "Failed to prune unused images": [
  null,
  "فشل تقليم الصور غير المستخدمة"
 ],
 "Failed to pull image $0": [
  null,
  "فشل في سحب الصورة $0"
 ],
 "Failed to remove container $0": [
  null,
  "فشل في إزالة الحاوية $0"
 ],
 "Failed to remove image $0": [
  null,
  "فشل في إزالة الصورة $0"
 ],
 "Failed to rename container $0": [
  null,
  "فشل في إعادة تسمية الحاوية $0"
 ],
 "Failed to restart container $0": [
  null,
  "فشل في إعادة تشغيل الحاوية $0"
 ],
 "Failed to restart pod $0": [
  null,
  "فشل في إعادة تشغيل الـ pod: $0"
 ],
 "Failed to restore container $0": [
  null,
  "فشل في إعادة تخزين الحاوية $0"
 ],
 "Failed to resume container $0": [
  null,
  "فشل في استئناف الحاوية $0"
 ],
 "Failed to resume pod $0": [
  null,
  "فشل في استئناف الـ pod: $0"
 ],
 "Failed to run container $0": [
  null,
  "فشل في تشغيل الحاوية $0"
 ],
 "Failed to run health check on container $0": [
  null,
  "فشل تشغيل فحص الحالة الصحية على الحاوية $0"
 ],
 "Failed to search for images.": [
  null,
  "فشل في البحث عن الصور."
 ],
 "Failed to search for images: $0": [
  null,
  "فشل في البحث عن الصور: $0"
 ],
 "Failed to search for new images": [
  null,
  "فشل البحث عن صور جديدة"
 ],
 "Failed to start container $0": [
  null,
  "فشل بدء الحاوية $0"
 ],
 "Failed to start pod $0": [
  null,
  "فشل في بدء الـ pod: $0"
 ],
 "Failed to stop container $0": [
  null,
  "فشل في إيقاف الحاوية $0"
 ],
 "Failed to stop pod $0": [
  null,
  "فشل في إيقاف الـ pod: $0"
 ],
 "Failing streak": [
  null,
  "سلسلة الإخفاق الممتالية"
 ],
 "Force commit": [
  null,
  "فرض الإيداع"
 ],
 "Force delete": [
  null,
  "حذف إجباري"
 ],
 "Force delete pod $0?": [
  null,
  "تريد فرض حذف الـ pod: $0؟"
 ],
 "Force restart": [
  null,
  "فرض إعادة التشغيل"
 ],
 "Force stop": [
  null,
  "فرض الإيقاف"
 ],
 "GB": [
  null,
  "GB"
 ],
 "Gateway": [
  null,
  "البوّابة"
 ],
 "Health check": [
  null,
  "صحة الفحص"
 ],
 "Health check interval help": [
  null,
  "المساعدة في الفترات الفاصلة بين فحوصات الصحة"
 ],
 "Health check retries help": [
  null,
  "مساعدة إعادة محاولة التحقق من الصحة"
 ],
 "Health check start period help": [
  null,
  "المساعدة في فترة بدء الفحص الصحة"
 ],
 "Health check timeout help": [
  null,
  "المساعدة في مهلة التحقق من الصحة"
 ],
 "Health failure check action help": [
  null,
  "المساعدة في إجراء التحقق من الفشل الصحي"
 ],
 "Healthy": [
  null,
  "صحي"
 ],
 "Hide images": [
  null,
  "إخفاء الصور"
 ],
 "Hide intermediate images": [
  null,
  "إخفاء الصور الوسيطة"
 ],
 "History": [
  null,
  "تاريخ"
 ],
 "Host path": [
  null,
  "مسار المضيف"
 ],
 "Host port": [
  null,
  "منفذ المضيف"
 ],
 "Host port help": [
  null,
  "مساعدة منفذ المضيف"
 ],
 "ID": [
  null,
  "المعرّف"
 ],
 "IP address": [
  null,
  "عنوان IP"
 ],
 "IP address help": [
  null,
  "مساعدة عنوان IP"
 ],
 "Ideal for development": [
  null,
  "نموذجية للتطوير"
 ],
 "Ideal for running services": [
  null,
  "نموذجية لتشغيل الخدمات"
 ],
 "If host IP is set to 0.0.0.0 or not set at all, the port will be bound on all IPs on the host.": [
  null,
  "إذا تم تعيين عنوان IP المضيف على 0.0.0.0.0 أو لم يتم تعيينه على الإطلاق، فسيتم ربط المنفذ بجميع عناوين IP على المضيف."
 ],
 "If the host port is not set the container port will be randomly assigned a port on the host.": [
  null,
  "إذا لم يتم تعيين منفذ المضيف، فسيتم تعيين منفذ الحاوية بشكل عشوائي على المضيف."
 ],
 "Ignore IP address if set statically": [
  null,
  "تجاهل عنوان IP إذا تم تعيينه بشكل ثابت"
 ],
 "Ignore MAC address if set statically": [
  null,
  "تجاهل عنوان MAC إذا تم تعيينه بشكل ثابت"
 ],
 "Image": [
  null,
  "صورة"
 ],
 "Image name is not unique": [
  null,
  "اسم الصورة ليس فريداً"
 ],
 "Image name is required": [
  null,
  "اسم الصورة مطلوب"
 ],
 "Image selection help": [
  null,
  "المساعدة في تحديد صورة"
 ],
 "Images": [
  null,
  "الصور"
 ],
 "Increase CPU shares": [
  null,
  "زيادة مشاركات وحدة المعالجة المركزية (CPU)"
 ],
 "Increase interval": [
  null,
  "زيادة الفترة الزمنية"
 ],
 "Increase maximum retries": [
  null,
  "زيادة الحد الأقصى لإعادة المحاولة"
 ],
 "Increase memory": [
  null,
  "زيادة الذكرة"
 ],
 "Increase retries": [
  null,
  "زيادة عدد مرات إعادة المحاولة"
 ],
 "Increase start period": [
  null,
  "زيادة فترة البدء"
 ],
 "Increase timeout": [
  null,
  "زيادة المهلة الزمنية"
 ],
 "Integration": [
  null,
  "تكامل"
 ],
 "Interval": [
  null,
  "فترة زمنية"
 ],
 "Interval how often health check is run.": [
  null,
  "الفاصل الزمني لعدد المرات التي يتم فيها تشغيل فحص الصحة."
 ],
 "Invalid characters. Name can only contain letters, numbers, and certain punctuation (_ . -).": [
  null,
  "أحرف غير صالحة. يمكن أن يحتوي الاسم فقط على أحرف وأرقام وعلامات ترقيم معينة (_ . -)."
 ],
 "KB": [
  null,
  "KB"
 ],
 "Keep all temporary checkpoint files": [
  null,
  "الاحتفاظ بجميع ملفات نقاط التفتيش المؤقتة"
 ],
 "Key": [
  null,
  "مفتاح"
 ],
 "Key contains invalid characters": [
  null,
  "يحتوي المفتاح على أحرف غير صالحة"
 ],
 "Key must not be empty": [
  null,
  "يجب ألا يكون المفتاح فارغاً"
 ],
 "Key must not begin with a digit": [
  null,
  "يجب ألا يبدأ المفتاح بعدد"
 ],
 "Last 5 runs": [
  null,
  "آخر ٥ مرات تشغيل"
 ],
 "Latest checkpoint": [
  null,
  "‎آخر نقطة فحص"
 ],
 "Leave running after writing checkpoint to disk": [
  null,
  "ترك التشغيل بعد كتابة نقطة التحقق على القرص"
 ],
 "Loading details...": [
  null,
  "جاري تحميل التفاصيل..."
 ],
 "Loading logs...": [
  null,
  "جاري تحميل السجلات..."
 ],
 "Loading...": [
  null,
  "قيد التحميل..."
 ],
 "Local": [
  null,
  "محلي"
 ],
 "Local images": [
  null,
  "الصور المحلية"
 ],
 "Logs": [
  null,
  "السجلات"
 ],
 "MAC address": [
  null,
  "عنوان MAC"
 ],
 "MB": [
  null,
  "MB"
 ],
 "Maximum retries": [
  null,
  "الحد الأقصى لإعادة المحاولة"
 ],
 "Memory": [
  null,
  "الذاكرة"
 ],
 "Memory limit": [
  null,
  "حد الذاكرة"
 ],
 "Memory unit": [
  null,
  "وحدة الذاكرة"
 ],
 "Mode": [
  null,
  "الطور"
 ],
 "Multiple tags exist for this image. Select the tagged images to delete.": [
  null,
  "توجد عدة أوسمة لهذه الصورة. حدد الصور الموسومة لحذفها."
 ],
 "Must be a valid IP address": [
  null,
  "يجب أن يكةن عنوان IP صالحاً"
 ],
 "Name": [
  null,
  "الاسم"
 ],
 "Name already in use": [
  null,
  "الاسم مستخدم بالفعل"
 ],
 "New container name": [
  null,
  "اسم حاوية جديد"
 ],
 "New image name": [
  null,
  "اسم صورة جديد"
 ],
 "No": [
  null,
  "لا"
 ],
 "No action": [
  null,
  "لا حدث"
 ],
 "No containers": [
  null,
  "لا حاويات"
 ],
 "No containers are using this image": [
  null,
  "لا حاويات تستخدم هذه الصورة"
 ],
 "No containers in this pod": [
  null,
  "لا حاويات في هذا الـ pod"
 ],
 "No containers that match the current filter": [
  null,
  "لا توجد حاويات مطابقة لعامل التصفية الحالي"
 ],
 "No environment variables specified": [
  null,
  "لم يتم تحديد متغيرات البيئة"
 ],
 "No images": [
  null,
  "لا صور"
 ],
 "No images found": [
  null,
  "لا صور موجودة"
 ],
 "No images that match the current filter": [
  null,
  "لا صور تتطابق مع عامل التصفية الحالي"
 ],
 "No label": [
  null,
  "لا يوجد علامة"
 ],
 "No ports exposed": [
  null,
  "لا توجد منافذ مكشوفة"
 ],
 "No results for $0": [
  null,
  "لا تنائج لـ $0"
 ],
 "No running containers": [
  null,
  "لا حاويات قيد التشغيل"
 ],
 "No volumes specified": [
  null,
  "لا وحدات تحزين محددة"
 ],
 "On failure": [
  null,
  "عند الفشل"
 ],
 "Only running": [
  null,
  "التشغيل فقط"
 ],
 "Options": [
  null,
  "الخيارات"
 ],
 "Owner": [
  null,
  "المالك"
 ],
 "Owner help": [
  null,
  "مساعدة المالك"
 ],
 "Passed health run": [
  null,
  "اجتازت اختبار الصحة"
 ],
 "Paste one or more lines of key=value pairs into any field for bulk import": [
  null,
  "الصق سطرًا واحدًا أو أكثر من أزواج المفتاح= القيمة في أي حقل للاستيراد الجماعي"
 ],
 "Pause": [
  null,
  "إيقاف"
 ],
 "Pause container when creating image": [
  null,
  "إيقاف الحاوية مؤقتاً عند إنشاء الصورة"
 ],
 "Paused": [
  null,
  "تم إيقافه مؤقتاً"
 ],
 "Pod failed to be created": [
  null,
  "فشل إنشاء الـ Pod"
 ],
 "Pod name": [
  null,
  "اسم الـ Pod"
 ],
 "Podman service failed": [
  null,
  "خدمة Podman تعطلت"
 ],
 "Port mapping": [
  null,
  "تعيين المنفذ"
 ],
 "Ports": [
  null,
  "المنافذ"
 ],
 "Ports under 1024 can be mapped": [
  null,
  "يمكن تعيين المنافذ الأقل من 1024"
 ],
 "Private": [
  null,
  "خاص"
 ],
 "Protocol": [
  null,
  "بروتوكول"
 ],
 "Prune": [
  null,
  "التقليم"
 ],
 "Prune unused containers": [
  null,
  "تقليم الحاويات غير المستخدمة"
 ],
 "Prune unused images": [
  null,
  "تلقيم الصور الغير مستخدمة"
 ],
 "Pruning containers": [
  null,
  "تلقيم الحاويات"
 ],
 "Pruning images": [
  null,
  "تلقيم الصور"
 ],
 "Pull": [
  null,
  "اسحب"
 ],
 "Pull all images": [
  null,
  "سحب جميع الصور"
 ],
 "Pull latest image": [
  null,
  "اسحب آخر صورة"
 ],
 "Pulling": [
  null,
  "السحب"
 ],
 "Read-only access": [
  null,
  "وصول القرآءة فقط"
 ],
 "Read-write access": [
  null,
  "وصول القرآءة-الكتابة"
 ],
 "Remove item": [
  null,
  "إزالة العنصر"
 ],
 "Removes selected non-running containers": [
  null,
  "أزل الحاويات المحددة التي ليست قيد التشغيل"
 ],
 "Removing": [
  null,
  "قيد الإزالة"
 ],
 "Rename": [
  null,
  "إعادة التسمية"
 ],
 "Rename container $0": [
  null,
  "إعادة تسمية الحاوية $0"
 ],
 "Resource limits can be set": [
  null,
  "يمكن تعيين حدود للموارد"
 ],
 "Restart": [
  null,
  "أعد التشغيل"
 ],
 "Restart policy": [
  null,
  "سياسة إعادة التشغيل"
 ],
 "Restart policy help": [
  null,
  "تعليمات سياسة إعادة التشغيل"
 ],
 "Restart policy to follow when containers exit.": [
  null,
  "سياسة إعادة التشغيل الواجب اتباعها عند إنهاء الحاويات."
 ],
 "Restart policy to follow when containers exit. Using linger for auto-starting containers may not work in some circumstances, such as when ecryptfs, systemd-homed, NFS, or 2FA are used on a user account.": [
  null,
  "سياسة إعادة التشغيل المبتبعة عند إنهاء الحاويات. قد لا يعمل استخدام linger لبدء تشغيل الحاويات تلقائيًا في بعض الظروف، مثل عند استخدام ecryptfs أو systemd-homed-homed أو NFS أو 2FA على حساب مستخدم."
 ],
 "Restore": [
  null,
  "استعادة"
 ],
 "Restore container $0": [
  null,
  "استعادة الحاوية $0"
 ],
 "Restore with established TCP connections": [
  null,
  "الاستعادة مع اتصالات TCP القائمة"
 ],
 "Restricted by user account permissions": [
  null,
  "مقيد بصلاحيات حساب المستخدم"
 ],
 "Resume": [
  null,
  "استئناف"
 ],
 "Retries": [
  null,
  "إعادة المحاولة"
 ],
 "Retry another term.": [
  null,
  "إعادة تجربة المدة."
 ],
 "Run health check": [
  null,
  "شغَّل فحص الصحة"
 ],
 "Running": [
  null,
  "التشغيل"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Search by name or description": [
  null,
  "البحث عبر الاسم أو الوصف"
 ],
 "Search by registry": [
  null,
  "البحث عبر السجل"
 ],
 "Search for": [
  null,
  "البحث عن"
 ],
 "Search for an image": [
  null,
  "البحث عن صورة"
 ],
 "Search string or container location": [
  null,
  "سلسلة البحث أو موقع الحاوية"
 ],
 "Searching...": [
  null,
  "يجري البحث..."
 ],
 "Searching: $0": [
  null,
  "البحث: $0"
 ],
 "Shared": [
  null,
  "مشتركة"
 ],
 "Show": [
  null,
  "عرض"
 ],
 "Show images": [
  null,
  "أظهر الصور"
 ],
 "Show intermediate images": [
  null,
  "إظهار الصور الوسيطة"
 ],
 "Show less": [
  null,
  "عرض أقل"
 ],
 "Show more": [
  null,
  "أظهر المزيد"
 ],
 "Size": [
  null,
  "الحجم"
 ],
 "Start": [
  null,
  "بدء"
 ],
 "Start period": [
  null,
  "فترة البدء"
 ],
 "Start typing to look for images.": [
  null,
  "ابدأ الكتابة للبحث عن الصور."
 ],
 "Started at": [
  null,
  "بدأ عند"
 ],
 "State": [
  null,
  "حالة"
 ],
 "Status": [
  null,
  "الحالة"
 ],
 "Stop": [
  null,
  "إيقاف"
 ],
 "Stopped": [
  null,
  "تم إيقافه"
 ],
 "Support preserving established TCP connections": [
  null,
  "دعم الحفاظ على اتصالات TCP المنشأة"
 ],
 "System": [
  null,
  "النظام"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "Tag": [
  null,
  "علامة"
 ],
 "Tags": [
  null,
  "العلامات"
 ],
 "The initialization time needed for a container to bootstrap.": [
  null,
  "وقت التهيئة الأولية اللازم لتهيئة الحاوية للتمهيد."
 ],
 "The maximum time allowed to complete the health check before an interval is considered failed.": [
  null,
  "الحد الأقصى للوقت المسموح به لإكمال الفحص الصحي قبل اعتبار أن الفاصل الزمني فشل."
 ],
 "The number of retries allowed before a healthcheck is considered to be unhealthy.": [
  null,
  "عدد مرات إعادة المحاولة المسموح بها قبل اعتبار فحص الصحة غير صحي."
 ],
 "Timeout": [
  null,
  "المهلة الزمنية"
 ],
 "Troubleshoot": [
  null,
  "استكشاف الأخطاء وإصلاحها"
 ],
 "Type to filter…": [
  null,
  "نوع عامل التصفية…"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Unable to load image history": [
  null,
  "غير قادر على تحميل تاريخ الصورة"
 ],
 "Unhealthy": [
  null,
  "غير صحي"
 ],
 "Up since:": [
  null,
  "منذ:"
 ],
 "Use legacy Docker format": [
  null,
  "استخدام تنسيق Docker القديم"
 ],
 "Used by": [
  null,
  "مستخدم من قبل"
 ],
 "User": [
  null,
  "المستخدم"
 ],
 "User:": [
  null,
  "المستخدم:"
 ],
 "Value": [
  null,
  "قيمة"
 ],
 "View $0": [
  null,
  "عرض $0"
 ],
 "View $0 logs": [
  null,
  "عرض سجلات $0"
 ],
 "Volumes": [
  null,
  "وحدات التخزين"
 ],
 "When unhealthy": [
  null,
  "عندما تكون غير صحية"
 ],
 "With terminal": [
  null,
  "مع واجهة الطرفية"
 ],
 "Writable": [
  null,
  "قابل للكتابة"
 ],
 "downloading": [
  null,
  "التنزيل"
 ],
 "host[:port]/[user]/container[:tag]": [
  null,
  "مضيف[:منفذ]/[مستخدم]/ حاوية[:علامة]"
 ],
 "in": [
  null,
  "في"
 ],
 "intermediate": [
  null,
  "وسيط"
 ],
 "intermediate image": [
  null,
  "صورة وسيطة"
 ],
 "n/a": [
  null,
  "غير متاح"
 ],
 "not available": [
  null,
  "غير متوفر"
 ],
 "pod": [
  null,
  "Pod"
 ],
 "ports": [
  null,
  "المنافذ"
 ],
 "seconds": [
  null,
  "الثواني"
 ],
 "service": [
  null,
  "الخدمة"
 ],
 "system": [
  null,
  "النظام"
 ],
 "systemd service": [
  null,
  "خدمة systrmd"
 ],
 "unused": [
  null,
  "غير مستخدم"
 ],
 "user": [
  null,
  "المُستخدم"
 ],
 "user:": [
  null,
  "المستخدم:"
 ],
 "volumes": [
  null,
  "وحدات التخزين"
 ]
});
