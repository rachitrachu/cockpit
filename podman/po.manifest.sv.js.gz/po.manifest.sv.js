cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "sv",
  "language-direction": "ltr"
 },
 "Podman containers": [
  null,
  "Podman-behållare"
 ],
 "container": [
  null,
  "behållare"
 ],
 "image": [
  null,
  "avbild"
 ],
 "podman": [
  null,
  "podman"
 ]
});
