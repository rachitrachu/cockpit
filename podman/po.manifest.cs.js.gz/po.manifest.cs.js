cockpit.locale({
 "": {
  "plural-forms": (n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2,
  "language": "cs",
  "language-direction": "ltr"
 },
 "Podman containers": [
  null,
  "Podman kontejnery"
 ],
 "container": [
  null,
  "kontejner"
 ],
 "image": [
  null,
  "obraz"
 ],
 "podman": [
  null,
  "podman"
 ]
});
