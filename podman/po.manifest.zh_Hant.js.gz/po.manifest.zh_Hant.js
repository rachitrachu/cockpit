cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "zh_Hant",
  "language-direction": "ltr"
 },
 "Podman containers": [
  null,
  "Podman 容器"
 ],
 "container": [
  null,
  "容器"
 ],
 "image": [
  null,
  "映像檔"
 ],
 "podman": [
  null,
  "podman"
 ]
});
