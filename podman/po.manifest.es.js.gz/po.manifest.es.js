cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "es",
  "language-direction": "ltr"
 },
 "Podman containers": [
  null,
  "Contenedores de Podman"
 ],
 "container": [
  null,
  "contenedor"
 ],
 "image": [
  null,
  "imagen"
 ],
 "podman": [
  null,
  "podman"
 ]
});
