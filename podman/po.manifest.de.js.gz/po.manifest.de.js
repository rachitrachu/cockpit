cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "de",
  "language-direction": "ltr"
 },
 "Podman containers": [
  null,
  "Podman-Container"
 ],
 "container": [
  null,
  "container"
 ],
 "image": [
  null,
  "Image"
 ],
 "podman": [
  null,
  "podman"
 ]
});
