cockpit.locale({
 "": {
  "plural-forms": (n) => n > 1,
  "language": "fr",
  "language-direction": "ltr"
 },
 "Podman containers": [
  null,
  "Conteneurs Podman"
 ],
 "container": [
  null,
  "conteneur"
 ],
 "image": [
  null,
  "image"
 ],
 "podman": [
  null,
  "podman"
 ]
});
