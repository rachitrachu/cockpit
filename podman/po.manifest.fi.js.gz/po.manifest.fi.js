cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "fi",
  "language-direction": "ltr"
 },
 "Podman containers": [
  null,
  "Podman-kontit"
 ],
 "container": [
  null,
  "kontti"
 ],
 "image": [
  null,
  "levykuva"
 ],
 "podman": [
  null,
  "podman"
 ]
});
