cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "es",
  "language-direction": "ltr"
 },
 "$0 container": [
  null,
  "$0 contenedor",
  "$0 contenedores"
 ],
 "$0 image total, $1": [
  null,
  "$0 imagen, $1",
  "$0 imágenes en total, $1"
 ],
 "$0 second": [
  null,
  "$0 segundo",
  "$0 segundos"
 ],
 "$0 unused image, $1": [
  null,
  "$0 imagen sin usar, $1",
  "$0 imágenes sin usar, $1"
 ],
 "$0% of $1 limit": [
  null,
  "$0% de $1 límite"
 ],
 "1 to 65535": [
  null,
  "1 a 65535"
 ],
 "Action to take once the container transitions to an unhealthy state.": [
  null,
  "Acción a tomar una vez que el contenedor pase a un mal estado de salud."
 ],
 "Actions": [
  null,
  "Acciones"
 ],
 "Add port mapping": [
  null,
  "Añadir mapeo de puertos"
 ],
 "Add variable": [
  null,
  "Añadir variable"
 ],
 "Add volume": [
  null,
  "Añadir volumen"
 ],
 "All": [
  null,
  "Todos"
 ],
 "All registries": [
  null,
  "Todos los registros"
 ],
 "Always": [
  null,
  "Siempre"
 ],
 "An error occurred": [
  null,
  "Ocurrió un error"
 ],
 "Author": [
  null,
  "Autor"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "CPU Shares help": [
  null,
  "Ayuda sobre shares de CPU"
 ],
 "CPU shares": [
  null,
  "Shares de CPU"
 ],
 "CPU shares determine the priority of running containers. Default priority is 1024. A higher number prioritizes this container. A lower number decreases priority.": [
  null,
  "Los shares de CPU determinan la prioridad de ejecución de contenedores. La prioridad por defecto es 1024. Un número mayor prioriza este contenedor. Un número menor reduce la prioridad."
 ],
 "Cancel": [
  null,
  "Cancelar"
 ],
 "Checking health": [
  null,
  "Comprobando estado de salud"
 ],
 "Checkpoint": [
  null,
  "Punto comprobante"
 ],
 "Checkpoint and restore support": [
  null,
  "Soporte para checkpoint y restauración"
 ],
 "Checkpoint container $0": [
  null,
  "Crear checkpoint del contenedor $0"
 ],
 "Click to see published ports": [
  null,
  "Pulse para ver los puertos publicados"
 ],
 "Click to see volumes": [
  null,
  "Pulse para ver los volúmenes"
 ],
 "Command": [
  null,
  "Comando"
 ],
 "Comments": [
  null,
  "Comentarios"
 ],
 "Commit": [
  null,
  "Commit"
 ],
 "Commit container": [
  null,
  "Confirmar contenedor"
 ],
 "Configured": [
  null,
  "Configurado"
 ],
 "Console": [
  null,
  "Consola"
 ],
 "Container": [
  null,
  "Contenedores"
 ],
 "Container failed to be created": [
  null,
  "El contenedor no pudo ser creado"
 ],
 "Container failed to be started": [
  null,
  "El contenedor no pudo ser iniciado"
 ],
 "Container is not running": [
  null,
  "El contenedor no se está ejecutando"
 ],
 "Container name": [
  null,
  "Nombre de contenedor"
 ],
 "Container name is required.": [
  null,
  "Se requiere un nombre para el contenedor."
 ],
 "Container path": [
  null,
  "Ruta del contenedor"
 ],
 "Container path must not be empty": [
  null,
  "La ruta del contenedor no debe estar vacía"
 ],
 "Container port": [
  null,
  "Puerto del contenedor"
 ],
 "Container port must not be empty": [
  null,
  "El puerto de contenedores no debe estar vacío"
 ],
 "Containers": [
  null,
  "Contenedores"
 ],
 "Create": [
  null,
  "Crear"
 ],
 "Create a new image based on the current state of the $0 container.": [
  null,
  "Crear una imagen nueva basada en el estado actual del contenedor $0."
 ],
 "Create and run": [
  null,
  "Crear y ejecutar"
 ],
 "Create container": [
  null,
  "Crear contenedor"
 ],
 "Create container in $0": [
  null,
  "Crear contenedor en $0"
 ],
 "Create container in pod": [
  null,
  "Crear un contenedor en el pod"
 ],
 "Create pod": [
  null,
  "Crear pod"
 ],
 "Created": [
  null,
  "Creado"
 ],
 "Created by": [
  null,
  "Creada por"
 ],
 "Decrease CPU shares": [
  null,
  "Reducir shares de CPU"
 ],
 "Decrease interval": [
  null,
  "Reducir intervalo"
 ],
 "Decrease maximum retries": [
  null,
  "Reducir el número máximo de reintentos"
 ],
 "Decrease memory": [
  null,
  "Reducir la cantidad de memoria"
 ],
 "Decrease retries": [
  null,
  "Reducir el número de reintentos"
 ],
 "Decrease start period": [
  null,
  "Reducir el periodo de arranque"
 ],
 "Decrease timeout": [
  null,
  "Reducir el tiempo de espera"
 ],
 "Delete": [
  null,
  "Eliminar"
 ],
 "Delete $0 image?": [
  null,
  "¿Eliminar imagen de $0?"
 ],
 "Delete $0?": [
  null,
  "¿Eliminar $0?"
 ],
 "Delete image": [
  null,
  "Eliminar Imagen"
 ],
 "Delete pod $0?": [
  null,
  "¿Eliminar pod $0?"
 ],
 "Delete tagged images": [
  null,
  "Eliminar imágenes etiquetadas"
 ],
 "Delete unused images of user $0:": [
  null,
  "Elimina imágenes inusuales del usuario $0:"
 ],
 "Delete unused system images:": [
  null,
  "Eliminar imágenes del sistema sin usar:"
 ],
 "Deleting a container will erase all data in it.": [
  null,
  "Eliminando un contenedor se borrará toda la información que hay en él."
 ],
 "Deleting a running container will erase all data in it.": [
  null,
  "Eliminando un contenedor en ejecución borrará toda la información que haya en él."
 ],
 "Deleting this pod will remove the following containers:": [
  null,
  "Eliminando este pod eliminará los siguientes contenedores:"
 ],
 "Details": [
  null,
  "Detalles"
 ],
 "Disk space": [
  null,
  "Tamaño en disco"
 ],
 "Docker format is useful when sharing the image with Docker or Moby Engine": [
  null,
  "El formato Docker es útil para compartir la imagen con Docker o Moby Engine"
 ],
 "Download": [
  null,
  "Descargar"
 ],
 "Download new image": [
  null,
  "Descargar nueva imagen"
 ],
 "Empty pod $0 will be permanently removed.": [
  null,
  "El pod $0, vacío, será eliminado permanentemente."
 ],
 "Entrypoint": [
  null,
  "Punto de entrada"
 ],
 "Environment variables": [
  null,
  "Variables de entorno"
 ],
 "Error": [
  null,
  "Error"
 ],
 "Error message": [
  null,
  "Mensaje de error"
 ],
 "Error occurred while connecting console": [
  null,
  "Hubo un error al conectar la consola"
 ],
 "Example, Your Name <yourname@example.com>": [
  null,
  "Por ejemplo, Tu Nombre <tunombre@ejemplo.es>"
 ],
 "Example: $0": [
  null,
  "Por ejemplo: $0"
 ],
 "Exited": [
  null,
  "Finalizado"
 ],
 "Failed health run": [
  null,
  "Comprobación de estado de salud fallada"
 ],
 "Failed to checkpoint container $0": [
  null,
  "Falló hacer el checkpoint del contenedor $0"
 ],
 "Failed to clean up container": [
  null,
  "Falló al limpiar el contenedor"
 ],
 "Failed to commit container $0": [
  null,
  "Falló hacer el commit en el contenedor $0"
 ],
 "Failed to create container $0": [
  null,
  "Fallo al crear el contenedor $0"
 ],
 "Failed to download image $0:$1": [
  null,
  "Fallo al descargar la imagen $0:$1"
 ],
 "Failed to force remove container $0": [
  null,
  "Falló al forzar el borrado del contenedor $0"
 ],
 "Failed to force remove image $0": [
  null,
  "Fallo al forzar el borrado de la imagen $0"
 ],
 "Failed to force restart pod $0": [
  null,
  "Fallo al reiniciar forzadamente el pod $0"
 ],
 "Failed to force stop pod $0": [
  null,
  "Fallo al detener forzadamente el pod $0"
 ],
 "Failed to pause container $0": [
  null,
  "Fallo al pausar el contenedor $0"
 ],
 "Failed to pause pod $0": [
  null,
  "Fallo al pausar el pod $0"
 ],
 "Failed to prune unused containers": [
  null,
  "Fallo al eliminar los contenedores no utilizados"
 ],
 "Failed to prune unused images": [
  null,
  "Fallo al eliminar las imágenes no usadas"
 ],
 "Failed to pull image $0": [
  null,
  "Fallo al obtener la imagen $0"
 ],
 "Failed to remove container $0": [
  null,
  "Falló al eliminar el contenedor $0"
 ],
 "Failed to remove image $0": [
  null,
  "Fallo al eliminar la imagen $0"
 ],
 "Failed to rename container $0": [
  null,
  "Fallo al renombrar el contenedor $0"
 ],
 "Failed to restart container $0": [
  null,
  "Falló al reiniciar el contenedor $0"
 ],
 "Failed to restart pod $0": [
  null,
  "Fallo al reiniciar el pod $0"
 ],
 "Failed to restore container $0": [
  null,
  "Fallo al restaurar el contenedor $0"
 ],
 "Failed to resume container $0": [
  null,
  "Fallo al reanudar el contenedor $0"
 ],
 "Failed to resume pod $0": [
  null,
  "Fallo al reanudar el pod $0"
 ],
 "Failed to run container $0": [
  null,
  "Fallo al iniciar el contenedor $0"
 ],
 "Failed to run health check on container $0": [
  null,
  "Fallo al comprobar el estado de salud del contenedor $0"
 ],
 "Failed to search for images.": [
  null,
  "Fallo al buscar imágenes."
 ],
 "Failed to search for images: $0": [
  null,
  "Fallo al buscar las imágenes: $0"
 ],
 "Failed to search for new images": [
  null,
  "Falló al buscar nuevas imágenes"
 ],
 "Failed to start container $0": [
  null,
  "Falló al iniciar el contenedor $0"
 ],
 "Failed to start pod $0": [
  null,
  "Fallo al iniciar el pod $0"
 ],
 "Failed to stop container $0": [
  null,
  "Falló al parar el contenedor $0"
 ],
 "Failed to stop pod $0": [
  null,
  "Fallo al parar el pod $0"
 ],
 "Failing streak": [
  null,
  "Racha de fallos"
 ],
 "Force commit": [
  null,
  "Forzar commit"
 ],
 "Force delete": [
  null,
  "Forzar el borrado"
 ],
 "Force delete pod $0?": [
  null,
  "¿Forzar la eliminación del pod $0?"
 ],
 "Force restart": [
  null,
  "Forzar el reinicio"
 ],
 "Force stop": [
  null,
  "Forzar la parada"
 ],
 "GB": [
  null,
  "GB"
 ],
 "Gateway": [
  null,
  "Puerta de enlace"
 ],
 "Health check": [
  null,
  "Comprobación del estado de salud"
 ],
 "Health check interval help": [
  null,
  "Ayuda sobre el intervalo de comprobación del estado de salud"
 ],
 "Health check retries help": [
  null,
  "Ayuda sobre el número de reintentos de comprobación del estado de salud"
 ],
 "Health check start period help": [
  null,
  "Ayuda sobre el periodo de arranque de comprobación del estado de salud"
 ],
 "Health check timeout help": [
  null,
  "Ayuda sobre el tiempo de espera de comprobación del estado de salud"
 ],
 "Health failure check action help": [
  null,
  "Ayuda sobre la acción al fallo al comprobar el estado de salud"
 ],
 "Healthy": [
  null,
  "Buen estado de salud"
 ],
 "Hide images": [
  null,
  "Ocultar imágenes"
 ],
 "Hide intermediate images": [
  null,
  "Ocultar imágenes intermedias"
 ],
 "History": [
  null,
  "Historial"
 ],
 "Host path": [
  null,
  "Ruta del anfitrión"
 ],
 "Host port": [
  null,
  "Puerto del anfitrión"
 ],
 "Host port help": [
  null,
  "Ayuda sobre el puerto del anfitrión"
 ],
 "ID": [
  null,
  "ID"
 ],
 "IP address": [
  null,
  "Dirección IP"
 ],
 "IP address help": [
  null,
  "Ayuda sobre la dirección IP"
 ],
 "Ideal for development": [
  null,
  "Idóneo para entornos de desarrollo"
 ],
 "Ideal for running services": [
  null,
  "Idóneo para ejecutar servicios"
 ],
 "If host IP is set to 0.0.0.0 or not set at all, the port will be bound on all IPs on the host.": [
  null,
  "Si la IP del host se asigna a 0.0.0.0 o no se asigna, el puerto se asociará a todas las IP's del host."
 ],
 "If the host port is not set the container port will be randomly assigned a port on the host.": [
  null,
  "Si no se asigna el puerto del host, el puerto del contenedor se asignará a un puerto aleatorio del host."
 ],
 "Ignore IP address if set statically": [
  null,
  "Ignorar la dirección IP si se ha configurado de forma estática"
 ],
 "Ignore MAC address if set statically": [
  null,
  "Ignorar la dirección MAC si se ha configurado de forma estática"
 ],
 "Image": [
  null,
  "Imagen"
 ],
 "Image name is not unique": [
  null,
  "El nombre de la imagen no es único"
 ],
 "Image name is required": [
  null,
  "Se requiere un nombre para la imagen"
 ],
 "Image selection help": [
  null,
  "Ayuda sobre la selección de imagen"
 ],
 "Images": [
  null,
  "Imágenes"
 ],
 "Increase CPU shares": [
  null,
  "Incrementar shares de CPU"
 ],
 "Increase interval": [
  null,
  "Incrementar el intervalo"
 ],
 "Increase maximum retries": [
  null,
  "Incrementar el número máximo de reintentos"
 ],
 "Increase memory": [
  null,
  "Incrementar la cantidad de memoria"
 ],
 "Increase retries": [
  null,
  "Incrementar el número de reintentos"
 ],
 "Increase start period": [
  null,
  "Incrementar el periodo de arranque"
 ],
 "Increase timeout": [
  null,
  "Incrementar el tiempo de espera"
 ],
 "Integration": [
  null,
  "Integración"
 ],
 "Interval": [
  null,
  "Intervalo"
 ],
 "Interval how often health check is run.": [
  null,
  "Cada cuánto se ejecuta la comprobación del estado de salud."
 ],
 "Invalid characters. Name can only contain letters, numbers, and certain punctuation (_ . -).": [
  null,
  "Carácteres inválidos. El nombre sólo puede contener letras, números y ciertos signos de puntuación (_ . -)."
 ],
 "KB": [
  null,
  "KB"
 ],
 "Keep all temporary checkpoint files": [
  null,
  "Mantener todos los archivos temporales de checkpoint"
 ],
 "Key": [
  null,
  "Clave"
 ],
 "Key contains invalid characters": [
  null,
  "La lave contiene caracteres no válidos"
 ],
 "Key must not be empty": [
  null,
  "La clave no debe estar vacía"
 ],
 "Key must not begin with a digit": [
  null,
  "La clave no debe empezar con un digito"
 ],
 "Last 5 runs": [
  null,
  "Últimas 5 comprobaciones"
 ],
 "Latest checkpoint": [
  null,
  "Último punto comprobante"
 ],
 "Leave running after writing checkpoint to disk": [
  null,
  "Seguir ejecutando tras escribir el punto comprobante en disco"
 ],
 "Loading details...": [
  null,
  "Cargando detalles..."
 ],
 "Loading logs...": [
  null,
  "Cargando registros..."
 ],
 "Loading...": [
  null,
  "Cargando..."
 ],
 "Local": [
  null,
  "Local"
 ],
 "Local images": [
  null,
  "Imágenes locales"
 ],
 "Logs": [
  null,
  "Registros"
 ],
 "MAC address": [
  null,
  "Dirección MAC"
 ],
 "MB": [
  null,
  "MB"
 ],
 "Maximum retries": [
  null,
  "Número máximo de reintentos"
 ],
 "Memory": [
  null,
  "Memoria"
 ],
 "Memory limit": [
  null,
  "Límite de memoria"
 ],
 "Memory unit": [
  null,
  "Unidad de medida de memoria"
 ],
 "Mode": [
  null,
  "Modo"
 ],
 "Multiple tags exist for this image. Select the tagged images to delete.": [
  null,
  "Existen múltiples etiquetas para esta imagen. Seleccione las imágenes etiquetadas a eliminar."
 ],
 "Must be a valid IP address": [
  null,
  "Debe ser una dirección IP válida"
 ],
 "Name": [
  null,
  "Nombre"
 ],
 "Name already in use": [
  null,
  "Nombre ya en uso"
 ],
 "New container name": [
  null,
  "Nuevo nombre del contenedor"
 ],
 "New image name": [
  null,
  "Nombre de la nueva imagen"
 ],
 "No": [
  null,
  "No"
 ],
 "No action": [
  null,
  "Ninguna acción"
 ],
 "No containers": [
  null,
  "No hay contenedores"
 ],
 "No containers are using this image": [
  null,
  "No hay contenedores que utilicen esta imagen"
 ],
 "No containers in this pod": [
  null,
  "No hay contenedores en este pod"
 ],
 "No containers that match the current filter": [
  null,
  "No hay contenedores relacionados con los criterios de búsqueda"
 ],
 "No environment variables specified": [
  null,
  "No se han especificado variables de entorno"
 ],
 "No images": [
  null,
  "No hay imágenes"
 ],
 "No images found": [
  null,
  "No se han encontrado imágenes"
 ],
 "No images that match the current filter": [
  null,
  "No hay imágenes relacionadas con el criterio de búsqueda"
 ],
 "No label": [
  null,
  "Sin etiqueta"
 ],
 "No ports exposed": [
  null,
  "No hay puertos expuestos"
 ],
 "No results for $0": [
  null,
  "No hay resultados para $0"
 ],
 "No running containers": [
  null,
  "No hay contenedores ejecutándose"
 ],
 "No volumes specified": [
  null,
  "No se han especificado volúmenes"
 ],
 "On failure": [
  null,
  "En caso de fallo"
 ],
 "Only running": [
  null,
  "Sólo los que se están ejecutando"
 ],
 "Options": [
  null,
  "Opciones"
 ],
 "Owner": [
  null,
  "Propietario"
 ],
 "Owner help": [
  null,
  "Ayuda sobre el propietario"
 ],
 "Passed health run": [
  null,
  "Comprobación de estado de salud superada"
 ],
 "Paste one or more lines of key=value pairs into any field for bulk import": [
  null,
  "Pegue una o más líneas de pares clave=valor en cualquier campo para importar en masa"
 ],
 "Pause": [
  null,
  "Pausar"
 ],
 "Pause container when creating image": [
  null,
  "Pausar el contenedor cuando se cree la imagen"
 ],
 "Paused": [
  null,
  "Pausado"
 ],
 "Pod failed to be created": [
  null,
  "Fallo al crear el pod"
 ],
 "Pod name": [
  null,
  "Nombre del pod"
 ],
 "Podman service failed": [
  null,
  "El servicio Podman falló"
 ],
 "Port mapping": [
  null,
  "Mapeo de puertos"
 ],
 "Ports": [
  null,
  "Puertos"
 ],
 "Ports under 1024 can be mapped": [
  null,
  "Se pueden mapear puertos inferiores a 1024"
 ],
 "Private": [
  null,
  "Privado"
 ],
 "Protocol": [
  null,
  "Protocolo"
 ],
 "Prune": [
  null,
  "Eliminar"
 ],
 "Prune unused containers": [
  null,
  "Eliminar contenedores no utilizados"
 ],
 "Prune unused images": [
  null,
  "Eliminar imágenes no utilizadas"
 ],
 "Pruning containers": [
  null,
  "Eliminando contenedores"
 ],
 "Pruning images": [
  null,
  "Eliminando imágenes no utilizadas"
 ],
 "Pull": [
  null,
  "Empujar"
 ],
 "Pull all images": [
  null,
  "Sacar todas las imágenes"
 ],
 "Pull latest image": [
  null,
  "Obtener la última imagen"
 ],
 "Pulling": [
  null,
  "Obteniendo"
 ],
 "Read-only access": [
  null,
  "Acceso de sólo lectura"
 ],
 "Read-write access": [
  null,
  "Acceso de lectura y escritura"
 ],
 "Remove item": [
  null,
  "Eliminar elemento"
 ],
 "Removes selected non-running containers": [
  null,
  "Elimina los contenedores seleccionados que no se están ejecutando"
 ],
 "Removing": [
  null,
  "Eliminándose"
 ],
 "Rename": [
  null,
  "Renombrar"
 ],
 "Rename container $0": [
  null,
  "Renombrar el contenedor $0"
 ],
 "Resource limits can be set": [
  null,
  "Se pueden establecer límites sobre los recursos"
 ],
 "Restart": [
  null,
  "Reiniciar"
 ],
 "Restart policy": [
  null,
  "Política de reinicio"
 ],
 "Restart policy help": [
  null,
  "Ayuda sobre la política de reinicio"
 ],
 "Restart policy to follow when containers exit.": [
  null,
  "Política de reinicio a seguir cuando se cierren contenedores."
 ],
 "Restart policy to follow when containers exit. Using linger for auto-starting containers may not work in some circumstances, such as when ecryptfs, systemd-homed, NFS, or 2FA are used on a user account.": [
  null,
  "Política de reinicio a seguir cuando los contenedores finalicen. Utilizar linger para iniciar contenedores automáticamente puede no funcionar bajo ciertas circunstancias, como cuando se emplean ecryptfs, systemd-homed, NFS o 2FA en una cuenta de usuario."
 ],
 "Restore": [
  null,
  "Restaurar"
 ],
 "Restore container $0": [
  null,
  "Restaurar el contenedor $0"
 ],
 "Restore with established TCP connections": [
  null,
  "Restaurar con las conexiones TCP establecidas"
 ],
 "Restricted by user account permissions": [
  null,
  "Restringido por los permisos de la cuenta de usuario"
 ],
 "Resume": [
  null,
  "Reanudar"
 ],
 "Retries": [
  null,
  "Número de reintentos"
 ],
 "Retry another term.": [
  null,
  "Pruebe con otro término."
 ],
 "Run health check": [
  null,
  "Ejecutar comprobación de estado de salud"
 ],
 "Running": [
  null,
  "Ejecutándose"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Search by name or description": [
  null,
  "Buscar por nombre o descripción"
 ],
 "Search by registry": [
  null,
  "Buscar por registro"
 ],
 "Search for": [
  null,
  "Buscar"
 ],
 "Search for an image": [
  null,
  "Buscar una imagen"
 ],
 "Search string or container location": [
  null,
  "Buscar cadena o ubicación de contenedor"
 ],
 "Searching...": [
  null,
  "Buscando…"
 ],
 "Searching: $0": [
  null,
  "Buscando: $0"
 ],
 "Shared": [
  null,
  "Compartido"
 ],
 "Show": [
  null,
  "Mostrar"
 ],
 "Show images": [
  null,
  "Mostrar imágenes"
 ],
 "Show intermediate images": [
  null,
  "Mostrar imágenes intermedias"
 ],
 "Show less": [
  null,
  "Mostrar menos"
 ],
 "Show more": [
  null,
  "Mostrar más"
 ],
 "Size": [
  null,
  "Tamaño"
 ],
 "Start": [
  null,
  "Iniciar"
 ],
 "Start period": [
  null,
  "Periodo de arranque"
 ],
 "Start typing to look for images.": [
  null,
  "Comience a escribir para buscar imágenes."
 ],
 "Started at": [
  null,
  "Comenzó"
 ],
 "State": [
  null,
  "Estado"
 ],
 "Status": [
  null,
  "Estado"
 ],
 "Stop": [
  null,
  "Parar"
 ],
 "Stopped": [
  null,
  "Detenido"
 ],
 "Support preserving established TCP connections": [
  null,
  "Habilitar la preservación de las conexiones TCP establecidas"
 ],
 "System": [
  null,
  "Sistema"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "Tag": [
  null,
  "Etiqueta"
 ],
 "Tags": [
  null,
  "Etiquetas"
 ],
 "The initialization time needed for a container to bootstrap.": [
  null,
  "El tiempo de inicialización necesario para que un contenedor arranque."
 ],
 "The maximum time allowed to complete the health check before an interval is considered failed.": [
  null,
  "El máximo tiempo permitido para completar una comprobación de estado de salud antes de que se considere fallada."
 ],
 "The number of retries allowed before a healthcheck is considered to be unhealthy.": [
  null,
  "El máximo número de reintentos permitidos antes de que se considere un mal estado de salud."
 ],
 "Timeout": [
  null,
  "Tiempo de espera"
 ],
 "Troubleshoot": [
  null,
  "Solución de errores"
 ],
 "Type to filter…": [
  null,
  "Escriba para establecer un criterio de búsqueda…"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Unable to load image history": [
  null,
  "No se pudo cargar el historial de imágenes"
 ],
 "Unhealthy": [
  null,
  "Mal estado de salud"
 ],
 "Up since:": [
  null,
  "Levantado desde:"
 ],
 "Use legacy Docker format": [
  null,
  "Usar el formato heredado Docker"
 ],
 "Used by": [
  null,
  "Usado por"
 ],
 "User": [
  null,
  "Usuario"
 ],
 "User:": [
  null,
  "Usuario:"
 ],
 "Value": [
  null,
  "Valor"
 ],
 "View $0": [
  null,
  "Ver $0"
 ],
 "Volumes": [
  null,
  "Volúmenes"
 ],
 "When unhealthy": [
  null,
  "En caso de mal estado de salud"
 ],
 "With terminal": [
  null,
  "Con terminal"
 ],
 "Writable": [
  null,
  "Puede escribirse"
 ],
 "downloading": [
  null,
  "descargando"
 ],
 "host[:port]/[user]/container[:tag]": [
  null,
  "host[:puerto]/[usuario]/contenedor[:etiqueta]"
 ],
 "in": [
  null,
  "en"
 ],
 "intermediate": [
  null,
  "intermedia"
 ],
 "intermediate image": [
  null,
  "imagen intermedia"
 ],
 "n/a": [
  null,
  "n/d"
 ],
 "not available": [
  null,
  "no disponible"
 ],
 "pod": [
  null,
  "pod"
 ],
 "ports": [
  null,
  "puertos"
 ],
 "seconds": [
  null,
  "segundos"
 ],
 "service": [
  null,
  "servicio"
 ],
 "system": [
  null,
  "sistema"
 ],
 "systemd service": [
  null,
  "servicio systemd"
 ],
 "unused": [
  null,
  "sin utilizar"
 ],
 "user": [
  null,
  "usuario"
 ],
 "user:": [
  null,
  "usuario:"
 ],
 "volumes": [
  null,
  "volúmenes"
 ]
});
