cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "sv",
  "language-direction": "ltr"
 },
 "$0 container": [
  null,
  "$0 behållare",
  "$0 behållare"
 ],
 "$0 image total, $1": [
  null,
  "$0 avbild, total, $1",
  "$0 avbilder, totalt, $1"
 ],
 "$0 second": [
  null,
  "$0 sekund",
  "$0 sekunder"
 ],
 "$0 unused image, $1": [
  null,
  "$0 oanvänd avbild, $1",
  "$0 oanvända avbilder, $1"
 ],
 "$0% of $1 limit": [
  null,
  "$0 % av gränsen $1"
 ],
 "1 to 65535": [
  null,
  "1 till 65535"
 ],
 "Action to take once the container transitions to an unhealthy state.": [
  null,
  "Åtgärd att ta när behållaren övergår till ett ohälsosamt tillstånd."
 ],
 "Actions": [
  null,
  "Åtgärder"
 ],
 "Add port mapping": [
  null,
  "Lägg till portmappning"
 ],
 "Add variable": [
  null,
  "Lägg till variabel"
 ],
 "Add volume": [
  null,
  "Lägg till volym"
 ],
 "All": [
  null,
  "Alla"
 ],
 "All registries": [
  null,
  "Alla register"
 ],
 "Always": [
  null,
  "Alltid"
 ],
 "An error occurred": [
  null,
  "Ett fel uppstod"
 ],
 "Author": [
  null,
  "Upphovsman"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "CPU Shares help": [
  null,
  "CPU-andelar hjälp"
 ],
 "CPU shares": [
  null,
  "CPU-andelar"
 ],
 "CPU shares determine the priority of running containers. Default priority is 1024. A higher number prioritizes this container. A lower number decreases priority.": [
  null,
  "CPU-andelar avgör prioriteten på körande behållare. Standardprioriteten är 1024. Ett högre tal prioriterar denna behållare. Ett lägre tal sänker prioriteten."
 ],
 "Cancel": [
  null,
  "Avbryt"
 ],
 "Checking health": [
  null,
  "Kontrollerar hälsa"
 ],
 "Checkpoint": [
  null,
  "Checkpunkt"
 ],
 "Checkpoint and restore support": [
  null,
  "checkpunkt och återställnings stöd"
 ],
 "Checkpoint container $0": [
  null,
  "Ta checkpunkt på behållare $0"
 ],
 "Click to see published ports": [
  null,
  "Klicka för att se publicerade portar"
 ],
 "Click to see volumes": [
  null,
  "Klicka för att se volymer"
 ],
 "Command": [
  null,
  "Kommando"
 ],
 "Comments": [
  null,
  "Kommentarer"
 ],
 "Commit": [
  null,
  "Fastställ"
 ],
 "Commit container": [
  null,
  "Commit behållare"
 ],
 "Configured": [
  null,
  "Konfigurerad"
 ],
 "Console": [
  null,
  "Konsol"
 ],
 "Container": [
  null,
  "Behållare"
 ],
 "Container failed to be created": [
  null,
  "Behållaren misslyckades att skapas"
 ],
 "Container failed to be started": [
  null,
  "Behållaren misslyckades att startas"
 ],
 "Container is not running": [
  null,
  "Behållaren kör inte"
 ],
 "Container name": [
  null,
  "Behållarnamn"
 ],
 "Container name is required.": [
  null,
  "Behållarnamn krävs."
 ],
 "Container path": [
  null,
  "Behållarsökväg"
 ],
 "Container path must not be empty": [
  null,
  "Behållarens sökväg får inte vara tom"
 ],
 "Container port": [
  null,
  "Behållarport"
 ],
 "Container port must not be empty": [
  null,
  "Behållarporten får inte vara tom"
 ],
 "Containers": [
  null,
  "Behållare"
 ],
 "Create": [
  null,
  "Skapa"
 ],
 "Create a new image based on the current state of the $0 container.": [
  null,
  "Skapa en ny avbild baserad på det aktuella läget för $0 behållaren."
 ],
 "Create and run": [
  null,
  "Skapa och kör"
 ],
 "Create container": [
  null,
  "Skapa behållare"
 ],
 "Create container in $0": [
  null,
  "Skapa behållare i $0"
 ],
 "Create container in pod": [
  null,
  "Skapa behållare i kapsel"
 ],
 "Create pod": [
  null,
  "Skapa pod"
 ],
 "Created": [
  null,
  "Skapad"
 ],
 "Created by": [
  null,
  "Skapad av"
 ],
 "Decrease CPU shares": [
  null,
  "Minska CPU-andelar"
 ],
 "Decrease interval": [
  null,
  "Minska intervallet"
 ],
 "Decrease maximum retries": [
  null,
  "Minska maximalt antal försök igen"
 ],
 "Decrease memory": [
  null,
  "Minska minne"
 ],
 "Decrease retries": [
  null,
  "Minska återförsök"
 ],
 "Decrease start period": [
  null,
  "Minska startintervallet"
 ],
 "Decrease timeout": [
  null,
  "Minska timeout"
 ],
 "Delete": [
  null,
  "Ta bort"
 ],
 "Delete $0 image?": [
  null,
  "Radera $0 avbild?"
 ],
 "Delete $0?": [
  null,
  "Radera $0?"
 ],
 "Delete image": [
  null,
  "Radera avbild"
 ],
 "Delete pod $0?": [
  null,
  "Radera podd $0?"
 ],
 "Delete tagged images": [
  null,
  "Radera taggade avbilder"
 ],
 "Delete unused images of user $0:": [
  null,
  "Radera oanvända avbilder för användare $0:"
 ],
 "Delete unused system images:": [
  null,
  "Ta bort oanvända systemavbilder:"
 ],
 "Deleting a container will erase all data in it.": [
  null,
  "När en behållare raderas försvinner även all data i den."
 ],
 "Deleting a running container will erase all data in it.": [
  null,
  "När en behållare som körs raderas försvinner även all data i den."
 ],
 "Deleting this pod will remove the following containers:": [
  null,
  "Att ta bort denna kapsel kommer ta bort följande behållare:"
 ],
 "Details": [
  null,
  "Detaljer"
 ],
 "Disk space": [
  null,
  "Disk utrymme"
 ],
 "Docker format is useful when sharing the image with Docker or Moby Engine": [
  null,
  "Docker-format är användbart när du delar avbilden med Docker eller Moby Engine"
 ],
 "Download": [
  null,
  "Ladda ner"
 ],
 "Download new image": [
  null,
  "Ladda ner ny avbild"
 ],
 "Empty pod $0 will be permanently removed.": [
  null,
  "Tom podd $0 kommer att tas bort permanent."
 ],
 "Entrypoint": [
  null,
  "Ingångspunkt"
 ],
 "Environment variables": [
  null,
  "Miljövariabler"
 ],
 "Error": [
  null,
  "Fel"
 ],
 "Error message": [
  null,
  "Felmeddelande"
 ],
 "Error occurred while connecting console": [
  null,
  "Ett fel uppstod vid anslutning till konsolen"
 ],
 "Example, Your Name <yourname@example.com>": [
  null,
  "Exempel, Ditt Namn <dittnamn@exempel.com>"
 ],
 "Example: $0": [
  null,
  "Exempel: $0"
 ],
 "Exited": [
  null,
  "Avslutats"
 ],
 "Failed health run": [
  null,
  "Misslyckad hälsokörning"
 ],
 "Failed to checkpoint container $0": [
  null,
  "Kunde inte ta checkpunkt av behållare $0"
 ],
 "Failed to clean up container": [
  null,
  "Misslyckades med att rensa upp behållaren"
 ],
 "Failed to commit container $0": [
  null,
  "Kunde inte fastställa behållaren $0"
 ],
 "Failed to create container $0": [
  null,
  "Misslyckades att skapa behållaren $0"
 ],
 "Failed to download image $0:$1": [
  null,
  "Kunde inte ladda ner avbild $0:$1"
 ],
 "Failed to force remove container $0": [
  null,
  "Misslyckades att tvingande ta bort behållare $0"
 ],
 "Failed to force remove image $0": [
  null,
  "Misslyckades att tvingande ta bort avbilden $0"
 ],
 "Failed to force restart pod $0": [
  null,
  "Misslyckades med tvingad omstart av kapseln $0"
 ],
 "Failed to force stop pod $0": [
  null,
  "Misslyckades att tvinga stopp av kapsel $0"
 ],
 "Failed to pause container $0": [
  null,
  "Misslyckades med att pausa behållaren $0"
 ],
 "Failed to pause pod $0": [
  null,
  "Misslyckades att pausa kapseln $0"
 ],
 "Failed to prune unused containers": [
  null,
  "Misslyckades att rensa oanvända behållare"
 ],
 "Failed to prune unused images": [
  null,
  "Misslyckades att rensa oanvända avbilder"
 ],
 "Failed to pull image $0": [
  null,
  "Misslyckades med att hämta avbilden $0"
 ],
 "Failed to remove container $0": [
  null,
  "Misslyckades att ta bort behållaren $0"
 ],
 "Failed to remove image $0": [
  null,
  "Misslyckades att ta bort avbilden $0"
 ],
 "Failed to rename container $0": [
  null,
  "Misslyckades att byta namn på behållaren $0"
 ],
 "Failed to restart container $0": [
  null,
  "Misslyckades att starta om behållaren $0"
 ],
 "Failed to restart pod $0": [
  null,
  "Misslyckades att starta om kapseln $0"
 ],
 "Failed to restore container $0": [
  null,
  "Misslyckades att återställa behållaren $0"
 ],
 "Failed to resume container $0": [
  null,
  "Misslyckades att återuppta behållaren $0"
 ],
 "Failed to resume pod $0": [
  null,
  "Misslyckades att återuppta kapseln $0"
 ],
 "Failed to run container $0": [
  null,
  "Misslyckades att köra behållaren $0"
 ],
 "Failed to run health check on container $0": [
  null,
  "Misslyckades att köra hälsokontrollen på behållare $0"
 ],
 "Failed to search for images.": [
  null,
  "Misslyckades att söka efter avbilder."
 ],
 "Failed to search for images: $0": [
  null,
  "Misslyckades att söka efter avbilder: $0"
 ],
 "Failed to search for new images": [
  null,
  "Misslyckades att söka efter nya avbilder"
 ],
 "Failed to start container $0": [
  null,
  "Misslyckades att starta behållaren $0"
 ],
 "Failed to start pod $0": [
  null,
  "Misslyckades att starta kapseln $0"
 ],
 "Failed to stop container $0": [
  null,
  "Misslyckades att stoppa behållaren $0"
 ],
 "Failed to stop pod $0": [
  null,
  "Misslyckades att stoppa kapseln $0"
 ],
 "Failing streak": [
  null,
  "Misslyckanden i följd"
 ],
 "Force commit": [
  null,
  "Framtvinga commit"
 ],
 "Force delete": [
  null,
  "Framtvinga borttagande"
 ],
 "Force delete pod $0?": [
  null,
  "Framtvinga borttagande av podd $0?"
 ],
 "Force restart": [
  null,
  "Framtvinga omstart"
 ],
 "Force stop": [
  null,
  "Framtvinga stopp"
 ],
 "GB": [
  null,
  "GB"
 ],
 "Gateway": [
  null,
  "Gateway"
 ],
 "Health check": [
  null,
  "Hälsokontroll"
 ],
 "Health check interval help": [
  null,
  "Hälsokontrollens intervallhjälp"
 ],
 "Health check retries help": [
  null,
  "Hälsokontrollens återförsökshjälp"
 ],
 "Health check start period help": [
  null,
  "Hälsokontrollens startintervallshjälp"
 ],
 "Health check timeout help": [
  null,
  "Hälsokontrollens tidsgränshjälp"
 ],
 "Health failure check action help": [
  null,
  "Hälsokontrollens checkåtgärd hjälp"
 ],
 "Healthy": [
  null,
  "Hälsosam"
 ],
 "Hide images": [
  null,
  "Dölj avbilder"
 ],
 "Hide intermediate images": [
  null,
  "Dölj mellanliggande avbilder"
 ],
 "History": [
  null,
  "Historik"
 ],
 "Host path": [
  null,
  "Värdsökväg"
 ],
 "Host port": [
  null,
  "Värdport"
 ],
 "Host port help": [
  null,
  "Värdport hjälp"
 ],
 "ID": [
  null,
  "ID"
 ],
 "IP address": [
  null,
  "IP-adress"
 ],
 "IP address help": [
  null,
  "IP-adress hjälp"
 ],
 "Ideal for development": [
  null,
  "Ideal för utveckling"
 ],
 "Ideal for running services": [
  null,
  "Ideal för att köra tjänster"
 ],
 "If host IP is set to 0.0.0.0 or not set at all, the port will be bound on all IPs on the host.": [
  null,
  "Om värd-IP är inställd på 0.0.0.0 eller inte alls, kommer porten att bindas till alla IP-adresser på värden."
 ],
 "If the host port is not set the container port will be randomly assigned a port on the host.": [
  null,
  "Om värdporten inte är inställd kommer behållareporten att slumpmässigt tilldelas en port på värden."
 ],
 "Ignore IP address if set statically": [
  null,
  "Ignorera IP-adressen om den är statiskt satt"
 ],
 "Ignore MAC address if set statically": [
  null,
  "Ignorera MAC-adressen om den är statiskt satt"
 ],
 "Image": [
  null,
  "Avbild"
 ],
 "Image name is not unique": [
  null,
  "Avbildsnamn är inte unikt"
 ],
 "Image name is required": [
  null,
  "Avbildsnamn krävs"
 ],
 "Image selection help": [
  null,
  "Avbildsval hjälp"
 ],
 "Images": [
  null,
  "Avbilder"
 ],
 "Increase CPU shares": [
  null,
  "Öka CPU-andelar"
 ],
 "Increase interval": [
  null,
  "Öka intervallet"
 ],
 "Increase maximum retries": [
  null,
  "Öka maximalt antal försök igen"
 ],
 "Increase memory": [
  null,
  "Öka minne"
 ],
 "Increase retries": [
  null,
  "Öka återförsöken"
 ],
 "Increase start period": [
  null,
  "Öka startintervallet"
 ],
 "Increase timeout": [
  null,
  "Öka timeout"
 ],
 "Integration": [
  null,
  "Integration"
 ],
 "Interval": [
  null,
  "Intervall"
 ],
 "Interval how often health check is run.": [
  null,
  "Intervallet hur ofta hälsokontroller körs."
 ],
 "Invalid characters. Name can only contain letters, numbers, and certain punctuation (_ . -).": [
  null,
  "Ogiltiga tecken. Namn kan bara innehålla bokstäver, siffror och vissa skiljetecken (_ . -)."
 ],
 "KB": [
  null,
  "KB"
 ],
 "Keep all temporary checkpoint files": [
  null,
  "Behåll alla tillfälliga checkpunktsfiler"
 ],
 "Key": [
  null,
  "Nyckel"
 ],
 "Key contains invalid characters": [
  null,
  "Nyckel innehåller ogiltiga tecken"
 ],
 "Key must not be empty": [
  null,
  "Nyckel får inte vara tom"
 ],
 "Key must not begin with a digit": [
  null,
  "Nyckel får inte börja med en siffra"
 ],
 "Last 5 runs": [
  null,
  "Senaste 5 körningarna"
 ],
 "Latest checkpoint": [
  null,
  "Senaste checkpunkt"
 ],
 "Leave running after writing checkpoint to disk": [
  null,
  "Låt fortsätta köra efter att skriva checkpunkt till disk"
 ],
 "Loading details...": [
  null,
  "Läser in detaljer …"
 ],
 "Loading logs...": [
  null,
  "Läser in loggar …"
 ],
 "Loading...": [
  null,
  "Läser in …"
 ],
 "Local": [
  null,
  "Lokal"
 ],
 "Local images": [
  null,
  "Lokala avbilder"
 ],
 "Logs": [
  null,
  "Loggar"
 ],
 "MAC address": [
  null,
  "MAC-adress"
 ],
 "MB": [
  null,
  "MB"
 ],
 "Maximum retries": [
  null,
  "Maximalt antal försök igen"
 ],
 "Memory": [
  null,
  "Minne"
 ],
 "Memory limit": [
  null,
  "Minnesgräns"
 ],
 "Memory unit": [
  null,
  "Minnesenhet"
 ],
 "Mode": [
  null,
  "Läge"
 ],
 "Multiple tags exist for this image. Select the tagged images to delete.": [
  null,
  "Flera taggar finns för denna avbild. Välj vilka taggade avbilder som skall raderas."
 ],
 "Must be a valid IP address": [
  null,
  "Måste vara en giltig IP adress"
 ],
 "Name": [
  null,
  "Namn"
 ],
 "Name already in use": [
  null,
  "Namn används redan"
 ],
 "New container name": [
  null,
  "Nytt behållarnamn"
 ],
 "New image name": [
  null,
  "Nytt Avbildsnamn"
 ],
 "No": [
  null,
  "Nej"
 ],
 "No action": [
  null,
  "Ingen åtgärd"
 ],
 "No containers": [
  null,
  "Inga behållare"
 ],
 "No containers are using this image": [
  null,
  "Inga behållare använder denna avbild"
 ],
 "No containers in this pod": [
  null,
  "Inga behållare i denna kapsel"
 ],
 "No containers that match the current filter": [
  null,
  "Inga behållare som stämmer med det aktuella filtret"
 ],
 "No environment variables specified": [
  null,
  "Inga miljövariabler specificerade"
 ],
 "No images": [
  null,
  "Inga avbilder"
 ],
 "No images found": [
  null,
  "Inga avbilder funna"
 ],
 "No images that match the current filter": [
  null,
  "Inga avbilder som stämmer med det aktuella filtret"
 ],
 "No label": [
  null,
  "Ingen Etikett"
 ],
 "No ports exposed": [
  null,
  "Inga portar exponerade"
 ],
 "No results for $0": [
  null,
  "Inga resultat för $0"
 ],
 "No running containers": [
  null,
  "Inga körande behållare"
 ],
 "No volumes specified": [
  null,
  "Inga volymer specificerade"
 ],
 "On failure": [
  null,
  "Vid misslyckande"
 ],
 "Only running": [
  null,
  "Endast körande"
 ],
 "Options": [
  null,
  "Alternativ"
 ],
 "Owner": [
  null,
  "Ägare"
 ],
 "Owner help": [
  null,
  "Ägare hjälp"
 ],
 "Passed health run": [
  null,
  "Lyckad hälsokontrollskörning"
 ],
 "Paste one or more lines of key=value pairs into any field for bulk import": [
  null,
  "Klistra in en eller flera rader med nyckel=värdepar i valfritt fält för massimport"
 ],
 "Pause": [
  null,
  "Pausa"
 ],
 "Pause container when creating image": [
  null,
  "Pausa behållaren när du skapar en avbild"
 ],
 "Paused": [
  null,
  "Pausad"
 ],
 "Pod failed to be created": [
  null,
  "Podden kunde inte skapas"
 ],
 "Pod name": [
  null,
  "Pod namn"
 ],
 "Podman service failed": [
  null,
  "Podman-tjänsten misslyckades"
 ],
 "Port mapping": [
  null,
  "Portkartering"
 ],
 "Ports": [
  null,
  "Portar"
 ],
 "Ports under 1024 can be mapped": [
  null,
  "Portar under 1024 kan inte mappas"
 ],
 "Private": [
  null,
  "Privat"
 ],
 "Protocol": [
  null,
  "Protokoll"
 ],
 "Prune": [
  null,
  "Rensa"
 ],
 "Prune unused containers": [
  null,
  "Rensa oanvända behållare"
 ],
 "Prune unused images": [
  null,
  "Rensa oanvända avbilder"
 ],
 "Pruning containers": [
  null,
  "Rensar behållare"
 ],
 "Pruning images": [
  null,
  "Rensar avbilder"
 ],
 "Pull": [
  null,
  "Hämta"
 ],
 "Pull all images": [
  null,
  "Hämta alla avbilder"
 ],
 "Pull latest image": [
  null,
  "Hämta senaste avbild"
 ],
 "Pulling": [
  null,
  "Hämtar"
 ],
 "Read-only access": [
  null,
  "Skrivskyddad åtkomst"
 ],
 "Read-write access": [
  null,
  "Läs och skrivåtkomst"
 ],
 "Remove item": [
  null,
  "Ta bort post"
 ],
 "Removes selected non-running containers": [
  null,
  "Tar bort valda icke-körande behållare"
 ],
 "Removing": [
  null,
  "Tar bort"
 ],
 "Rename": [
  null,
  "Byt namn"
 ],
 "Rename container $0": [
  null,
  "Byt namn på behållaren $0"
 ],
 "Resource limits can be set": [
  null,
  "Resursgränser kan ställas in"
 ],
 "Restart": [
  null,
  "Starta om"
 ],
 "Restart policy": [
  null,
  "Starta om policy"
 ],
 "Restart policy help": [
  null,
  "Starta om policy hjälp"
 ],
 "Restart policy to follow when containers exit.": [
  null,
  "Starta om policy att följa när behållare avslutas."
 ],
 "Restart policy to follow when containers exit. Using linger for auto-starting containers may not work in some circumstances, such as when ecryptfs, systemd-homed, NFS, or 2FA are used on a user account.": [
  null,
  "Starta om policyn till att följa när behållare avslutar. Att använda fortlevande (linger) för automatstartande behållare fungerar kanske inte i vissa situationer, som när ecryptfs, systemd-homed, NFS eller 2FA används för ett användarkonto."
 ],
 "Restore": [
  null,
  "Återställ"
 ],
 "Restore container $0": [
  null,
  "Återställ behållaren $0"
 ],
 "Restore with established TCP connections": [
  null,
  "Återställ med etablerade TCP-förbindelser"
 ],
 "Restricted by user account permissions": [
  null,
  "Begränsat av användarkontobehörigheter"
 ],
 "Resume": [
  null,
  "Återuppta"
 ],
 "Retries": [
  null,
  "Omförsök"
 ],
 "Retry another term.": [
  null,
  "Försök igen med en annan term."
 ],
 "Run health check": [
  null,
  "Kör hälsokontroll"
 ],
 "Running": [
  null,
  "Kör"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Search by name or description": [
  null,
  "Sök efter namn eller beskrivning"
 ],
 "Search by registry": [
  null,
  "Sök efter register"
 ],
 "Search for": [
  null,
  "Sök efter"
 ],
 "Search for an image": [
  null,
  "Sök efter en avbild"
 ],
 "Search string or container location": [
  null,
  "Söksträng eller behållareplats"
 ],
 "Searching...": [
  null,
  "Söker …"
 ],
 "Searching: $0": [
  null,
  "Söker: $0"
 ],
 "Shared": [
  null,
  "Delad"
 ],
 "Show": [
  null,
  "Visa"
 ],
 "Show images": [
  null,
  "Visa avbilder"
 ],
 "Show intermediate images": [
  null,
  "Visa mellanliggande avbilder"
 ],
 "Show less": [
  null,
  "Visa mindre"
 ],
 "Show more": [
  null,
  "Visa mer"
 ],
 "Size": [
  null,
  "Storlek"
 ],
 "Start": [
  null,
  "Starta"
 ],
 "Start period": [
  null,
  "Startperiod"
 ],
 "Start typing to look for images.": [
  null,
  "Börja skriva för att leta efter avbilder."
 ],
 "Started at": [
  null,
  "Startad vid"
 ],
 "State": [
  null,
  "Tillstånd"
 ],
 "Status": [
  null,
  "Status"
 ],
 "Stop": [
  null,
  "Stoppa"
 ],
 "Stopped": [
  null,
  "Stoppad"
 ],
 "Support preserving established TCP connections": [
  null,
  "Stöd att bevara etablerade TCP-förbindelser"
 ],
 "System": [
  null,
  "System"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "Tag": [
  null,
  "Tagg"
 ],
 "Tags": [
  null,
  "Taggar"
 ],
 "The initialization time needed for a container to bootstrap.": [
  null,
  "Initieringstiden sombehövs för att en behållare skall komma igång."
 ],
 "The maximum time allowed to complete the health check before an interval is considered failed.": [
  null,
  "Den maximala tiden som tillåts för att klara av hälsokontrollen före ett intervall betraktas som misslyckat."
 ],
 "The number of retries allowed before a healthcheck is considered to be unhealthy.": [
  null,
  "Antalet återförsök som tillåts före en hälsokontroll betraktas som ohälsosam."
 ],
 "Timeout": [
  null,
  "Tidsgräns"
 ],
 "Troubleshoot": [
  null,
  "Felsök"
 ],
 "Type to filter…": [
  null,
  "Skriv för att filtrera …"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Unable to load image history": [
  null,
  "Kunde inte ladda avbildshistoriken"
 ],
 "Unhealthy": [
  null,
  "Ohälsosam"
 ],
 "Up since:": [
  null,
  "Uppe sedan:"
 ],
 "Use legacy Docker format": [
  null,
  "Använd gammalt Docker-format"
 ],
 "Used by": [
  null,
  "Används av"
 ],
 "User": [
  null,
  "Användare"
 ],
 "User:": [
  null,
  "Användare:"
 ],
 "Value": [
  null,
  "Värde"
 ],
 "View $0": [
  null,
  "Visa $0"
 ],
 "View $0 logs": [
  null,
  "Visa $0 loggar"
 ],
 "Volumes": [
  null,
  "Volymer"
 ],
 "When unhealthy": [
  null,
  "När ohälsosam"
 ],
 "With terminal": [
  null,
  "Med terminal"
 ],
 "Writable": [
  null,
  "Skrivbar"
 ],
 "downloading": [
  null,
  "hämtar"
 ],
 "host[:port]/[user]/container[:tag]": [
  null,
  "värd[:port]/[användare]/behållare[:tagg]"
 ],
 "in": [
  null,
  "i"
 ],
 "intermediate": [
  null,
  "mellanliggande"
 ],
 "intermediate image": [
  null,
  "mellanliggande avbild"
 ],
 "n/a": [
  null,
  "ej tillämpligt"
 ],
 "not available": [
  null,
  "inte tillgängligt"
 ],
 "pod": [
  null,
  "pod"
 ],
 "ports": [
  null,
  "portar"
 ],
 "seconds": [
  null,
  "sekunder"
 ],
 "service": [
  null,
  "tjänst"
 ],
 "system": [
  null,
  "system"
 ],
 "systemd service": [
  null,
  "systemd tjänst"
 ],
 "unused": [
  null,
  "oanvänd"
 ],
 "user": [
  null,
  "användare"
 ],
 "user:": [
  null,
  "användare:"
 ],
 "volumes": [
  null,
  "volymer"
 ]
});
