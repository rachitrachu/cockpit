cockpit.locale({
 "": {
  "plural-forms": (n) => n > 1,
  "language": "fr",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 can not be made larger": [
  null,
  "$0 ne peuvent pas être agrandis"
 ],
 "$0 can not be made smaller": [
  null,
  "$0 impossible à réduire"
 ],
 "$0 can not be resized": [
  null,
  "$0 ne peut pas être redimensionné"
 ],
 "$0 can not be resized here": [
  null,
  "$0 ne peut pas être redimensionné ici"
 ],
 "$0 chunk size": [
  null,
  "blocs de taille $0"
 ],
 "$0 data + $1 overhead used of $2 ($3)": [
  null,
  "$0 données + $1 surcharge utilisée de $2 ( $3 )"
 ],
 "$0 day": [
  null,
  "$0 jour",
  "$0 jours"
 ],
 "$0 disk is missing": [
  null,
  "$0 disque est manquant",
  "$0 disques sont manquants"
 ],
 "$0 disks": [
  null,
  "$0 disques"
 ],
 "$0 exited with code $1": [
  null,
  "$0 quitté avec le code $1"
 ],
 "$0 failed": [
  null,
  "$0 échoué"
 ],
 "$0 filesystem": [
  null,
  "Système de fichiers $0"
 ],
 "$0 hour": [
  null,
  "$0 heure",
  "$0 heures"
 ],
 "$0 hours": [
  null,
  "$0 heures"
 ],
 "$0 is in use": [
  null,
  "$0 est en cours d’utilisation"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 n’est disponible dans aucun référentiel."
 ],
 "$0 key changed": [
  null,
  "$0 clé modifiée"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 killed avec un signal $1"
 ],
 "$0 minute": [
  null,
  "$0 minute",
  "$0 minutes"
 ],
 "$0 month": [
  null,
  "$0 mois",
  "$0 mois"
 ],
 "$0 partitions": [
  null,
  "Partitions $0"
 ],
 "$0 slot remains": [
  null,
  "$0 il reste un créneau",
  "$0 logements restants"
 ],
 "$0 synchronized": [
  null,
  "$0 synchronisé"
 ],
 "$0 used of $1 ($2 saved)": [
  null,
  "$0 utilisé de $1 ($2 enregistré)"
 ],
 "$0 used, $1 total": [
  null,
  "$0 utilisés, $1 au total"
 ],
 "$0 week": [
  null,
  "$0 semaine",
  "$0 semaines"
 ],
 "$0 will be installed.": [
  null,
  "$0 sera installé."
 ],
 "$0 year": [
  null,
  "$0 an",
  "$0 ans"
 ],
 "$name (from $host)": [
  null,
  "$name (de $host )"
 ],
 "(Not part of target)": [
  null,
  "(Ne fait pas partie de la cible)"
 ],
 "(no assigned mount point)": [
  null,
  "(aucun point de montage assigné)"
 ],
 "(not mounted)": [
  null,
  "(non monté)"
 ],
 "(recommended)": [
  null,
  "(recommandé)"
 ],
 "1 MiB": [
  null,
  "1 MiB"
 ],
 "1 day": [
  null,
  "1 jour"
 ],
 "1 hour": [
  null,
  "1 heure"
 ],
 "1 minute": [
  null,
  "1 minute"
 ],
 "1 week": [
  null,
  "1 semaine"
 ],
 "128 KiB": [
  null,
  "128 Kio"
 ],
 "16 KiB": [
  null,
  "16 Kio"
 ],
 "2 MiB": [
  null,
  "2 Mio"
 ],
 "20 minutes": [
  null,
  "20 minutes"
 ],
 "32 KiB": [
  null,
  "32 Kio"
 ],
 "4 KiB": [
  null,
  "4 Kio"
 ],
 "40 minutes": [
  null,
  "40 minutes"
 ],
 "5 minutes": [
  null,
  "5 minutes"
 ],
 "512 KiB": [
  null,
  "512 Kio"
 ],
 "6 hours": [
  null,
  "6 heures"
 ],
 "60 minutes": [
  null,
  "60 minutes"
 ],
 "64 KiB": [
  null,
  "64 Kio"
 ],
 "8 KiB": [
  null,
  "8 Kio"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Une version compatible de Cockpit n’est pas installée sur $0."
 ],
 "A fatal error occurred during the self-test operation": [
  null,
  "Une erreur fatale s'est produite durant l'opération d'autotest"
 ],
 "A filesystem with this name exists already in this pool.": [
  null,
  "Un système de fichiers portant ce nom existe déjà dans ce pool."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Une nouvelle clé SSH à $0 sera créée pour $1 sur $2 et elle sera ajoutée au fichier $3 de $4 sur $5."
 ],
 "A pool with this name exists already.": [
  null,
  "Un pool portant ce nom existe déjà."
 ],
 "A volume group with missing physical volumes can not be renamed.": [
  null,
  "Un groupe de volumes avec des volumes physiques manquants ne peut pas être renommé."
 ],
 "Abort test": [
  null,
  "Interrompre le test"
 ],
 "Aborted": [
  null,
  "Interrompu"
 ],
 "Aborted by a Controller Level Reset": [
  null,
  "Interrompu par une réinitialisation au niveau du contrôleur"
 ],
 "Aborted due to a removal of a namespace from the namespace inventory": [
  null,
  "Interrompu par la suppression d'un espace de noms dans l'inventaire d'espaces de noms"
 ],
 "Aborted due to a sanitize operation": [
  null,
  "Interrompu par une opération d'assainissement"
 ],
 "Aborted due to the processing of a Format NVM command": [
  null,
  "Interrompu par le traitement d'une commande Format NVM"
 ],
 "Aborted for unknown reason": [
  null,
  "Interrompu pour une raison inconnue"
 ],
 "Absent": [
  null,
  "Absent"
 ],
 "Acceptable password": [
  null,
  "Mot de passe acceptable"
 ],
 "Action": [
  null,
  "Action"
 ],
 "Actions": [
  null,
  "Actions"
 ],
 "Activate": [
  null,
  "Activer"
 ],
 "Activate before resizing": [
  null,
  "Activer avant de redimensionner"
 ],
 "Activating $target": [
  null,
  "Activation de $target"
 ],
 "Add": [
  null,
  "Ajouter"
 ],
 "Add $0": [
  null,
  "Ajouter $0"
 ],
 "Add Network Bound Disk Encryption": [
  null,
  "Ajouter le chiffrement de disque lié au réseau (NBDE)"
 ],
 "Add Tang keyserver": [
  null,
  "Ajouter clé serveur Tang"
 ],
 "Add a bitmap": [
  null,
  "Ajouter une bitmap"
 ],
 "Add block devices": [
  null,
  "Ajouter des périphériques block"
 ],
 "Add disk": [
  null,
  "Ajouter un disque"
 ],
 "Add disks": [
  null,
  "Ajouter des disques"
 ],
 "Add iSCSI portal": [
  null,
  "Ajouter un portail iSCSI"
 ],
 "Add key": [
  null,
  "Ajouter une clé"
 ],
 "Add keyserver": [
  null,
  "Ajouter un serveur de clés"
 ],
 "Add passphrase": [
  null,
  "Ajouter mot de passe"
 ],
 "Add physical volume": [
  null,
  "Ajouter le volume physique"
 ],
 "Adding \"$0\" to encryption options": [
  null,
  "Ajout de \"$0\" aux options de chiffrement"
 ],
 "Adding \"$0\" to filesystem options": [
  null,
  "Ajout de \"$0\" aux options du système de fichiers"
 ],
 "Adding a keyserver requires unlocking the pool. Please provide the existing pool passphrase.": [
  null,
  "L'ajout d'un serveur de clés nécessite de déverrouiller le pool. Veuillez fournir le mot de passe actuel du pool."
 ],
 "Adding key": [
  null,
  "Ajout d’une clé"
 ],
 "Adding physical volume to $target": [
  null,
  "Ajout d’un volume physique à $target"
 ],
 "Adding rd.neednet=1 to kernel command line": [
  null,
  "Ajout de rd.neednet=1 à la ligne de commande du noyau"
 ],
 "Additional packages:": [
  null,
  "Paquets supplémentaires :"
 ],
 "Address": [
  null,
  "Adresse"
 ],
 "Address cannot be empty": [
  null,
  "L’adresse ne peut pas être vide"
 ],
 "Address is not a valid URL": [
  null,
  "L’adresse ne correspond pas à une URL valide"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Administration avec la console web de Cockpit"
 ],
 "Advanced TCA": [
  null,
  "TCA avancé"
 ],
 "All $0 selected physical volumes are needed for the chosen layout.": [
  null,
  "L'ensemble des $0 volumes physiques sélectionnés sont nécessaires pour le schéma choisi."
 ],
 "All media is in read-only mode": [
  null,
  "Tous les supports sont en mode Lecture seule"
 ],
 "All-in-one": [
  null,
  "Tout en un"
 ],
 "Allocated": [
  null,
  "Alloué"
 ],
 "Allow overprovisioning": [
  null,
  "Autoriser la surallocation"
 ],
 "An additional $0 must be selected": [
  null,
  "Un $0 additionnel doit être sélectionné"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Documentation des rôles Ansible"
 ],
 "Appropriate for critical mounts, such as /var": [
  null,
  "Approprié pour les montages critiques, tels que /var"
 ],
 "Assessment": [
  null,
  "Évaluation"
 ],
 "At boot": [
  null,
  "Au démarrage"
 ],
 "At least $0 disk is needed.": [
  null,
  "Au moins $0 disque est nécessaire.",
  "Au moins $0 disques sont nécessaires."
 ],
 "At least one block device is needed.": [
  null,
  "Au moins un périphérique block est nécessaire."
 ],
 "At least one disk is needed.": [
  null,
  "Au moins un disque est nécessaire."
 ],
 "At least one subvolume needs to be mounted": [
  null,
  "Au moins 1 sous-volume doit être monté"
 ],
 "Attributes failing": [
  null,
  "Attributs en échec"
 ],
 "Authentication": [
  null,
  "Authentification"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Une authentification est nécessaire pour effectuer les tâches privilégiées dans la console web Cockpit"
 ],
 "Authentication required": [
  null,
  "Authentification requise"
 ],
 "Authorize SSH key": [
  null,
  "Autoriser la clé SSH"
 ],
 "Automatically using NTP": [
  null,
  "Utiliser automatiquement NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Utilisation automatique de serveurs NTP supplémentaires"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Utiliser automatiquement des serveurs NTP spécifiques"
 ],
 "Automation script": [
  null,
  "Script d’automatisation"
 ],
 "Available targets on $0": [
  null,
  "Cibles disponibles sur $0"
 ],
 "BIOS boot partition": [
  null,
  "Partition de démarrage BIOS"
 ],
 "Blade": [
  null,
  "Lame"
 ],
 "Blade enclosure": [
  null,
  "Boîtier en lame"
 ],
 "Block device": [
  null,
  "Périphérique block"
 ],
 "Block device for filesystems": [
  null,
  "Périphérique block pour système de fichiers"
 ],
 "Block devices": [
  null,
  "Périphériques block"
 ],
 "Blocked": [
  null,
  "Bloqué"
 ],
 "Boot fails if filesystem does not mount, preventing remote access": [
  null,
  "Le démarrage échoue si le système de fichiers n'est pas monté, ce qui empêche l'accès à distance"
 ],
 "Boot still succeeds when filesystem does not mount": [
  null,
  "Le démarrage réussit toujours lorsque le système de fichiers n'est pas monté"
 ],
 "Bus expansion chassis": [
  null,
  "Châssis d’extension de bus"
 ],
 "Cache": [
  null,
  "Cache"
 ],
 "Cancel": [
  null,
  "Annuler"
 ],
 "Cannot forward login credentials": [
  null,
  "Impossible de transférer les identifiants de connexion"
 ],
 "Cannot schedule event in the past": [
  null,
  "Impossible de planifier un événement dans le passé"
 ],
 "Capacity": [
  null,
  "Capacité"
 ],
 "Category": [
  null,
  "Catégorie"
 ],
 "Change": [
  null,
  "Modifier"
 ],
 "Change iSCSI initiator name": [
  null,
  "Modifier le nom de l’initiateur iSCSI"
 ],
 "Change label": [
  null,
  "Changer l’étiquette"
 ],
 "Change passphrase": [
  null,
  "Modifier la phrase secrète"
 ],
 "Change system time": [
  null,
  "Modifier l’heure du système"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Les changements de clés sont souvent le résultat d’une réinstallation du système d’exploitation. Cependant, un changement inattendu peut indiquer une tentative d’interception de votre connexion par un tiers."
 ],
 "Changing partition types might prevent the system from booting.": [
  null,
  "Modifier les types de partition pourrait empêcher le système de démarrer."
 ],
 "Check that the SHA-256 or SHA-1 hash from the command matches this dialog.": [
  null,
  "Vérifiez que le hash SHA-256 ou SHA-1 de la commande correspond à celui dans cette boîte de dialogue."
 ],
 "Check the key hash with the Tang server.": [
  null,
  "Vérifiez le hash de la clé avec le serveur Tang."
 ],
 "Checking $target": [
  null,
  "Vérification $target"
 ],
 "Checking MDRAID device $target": [
  null,
  "Vérification du périphérique RAID $target"
 ],
 "Checking and repairing MDRAID device $target": [
  null,
  "Vérification et réparation du périphérique MDRAID $target"
 ],
 "Checking filesystem usage": [
  null,
  "Vérification de l'utilisation des systèmes de fichiers"
 ],
 "Checking for $0 package": [
  null,
  "Vérification du paquet $0"
 ],
 "Checking for NBDE support in the initrd": [
  null,
  "Vérification du support NBDE dans initrd"
 ],
 "Checking installed software": [
  null,
  "Vérification des logiciels installés"
 ],
 "Chunk size": [
  null,
  "Taille des blocs"
 ],
 "Cleaning up for $target": [
  null,
  "Nettoyage pour $target"
 ],
 "Clear input value": [
  null,
  "Effacer la valeur saisie"
 ],
 "Cleartext device": [
  null,
  "Périphérique en clair"
 ],
 "Close": [
  null,
  "Fermer"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Configuration du cockpit de NetworkManager et Firewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit n’a pas pu contacter l’hôte indiqué."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit est un gestionnaire de serveur qui facilite l’administration de vos serveurs Linux via un navigateur Web. Sauter entre le terminal et l’outil web n’est pas un problème. Un service démarré via Cockpit peut être arrêté via le terminal. De même, si une erreur se produit dans le terminal, elle s’affiche dans l’interface du journal Cockpit."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit n’est pas compatible avec le logiciel sur le système."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit n’est pas installé"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit n’est pas installé sur le système."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit est parfait pour les nouveaux administrateurs système, leur permettant d’effectuer facilement des tâches simples telles que l’administration du stockage, l’inspection des journaux, le démarrage et l’arrêt des services. Vous pouvez surveiller et administrer plusieurs serveurs en même temps. Il suffit de les ajouter en un seul clic et vos machines s’occuperont de leurs pairs."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Collecte et regroupement des données de diagnostic et d'assistance"
 ],
 "Collect kernel crash dumps": [
  null,
  "Collecter les vidages de mémoire sur incidents du noyau"
 ],
 "Command": [
  null,
  "Commander"
 ],
 "Compact PCI": [
  null,
  "PCI compact"
 ],
 "Compatible with all systems and devices (MBR)": [
  null,
  "Compatible avec tous les systèmes et périphériques (MBR)"
 ],
 "Compatible with modern system and hard disks > 2TB (GPT)": [
  null,
  "Compatible avec les systèmes modernes et les disques durs > 2 To (GPT)"
 ],
 "Completed with a segment that failed and the segment that failed is not known": [
  null,
  "Terminé avec l'échec d'un segment inconnu"
 ],
 "Completed with one or more failed segments": [
  null,
  "Terminé avec l'échec d'un ou plusieurs segments"
 ],
 "Compression": [
  null,
  "Compression"
 ],
 "Confirm": [
  null,
  "Confirmer"
 ],
 "Confirm deletion of $0": [
  null,
  "Confirmer la suppression de $0"
 ],
 "Confirm key password": [
  null,
  "Confirmer le mot de passe de la clé"
 ],
 "Confirm removal with an alternate passphrase": [
  null,
  "Confirmer la suppression avec une phrase secrète alternative"
 ],
 "Confirm stopping of $0": [
  null,
  "Confirmer l'arrêt de $0"
 ],
 "Connection has timed out.": [
  null,
  "La connexion a expiré."
 ],
 "Convertible": [
  null,
  "Convertible"
 ],
 "Copied": [
  null,
  "Copié"
 ],
 "Copy": [
  null,
  "Copier"
 ],
 "Copy to clipboard": [
  null,
  "Copier dans le presse-papier"
 ],
 "Create": [
  null,
  "Créer"
 ],
 "Create $0": [
  null,
  "Créer $0"
 ],
 "Create LVM2 volume group": [
  null,
  "Créer un groupe de volumes LVM2"
 ],
 "Create MDRAID device": [
  null,
  "Créer un périphérique MDRAID"
 ],
 "Create RAID device": [
  null,
  "Créer Périphérique RAID"
 ],
 "Create Stratis pool": [
  null,
  "Créer un pool Stratis"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Créer une nouvelle clé SSH et l’autoriser"
 ],
 "Create a snapshot of filesystem $0": [
  null,
  "Créer un instantané du système de fichiers $0"
 ],
 "Create and mount": [
  null,
  "Créer et monter"
 ],
 "Create and start": [
  null,
  "Créer et démarrer"
 ],
 "Create filesystem": [
  null,
  "Créer un système de fichiers"
 ],
 "Create logical volume": [
  null,
  "Créer un volume logique"
 ],
 "Create new filesystem": [
  null,
  "Créer un nouveau système de fichiers"
 ],
 "Create new logical volume": [
  null,
  "Créer un nouveau volume logique"
 ],
 "Create new task file with this content.": [
  null,
  "Créez un nouveau fichier de tâches avec ce contenu."
 ],
 "Create new thinly provisioned logical volume": [
  null,
  "Créer un nouveau volume logique à allocation fine et dynamique"
 ],
 "Create only": [
  null,
  "Créer uniquement"
 ],
 "Create partition": [
  null,
  "Créer une partition"
 ],
 "Create partition on $0": [
  null,
  "Créer une partition sur $0"
 ],
 "Create partition table": [
  null,
  "Créer une table de partitions"
 ],
 "Create snapshot": [
  null,
  "Créer Instantané"
 ],
 "Create snapshot and mount": [
  null,
  "Créer un instantané et le monter"
 ],
 "Create snapshot only": [
  null,
  "Créer un instantané uniquement"
 ],
 "Create storage device": [
  null,
  "Créer un périphérique de stockage"
 ],
 "Create subvolume": [
  null,
  "Créer un sous-volume"
 ],
 "Create thin volume": [
  null,
  "Créer un volume à allocation fine"
 ],
 "Create volume group": [
  null,
  "Créer un groupe de volumes"
 ],
 "Creating LVM2 volume group $target": [
  null,
  "Création du groupe de volumes LVM2 $target"
 ],
 "Creating MDRAID device $target": [
  null,
  "Création d’un périphérique MDRAID $target"
 ],
 "Creating VDO device": [
  null,
  "Création d’un périphérique VDO"
 ],
 "Creating filesystem on $target": [
  null,
  "Création d’un système de fichiers sur $target"
 ],
 "Creating logical volume $target": [
  null,
  "Création du volume logique $target"
 ],
 "Creating partition $target": [
  null,
  "Création de la partition $target"
 ],
 "Creating snapshot of $target": [
  null,
  "Création d’un instantané de $target"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Inser"
 ],
 "Currently in use": [
  null,
  "Actuellement en cours d’utilisation"
 ],
 "Custom": [
  null,
  "Personnalisé"
 ],
 "Custom mount options": [
  null,
  "Options de montage personnalisées"
 ],
 "Custom type": [
  null,
  "Type personnalisé"
 ],
 "Data": [
  null,
  "Données"
 ],
 "Data used": [
  null,
  "Données utilisées"
 ],
 "Data will be stored as two copies and also in an alternating fashion on the selected physical volumes, to improve both reliability and performance. At least four volumes need to be selected.": [
  null,
  "Les données seront stockées en deux copies et en alternant entre les volumes physiques sélectionnés, pour améliorer la fiabilité et les performances. Au moins quatre volumes doivent être sélectionnés."
 ],
 "Data will be stored as two or more copies on the selected physical volumes, to improve reliability. At least two volumes need to be selected.": [
  null,
  "Les données seront stockées sur les volumes physiques sélectionnés en deux copies ou plus, pour améliorer la fiabilité. Au moins deux volumes doivent être sélectionnés."
 ],
 "Data will be stored on the selected physical volumes in an alternating fashion to improve performance. At least two volumes need to be selected.": [
  null,
  "Les données seront stockées en alternance sur les volumes physiques sélectionnés pour améliorer les performances. Au moins deux volumes doivent être sélectionnés."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. At least three volumes need to be selected.": [
  null,
  "Les données seront stockées sur les volumes physiques sélectionnés de façon à ce que l'un d'entre eux puisse être perdu sans affecter l'intégrité des données. Au moins trois volumes doivent être sélectionnés."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. Data is also stored in an alternating fashion to improve performance. At least three volumes need to be selected.": [
  null,
  "Les données seront stockées sur les volumes physiques sélectionnés de façon à ce que l'un d'entre eux puisse être perdu sans affecter l'intégrité des données. Les données sont également stockées en alternance afin d'améliorer les performances. Au moins trois volumes doivent être sélectionnés."
 ],
 "Data will be stored on the selected physical volumes so that up to two of them can be lost at the same time without affecting the data. Data is also stored in an alternating fashion to improve performance. At least five volumes need to be selected.": [
  null,
  "Les données seront stockées sur les volumes physiques sélectionnés de façon à ce que deux d'entre eux puissent être perdus sans affecter l'intégrité des données. Les données sont également stockées en alternance afin d'améliorer les performances. Au moins cinq volumes doivent être sélectionnés."
 ],
 "Data will be stored on the selected physical volumes without any additional redundancy or performance improvements.": [
  null,
  "Les données seront stockées sur les volumes physiques sélectionnés sans aucune amélioration vis-à-vis de la redondance ou des performances."
 ],
 "Deactivate": [
  null,
  "Désactiver"
 ],
 "Deactivate logical volume $0/$1?": [
  null,
  "Désactiver le volume logique $0/$1 ?"
 ],
 "Deactivating $target": [
  null,
  "Désactivation de $target"
 ],
 "Dedicated parity (RAID 4)": [
  null,
  "Parité dédiée (RAID 4)"
 ],
 "Deduplication": [
  null,
  "Déduplication"
 ],
 "Degraded": [
  null,
  "Dégradé"
 ],
 "Delay": [
  null,
  "Retard"
 ],
 "Delete": [
  null,
  "Supprimer"
 ],
 "Delete filesystem": [
  null,
  "Supprimer le système de fichiers"
 ],
 "Delete group": [
  null,
  "Supprimer le groupe"
 ],
 "Delete pool": [
  null,
  "Supprimer le pool"
 ],
 "Deleting $target": [
  null,
  "Suppression de $target"
 ],
 "Deleting LVM2 volume group $target": [
  null,
  "Suppression du groupe de volumes LVM2 $target"
 ],
 "Deleting a Stratis pool will erase all data it contains.": [
  null,
  "La suppression d’un pool Stratis efface toutes les données qu’il contient."
 ],
 "Deleting a filesystem will delete all data in it.": [
  null,
  "La suppression d’un système de fichiers entraîne la suppression de toutes les données qu’il contient."
 ],
 "Deleting a logical volume will delete all data in it.": [
  null,
  "La suppression d’un volume logique supprimera toutes les données qu’il contient."
 ],
 "Deleting a partition will delete all data in it.": [
  null,
  "La suppression d’une partition supprimera toutes les données qui s’y trouvent."
 ],
 "Deleting erases all data on a MDRAID device.": [
  null,
  "La suppression efface toutes les données d’un périphérique MDRAID."
 ],
 "Deleting erases all data on a VDO device.": [
  null,
  "La suppression efface toutes les données d’un périphérique VDO."
 ],
 "Deleting erases all data on a btrfs volume.": [
  null,
  "La suppression efface toutes les données sur un volume Btrfs."
 ],
 "Deleting erases all data on a volume group.": [
  null,
  "La suppression efface toutes les données d’un groupe de volumes."
 ],
 "Deleting erases all data on this subvolume and all its children.": [
  null,
  "La suppression efface toutes les données sur ce sous-volume et sur tous ses enfants."
 ],
 "Description": [
  null,
  "Description"
 ],
 "Desktop": [
  null,
  "Bureau"
 ],
 "Detachable": [
  null,
  "Détachable"
 ],
 "Device": [
  null,
  "Périphérique"
 ],
 "Device contains unrecognized data": [
  null,
  "L'appareil contient des données non reconnues"
 ],
 "Device file": [
  null,
  "Fichier de périphérique"
 ],
 "Device health (SMART)": [
  null,
  "Santé de l'appareil (SMART)"
 ],
 "Device is read-only": [
  null,
  "Périphérique en lecture seule"
 ],
 "Device number": [
  null,
  "Numéro du périphérique"
 ],
 "Diagnostic reports": [
  null,
  "Rapports de diagnostic"
 ],
 "Did not complete": [
  null,
  "Ne s'est pas terminé"
 ],
 "Disconnect": [
  null,
  "Déconnecter"
 ],
 "Disk is OK": [
  null,
  "Le disque est OK"
 ],
 "Disk is failing": [
  null,
  "Le disque est défaillant"
 ],
 "Disk passphrase": [
  null,
  "Phrase secrète du disque"
 ],
 "Disks": [
  null,
  "Disques"
 ],
 "Dismiss": [
  null,
  "Ignorer"
 ],
 "Distributed parity (RAID 5)": [
  null,
  "Parité répartie (RAID 5)"
 ],
 "Do not mount": [
  null,
  "Ne pas monter"
 ],
 "Do not mount automatically on boot": [
  null,
  "Ne pas monter automatiquement au démarrage"
 ],
 "Docking station": [
  null,
  "Station d’accueil"
 ],
 "Does not mount during boot": [
  null,
  "Ne se monte pas au démarrage"
 ],
 "Double distributed parity (RAID 6)": [
  null,
  "Parité doublement distribuée (RAID 6)"
 ],
 "Downloading $0": [
  null,
  "Téléchargement de $0"
 ],
 "Drive": [
  null,
  "Lecteur"
 ],
 "Dual rank": [
  null,
  "Double rang"
 ],
 "EFI system partition": [
  null,
  "Partition système EFI"
 ],
 "Edit": [
  null,
  "Modifier"
 ],
 "Edit Tang keyserver": [
  null,
  "Modifier le serveur de clés Tang"
 ],
 "Edit mount point": [
  null,
  "Modifier le point de montage"
 ],
 "Editing a key requires a free slot": [
  null,
  "La modification d’une clé nécessite un emplacement libre"
 ],
 "Ejecting $target": [
  null,
  "Éjecter $target"
 ],
 "Embedded PC": [
  null,
  "PC intégré"
 ],
 "Emptying $target": [
  null,
  "$target en cours de vidage"
 ],
 "Enabling $0": [
  null,
  "Permettre l'accès à $0"
 ],
 "Encrypt data with a Tang keyserver": [
  null,
  "Chiffrer les données avec un serveur de clés Tang"
 ],
 "Encrypt data with a passphrase": [
  null,
  "Chiffrer les données avec une phrase secrète"
 ],
 "Encrypted $0": [
  null,
  "Chiffré $0"
 ],
 "Encrypted Stratis pool": [
  null,
  "Pool Stratis chiffré"
 ],
 "Encrypted logical volume of $0": [
  null,
  "Volume logique chiffré de $0"
 ],
 "Encrypted partition of $0": [
  null,
  "Partition chiffrée de $0"
 ],
 "Encryption": [
  null,
  "Chiffrement"
 ],
 "Encryption options": [
  null,
  "Options de chiffrement"
 ],
 "Encryption type": [
  null,
  "Type de chiffrement"
 ],
 "Erasing $target": [
  null,
  "Effacement de $target"
 ],
 "Error": [
  null,
  "Erreur"
 ],
 "Error installing $0: PackageKit is not installed": [
  null,
  "Erreur d'installation de $0 : PackageKit n'est pas installé"
 ],
 "Exactly $0 physical volumes must be selected": [
  null,
  "Exactement $0 volumes physiques doivent être sélectionné"
 ],
 "Exactly $0 physical volumes need to be selected, one for each stripe of the logical volume.": [
  null,
  "Exactement $0 volumes physiques doivent être sélectionnés, un pour chaque bande du volume logique."
 ],
 "Excellent password": [
  null,
  "Mot de passe excellent"
 ],
 "Expansion chassis": [
  null,
  "Châssis d’extension"
 ],
 "Extended partition": [
  null,
  "Partition étendue"
 ],
 "Failed": [
  null,
  "Échoué"
 ],
 "Failed (Damaged)": [
  null,
  "Échec (endommagé)"
 ],
 "Failed (Electrical)": [
  null,
  "Échec (électrique)"
 ],
 "Failed (Read)": [
  null,
  "Échec (lecture)"
 ],
 "Failed (Servo)": [
  null,
  "Échec (Servo)"
 ],
 "Failed (Unknown)": [
  null,
  "Échec (inconnu)"
 ],
 "Failed to change password": [
  null,
  "Échec de la modification du mot de passe"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Échec de l’activation $0 dans firewalld"
 ],
 "Filesystem": [
  null,
  "Système de fichiers"
 ],
 "Filesystem is locked": [
  null,
  "Le système de fichiers est verrouillé"
 ],
 "Filesystem is mounted read-only": [
  null,
  "Le système de fichiers est monté en lecture seule"
 ],
 "Filesystem name": [
  null,
  "Nom du système de fichiers"
 ],
 "Filesystem outside the target": [
  null,
  "Système de fichiers hors de la cible"
 ],
 "Filesystems are already mounted below this mountpoint.": [
  null,
  "Les systèmes de fichiers sont déjà montés en dessous de ce point de montage."
 ],
 "Firmware version": [
  null,
  "Version du micrologiciel"
 ],
 "Fix NBDE support": [
  null,
  "Correction du support NBDE"
 ],
 "Format": [
  null,
  "Formater"
 ],
 "Format $0": [
  null,
  "Formater $0"
 ],
 "Format and mount": [
  null,
  "Format et montage"
 ],
 "Format and start": [
  null,
  "Formater et démarrer"
 ],
 "Format only": [
  null,
  "Format uniquement"
 ],
 "Formatting erases all data on a storage device.": [
  null,
  "Le formatage efface toutes les données d’un périphérique de stockage."
 ],
 "Free space": [
  null,
  "Espace libre"
 ],
 "Go to now": [
  null,
  "Aller à maintenant"
 ],
 "Grow": [
  null,
  "Augmenter"
 ],
 "Grow content": [
  null,
  "Augmenter le contenu"
 ],
 "Grow logical size of $0": [
  null,
  "Augmenter la taille logique de $0"
 ],
 "Grow logical volume": [
  null,
  "Augmenter le volume logique"
 ],
 "Grow partition": [
  null,
  "Agrandir la partition"
 ],
 "Grow the pool to take all space": [
  null,
  "Agrandir le pool pour qu'il occupe tout l'espace"
 ],
 "Grow to take all space": [
  null,
  "Augmenter en vue de prendre tout l’espace"
 ],
 "Handheld": [
  null,
  "Portable"
 ],
 "Hard Disk Drive": [
  null,
  "Lecteur de disque dur"
 ],
 "Hide confirmation password": [
  null,
  "Masquer le mot de passe de confirmation"
 ],
 "Hide password": [
  null,
  "Masquer le mot de passe"
 ],
 "Host key is incorrect": [
  null,
  "La clé de l’hôte est incorrecte"
 ],
 "How to check": [
  null,
  "Comment vérifier"
 ],
 "I confirm I want to lose this data forever": [
  null,
  "Je confirme vouloir perdre ces données pour toujours"
 ],
 "ID": [
  null,
  "ID"
 ],
 "INTERNAL ERROR - This logical volume is marked as active and should have an associated block device. However, no such block device could be found.": [
  null,
  "ERREUR INTERNE – Ce volume logique est marqué comme actif et devrait avoir un périphérique block associé. Or, aucun périphérique block correspondant n'a pu être trouvé."
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Si l’empreinte digitale correspond, cliquez sur « Accepter la clé et ajouter l'hôte ». Sinon, ne vous connectez pas et contactez votre administrateur."
 ],
 "Important data might be deleted:": [
  null,
  "Des données importantes pourraient être supprimées :"
 ],
 "In a terminal, run: ": [
  null,
  "Dans un terminal, exécuter : "
 ],
 "In progress": [
  null,
  "En cours"
 ],
 "In sync": [
  null,
  "En sync"
 ],
 "Inactive logical volume": [
  null,
  "Volume logique inactif"
 ],
 "Inconsistent filesystem mount": [
  null,
  "Montage de système de fichiers incohérent"
 ],
 "Index memory": [
  null,
  "Mémoire de l’index"
 ],
 "Initialize": [
  null,
  "Initialiser"
 ],
 "Initialize disk $0": [
  null,
  "Initialiser le disque $0"
 ],
 "Initializing erases all data on a disk.": [
  null,
  "L’initialisation efface toutes les données d’un disque."
 ],
 "Install": [
  null,
  "Installer"
 ],
 "Install NFS support": [
  null,
  "Installer la prise en charge NFS"
 ],
 "Install Stratis support": [
  null,
  "Installer la prise en charge de Stratis"
 ],
 "Install software": [
  null,
  "Installer le logiciel"
 ],
 "Installing $0": [
  null,
  "Installation de $0"
 ],
 "Installing $0 would remove $1.": [
  null,
  "L’installation de $0 supprimerait $1."
 ],
 "Installing packages": [
  null,
  "Installation des paquets"
 ],
 "Internal error": [
  null,
  "Erreur interne"
 ],
 "Interrupted": [
  null,
  "Interrompu"
 ],
 "Invalid date format": [
  null,
  "Format de date non valide"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Format de date non valide et format d’heure non valide"
 ],
 "Invalid file permissions": [
  null,
  "Les autorisations de fichier ne sont pas valides"
 ],
 "Invalid time format": [
  null,
  "Format d’heure non valide"
 ],
 "Invalid timezone": [
  null,
  "Fuseau horaire incorrect"
 ],
 "Invalid username or password": [
  null,
  "Nom d’utilisateur ou mot de passe non valide"
 ],
 "IoT gateway": [
  null,
  "Passerelle IoT"
 ],
 "Jobs": [
  null,
  "Tâches"
 ],
 "Kernel dump": [
  null,
  "Kernel Dump"
 ],
 "Key password": [
  null,
  "Mot de passe clé"
 ],
 "Key slots with unknown types can not be edited here": [
  null,
  "Les emplacements de clé de type inconnu ne peuvent pas être édités ici"
 ],
 "Key source": [
  null,
  "Source de la clé"
 ],
 "Keys": [
  null,
  "Clés"
 ],
 "Keyserver": [
  null,
  "Serveur de clés"
 ],
 "Keyserver address": [
  null,
  "Adresse du serveur"
 ],
 "Keyserver removal may prevent unlocking $0.": [
  null,
  "La suppression du serveur de clés peut empêcher le déverrouillage de $0."
 ],
 "LVM2 VDO pool": [
  null,
  "Pool VDO LVM2"
 ],
 "LVM2 logical volume": [
  null,
  "Volume logique LVM2"
 ],
 "LVM2 logical volumes": [
  null,
  "Volume logique LVM2"
 ],
 "LVM2 physical volume": [
  null,
  "Volume physique LVM2"
 ],
 "LVM2 physical volumes": [
  null,
  "Volumes physiques LVM2"
 ],
 "LVM2 volume group": [
  null,
  "Groupe de volumes LVM2"
 ],
 "LVM2 volume group $0": [
  null,
  "Groupe de volumes LVM2 $0"
 ],
 "Label": [
  null,
  "Étiquette"
 ],
 "Laptop": [
  null,
  "Portable"
 ],
 "Last cannot be removed": [
  null,
  "Impossible de retirer le dernier volume"
 ],
 "Last disk can not be removed": [
  null,
  "Impossible de retirer le dernier disque"
 ],
 "Last modified: $0": [
  null,
  "Dernière modification : $0"
 ],
 "Layout": [
  null,
  "Disposition"
 ],
 "Learn more": [
  null,
  "En savoir plus"
 ],
 "Limit size": [
  null,
  "Limiter la taille"
 ],
 "Limit virtual filesystem size": [
  null,
  "Limiter la taille du système de fichiers virtuel"
 ],
 "Linear": [
  null,
  "Linéaire"
 ],
 "Linux filesystem data": [
  null,
  "Données de système de fichiers Linux"
 ],
 "Linux swap space": [
  null,
  "Espace swap Linux"
 ],
 "Loading system modifications...": [
  null,
  "Chargement des modifications système..."
 ],
 "Loading...": [
  null,
  "Chargement..."
 ],
 "Local mount point": [
  null,
  "Point de montage local"
 ],
 "Local storage": [
  null,
  "Stockage local"
 ],
 "Location": [
  null,
  "Emplacement"
 ],
 "Lock": [
  null,
  "Verrouillage"
 ],
 "Lock $0?": [
  null,
  "Verrouiller $0 ?"
 ],
 "Locked data": [
  null,
  "Données verrouillées"
 ],
 "Locked encrypted device might contain data": [
  null,
  "Un périphérique chiffré et verrouillé pourrait contenir des données"
 ],
 "Locking $target": [
  null,
  "Verrouillage de $target"
 ],
 "Log in": [
  null,
  "Connexion"
 ],
 "Log in to $0": [
  null,
  "Connectez-vous à $0"
 ],
 "Log messages": [
  null,
  "Enregistrer les messages"
 ],
 "Logical": [
  null,
  "Logique"
 ],
 "Logical Volume Manager partition": [
  null,
  "Partition Logical Volume Manager"
 ],
 "Logical size": [
  null,
  "Taille logique"
 ],
 "Logical volume": [
  null,
  "Volume logique"
 ],
 "Logical volume (snapshot)": [
  null,
  "Volume logique (instantané)"
 ],
 "Logical volume of $0": [
  null,
  "Volume logique de $0"
 ],
 "Login failed": [
  null,
  "Échec de la connexion"
 ],
 "Low profile desktop": [
  null,
  "Bureau de profil bas"
 ],
 "Lunch box": [
  null,
  "Lunch Box"
 ],
 "MDRAID device": [
  null,
  "Périphérique MDRAID"
 ],
 "MDRAID device $0": [
  null,
  "Périphérique MDRAID $0"
 ],
 "MDRAID device is recovering": [
  null,
  "Le périphérique MDRAID est en cours de récupération"
 ],
 "MDRAID device must be running": [
  null,
  "Le périphérique MDRAID doit être en cours d'exécution"
 ],
 "MDRAID disk": [
  null,
  "Disque MDRAID"
 ],
 "MDRAID disks": [
  null,
  "Disques MDRAID"
 ],
 "Main server chassis": [
  null,
  "Châssis principal du serveur"
 ],
 "Manage storage": [
  null,
  "Gérer le stockage"
 ],
 "Manually": [
  null,
  "Manuellement"
 ],
 "Marking $target as faulty": [
  null,
  "Marquage de $target comme défectueux"
 ],
 "Media drive": [
  null,
  "Lecteur média"
 ],
 "Message to logged in users": [
  null,
  "Message aux utilisateurs connectés"
 ],
 "Metadata used": [
  null,
  "Méta-données utilisées"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini Tour"
 ],
 "Mirrored (RAID 1)": [
  null,
  "En miroir (RAID 1)"
 ],
 "Model": [
  null,
  "Modèle"
 ],
 "Modifying $target": [
  null,
  "Modifier $target"
 ],
 "Mount": [
  null,
  "Monter"
 ],
 "Mount Point": [
  null,
  "Point de montage"
 ],
 "Mount after network becomes available, ignore failure": [
  null,
  "Monter après que le réseau soit devenu disponible, ignorer les échecs"
 ],
 "Mount also automatically on boot": [
  null,
  "Monter automatiquement au démarrage également"
 ],
 "Mount at boot": [
  null,
  "Monter au démarrage"
 ],
 "Mount automatically on $0 on boot": [
  null,
  "Montage automatique $0 au démarrage"
 ],
 "Mount before services start": [
  null,
  "Montage avant le début des services"
 ],
 "Mount configuration": [
  null,
  "Configuration de montage"
 ],
 "Mount filesystem": [
  null,
  "Monter le système de fichiers"
 ],
 "Mount now": [
  null,
  "Monter maintenant"
 ],
 "Mount on $0 now": [
  null,
  "Montez sur $0 maintenant"
 ],
 "Mount options": [
  null,
  "Options de montage"
 ],
 "Mount point": [
  null,
  "Point de montage"
 ],
 "Mount point cannot be empty": [
  null,
  "Le point de montage ne peut pas être vide"
 ],
 "Mount point cannot be empty.": [
  null,
  "Le point de montage ne peut pas être vide."
 ],
 "Mount point is already used for $0": [
  null,
  "Le point de montage est déjà utilisé pour $0"
 ],
 "Mount point must start with \"/\".": [
  null,
  "Le point de montage doit commencer par « / »."
 ],
 "Mount read only": [
  null,
  "Monter en lecture seule"
 ],
 "Mount without waiting, ignore failure": [
  null,
  "Monter sans attendre, ignorer les échecs"
 ],
 "Mounting $target": [
  null,
  "Montage de $target"
 ],
 "Mounts before services start": [
  null,
  "Montage avant le démarrage des services"
 ],
 "Mounts in parallel with services": [
  null,
  "Montage en parallèle avec les services"
 ],
 "Mounts in parallel with services, but after network is available": [
  null,
  "Montage en parallèle avec les services, mais après que le réseau soit disponible"
 ],
 "Multi-system chassis": [
  null,
  "Châssis multi-système"
 ],
 "Multipathed devices": [
  null,
  "Appareils multi-chemins"
 ],
 "NFS mount": [
  null,
  "Point de montage NFS"
 ],
 "NTP server": [
  null,
  "Serveur NTP"
 ],
 "Name": [
  null,
  "Nom"
 ],
 "Name can not be empty.": [
  null,
  "Le nom ne peut pas être vide."
 ],
 "Name cannot be empty.": [
  null,
  "Le nom ne peut pas être vide."
 ],
 "Name cannot be longer than $0 bytes": [
  null,
  "Le nom ne peut pas dépasser $0 octets"
 ],
 "Name cannot be longer than $0 characters": [
  null,
  "Le nom ne peut pas dépasser $0 caractères"
 ],
 "Name cannot be longer than 127 characters.": [
  null,
  "Le nom ne peut pas dépasser 127 caractères."
 ],
 "Name cannot be longer than 255 characters.": [
  null,
  "Le nom ne peut pas dépasser 255 caractères."
 ],
 "Name cannot contain the character '$0'.": [
  null,
  "Le nom ne peut pas contenir le caractère « $0 »."
 ],
 "Name cannot contain the character '/'.": [
  null,
  "Le nom ne peut pas contenir le caractère '/'."
 ],
 "Name cannot contain whitespace.": [
  null,
  "Le nom ne peut pas contenir d’espace."
 ],
 "Need a spare disk": [
  null,
  "Disque supplémentaire nécessaire"
 ],
 "Need at least one NTP server": [
  null,
  "Besoin d’au moins un serveur NTP"
 ],
 "Networked storage": [
  null,
  "Stockage réseau"
 ],
 "Networking": [
  null,
  "Réseau"
 ],
 "New NFS mount": [
  null,
  "Nouveau point de montage NFS"
 ],
 "New passphrase": [
  null,
  "Nouvelle phrase secrète"
 ],
 "New password was not accepted": [
  null,
  "Le nouveau mot de passe n’a pas été accepté"
 ],
 "Next": [
  null,
  "Suivant"
 ],
 "No available slots": [
  null,
  "Pas d’emplacements disponibles"
 ],
 "No block devices are available.": [
  null,
  "Aucun périphérique block n’est disponible."
 ],
 "No block devices found": [
  null,
  "Aucun périphérique block trouvé"
 ],
 "No delay": [
  null,
  "Aucun délai"
 ],
 "No devices found": [
  null,
  "Aucun périphérique trouvé"
 ],
 "No disks are available.": [
  null,
  "Aucun disque disponible."
 ],
 "No disks found": [
  null,
  "Aucun disque trouvé"
 ],
 "No drives found": [
  null,
  "Aucun lecteur trouvé"
 ],
 "No encryption": [
  null,
  "Aucun chiffrement"
 ],
 "No filesystem": [
  null,
  "Aucun système de fichiers"
 ],
 "No filesystems": [
  null,
  "Aucun système de fichiers"
 ],
 "No free key slots": [
  null,
  "Pas d’emplacements libres pour les clés"
 ],
 "No free space": [
  null,
  "Pas d’espace libre"
 ],
 "No free space after this partition": [
  null,
  "Aucun espace libre après cette partition"
 ],
 "No keys added": [
  null,
  "Aucune clé n’a été ajoutée"
 ],
 "No logical volumes": [
  null,
  "Pas de volumes logiques"
 ],
 "No media inserted": [
  null,
  "Aucun média inséré"
 ],
 "No partitioning": [
  null,
  "Pas de partitionnement"
 ],
 "No partitions found": [
  null,
  "Aucune partition trouvée"
 ],
 "No physical volumes found": [
  null,
  "Aucun volume physique trouvé"
 ],
 "No results found": [
  null,
  "Aucun résultat trouvé"
 ],
 "No snapshots found": [
  null,
  "Aucun instantané trouvé"
 ],
 "No storage found": [
  null,
  "Aucun stockage trouvé"
 ],
 "No subvolumes": [
  null,
  "Aucun sous-volume"
 ],
 "No such file or directory": [
  null,
  "Aucun fichier ou répertoire de ce nom"
 ],
 "No system modifications": [
  null,
  "Aucune modification système"
 ],
 "Not a valid private key": [
  null,
  "Clé privée non valide"
 ],
 "Not enough free space": [
  null,
  "Pas assez d’espace libre"
 ],
 "Not enough space": [
  null,
  "Espace insuffisant"
 ],
 "Not enough space to grow": [
  null,
  "Espace insuffisant pour agrandir le volume"
 ],
 "Not found": [
  null,
  "Non trouvé"
 ],
 "Not permitted to perform this action.": [
  null,
  "Non autorisé à effectuer cette action."
 ],
 "Not running": [
  null,
  "Pas en cours d’exécution"
 ],
 "Not synchronized": [
  null,
  "Non synchronisé"
 ],
 "Notebook": [
  null,
  "Ordinateur portable"
 ],
 "Number of bad sectors": [
  null,
  "Nombre de secteurs défectueux"
 ],
 "Occurrences": [
  null,
  "Occurrences"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Old passphrase": [
  null,
  "Ancienne phrase secrète"
 ],
 "Old password not accepted": [
  null,
  "Ancien mot de passe non accepté"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Une fois que Cockpit est installé, l’activer avec « systemctl enable --now cockpit.socket »."
 ],
 "Only $0 of $1 are used.": [
  null,
  "Seulement $0 de $1 sont utilisés."
 ],
 "Operation '$operation' on $target": [
  null,
  "Opération « $operation » sur $target"
 ],
 "Options": [
  null,
  "Options"
 ],
 "Other": [
  null,
  "Autre"
 ],
 "Overprovisioning": [
  null,
  "Surallocation"
 ],
 "Overwrite": [
  null,
  "Écraser"
 ],
 "Overwrite existing data with zeros (slower)": [
  null,
  "Écraser les données existantes avec des zéros (plus lent)"
 ],
 "PID": [
  null,
  "PID"
 ],
 "PackageKit crashed": [
  null,
  "Plantage de « PackageKit »"
 ],
 "Partition": [
  null,
  "Partition"
 ],
 "Partition of $0": [
  null,
  "Partition de $0"
 ],
 "Partition size is $0. Content size is $1.": [
  null,
  "Taille de la partition : $0. Taille du contenu : $1."
 ],
 "Partitioning": [
  null,
  "Partitionnement"
 ],
 "Partitions": [
  null,
  "Partitions"
 ],
 "Partitions are not supported on this block device. If it is used as a disk for a virtual machine, the partitions must be managed by the operating system inside the virtual machine.": [
  null,
  "Les partitions ne sont pas prises en charge sur ce périphérique block. S'il est utilisé en tant que disque pour une machine virtuelle, les partitions doivent être gérées par le système d'exploitation à l'intérieur de la machine virtuelle."
 ],
 "Passphrase": [
  null,
  "Phrase secrète"
 ],
 "Passphrase can not be empty": [
  null,
  "La phrase secrète ne peut pas être vide"
 ],
 "Passphrase cannot be empty": [
  null,
  "La phrase secrète ne peut pas être vide"
 ],
 "Passphrase from any other key slot": [
  null,
  "Phrase secrète de n’importe quel autre emplacement de clé"
 ],
 "Passphrase removal may prevent unlocking $0.": [
  null,
  "La suppression de la phrase secrète peut empêcher le déverrouillage de $0."
 ],
 "Passphrases do not match": [
  null,
  "Les phrases secrète ne correspondent pas"
 ],
 "Password": [
  null,
  "Mot de passe"
 ],
 "Password is not acceptable": [
  null,
  "Le mot de passe n’est pas acceptable"
 ],
 "Password is too weak": [
  null,
  "Le mot de passe est trop faible"
 ],
 "Password not accepted": [
  null,
  "Mot de passe non accepté"
 ],
 "Paste": [
  null,
  "Coller"
 ],
 "Paste error": [
  null,
  "Erreur de collage"
 ],
 "Path on server": [
  null,
  "Chemin sur le serveur"
 ],
 "Path on server cannot be empty.": [
  null,
  "Le chemin sur le serveur ne peut pas être vide."
 ],
 "Path on server must start with \"/\".": [
  null,
  "Le chemin sur le serveur doit commencer par « / »."
 ],
 "Path to file": [
  null,
  "Chemin d’accès au fichier"
 ],
 "Peripheral chassis": [
  null,
  "Châssis périphérique"
 ],
 "Permanently delete $0?": [
  null,
  "Supprimer définitivement $0 ?"
 ],
 "Permanently delete logical volume $0/$1?": [
  null,
  "Supprimer définitivement le volume logique $0/$1 ?"
 ],
 "Permanently delete subvolume $0?": [
  null,
  "Supprimer définitivement le sous-volume $0 ?"
 ],
 "Persistent memory has become read-only": [
  null,
  "La mémoire persistante est passée en lecture seule"
 ],
 "Physical": [
  null,
  "Physique"
 ],
 "Physical Volumes": [
  null,
  "Volumes physiques"
 ],
 "Physical volumes": [
  null,
  "Volumes physiques"
 ],
 "Physical volumes can not be resized here": [
  null,
  "Les volumes physiques ne peuvent pas être redimensionnés ici"
 ],
 "Pick date": [
  null,
  "Choisissez une date"
 ],
 "Pizza box": [
  null,
  "Pizza Box"
 ],
 "Please unmount them first.": [
  null,
  "Veuillez commencer par les démonter."
 ],
 "Pool for thin logical volumes": [
  null,
  "Pool pour les volumes logiques à allocation fine"
 ],
 "Pool for thinly provisioned LVM2 logical volumes": [
  null,
  "Pool pour les volumes logiques LVM2 à allocation fine et dynamique"
 ],
 "Pool for thinly provisioned volumes": [
  null,
  "Pool pour les volumes à allocation fine et dynamique"
 ],
 "Pool passphrase": [
  null,
  "Phrase secrète du pool"
 ],
 "Port": [
  null,
  "Port"
 ],
 "Portable": [
  null,
  "Portable"
 ],
 "Power on hours": [
  null,
  "Heures totales"
 ],
 "PowerPC PReP boot partition": [
  null,
  "Partition de démarrage PReP pour PowerPC"
 ],
 "Present": [
  null,
  "Présent"
 ],
 "Processes using the location": [
  null,
  "Processus utilisant l’emplacement"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "L’invite via ssh-add a expiré"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "L’invite via ssh-keygen a expiré"
 ],
 "Provide the passphrase for the pool on these block devices:": [
  null,
  "Fournissez la phrase secrète pour le pool sur ces périphériques block :"
 ],
 "Purpose": [
  null,
  "Objectif"
 ],
 "RAID ($0)": [
  null,
  "RAID ( $0 )"
 ],
 "RAID 0": [
  null,
  "RAID 0"
 ],
 "RAID 0 (stripe)": [
  null,
  "RAID 0 (Bande)"
 ],
 "RAID 1": [
  null,
  "RAID 1"
 ],
 "RAID 1 (mirror)": [
  null,
  "RAID 1 (Miroir)"
 ],
 "RAID 10": [
  null,
  "RAID 10"
 ],
 "RAID 10 (stripe of mirrors)": [
  null,
  "RAID 10 (Bande de miroirs)"
 ],
 "RAID 4": [
  null,
  "RAID 4"
 ],
 "RAID 4 (dedicated parity)": [
  null,
  "RAID 4 (Parité dédiée)"
 ],
 "RAID 5": [
  null,
  "RAID 5"
 ],
 "RAID 5 (distributed parity)": [
  null,
  "RAID 5 (Parité répartie)"
 ],
 "RAID 6": [
  null,
  "RAID 6"
 ],
 "RAID 6 (double distributed parity)": [
  null,
  "RAID 6 (Double parité répartie)"
 ],
 "RAID chassis": [
  null,
  "Châssis RAID"
 ],
 "RAID level": [
  null,
  "Niveau RAID"
 ],
 "RAID10 needs an even number of physical volumes": [
  null,
  "Le RAID10 nécessite un nombre pair de volumes physiques"
 ],
 "Rack mount chassis": [
  null,
  "Châssis de montage en rack"
 ],
 "Reading": [
  null,
  "Lecture en cours"
 ],
 "Reboot": [
  null,
  "Redémarrer"
 ],
 "Recovering": [
  null,
  "Recouvrement"
 ],
 "Recovering MDRAID device $target": [
  null,
  "Restauration du périphérique MDRAID $target"
 ],
 "Regenerating initrd": [
  null,
  "Régénération d’ initrd"
 ],
 "Related processes and services will be forcefully stopped.": [
  null,
  "Les processus et services connexes seront arrêtés de force."
 ],
 "Related processes will be forcefully stopped.": [
  null,
  "Les processus connexes seront arrêtés de force."
 ],
 "Related services will be forcefully stopped.": [
  null,
  "Les services connexes seront arrêtés par la force."
 ],
 "Removals:": [
  null,
  "Suppressions :"
 ],
 "Remove": [
  null,
  "Retirer"
 ],
 "Remove $0?": [
  null,
  "Supprimer $0 ?"
 ],
 "Remove Tang keyserver?": [
  null,
  "Supprimer le serveur de clés Tang ?"
 ],
 "Remove device": [
  null,
  "Supprimer le périphérique"
 ],
 "Remove missing physical volumes?": [
  null,
  "Retirer les volumes physiques manquants ?"
 ],
 "Remove passphrase in key slot $0?": [
  null,
  "Supprimer la phrase de secrète dans l’emplacement de la clé $0 ?"
 ],
 "Remove passphrase?": [
  null,
  "Supprimer la phrase secrète ?"
 ],
 "Removing $0": [
  null,
  "Suppression de $0"
 ],
 "Removing $target from MDRAID device": [
  null,
  "Supprimer $target du périphérique MDRAID"
 ],
 "Removing a passphrase without confirmation of another passphrase may prevent unlocking or key management, if other passphrases are forgotten or lost.": [
  null,
  "La suppression d’une phrase secrète sans confirmation d’une autre phrase secrète peut empêcher le déverrouillage ou la gestion des clés, si les autres phrases secrètes sont oubliées ou perdues."
 ],
 "Removing physical volume from $target": [
  null,
  "Suppression du volume physique de $target"
 ],
 "Rename": [
  null,
  "Renommer"
 ],
 "Rename Stratis pool": [
  null,
  "Renommer le pool Stratis"
 ],
 "Rename filesystem": [
  null,
  "Renommer le système de fichiers"
 ],
 "Rename logical volume": [
  null,
  "Renommer le volume logique"
 ],
 "Rename volume group": [
  null,
  "Renommer le groupe de volumes"
 ],
 "Renaming $target": [
  null,
  "Renommer $target"
 ],
 "Repair": [
  null,
  "Réparer"
 ],
 "Repair logical volume $0": [
  null,
  "Réparer le volume logique $0"
 ],
 "Repairing $target": [
  null,
  "Réparer $target"
 ],
 "Repeat passphrase": [
  null,
  "Répéter la phrase secrète"
 ],
 "Resizing $target": [
  null,
  "Redimensionnement $target"
 ],
 "Resizing an encrypted filesystem requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Le redimensionnement d'un système de fichiers chiffré nécessite le déverrouillage du disque. Veuillez fournir la phrase secrète du disque actuel."
 ],
 "Reuse existing encryption": [
  null,
  "Réutiliser le chiffrement existant"
 ],
 "Reuse existing encryption ($0)": [
  null,
  "Réutiliser le chiffrement existant ($0)"
 ],
 "Row expansion": [
  null,
  "Agrandissement de ligne"
 ],
 "Row select": [
  null,
  "Sélection de ligne"
 ],
 "Run extended test": [
  null,
  "Exécuter un test étendu"
 ],
 "Run short test": [
  null,
  "Exécuter un test court"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Exécutez cette commande sur un réseau de confiance ou en la tapant physiquement sur la machine distante :"
 ],
 "Running": [
  null,
  "En cours"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SHA-1": [
  null,
  "SHA-1"
 ],
 "SHA-256": [
  null,
  "SHA256"
 ],
 "SMART self-test of $target": [
  null,
  "Autotest SMART de $target"
 ],
 "SSH key": [
  null,
  "Clé SSH"
 ],
 "SSH key login": [
  null,
  "Connexion par clé SSH"
 ],
 "Save": [
  null,
  "Enregistrer"
 ],
 "Save space by compressing individual blocks with LZ4": [
  null,
  "Économiser de l’espace en compressant les blocs individuels avec LZ4"
 ],
 "Save space by storing identical data blocks just once": [
  null,
  "Économiser de l’espace en stockant une seule fois les blocs de données identiques"
 ],
 "Saving a new passphrase requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "L'enregistrement d'une nouvelle phrase secrète nécessite le déverrouillage du disque. Veuillez fournir la phrase secrète du disque actuel."
 ],
 "Sealed-case PC": [
  null,
  "PC scellé"
 ],
 "Securely erasing $target": [
  null,
  "Effacer en toute sécurité $target"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Configuration et dépannage de Linux avec renforcement de la sécurité"
 ],
 "Select an option": [
  null,
  "Sélectionner une option"
 ],
 "Select the physical volumes that should be used to repair the logical volume. At least $0 are needed.": [
  null,
  "Sélectionnez les volumes physiques à utiliser pour réparer le volume logique. Au moins $0 volumes physiques sont nécessaires."
 ],
 "Self-test status": [
  null,
  "État d'autotest"
 ],
 "Serial number": [
  null,
  "Numéro de série"
 ],
 "Server": [
  null,
  "Serveur"
 ],
 "Server address": [
  null,
  "Adresse du serveur"
 ],
 "Server address cannot be empty.": [
  null,
  "L’adresse du serveur ne peut pas être vide."
 ],
 "Server cannot be empty.": [
  null,
  "Le serveur ne peut pas être vide."
 ],
 "Server has closed the connection.": [
  null,
  "Le serveur a fermé la connexion."
 ],
 "Service": [
  null,
  "Service"
 ],
 "Services using the location": [
  null,
  "Services utilisant l’emplacement"
 ],
 "Set": [
  null,
  "Ensemble"
 ],
 "Set initial size": [
  null,
  "Définir une taille initiale"
 ],
 "Set limit of virtual filesystem size": [
  null,
  "Définir la limite de taille du système de fichiers virtuel"
 ],
 "Set partition type of $0": [
  null,
  "Définir le type de partition de $0"
 ],
 "Set time": [
  null,
  "Régler l’heure"
 ],
 "Setting up loop device $target": [
  null,
  "Configuration du périphérique de boucle $target"
 ],
 "Shell script": [
  null,
  "Script shell"
 ],
 "Shift+Insert": [
  null,
  "Maj+Inser"
 ],
 "Show all $0 rows": [
  null,
  "Afficher l'ensemble des $0 lignes"
 ],
 "Show confirmation password": [
  null,
  "Afficher le mot de passe de confirmation"
 ],
 "Show password": [
  null,
  "Afficher le mot de passe"
 ],
 "Shrink": [
  null,
  "Réduire"
 ],
 "Shrink logical volume": [
  null,
  "Réduire le volume logique"
 ],
 "Shrink partition": [
  null,
  "Réduire la partition"
 ],
 "Shrink volume": [
  null,
  "Réduire le volume"
 ],
 "Shut down": [
  null,
  "Fermeture"
 ],
 "Single rank": [
  null,
  "Rang unique"
 ],
 "Size": [
  null,
  "Taille"
 ],
 "Size cannot be negative": [
  null,
  "La taille ne peut pas être négative"
 ],
 "Size cannot be zero": [
  null,
  "La taille ne peut pas être nulle"
 ],
 "Size is too large": [
  null,
  "La taille est trop grande"
 ],
 "Size must be a number": [
  null,
  "La taille doit correspondre à un nombre"
 ],
 "Size must be at least $0": [
  null,
  "La taille doit être au moins $0"
 ],
 "Slot $0": [
  null,
  "Emplacement $0"
 ],
 "Snapshot": [
  null,
  "Instantané"
 ],
 "Snapshot origin": [
  null,
  "Origine de l'instantané"
 ],
 "Snapshots": [
  null,
  "Instantanés"
 ],
 "Solid State Drive": [
  null,
  "Disque SSD"
 ],
 "Some block devices of this pool have grown in size after the pool was created. The pool can be safely grown to use the newly available space.": [
  null,
  "Certains périphériques block de ce pool ont gagné en taille depuis la création du pool. Le pool peut être agrandi en toute sécurité pour utiliser le nouvel espace disponible."
 ],
 "Sorry": [
  null,
  "Désolé"
 ],
 "Space-saving computer": [
  null,
  "Ordinateur gain de place"
 ],
 "Spare": [
  null,
  "De rechange"
 ],
 "Spare capacity is below the threshold": [
  null,
  "La capacité restante est inférieure au seuil"
 ],
 "Specific time": [
  null,
  "Temps spécifique"
 ],
 "Start": [
  null,
  "Démarrer"
 ],
 "Start multipath": [
  null,
  "Démarrer Multipath"
 ],
 "Started": [
  null,
  "Démarré"
 ],
 "Starting MDRAID device $target": [
  null,
  "Démarrage du périphérique MDRAID $target"
 ],
 "Starting swapspace $target": [
  null,
  "Démarrage de swapspace $target"
 ],
 "State": [
  null,
  "État"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "Stop": [
  null,
  "Arrêter"
 ],
 "Stop and remove": [
  null,
  "Arrêter et retirer"
 ],
 "Stop and unmount": [
  null,
  "Arrêter et démonter"
 ],
 "Stop device": [
  null,
  "Arrêter le périphérique"
 ],
 "Stopping MDRAID device $target": [
  null,
  "Arrêt du périphérique RAID $target"
 ],
 "Stopping swapspace $target": [
  null,
  "Arrêt de l’espace d’échange $target"
 ],
 "Storage": [
  null,
  "Stockage"
 ],
 "Storage can not be managed on this system.": [
  null,
  "Le stockage ne peut pas être géré sur ce système."
 ],
 "Storage logs": [
  null,
  "Journaux de stockage"
 ],
 "Store passphrase": [
  null,
  "Stocker la phrase secrète"
 ],
 "Stored passphrase": [
  null,
  "Phrase secrète stockée"
 ],
 "Stratis block device": [
  null,
  "Périphérique block Stratis"
 ],
 "Stratis block devices": [
  null,
  "Périphériques block Stratis"
 ],
 "Stratis blockdevs can not be made smaller": [
  null,
  "Les blockdevs Stratis ne peuvent pas être réduits"
 ],
 "Stratis filesystem": [
  null,
  "Système de fichiers Stratis"
 ],
 "Stratis filesystems": [
  null,
  "Systèmes de fichiers Stratis"
 ],
 "Stratis filesystems pool": [
  null,
  "Pool de systèmes de fichiers Stratis"
 ],
 "Stratis pool": [
  null,
  "Pool Stratis"
 ],
 "Striped (RAID 0)": [
  null,
  "En bandes (RAID 0)"
 ],
 "Striped and mirrored (RAID 10)": [
  null,
  "En bandes et en miroir (RAID 10)"
 ],
 "Stripes": [
  null,
  "Bandes"
 ],
 "Strong password": [
  null,
  "Mot de passe fort"
 ],
 "Sub-Chassis": [
  null,
  "Sous-châssis"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Successful": [
  null,
  "Réussi"
 ],
 "Successfully copied to clipboard!": [
  null,
  "Copié dans le presse-papiers avec succès !"
 ],
 "Swap": [
  null,
  "Swap"
 ],
 "Swap can not be resized here": [
  null,
  "Le swap ne peut pas être redimensionné ici"
 ],
 "Synchronized": [
  null,
  "Synchronisé"
 ],
 "Synchronized with $0": [
  null,
  "Synchronisé avec $0"
 ],
 "Synchronizing": [
  null,
  "Synchronisation"
 ],
 "Synchronizing MDRAID device $target": [
  null,
  "Synchronisation du périphérique MDRAID $target"
 ],
 "Tablet": [
  null,
  "Tablette"
 ],
 "Tang keyserver": [
  null,
  "Serveur de clés Tang"
 ],
 "Target": [
  null,
  "Cible"
 ],
 "Temperature outside of recommended thresholds": [
  null,
  "Température dépassant les seuils recommandés"
 ],
 "The $0 package is not available from any repository.": [
  null,
  "Le paquet $0 n’est disponible dans aucun référentiel."
 ],
 "The $0 package must be installed to create Stratis pools.": [
  null,
  "Le paquet $0 doit être installé pour pouvoir créer des pools Stratis."
 ],
 "The $0 package must be installed.": [
  null,
  "Le paquet $0 doit être installé."
 ],
 "The $0 package will be installed to create VDO devices.": [
  null,
  "Le paquet $0 sera installé pour créer des périphériques VDO."
 ],
 "The MDRAID device is in a degraded state": [
  null,
  "Le périphérique MDRAID est dans un état dégradé"
 ],
 "The MDRAID device must be running": [
  null,
  "Le périphérique MDRAID doit être en cours d'exécution"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "La clé SSH $0 de $1 sur $2 sera ajoutée au fichier $3 de $4 sur $5."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "La clé SSH $0 sera disponible pour le reste de la session et sera également disponible pour la connexion à d’autres hôtes."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "La clé SSH permettant de se connecter à $0 est protégée par un mot de passe, et l’hôte ne permet pas de se connecter avec un mot de passe. Veuillez fournir le mot de passe de la clé à $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "La clé SSH permettant de se connecter à $0 est protégée. Vous pouvez vous connecter avec votre mot de passe de connexion ou en fournissant le mot de passe de la clé à $1."
 ],
 "The creation of this VDO device did not finish and the device can't be used.": [
  null,
  "La création de ce périphérique VDO n’est pas terminée et l’appareil ne peut pas être utilisé."
 ],
 "The currently logged in user is not permitted to see information about keys.": [
  null,
  "L’utilisateur actuellement connecté n’est pas autorisé à voir les informations sur les clés."
 ],
 "The disk needs to be unlocked before formatting. Please provide an existing passphrase.": [
  null,
  "Le disque doit être déverrouillé avant le formatage. Veuillez fournir une phrase secrète existante."
 ],
 "The filesystem has no assigned mount point.": [
  null,
  "Le système de fichiers n’a pas de point de montage assigné."
 ],
 "The filesystem has no permanent mount point.": [
  null,
  "Le système de fichiers n’a pas de point de montage permanent."
 ],
 "The filesystem is configured to be automatically mounted on boot but its encryption container will not be unlocked at that time.": [
  null,
  "Le système de fichiers est configuré pour être monté automatiquement au démarrage, mais son conteneur de chiffrement ne sera pas encore déverrouillé."
 ],
 "The filesystem is currently mounted but will not be mounted after the next boot.": [
  null,
  "Le système de fichiers est actuellement monté mais ne le sera plus après le prochain démarrage."
 ],
 "The filesystem is currently mounted on $0 but will be mounted on $1 on the next boot.": [
  null,
  "Le système de fichiers est actuellement monté sur $0 mais sera monté sur $1 au prochain démarrage."
 ],
 "The filesystem is currently mounted on $0 but will not be mounted after the next boot.": [
  null,
  "Le système de fichiers est actuellement monté $0 mais ne sera pas monté après le prochain démarrage."
 ],
 "The filesystem is currently not mounted but will be mounted on the next boot.": [
  null,
  "Le système de fichiers n’est pas actuellement monté mais sera monté au prochain démarrage."
 ],
 "The filesystem is not mounted.": [
  null,
  "Le système de fichiers n’est pas monté."
 ],
 "The filesystem will be unlocked and mounted on the next boot. This might require inputting a passphrase.": [
  null,
  "Le système de fichiers sera déverrouillé et monté au prochain démarrage. Cela peut nécessiter la saisie d’une phrase secrète."
 ],
 "The fingerprint should match:": [
  null,
  "Les empreintes doivent correspondre :"
 ],
 "The initrd must be regenerated.": [
  null,
  "L'initrd doit être régénéré."
 ],
 "The key password can not be empty": [
  null,
  "Le mot de passe de la clé ne peut pas être vide"
 ],
 "The key passwords do not match": [
  null,
  "Les mots de passe sont différents"
 ],
 "The last key slot can not be removed": [
  null,
  "Le dernier logement de clé ne peut pas être retiré"
 ],
 "The last mounted subvolume can not be deleted": [
  null,
  "Le dernier sous-volume monté ne peut pas être supprimé"
 ],
 "The listed processes and services will be forcefully stopped.": [
  null,
  "Les processus et services listés seront stoppés en force."
 ],
 "The listed processes will be forcefully stopped.": [
  null,
  "Les processus énumérés seront stoppés en force."
 ],
 "The listed services will be forcefully stopped.": [
  null,
  "Les services répertoriés seront stoppés en force."
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "L’utilisateur actuellement connecté n’est pas autorisé à voir les modifications système"
 ],
 "The mount point $0 is in use by these processes:": [
  null,
  "Le point de montage $0 est utilisé par ces processus :"
 ],
 "The mount point $0 is in use by these services:": [
  null,
  "Le point de montage $0 est utilisé par ces services :"
 ],
 "The password can not be empty": [
  null,
  "Le mot de passe ne peut pas être vide"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "L’empreinte digitale qui en résulte peut être partagée via des méthodes publiques, y compris par courrier électronique."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "L'empreinte qui en découle peut être partagée publiquement par e-mail ou autre sans risque. Si vous demandez à quelqu'un d'autre de faire la vérification pour vous, cette personne peut vous envoyer les résultats par n'importe quel biais."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Le serveur a refusé d’authentifier en utilisant des méthodes prises en charge."
 ],
 "The system does not currently support unlocking a filesystem with a Tang keyserver during boot.": [
  null,
  "Le système ne prend actuellement pas en charge le déverrouillage d'un système de fichiers avec un serveur de clés Tang pendant le démarrage."
 ],
 "The system does not currently support unlocking the root filesystem with a Tang keyserver.": [
  null,
  "Le système ne prend actuellement pas en charge le déverrouillage du système de fichiers racine avec un serveur de clés Tang."
 ],
 "There are devices with multiple paths on the system, but the multipath service is not running.": [
  null,
  "Il y a des périphériques avec plusieurs chemins sur le système, mais le service multipath n’est pas en cours d’exécution."
 ],
 "There is not enough space available that could be used for a repair. At least $0 are needed on physical volumes that are not already used for this logical volume.": [
  null,
  "Il n'y a pas assez d'espace libre pouvant être utilisé pour une réparation. Au moins $0 sont nécessaires sur des volumes physiques n'étant pas déjà utilisés pour ce volume logique."
 ],
 "These additional steps are necessary:": [
  null,
  "Ces étapes supplémentaires sont nécessaires :"
 ],
 "These changes will be made:": [
  null,
  "Ces changements seront effectués :"
 ],
 "Thin logical volume": [
  null,
  "Volume logique à allocation fine"
 ],
 "Thinly provisioned LVM2 logical volumes": [
  null,
  "Volumes logiques LVM2 à allocation fine et dynamique"
 ],
 "This MDRAID device has no write-intent bitmap. Such a bitmap can reduce synchronization times significantly.": [
  null,
  "Ce périphérique MDRAID n'a pas de bitmap d'intention d'écriture. Une telle bitmap peut réduire les temps de synchronisation de façon significative."
 ],
 "This NFS mount is in use and only its options can be changed.": [
  null,
  "Ce montage NFS est en cours d’utilisation et seules ses options peuvent être modifiées."
 ],
 "This VDO device does not use all of its backing device.": [
  null,
  "Ce périphérique VDO n’utilise pas tout son périphérique de sauvegarde."
 ],
 "This device can not be used for the installation target.": [
  null,
  "Ce périphérique ne peut pas être utilisé pour la cible d'installation."
 ],
 "This device is currently in use.": [
  null,
  "Ce périphérique est actuellement en cours d’utilisation."
 ],
 "This keyserver is the only way to unlock the pool and can not be removed.": [
  null,
  "Ce serveur de clés constitue la seule manière de déverrouiller le pool et ne peut pas être enlevé."
 ],
 "This logical volume has lost some of its physical volumes and can no longer be used. You need to delete it and create a new one to take its place.": [
  null,
  "Ce volume logique a perdu certains de ses volumes physiques et ne peut plus être utilisé. Vous devez le supprimer et en créer un nouveau pour le remplacer."
 ],
 "This logical volume has lost some of its physical volumes but has not lost any data yet. You should repair it to restore its original redundancy.": [
  null,
  "Ce volume logique a perdu certains de ses volumes physiques mais n'a pas encore perdu de données. Vous devriez le réparer pour rétablir la redondance d'origine."
 ],
 "This logical volume has lost some of its physical volumes but might not have lost any data yet. You might be able to repair it.": [
  null,
  "Ce volume logique a perdu certains de ses volumes physiques mais pourrait ne pas avoir encore perdu de données. Vous arriverez peut-être à le réparer."
 ],
 "This logical volume is not completely used by its content.": [
  null,
  "Ce volume logique n’est pas complètement utilisé par son contenu."
 ],
 "This partition is not completely used by its content.": [
  null,
  "Cette partition n’est pas complètement utilisée par son contenu."
 ],
 "This passphrase is the only way to unlock the pool and can not be removed.": [
  null,
  "Cette phrase secrète constitue la seule manière de déverrouiller le pool et ne peut pas être enlevée."
 ],
 "This pool does not use all the space on its block devices.": [
  null,
  "Ce pool n’utilise pas tout l'espace sur ses périphériques block."
 ],
 "This pool is in a degraded state.": [
  null,
  "Ce pool est dans un état dégradé."
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Cet outil configure la politique SELinux et peut aider à comprendre et à résoudre les violations de la politique."
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Cet outil configure le système pour qu'il écrive les vidages de mémoire sur incidents du noyau. Il prend en charge les cibles \"local\" (disque), \"ssh\" et \"nfs\"."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Cet outil génère une archive des informations de configuration et de diagnostic du système en cours d'exécution. Ces archives peuvent être stockées localement ou centralement à des fins d'enregistrement ou de suivi, ou être envoyées aux représentants du support technique, aux développeurs ou aux administrateurs système pour les aider dans la recherche d'erreurs techniques et le débogage."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Cet outil gère le stockage local, tel que les systèmes de fichiers, les groupes de volumes LVM2 et les montages NFS."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Cet outil gère les réseaux tels que les liens, les ponts, les équipes, les VLAN et les pare-feu en utilisant NetworkManager et Firewalld. NetworkManager est incompatible avec les scripts par défaut systemd-networkd d'Ubuntu et ifupdown de Debian."
 ],
 "This volume group contains the root filesystem. Renaming it might require further changes to the bootloader configuration or kernel command line.": [
  null,
  "Ce groupe de volumes contient le système de fichiers racine. Renommer ce groupe pourrait nécessiter des modifications de la configuration du bootloader ou de la ligne de commande du noyau."
 ],
 "This volume group is missing some physical volumes.": [
  null,
  "Il manque certains volumes physiques dans ce groupe de volumes."
 ],
 "Tier": [
  null,
  "Niveau"
 ],
 "Time zone": [
  null,
  "Fuseau horaire"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Pour vous assurer que votre connexion n’est pas interceptée par un tiers malveillant, veuillez vérifier l’empreinte de la clé de l’hôte :"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Pour vérifier une empreinte digitale, exécutez les opérations suivantes sur $0 en étant physiquement assis devant la machine ou en passant par un réseau de confiance :"
 ],
 "Toggle date picker": [
  null,
  "Basculer le sélecteur de date"
 ],
 "Too much data": [
  null,
  "Trop de données"
 ],
 "Total size: $0": [
  null,
  "Taille totale : $0"
 ],
 "Tower": [
  null,
  "Tower"
 ],
 "Trust and add host": [
  null,
  "Faire confiance à l'hôte et l'ajouter"
 ],
 "Trust key": [
  null,
  "Clé de confiance"
 ],
 "Trying to synchronize with $0": [
  null,
  "Synchronisation avec $0 en cours d'essai"
 ],
 "Type": [
  null,
  "Type"
 ],
 "Type can only contain the characters 0 to 9, A to F, and \"-\".": [
  null,
  "Le type ne peut contenir que les caractères de 0 à 9 et de A à F, ainsi que le caractère \"-\"."
 ],
 "Type must be of the form NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN.": [
  null,
  "Le type doit être au format NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN."
 ],
 "Type must contain exactly two hexadecimal characters (0 to 9, A to F).": [
  null,
  "Le type doit contenir exactement deux caractères hexadécimaux (0 à 9, A à F)."
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "Impossible de se connecter à $0 en utilisant l'authentification par clé SSH. Veuillez fournir le mot de passe."
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Impossible de se connecter à $0. L’hôte n’accepte pas le mot de passe de connexion ou l’une de vos clés SSH."
 ],
 "Unable to reach server": [
  null,
  "Impossible d’atteindre le serveur"
 ],
 "Unable to remove mount": [
  null,
  "Impossible de supprimer le montage"
 ],
 "Unable to repair logical volume $0": [
  null,
  "Impossible de réparer le volume logique $0"
 ],
 "Unable to unmount filesystem": [
  null,
  "Impossible de démonter le système de fichiers"
 ],
 "Unexpected PackageKit error during installation of $0: $1": [
  null,
  "Erreur PackageKit inattendue lors de l'installation de $0 : $1"
 ],
 "Unexpected partitions": [
  null,
  "Partition inattendues"
 ],
 "Unformatted data": [
  null,
  "Données non formatées"
 ],
 "Unknown": [
  null,
  "Inconnu"
 ],
 "Unknown ($0)": [
  null,
  "Inconnu ( $0 )"
 ],
 "Unknown host name": [
  null,
  "Nom d’hôte inconnu"
 ],
 "Unknown host: $0": [
  null,
  "Hôte inconnu : $0"
 ],
 "Unknown type": [
  null,
  "Type inconnu"
 ],
 "Unlock": [
  null,
  "Déverrouiller"
 ],
 "Unlock automatically on boot": [
  null,
  "Déverrouiller automatiquement au démarrage"
 ],
 "Unlock before resizing": [
  null,
  "Déverrouillez-le avant de le redimensionner"
 ],
 "Unlock encrypted Stratis pool": [
  null,
  "Déverrouiller le pool Stratis chiffré"
 ],
 "Unlocking $target": [
  null,
  "Déverrouillage $target"
 ],
 "Unlocking disk": [
  null,
  "Déverrouillage du disque"
 ],
 "Unmount": [
  null,
  "Démonter"
 ],
 "Unmount filesystem $0": [
  null,
  "Démonter le système de fichiers $0"
 ],
 "Unmount now": [
  null,
  "Supprimer le montage maintenant"
 ],
 "Unmounting $target": [
  null,
  "Démonter $target"
 ],
 "Unrecognized data": [
  null,
  "Données non reconnues"
 ],
 "Unrecognized data can not be made smaller here": [
  null,
  "Les données non reconnues ne peuvent pas être plus petites ici"
 ],
 "Unrecognized data can not be made smaller here.": [
  null,
  "Les données non reconnues ne peuvent pas être plus petites ici."
 ],
 "Unsupported logical volume": [
  null,
  "Volume logique non pris en charge"
 ],
 "Untrusted host": [
  null,
  "Hôte non sécurisé"
 ],
 "Usage": [
  null,
  "Utilisation"
 ],
 "Usage of $0": [
  null,
  "Utilisation de $0"
 ],
 "Use": [
  null,
  "Utiliser"
 ],
 "Use $0": [
  null,
  "Utiliser $0"
 ],
 "Use compression": [
  null,
  "Utiliser la compression"
 ],
 "Use deduplication": [
  null,
  "Déduplication"
 ],
 "Used": [
  null,
  "Utilisé"
 ],
 "Useful for mounts that are optional or need interaction (such as passphrases)": [
  null,
  "Utile pour les montages facultatifs ou nécessitant une interaction (comme les phrases secrètes)"
 ],
 "User": [
  null,
  "Utilisateur"
 ],
 "Username": [
  null,
  "Nom d’utilisateur"
 ],
 "VDO backing devices can not be made smaller": [
  null,
  "Les sauvegardes VDO ne peuvent pas être plus petits"
 ],
 "VDO device $0": [
  null,
  "Périphérique VDO $0"
 ],
 "VDO filesystem volume (compression/deduplication)": [
  null,
  "Volume du système de fichiers VDO (compression/dédoublonnage)"
 ],
 "Vendor": [
  null,
  "Fournisseur"
 ],
 "Verify fingerprint": [
  null,
  "Vérifier l'empreinte digitale"
 ],
 "Verify key": [
  null,
  "Vérifier la clé"
 ],
 "Very securely erasing $target": [
  null,
  "Effacement très sécurisé de $target"
 ],
 "View all logs": [
  null,
  "Voir tous les journaux"
 ],
 "View automation script": [
  null,
  "Afficher le script d’automation"
 ],
 "View logs": [
  null,
  "Voir les journaux"
 ],
 "Virtual filesystem sizes are larger than the pool. Overprovisioning can not be disabled.": [
  null,
  "Le système de fichiers virtuel est plus grand que le pool. La surallocation ne peut pas être désactivée."
 ],
 "Virtual size": [
  null,
  "Taille virtuelle"
 ],
 "Virtual size limit": [
  null,
  "Taille virtuelle limite"
 ],
 "Visit firewall": [
  null,
  "Visitez le pare-feu"
 ],
 "Volatile memory backup failed": [
  null,
  "Échec de la sauvegarde de la mémoire volatile"
 ],
 "Volume group": [
  null,
  "Groupe de volumes"
 ],
 "Volume group is missing physical volumes": [
  null,
  "Il manque des volumes physiques dans le groupe de volumes"
 ],
 "Volume size is $0. Content size is $1.": [
  null,
  "La taille du volume est $0. La taille du contenu est $1."
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Attente de la fin des autres opérations de gestion du logiciel"
 ],
 "Weak password": [
  null,
  "Mot de passe faible"
 ],
 "Web Console for Linux servers": [
  null,
  "Console web pour serveurs Linux"
 ],
 "World wide name": [
  null,
  "World wide name"
 ],
 "Write-mostly": [
  null,
  "Écriture - le plus souvent"
 ],
 "Writing": [
  null,
  "Écriture"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Vous vous connectez à $0 pour la première fois."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Votre navigateur n’autorise pas le collage à partir du menu contextuel. Vous pouvez utiliser Maj+Insérer."
 ],
 "Your session has been terminated.": [
  null,
  "Votre session a été interrompue."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Votre session a expiré. Veuillez vous reconnecter."
 ],
 "Zone": [
  null,
  "Zone"
 ],
 "[binary data]": [
  null,
  "[données binaires]"
 ],
 "[no data]": [
  null,
  "[pas de données]"
 ],
 "after network": [
  null,
  "après le réseau"
 ],
 "backing device for VDO device": [
  null,
  "périphérique de sauvegarde pour périphérique VDO"
 ],
 "btrfs device": [
  null,
  "Périphérique btrfs"
 ],
 "btrfs devices": [
  null,
  "Périphériques btrfs"
 ],
 "btrfs filesystem": [
  null,
  "Système de fichiers btrfs"
 ],
 "btrfs subvolume": [
  null,
  "Sous-volume btrfs"
 ],
 "btrfs subvolume $0 of $1": [
  null,
  "Sous-volume btrfs $0 de $1"
 ],
 "btrfs subvolumes": [
  null,
  "Sous-volumes btrfs"
 ],
 "btrfs volume": [
  null,
  "Volume btrfs"
 ],
 "cache": [
  null,
  "cache"
 ],
 "data": [
  null,
  "données"
 ],
 "deactivate": [
  null,
  "désactiver"
 ],
 "delete": [
  null,
  "supprimer"
 ],
 "device of btrfs volume": [
  null,
  "périphérique d'un volume btrfs"
 ],
 "edit": [
  null,
  "modifier"
 ],
 "encrypted": [
  null,
  "chiffré"
 ],
 "format": [
  null,
  "formater"
 ],
 "grow": [
  null,
  "développer"
 ],
 "iSCSI Drive": [
  null,
  "Lecteur iSCSI"
 ],
 "iSCSI drives": [
  null,
  "Lecteurs iSCSI"
 ],
 "iSCSI portal": [
  null,
  "Portail iSCSI"
 ],
 "ignore failure": [
  null,
  "ignorer l'échec"
 ],
 "in less than a minute": [
  null,
  "dans moins d'une minute"
 ],
 "initialize": [
  null,
  "initialiser"
 ],
 "less than a minute ago": [
  null,
  "il y a moins d'une minute"
 ],
 "lock": [
  null,
  "verrouiller"
 ],
 "member of MDRAID device": [
  null,
  "membre d'un périphérique MDRAID"
 ],
 "member of Stratis pool": [
  null,
  "membre du pool Stratis"
 ],
 "mount": [
  null,
  "monter"
 ],
 "never mount at boot": [
  null,
  "ne jamais monter au démarrage"
 ],
 "none": [
  null,
  "aucun"
 ],
 "password quality": [
  null,
  "qualité mot de passe"
 ],
 "physical volume of LVM2 volume group": [
  null,
  "volume physique du groupe de volumes LVM2"
 ],
 "read only": [
  null,
  "lecture seule"
 ],
 "remove from LVM2": [
  null,
  "retirer de LVM2"
 ],
 "remove from MDRAID": [
  null,
  "retirer du MDRAID"
 ],
 "remove from btrfs volume": [
  null,
  "retirer d'un volume btrfs"
 ],
 "show less": [
  null,
  "montrer moins"
 ],
 "show more": [
  null,
  "montrer plus"
 ],
 "shrink": [
  null,
  "réduire"
 ],
 "snapshot": [
  null,
  "instantané"
 ],
 "stop": [
  null,
  "arrêter"
 ],
 "stop boot on failure": [
  null,
  "arrêter le démarrage en cas d'échec"
 ],
 "stopped": [
  null,
  "arrêté"
 ],
 "unknown target": [
  null,
  "cible inconnue"
 ],
 "unmount": [
  null,
  "Démonter"
 ],
 "unpartitioned space on $0": [
  null,
  "espace non partitionné sur $0"
 ],
 "using key description $0": [
  null,
  "utilisation de la clé avec pour description $0"
 ],
 "yes": [
  null,
  "oui"
 ],
 "format-bytes\u0004bytes": [
  null,
  "octets"
 ]
});
