cockpit.locale({
 "": {
  "plural-forms": (n) => n==0 ? 0 : n==1 ? 1 : n==2 ? 2 : n%100>=3 && n%100<=10 ? 3 : n%100>=11 ? 4 : 5,
  "language": "ar",
  "language-direction": "rtl"
 },
 "Diagnostic reports": [
  null,
  "تقارير التشخيص"
 ],
 "Kernel dump": [
  null,
  "عطب نواة النظام"
 ],
 "Managing LVMs": [
  null,
  "إدارة الـ LVMs"
 ],
 "Managing NFS mounts": [
  null,
  "إدارة عمليات تركيب NFS"
 ],
 "Managing RAIDs": [
  null,
  "إدارة وحدات RAID"
 ],
 "Managing VDOs": [
  null,
  "إدارة وحدات VDO"
 ],
 "Managing partitions": [
  null,
  "إدارة الأقسام"
 ],
 "Managing physical drives": [
  null,
  "إدراة الأقراص الفيزيائية"
 ],
 "Networking": [
  null,
  "التشبيك"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "التخزين"
 ],
 "Using LUKS encryption": [
  null,
  "استخدام تشفير LUKS"
 ],
 "Using Tang server": [
  null,
  "استخدام خادم Tang"
 ],
 "disk": [
  null,
  "قرص"
 ],
 "drive": [
  null,
  "قرص صلب"
 ],
 "encryption": [
  null,
  "التشفير"
 ],
 "filesystem": [
  null,
  "نظام الملفات"
 ],
 "format": [
  null,
  "تَهيئة"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "luks": [
  null,
  "luks"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "mount": [
  null,
  "ركِّب"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "partition": [
  null,
  "قسم"
 ],
 "raid": [
  null,
  "تجميع الأقراص"
 ],
 "tang": [
  null,
  "tang"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "unmount": [
  null,
  "إلغاء التركيب"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "volume": [
  null,
  "وحدة تخزين"
 ]
});
