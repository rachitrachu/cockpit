cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "ja",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 can not be made larger": [
  null,
  "$0 を大きくすることはできません"
 ],
 "$0 can not be made smaller": [
  null,
  "$0 を小さくすることはできません"
 ],
 "$0 can not be resized": [
  null,
  "$0 のサイズは変更できません"
 ],
 "$0 can not be resized here": [
  null,
  "ここでは $0 のサイズを変更できません"
 ],
 "$0 chunk size": [
  null,
  "$0 チャンクサイズ"
 ],
 "$0 data + $1 overhead used of $2 ($3)": [
  null,
  "$0 データ + $1 オーバーヘッドが $2 ($3) を使用しています"
 ],
 "$0 day": [
  null,
  "$0 日"
 ],
 "$0 disk is missing": [
  null,
  "$0 本のディスクがありません"
 ],
 "$0 disks": [
  null,
  "$0 ディスク"
 ],
 "$0 exited with code $1": [
  null,
  "$0 がコード $1 で終了しました"
 ],
 "$0 failed": [
  null,
  "$0 が失敗しました"
 ],
 "$0 filesystem": [
  null,
  "$0 ファイルシステム"
 ],
 "$0 hour": [
  null,
  "$0 時間"
 ],
 "$0 is in use": [
  null,
  "$0 は使用されています"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 は、あらゆるリポジトリーから利用できません。"
 ],
 "$0 key changed": [
  null,
  "$0 キーが変更されました"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 がシグナル $1 で終了しました"
 ],
 "$0 minute": [
  null,
  "$0 分"
 ],
 "$0 month": [
  null,
  "$0 カ月"
 ],
 "$0 partitions": [
  null,
  "$0 パーティション"
 ],
 "$0 slot remains": [
  null,
  "$0 スロットが残ります"
 ],
 "$0 synchronized": [
  null,
  "$0 同期済み"
 ],
 "$0 used of $1 ($2 saved)": [
  null,
  "$0 が $1 ($2 が保存) を使用しています"
 ],
 "$0 used, $1 total": [
  null,
  "利用済 $0、合計 $1"
 ],
 "$0 week": [
  null,
  "$0 週"
 ],
 "$0 will be installed.": [
  null,
  "$0 がインストールされます。"
 ],
 "$0 year": [
  null,
  "$0 年"
 ],
 "$name (from $host)": [
  null,
  "$name ($host)"
 ],
 "(Not part of target)": [
  null,
  "(ターゲットに含まれていません)"
 ],
 "(no assigned mount point)": [
  null,
  "(マウントポイントが割り当てられていません)"
 ],
 "(not mounted)": [
  null,
  "(マウントされていません)"
 ],
 "(recommended)": [
  null,
  "(推奨)"
 ],
 "1 MiB": [
  null,
  "1 MiB"
 ],
 "1 day": [
  null,
  "1 日"
 ],
 "1 hour": [
  null,
  "1 時間"
 ],
 "1 minute": [
  null,
  "1 分"
 ],
 "1 week": [
  null,
  "1 週間"
 ],
 "128 KiB": [
  null,
  "128 KiB"
 ],
 "16 KiB": [
  null,
  "16 KiB"
 ],
 "2 MiB": [
  null,
  "2 MiB"
 ],
 "20 minutes": [
  null,
  "20 分"
 ],
 "32 KiB": [
  null,
  "32 KiB"
 ],
 "4 KiB": [
  null,
  "4 KiB"
 ],
 "40 minutes": [
  null,
  "40 分"
 ],
 "5 minutes": [
  null,
  "5 分"
 ],
 "512 KiB": [
  null,
  "512 KiB"
 ],
 "6 hours": [
  null,
  "6 時間"
 ],
 "60 minutes": [
  null,
  "60 分"
 ],
 "64 KiB": [
  null,
  "64 KiB"
 ],
 "8 KiB": [
  null,
  "8 KiB"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Cockpit の互換バージョンが $0 にインストールされていません。"
 ],
 "A fatal error occurred during the self-test operation": [
  null,
  ""
 ],
 "A filesystem with this name exists already in this pool.": [
  null,
  "この名前のファイルシステムは、すでにこのプールに存在します。"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "$0 で新しい SSH キーが $2 の $1 用に作成され、$5 上の $3 の $3 ファイルに追加されました。"
 ],
 "A pool with this name exists already.": [
  null,
  "この名前を持つプールはすでに存在します。"
 ],
 "A volume group with missing physical volumes can not be renamed.": [
  null,
  "物理ボリュームが欠落しているボリュームグループの名前は変更できません。"
 ],
 "Abort test": [
  null,
  ""
 ],
 "Aborted": [
  null,
  ""
 ],
 "Aborted by a Controller Level Reset": [
  null,
  ""
 ],
 "Aborted due to a removal of a namespace from the namespace inventory": [
  null,
  ""
 ],
 "Aborted due to a sanitize operation": [
  null,
  ""
 ],
 "Aborted due to the processing of a Format NVM command": [
  null,
  ""
 ],
 "Aborted for unknown reason": [
  null,
  ""
 ],
 "Absent": [
  null,
  "不在"
 ],
 "Acceptable password": [
  null,
  "受け入れられるパスワード"
 ],
 "Action": [
  null,
  "アクション"
 ],
 "Actions": [
  null,
  "動作"
 ],
 "Activate": [
  null,
  "有効化"
 ],
 "Activate before resizing": [
  null,
  "リサイズする前に有効化"
 ],
 "Activating $target": [
  null,
  "$target のアクティベート"
 ],
 "Add": [
  null,
  "追加"
 ],
 "Add $0": [
  null,
  "$0 の追加"
 ],
 "Add Network Bound Disk Encryption": [
  null,
  "ネットワークバウンドディスクの暗号化追加"
 ],
 "Add Tang keyserver": [
  null,
  "Tang キーサーバーの追加"
 ],
 "Add a bitmap": [
  null,
  "bitmap の追加"
 ],
 "Add block devices": [
  null,
  "ブロックデバイスの追加"
 ],
 "Add disk": [
  null,
  "ディスクの追加"
 ],
 "Add disks": [
  null,
  "ディスクの追加"
 ],
 "Add iSCSI portal": [
  null,
  "iSCSI ポータルの追加"
 ],
 "Add key": [
  null,
  "キーの追加"
 ],
 "Add keyserver": [
  null,
  "キーサーバーの追加"
 ],
 "Add passphrase": [
  null,
  "パスフレーズの追加"
 ],
 "Add physical volume": [
  null,
  "物理ボリュームの追加"
 ],
 "Adding \"$0\" to encryption options": [
  null,
  "暗号化オプションへの \"$0\" の追加"
 ],
 "Adding \"$0\" to filesystem options": [
  null,
  "ファイルシステムオプションへの \"$0\" の追加"
 ],
 "Adding a keyserver requires unlocking the pool. Please provide the existing pool passphrase.": [
  null,
  "キーサーバーを追加するには、プールのロック解除が必要です。既存のプールパスフレーズを提供してください。"
 ],
 "Adding key": [
  null,
  "キーの追加"
 ],
 "Adding physical volume to $target": [
  null,
  "$target への物理ボリュームの追加"
 ],
 "Adding rd.neednet=1 to kernel command line": [
  null,
  "カーネルコマンドラインへの rd.neednet=1 の追加"
 ],
 "Additional packages:": [
  null,
  "追加のパッケージ:"
 ],
 "Address": [
  null,
  "アドレス"
 ],
 "Address cannot be empty": [
  null,
  "アドレスは空欄にできません"
 ],
 "Address is not a valid URL": [
  null,
  "アドレスの URL は有効ではありません"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Cockpit Web コンソールでの管理"
 ],
 "Advanced TCA": [
  null,
  "高度な TCA"
 ],
 "All $0 selected physical volumes are needed for the chosen layout.": [
  null,
  "選択したレイアウトには、選択した $0 の物理ボリュームがすべて必要です。"
 ],
 "All-in-one": [
  null,
  "オールインワン"
 ],
 "Allocated": [
  null,
  "割り当て済み"
 ],
 "Allow overprovisioning": [
  null,
  "オーバー プロビジョンを許可"
 ],
 "An additional $0 must be selected": [
  null,
  "追加の $0 を選択する必要があります"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Ansible ロールのドキュメント"
 ],
 "Appropriate for critical mounts, such as /var": [
  null,
  "/var などの重要なマウントに適しています"
 ],
 "Assessment": [
  null,
  "評価"
 ],
 "At boot": [
  null,
  "起動時"
 ],
 "At least $0 disk is needed.": [
  null,
  "少なくとも $0 個のディスクが必要です。"
 ],
 "At least one block device is needed.": [
  null,
  "1 つ以上のブロックデバイスが必要です。"
 ],
 "At least one disk is needed.": [
  null,
  "1 つ以上のディスクが必要です。"
 ],
 "At least one subvolume needs to be mounted": [
  null,
  "少なくとも1つのサブボリュームをマウントする必要があります"
 ],
 "Authentication": [
  null,
  "認証"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Cockpit Web コンソールでの特権タスクの実行には、認証が必要です"
 ],
 "Authentication required": [
  null,
  "認証が必要です"
 ],
 "Authorize SSH key": [
  null,
  "SSH キーの認証"
 ],
 "Automatically using NTP": [
  null,
  "NTP を自動的に使用"
 ],
 "Automatically using additional NTP servers": [
  null,
  "追加の NTP サーバーを自動的に使用"
 ],
 "Automatically using specific NTP servers": [
  null,
  "特定の NTP サーバーを自動的に使用"
 ],
 "Automation script": [
  null,
  "オートメーションスクリプト"
 ],
 "Available targets on $0": [
  null,
  "$0 で利用可能なターゲット"
 ],
 "BIOS boot partition": [
  null,
  "BIOS ブートパーティション"
 ],
 "Blade": [
  null,
  "ブレード"
 ],
 "Blade enclosure": [
  null,
  "ブレードエンクロージャー"
 ],
 "Block device": [
  null,
  "ブロックデバイス"
 ],
 "Block device for filesystems": [
  null,
  "ファイルシステム用ブロックデバイス"
 ],
 "Block devices": [
  null,
  "ブロックデバイス"
 ],
 "Blocked": [
  null,
  "ブロック済み"
 ],
 "Boot fails if filesystem does not mount, preventing remote access": [
  null,
  "ファイルシステムがマウントされず、リモートアクセスができないと、起動に失敗します"
 ],
 "Boot still succeeds when filesystem does not mount": [
  null,
  "ファイルシステムがマウントされなくても、起動は成功します"
 ],
 "Bus expansion chassis": [
  null,
  "バス拡張シャーシ"
 ],
 "Cache": [
  null,
  "キャッシュ"
 ],
 "Cancel": [
  null,
  "取り消し"
 ],
 "Cannot forward login credentials": [
  null,
  "ログインのクレデンシャルをフォワードできません"
 ],
 "Cannot schedule event in the past": [
  null,
  "過去のイベントはスケジュールできません"
 ],
 "Capacity": [
  null,
  "容量"
 ],
 "Category": [
  null,
  "カテゴリー"
 ],
 "Change": [
  null,
  "変更"
 ],
 "Change iSCSI initiator name": [
  null,
  "iSCSI イニシエーター名の変更"
 ],
 "Change label": [
  null,
  "ラベルの変更"
 ],
 "Change passphrase": [
  null,
  "パスフレーズの変更"
 ],
 "Change system time": [
  null,
  "システム時間の変更"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "キーを変更すると、オペレーティングシステムを再インストールすることになることが多くあります。ただし、予期しない変更により接続の傍受が試行される場合もあります。"
 ],
 "Changing partition types might prevent the system from booting.": [
  null,
  "パーティションタイプを変更すると、システムが起動しなくなる可能性があります。"
 ],
 "Check that the SHA-256 or SHA-1 hash from the command matches this dialog.": [
  null,
  "そのコマンドの SHA-256 または SHA-1 が、このダイアログに一致するかどうかを確認します。"
 ],
 "Check the key hash with the Tang server.": [
  null,
  "キーハッシュを Tang サーバーで確認します。"
 ],
 "Checking $target": [
  null,
  "$target の確認中"
 ],
 "Checking MDRAID device $target": [
  null,
  "MDRAID デバイス $target の確認"
 ],
 "Checking and repairing MDRAID device $target": [
  null,
  "MDRAID デバイス $target の確認および修復"
 ],
 "Checking filesystem usage": [
  null,
  "ファイルシステム利用率を確認中"
 ],
 "Checking for $0 package": [
  null,
  "$0 パッケージの確認中"
 ],
 "Checking for NBDE support in the initrd": [
  null,
  "initrd での NBDE サポートの確認中"
 ],
 "Checking installed software": [
  null,
  "インストールされたソフトウェアの確認中"
 ],
 "Chunk size": [
  null,
  "チャンクサイズ"
 ],
 "Cleaning up for $target": [
  null,
  "$target のクリーンアップ中"
 ],
 "Clear input value": [
  null,
  "入力値の消去"
 ],
 "Cleartext device": [
  null,
  "cleartext デバイス"
 ],
 "Close": [
  null,
  "閉じる"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Cockpit の NetworkManager と Firewalld の設定"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit は該当するホストに接続できませんでした。"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit は、Web ブラウザーで Linux サーバーを簡単に管理できるサーバーマネージャーです。端末と Web ツールを区別せずに使用できます。Cockpit で起動されたサービスは端末で停止できます。同様に、端末でエラーが発生した場合は、そのエラーを Cockpit ジャーナルインターフェースで確認できます。"
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit にはシステム上のそのソフトウェアとの互換性がありません。"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit はインストールされていません"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit はシステムにインストールされていません。"
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit は経験が少ないシステム管理者に最適です。これらのシステム管理者はストレージの管理、ジャーナルの検査、サービスの起動および停止などの単純なタスクを簡単に実行できるようになります。また、複数のサーバーを同時に監視および管理できます。これらのサーバーはクリックするだけで追加できます。追加後に、ご使用のマシンは他のマシンを管理するようになります。"
 ],
 "Collect and package diagnostic and support data": [
  null,
  "診断およびサポートデータの収集とパッケージ化"
 ],
 "Collect kernel crash dumps": [
  null,
  "カーネルクラッシュダンプの収集"
 ],
 "Command": [
  null,
  "コマンド"
 ],
 "Compact PCI": [
  null,
  "PCI の圧縮"
 ],
 "Compatible with all systems and devices (MBR)": [
  null,
  "すべてのシステムおよびデバイスとの互換性あり (MBR)"
 ],
 "Compatible with modern system and hard disks > 2TB (GPT)": [
  null,
  "最新のシステムとの互換性があり、ハードディスクが 2TB よりも大きい (GPT)"
 ],
 "Completed with a segment that failed and the segment that failed is not known": [
  null,
  ""
 ],
 "Completed with one or more failed segments": [
  null,
  ""
 ],
 "Compression": [
  null,
  "圧縮"
 ],
 "Confirm": [
  null,
  "確認"
 ],
 "Confirm deletion of $0": [
  null,
  "$0 の削除を確定する"
 ],
 "Confirm key password": [
  null,
  "キーパスワードの確認"
 ],
 "Confirm removal with an alternate passphrase": [
  null,
  "代替のパスフレーズで削除を確認"
 ],
 "Confirm stopping of $0": [
  null,
  "$0 の停止を確定する"
 ],
 "Connection has timed out.": [
  null,
  "接続がタイムアウトしました。"
 ],
 "Convertible": [
  null,
  "変換可能"
 ],
 "Copied": [
  null,
  "コピー済み"
 ],
 "Copy": [
  null,
  "コピー"
 ],
 "Copy to clipboard": [
  null,
  "クリップボードにコピー"
 ],
 "Create": [
  null,
  "作成"
 ],
 "Create $0": [
  null,
  "$0 を作成"
 ],
 "Create LVM2 volume group": [
  null,
  "LVM2 ボリュームグループの作成"
 ],
 "Create MDRAID device": [
  null,
  "MDRAID デバイスの作成"
 ],
 "Create RAID device": [
  null,
  "RAID デバイスの作成"
 ],
 "Create Stratis pool": [
  null,
  "Stratis プールの作成"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "新しい SSH キーを作成して承認します"
 ],
 "Create a snapshot of filesystem $0": [
  null,
  "ファイルシステム $0 のスナップショットの作成"
 ],
 "Create and mount": [
  null,
  "作成およびマウント"
 ],
 "Create and start": [
  null,
  "作成および起動"
 ],
 "Create filesystem": [
  null,
  "ファイルシステムの作成"
 ],
 "Create logical volume": [
  null,
  "論理ボリュームの作成"
 ],
 "Create new filesystem": [
  null,
  "ファイルシステムの新規作成"
 ],
 "Create new logical volume": [
  null,
  "論理ボリュームの新規作成"
 ],
 "Create new task file with this content.": [
  null,
  "このコンテンツで新しいタスクファイルを作成します。"
 ],
 "Create new thinly provisioned logical volume": [
  null,
  "シンプロビジョニングされた論理ボリュームの新規作成"
 ],
 "Create only": [
  null,
  "作成のみ"
 ],
 "Create partition": [
  null,
  "パーティションの作成"
 ],
 "Create partition on $0": [
  null,
  "$0 上でのパーティションの作成"
 ],
 "Create partition table": [
  null,
  "パーティションテーブルの作成"
 ],
 "Create snapshot": [
  null,
  "スナップショットの作成"
 ],
 "Create snapshot and mount": [
  null,
  "スナップショットの作成およびマウント"
 ],
 "Create snapshot only": [
  null,
  "スナップショットの作成のみ"
 ],
 "Create storage device": [
  null,
  "ストレージデバイスの作成"
 ],
 "Create subvolume": [
  null,
  "サブボリュームの作成"
 ],
 "Create thin volume": [
  null,
  "シンボリュームの作成"
 ],
 "Create volume group": [
  null,
  "ボリュームグループの作成"
 ],
 "Creating LVM2 volume group $target": [
  null,
  "LVM2 ボリュームグループ $target の作成"
 ],
 "Creating MDRAID device $target": [
  null,
  "MDRAID デバイス $target の作成"
 ],
 "Creating VDO device": [
  null,
  "VDO デバイスの作成"
 ],
 "Creating filesystem on $target": [
  null,
  "$target 上でのファイルシステムの作成"
 ],
 "Creating logical volume $target": [
  null,
  "論理ボリューム $target の作成"
 ],
 "Creating partition $target": [
  null,
  "パーティション $target の作成"
 ],
 "Creating snapshot of $target": [
  null,
  "$target のスナップショットの作成"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Currently in use": [
  null,
  "現在使用中"
 ],
 "Custom": [
  null,
  "カスタム"
 ],
 "Custom mount options": [
  null,
  "カスタムのマウントオプション"
 ],
 "Custom type": [
  null,
  "カスタムタイプ"
 ],
 "Data": [
  null,
  "データ"
 ],
 "Data used": [
  null,
  "使用済みデータ"
 ],
 "Data will be stored as two copies and also in an alternating fashion on the selected physical volumes, to improve both reliability and performance. At least four volumes need to be selected.": [
  null,
  "信頼性とパフォーマンスを向上させるために、データは 2 つのコピーとして、複数の選択した物理ボリュームに交互に保存されます。4 つ以上のボリュームを選択する必要があります。"
 ],
 "Data will be stored as two or more copies on the selected physical volumes, to improve reliability. At least two volumes need to be selected.": [
  null,
  "信頼性を向上させるために、データは複数の選択した物理ボリュームに 2 つ以上のコピーとして保存されます。2 つ以上のボリュームを選択する必要があります。"
 ],
 "Data will be stored on the selected physical volumes in an alternating fashion to improve performance. At least two volumes need to be selected.": [
  null,
  "パフォーマンスを向上させるために、データは複数の選択した物理ボリュームに交互に保存されます。2 つ以上のボリュームを選択する必要があります。"
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. At least three volumes need to be selected.": [
  null,
  "物理ボリュームの 1 つが失われてもデータに影響しないように、データは複数の選択した物理ボリュームに保存されます。3 つ以上のボリュームを選択する必要があります。"
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. Data is also stored in an alternating fashion to improve performance. At least three volumes need to be selected.": [
  null,
  "物理ボリュームの 1 つが失われてもデータに影響しないように、データは複数の選択した物理ボリュームに保存されます。また、パフォーマンスを向上させるために、データは交互に保存されます。3 つ以上のボリュームを選択する必要があります。"
 ],
 "Data will be stored on the selected physical volumes so that up to two of them can be lost at the same time without affecting the data. Data is also stored in an alternating fashion to improve performance. At least five volumes need to be selected.": [
  null,
  "物理ボリュームが同時に 2 つまで失われてもデータに影響しないように、データは複数の選択した物理ボリュームに保存されます。また、パフォーマンスを向上させるために、データは交互に保存されます。5 つ以上のボリュームを選択する必要があります。"
 ],
 "Data will be stored on the selected physical volumes without any additional redundancy or performance improvements.": [
  null,
  "データは選択した物理ボリュームに保存されます。冗長性やパフォーマンスの向上はありません。"
 ],
 "Deactivate": [
  null,
  "解除"
 ],
 "Deactivate logical volume $0/$1?": [
  null,
  "論理ボリューム $0/$1 を非アクティブ化しますか?"
 ],
 "Deactivating $target": [
  null,
  "$target の非アクティブ化"
 ],
 "Dedicated parity (RAID 4)": [
  null,
  "専用パリティー (RAID 4)"
 ],
 "Deduplication": [
  null,
  "重複"
 ],
 "Degraded": [
  null,
  ""
 ],
 "Delay": [
  null,
  "遅延"
 ],
 "Delete": [
  null,
  "削除"
 ],
 "Delete group": [
  null,
  "グループの削除"
 ],
 "Delete pool": [
  null,
  "プールの削除"
 ],
 "Deleting $target": [
  null,
  "$target の削除中"
 ],
 "Deleting LVM2 volume group $target": [
  null,
  "LVM2 ボリュームグループ $target の削除"
 ],
 "Deleting a Stratis pool will erase all data it contains.": [
  null,
  "Stratis プールを削除すると、Stratis プールに含まれるデータがすべて消去されます。"
 ],
 "Deleting a filesystem will delete all data in it.": [
  null,
  "ファイルシステムを削除すると、そのファイルシステム内のすべてのデータが削除されます。"
 ],
 "Deleting a logical volume will delete all data in it.": [
  null,
  "論理ボリュームを削除すると、論理ボリューム内のすべてのデータが削除されます。"
 ],
 "Deleting a partition will delete all data in it.": [
  null,
  "パーティションを削除すると、パーティション内のすべてのデータが削除されます。"
 ],
 "Deleting erases all data on a MDRAID device.": [
  null,
  "削除すると、MDRAID デバイスのデータがすべて消去されます。"
 ],
 "Deleting erases all data on a VDO device.": [
  null,
  "削除すると、VDO デバイスのデータがすべて消去されます。"
 ],
 "Deleting erases all data on a volume group.": [
  null,
  "削除すると、ボリュームグループのデータがすべて消去されます。"
 ],
 "Description": [
  null,
  "説明"
 ],
 "Desktop": [
  null,
  "デスクトップ"
 ],
 "Detachable": [
  null,
  "割り当て解除可能"
 ],
 "Device": [
  null,
  "デバイス"
 ],
 "Device contains unrecognized data": [
  null,
  "デバイスに識別できないデータがある"
 ],
 "Device file": [
  null,
  "デバイスファイル"
 ],
 "Device health (SMART)": [
  null,
  ""
 ],
 "Device is read-only": [
  null,
  "デバイスは読み取り専用です"
 ],
 "Device number": [
  null,
  "デバイス番号"
 ],
 "Diagnostic reports": [
  null,
  "診断レポート"
 ],
 "Did not complete": [
  null,
  ""
 ],
 "Disconnect": [
  null,
  "切断"
 ],
 "Disk is OK": [
  null,
  "ディスクは OK です"
 ],
 "Disk is failing": [
  null,
  "ディスクで障害が発生中"
 ],
 "Disk passphrase": [
  null,
  "ディスクのパスフレーズ"
 ],
 "Disks": [
  null,
  "ディスク"
 ],
 "Dismiss": [
  null,
  "解除"
 ],
 "Distributed parity (RAID 5)": [
  null,
  "分散パリティー (RAID 5)"
 ],
 "Do not mount": [
  null,
  "マウントしない"
 ],
 "Do not mount automatically on boot": [
  null,
  "起動時に自動的にマウントしない"
 ],
 "Docking station": [
  null,
  "ドッキングステーション"
 ],
 "Does not mount during boot": [
  null,
  "起動時にマウントしません"
 ],
 "Double distributed parity (RAID 6)": [
  null,
  "ダブル分散パリティー (RAID 6)"
 ],
 "Downloading $0": [
  null,
  "$0 をダウンロード中"
 ],
 "Drive": [
  null,
  "ドライブ"
 ],
 "Dual rank": [
  null,
  "デュアルランク"
 ],
 "EFI system partition": [
  null,
  "EFI システムパーティション"
 ],
 "Edit": [
  null,
  "編集"
 ],
 "Edit Tang keyserver": [
  null,
  "Tang キーサーバーを編集する"
 ],
 "Edit mount point": [
  null,
  "マウントポイントの編集"
 ],
 "Editing a key requires a free slot": [
  null,
  "キーの編集にはフリースロットが必要です"
 ],
 "Ejecting $target": [
  null,
  "$target の取り出し中"
 ],
 "Embedded PC": [
  null,
  "組み込み PC"
 ],
 "Emptying $target": [
  null,
  "$target を空にしています"
 ],
 "Enabling $0": [
  null,
  "$0 の有効化"
 ],
 "Encrypt data with a Tang keyserver": [
  null,
  "Tang キーサーバーでデータを暗号化する"
 ],
 "Encrypt data with a passphrase": [
  null,
  "パスフレーズでデータを暗号化する"
 ],
 "Encrypted $0": [
  null,
  "暗号化された $0"
 ],
 "Encrypted Stratis pool": [
  null,
  "暗号化された Stratis プール"
 ],
 "Encrypted logical volume of $0": [
  null,
  "暗号化された $0 の論理ボリューム"
 ],
 "Encrypted partition of $0": [
  null,
  "暗号化された $0 のパーティション"
 ],
 "Encryption": [
  null,
  "暗号化"
 ],
 "Encryption options": [
  null,
  "暗号化オプション"
 ],
 "Encryption type": [
  null,
  "暗号化タイプ"
 ],
 "Erasing $target": [
  null,
  "$target の削除中"
 ],
 "Error": [
  null,
  "エラー"
 ],
 "Error installing $0: PackageKit is not installed": [
  null,
  "$0 のインストールエラー: PackageKit はインストールされていません"
 ],
 "Exactly $0 physical volumes must be selected": [
  null,
  "$0 個の物理ボリュームを選択する必要があります"
 ],
 "Exactly $0 physical volumes need to be selected, one for each stripe of the logical volume.": [
  null,
  "論理ボリュームのストライプごとに 1 つずつ、合計で $0 個の物理ボリュームを選択する必要があります。"
 ],
 "Excellent password": [
  null,
  "優れたパスワード"
 ],
 "Expansion chassis": [
  null,
  "拡張シャーシ"
 ],
 "Extended partition": [
  null,
  "拡張パーティション"
 ],
 "Failed": [
  null,
  "失敗"
 ],
 "Failed (Damaged)": [
  null,
  ""
 ],
 "Failed (Electrical)": [
  null,
  ""
 ],
 "Failed to change password": [
  null,
  "パスワードの変更に失敗しました"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "firewalld での $0 の有効化に失敗しました"
 ],
 "Filesystem": [
  null,
  "ファイルシステム"
 ],
 "Filesystem is locked": [
  null,
  "ファイルシステムがロックされています"
 ],
 "Filesystem is mounted read-only": [
  null,
  "ファイルシステムは読み取り専用でマウントされています"
 ],
 "Filesystem name": [
  null,
  "ファイルシステム名"
 ],
 "Filesystem outside the target": [
  null,
  "ターゲット外のファイルシステム"
 ],
 "Filesystems are already mounted below this mountpoint.": [
  null,
  "このマウントポイントの下にはファイルシステムがマウント済みです。"
 ],
 "Firmware version": [
  null,
  "ファームウェアバージョン"
 ],
 "Fix NBDE support": [
  null,
  "NBDE サポートの修正"
 ],
 "Format": [
  null,
  "フォーマット"
 ],
 "Format $0": [
  null,
  "$0 のフォーマット"
 ],
 "Format and mount": [
  null,
  "フォーマットおよびマウント"
 ],
 "Format and start": [
  null,
  "フォーマットおよび起動"
 ],
 "Format only": [
  null,
  "フォーマットのみ"
 ],
 "Formatting erases all data on a storage device.": [
  null,
  "フォーマットすると、ストレージデバイスのすべてのデータが削除されます。"
 ],
 "Free space": [
  null,
  "空き領域"
 ],
 "Go to now": [
  null,
  "今すぐ移動"
 ],
 "Grow": [
  null,
  "増加"
 ],
 "Grow content": [
  null,
  "コンテンツを増やす"
 ],
 "Grow logical size of $0": [
  null,
  "$0 の論理サイズを増加"
 ],
 "Grow logical volume": [
  null,
  "論理ボリュームの増加"
 ],
 "Grow partition": [
  null,
  "パーティションの拡張"
 ],
 "Grow the pool to take all space": [
  null,
  "すべての領域を使用してプールを拡大する"
 ],
 "Grow to take all space": [
  null,
  "すべての領域を使用して増加"
 ],
 "Handheld": [
  null,
  "ハンドヘルド"
 ],
 "Hard Disk Drive": [
  null,
  "ハードディスクドライブ"
 ],
 "Hide confirmation password": [
  null,
  "確認パスワードの非表示"
 ],
 "Hide password": [
  null,
  "パスワードの非表示"
 ],
 "Host key is incorrect": [
  null,
  "ホスト鍵が正しくありません"
 ],
 "How to check": [
  null,
  "チェック方法"
 ],
 "I confirm I want to lose this data forever": [
  null,
  "このデータが完全に削除されることに同意します"
 ],
 "ID": [
  null,
  "ID"
 ],
 "INTERNAL ERROR - This logical volume is marked as active and should have an associated block device. However, no such block device could be found.": [
  null,
  "内部エラー - この論理ボリュームはアクティブとマークされており、関連付けられたブロックデバイスが必要です。しかし、そのようなブロックデバイスは見つかりません。"
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "フィンガープリントが一致している場合は、'ホストを信頼して追加' をクリックします。一致していない場合は、接続せずに管理者にお問い合わせください。"
 ],
 "Important data might be deleted:": [
  null,
  "重要なデータが削除される可能性があります:"
 ],
 "In a terminal, run: ": [
  null,
  "ターミナルで以下を実行します: "
 ],
 "In sync": [
  null,
  "同期"
 ],
 "Inactive logical volume": [
  null,
  "非アクティブな論理ボリューム"
 ],
 "Inconsistent filesystem mount": [
  null,
  "一貫性のないシステムマウント"
 ],
 "Index memory": [
  null,
  "インデックスメモリー"
 ],
 "Initialize": [
  null,
  "初期化"
 ],
 "Initialize disk $0": [
  null,
  "ディスク $0 を初期化します"
 ],
 "Initializing erases all data on a disk.": [
  null,
  "初期化すると、ディスク上の全データが削除されます。"
 ],
 "Install": [
  null,
  "インストール"
 ],
 "Install NFS support": [
  null,
  "NFS サポートをインストールする"
 ],
 "Install Stratis support": [
  null,
  "Stratis サポートをインストールする"
 ],
 "Install software": [
  null,
  "ソフトウェアをインストール"
 ],
 "Installing $0": [
  null,
  "$0 をインストール中"
 ],
 "Installing $0 would remove $1.": [
  null,
  "$0 をインストールすると、$1 が削除されます。"
 ],
 "Installing packages": [
  null,
  "パッケージのインストール"
 ],
 "Internal error": [
  null,
  "内部エラー"
 ],
 "Invalid date format": [
  null,
  "無効な日付形式"
 ],
 "Invalid date format and invalid time format": [
  null,
  "無効な日付形式と無効な時間形式"
 ],
 "Invalid file permissions": [
  null,
  "無効なファイルパーミッション"
 ],
 "Invalid time format": [
  null,
  "無効な時間形式"
 ],
 "Invalid timezone": [
  null,
  "無効なタイムゾーン"
 ],
 "Invalid username or password": [
  null,
  "無効なユーザー名またはパスワード"
 ],
 "IoT gateway": [
  null,
  "IoT ゲートウェイ"
 ],
 "Jobs": [
  null,
  "ジョブ"
 ],
 "Kernel dump": [
  null,
  "カーネルダンプ"
 ],
 "Key password": [
  null,
  "キーパスワード"
 ],
 "Key slots with unknown types can not be edited here": [
  null,
  "タイプ不明のキースロットは、ここでは編集できません"
 ],
 "Key source": [
  null,
  "キーソース"
 ],
 "Keys": [
  null,
  "キー"
 ],
 "Keyserver": [
  null,
  "キーサーバー"
 ],
 "Keyserver address": [
  null,
  "キーサーバーのアドレス"
 ],
 "Keyserver removal may prevent unlocking $0.": [
  null,
  "キーサーバーの削除により、$0 のロック解除ができない可能性があります。"
 ],
 "LVM2 VDO pool": [
  null,
  "LVM2 VDO プール"
 ],
 "LVM2 logical volume": [
  null,
  "LVM2 論理ボリューム"
 ],
 "LVM2 logical volumes": [
  null,
  "LVM2 論理ボリューム"
 ],
 "LVM2 physical volume": [
  null,
  "LVM2 物理ボリューム"
 ],
 "LVM2 physical volumes": [
  null,
  "LVM2 物理ボリューム"
 ],
 "LVM2 volume group": [
  null,
  "LVM2 ボリュームグループ"
 ],
 "LVM2 volume group $0": [
  null,
  "LVM2 ボリュームグループ $0"
 ],
 "Label": [
  null,
  "ラベル"
 ],
 "Laptop": [
  null,
  "ラップトップ"
 ],
 "Last cannot be removed": [
  null,
  "最後のものは削除できません"
 ],
 "Last disk can not be removed": [
  null,
  "最後のディスクは削除できません"
 ],
 "Last modified: $0": [
  null,
  "最終更新日: $0"
 ],
 "Layout": [
  null,
  "レイアウト"
 ],
 "Learn more": [
  null,
  "もっと詳しく"
 ],
 "Limit size": [
  null,
  "サイズ制限"
 ],
 "Limit virtual filesystem size": [
  null,
  "仮想ファイルシステムのサイズ制限"
 ],
 "Linear": [
  null,
  "リニア"
 ],
 "Linux filesystem data": [
  null,
  "Linux ファイルシステムデータ"
 ],
 "Linux swap space": [
  null,
  "Linux スワップ領域"
 ],
 "Loading system modifications...": [
  null,
  "システム変更をロード中..."
 ],
 "Loading...": [
  null,
  "ロード中..."
 ],
 "Local mount point": [
  null,
  "ローカルマウントポイント"
 ],
 "Local storage": [
  null,
  "ローカルストレージ"
 ],
 "Location": [
  null,
  "場所"
 ],
 "Lock": [
  null,
  "ロック"
 ],
 "Lock $0?": [
  null,
  "$0 をロックします？"
 ],
 "Locked data": [
  null,
  "ロックされたデータ"
 ],
 "Locked encrypted device might contain data": [
  null,
  "ロックされた暗号化デバイスにはデータが含まれている可能性があります"
 ],
 "Locking $target": [
  null,
  "$target のロック中"
 ],
 "Log in": [
  null,
  "ログイン"
 ],
 "Log in to $0": [
  null,
  "$0 へのログイン"
 ],
 "Log messages": [
  null,
  "ログメッセージ"
 ],
 "Logical": [
  null,
  "論理"
 ],
 "Logical Volume Manager partition": [
  null,
  "論理ボリュームマネージャーのパーティション"
 ],
 "Logical size": [
  null,
  "論理サイズ"
 ],
 "Logical volume": [
  null,
  "論理ボリューム"
 ],
 "Logical volume (snapshot)": [
  null,
  "論理ボリューム (スナップショット)"
 ],
 "Logical volume of $0": [
  null,
  "$0 の論理ボリューム"
 ],
 "Login failed": [
  null,
  "ログインが失敗しました"
 ],
 "Low profile desktop": [
  null,
  "低プロファイルデスクトップ"
 ],
 "Lunch box": [
  null,
  "ランチボックス"
 ],
 "MDRAID device": [
  null,
  "MDRAID デバイス"
 ],
 "MDRAID device $0": [
  null,
  "MDRAID デバイス $0"
 ],
 "MDRAID device is recovering": [
  null,
  "MDRAID デバイスが復旧中です"
 ],
 "MDRAID device must be running": [
  null,
  "MDRAID デバイスが実行中である必要があります"
 ],
 "MDRAID disk": [
  null,
  "MDRAID ディスク"
 ],
 "MDRAID disks": [
  null,
  "MDRAID ディスク"
 ],
 "Main server chassis": [
  null,
  "メインサーバーシャーシ"
 ],
 "Manage storage": [
  null,
  "ストレージの管理"
 ],
 "Manually": [
  null,
  "手動"
 ],
 "Marking $target as faulty": [
  null,
  "$target を問題があるものとしてマークする"
 ],
 "Media drive": [
  null,
  "メディアドライブ"
 ],
 "Message to logged in users": [
  null,
  "ログインしているユーザーへのメッセージ"
 ],
 "Metadata used": [
  null,
  "使用済みメタデータ"
 ],
 "Mini PC": [
  null,
  "ミニ PC"
 ],
 "Mini tower": [
  null,
  "ミニタワー"
 ],
 "Mirrored (RAID 1)": [
  null,
  "ミラー (RAID 1)"
 ],
 "Model": [
  null,
  "モデル"
 ],
 "Modifying $target": [
  null,
  "$target の変更"
 ],
 "Mount": [
  null,
  "マウント"
 ],
 "Mount Point": [
  null,
  "マウントポイント"
 ],
 "Mount after network becomes available, ignore failure": [
  null,
  "ネットワークが利用可能になった後にマウントし、失敗を無視します"
 ],
 "Mount also automatically on boot": [
  null,
  "起動時に自動的にもマウントします"
 ],
 "Mount at boot": [
  null,
  "起動時にマウント"
 ],
 "Mount automatically on $0 on boot": [
  null,
  "起動時に自動的に $0 にマウントします"
 ],
 "Mount before services start": [
  null,
  "サービス起動前にマウントします"
 ],
 "Mount configuration": [
  null,
  "マウント設定"
 ],
 "Mount filesystem": [
  null,
  "ファイルシステムをマウントします"
 ],
 "Mount now": [
  null,
  "今すぐマウントします"
 ],
 "Mount on $0 now": [
  null,
  "$0 に今すぐマウントします"
 ],
 "Mount options": [
  null,
  "マウントオプション"
 ],
 "Mount point": [
  null,
  "マウントポイント"
 ],
 "Mount point cannot be empty": [
  null,
  "マウントポイントは空欄にできません"
 ],
 "Mount point cannot be empty.": [
  null,
  "マウントポイントは空欄にできません。"
 ],
 "Mount point is already used for $0": [
  null,
  "マウントポイントはすでに $0 で使用しています"
 ],
 "Mount point must start with \"/\".": [
  null,
  "マウントポイントは \"/\" で開始してください。"
 ],
 "Mount read only": [
  null,
  "読み取り専用でマウント"
 ],
 "Mount without waiting, ignore failure": [
  null,
  "待機せずにマウントし、失敗を無視します"
 ],
 "Mounting $target": [
  null,
  "$target のマウント"
 ],
 "Mounts before services start": [
  null,
  "サービス起動前にマウントします"
 ],
 "Mounts in parallel with services": [
  null,
  "サービスと並行してマウントします"
 ],
 "Mounts in parallel with services, but after network is available": [
  null,
  "サービスと並行してマウントしますが、ネットワークが利用可能になった後にマウントします"
 ],
 "Multi-system chassis": [
  null,
  "マルチシステムシャーシ"
 ],
 "Multipathed devices": [
  null,
  "マルチパスデバイス"
 ],
 "NFS mount": [
  null,
  "NFS マウント"
 ],
 "NTP server": [
  null,
  "NTP サーバー"
 ],
 "Name": [
  null,
  "名前"
 ],
 "Name can not be empty.": [
  null,
  "名前は空欄にできません。"
 ],
 "Name cannot be empty.": [
  null,
  "名前は空欄にすることができません。"
 ],
 "Name cannot be longer than $0 bytes": [
  null,
  "名前は、$0 バイトを超えることができません"
 ],
 "Name cannot be longer than $0 characters": [
  null,
  "名前は、$0 文字を超えることができません"
 ],
 "Name cannot be longer than 127 characters.": [
  null,
  "名前は 127 文字を超えることができません。"
 ],
 "Name cannot be longer than 255 characters.": [
  null,
  "名前は 255 文字を超えることができません。"
 ],
 "Name cannot contain the character '$0'.": [
  null,
  "名前には文字 '$0' を含めることができません。"
 ],
 "Name cannot contain the character '/'.": [
  null,
  "名前には文字 '/' を含めることができません。"
 ],
 "Name cannot contain whitespace.": [
  null,
  "名前にはスペースを含めることができません。"
 ],
 "Need a spare disk": [
  null,
  "スペアディスクが必要です"
 ],
 "Need at least one NTP server": [
  null,
  "少なくとも 1 つの NTP サーバーが必要です"
 ],
 "Networked storage": [
  null,
  "ネットワークストレージ"
 ],
 "Networking": [
  null,
  "ネットワーキング"
 ],
 "New NFS mount": [
  null,
  "NFS の新規マウント"
 ],
 "New passphrase": [
  null,
  "新しいパスフレーズ"
 ],
 "New password was not accepted": [
  null,
  "新規パスワードは受け入れられませんでした"
 ],
 "Next": [
  null,
  "次へ"
 ],
 "No available slots": [
  null,
  "利用可能なスロットはありません"
 ],
 "No block devices are available.": [
  null,
  "ブロックデバイスは利用できません。"
 ],
 "No block devices found": [
  null,
  "ブロックデバイスが見つかりません"
 ],
 "No delay": [
  null,
  "遅延なし"
 ],
 "No devices found": [
  null,
  "デバイスが見つかりません"
 ],
 "No disks are available.": [
  null,
  "ディスクが利用できません。"
 ],
 "No disks found": [
  null,
  "ディスクが見つかりません"
 ],
 "No drives found": [
  null,
  "ドライブが見つかりません"
 ],
 "No encryption": [
  null,
  "暗号化なし"
 ],
 "No filesystem": [
  null,
  "ファイルシステムなし"
 ],
 "No filesystems": [
  null,
  "ファイルシステムがありません"
 ],
 "No free key slots": [
  null,
  "フリーのキースロットはありません"
 ],
 "No free space": [
  null,
  "空き領域なし"
 ],
 "No free space after this partition": [
  null,
  "このパーティションの後に空き領域がありません"
 ],
 "No keys added": [
  null,
  "追加されたキーはありません"
 ],
 "No logical volumes": [
  null,
  "論理ボリュームなし"
 ],
 "No media inserted": [
  null,
  "メディアが挿入されていません"
 ],
 "No partitioning": [
  null,
  "パーティションなし"
 ],
 "No partitions found": [
  null,
  "パーティションが見つかりません"
 ],
 "No physical volumes found": [
  null,
  "物理ボリュームが見つかりません"
 ],
 "No results found": [
  null,
  "結果が見つかりません"
 ],
 "No snapshots found": [
  null,
  "スナップショットを見つかりませんでした"
 ],
 "No storage found": [
  null,
  "ストレージが見つかりません"
 ],
 "No subvolumes": [
  null,
  "サブボリュームなし"
 ],
 "No such file or directory": [
  null,
  "このようなファイルまたはディレクトリーがありません"
 ],
 "No system modifications": [
  null,
  "システム変更がありません"
 ],
 "Not a valid private key": [
  null,
  "有効な秘密鍵ではありません"
 ],
 "Not enough free space": [
  null,
  "十分な空き領域がありません"
 ],
 "Not enough space": [
  null,
  "スペースが不足しています"
 ],
 "Not enough space to grow": [
  null,
  "拡張するのに十分な領域がありません"
 ],
 "Not found": [
  null,
  "見つかりません"
 ],
 "Not permitted to perform this action.": [
  null,
  "この動作を実行する権限がありません。"
 ],
 "Not running": [
  null,
  "未実行"
 ],
 "Not synchronized": [
  null,
  "同期されていません"
 ],
 "Notebook": [
  null,
  "ノートブック"
 ],
 "Number of bad sectors": [
  null,
  ""
 ],
 "Occurrences": [
  null,
  "発生"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Old passphrase": [
  null,
  "古いパスフレーズ"
 ],
 "Old password not accepted": [
  null,
  "古いパスワードは受け入れられません"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Cockpit がインストールされたら、\"systemctl enable --now cockpit.socket\" コマンドで有効にします。"
 ],
 "Only $0 of $1 are used.": [
  null,
  "$1 のうち $0 だけが使用されています。"
 ],
 "Operation '$operation' on $target": [
  null,
  "$target 上の操作 '$operation'"
 ],
 "Options": [
  null,
  "オプション"
 ],
 "Other": [
  null,
  "その他"
 ],
 "Overprovisioning": [
  null,
  "オーバープロビジョニング"
 ],
 "Overwrite": [
  null,
  "上書き"
 ],
 "Overwrite existing data with zeros (slower)": [
  null,
  "既存のデータをゼロで上書き (低速)"
 ],
 "PID": [
  null,
  "PID"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit がクラッシュしました"
 ],
 "Partition": [
  null,
  "パーティション"
 ],
 "Partition of $0": [
  null,
  "$0 のパーティション"
 ],
 "Partition size is $0. Content size is $1.": [
  null,
  "パーティションサイズは $0 です。コンテンツサイズは $1 です。"
 ],
 "Partitioning": [
  null,
  "パーティション構成"
 ],
 "Partitions": [
  null,
  "パーティション"
 ],
 "Partitions are not supported on this block device. If it is used as a disk for a virtual machine, the partitions must be managed by the operating system inside the virtual machine.": [
  null,
  ""
 ],
 "Passphrase": [
  null,
  "パスフレーズ"
 ],
 "Passphrase can not be empty": [
  null,
  "パスフレーズは空欄にすることはできません"
 ],
 "Passphrase cannot be empty": [
  null,
  "パスフレーズは空欄にすることができません"
 ],
 "Passphrase from any other key slot": [
  null,
  "その他のキースロットのパスフレーズ"
 ],
 "Passphrase removal may prevent unlocking $0.": [
  null,
  "パスフレーズの削除で、$0 のロック解除ができない可能性があります。"
 ],
 "Passphrases do not match": [
  null,
  "パスフレーズが一致しません"
 ],
 "Password": [
  null,
  "パスワード"
 ],
 "Password is not acceptable": [
  null,
  "パスワードは受け入れられません"
 ],
 "Password is too weak": [
  null,
  "パスワードが弱すぎます"
 ],
 "Password not accepted": [
  null,
  "パスワードは受け入れられません"
 ],
 "Paste": [
  null,
  "貼り付け"
 ],
 "Paste error": [
  null,
  "貼り付けエラー"
 ],
 "Path on server": [
  null,
  "サーバーのパス"
 ],
 "Path on server cannot be empty.": [
  null,
  "サーバーのパスは空欄にはできません。"
 ],
 "Path on server must start with \"/\".": [
  null,
  "サーバーのパスは \"/\" で開始してください。"
 ],
 "Path to file": [
  null,
  "ファイルのパス"
 ],
 "Peripheral chassis": [
  null,
  "周辺機器シャーシ"
 ],
 "Permanently delete $0?": [
  null,
  "$0 を完全に削除しますか？"
 ],
 "Permanently delete logical volume $0/$1?": [
  null,
  "論理ボリューム $0/$1 を完全に削除しますか?"
 ],
 "Permanently delete subvolume $0?": [
  null,
  "サブボリューム $0 を完全に削除しますか？"
 ],
 "Physical": [
  null,
  "物理"
 ],
 "Physical Volumes": [
  null,
  "物理ボリューム"
 ],
 "Physical volumes": [
  null,
  "物理ボリューム"
 ],
 "Physical volumes can not be resized here": [
  null,
  "ここでは物理ボリュームのサイズを変更できません"
 ],
 "Pick date": [
  null,
  "日付けの選択"
 ],
 "Pizza box": [
  null,
  "ピザ箱"
 ],
 "Please unmount them first.": [
  null,
  "先にアンマウントしてください。"
 ],
 "Pool for thin logical volumes": [
  null,
  "シン論理ボリューム用プール"
 ],
 "Pool for thinly provisioned LVM2 logical volumes": [
  null,
  "シンプロビジョニングされた LVM2 論理ボリューム用プール"
 ],
 "Pool for thinly provisioned volumes": [
  null,
  "シンプロビジョニングされたボリューム用プール"
 ],
 "Pool passphrase": [
  null,
  "プールパスフレーズ"
 ],
 "Port": [
  null,
  "ポート"
 ],
 "Portable": [
  null,
  "ポータブル"
 ],
 "Power on hours": [
  null,
  ""
 ],
 "PowerPC PReP boot partition": [
  null,
  "PowerPC PReP ブートパーティション"
 ],
 "Present": [
  null,
  "存在"
 ],
 "Processes using the location": [
  null,
  "ロケーションを使用するプロセス"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "ssh-add によるプロンプトがタイムアウトしました"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "ssh-keygen によるプロンプトがタイムアウトしました"
 ],
 "Provide the passphrase for the pool on these block devices:": [
  null,
  "このブロックデバイス上のプールのパスフレーズを指定します:"
 ],
 "Purpose": [
  null,
  "目的"
 ],
 "RAID ($0)": [
  null,
  "RAID ($0)"
 ],
 "RAID 0": [
  null,
  "RAID 0"
 ],
 "RAID 0 (stripe)": [
  null,
  "RAID 0 (ストライプ)"
 ],
 "RAID 1": [
  null,
  "RAID 1"
 ],
 "RAID 1 (mirror)": [
  null,
  "RAID 1 (ミラー)"
 ],
 "RAID 10": [
  null,
  "RAID 10"
 ],
 "RAID 10 (stripe of mirrors)": [
  null,
  "RAID 10 (ミラーのストライプ)"
 ],
 "RAID 4": [
  null,
  "RAID 4"
 ],
 "RAID 4 (dedicated parity)": [
  null,
  "RAID 4 (専用パリティー)"
 ],
 "RAID 5": [
  null,
  "RAID 5"
 ],
 "RAID 5 (distributed parity)": [
  null,
  "RAID 5 (分散パリティー)"
 ],
 "RAID 6": [
  null,
  "RAID 6"
 ],
 "RAID 6 (double distributed parity)": [
  null,
  "RAID 6 (ダブル分散パリティー)"
 ],
 "RAID chassis": [
  null,
  "RAID シャーシ"
 ],
 "RAID level": [
  null,
  "RAID レベル"
 ],
 "RAID10 needs an even number of physical volumes": [
  null,
  "RAID10 には偶数個の物理ボリュームが必要です"
 ],
 "Rack mount chassis": [
  null,
  "ラックマウントシャーシ"
 ],
 "Reading": [
  null,
  "読み取り中"
 ],
 "Reboot": [
  null,
  "再起動"
 ],
 "Recovering": [
  null,
  "復旧"
 ],
 "Recovering MDRAID device $target": [
  null,
  "MDRAID デバイス $target の復旧"
 ],
 "Regenerating initrd": [
  null,
  "initrd の再生成"
 ],
 "Related processes and services will be forcefully stopped.": [
  null,
  "関連するプロセスとサービスは強制的に停止されます。"
 ],
 "Related processes will be forcefully stopped.": [
  null,
  "関連するプロセスは強制的に停止されます。"
 ],
 "Related services will be forcefully stopped.": [
  null,
  "関連するサービスは強制的に停止されます。"
 ],
 "Removals:": [
  null,
  "削除:"
 ],
 "Remove": [
  null,
  "削除"
 ],
 "Remove $0?": [
  null,
  "$0 を削除しますか?"
 ],
 "Remove Tang keyserver?": [
  null,
  "Tang キーサーバーを削除しますか？"
 ],
 "Remove device": [
  null,
  "デバイスの削除"
 ],
 "Remove missing physical volumes?": [
  null,
  "見つからない物理ボリュームを削除しますか?"
 ],
 "Remove passphrase in key slot $0?": [
  null,
  "キースロットのパスフレーズ $0 を削除しますか？"
 ],
 "Remove passphrase?": [
  null,
  "パスフレーズを削除しますか?"
 ],
 "Removing $0": [
  null,
  "$0 を削除中"
 ],
 "Removing $target from MDRAID device": [
  null,
  "$target を MDRAID デバイスから削除"
 ],
 "Removing a passphrase without confirmation of another passphrase may prevent unlocking or key management, if other passphrases are forgotten or lost.": [
  null,
  "別のパスフレーズの確認なしでパスフレーズを削除すると、その他のパスフレーズを忘れたり、紛失した場合に、アンロックやキー管理ができなくなることがあります。"
 ],
 "Removing physical volume from $target": [
  null,
  "$target から物理ボリュームを削除"
 ],
 "Rename": [
  null,
  "名前変更"
 ],
 "Rename Stratis pool": [
  null,
  "Stratis プールの名前変更"
 ],
 "Rename filesystem": [
  null,
  "ファイルシステムの名前変更"
 ],
 "Rename logical volume": [
  null,
  "論理ボリュームの名前変更"
 ],
 "Rename volume group": [
  null,
  "ボリュームグループの名前変更"
 ],
 "Renaming $target": [
  null,
  "$target の名前変更"
 ],
 "Repair": [
  null,
  "修復"
 ],
 "Repair logical volume $0": [
  null,
  "論理ボリューム $0 の修復"
 ],
 "Repairing $target": [
  null,
  "$target の修復"
 ],
 "Repeat passphrase": [
  null,
  "パスフレーズの繰り返し"
 ],
 "Resizing $target": [
  null,
  "$target のサイズ変更"
 ],
 "Resizing an encrypted filesystem requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "暗号化されたファイルシステムのサイズ変更には、ディスクのロック解除が必要です。現在のディスクのパスフレーズを提供してください。"
 ],
 "Reuse existing encryption": [
  null,
  "既存の暗号化を再利用"
 ],
 "Reuse existing encryption ($0)": [
  null,
  "既存の暗号化を再利用 ($0)"
 ],
 "Row expansion": [
  null,
  "行の拡張"
 ],
 "Row select": [
  null,
  "行の選択"
 ],
 "Run extended test": [
  null,
  ""
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "信頼できるネットワーク経由で、またはリモートマシンで直接、次のコマンドを実行します:"
 ],
 "Running": [
  null,
  "実行中"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SHA-1": [
  null,
  "SHA-1"
 ],
 "SHA-256": [
  null,
  "SHA-256"
 ],
 "SMART self-test of $target": [
  null,
  "$target の SMART 自己テスト"
 ],
 "SSH key": [
  null,
  "SSH キー"
 ],
 "SSH key login": [
  null,
  "SSH 鍵ログイン"
 ],
 "Save": [
  null,
  "保存"
 ],
 "Save space by compressing individual blocks with LZ4": [
  null,
  "LZ4 で個別のブロックを圧縮して空き領域を節約します"
 ],
 "Save space by storing identical data blocks just once": [
  null,
  "同一のデータブロックを 1 回だけ保存することで、空き領域を節約します"
 ],
 "Saving a new passphrase requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "新しいパスフレーズの保存には、ディスクのロック解除が必要です。現在のディスクのパスフレーズを提供してください。"
 ],
 "Sealed-case PC": [
  null,
  "シールドケース PC"
 ],
 "Securely erasing $target": [
  null,
  "$target を安全に削除"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Security Enhanced Linux の設定とトラブルシューティング"
 ],
 "Select an option": [
  null,
  "オプションの選択"
 ],
 "Select the physical volumes that should be used to repair the logical volume. At least $0 are needed.": [
  null,
  "論理ボリュームの修復に使用する物理ボリュームを選択します。$0 以上が必要です。"
 ],
 "Serial number": [
  null,
  "シリアルナンバー"
 ],
 "Server": [
  null,
  "サーバー"
 ],
 "Server address": [
  null,
  "サーバーアドレス"
 ],
 "Server address cannot be empty.": [
  null,
  "サーバーアドレスは空欄にできません。"
 ],
 "Server cannot be empty.": [
  null,
  "サーバーは空欄にできません。"
 ],
 "Server has closed the connection.": [
  null,
  "サーバーの接続が終了しました。"
 ],
 "Service": [
  null,
  "サービス"
 ],
 "Services using the location": [
  null,
  "ロケーションを使用するサービス"
 ],
 "Set": [
  null,
  "セット"
 ],
 "Set initial size": [
  null,
  "初期サイズ設定"
 ],
 "Set limit of virtual filesystem size": [
  null,
  "仮想ファイルシステムのサイズを制限します"
 ],
 "Set partition type of $0": [
  null,
  "$0 のパーティションタイプの設定"
 ],
 "Set time": [
  null,
  "時間の設定"
 ],
 "Setting up loop device $target": [
  null,
  "ループデバイス $target の設定"
 ],
 "Shell script": [
  null,
  "シェルスクリプト"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show all $0 rows": [
  null,
  "$0 行をすべて表示"
 ],
 "Show confirmation password": [
  null,
  "確認パスワードの表示"
 ],
 "Show password": [
  null,
  "パスワードを表示する"
 ],
 "Shrink": [
  null,
  "縮小"
 ],
 "Shrink logical volume": [
  null,
  "論理ボリュームの縮小"
 ],
 "Shrink partition": [
  null,
  "パーティションの縮小"
 ],
 "Shrink volume": [
  null,
  "ボリュームの縮小"
 ],
 "Shut down": [
  null,
  "シャットダウン"
 ],
 "Single rank": [
  null,
  "シングルランク"
 ],
 "Size": [
  null,
  "サイズ"
 ],
 "Size cannot be negative": [
  null,
  "サイズはマイナスにすることができません"
 ],
 "Size cannot be zero": [
  null,
  "サイズはゼロにすることができません"
 ],
 "Size is too large": [
  null,
  "サイズが大きすぎます"
 ],
 "Size must be a number": [
  null,
  "サイズは数値である必要があります"
 ],
 "Size must be at least $0": [
  null,
  "サイズは $0 以上にする必要があります"
 ],
 "Slot $0": [
  null,
  "スロット $0"
 ],
 "Snapshot": [
  null,
  "スナップショット"
 ],
 "Snapshot origin": [
  null,
  "スナップショット元"
 ],
 "Snapshots": [
  null,
  "スナップショット"
 ],
 "Solid State Drive": [
  null,
  "ソリッドステートドライブ"
 ],
 "Some block devices of this pool have grown in size after the pool was created. The pool can be safely grown to use the newly available space.": [
  null,
  "プールの作成後に、このプールのブロックデバイスでサイズが増大したものがあります。このプールを安全に拡張するには新たに利用可能な領域を使用してください。"
 ],
 "Sorry": [
  null,
  "申し訳ございません"
 ],
 "Space-saving computer": [
  null,
  "省スペースコンピューター"
 ],
 "Spare": [
  null,
  "スペア"
 ],
 "Spare capacity is below the threshold": [
  null,
  ""
 ],
 "Specific time": [
  null,
  "特定の時間"
 ],
 "Start": [
  null,
  "起動"
 ],
 "Start multipath": [
  null,
  "マルチパスの開始"
 ],
 "Started": [
  null,
  "開始"
 ],
 "Starting MDRAID device $target": [
  null,
  "MDRAID $target デバイスの起動"
 ],
 "Starting swapspace $target": [
  null,
  "スワップ領域 $target の起動"
 ],
 "State": [
  null,
  "状態"
 ],
 "Stick PC": [
  null,
  "スティッキー PC"
 ],
 "Stop": [
  null,
  "停止"
 ],
 "Stop and remove": [
  null,
  "停止して削除"
 ],
 "Stop and unmount": [
  null,
  "停止してアンマウント"
 ],
 "Stop device": [
  null,
  "デバイスの停止"
 ],
 "Stopping MDRAID device $target": [
  null,
  "MDRAID デバイス $target の停止"
 ],
 "Stopping swapspace $target": [
  null,
  "スワップ領域 $target の停止"
 ],
 "Storage": [
  null,
  "ストレージ"
 ],
 "Storage can not be managed on this system.": [
  null,
  "ストレージは、このシステムで管理できません。"
 ],
 "Storage logs": [
  null,
  "ストレージログ"
 ],
 "Store passphrase": [
  null,
  "パスフレーズの保存"
 ],
 "Stored passphrase": [
  null,
  "保存されたパスフレーズ"
 ],
 "Stratis block device": [
  null,
  "Stratis ブロックデバイス"
 ],
 "Stratis block devices": [
  null,
  "Stratis ブロックデバイス"
 ],
 "Stratis blockdevs can not be made smaller": [
  null,
  "Stratis blockdevs は縮小できません"
 ],
 "Stratis filesystem": [
  null,
  "Stratis ファイルシステム"
 ],
 "Stratis filesystems": [
  null,
  "Stratis ファイルシステム"
 ],
 "Stratis filesystems pool": [
  null,
  "Stratis ファイルシステムプール"
 ],
 "Stratis pool": [
  null,
  "Stratis プール"
 ],
 "Striped (RAID 0)": [
  null,
  "ストライプ (RAID 0)"
 ],
 "Striped and mirrored (RAID 10)": [
  null,
  "ストライプおよびミラー (RAID 10)"
 ],
 "Stripes": [
  null,
  "ストライプ"
 ],
 "Strong password": [
  null,
  "強固なパスワード"
 ],
 "Sub-Chassis": [
  null,
  "サブシャーシ"
 ],
 "Sub-Notebook": [
  null,
  "サブノート"
 ],
 "Successfully copied to clipboard!": [
  null,
  "クリップボードへのコピーに成功しました！"
 ],
 "Swap": [
  null,
  "スワップ"
 ],
 "Swap can not be resized here": [
  null,
  "ここではスワップのサイズを変更できません"
 ],
 "Synchronized": [
  null,
  "同期済み"
 ],
 "Synchronized with $0": [
  null,
  "$0 と同期済み"
 ],
 "Synchronizing": [
  null,
  "同期中"
 ],
 "Synchronizing MDRAID device $target": [
  null,
  "MDRAID デバイス $target の同期"
 ],
 "Tablet": [
  null,
  "タブレット"
 ],
 "Tang keyserver": [
  null,
  "Tang キーサーバー"
 ],
 "Target": [
  null,
  "ターゲット"
 ],
 "Temperature outside of recommended thresholds": [
  null,
  ""
 ],
 "The $0 package is not available from any repository.": [
  null,
  "$0 パッケージは、あらゆるリポジトリーから利用できません。"
 ],
 "The $0 package must be installed to create Stratis pools.": [
  null,
  "Stratis デバイスを作成するために $0 パッケージをインストールする必要があります。"
 ],
 "The $0 package must be installed.": [
  null,
  "$0 パッケージがインストールされている必要があります。"
 ],
 "The $0 package will be installed to create VDO devices.": [
  null,
  "$0 パッケージがインストールされ、VDO デバイスを作成します。"
 ],
 "The MDRAID device is in a degraded state": [
  null,
  "MDRAID デバイスがデグレード状態です"
 ],
 "The MDRAID device must be running": [
  null,
  "MDRAID デバイスが実行中である必要があります"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "$2 の $1 の SSH キー $0 は、$5 上の $4 の $3 ファイルに追加されます。"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH キー $0 はセッションの残りの時間に利用できるようになり、他のホストにもログインできるようになります。"
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "$0 にログインするための SSH キーはパスワードで保護され、パスワードによるログインを許可しません。$1 にキーのパスワードを指定してください。"
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "$0 にログインするための SSH キーは保護されています。ログインパスワードでログインするか、$1 で鍵のパスワードを提供することでログインできます。"
 ],
 "The creation of this VDO device did not finish and the device can't be used.": [
  null,
  "この VDO デバイスの作成は終了していないため、使用できません。"
 ],
 "The currently logged in user is not permitted to see information about keys.": [
  null,
  "現在ログイン中のユーザーは、キーに関する情報を見ることを許可されていません。"
 ],
 "The filesystem has no assigned mount point.": [
  null,
  "ファイルシステムにマウントポイントが割り当てられていません。"
 ],
 "The filesystem has no permanent mount point.": [
  null,
  "ファイルシステムには永続的なマウントポイントがありません。"
 ],
 "The filesystem is configured to be automatically mounted on boot but its encryption container will not be unlocked at that time.": [
  null,
  "ファイルシステムは起動時に自動的にマウントされるように設定されていますが、その暗号化コンテナーはその時点ではアンロックされません。"
 ],
 "The filesystem is currently mounted but will not be mounted after the next boot.": [
  null,
  "ファイルシステムは現在マウントされていますが、次回のブート後はマウントされません。"
 ],
 "The filesystem is currently mounted on $0 but will be mounted on $1 on the next boot.": [
  null,
  "ファイルシステムは現在 $0 にマウントされていますが、次回のブート時に $1 にマウントされます。"
 ],
 "The filesystem is currently mounted on $0 but will not be mounted after the next boot.": [
  null,
  "ファイルシステムは現在 $0 にマウントされていますが、次回のブート後はマウントされません。"
 ],
 "The filesystem is currently not mounted but will be mounted on the next boot.": [
  null,
  "ファイルシステムは現在マウントされていませんが、次回のブート時にマウントされます。"
 ],
 "The filesystem is not mounted.": [
  null,
  "ファイルシステムはマウントされていません。"
 ],
 "The filesystem will be unlocked and mounted on the next boot. This might require inputting a passphrase.": [
  null,
  "ファイルシステムはロック解除され、次回の起動時にマウントされます。パスフレーズの入力が必要になる場合があります。"
 ],
 "The fingerprint should match:": [
  null,
  "フィンガープリントは次のものと一致する必要があります:"
 ],
 "The initrd must be regenerated.": [
  null,
  "initrd を再生成する必要があります。"
 ],
 "The key password can not be empty": [
  null,
  "キーのパスワードは空にすることはできません"
 ],
 "The key passwords do not match": [
  null,
  "キーのパスワードが一致しません"
 ],
 "The last key slot can not be removed": [
  null,
  "最後のキースロットは削除できません"
 ],
 "The last mounted subvolume can not be deleted": [
  null,
  "最後にマウントされたサブボリュームは削除できません"
 ],
 "The listed processes and services will be forcefully stopped.": [
  null,
  "一覧表示されたプロセスとサービスは強制的に停止されます。"
 ],
 "The listed processes will be forcefully stopped.": [
  null,
  "一覧表示されたプロセスは強制的に停止されます。"
 ],
 "The listed services will be forcefully stopped.": [
  null,
  "一覧表示されたサービスは強制的に停止されます。"
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "ログインしているユーザーには、システム変更を表示する権限がありません"
 ],
 "The mount point $0 is in use by these processes:": [
  null,
  "マウントポイント $0 は、以下のプロセスにより使用されています:"
 ],
 "The mount point $0 is in use by these services:": [
  null,
  "マウントポイント $0 は、以下のサービスにより使用されています:"
 ],
 "The password can not be empty": [
  null,
  "パスワードは空にできません"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "作成されたフィンガープリントは、電子メールを含むパブリックメソッドを介して共有すると問題ありません。"
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "生成されたフィンガープリントは、メールなどのパブリックな方法で共有しても問題ありません。他の人に検証を依頼した場合、その人は任意の方法で結果を送信できます。"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "サーバーはサポートされた方法を使用した認証を拒否しました。"
 ],
 "The system does not currently support unlocking a filesystem with a Tang keyserver during boot.": [
  null,
  "現在、このシステムでは、起動時に Tang 鍵サーバーを使用したファイルシステムのロック解除をサポートしていません。"
 ],
 "The system does not currently support unlocking the root filesystem with a Tang keyserver.": [
  null,
  "現在、このシステムは Tang 鍵サーバーを使用したルートファイルシステムのロック解除をサポートしていません。"
 ],
 "There are devices with multiple paths on the system, but the multipath service is not running.": [
  null,
  "システムに複数のパスを持つデバイスがありますが、マルチパスサービスが実行されていません。"
 ],
 "There is not enough space available that could be used for a repair. At least $0 are needed on physical volumes that are not already used for this logical volume.": [
  null,
  "修復に使用できる十分な領域がありません。この論理ボリューム用に使用されていない領域が、物理ボリュームに $0 以上必要です。"
 ],
 "These additional steps are necessary:": [
  null,
  "以下の追加手順が必要です:"
 ],
 "These changes will be made:": [
  null,
  "以下の変更が行われます:"
 ],
 "Thin logical volume": [
  null,
  "シン論理ボリューム"
 ],
 "Thinly provisioned LVM2 logical volumes": [
  null,
  "シンプロビジョニングされた LVM2 論理ボリューム"
 ],
 "This MDRAID device has no write-intent bitmap. Such a bitmap can reduce synchronization times significantly.": [
  null,
  "この MDRAID デバイスには write-intent ビットマップがありません。このビットマップを使用すると、同期時間を大幅に短縮できます。"
 ],
 "This NFS mount is in use and only its options can be changed.": [
  null,
  "この NFS マウントは使用中で、そのオプションだけを変更できます。"
 ],
 "This VDO device does not use all of its backing device.": [
  null,
  "この VDO デバイスは、そのバッキングデバイスをすべて使用していません。"
 ],
 "This device can not be used for the installation target.": [
  null,
  "このデバイスはインストール対象として使用できません。"
 ],
 "This device is currently in use.": [
  null,
  "このデバイスは現在使用されています。"
 ],
 "This keyserver is the only way to unlock the pool and can not be removed.": [
  null,
  "このキーサーバーは、プールのロック解除する唯一の手段であるため、削除できません。"
 ],
 "This logical volume has lost some of its physical volumes and can no longer be used. You need to delete it and create a new one to take its place.": [
  null,
  "この論理ボリュームは一部の物理ボリュームを失ったため、使用できなくなりました。この論理ボリュームを削除して、代わりに新しいものを作成する必要があります。"
 ],
 "This logical volume has lost some of its physical volumes but has not lost any data yet. You should repair it to restore its original redundancy.": [
  null,
  "この論理ボリュームは一部の物理ボリュームを失いましたが、データはまだ失われていません。元の冗長性を復元するには、この論理ボリュームを修復する必要があります。"
 ],
 "This logical volume has lost some of its physical volumes but might not have lost any data yet. You might be able to repair it.": [
  null,
  "この論理ボリュームは一部の物理ボリュームを失いましたが、データはまだ失われていない可能性があります。この論理ボリュームを修復できる可能性があります。"
 ],
 "This logical volume is not completely used by its content.": [
  null,
  "この論理ボリュームは、コンテンツによって完全には使用されていません。"
 ],
 "This partition is not completely used by its content.": [
  null,
  "このパーティションは、コンテンツによって完全に使い切られていません。"
 ],
 "This passphrase is the only way to unlock the pool and can not be removed.": [
  null,
  "このパスフレーズは、プールのロックを解除するための唯一の手段であるため、削除できません。"
 ],
 "This pool does not use all the space on its block devices.": [
  null,
  "このプールは、プールのブロックデバイスにある領域をすべて使用していません。"
 ],
 "This pool is in a degraded state.": [
  null,
  "このプールは、degraded の状態にあります。"
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "このツールは、SELinux ポリシーを設定します。また、ポリシー違反の把握と解決に役立ちます。"
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "このツールは、システムがカーネルクラッシュダンプを書き込むように設定します。\"local\"（ディスク）、\"ssh\"、および \"nfs\" をターゲットとしてサポートしています。"
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "このツールは、実行中のシステムから設定および診断情報のアーカイブを生成します。アーカイブは、記録や追跡の目的でローカルまたは一元的に保存することも、技術的な障害の発見やデバッグを支援するためにテクニカルサポート担当者、開発者、システム管理者に送信することもできます。"
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "このツールは、ファイルシステム、LVM2 ボリュームグループ、NFS マウントなどのローカルストレージを管理します。"
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "このツールは、NetworkManager と Firewalld を使用して、ボンディング、ブリッジ、チーム、VLAN、ファイアウォールなどのネットワーク設定を管理します。NetworkManager は、Ubuntu のデフォルトの systemd-networkd および Debian の ifupdown スクリプトと互換性がありません。"
 ],
 "This volume group contains the root filesystem. Renaming it might require further changes to the bootloader configuration or kernel command line.": [
  null,
  ""
 ],
 "This volume group is missing some physical volumes.": [
  null,
  "このボリュームグループの一部の物理ボリュームがありません。"
 ],
 "Tier": [
  null,
  "階層"
 ],
 "Time zone": [
  null,
  "タイムゾーン"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "悪意のあるサードパーティーによって接続がインターセプトされないようにするには、ホストキーフィンガープリントを確認してください:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "フィンガープリントを確認するには、マシン上に物理的に置かれるか、信頼できるネットワークを介して $0 で次のコマンドを実行します:"
 ],
 "Toggle date picker": [
  null,
  "日付選択の切り替え"
 ],
 "Too much data": [
  null,
  "データが多すぎます"
 ],
 "Total size: $0": [
  null,
  "合計サイズ: $0"
 ],
 "Tower": [
  null,
  "タワー"
 ],
 "Trust and add host": [
  null,
  "ホストを信頼して追加"
 ],
 "Trust key": [
  null,
  "キーを信頼します"
 ],
 "Trying to synchronize with $0": [
  null,
  "$0 との同期を試行中です"
 ],
 "Type": [
  null,
  "タイプ"
 ],
 "Type can only contain the characters 0 to 9, A to F, and \"-\".": [
  null,
  "タイプには、0 から 9、A から F、および \"-\" のみを含めることができます。"
 ],
 "Type must be of the form NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN.": [
  null,
  "タイプは、NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN の形式である必要があります。"
 ],
 "Type must contain exactly two hexadecimal characters (0 to 9, A to F).": [
  null,
  "タイプには 16 進文字 (0 から 9、A から F) が 2 つ含まれている必要があります。"
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "SSH 鍵認証を使用して $0 にログインできません。パスワードを入力してください。"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "$0 にログインできません。ホストが、パスワードログインまたは SSH キーを受け付けていません。"
 ],
 "Unable to reach server": [
  null,
  "サーバーに到達できません"
 ],
 "Unable to remove mount": [
  null,
  "マウントを削除できません"
 ],
 "Unable to repair logical volume $0": [
  null,
  "論理ボリューム $0 を修復できません"
 ],
 "Unable to unmount filesystem": [
  null,
  "ファイルシステムをアンマウントできません"
 ],
 "Unexpected PackageKit error during installation of $0: $1": [
  null,
  "$0 のインストール時に予期しない PackageKit エラーが発生しました: $1"
 ],
 "Unformatted data": [
  null,
  "未フォーマットのデータ"
 ],
 "Unknown": [
  null,
  "不明"
 ],
 "Unknown ($0)": [
  null,
  "不明な ($0)"
 ],
 "Unknown host name": [
  null,
  "不明なホスト名"
 ],
 "Unknown host: $0": [
  null,
  "不明なホスト: $0"
 ],
 "Unknown type": [
  null,
  "不明なタイプ"
 ],
 "Unlock": [
  null,
  "ロック解除"
 ],
 "Unlock automatically on boot": [
  null,
  "システムの起動時に自動ロック解除"
 ],
 "Unlock before resizing": [
  null,
  "サイズ変更前のロック解除"
 ],
 "Unlock encrypted Stratis pool": [
  null,
  "暗号化 Stratis プールのロック解除"
 ],
 "Unlocking $target": [
  null,
  "$target をロック解除中"
 ],
 "Unlocking disk": [
  null,
  "ディスクのロック解除"
 ],
 "Unmount": [
  null,
  "アンマウント"
 ],
 "Unmount filesystem $0": [
  null,
  "ファイルシステム $0 のアンマウント"
 ],
 "Unmount now": [
  null,
  "今すぐアンマウントします"
 ],
 "Unmounting $target": [
  null,
  "$target のアンマウント中"
 ],
 "Unrecognized data": [
  null,
  "認識されないデータ"
 ],
 "Unrecognized data can not be made smaller here": [
  null,
  "ここでは、認識されないデータを小さくすることはできません"
 ],
 "Unrecognized data can not be made smaller here.": [
  null,
  "ここでは、認識されないデータを小さくすることはできません。"
 ],
 "Unsupported logical volume": [
  null,
  "サポートされていない論理ボリューム"
 ],
 "Untrusted host": [
  null,
  "信用できないホスト"
 ],
 "Usage": [
  null,
  "使用率"
 ],
 "Usage of $0": [
  null,
  "$0 の使用率"
 ],
 "Use": [
  null,
  "使用"
 ],
 "Use $0": [
  null,
  "$0 を利用"
 ],
 "Use compression": [
  null,
  "圧縮の使用"
 ],
 "Use deduplication": [
  null,
  "重複排除の使用"
 ],
 "Used": [
  null,
  "使用済み"
 ],
 "Useful for mounts that are optional or need interaction (such as passphrases)": [
  null,
  "オプションのマウントや対話が必要なマウント (パスフレーズなど) に役立ちます"
 ],
 "User": [
  null,
  "ユーザー"
 ],
 "Username": [
  null,
  "ユーザー名"
 ],
 "VDO backing devices can not be made smaller": [
  null,
  "VDO バッキングデバイスを小さくすることはできません"
 ],
 "VDO device $0": [
  null,
  "VDO デバイス $0"
 ],
 "VDO filesystem volume (compression/deduplication)": [
  null,
  "VDO ファイルシステムボリューム (圧縮/重複排除)"
 ],
 "Vendor": [
  null,
  "ベンダー"
 ],
 "Verify fingerprint": [
  null,
  "フィンガープリントの検証"
 ],
 "Verify key": [
  null,
  "キーを検証します"
 ],
 "Very securely erasing $target": [
  null,
  "$target を非常に安全に削除"
 ],
 "View all logs": [
  null,
  "すべてのログの表示"
 ],
 "View automation script": [
  null,
  "オートメーションスクリプトの表示"
 ],
 "View logs": [
  null,
  "ログの表示"
 ],
 "Virtual filesystem sizes are larger than the pool. Overprovisioning can not be disabled.": [
  null,
  "仮想ファイルシステムのサイズがプールよりも大きくなっています。オーバー プロビジョニングを無効にすることはできません。"
 ],
 "Virtual size": [
  null,
  "仮想サイズ"
 ],
 "Virtual size limit": [
  null,
  "仮想サイズ制限"
 ],
 "Visit firewall": [
  null,
  "ファイアウォールへのアクセス"
 ],
 "Volatile memory backup failed": [
  null,
  ""
 ],
 "Volume group": [
  null,
  "ボリュームグループ"
 ],
 "Volume group is missing physical volumes": [
  null,
  "ボリュームグループに物理ボリュームがありません"
 ],
 "Volume size is $0. Content size is $1.": [
  null,
  "ボリュームサイズは $0 です。コンテンツサイズは $1 です。"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "他のソフトウェア管理オペレーションが終了するまで待機中"
 ],
 "Weak password": [
  null,
  "脆弱なパスワード"
 ],
 "Web Console for Linux servers": [
  null,
  "Linux サーバー用 Web コンソール"
 ],
 "World wide name": [
  null,
  "World wide name"
 ],
 "Write-mostly": [
  null,
  "多くは書き込み"
 ],
 "Writing": [
  null,
  "書き込み中"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "初めて $0 に接続しています。"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "お使いのブラウザーでは、コンテキストメニューからの貼り付けが許可されていません。Shift+Insert を使用できます。"
 ],
 "Your session has been terminated.": [
  null,
  "セッションが終了しました。"
 ],
 "Your session has expired. Please log in again.": [
  null,
  "セッションの有効期限が切れました。再度ログインしてください。"
 ],
 "Zone": [
  null,
  "ゾーン"
 ],
 "[binary data]": [
  null,
  "[バイナリーデータ]"
 ],
 "[no data]": [
  null,
  "[データなし]"
 ],
 "after network": [
  null,
  "ネットワークの後"
 ],
 "backing device for VDO device": [
  null,
  "VDO デバイスのバッキングデバイス"
 ],
 "btrfs device": [
  null,
  "btrfs デバイス"
 ],
 "btrfs devices": [
  null,
  "btrfs デバイス"
 ],
 "btrfs filesystem": [
  null,
  "btrfs ファイルシステム"
 ],
 "btrfs subvolume": [
  null,
  "btrfs サブボリューム"
 ],
 "btrfs subvolume $0 of $1": [
  null,
  "$1 の btrfs サブボリューム $0"
 ],
 "btrfs subvolumes": [
  null,
  "btrfs サブボリューム"
 ],
 "btrfs volume": [
  null,
  "btrfs ボリューム"
 ],
 "cache": [
  null,
  "キャッシュ"
 ],
 "data": [
  null,
  "データ"
 ],
 "deactivate": [
  null,
  "非アクティブ化"
 ],
 "delete": [
  null,
  "削除"
 ],
 "device of btrfs volume": [
  null,
  "btrfs ボリュームのデバイス"
 ],
 "edit": [
  null,
  "編集"
 ],
 "encrypted": [
  null,
  "暗号化"
 ],
 "format": [
  null,
  "フォーマット"
 ],
 "grow": [
  null,
  "増加"
 ],
 "iSCSI Drive": [
  null,
  "iSCSI ドライブ"
 ],
 "iSCSI drives": [
  null,
  "iSCSI ドライブ"
 ],
 "iSCSI portal": [
  null,
  "iSCSI ポータル"
 ],
 "ignore failure": [
  null,
  "失敗を無視"
 ],
 "in less than a minute": [
  null,
  "一分以内"
 ],
 "initialize": [
  null,
  "初期化"
 ],
 "less than a minute ago": [
  null,
  "一分以内"
 ],
 "lock": [
  null,
  "ロック"
 ],
 "member of MDRAID device": [
  null,
  "MDRAID デバイスのメンバー"
 ],
 "member of Stratis pool": [
  null,
  "Stratis プールのメンバー"
 ],
 "mount": [
  null,
  "マウント"
 ],
 "never mount at boot": [
  null,
  "起動時にマウントしない"
 ],
 "none": [
  null,
  "なし"
 ],
 "password quality": [
  null,
  "パスワードの強度"
 ],
 "physical volume of LVM2 volume group": [
  null,
  "LVM2 ボリュームグループの物理ボリューム"
 ],
 "read only": [
  null,
  "読み取り専用"
 ],
 "remove from LVM2": [
  null,
  "LVM2 からの削除"
 ],
 "remove from MDRAID": [
  null,
  "MDRAID からの削除"
 ],
 "remove from btrfs volume": [
  null,
  "btrfs ボリュームの削除"
 ],
 "show less": [
  null,
  "簡易表示"
 ],
 "show more": [
  null,
  "詳細表示"
 ],
 "shrink": [
  null,
  "縮小"
 ],
 "snapshot": [
  null,
  "スナップショット"
 ],
 "stop": [
  null,
  "停止"
 ],
 "stop boot on failure": [
  null,
  "失敗時にブートを停止"
 ],
 "stopped": [
  null,
  "停止中"
 ],
 "unknown target": [
  null,
  "不明なターゲット"
 ],
 "unmount": [
  null,
  "アンマウント"
 ],
 "unpartitioned space on $0": [
  null,
  "$0 の未パーティション領域"
 ],
 "using key description $0": [
  null,
  "キー説明 $0 の使用"
 ],
 "yes": [
  null,
  "はい"
 ],
 "format-bytes\u0004bytes": [
  null,
  "バイト"
 ]
});
