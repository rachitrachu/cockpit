cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "ko",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 can not be made larger": [
  null,
  "$0는 더 크게 만들 수 없습니다"
 ],
 "$0 can not be made smaller": [
  null,
  "$0는 더 작게 만들 수 없습니다"
 ],
 "$0 can not be resized": [
  null,
  "$0는 크기를 조정 할 수 없습니다"
 ],
 "$0 can not be resized here": [
  null,
  "$0는 여기에서 크기를 조정 할 수 없습니다"
 ],
 "$0 chunk size": [
  null,
  "$0 청크 크기"
 ],
 "$0 data + $1 overhead used of $2 ($3)": [
  null,
  "$0 데이터 + $1 오버헤드가 $2 ($3) 사용"
 ],
 "$0 day": [
  null,
  "$0 일"
 ],
 "$0 disk is missing": [
  null,
  "$0 디스크가 없습니다"
 ],
 "$0 disks": [
  null,
  "$0 디스크"
 ],
 "$0 exited with code $1": [
  null,
  "$0가 코드 $1로 종료됨"
 ],
 "$0 failed": [
  null,
  "$0 실패"
 ],
 "$0 filesystem": [
  null,
  "$0 파일 시스템"
 ],
 "$0 hour": [
  null,
  "$0 시"
 ],
 "$0 hours": [
  null,
  "$0 시"
 ],
 "$0 is in use": [
  null,
  "$0 사용 중"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 는 저장소에서 사용 할 수 없습니다."
 ],
 "$0 key changed": [
  null,
  "$0 키 변경됩니다"
 ],
 "$0 killed with signal $1": [
  null,
  "$1 시그널에 의해 $0 가 종료되었습니다"
 ],
 "$0 minute": [
  null,
  "$0 분"
 ],
 "$0 month": [
  null,
  "$0 달"
 ],
 "$0 partitions": [
  null,
  "$0 파티션"
 ],
 "$0 slot remains": [
  null,
  "$0 슬롯이 남아 있습니다"
 ],
 "$0 synchronized": [
  null,
  "$0 가 동기화 되었습니다"
 ],
 "$0 used of $1 ($2 saved)": [
  null,
  "$0/$1 ($2 저장)을 사용하고 있습니다"
 ],
 "$0 used, $1 total": [
  null,
  "$0 사용됨, $1 총계"
 ],
 "$0 week": [
  null,
  "$0 주"
 ],
 "$0 will be installed.": [
  null,
  "$0 가 설치됩니다."
 ],
 "$0 year": [
  null,
  "$0 년"
 ],
 "$name (from $host)": [
  null,
  "$name ($host 에서)"
 ],
 "(Not part of target)": [
  null,
  "(대상에 포함되지 않음)"
 ],
 "(no assigned mount point)": [
  null,
  "(할당된 적재 지점이 없음)"
 ],
 "(not mounted)": [
  null,
  "(적재 되지 않음)"
 ],
 "(recommended)": [
  null,
  "(권장 사항)"
 ],
 "1 MiB": [
  null,
  "1 MiB"
 ],
 "1 day": [
  null,
  "1 일"
 ],
 "1 hour": [
  null,
  "1시간"
 ],
 "1 minute": [
  null,
  "1 분"
 ],
 "1 week": [
  null,
  "1 주"
 ],
 "128 KiB": [
  null,
  "128 KiB"
 ],
 "16 KiB": [
  null,
  "16 KiB"
 ],
 "2 MiB": [
  null,
  "2 MiB"
 ],
 "20 minutes": [
  null,
  "20분"
 ],
 "32 KiB": [
  null,
  "32 KiB"
 ],
 "4 KiB": [
  null,
  "4 KiB"
 ],
 "40 minutes": [
  null,
  "40 분"
 ],
 "5 minutes": [
  null,
  "5분"
 ],
 "512 KiB": [
  null,
  "512 KiB"
 ],
 "6 hours": [
  null,
  "6 시간"
 ],
 "60 minutes": [
  null,
  "60 분"
 ],
 "64 KiB": [
  null,
  "64 KiB"
 ],
 "8 KiB": [
  null,
  "8 KiB"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "호환 가능한 Cockpit 버전이 $0 에서 설치되지 않았습니다."
 ],
 "A fatal error occurred during the self-test operation": [
  null,
  "자체-시험 동작 중에 심각한 오류가 발생했습니다"
 ],
 "A filesystem with this name exists already in this pool.": [
  null,
  "이 이름을 가진 파일 시스템이 이미 이 풀에 있습니다."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "$0 에서 신규 SSH 키는 $1 에서($2 에 대해) 생성되고 $3 파일($4 의($5 에 대한))에 추가됩니다."
 ],
 "A pool with this name exists already.": [
  null,
  "이와 같은 이름을 갖는 풀은 이미 존재합니다."
 ],
 "A volume group with missing physical volumes can not be renamed.": [
  null,
  "누락된 물리 볼륨인 볼륨 그룹은 이름을 재지정 할 수 없습니다."
 ],
 "Abort test": [
  null,
  "시험 중지"
 ],
 "Aborted": [
  null,
  "중지됨"
 ],
 "Aborted by a Controller Level Reset": [
  null,
  "제어기 수준 재-지정에 의해 중지됨"
 ],
 "Aborted due to a removal of a namespace from the namespace inventory": [
  null,
  "이름공간 목록에서 이름공간 제거 원인으로 중지됨"
 ],
 "Aborted due to a sanitize operation": [
  null,
  "오염제거 동작으로 인해 중지됨"
 ],
 "Aborted due to the processing of a Format NVM command": [
  null,
  "초기화 NVM 명령의 처리로 인해 중지됨"
 ],
 "Aborted for unknown reason": [
  null,
  "알 수 없는 원인으로 중지됨"
 ],
 "Absent": [
  null,
  "부재"
 ],
 "Acceptable password": [
  null,
  "허용되는 비밀번호"
 ],
 "Action": [
  null,
  "동작"
 ],
 "Actions": [
  null,
  "동작"
 ],
 "Activate": [
  null,
  "활성화"
 ],
 "Activate before resizing": [
  null,
  "크기 조정전 활성화"
 ],
 "Activating $target": [
  null,
  "$target 활성화 중"
 ],
 "Add": [
  null,
  "추가"
 ],
 "Add $0": [
  null,
  "$0 추가"
 ],
 "Add Network Bound Disk Encryption": [
  null,
  "네트워크 연결 디스크 암호화 추가"
 ],
 "Add Tang keyserver": [
  null,
  "Tang 키 서버 추가"
 ],
 "Add a bitmap": [
  null,
  "비트맵 추가"
 ],
 "Add block devices": [
  null,
  "블록 장치 추가"
 ],
 "Add disk": [
  null,
  "디스크 추가"
 ],
 "Add disks": [
  null,
  "디스크 추가"
 ],
 "Add iSCSI portal": [
  null,
  "iSCSI 포털 추가"
 ],
 "Add key": [
  null,
  "키 추가"
 ],
 "Add keyserver": [
  null,
  "키 서버 추가"
 ],
 "Add passphrase": [
  null,
  "암호문 추가"
 ],
 "Add physical volume": [
  null,
  "물리 볼륨 추가"
 ],
 "Adding \"$0\" to encryption options": [
  null,
  "암호화 옵션에 \"$0\"를 추가하기"
 ],
 "Adding \"$0\" to filesystem options": [
  null,
  "파일 시스템 옵션에 \"$0\" 추가하기"
 ],
 "Adding a keyserver requires unlocking the pool. Please provide the existing pool passphrase.": [
  null,
  "키 서버 추가하기는 풀 잠금 해제가 필요합니다. 기존 풀 암호문을 제공해 주세요."
 ],
 "Adding key": [
  null,
  "키 추가 중"
 ],
 "Adding physical volume to $target": [
  null,
  "$target 에 물리 볼륨 추가 중"
 ],
 "Adding rd.neednet=1 to kernel command line": [
  null,
  "커널 명령행에 rd.neednet=1 추가하기"
 ],
 "Additional packages:": [
  null,
  "추가 꾸러미 :"
 ],
 "Address": [
  null,
  "주소"
 ],
 "Address cannot be empty": [
  null,
  "주소는 비워 둘 수 없습니다"
 ],
 "Address is not a valid URL": [
  null,
  "주소가 유효하지 않습니다"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Cockpit 웹 콘솔로 관리"
 ],
 "Advanced TCA": [
  null,
  "고급 TCA"
 ],
 "All $0 selected physical volumes are needed for the chosen layout.": [
  null,
  "모든 $0 의 선택된 물리 볼륨은 선택된 배열을 위해 필요합니다."
 ],
 "All media is in read-only mode": [
  null,
  "모든 미디어가 읽기-전용 방식입니다"
 ],
 "All-in-one": [
  null,
  "일체형"
 ],
 "Allocated": [
  null,
  "할당됨"
 ],
 "Allow overprovisioning": [
  null,
  "과도공급 허용"
 ],
 "An additional $0 must be selected": [
  null,
  "추가 $0 를 선택해야 합니다"
 ],
 "Ansible": [
  null,
  "앤서블"
 ],
 "Ansible roles documentation": [
  null,
  "Ansible 역할 문서"
 ],
 "Appropriate for critical mounts, such as /var": [
  null,
  "/var와 같은 중요한 적재에 적절한"
 ],
 "Assessment": [
  null,
  "평가"
 ],
 "At boot": [
  null,
  "부팅"
 ],
 "At least $0 disk is needed.": [
  null,
  "최소 $0 개의 디스크가 필요합니다."
 ],
 "At least one block device is needed.": [
  null,
  "최소 1개의 블록 장치가 필요합니다."
 ],
 "At least one disk is needed.": [
  null,
  "최소 1개의 디스크가 필요합니다."
 ],
 "At least one subvolume needs to be mounted": [
  null,
  "적어도 하나의 하위 볼륨은 적재되어야 합니다"
 ],
 "Attributes failing": [
  null,
  "속성 실패"
 ],
 "Authentication": [
  null,
  "인증"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Cockpit 웹 콘솔의 권한 작업을 수행하려면 인증이 필요합니다"
 ],
 "Authentication required": [
  null,
  "인증이 필요합니다"
 ],
 "Authorize SSH key": [
  null,
  "SSH 키 승인"
 ],
 "Automatically using NTP": [
  null,
  "자동으로 NTP 사용"
 ],
 "Automatically using additional NTP servers": [
  null,
  "추가 NTP 서버를 자동으로 사용"
 ],
 "Automatically using specific NTP servers": [
  null,
  "특정 NTP 서버를 자동으로 사용"
 ],
 "Automation script": [
  null,
  "자동 스크립트"
 ],
 "Available targets on $0": [
  null,
  "$0 에서 사용 가능한 대상"
 ],
 "BIOS boot partition": [
  null,
  "바이오스 부트 파티션"
 ],
 "Blade": [
  null,
  "블레이드"
 ],
 "Blade enclosure": [
  null,
  "블레이드 인클로저"
 ],
 "Block device": [
  null,
  "블럭 장치"
 ],
 "Block device for filesystems": [
  null,
  "파일 시스템의 블록 장치"
 ],
 "Block devices": [
  null,
  "블록 장치"
 ],
 "Blocked": [
  null,
  "차단됨"
 ],
 "Boot fails if filesystem does not mount, preventing remote access": [
  null,
  "만약 파일 시스템이 적재되지 않으면 부팅이 실패하여 원격 접근이 차단됨"
 ],
 "Boot still succeeds when filesystem does not mount": [
  null,
  "파일 시스템이 적재되어 않았을 때에도 부팅이 계속 진행됩니다"
 ],
 "Bus expansion chassis": [
  null,
  "버스 확장 섀시"
 ],
 "Cache": [
  null,
  "캐쉬"
 ],
 "Cancel": [
  null,
  "취소"
 ],
 "Cannot forward login credentials": [
  null,
  "로그인 정보를 전송할 수 없습니다"
 ],
 "Cannot schedule event in the past": [
  null,
  "이전 이벤트를 예약할 수 없습니다"
 ],
 "Capacity": [
  null,
  "용량"
 ],
 "Category": [
  null,
  "분류"
 ],
 "Change": [
  null,
  "변경"
 ],
 "Change iSCSI initiator name": [
  null,
  "iSCSI 개시자 이름 변경"
 ],
 "Change label": [
  null,
  "분류 변경"
 ],
 "Change passphrase": [
  null,
  "암호문 변경"
 ],
 "Change system time": [
  null,
  "시스템 시간 변경"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "때때로 운영 체제 재설치로 인해 키가 변경될 수 있습니다. 그러나 예기치 않은 변경은 연결을 가로채는 타사의 시도를 나타낼 수도 있습니다."
 ],
 "Changing partition types might prevent the system from booting.": [
  null,
  "파티션 유형 변경은 부팅을 막을 수 있습니다."
 ],
 "Check that the SHA-256 or SHA-1 hash from the command matches this dialog.": [
  null,
  "명령에서 SHA-256 또는 SHA-1 해쉬가 이와 같은 대화상자와 일치하는지 확인합니다."
 ],
 "Check the key hash with the Tang server.": [
  null,
  "탕(Tang) 서버와 함께 키 해쉬를 확인합니다."
 ],
 "Checking $target": [
  null,
  "$target 확인 중"
 ],
 "Checking MDRAID device $target": [
  null,
  "MD레이드 장치 $target 확인 중"
 ],
 "Checking and repairing MDRAID device $target": [
  null,
  "MD레이드 장치 $target 확인과 복구 중"
 ],
 "Checking filesystem usage": [
  null,
  "파일시스템 사용량 확인 중"
 ],
 "Checking for $0 package": [
  null,
  "$0 꾸러미를 점검 중"
 ],
 "Checking for NBDE support in the initrd": [
  null,
  "initrd에서 NBDE 지원을 위한 점검하기"
 ],
 "Checking installed software": [
  null,
  "설치된 소프트웨어 확인 중"
 ],
 "Chunk size": [
  null,
  "청크 크기"
 ],
 "Cleaning up for $target": [
  null,
  "$target 지우는 중"
 ],
 "Clear input value": [
  null,
  "입력 값 초기화"
 ],
 "Cleartext device": [
  null,
  "일반 문자 장치"
 ],
 "Close": [
  null,
  "닫기"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "NetworkManager 및 Firewalld의 Cockpit 구성"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit을 지정된 호스트에 연결 할 수 없습니다."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit은 웹 브라우저에서 리눅스 서버를 쉽게 관리 할 수 있는 서버 관리자입니다. 터미널과 웹 도구을 구분하지 않고 사용할 수 있습니다. Cockpit에서 시작된 서비스는 터미널을 통해 중지할 수 있습니다. 마찬가지로 터미널에서 오류가 발생한 경우 해당 오류를 Cockpit 저널 연결장치에서 확인 할 수 있습니다."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit은 시스템의 소프트웨어와 호환성이 없습니다."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit이 설치되어 있지 않습니다"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "시스템에 Cockpit이 설치되어 있지 않습니다."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit은 경험이 적은 시스템 관리자에게 적합합니다. 시스템 관리자는 저장장치 관리, 저널 검사, 서비스 시작 및 중지 등의 간단한 작업을 쉽게 수행할 수 있으며 여러 서버를 동시에 모니터링 및 관리 할 수 있습니다. 간단하게 장비를 추가하여 서버를 추가할 수 있으며 추가 후 다른 기기를 관리할 수 있습니다."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "진단 및 지원 자료 수집 및 꾸러미"
 ],
 "Collect kernel crash dumps": [
  null,
  "커널 충돌 덤프 수집"
 ],
 "Command": [
  null,
  "명령"
 ],
 "Compact PCI": [
  null,
  "PCI 압축"
 ],
 "Compatible with all systems and devices (MBR)": [
  null,
  "모든 시스템과 장치와 호환됩니다 (MBR)"
 ],
 "Compatible with modern system and hard disks > 2TB (GPT)": [
  null,
  "최신 시스템과 2TB 이상의 하드 디스크와 호환됩니다 (GPT)"
 ],
 "Completed with a segment that failed and the segment that failed is not known": [
  null,
  "실패한 부분으로 완료하였으며 실패한 부분은 알 수 없습니다"
 ],
 "Completed with one or more failed segments": [
  null,
  "하나 이상으로 실패한 부분으로 완료됨"
 ],
 "Compression": [
  null,
  "압축"
 ],
 "Confirm": [
  null,
  "확인"
 ],
 "Confirm deletion of $0": [
  null,
  "$0 삭제를 확인합니다"
 ],
 "Confirm key password": [
  null,
  "키 비밀빈호 확인"
 ],
 "Confirm removal with an alternate passphrase": [
  null,
  "대체 암호문 삭제 확인"
 ],
 "Confirm stopping of $0": [
  null,
  "$0 의 정지를 확인합니다"
 ],
 "Connection has timed out.": [
  null,
  "연결 시간 초과."
 ],
 "Convertible": [
  null,
  "변환 가능"
 ],
 "Copied": [
  null,
  "복사됨"
 ],
 "Copy": [
  null,
  "복사"
 ],
 "Copy to clipboard": [
  null,
  "클립보드로 복사"
 ],
 "Create": [
  null,
  "생성"
 ],
 "Create $0": [
  null,
  "$0 생성"
 ],
 "Create LVM2 volume group": [
  null,
  "LVM2 볼륨 그룹 만들기"
 ],
 "Create MDRAID device": [
  null,
  "MD레이드 장치 만들기"
 ],
 "Create RAID device": [
  null,
  "레이드 장치 만들기"
 ],
 "Create Stratis pool": [
  null,
  "스트라티스 풀 생성"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "신규 SSH 키를 생성하고 승인합니다"
 ],
 "Create a snapshot of filesystem $0": [
  null,
  "파일 시스템 $0 의 순간찍기 생성"
 ],
 "Create and mount": [
  null,
  "생성과 적재"
 ],
 "Create and start": [
  null,
  "생성과 시작"
 ],
 "Create filesystem": [
  null,
  "파일 시스템 생성"
 ],
 "Create logical volume": [
  null,
  "논리 볼륨 만들기"
 ],
 "Create new filesystem": [
  null,
  "신규 파일 시스템 생성"
 ],
 "Create new logical volume": [
  null,
  "신규 논리 볼륨 만들기"
 ],
 "Create new task file with this content.": [
  null,
  "이 컨텐츠로 신규 작업 파일을 만듭니다."
 ],
 "Create new thinly provisioned logical volume": [
  null,
  "신규 씬 프로비젼닝 논리 볼륨 만들기"
 ],
 "Create only": [
  null,
  "읽기 전용"
 ],
 "Create partition": [
  null,
  "파티션 만들기"
 ],
 "Create partition on $0": [
  null,
  "$0 에서 파티션 생성"
 ],
 "Create partition table": [
  null,
  "파티션 테이블 만들기"
 ],
 "Create snapshot": [
  null,
  "순간찍기 만들기"
 ],
 "Create snapshot and mount": [
  null,
  "순간찍기 생성과 적재"
 ],
 "Create snapshot only": [
  null,
  "순간찍기 전용 생성"
 ],
 "Create storage device": [
  null,
  "저장소 장치 만들기"
 ],
 "Create subvolume": [
  null,
  "하위볼륨 만들기"
 ],
 "Create thin volume": [
  null,
  "씬 볼륨 만들기"
 ],
 "Create volume group": [
  null,
  "볼륨 그룹 만들기"
 ],
 "Creating LVM2 volume group $target": [
  null,
  "LVM2 볼륨 그룹 $target 생성 중"
 ],
 "Creating MDRAID device $target": [
  null,
  "MD레이드 장치 $target 생성 중"
 ],
 "Creating VDO device": [
  null,
  "VDO 장치 생성 중"
 ],
 "Creating filesystem on $target": [
  null,
  "$target 에 파일 시스템 만드는 중"
 ],
 "Creating logical volume $target": [
  null,
  "논리 볼륨 $target 생성 중"
 ],
 "Creating partition $target": [
  null,
  "파티션 $target 생성 중"
 ],
 "Creating snapshot of $target": [
  null,
  "$target 순간찍기 생성 중"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Currently in use": [
  null,
  "현재 사용 중"
 ],
 "Custom": [
  null,
  "사용자 지정"
 ],
 "Custom mount options": [
  null,
  "사용자 정의 적재 옵션"
 ],
 "Custom type": [
  null,
  "사용자 유형"
 ],
 "Data": [
  null,
  "데이터"
 ],
 "Data used": [
  null,
  "사용된 데이터"
 ],
 "Data will be stored as two copies and also in an alternating fashion on the selected physical volumes, to improve both reliability and performance. At least four volumes need to be selected.": [
  null,
  "자료는 안정성과 성능을 모두 향상시키기 위해 선택한 물리적 볼륨에 두 개의 복사본으로 교대로 저장됩니다. 선택하려면 적어도 4개의 볼륨이 필요합니다."
 ],
 "Data will be stored as two or more copies on the selected physical volumes, to improve reliability. At least two volumes need to be selected.": [
  null,
  "자료는 안정성을 향상시키기 위해 선택한 물리적 볼륨에 두 개 이상의 복사본으로 저장됩니다. 선택하려면 적어도 2개의 볼륨이 필요합니다."
 ],
 "Data will be stored on the selected physical volumes in an alternating fashion to improve performance. At least two volumes need to be selected.": [
  null,
  "자료는 성능을 모두 향상시키기 위해 교대로 선택한 물리적 볼륨에 저장됩니다. 선택하려면 적어도 2개의 볼륨이 필요합니다."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. At least three volumes need to be selected.": [
  null,
  "자료는 선택한 물리적 볼륨에 저장되므로 그 중 하나가 손실되어도 영향을 주지 않습니다. 선택하려면 최소한 3개의 볼륨이 필요합니다."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. Data is also stored in an alternating fashion to improve performance. At least three volumes need to be selected.": [
  null,
  "자료는 선택한 물리적 볼륨에 저장되므로 그 중 하나가 손실되어도 영향을 주지 않습니다. 자료는 또한 성능을 향상하기 위해 교차 저장됩니다. 선택하려면 최소한 3개의 볼륨이 필요합니다."
 ],
 "Data will be stored on the selected physical volumes so that up to two of them can be lost at the same time without affecting the data. Data is also stored in an alternating fashion to improve performance. At least five volumes need to be selected.": [
  null,
  "자료는 선택한 물리적 볼륨에 저장되므로 그 중 두 개가 손실되어도 영향을 주지 않습니다. 자료는 또한 성능을 향상하기 위해 교차 저장됩니다. 선택하려면 최소한 5개의 볼륨이 필요합니다."
 ],
 "Data will be stored on the selected physical volumes without any additional redundancy or performance improvements.": [
  null,
  "자료는 어떤 추가적인 중복 또는 성능 개선없이 선택된 물리 볼륨에 저장됩니다."
 ],
 "Deactivate": [
  null,
  "비활성화"
 ],
 "Deactivate logical volume $0/$1?": [
  null,
  "논리 볼륨 $0/$1 을 비활성할까요?"
 ],
 "Deactivating $target": [
  null,
  "$target 비활성화 중"
 ],
 "Dedicated parity (RAID 4)": [
  null,
  "전용 페리티 (레이드 4)"
 ],
 "Deduplication": [
  null,
  "중복"
 ],
 "Degraded": [
  null,
  "강등됨"
 ],
 "Delay": [
  null,
  "지연"
 ],
 "Delete": [
  null,
  "삭제"
 ],
 "Delete filesystem": [
  null,
  "파일시스템 삭제"
 ],
 "Delete group": [
  null,
  "그룹 삭제"
 ],
 "Delete pool": [
  null,
  "풀 삭제"
 ],
 "Deleting $target": [
  null,
  "$target 삭제 중"
 ],
 "Deleting LVM2 volume group $target": [
  null,
  "LVM2 볼륨 그룹 $target 삭제 중"
 ],
 "Deleting a Stratis pool will erase all data it contains.": [
  null,
  "스트라티스 풀 삭제는 이를 포함한 모든 자료를 삭제합니다."
 ],
 "Deleting a filesystem will delete all data in it.": [
  null,
  "파일 시스템을 삭제는 해당 파일에 있는 모든 자료를 삭제합니다."
 ],
 "Deleting a logical volume will delete all data in it.": [
  null,
  "논리 볼륨을 삭제하면 논리 볼륨 내의 모든 데이터도 함께 삭제됩니다."
 ],
 "Deleting a partition will delete all data in it.": [
  null,
  "파티션을 삭제하면 파티션 내의 모든 자료도 함께 삭제됩니다."
 ],
 "Deleting erases all data on a MDRAID device.": [
  null,
  "삭제하면 MD레이드 장치에서 모든 자료를 삭제합니다."
 ],
 "Deleting erases all data on a VDO device.": [
  null,
  "삭제하면 VDO 장치에서 모든 자료를 삭제합니다."
 ],
 "Deleting erases all data on a btrfs volume.": [
  null,
  "삭제하기는 btrfs 볼륨에서 모든 자료를 제거합니다."
 ],
 "Deleting erases all data on a volume group.": [
  null,
  "삭제하면 볼륨 그룹에서 모든 자료가 제거됩니다."
 ],
 "Deleting erases all data on this subvolume and all its children.": [
  null,
  "삭제하면 이와 같은 하위 볼륨에서의 모든 자료와 모든 하위 볼륨이 제거됩니다."
 ],
 "Description": [
  null,
  "설명"
 ],
 "Desktop": [
  null,
  "데스크탑"
 ],
 "Detachable": [
  null,
  "분리 가능"
 ],
 "Device": [
  null,
  "장치"
 ],
 "Device contains unrecognized data": [
  null,
  "장치가 인식되지 않는 자료를 포함합니다"
 ],
 "Device file": [
  null,
  "장치 파일"
 ],
 "Device health (SMART)": [
  null,
  "장치 상태 (SMART)"
 ],
 "Device is read-only": [
  null,
  "장치는 읽기 전용입니다"
 ],
 "Device number": [
  null,
  "장치 번호"
 ],
 "Diagnostic reports": [
  null,
  "진단 보고서"
 ],
 "Did not complete": [
  null,
  "완료되지 않았습니다"
 ],
 "Disconnect": [
  null,
  "연결 끊김"
 ],
 "Disk is OK": [
  null,
  "디스크는 정상입니다"
 ],
 "Disk is failing": [
  null,
  "디스크에 오류가 났습니다"
 ],
 "Disk passphrase": [
  null,
  "디스크 비밀번호"
 ],
 "Disks": [
  null,
  "디스크"
 ],
 "Dismiss": [
  null,
  "제거"
 ],
 "Distributed parity (RAID 5)": [
  null,
  "분산 패리티 (레이드 5)"
 ],
 "Do not mount": [
  null,
  "적재하지 않습니다"
 ],
 "Do not mount automatically on boot": [
  null,
  "부팅시 자동으로 적재하지 마세요"
 ],
 "Docking station": [
  null,
  "도킹 스테이션"
 ],
 "Does not mount during boot": [
  null,
  "부팅시 적재하지 않습니다"
 ],
 "Double distributed parity (RAID 6)": [
  null,
  "이중 분산 패리티 (레이드 6)"
 ],
 "Downloading $0": [
  null,
  "$0 내려받기 중"
 ],
 "Drive": [
  null,
  "드라이브"
 ],
 "Dual rank": [
  null,
  "듀얼 랭크"
 ],
 "EFI system partition": [
  null,
  "EFI 시스템 파티션"
 ],
 "Edit": [
  null,
  "편집"
 ],
 "Edit Tang keyserver": [
  null,
  "Tang 키 서버 편집"
 ],
 "Edit mount point": [
  null,
  "적재 지점 편집"
 ],
 "Editing a key requires a free slot": [
  null,
  "키 편집에 빈 슬롯이 필요합니다"
 ],
 "Ejecting $target": [
  null,
  "$target 꺼내는 중"
 ],
 "Embedded PC": [
  null,
  "임베디드 PC"
 ],
 "Emptying $target": [
  null,
  "$target 비우는 중"
 ],
 "Enabling $0": [
  null,
  "$0 활성화"
 ],
 "Encrypt data with a Tang keyserver": [
  null,
  "Tang 키 서버로 데이터 암호화"
 ],
 "Encrypt data with a passphrase": [
  null,
  "암호로 데이터 암호화"
 ],
 "Encrypted $0": [
  null,
  "$0 암호화됩니다"
 ],
 "Encrypted Stratis pool": [
  null,
  "암호화된 스트라티스 풀"
 ],
 "Encrypted logical volume of $0": [
  null,
  "$0 의 암호화된 논리 볼륨"
 ],
 "Encrypted partition of $0": [
  null,
  "$0 의 암호화된 파티션"
 ],
 "Encryption": [
  null,
  "암호화"
 ],
 "Encryption options": [
  null,
  "암호화 옵션"
 ],
 "Encryption type": [
  null,
  "암호화 유형"
 ],
 "Erasing $target": [
  null,
  "$target 제거 중"
 ],
 "Error": [
  null,
  "오류"
 ],
 "Error installing $0: PackageKit is not installed": [
  null,
  "$0 설치 중에 오류 발생: PackageKit이 설치되어 있지 않습니다"
 ],
 "Exactly $0 physical volumes must be selected": [
  null,
  "정확히 $0 물리 볼륨이 선택되어야 합니다"
 ],
 "Exactly $0 physical volumes need to be selected, one for each stripe of the logical volume.": [
  null,
  "정확히 $0 물리 볼륨은 논리 볼륨의 개별 스트라이프 마다 선택되어야 합니다."
 ],
 "Excellent password": [
  null,
  "우수한 비밀번호"
 ],
 "Expansion chassis": [
  null,
  "확장 섀시"
 ],
 "Extended partition": [
  null,
  "확장 파티션"
 ],
 "Failed": [
  null,
  "실패함"
 ],
 "Failed (Damaged)": [
  null,
  "실패함 (손상됨)"
 ],
 "Failed (Electrical)": [
  null,
  "실패함 (전기요인)"
 ],
 "Failed (Read)": [
  null,
  "실패함 (읽기)"
 ],
 "Failed (Servo)": [
  null,
  "실패함 (서보)"
 ],
 "Failed (Unknown)": [
  null,
  "실패함 (알 수 없음)"
 ],
 "Failed to change password": [
  null,
  "비밀번호 변경 실패"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "방화벽에서 $0 활성화에 실패"
 ],
 "Filesystem": [
  null,
  "파일시스템"
 ],
 "Filesystem is locked": [
  null,
  "파일 시스템이 잠겨 있습니다"
 ],
 "Filesystem is mounted read-only": [
  null,
  "파일시스템이 읽기-전용으로 적재되었습니다"
 ],
 "Filesystem name": [
  null,
  "파일시스템 이름"
 ],
 "Filesystem outside the target": [
  null,
  "대상 외부의 파일시스템"
 ],
 "Filesystems are already mounted below this mountpoint.": [
  null,
  "파일 시스템은 이미 이 적재지점 아래에 적재되어 있습니다."
 ],
 "Firmware version": [
  null,
  "펌웨어 버전"
 ],
 "Fix NBDE support": [
  null,
  "NBDE 지원 수정"
 ],
 "Format": [
  null,
  "포맷"
 ],
 "Format $0": [
  null,
  "$0 포맷"
 ],
 "Format and mount": [
  null,
  "초기화 및 적재"
 ],
 "Format and start": [
  null,
  "초기화 및 시작"
 ],
 "Format only": [
  null,
  "초기화 전용"
 ],
 "Formatting erases all data on a storage device.": [
  null,
  "초기화하면 저장장치에서 모든 자료가 제거됩니다."
 ],
 "Free space": [
  null,
  "여유공간"
 ],
 "Go to now": [
  null,
  "지금 바로 가기"
 ],
 "Grow": [
  null,
  "확장"
 ],
 "Grow content": [
  null,
  "컨텐츠 확장"
 ],
 "Grow logical size of $0": [
  null,
  "$0 의 논리 크기 확장"
 ],
 "Grow logical volume": [
  null,
  "논리 불륨 확장"
 ],
 "Grow partition": [
  null,
  "파티션 늘리기"
 ],
 "Grow the pool to take all space": [
  null,
  "모든 공간을 사용하여 풀 확장하기"
 ],
 "Grow to take all space": [
  null,
  "모든 공간을 사용하여 확장하기"
 ],
 "Handheld": [
  null,
  "휴대용"
 ],
 "Hard Disk Drive": [
  null,
  "하드 디스크 드라이브"
 ],
 "Hide confirmation password": [
  null,
  "확인 비밀번호 숨기기"
 ],
 "Hide password": [
  null,
  "비밀번호 숨기기"
 ],
 "Host key is incorrect": [
  null,
  "호스트 키가 잘못되었습니다"
 ],
 "How to check": [
  null,
  "점검하는 방법"
 ],
 "I confirm I want to lose this data forever": [
  null,
  "이 자료를 영구히 버리고자 확인합니다"
 ],
 "ID": [
  null,
  "ID"
 ],
 "INTERNAL ERROR - This logical volume is marked as active and should have an associated block device. However, no such block device could be found.": [
  null,
  "내부 오류 - 이와 같은 논리 볼륨은 활성화로 표시되며 연관된 블록 장치가 있어야 합니다. 아무튼, 이런 블럭 장치를 찾을 수 없습니다."
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "만약 지문이 일치하면, '키 ' 호스트 신뢰 및 추가'를 눌러주세요. 그렇지 않다면, 연결하지 않고 관리자에게 문의하세요."
 ],
 "Important data might be deleted:": [
  null,
  "중요한 자료가 삭제 될 수 있습니다:"
 ],
 "In a terminal, run: ": [
  null,
  "터미널에서 실행합니다: "
 ],
 "In progress": [
  null,
  "진행 중"
 ],
 "In sync": [
  null,
  "동기화"
 ],
 "Inactive logical volume": [
  null,
  "논리 볼륨 비활성화"
 ],
 "Inconsistent filesystem mount": [
  null,
  "일관되지 않은 파일 시스템 적재"
 ],
 "Index memory": [
  null,
  "인덱스 메모리"
 ],
 "Initialize": [
  null,
  "초기화합니다"
 ],
 "Initialize disk $0": [
  null,
  "디스크 $0 를 초기화합니다"
 ],
 "Initializing erases all data on a disk.": [
  null,
  "초기화는 디스크에서 모든 자료를 제거합니다."
 ],
 "Install": [
  null,
  "설치"
 ],
 "Install NFS support": [
  null,
  "NFS 지원 설치"
 ],
 "Install Stratis support": [
  null,
  "스트라티스 지원 설치"
 ],
 "Install software": [
  null,
  "소프트웨어 설치"
 ],
 "Installing $0": [
  null,
  "$0 설치 중"
 ],
 "Installing $0 would remove $1.": [
  null,
  "$0 를 설치하면 $1 가 제거됩니다."
 ],
 "Installing packages": [
  null,
  "꾸러미 설치"
 ],
 "Internal error": [
  null,
  "내부 오류"
 ],
 "Interrupted": [
  null,
  "중단됨"
 ],
 "Invalid date format": [
  null,
  "잘못된 날짜 형식"
 ],
 "Invalid date format and invalid time format": [
  null,
  "잘못된 날짜 형식 및 잘못된 시간 형식"
 ],
 "Invalid file permissions": [
  null,
  "잘못된 파일 권한"
 ],
 "Invalid time format": [
  null,
  "잘못된 시간 형식"
 ],
 "Invalid timezone": [
  null,
  "잘못된 시간대"
 ],
 "Invalid username or password": [
  null,
  "잘못된 사용자 이름 또는 비밀번호"
 ],
 "IoT gateway": [
  null,
  "IoT 게이트웨이"
 ],
 "Jobs": [
  null,
  "작업"
 ],
 "Kernel dump": [
  null,
  "커널 덤프"
 ],
 "Key password": [
  null,
  "키 비밀번호"
 ],
 "Key slots with unknown types can not be edited here": [
  null,
  "알 수 없는 유형의 키 슬롯은 여기에서 수정할 수 없습니다"
 ],
 "Key source": [
  null,
  "키 소스"
 ],
 "Keys": [
  null,
  "키"
 ],
 "Keyserver": [
  null,
  "키 서버"
 ],
 "Keyserver address": [
  null,
  "키 서버 주소"
 ],
 "Keyserver removal may prevent unlocking $0.": [
  null,
  "키 서버를 제거하면 $0 잠금 해제가 되지 않을 수 있습니다."
 ],
 "LVM2 VDO pool": [
  null,
  "LVM2 VDO 풀"
 ],
 "LVM2 logical volume": [
  null,
  "LVM2 논리 볼륨"
 ],
 "LVM2 logical volumes": [
  null,
  "LVM2 논리 볼륨"
 ],
 "LVM2 physical volume": [
  null,
  "LVM2 물리 볼륨"
 ],
 "LVM2 physical volumes": [
  null,
  "LVM2 물리 볼륨"
 ],
 "LVM2 volume group": [
  null,
  "LVM2 볼륨 그룹"
 ],
 "LVM2 volume group $0": [
  null,
  "LVM2 볼륨 그룹 $0"
 ],
 "Label": [
  null,
  "이름표"
 ],
 "Laptop": [
  null,
  "랩탑"
 ],
 "Last cannot be removed": [
  null,
  "마지막은 제거 될 수 없습니다"
 ],
 "Last disk can not be removed": [
  null,
  "마지막 디스크는 제거 될 수 없습니다"
 ],
 "Last modified: $0": [
  null,
  "마지막 수정 날짜: $0"
 ],
 "Layout": [
  null,
  "배열"
 ],
 "Learn more": [
  null,
  "더 알아보기"
 ],
 "Limit size": [
  null,
  "크기 제한"
 ],
 "Limit virtual filesystem size": [
  null,
  "가상 파일시스템 크기를 제한합니다"
 ],
 "Linear": [
  null,
  "선형성"
 ],
 "Linux filesystem data": [
  null,
  "리눅스 파일시스템 자료"
 ],
 "Linux swap space": [
  null,
  "리눅스 스왑 공간"
 ],
 "Loading system modifications...": [
  null,
  "시스템 수정 적재 중..."
 ],
 "Loading...": [
  null,
  "적재 중..."
 ],
 "Local mount point": [
  null,
  "로컬 적재 지점"
 ],
 "Local storage": [
  null,
  "로컬 저장소"
 ],
 "Location": [
  null,
  "위치"
 ],
 "Lock": [
  null,
  "잠그기"
 ],
 "Lock $0?": [
  null,
  "$0 잠금?"
 ],
 "Locked data": [
  null,
  "잠김 자료"
 ],
 "Locked encrypted device might contain data": [
  null,
  "잠긴 암호화된 장치에 자료가 포함 될 수 있습니다"
 ],
 "Locking $target": [
  null,
  "$target 잠금 중"
 ],
 "Log in": [
  null,
  "로그인"
 ],
 "Log in to $0": [
  null,
  "$0 로 로그인"
 ],
 "Log messages": [
  null,
  "로그 메세지"
 ],
 "Logical": [
  null,
  "논리"
 ],
 "Logical Volume Manager partition": [
  null,
  "논리 볼륨 관리 파티션"
 ],
 "Logical size": [
  null,
  "논리 크기"
 ],
 "Logical volume": [
  null,
  "논리 볼륨"
 ],
 "Logical volume (snapshot)": [
  null,
  "논리 볼륨(순간찍기)"
 ],
 "Logical volume of $0": [
  null,
  "$0 논리 볼륨"
 ],
 "Login failed": [
  null,
  "로그인 실패"
 ],
 "Low profile desktop": [
  null,
  "낮은 프로파일 데스크탑"
 ],
 "Lunch box": [
  null,
  "Lunch Box"
 ],
 "MDRAID device": [
  null,
  "MD레이드 장치"
 ],
 "MDRAID device $0": [
  null,
  "MD레이드 장치 $0"
 ],
 "MDRAID device is recovering": [
  null,
  "MD레이드 장치는 복구 중입니다"
 ],
 "MDRAID device must be running": [
  null,
  "MD레이드 장치는 실행 중이어야 합니다"
 ],
 "MDRAID disk": [
  null,
  "MD레이드 디스크"
 ],
 "MDRAID disks": [
  null,
  "MD레이드 디스크"
 ],
 "Main server chassis": [
  null,
  "메인 서버 섀시"
 ],
 "Manage storage": [
  null,
  "관리 저장소"
 ],
 "Manually": [
  null,
  "수동"
 ],
 "Marking $target as faulty": [
  null,
  "$target 를 오류가 있는 것으로 표시"
 ],
 "Media drive": [
  null,
  "미디어 드라이브"
 ],
 "Message to logged in users": [
  null,
  "로그인한 사용자에게 보내는 메세지"
 ],
 "Metadata used": [
  null,
  "사용된 메타데이터"
 ],
 "Mini PC": [
  null,
  "미니 PC"
 ],
 "Mini tower": [
  null,
  "미니 타워"
 ],
 "Mirrored (RAID 1)": [
  null,
  "미러 (레이드 1)"
 ],
 "Model": [
  null,
  "모델"
 ],
 "Modifying $target": [
  null,
  "$target 수정 중"
 ],
 "Mount": [
  null,
  "적재"
 ],
 "Mount Point": [
  null,
  "적재 지점"
 ],
 "Mount after network becomes available, ignore failure": [
  null,
  "네트워크를 사용 할 수 있게 된 후 적재, 실패를 무시합니다"
 ],
 "Mount also automatically on boot": [
  null,
  "부팅시 자동으로 적재"
 ],
 "Mount at boot": [
  null,
  "재시작 시 적재"
 ],
 "Mount automatically on $0 on boot": [
  null,
  "부팅시 $0 에서 자동으로 적재"
 ],
 "Mount before services start": [
  null,
  "서비스를 시작하기 전에 적재"
 ],
 "Mount configuration": [
  null,
  "적재 구성"
 ],
 "Mount filesystem": [
  null,
  "파일 시스템 적재"
 ],
 "Mount now": [
  null,
  "지금 적재"
 ],
 "Mount on $0 now": [
  null,
  "지금 $0 에서 적재"
 ],
 "Mount options": [
  null,
  "적재 옵션"
 ],
 "Mount point": [
  null,
  "적재 지점"
 ],
 "Mount point cannot be empty": [
  null,
  "적재 지점을 비워둘 수 없습니다"
 ],
 "Mount point cannot be empty.": [
  null,
  "적재 지점을 비워둘 수 없습니다."
 ],
 "Mount point is already used for $0": [
  null,
  "적재 지점은 $0 용으로 이미 사용되었습니다"
 ],
 "Mount point must start with \"/\".": [
  null,
  "적재 지점은 \"/\"로 시작해야 합니다."
 ],
 "Mount read only": [
  null,
  "읽기 전용으로 적재"
 ],
 "Mount without waiting, ignore failure": [
  null,
  "기다림 없이 적재, 실패를 무시합니다"
 ],
 "Mounting $target": [
  null,
  "$target 적재 중"
 ],
 "Mounts before services start": [
  null,
  "서비스를 시작하기 전에 적재"
 ],
 "Mounts in parallel with services": [
  null,
  "서비스와 병행하여 적재"
 ],
 "Mounts in parallel with services, but after network is available": [
  null,
  "서비스와 병행하여 적재, 하지만 네트워크가 가용해야 합니다"
 ],
 "Multi-system chassis": [
  null,
  "멀티 시스템 섀시"
 ],
 "Multipathed devices": [
  null,
  "다중 경로 장치"
 ],
 "NFS mount": [
  null,
  "NFS 적재"
 ],
 "NTP server": [
  null,
  "NTP 서버"
 ],
 "Name": [
  null,
  "이름"
 ],
 "Name can not be empty.": [
  null,
  "이름을 입력하셔야 합니다."
 ],
 "Name cannot be empty.": [
  null,
  "이름을 입력하셔야 합니다."
 ],
 "Name cannot be longer than $0 bytes": [
  null,
  "이름은 $0 바이트보다 길 수 없습니다"
 ],
 "Name cannot be longer than $0 characters": [
  null,
  "이름은 $0 자를 초과 할 수 없습니다"
 ],
 "Name cannot be longer than 127 characters.": [
  null,
  "이름은 127자보다 길 수 없습니다."
 ],
 "Name cannot be longer than 255 characters.": [
  null,
  "이름은 255자 보다 길 수 없습니다."
 ],
 "Name cannot contain the character '$0'.": [
  null,
  "이름에는 문자 '$0'를 포함할 수 없습니다."
 ],
 "Name cannot contain the character '/'.": [
  null,
  "이름에는 문자 '/'를 포함 할 수 없습니다."
 ],
 "Name cannot contain whitespace.": [
  null,
  "이름에는 공백이 없어야 합니다."
 ],
 "Need a spare disk": [
  null,
  "예비 디스크가 필요합니다"
 ],
 "Need at least one NTP server": [
  null,
  "최소 하나의 NTP 서버가 필요합니다"
 ],
 "Networked storage": [
  null,
  "네트워크 저장소"
 ],
 "Networking": [
  null,
  "네트워킹"
 ],
 "New NFS mount": [
  null,
  "신규 NFS 적재"
 ],
 "New passphrase": [
  null,
  "신규 암호문"
 ],
 "New password was not accepted": [
  null,
  "신규 비밀번호가 허용되지 않습니다"
 ],
 "Next": [
  null,
  "다음"
 ],
 "No available slots": [
  null,
  "사용 가능한 홈이 없습니다"
 ],
 "No block devices are available.": [
  null,
  "사용 가능한 블록 장치가 없습니다."
 ],
 "No block devices found": [
  null,
  "블럭 장치를 찾을 수 없습니다"
 ],
 "No delay": [
  null,
  "지연 없음"
 ],
 "No devices found": [
  null,
  "장치를 찾을 수 없습니다"
 ],
 "No disks are available.": [
  null,
  "사용 가능한 디스크가 없습니다."
 ],
 "No disks found": [
  null,
  "디스크를 찾을 수 없음"
 ],
 "No drives found": [
  null,
  "드라이브를 찾을 수 없음"
 ],
 "No encryption": [
  null,
  "암호화 없음"
 ],
 "No filesystem": [
  null,
  "파일시스템 없음"
 ],
 "No filesystems": [
  null,
  "파일 시스템 없음"
 ],
 "No free key slots": [
  null,
  "여유 키 슬롯이 없습니다"
 ],
 "No free space": [
  null,
  "여유공간이 없습니다"
 ],
 "No free space after this partition": [
  null,
  "이 파티션 후에는 여유 공간이 없습니다"
 ],
 "No keys added": [
  null,
  "추가된 키가 없습니다"
 ],
 "No logical volumes": [
  null,
  "논리 볼륨 없음"
 ],
 "No media inserted": [
  null,
  "미디어가 삽입되어 있지 않습니다"
 ],
 "No partitioning": [
  null,
  "파티션 설정하지 않음"
 ],
 "No partitions found": [
  null,
  "파티션을 찾을 수 없음"
 ],
 "No physical volumes found": [
  null,
  "물리 볼륨을 찾을 수 없음"
 ],
 "No results found": [
  null,
  "결과를 찾을 수 없습니다"
 ],
 "No snapshots found": [
  null,
  "순간찍기를 찾을 수 없음"
 ],
 "No storage found": [
  null,
  "저장소를 찾을 수 없음"
 ],
 "No subvolumes": [
  null,
  "하위볼륨 없음"
 ],
 "No such file or directory": [
  null,
  "이러한 파일 또는 디렉토리가 없습니다"
 ],
 "No system modifications": [
  null,
  "시스템 수정 없음"
 ],
 "Not a valid private key": [
  null,
  "유효한 개인 키가 없습니다"
 ],
 "Not enough free space": [
  null,
  "여유 공간이 부족합니다"
 ],
 "Not enough space": [
  null,
  "공간이 부족합니다"
 ],
 "Not enough space to grow": [
  null,
  "확장 공간이 부족합니다"
 ],
 "Not found": [
  null,
  "찾을 수 없습니다"
 ],
 "Not permitted to perform this action.": [
  null,
  "이 작업을 실행할 수 있는 권한이 없습니다."
 ],
 "Not running": [
  null,
  "미동작"
 ],
 "Not synchronized": [
  null,
  "동기화 되어 있지 않습니다"
 ],
 "Notebook": [
  null,
  "노트북"
 ],
 "Number of bad sectors": [
  null,
  "배드 섹터 수"
 ],
 "Occurrences": [
  null,
  "발생"
 ],
 "Ok": [
  null,
  "확인"
 ],
 "Old passphrase": [
  null,
  "이전 비밀번호"
 ],
 "Old password not accepted": [
  null,
  "이전 비밀번호가 허용되지 않습니다"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Cockpit이 설치되면 \"systemctl enable --now cockpit.socket\"을 사용하여 이를 활성화합니다."
 ],
 "Only $0 of $1 are used.": [
  null,
  "$1 중 $0 만 사용됩니다."
 ],
 "Operation '$operation' on $target": [
  null,
  "$target 에서 '$operation' 작업"
 ],
 "Options": [
  null,
  "옵션"
 ],
 "Other": [
  null,
  "기타"
 ],
 "Overprovisioning": [
  null,
  "과도공급"
 ],
 "Overwrite": [
  null,
  "덮어쓰기"
 ],
 "Overwrite existing data with zeros (slower)": [
  null,
  "기존의 자료를 제로로 덮어쓰기 (더 느리게)"
 ],
 "PID": [
  null,
  "PID"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit가 충돌했습니다"
 ],
 "Partition": [
  null,
  "파티션"
 ],
 "Partition of $0": [
  null,
  "$0 의 파티션"
 ],
 "Partition size is $0. Content size is $1.": [
  null,
  "파티션 크기는 $0 입니다. 해당 크기는 $1 입니다."
 ],
 "Partitioning": [
  null,
  "파티션"
 ],
 "Partitions": [
  null,
  "파티션"
 ],
 "Partitions are not supported on this block device. If it is used as a disk for a virtual machine, the partitions must be managed by the operating system inside the virtual machine.": [
  null,
  "파티션은 이와 같은 블록 장치에서 지원되지 않습니다. 만약 가상 장비를 위한 디스크로 사용되면, 파티션은 가상 장비 안에 있는 운영체제에 의해 관리되어야 합니다."
 ],
 "Passphrase": [
  null,
  "암호문"
 ],
 "Passphrase can not be empty": [
  null,
  "암호문은 비워 둘 수 없습니다"
 ],
 "Passphrase cannot be empty": [
  null,
  "암호문는 비워 둘 수 없습니다"
 ],
 "Passphrase from any other key slot": [
  null,
  "다른 키 슬롯에서 암호문"
 ],
 "Passphrase removal may prevent unlocking $0.": [
  null,
  "암호문 제거에서 $0 잠금 해제가 되지 않을 수 있습니다."
 ],
 "Passphrases do not match": [
  null,
  "암호문이 일치하지 않습니다"
 ],
 "Password": [
  null,
  "비밀번호"
 ],
 "Password is not acceptable": [
  null,
  "비밀번호가 허용되지 않습니다"
 ],
 "Password is too weak": [
  null,
  "비밀번호가 너무 취약합니다"
 ],
 "Password not accepted": [
  null,
  "비밀번호가 허용되지 않습니다"
 ],
 "Paste": [
  null,
  "붙여넣기"
 ],
 "Paste error": [
  null,
  "붙임 오류"
 ],
 "Path on server": [
  null,
  "서버상의 경로"
 ],
 "Path on server cannot be empty.": [
  null,
  "서버상의 경로는 비워둘 수 없습니다."
 ],
 "Path on server must start with \"/\".": [
  null,
  "서버상의 경로는 \"/\"로 시작해야 합니다."
 ],
 "Path to file": [
  null,
  "파일의 경로"
 ],
 "Peripheral chassis": [
  null,
  "주변 장치 섀시"
 ],
 "Permanently delete $0?": [
  null,
  "영구적으로 $0 를 삭제할까요?"
 ],
 "Permanently delete logical volume $0/$1?": [
  null,
  "영구적으로 논리 볼륨 $0/$1 를 삭제할까요?"
 ],
 "Permanently delete subvolume $0?": [
  null,
  "영구적으로 하위볼륨 $0 를 삭제 할까요?"
 ],
 "Persistent memory has become read-only": [
  null,
  "영구 메모리가 읽기-전용으로 되었습니다"
 ],
 "Physical": [
  null,
  "물리"
 ],
 "Physical Volumes": [
  null,
  "물리 볼륨"
 ],
 "Physical volumes": [
  null,
  "물리 볼륨"
 ],
 "Physical volumes can not be resized here": [
  null,
  "물리적 볼륨은 여기에서 크기를 변경 할 수 없습니다"
 ],
 "Pick date": [
  null,
  "날짜 선택"
 ],
 "Pizza box": [
  null,
  "피자 박스"
 ],
 "Please unmount them first.": [
  null,
  "우선 적재된 부분을 해제해 주세요."
 ],
 "Pool for thin logical volumes": [
  null,
  "씬 논리 볼륨을 위한 풀"
 ],
 "Pool for thinly provisioned LVM2 logical volumes": [
  null,
  "씬 프로비저닝된 LVM2 논리 볼륨을 위한 풀"
 ],
 "Pool for thinly provisioned volumes": [
  null,
  "씬 프로비저닝된 볼륨을 위한 풀"
 ],
 "Pool passphrase": [
  null,
  "풀 암호문"
 ],
 "Port": [
  null,
  "포트"
 ],
 "Portable": [
  null,
  "이동식"
 ],
 "Power on hours": [
  null,
  "동작 시간"
 ],
 "PowerPC PReP boot partition": [
  null,
  "PowerPC PReP 부트 파티션"
 ],
 "Present": [
  null,
  "존재"
 ],
 "Processes using the location": [
  null,
  "위치를 사용하는 프로세스"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "ssh-add를 통한 메세지 제공 시간이 초과되었습니다"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "ssh-keygen을 통한 메세지 제공시간이 초과되었습니다"
 ],
 "Provide the passphrase for the pool on these block devices:": [
  null,
  "이들 블록 장치에서 풀을 위한 암호문를 제공합니다:"
 ],
 "Purpose": [
  null,
  "목적"
 ],
 "RAID ($0)": [
  null,
  "레이드 ($0)"
 ],
 "RAID 0": [
  null,
  "레이드 0"
 ],
 "RAID 0 (stripe)": [
  null,
  "레이드 0(스트라이프)"
 ],
 "RAID 1": [
  null,
  "레이드 1"
 ],
 "RAID 1 (mirror)": [
  null,
  "레이드 1(미러)"
 ],
 "RAID 10": [
  null,
  "레이드 10"
 ],
 "RAID 10 (stripe of mirrors)": [
  null,
  "레이드 10(미러 스트라이프)"
 ],
 "RAID 4": [
  null,
  "레이드 4"
 ],
 "RAID 4 (dedicated parity)": [
  null,
  "레이드 4(전용 패리티)"
 ],
 "RAID 5": [
  null,
  "레이드 5"
 ],
 "RAID 5 (distributed parity)": [
  null,
  "레이드 5(분산 패리티)"
 ],
 "RAID 6": [
  null,
  "레이드 6"
 ],
 "RAID 6 (double distributed parity)": [
  null,
  "레이드 6(이중 분산 패리티)"
 ],
 "RAID chassis": [
  null,
  "레이드 섀시"
 ],
 "RAID level": [
  null,
  "레이드 수준"
 ],
 "RAID10 needs an even number of physical volumes": [
  null,
  "레이드10은 짝수의 물리 볼륨이 필요합니다"
 ],
 "Rack mount chassis": [
  null,
  "랙 적재 구조"
 ],
 "Reading": [
  null,
  "읽기"
 ],
 "Reboot": [
  null,
  "재시작"
 ],
 "Recovering": [
  null,
  "복구 중"
 ],
 "Recovering MDRAID device $target": [
  null,
  "MD레이드 장치 $target 복구 중"
 ],
 "Regenerating initrd": [
  null,
  "initrd 재생하기"
 ],
 "Related processes and services will be forcefully stopped.": [
  null,
  "연관된 프로세서와 서비스는 강제 종료됩니다."
 ],
 "Related processes will be forcefully stopped.": [
  null,
  "연관된 프로세서는 강제 종료됩니다."
 ],
 "Related services will be forcefully stopped.": [
  null,
  "연관된 서비스는 강제 종료됩니다."
 ],
 "Removals:": [
  null,
  "삭제:"
 ],
 "Remove": [
  null,
  "제거"
 ],
 "Remove $0?": [
  null,
  "$0 를 제거할까요?"
 ],
 "Remove Tang keyserver?": [
  null,
  "Tang 키 서버 삭제?"
 ],
 "Remove device": [
  null,
  "장치 삭제"
 ],
 "Remove missing physical volumes?": [
  null,
  "누락된 물리 볼륨 제거?"
 ],
 "Remove passphrase in key slot $0?": [
  null,
  "키 홈 $0 에서 암호문를 제거할까요?"
 ],
 "Remove passphrase?": [
  null,
  "암호문 제거?"
 ],
 "Removing $0": [
  null,
  "$0 삭제 중"
 ],
 "Removing $target from MDRAID device": [
  null,
  "MD레이드 장치에서 $target 제거 중"
 ],
 "Removing a passphrase without confirmation of another passphrase may prevent unlocking or key management, if other passphrases are forgotten or lost.": [
  null,
  "다른 암호문의 확인 없이 암호문을 제거하는 것은 만약 다른 암호문은 잊었거나 또는 잃어 버렸을 경우에 잠금해제 또는 키 관리를 방지 할 수 있습니다."
 ],
 "Removing physical volume from $target": [
  null,
  "$target 에서 물리 볼륨 제거 중"
 ],
 "Rename": [
  null,
  "이름변경"
 ],
 "Rename Stratis pool": [
  null,
  "스트라티스 풀 이름 재지정"
 ],
 "Rename filesystem": [
  null,
  "파일 시스템 이름 변경"
 ],
 "Rename logical volume": [
  null,
  "논리 볼륨 이름 변경"
 ],
 "Rename volume group": [
  null,
  "볼륨 그룹 이름변경"
 ],
 "Renaming $target": [
  null,
  "$target 이름변경 중"
 ],
 "Repair": [
  null,
  "복구"
 ],
 "Repair logical volume $0": [
  null,
  "논리 볼륨 $0 를 복구합니다"
 ],
 "Repairing $target": [
  null,
  "$target 복구 중"
 ],
 "Repeat passphrase": [
  null,
  "암호문 반복"
 ],
 "Resizing $target": [
  null,
  "$target 크기 변경 중"
 ],
 "Resizing an encrypted filesystem requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "암호화된 파일 시스템의 크기를 변경하려면 디스크 잠금을 해제해야 합니다. 현재 디스크의 암호문을 입력하십시오."
 ],
 "Reuse existing encryption": [
  null,
  "기존 암호화 재사용"
 ],
 "Reuse existing encryption ($0)": [
  null,
  "기존 암호화($0) 재사용"
 ],
 "Row expansion": [
  null,
  "행 확장"
 ],
 "Row select": [
  null,
  "행 선택"
 ],
 "Run extended test": [
  null,
  "확장 시험 실행"
 ],
 "Run short test": [
  null,
  "단기 시험 실행"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "신뢰하는 네트워크 또는 원격 장비에서 물리적으로 이와 같은 명령을 실행합니다:"
 ],
 "Running": [
  null,
  "작동중"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SHA-1": [
  null,
  "SHA-1"
 ],
 "SHA-256": [
  null,
  "SHA-256"
 ],
 "SMART self-test of $target": [
  null,
  "$target 의 SMART 자체-시험"
 ],
 "SSH key": [
  null,
  "SSH 키"
 ],
 "SSH key login": [
  null,
  "SSH 키 로그인"
 ],
 "Save": [
  null,
  "저장"
 ],
 "Save space by compressing individual blocks with LZ4": [
  null,
  "LZ4로 개별 블록을 압축하여 공간을 절약합니다"
 ],
 "Save space by storing identical data blocks just once": [
  null,
  "동일한 데이터 블록을 한 번만 저장하여 공간을 절약합니다"
 ],
 "Saving a new passphrase requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "신규 암호문를 저장하려면 디스크 잠금 해제가 필요합니다. 현재 디스크의 암호문을 제공하십시오."
 ],
 "Sealed-case PC": [
  null,
  "쉴드 케이스 PC"
 ],
 "Securely erasing $target": [
  null,
  "$target 를 안전하게 삭제 중"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "보안이 향상된 리눅스 구성과 문제해결"
 ],
 "Select an option": [
  null,
  "옵션을 선택합니다"
 ],
 "Select the physical volumes that should be used to repair the logical volume. At least $0 are needed.": [
  null,
  "논리 볼륨을 복구하는데 사용해야 하는 물리 볼륨을 선택합니다. 적어도 $0 가 필요합니다."
 ],
 "Self-test status": [
  null,
  "자체-시험 상태"
 ],
 "Serial number": [
  null,
  "일련 번호"
 ],
 "Server": [
  null,
  "서버"
 ],
 "Server address": [
  null,
  "서버 주소"
 ],
 "Server address cannot be empty.": [
  null,
  "서버 주소는 비워둘 수 없습니다."
 ],
 "Server cannot be empty.": [
  null,
  "서버는 비워둘 수 없습니다."
 ],
 "Server has closed the connection.": [
  null,
  "서버 연결이 종료되었습니다."
 ],
 "Service": [
  null,
  "서비스"
 ],
 "Services using the location": [
  null,
  "위치를 사용 중인 서비스"
 ],
 "Set": [
  null,
  "설정"
 ],
 "Set initial size": [
  null,
  "초기 크기 설정"
 ],
 "Set limit of virtual filesystem size": [
  null,
  "가상 파일시스템 크기의 제한을 설정합니다"
 ],
 "Set partition type of $0": [
  null,
  "$0 의 파티션 유형을 설정"
 ],
 "Set time": [
  null,
  "시간 설정"
 ],
 "Setting up loop device $target": [
  null,
  "루프 장치 $target 설정 중"
 ],
 "Shell script": [
  null,
  "쉘 스크립트"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show all $0 rows": [
  null,
  "모든 $0 행 표시"
 ],
 "Show confirmation password": [
  null,
  "비밀번호 확인을 표시합니다"
 ],
 "Show password": [
  null,
  "비밀번호 표시"
 ],
 "Shrink": [
  null,
  "축소"
 ],
 "Shrink logical volume": [
  null,
  "논리 볼륨 축소"
 ],
 "Shrink partition": [
  null,
  "파티션 축소"
 ],
 "Shrink volume": [
  null,
  "볼륨 축소"
 ],
 "Shut down": [
  null,
  "종료"
 ],
 "Single rank": [
  null,
  "단일 등급"
 ],
 "Size": [
  null,
  "크기"
 ],
 "Size cannot be negative": [
  null,
  "크기는 음수일 수 없습니다"
 ],
 "Size cannot be zero": [
  null,
  "크기가 0 이 될 수 없습니다"
 ],
 "Size is too large": [
  null,
  "크기가 너무 큽니다"
 ],
 "Size must be a number": [
  null,
  "크기는 숫자여야 합니다"
 ],
 "Size must be at least $0": [
  null,
  "크기는 최소 $0 이어야 합니다"
 ],
 "Slot $0": [
  null,
  "슬롯 $0"
 ],
 "Snapshot": [
  null,
  "순간찍기"
 ],
 "Snapshot origin": [
  null,
  "순간찍기 원본"
 ],
 "Snapshots": [
  null,
  "순간찍기"
 ],
 "Solid State Drive": [
  null,
  "반도체형 드라이브"
 ],
 "Some block devices of this pool have grown in size after the pool was created. The pool can be safely grown to use the newly available space.": [
  null,
  "이 풀의 일부 블록 장치는 풀이 생성된 후 크기가 늘어났습니다. 풀은 새로 사용 가능한 공간을 활용하여 안전하게 확장할 수 있습니다."
 ],
 "Sorry": [
  null,
  "죄송합니다"
 ],
 "Space-saving computer": [
  null,
  "공간-절약형 컴퓨터"
 ],
 "Spare": [
  null,
  "예비"
 ],
 "Spare capacity is below the threshold": [
  null,
  "여유 공간이 한계점 이하입니다"
 ],
 "Specific time": [
  null,
  "특정 시간"
 ],
 "Start": [
  null,
  "시작"
 ],
 "Start multipath": [
  null,
  "멀티패스 시작"
 ],
 "Started": [
  null,
  "시작됨"
 ],
 "Starting MDRAID device $target": [
  null,
  "MD레이드 장치 $target 시작 중"
 ],
 "Starting swapspace $target": [
  null,
  "스왑공간 $target 시작 중"
 ],
 "State": [
  null,
  "상태"
 ],
 "Stick PC": [
  null,
  "스틱 PC"
 ],
 "Stop": [
  null,
  "중지"
 ],
 "Stop and remove": [
  null,
  "중지 및 제거"
 ],
 "Stop and unmount": [
  null,
  "중지 및 적재 해제"
 ],
 "Stop device": [
  null,
  "장치 중지"
 ],
 "Stopping MDRAID device $target": [
  null,
  "MD레이드 장치 $target 중지 중"
 ],
 "Stopping swapspace $target": [
  null,
  "스왑공간 $target 중지 중"
 ],
 "Storage": [
  null,
  "저장소"
 ],
 "Storage can not be managed on this system.": [
  null,
  "저장소는 이 시스템에서 관리 할 수 없습니다."
 ],
 "Storage logs": [
  null,
  "저장소 기록"
 ],
 "Store passphrase": [
  null,
  "암호문 저장"
 ],
 "Stored passphrase": [
  null,
  "저장된 암호문"
 ],
 "Stratis block device": [
  null,
  "스트라티스 블럭 장치"
 ],
 "Stratis block devices": [
  null,
  "스트라티스 블럭 장치"
 ],
 "Stratis blockdevs can not be made smaller": [
  null,
  "Stratis blockdevs를 더 작게 할 수 없습니다"
 ],
 "Stratis filesystem": [
  null,
  "스트라티스 파일 시스템"
 ],
 "Stratis filesystems": [
  null,
  "스트라티스 파일 시스템"
 ],
 "Stratis filesystems pool": [
  null,
  "스트라티스 파일 시스템 풀"
 ],
 "Stratis pool": [
  null,
  "스트라티스 풀"
 ],
 "Striped (RAID 0)": [
  null,
  "스트라이프 (레이드 0)"
 ],
 "Striped and mirrored (RAID 10)": [
  null,
  "미러된 스트라이프 (레이드 10)"
 ],
 "Stripes": [
  null,
  "스트라이프"
 ],
 "Strong password": [
  null,
  "강력한 비밀번호"
 ],
 "Sub-Chassis": [
  null,
  "서브 섀시"
 ],
 "Sub-Notebook": [
  null,
  "서브 노트북"
 ],
 "Successful": [
  null,
  "성공적으로"
 ],
 "Successfully copied to clipboard!": [
  null,
  "성공적으로 클립보드로 복사됨!"
 ],
 "Swap": [
  null,
  "스왑"
 ],
 "Swap can not be resized here": [
  null,
  "스왑은 여기에서 크기를 조정 할 수 없습니다"
 ],
 "Synchronized": [
  null,
  "동기화됩니다"
 ],
 "Synchronized with $0": [
  null,
  "$0 와 동기화됩니다"
 ],
 "Synchronizing": [
  null,
  "동기화 중"
 ],
 "Synchronizing MDRAID device $target": [
  null,
  "MD레이드 장치 $target 동기화 중"
 ],
 "Tablet": [
  null,
  "테블릿"
 ],
 "Tang keyserver": [
  null,
  "Tang 키 서버"
 ],
 "Target": [
  null,
  "대상"
 ],
 "Temperature outside of recommended thresholds": [
  null,
  "추천된 외부 온도 한계점"
 ],
 "The $0 package is not available from any repository.": [
  null,
  "$0 꾸러미는 저장소에서 사용 할 수 없습니다."
 ],
 "The $0 package must be installed to create Stratis pools.": [
  null,
  "$0 꾸러미는 스트라티스 풀을 생성하려면 설치해야 합니다."
 ],
 "The $0 package must be installed.": [
  null,
  "$0 꾸러미는 설치되어야 합니다."
 ],
 "The $0 package will be installed to create VDO devices.": [
  null,
  "$0 꾸러미는 VDO 장치를 생성하려면 설치됩니다."
 ],
 "The MDRAID device is in a degraded state": [
  null,
  "MD레이드 배열은 성능이 저하된 상태입니다"
 ],
 "The MDRAID device must be running": [
  null,
  "MD레이드 장치는 동작 중이어야 합니다"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "$1 의 SSH 키 $0 ($2 에서)는 $4 의 $3 ($5 에서)파일로 추가됩니다."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH 키 $0 는 세션의 나머지 부분에서 사용 할 수 있고 다른 호스트에 로그인 할 때에도 사용 할 수 있습니다."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "$0 에 로그인하기 위한 SSH 키가 비밀번호에 의해 보호되고 있으며, 그리고 호스트는 비밀번호로 로그인을 허용 하지 않습니다. $1 에서 키의 비밀번호를 제공하세요."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "$0 에 로그인하기 위해 SSH 키가 보호되고 있습니다. 당신은 $1 에서 자신의 로그인 비밀번호에 의하거나 키의 비밀번호 제공을 통해 로그인 할 수 있습니다.."
 ],
 "The creation of this VDO device did not finish and the device can't be used.": [
  null,
  "VDO 장치 생성이 완료되지 않았기 때문에 장치를 사용 할 수 없습니다."
 ],
 "The currently logged in user is not permitted to see information about keys.": [
  null,
  "현재 로그인한 사용자는 키에 대한 정보를 볼 수 없습니다."
 ],
 "The disk needs to be unlocked before formatting. Please provide an existing passphrase.": [
  null,
  "디스크는 초기화 하기 전에 잠금이 해제된 상태이어야 합니다. 기존 암호문를 입력하세요."
 ],
 "The filesystem has no assigned mount point.": [
  null,
  "파일시스템은 할당된 적재 지점이 없습니다."
 ],
 "The filesystem has no permanent mount point.": [
  null,
  "파일 시스템에 영구 적재 지점이 없습니다."
 ],
 "The filesystem is configured to be automatically mounted on boot but its encryption container will not be unlocked at that time.": [
  null,
  "파일 시스템이 부팅 시 자동으로 적재되도록 구성되어 있지만 이 암호화된 컨테이너는 그 때에 잠금이 해제되지 않습니다."
 ],
 "The filesystem is currently mounted but will not be mounted after the next boot.": [
  null,
  "파일 시스템이 현재 적재되어 있지만 다음 부팅 후에는 적재되지 않습니다."
 ],
 "The filesystem is currently mounted on $0 but will be mounted on $1 on the next boot.": [
  null,
  "파일 시스템이 현재 $0 에 적재되어 있지만 다음 부팅 후에는 $1 에 적재됩니다."
 ],
 "The filesystem is currently mounted on $0 but will not be mounted after the next boot.": [
  null,
  "파일 시스템이 현재 $0 에 적재되어 있지만 다음 부팅 후에는 적재되지 않습니다."
 ],
 "The filesystem is currently not mounted but will be mounted on the next boot.": [
  null,
  "파일 시스템이 현재 적재되어 있지 않지만 다음 부팅시에 적재됩니다."
 ],
 "The filesystem is not mounted.": [
  null,
  "파일 시스템이 적재되어 있지 않습니다."
 ],
 "The filesystem will be unlocked and mounted on the next boot. This might require inputting a passphrase.": [
  null,
  "파일 시스템은 잠금 해제되어 있어야 하고 다음 부팅시에는 적재됩니다. 이는 암호문를 입력해야 할 수 있습니다."
 ],
 "The fingerprint should match:": [
  null,
  "지문 표시가 일치해야 합니다:"
 ],
 "The initrd must be regenerated.": [
  null,
  "initrd는 재생되어야 합니다."
 ],
 "The key password can not be empty": [
  null,
  "키 비밀번호를 비워둘 수 없습니다"
 ],
 "The key passwords do not match": [
  null,
  "키 비밀번호가 일치하지 않습니다"
 ],
 "The last key slot can not be removed": [
  null,
  "마지막 키 홈은 제거 할 수 없습니다"
 ],
 "The last mounted subvolume can not be deleted": [
  null,
  "마지막 적재된 하위 볼륨은 삭제 될 수 없습니다"
 ],
 "The listed processes and services will be forcefully stopped.": [
  null,
  "나열된 프로세서와 서비스는 강제 종료됩니다."
 ],
 "The listed processes will be forcefully stopped.": [
  null,
  "나열된 프로세서는 강제 종료됩니다."
 ],
 "The listed services will be forcefully stopped.": [
  null,
  "나열된 서비스가 강제로 중지됩니다."
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "로그인한 사용자는 시스템 수정 사항을 볼 수 없습니다"
 ],
 "The mount point $0 is in use by these processes:": [
  null,
  "적재 지점 $0 는 이들 프로세서에 의해서 사용 중입니다:"
 ],
 "The mount point $0 is in use by these services:": [
  null,
  "적재지점 $0 는 이들 서비스에 의해 사용 중입니다:"
 ],
 "The password can not be empty": [
  null,
  "비밀번호를 비워둘 수 없습니다"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "최종 지문을 전자우편을 포함한 공개적인 방법을 통해 공유 할 수 있습니다."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "결과 지문은 전자우편을 포함하는 공개 방식을 통해 공유되어도 해도 좋습니다. 만약 누군가 당신을 위해 인증하도록 요청하는 경우, 어떤 방식을 사용하든 결과를 전송 할 수 있습니다."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "서버가 지원되는 방법을 사용하여 인증을 거부했습니다."
 ],
 "The system does not currently support unlocking a filesystem with a Tang keyserver during boot.": [
  null,
  "시스템은 현재 부팅시에 탕 키서버와 함께 파일 시스템 잠김 해제를 지원하지 않습니다."
 ],
 "The system does not currently support unlocking the root filesystem with a Tang keyserver.": [
  null,
  "시스템은 현재 탕 키서버와 함께 root 파일 시스템 잠김 해제를 지원하지 않습니다."
 ],
 "There are devices with multiple paths on the system, but the multipath service is not running.": [
  null,
  "시스템에 여러 경로를 갖는 장치가 있지만 다중 경로 서비스가 동작되고 있지 않습니다."
 ],
 "There is not enough space available that could be used for a repair. At least $0 are needed on physical volumes that are not already used for this logical volume.": [
  null,
  "복구를 위해 사용 가능한 여유 공간이 충분하지 않습니다. 적어도 $0 가 해당 논리 볼륨을 위해 사용되지 않는 물리 볼륨에서 필요합니다."
 ],
 "These additional steps are necessary:": [
  null,
  "다음과 같은 추가 단계가 필요합니다:"
 ],
 "These changes will be made:": [
  null,
  "이들 변경 사항은 다음과 같이 변경됩니다:"
 ],
 "Thin logical volume": [
  null,
  "씬 논리 볼륨"
 ],
 "Thinly provisioned LVM2 logical volumes": [
  null,
  "씬 프로비저닝된 LVM2 논리 볼륨"
 ],
 "This MDRAID device has no write-intent bitmap. Such a bitmap can reduce synchronization times significantly.": [
  null,
  "MD레이드 장치는 쓰기-의도 비트맵이 없습니다. 이러한 비트맵은 동기화 시간을 상당히 감소 시킬 수 있습니다."
 ],
 "This NFS mount is in use and only its options can be changed.": [
  null,
  "NFS 적재는 사용되고 있으며 선택만 변경 할 수 있습니다."
 ],
 "This VDO device does not use all of its backing device.": [
  null,
  "이 VDO 장치는 백업 장치를 사용하지 않습니다."
 ],
 "This device can not be used for the installation target.": [
  null,
  "이 장치는 설치 대상을 위해 사용 될 수 없습니다."
 ],
 "This device is currently in use.": [
  null,
  "이 장치는 현재 사용 중입니다."
 ],
 "This keyserver is the only way to unlock the pool and can not be removed.": [
  null,
  "이와 같은 키 서버는 풀을 잠금 해제하는 유일한 방법이고 제거 될 수 없습니다."
 ],
 "This logical volume has lost some of its physical volumes and can no longer be used. You need to delete it and create a new one to take its place.": [
  null,
  "이와 같은 논리 볼륨은 물리 볼륨의 일부를 손실하여 더 이상 사용될 수 없습니다. 이를 삭제하고 신규로 생성하고 이를 대체하세요."
 ],
 "This logical volume has lost some of its physical volumes but has not lost any data yet. You should repair it to restore its original redundancy.": [
  null,
  "이와 같은 논리 볼륨은 아직 자료를 손실하지 않았지만 물리 볼륨의 일부를 손실하였습니다. 원래의 중복된 부분을 복원하려면 이를 복구하세요."
 ],
 "This logical volume has lost some of its physical volumes but might not have lost any data yet. You might be able to repair it.": [
  null,
  "이와 같은 논리 볼륨은 아직 자료를 손실하지 않았지만 물리 볼륨의 일부를 손실하였습니다. 당신은 이를 복구 할 수 있습니다."
 ],
 "This logical volume is not completely used by its content.": [
  null,
  "이 논리 볼륨의 컨텐츠에 의해 완전히 사용되고 있지 않습니다."
 ],
 "This partition is not completely used by its content.": [
  null,
  "이 파티션은 컨텐츠에 의해 완전히 사용되고 있지 않습니다."
 ],
 "This passphrase is the only way to unlock the pool and can not be removed.": [
  null,
  "암호문은 풀을 잠금 해제하는 유일한 방법이고 제거 될 수 없습니다."
 ],
 "This pool does not use all the space on its block devices.": [
  null,
  "이 풀은 블록 장치의 모든 공간을 사용하지 않습니다."
 ],
 "This pool is in a degraded state.": [
  null,
  "이 풀은 성능이 저하된 상태입니다."
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "이와 같은 도구는 SELinux 정책을 구성하고 정책 위반을 이해하고 해결하는데 도움을 줄 수 있습니다."
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "이와 같은 도구는 커널 충돌 덤프를 작성하도록 시스템을 구성합니다. 이는 \"로컬\" (디스크), \"ssh\" 및 \"nfs\" 덤프 대상을 지원합니다."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "이와 같은 도구는 동작 중인 시스템에서 구성 및 진단 정보의 아카이브를 생성합니다. 아카이브는 기록 또는 추적 목적으로 로컬 또는 집중적으로 저장되거나 기술적 오류-찾기와 디버깅을 지원하기 위해 기술 지원 담당자, 개발자 또는 시스템 관리자에게 보낼 수 있습니다."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "이와 같은 도구는 파일시스템, LVM2 볼륨 그룹, 그리고 NFS 적재와 같은 로컬 저장소를 관리합니다."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "이와 같은 도구는 NetworkManager 및 Firewalld를 사용하여 bonds, bridges, teams, VLAN과 방화벽과 같은 네트워킹을 관리합니다. NetworkManager는 우분투 기본 systemd-netowrkd 및 데비안의 ifupdown 스크립트와는 호환되지 않습니다."
 ],
 "This volume group contains the root filesystem. Renaming it might require further changes to the bootloader configuration or kernel command line.": [
  null,
  "이와 같은 볼륨 그룹은 root 파일시스템을 포함합니다. 이름 변경하기는 부트로더 구성 또는 커널 명령 행을 추가로 변경해야 할 수도 있습니다."
 ],
 "This volume group is missing some physical volumes.": [
  null,
  "이와 같은 볼륨 그룹은 일부 물리 볼륨이 없습니다."
 ],
 "Tier": [
  null,
  "계층"
 ],
 "Time zone": [
  null,
  "시간대"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "악성의 제3자가 귀하의 연결을 가로채지 않도록 하려면 호스트 키 지문을 확인하십시오:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "지문을 확인하려면 물리적인 장치 또는 신뢰할 수 있는 네트워크를 통해 $0 에서 다음을 실행합니다:"
 ],
 "Toggle date picker": [
  null,
  "날짜 선택기 전환"
 ],
 "Too much data": [
  null,
  "데이터가 너무 많습니다"
 ],
 "Total size: $0": [
  null,
  "전체 크기: $0"
 ],
 "Tower": [
  null,
  "타워"
 ],
 "Trust and add host": [
  null,
  "호스트 신뢰 및 추가"
 ],
 "Trust key": [
  null,
  "신뢰 키"
 ],
 "Trying to synchronize with $0": [
  null,
  "$0 와 동기화를 시도 중입니다"
 ],
 "Type": [
  null,
  "유형"
 ],
 "Type can only contain the characters 0 to 9, A to F, and \"-\".": [
  null,
  "유형은 문자 0에서 9까지, A에서 F, 그리고 \"-\"만을 포함합니다."
 ],
 "Type must be of the form NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN.": [
  null,
  "유형은 형식 NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN이어야 합니다."
 ],
 "Type must contain exactly two hexadecimal characters (0 to 9, A to F).": [
  null,
  "유형은 정확하게 2가지 16진수 문자(0에서 9, A에서 F)가 포함되어야 합니다."
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "SSH 키 인증을 사용하여 $0 에 로그인 할 수 없습니다. 비밀번호를 입력하세요."
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "$0 에 로그인 할 수 없습니다. 호스트는 비밀번호 로그인 또는 자신의 SSH 키를 허용하지 않습니다."
 ],
 "Unable to reach server": [
  null,
  "서버에 연결 할 수 없습니다"
 ],
 "Unable to remove mount": [
  null,
  "적재를 제거 할 수 없습니다"
 ],
 "Unable to repair logical volume $0": [
  null,
  "논리 볼륨 $0 를 복구 할 수 없음"
 ],
 "Unable to unmount filesystem": [
  null,
  "파일 시스템 적재를 해제 할 수 없습니다"
 ],
 "Unexpected PackageKit error during installation of $0: $1": [
  null,
  "$0 설치 중에 예상치 못한 PackageKit 오류: $1"
 ],
 "Unexpected partitions": [
  null,
  "예상치 못한 파티션"
 ],
 "Unformatted data": [
  null,
  "초기화 되지 않은 자료"
 ],
 "Unknown": [
  null,
  "알 수 없음"
 ],
 "Unknown ($0)": [
  null,
  "알 수 없음 ($0)"
 ],
 "Unknown host name": [
  null,
  "알 수 없는 호스트 이름"
 ],
 "Unknown host: $0": [
  null,
  "알 수 없는 호스트: $0"
 ],
 "Unknown type": [
  null,
  "알 수 없는 유형"
 ],
 "Unlock": [
  null,
  "잠금 해제"
 ],
 "Unlock automatically on boot": [
  null,
  "부팅 시 자동으로 잠금 해제"
 ],
 "Unlock before resizing": [
  null,
  "크기 조정전 잠금해제"
 ],
 "Unlock encrypted Stratis pool": [
  null,
  "암호화된 스트라티스 풀 잠금 해제"
 ],
 "Unlocking $target": [
  null,
  "$target 잠금 해제 중"
 ],
 "Unlocking disk": [
  null,
  "디스크 잠금 해제 중"
 ],
 "Unmount": [
  null,
  "적재 해제"
 ],
 "Unmount filesystem $0": [
  null,
  "$0 파일 시스템 적재 해제"
 ],
 "Unmount now": [
  null,
  "지금 적재 해제"
 ],
 "Unmounting $target": [
  null,
  "$target 적재 해제 중"
 ],
 "Unrecognized data": [
  null,
  "인식되지 않는 데이터"
 ],
 "Unrecognized data can not be made smaller here": [
  null,
  "여기에서는 인식되지 않은 자료를 작게 할 수 없습니다"
 ],
 "Unrecognized data can not be made smaller here.": [
  null,
  "여기에서는 인식되지 않은 데이터를 작게할 수 없습니다."
 ],
 "Unsupported logical volume": [
  null,
  "미지원 논리 볼륨"
 ],
 "Untrusted host": [
  null,
  "지원되지 않는 호스트"
 ],
 "Usage": [
  null,
  "사용량"
 ],
 "Usage of $0": [
  null,
  "$0 사용량"
 ],
 "Use": [
  null,
  "사용"
 ],
 "Use $0": [
  null,
  "$0 사용"
 ],
 "Use compression": [
  null,
  "압축 사용"
 ],
 "Use deduplication": [
  null,
  "중복 제거 사용"
 ],
 "Used": [
  null,
  "사용됨"
 ],
 "Useful for mounts that are optional or need interaction (such as passphrases)": [
  null,
  "선택적이거나 상호 작용이 필요한 적재에 유용함 (암호문과 같은 경우)"
 ],
 "User": [
  null,
  "사용자"
 ],
 "Username": [
  null,
  "사용자 이름"
 ],
 "VDO backing devices can not be made smaller": [
  null,
  "VDO 백업 장치를 작게 할 수 없습니다"
 ],
 "VDO device $0": [
  null,
  "VDO 장치 $0"
 ],
 "VDO filesystem volume (compression/deduplication)": [
  null,
  "VDO 파일 시스템 볼륨 (압축/중복제거)"
 ],
 "Vendor": [
  null,
  "제조사"
 ],
 "Verify fingerprint": [
  null,
  "지문 검증"
 ],
 "Verify key": [
  null,
  "키 확인"
 ],
 "Very securely erasing $target": [
  null,
  "$target 를 매우 안전하게 삭제 중"
 ],
 "View all logs": [
  null,
  "모든 기록 보기"
 ],
 "View automation script": [
  null,
  "자동 스크립트 보기"
 ],
 "View logs": [
  null,
  "기록 보기"
 ],
 "Virtual filesystem sizes are larger than the pool. Overprovisioning can not be disabled.": [
  null,
  "가상 파일시스템 크기는 풀보다 큽니다. 과도공급은 비활성화 할 수 없습니다."
 ],
 "Virtual size": [
  null,
  "가상 크기"
 ],
 "Virtual size limit": [
  null,
  "가상 크기 제한"
 ],
 "Visit firewall": [
  null,
  "방화벽 방문"
 ],
 "Volatile memory backup failed": [
  null,
  "휘발성 메모리 보관이 실패함"
 ],
 "Volume group": [
  null,
  "볼륨 그룹"
 ],
 "Volume group is missing physical volumes": [
  null,
  "볼륨 그룹은 물리 볼륨에서 누락되었습니다"
 ],
 "Volume size is $0. Content size is $1.": [
  null,
  "볼륨 크기는 $0 입니다. 내용 크기는 $1 입니다."
 ],
 "Waiting for other software management operations to finish": [
  null,
  "다른 소프트웨어 관리 작업이 완료될 때 까지 대기 중"
 ],
 "Weak password": [
  null,
  "취약한 비밀번호"
 ],
 "Web Console for Linux servers": [
  null,
  "리눅스 서버를 위한 웹콘솔"
 ],
 "World wide name": [
  null,
  "고유 식별자"
 ],
 "Write-mostly": [
  null,
  "대부분 쓰기"
 ],
 "Writing": [
  null,
  "쓰기"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "처음으로 $0 에 연결됩니다."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "당신의 검색기는 내용 메뉴에서 붙여넣기를 허용하지 않습니다. Shift+Insert를 사용 할 수 있습니다."
 ],
 "Your session has been terminated.": [
  null,
  "세션이 종료되었습니다."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "세션이 만료되었습니다. 다시 로그인하십시오."
 ],
 "Zone": [
  null,
  "영역"
 ],
 "[binary data]": [
  null,
  "[바이너리 데이터]"
 ],
 "[no data]": [
  null,
  "[데이터 없음]"
 ],
 "after network": [
  null,
  "네트워크 이후에"
 ],
 "backing device for VDO device": [
  null,
  "VDO 장치용 백업 장치"
 ],
 "btrfs device": [
  null,
  "btrfs 장치"
 ],
 "btrfs devices": [
  null,
  "btrfs 장치"
 ],
 "btrfs filesystem": [
  null,
  "btrfs 파일 시스템"
 ],
 "btrfs subvolume": [
  null,
  "btrfs 하위볼륨"
 ],
 "btrfs subvolume $0 of $1": [
  null,
  "btrfs 하위 볼륨 $0/$1"
 ],
 "btrfs subvolumes": [
  null,
  "btrfs 하위볼륨"
 ],
 "btrfs volume": [
  null,
  "btrfs 볼륨"
 ],
 "cache": [
  null,
  "캐쉬"
 ],
 "data": [
  null,
  "자료"
 ],
 "deactivate": [
  null,
  "비활성화"
 ],
 "delete": [
  null,
  "삭제"
 ],
 "device of btrfs volume": [
  null,
  "btrfs 볼륨 장치"
 ],
 "edit": [
  null,
  "편집"
 ],
 "encrypted": [
  null,
  "암호화됨"
 ],
 "format": [
  null,
  "포맷"
 ],
 "grow": [
  null,
  "확장"
 ],
 "iSCSI Drive": [
  null,
  "iSCSI 드라이브"
 ],
 "iSCSI drives": [
  null,
  "iSCSI 드라이브"
 ],
 "iSCSI portal": [
  null,
  "iSCSI 포털"
 ],
 "ignore failure": [
  null,
  "실패를 무시"
 ],
 "in less than a minute": [
  null,
  "1분도 안되어"
 ],
 "initialize": [
  null,
  "초기화"
 ],
 "less than a minute ago": [
  null,
  "1분도 채 지나지 않아"
 ],
 "lock": [
  null,
  "잠금"
 ],
 "member of MDRAID device": [
  null,
  "MD레이드 장치의 구성원"
 ],
 "member of Stratis pool": [
  null,
  "스트라티스 풀의 구성원"
 ],
 "mount": [
  null,
  "적재"
 ],
 "never mount at boot": [
  null,
  "부팅시에 적재하지 않습니다"
 ],
 "none": [
  null,
  "없음"
 ],
 "password quality": [
  null,
  "비밀번호 수준"
 ],
 "physical volume of LVM2 volume group": [
  null,
  "LVM2 볼륨 그룹의 물리적인 볼륨"
 ],
 "read only": [
  null,
  "읽기 전용"
 ],
 "remove from LVM2": [
  null,
  "LVM2에서 제거"
 ],
 "remove from MDRAID": [
  null,
  "MD레이드에서 제거"
 ],
 "remove from btrfs volume": [
  null,
  "btrfs 볼륨에서 제거"
 ],
 "show less": [
  null,
  "덜 보기"
 ],
 "show more": [
  null,
  "더 보기"
 ],
 "shrink": [
  null,
  "축소"
 ],
 "snapshot": [
  null,
  "순간찍기"
 ],
 "stop": [
  null,
  "중지"
 ],
 "stop boot on failure": [
  null,
  "실패한 경우에 부트 중지"
 ],
 "stopped": [
  null,
  "정지됨"
 ],
 "unknown target": [
  null,
  "알 수 없는 대상"
 ],
 "unmount": [
  null,
  "적재 해제"
 ],
 "unpartitioned space on $0": [
  null,
  "$0 에 서 비-파티션 공간"
 ],
 "using key description $0": [
  null,
  "키 설명 $0 를 사용하기"
 ],
 "yes": [
  null,
  "예"
 ],
 "format-bytes\u0004bytes": [
  null,
  "바이트"
 ]
});
