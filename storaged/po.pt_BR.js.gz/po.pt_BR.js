cockpit.locale({
 "": {
  "plural-forms": (n) => (n != 1),
  "language": "pt_BR",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 can not be made larger": [
  null,
  "$0 não pode ser aumentado"
 ],
 "$0 can not be made smaller": [
  null,
  "$0 não pode ser reduzido"
 ],
 "$0 can not be resized": [
  null,
  "$0 não pode ser redimensionado"
 ],
 "$0 can not be resized here": [
  null,
  "$0 não pode ser redimensionado aqui"
 ],
 "$0 chunk size": [
  null,
  "Tamanho do bloco $0"
 ],
 "$0 data + $1 overhead used of $2 ($3)": [
  null,
  "$0 dados + $1 sobrecarga usada de $2 ($3)"
 ],
 "$0 day": [
  null,
  "$0 dia",
  "$0 dias"
 ],
 "$0 disk is missing": [
  null,
  "$0 disco não encontrado",
  "$0 discos não encontrados"
 ],
 "$0 disks": [
  null,
  "$0 discos"
 ],
 "$0 exited with code $1": [
  null,
  "$0 foi encerrado com o código $1"
 ],
 "$0 failed": [
  null,
  "$0 falhou"
 ],
 "$0 filesystem": [
  null,
  "Sistema de arquivos $0"
 ],
 "$0 hour": [
  null,
  "$0 hora",
  "$0 horas"
 ],
 "$0 hours": [
  null,
  "$0 horas"
 ],
 "$0 is in use": [
  null,
  "$0 está em uso"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 não está disponível em nenhum repositório."
 ],
 "$0 key changed": [
  null,
  "$0 chave alterada"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 morto com sinal $1"
 ],
 "$0 minute": [
  null,
  "$0 minuto",
  "$0 minutos"
 ],
 "$0 month": [
  null,
  "$0 mês",
  "$0 meses"
 ],
 "$0 partitions": [
  null,
  "Partições $0"
 ],
 "$0 slot remains": [
  null,
  "$0 slot restante",
  "$0 slots restantes"
 ],
 "$0 synchronized": [
  null,
  "$0 sincronizado"
 ],
 "$0 used of $1 ($2 saved)": [
  null,
  "$0 usados of $1 ($2 salvos)"
 ],
 "$0 used, $1 total": [
  null,
  "$0 usado, $1 total"
 ],
 "$0 week": [
  null,
  "$0 semana",
  "$0 semanas"
 ],
 "$0 will be installed.": [
  null,
  "$0 será instalado."
 ],
 "$0 year": [
  null,
  "$0 ano",
  "$0 anos"
 ],
 "$name (from $host)": [
  null,
  "$name (do $host)"
 ],
 "(Not part of target)": [
  null,
  "(Não faz parte do alvo)"
 ],
 "(no assigned mount point)": [
  null,
  "(nenhum ponto de montagem atribuído)"
 ],
 "(not mounted)": [
  null,
  "(não montado)"
 ],
 "(recommended)": [
  null,
  "(recomendado)"
 ],
 "1 MiB": [
  null,
  "1 MiB"
 ],
 "1 day": [
  null,
  "1 dia"
 ],
 "1 hour": [
  null,
  "1 hora"
 ],
 "1 minute": [
  null,
  "1 minuto"
 ],
 "1 week": [
  null,
  "1 semana"
 ],
 "128 KiB": [
  null,
  "128 KiB"
 ],
 "16 KiB": [
  null,
  "16 KiB"
 ],
 "2 MiB": [
  null,
  "2 MiB"
 ],
 "20 minutes": [
  null,
  "20 minutos"
 ],
 "32 KiB": [
  null,
  "32 KiB"
 ],
 "4 KiB": [
  null,
  "4 KiB"
 ],
 "40 minutes": [
  null,
  "40 minutos"
 ],
 "5 minutes": [
  null,
  "5 minutos"
 ],
 "512 KiB": [
  null,
  "512 KiB"
 ],
 "6 hours": [
  null,
  "6 horas"
 ],
 "60 minutes": [
  null,
  "60 minutos"
 ],
 "64 KiB": [
  null,
  "64 KiB"
 ],
 "8 KiB": [
  null,
  "8 KiB"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Uma versão compatível do Cockpit não está instalada em $0."
 ],
 "A fatal error occurred during the self-test operation": [
  null,
  "Ocorreu um erro fatal durante a operação de autoteste"
 ],
 "A filesystem with this name exists already in this pool.": [
  null,
  "Um sistema de arquivos com esse nome já existe nesse pool de armazenamento."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Uma nova chave SSH em $0 será criada por $1 em $2 e será adicionada ao arquivo $3 de $4 em $5."
 ],
 "A pool with this name exists already.": [
  null,
  "Já existe um pool de armazenamento com esse nome."
 ],
 "A volume group with missing physical volumes can not be renamed.": [
  null,
  "Um grupo de volumes com volumes físicos ausentes não pode ser renomeado."
 ],
 "Abort test": [
  null,
  "Abortar teste"
 ],
 "Aborted": [
  null,
  "Interrompido"
 ],
 "Aborted by a Controller Level Reset": [
  null,
  "Abortado por uma redefinição de nível do controlador"
 ],
 "Aborted due to a removal of a namespace from the namespace inventory": [
  null,
  "Abortado devido à remoção de um namespace do inventário de namespace"
 ],
 "Aborted due to a sanitize operation": [
  null,
  "Abortado devido a uma operação de higienização"
 ],
 "Aborted due to the processing of a Format NVM command": [
  null,
  "Abortado devido ao processamento de um comando Format NVM"
 ],
 "Aborted for unknown reason": [
  null,
  "Abortado por uma razão desconhecida"
 ],
 "Absent": [
  null,
  "Ausente"
 ],
 "Acceptable password": [
  null,
  "Senha aceitável"
 ],
 "Action": [
  null,
  "Ação"
 ],
 "Actions": [
  null,
  "Ações"
 ],
 "Activate": [
  null,
  "Ativar"
 ],
 "Activate before resizing": [
  null,
  "Ativar antes de redimensionar"
 ],
 "Activating $target": [
  null,
  "Ativando $target"
 ],
 "Add": [
  null,
  "Adicionar"
 ],
 "Add $0": [
  null,
  "Adicionar $0"
 ],
 "Add Network Bound Disk Encryption": [
  null,
  "Adicionar criptografia de disco vinculado à rede"
 ],
 "Add Tang keyserver": [
  null,
  "Adicionar servidor de chaves Tang"
 ],
 "Add a bitmap": [
  null,
  "Adicionar um bitmap"
 ],
 "Add block devices": [
  null,
  "Adicionar dispositivos de bloco"
 ],
 "Add disk": [
  null,
  "Adicionar disco"
 ],
 "Add disks": [
  null,
  "Adicionar discos"
 ],
 "Add iSCSI portal": [
  null,
  "Adicionar portal iSCSI"
 ],
 "Add key": [
  null,
  "Adicionar chave"
 ],
 "Add keyserver": [
  null,
  "Adicionar servidor de chaves"
 ],
 "Add passphrase": [
  null,
  "Adicionar senha"
 ],
 "Add physical volume": [
  null,
  "Adicionar volume físico"
 ],
 "Adding \"$0\" to encryption options": [
  null,
  "Adicionando \"$0\" às opções de criptografia"
 ],
 "Adding \"$0\" to filesystem options": [
  null,
  "Adicionando \"$0\" às opções do sistema de arquivos"
 ],
 "Adding a keyserver requires unlocking the pool. Please provide the existing pool passphrase.": [
  null,
  "Adicionar servidor de chaves requer o desbloqueio do pool de armazenamento. Forneça a senha do pool existente."
 ],
 "Adding key": [
  null,
  "Adicionando chave"
 ],
 "Adding physical volume to $target": [
  null,
  "Adicionando volume físico a $target"
 ],
 "Adding rd.neednet=1 to kernel command line": [
  null,
  "Adicionando rd.neednet=1 à linha de comando do kernel"
 ],
 "Additional packages:": [
  null,
  "Pacotes adicionais:"
 ],
 "Address": [
  null,
  "Endereço"
 ],
 "Address cannot be empty": [
  null,
  "O endereço não pode estar vazio"
 ],
 "Address is not a valid URL": [
  null,
  "O endereço não é uma URL válida"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Administração com o Console Web do Cockpit"
 ],
 "Advanced TCA": [
  null,
  "TCA avançado"
 ],
 "All $0 selected physical volumes are needed for the chosen layout.": [
  null,
  "Todos os $0 volumes físicos selecionados são necessários para o layout escolhido."
 ],
 "All media is in read-only mode": [
  null,
  "Todas as mídias estão em modo somente leitura"
 ],
 "All-in-one": [
  null,
  "All-in-one"
 ],
 "Allocated": [
  null,
  "Alocado"
 ],
 "Allow overprovisioning": [
  null,
  "Permitir superprovisionamento"
 ],
 "An additional $0 must be selected": [
  null,
  "Um $0 adicional deve ser selecionado"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Documentação de papéis do Ansible"
 ],
 "Appropriate for critical mounts, such as /var": [
  null,
  "Apropriado para montagens críticas, como /var"
 ],
 "Assessment": [
  null,
  "Avaliação"
 ],
 "At boot": [
  null,
  "Na inicialização"
 ],
 "At least $0 disk is needed.": [
  null,
  "Pelo menos $0 disco é necessário.",
  "Pelo menos $0 discos são necessários."
 ],
 "At least one block device is needed.": [
  null,
  "Pelo menos um dispositivo de bloco é necessário."
 ],
 "At least one disk is needed.": [
  null,
  "Pelo menos um disco é necessário."
 ],
 "At least one subvolume needs to be mounted": [
  null,
  "Pelo menos um subvolume precisa ser montado"
 ],
 "Attributes failing": [
  null,
  "Atributos falhando"
 ],
 "Authentication": [
  null,
  "Autenticação"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Autenticação é necessária para executar ações privilegiadas no Console Web do Cockpit"
 ],
 "Authentication required": [
  null,
  "Autenticação requerida"
 ],
 "Authorize SSH key": [
  null,
  "Autorizar chave SSH"
 ],
 "Automatically using NTP": [
  null,
  "Usando automaticamente o NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Usando automaticamente servidores NTP adicionais"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Usando automaticamente servidores NTP específicos"
 ],
 "Automation script": [
  null,
  "Script de automação"
 ],
 "Available targets on $0": [
  null,
  "Alvos disponíveis em $0"
 ],
 "BIOS boot partition": [
  null,
  "Partição de boot da BIOS"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Invólucro da lâmina"
 ],
 "Block device": [
  null,
  "Dispositivo de bloco"
 ],
 "Block device for filesystems": [
  null,
  "Dispositivo de bloqueio para sistemas de arquivos"
 ],
 "Block devices": [
  null,
  "Dispositivos de bloco"
 ],
 "Blocked": [
  null,
  "Bloqueado"
 ],
 "Boot fails if filesystem does not mount, preventing remote access": [
  null,
  "A inicialização falha se o sistema de arquivos não é montado, impedindo o acesso remoto"
 ],
 "Boot still succeeds when filesystem does not mount": [
  null,
  "A inicialização ainda é bem-sucedida quando o sistema de arquivos não é montado"
 ],
 "Bus expansion chassis": [
  null,
  "Chassi de Expansão de Barramento"
 ],
 "Cache": [
  null,
  "Cache"
 ],
 "Cancel": [
  null,
  "Cancelar"
 ],
 "Cannot forward login credentials": [
  null,
  "Não é possível prosseguir com as credenciais de login"
 ],
 "Cannot schedule event in the past": [
  null,
  "Não é possível agendar eventos no passado"
 ],
 "Capacity": [
  null,
  "Capacidade"
 ],
 "Category": [
  null,
  "Categoria"
 ],
 "Change": [
  null,
  "Alterar"
 ],
 "Change iSCSI initiator name": [
  null,
  "Alterar Nome do Iniciador iSCSI"
 ],
 "Change label": [
  null,
  "Alterar rótulo"
 ],
 "Change passphrase": [
  null,
  "Alterar senha"
 ],
 "Change system time": [
  null,
  "Alterar Horário do Sistema"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "As chaves alteradas frequentemente são resultado de uma reinstalação do sistema operacional. No entanto, uma alteração inesperada pode indicar uma tentativa de terceiros de interceptar sua conexão."
 ],
 "Changing partition types might prevent the system from booting.": [
  null,
  "Alterar os tipos de partição pode impedir a inicialização do sistema."
 ],
 "Check that the SHA-256 or SHA-1 hash from the command matches this dialog.": [
  null,
  "Verifique se o hash SHA-256 ou SHA-1 do comando corresponde a essa caixa de diálogo."
 ],
 "Check the key hash with the Tang server.": [
  null,
  "Verifique o hash da chave com o servidor Tang."
 ],
 "Checking $target": [
  null,
  "Vericando $target"
 ],
 "Checking MDRAID device $target": [
  null,
  "Checando Dispositivo MDRAID $target"
 ],
 "Checking and repairing MDRAID device $target": [
  null,
  "Checando e corrigindo o dispositivo MDRAID $target"
 ],
 "Checking filesystem usage": [
  null,
  "Verificando o uso do sistema de arquivos"
 ],
 "Checking for $0 package": [
  null,
  "Verificando a presença do pacote $0"
 ],
 "Checking for NBDE support in the initrd": [
  null,
  "Checando o suporte NBDE no initrd"
 ],
 "Checking installed software": [
  null,
  "Verificando o software instalado"
 ],
 "Chunk size": [
  null,
  "Tamanho do Bloco"
 ],
 "Cleaning up for $target": [
  null,
  "Limpando $target"
 ],
 "Clear input value": [
  null,
  "Limpar valor inserido"
 ],
 "Cleartext device": [
  null,
  "Dispositivo de texto simples"
 ],
 "Close": [
  null,
  "Fechar"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Configuração do cockpit do NetworkManager e Firewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "O Cockpit não poderia entrar em contato com o host fornecido."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit é um gerenciador de Servidores que facilita a tarefa de administrar seu servidor Linux via navegador web. Alternar entre o terminal e a ferramenta web, não é dif[icil. Um serviço pode ser iniciado pelo Cockpit e finalizado pelo Terminal. Da mesma forma, se um erro ocorrer no terminal, este pode ser detectado via interface do Cockpit."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "O Cockpit não é compatível com o software no sistema."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit não está instalado"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit não está instalado no sistema."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit é perfeito para novos administradores de sistemas, permitindo-lhes facilmente realizar tarefas simples, como a administração de armazenamento, inspecionando logs e iniciar/parar serviços. É possível monitorar e administrar vários servidores ao mesmo tempo. Basta adicioná-los com um único clique e suas máquinas vão cuidar de seus companheiros."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Coletar e empacotar dados de diagnóstico e suporte"
 ],
 "Collect kernel crash dumps": [
  null,
  "Coletar despejos de travamento de kernel"
 ],
 "Command": [
  null,
  "Comando"
 ],
 "Compact PCI": [
  null,
  "Compacto PCI"
 ],
 "Compatible with all systems and devices (MBR)": [
  null,
  "Compatível com todos os sistemas e dispositivos (MBR)"
 ],
 "Compatible with modern system and hard disks > 2TB (GPT)": [
  null,
  "Compatível com sistema moderno e discos rígidos > 2TB (GPT)"
 ],
 "Completed with a segment that failed and the segment that failed is not known": [
  null,
  "Concluído com um segmento que falhou e o segmento que falhou não é conhecido"
 ],
 "Completed with one or more failed segments": [
  null,
  "Concluído com um ou mais segmentos com falha"
 ],
 "Compression": [
  null,
  "Compressão"
 ],
 "Confirm": [
  null,
  "Confirmar"
 ],
 "Confirm deletion of $0": [
  null,
  "Confirmar a exclusão de $0"
 ],
 "Confirm key password": [
  null,
  "Confirme a senha da chave"
 ],
 "Confirm removal with an alternate passphrase": [
  null,
  "Confirme a remoção com a frase secreta alternativa"
 ],
 "Confirm stopping of $0": [
  null,
  "Confirmar a parada de $0"
 ],
 "Connection has timed out.": [
  null,
  "A conexão expirou."
 ],
 "Convertible": [
  null,
  "Conversível"
 ],
 "Copied": [
  null,
  "Copiado"
 ],
 "Copy": [
  null,
  "Copiar"
 ],
 "Copy to clipboard": [
  null,
  "Copiar para área de transferência"
 ],
 "Create": [
  null,
  "Criar"
 ],
 "Create $0": [
  null,
  "Criar $0"
 ],
 "Create LVM2 volume group": [
  null,
  "Criar grupo de volumes LVM2"
 ],
 "Create MDRAID device": [
  null,
  "Criar dispositivo MDRAID"
 ],
 "Create RAID device": [
  null,
  "Criar dispositivo RAID"
 ],
 "Create Stratis pool": [
  null,
  "Criar pool de Stratis"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Criar uma nova chave SSH e autorizá-la"
 ],
 "Create a snapshot of filesystem $0": [
  null,
  "Criar um instantâneo do sistema de arquivos $0"
 ],
 "Create and mount": [
  null,
  "Criar e montar"
 ],
 "Create and start": [
  null,
  "Criar e iniciar"
 ],
 "Create filesystem": [
  null,
  "Criar sistema de arquivos"
 ],
 "Create logical volume": [
  null,
  "Criar volume lógico"
 ],
 "Create new filesystem": [
  null,
  "Criar novo sistema de arquivos"
 ],
 "Create new logical volume": [
  null,
  "Criar novo volume lógico"
 ],
 "Create new task file with this content.": [
  null,
  "Crie um novo arquivo de tarefa com esse conteúdo."
 ],
 "Create new thinly provisioned logical volume": [
  null,
  "Criar novo volume lógico com provisionamento fino"
 ],
 "Create only": [
  null,
  "Criar apenas"
 ],
 "Create partition": [
  null,
  "Criar Partição"
 ],
 "Create partition on $0": [
  null,
  "Criar Partição em $0"
 ],
 "Create partition table": [
  null,
  "Criar tabela de partição"
 ],
 "Create snapshot": [
  null,
  "Criar Snapshot"
 ],
 "Create snapshot and mount": [
  null,
  "Criar snapshot e montar"
 ],
 "Create snapshot only": [
  null,
  "Criar snapshot apenas"
 ],
 "Create storage device": [
  null,
  "Criar dispositivo de armazenamento"
 ],
 "Create subvolume": [
  null,
  "Criar subvolume"
 ],
 "Create thin volume": [
  null,
  "Criar Thin Volume"
 ],
 "Create volume group": [
  null,
  "Criar Grupo de Volumes"
 ],
 "Creating LVM2 volume group $target": [
  null,
  "Criando o grupo de volumes LVM2 $target"
 ],
 "Creating MDRAID device $target": [
  null,
  "Criando dispositivo MDRAID $target"
 ],
 "Creating VDO device": [
  null,
  "Criando dispositivo VDO"
 ],
 "Creating filesystem on $target": [
  null,
  "Criando sistema de arquivos em $target"
 ],
 "Creating logical volume $target": [
  null,
  "Criando volume lógico $target"
 ],
 "Creating partition $target": [
  null,
  "Criando partição $target"
 ],
 "Creating snapshot of $target": [
  null,
  "Criando snapshot de $target"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Currently in use": [
  null,
  "Atualmente em uso"
 ],
 "Custom": [
  null,
  "Personalizado"
 ],
 "Custom mount options": [
  null,
  "Opções de montagem personalizadas"
 ],
 "Custom type": [
  null,
  "Tipo customizado"
 ],
 "Data": [
  null,
  "Dados"
 ],
 "Data used": [
  null,
  "Dados Usados"
 ],
 "Data will be stored as two copies and also in an alternating fashion on the selected physical volumes, to improve both reliability and performance. At least four volumes need to be selected.": [
  null,
  "Os dados serão armazenados como duas cópias e também de forma alternada nos volumes físicos selecionados, para melhorar a confiabilidade e o desempenho. Pelo menos quatro volumes precisam ser selecionados."
 ],
 "Data will be stored as two or more copies on the selected physical volumes, to improve reliability. At least two volumes need to be selected.": [
  null,
  "Os dados serão armazenados como duas ou mais cópias nos volumes físicos selecionados, para melhorar a confiabilidade. Pelo menos dois volumes precisam ser selecionados."
 ],
 "Data will be stored on the selected physical volumes in an alternating fashion to improve performance. At least two volumes need to be selected.": [
  null,
  "Os dados serão armazenados nos volumes físicos selecionados de forma alternada para melhorar o desempenho. Pelo menos dois volumes precisam ser selecionados."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. At least three volumes need to be selected.": [
  null,
  "Os dados serão armazenados nos volumes físicos selecionados para que um deles possa ser perdido sem afetar os dados. Pelo menos três volumes precisam ser selecionados."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. Data is also stored in an alternating fashion to improve performance. At least three volumes need to be selected.": [
  null,
  "Os dados serão armazenados nos volumes físicos selecionados para que um deles possa ser perdido sem afetar os dados. Os dados também são armazenados de forma alternada para melhorar o desempenho. Pelo menos três volumes precisam ser selecionados."
 ],
 "Data will be stored on the selected physical volumes so that up to two of them can be lost at the same time without affecting the data. Data is also stored in an alternating fashion to improve performance. At least five volumes need to be selected.": [
  null,
  "Os dados serão armazenados nos volumes físicos selecionados para que até dois deles possam ser perdidos ao mesmo tempo sem afetar os dados. Os dados também são armazenados de forma alternada para melhorar o desempenho. Pelo menos cinco volumes precisam ser selecionados."
 ],
 "Data will be stored on the selected physical volumes without any additional redundancy or performance improvements.": [
  null,
  "Os dados serão armazenados nos volumes físicos selecionados sem qualquer redundância adicional ou melhorias de desempenho."
 ],
 "Deactivate": [
  null,
  "Desativar"
 ],
 "Deactivate logical volume $0/$1?": [
  null,
  "Desativar o volume lógico $0/$1?"
 ],
 "Deactivating $target": [
  null,
  "Desativando $target"
 ],
 "Dedicated parity (RAID 4)": [
  null,
  "Paridade dedicada (RAID 4)"
 ],
 "Deduplication": [
  null,
  "Desduplicação"
 ],
 "Degraded": [
  null,
  "Degradado"
 ],
 "Delay": [
  null,
  "Atraso"
 ],
 "Delete": [
  null,
  "Excluir"
 ],
 "Delete filesystem": [
  null,
  "Excluir sistema de arquivos"
 ],
 "Delete group": [
  null,
  "Excluir grupo"
 ],
 "Delete pool": [
  null,
  "Excluir pool"
 ],
 "Deleting $target": [
  null,
  "Deletando $target"
 ],
 "Deleting LVM2 volume group $target": [
  null,
  "Excluindo grupo de volume LVM2 $target"
 ],
 "Deleting a Stratis pool will erase all data it contains.": [
  null,
  "A exclusão de um pool Stratis apagará todos os dados que ele contém."
 ],
 "Deleting a filesystem will delete all data in it.": [
  null,
  "A exclusão de um sistema de arquivos excluirá todos os dados dele."
 ],
 "Deleting a logical volume will delete all data in it.": [
  null,
  "A exclusão de um volume lógico excluirá todos os dados dele."
 ],
 "Deleting a partition will delete all data in it.": [
  null,
  "A exclusão de uma partição excluirá todos os dados dela."
 ],
 "Deleting erases all data on a MDRAID device.": [
  null,
  "A exclusão apaga todos os dados em um dispositivo MDRAID."
 ],
 "Deleting erases all data on a VDO device.": [
  null,
  "A exclusão apaga todos os dados em um dispositivo VDO."
 ],
 "Deleting erases all data on a btrfs volume.": [
  null,
  "A exclusão apaga todos os dados em um volume btrfs."
 ],
 "Deleting erases all data on a volume group.": [
  null,
  "A exclusão apaga todos os dados em um grupo de volumes."
 ],
 "Deleting erases all data on this subvolume and all its children.": [
  null,
  "A exclusão apaga todos os dados neste subvolume e em todos os seus filhos."
 ],
 "Description": [
  null,
  "Descrição"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Detachable": [
  null,
  "Destacável"
 ],
 "Device": [
  null,
  "Dispositivo"
 ],
 "Device contains unrecognized data": [
  null,
  "O dispositivo contém dados irreconhecíveis"
 ],
 "Device file": [
  null,
  "Arquivo do dispositivo"
 ],
 "Device health (SMART)": [
  null,
  "Saúde do dispositivo (SMART)"
 ],
 "Device is read-only": [
  null,
  "Dispositivo é somente leitura"
 ],
 "Device number": [
  null,
  "Número do dispositivo"
 ],
 "Diagnostic reports": [
  null,
  "Relatório de diagnostico"
 ],
 "Did not complete": [
  null,
  "Não concluiu"
 ],
 "Disconnect": [
  null,
  "Desconectar"
 ],
 "Disk is OK": [
  null,
  "O Disco está OK"
 ],
 "Disk is failing": [
  null,
  "O disco está falhando"
 ],
 "Disk passphrase": [
  null,
  "Senha de disco"
 ],
 "Disks": [
  null,
  "Discos"
 ],
 "Dismiss": [
  null,
  "Descartar"
 ],
 "Distributed parity (RAID 5)": [
  null,
  "Paridade distribuída (RAID 5)"
 ],
 "Do not mount": [
  null,
  "Não montar"
 ],
 "Do not mount automatically on boot": [
  null,
  "Não monta automaticamente na inicialização"
 ],
 "Docking station": [
  null,
  "Estação de ancoragem"
 ],
 "Does not mount during boot": [
  null,
  "Não monta durante a inicialização"
 ],
 "Double distributed parity (RAID 6)": [
  null,
  "Paridade duplamente distribuída (RAID 6)"
 ],
 "Downloading $0": [
  null,
  "Baixando $0"
 ],
 "Drive": [
  null,
  "Unidade"
 ],
 "Dual rank": [
  null,
  "Dual rank"
 ],
 "EFI system partition": [
  null,
  "Partição de sistema EFI"
 ],
 "Edit": [
  null,
  "Editar"
 ],
 "Edit Tang keyserver": [
  null,
  "Editar o servidor de chaves Tang"
 ],
 "Edit mount point": [
  null,
  "Editar ponto de montagem"
 ],
 "Editing a key requires a free slot": [
  null,
  "Editar uma chave requer um espaço livre"
 ],
 "Ejecting $target": [
  null,
  "Ejetando $target"
 ],
 "Embedded PC": [
  null,
  "PC integrado"
 ],
 "Emptying $target": [
  null,
  "Esvaziando $target"
 ],
 "Enabling $0": [
  null,
  "Habilitando $0"
 ],
 "Encrypt data with a Tang keyserver": [
  null,
  "Criptografar dados com um servidor de chaves Tang"
 ],
 "Encrypt data with a passphrase": [
  null,
  "Criptografar dados com uma senha"
 ],
 "Encrypted $0": [
  null,
  "Encriptado $0"
 ],
 "Encrypted Stratis pool": [
  null,
  "Pool de armazenamento Stratis criptografado"
 ],
 "Encrypted logical volume of $0": [
  null,
  "Volume Lógico Criptografado de $0"
 ],
 "Encrypted partition of $0": [
  null,
  "Partição Criptografada de $0"
 ],
 "Encryption": [
  null,
  "Encriptação"
 ],
 "Encryption options": [
  null,
  "Opções de Criptografia"
 ],
 "Encryption type": [
  null,
  "Tipo de encriptação"
 ],
 "Erasing $target": [
  null,
  "Apagando $target"
 ],
 "Error": [
  null,
  "Erro"
 ],
 "Error installing $0: PackageKit is not installed": [
  null,
  "Erro ao instalar $0: PackageKit não está instalado"
 ],
 "Exactly $0 physical volumes must be selected": [
  null,
  "Exatamente $0 volumes físicos devem ser selecionados"
 ],
 "Exactly $0 physical volumes need to be selected, one for each stripe of the logical volume.": [
  null,
  "Exatamente $0 volumes físicos precisam ser selecionados, um para cada faixa do volume lógico."
 ],
 "Excellent password": [
  null,
  "Senha excelente"
 ],
 "Expansion chassis": [
  null,
  "Chassi de Expansão"
 ],
 "Extended partition": [
  null,
  "Partição Extendida"
 ],
 "Failed": [
  null,
  "Falhou"
 ],
 "Failed (Damaged)": [
  null,
  "Falha (danificado)"
 ],
 "Failed (Electrical)": [
  null,
  "Falha (elétrica)"
 ],
 "Failed (Read)": [
  null,
  "Falha (leitura)"
 ],
 "Failed (Servo)": [
  null,
  "Falha (servo)"
 ],
 "Failed (Unknown)": [
  null,
  "Falha (desconhecida)"
 ],
 "Failed to change password": [
  null,
  "Falha ao mudar senha"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Falha ao habilitar $0 no firewalld"
 ],
 "Filesystem": [
  null,
  "Sistema de arquivos"
 ],
 "Filesystem is locked": [
  null,
  "Sistema de arquivos está bloqueado"
 ],
 "Filesystem is mounted read-only": [
  null,
  "O sistema de arquivos está montado somente para leitura"
 ],
 "Filesystem name": [
  null,
  "Nome do sistema de arquivos"
 ],
 "Filesystem outside the target": [
  null,
  "Sistema de arquivos fora do alvo"
 ],
 "Filesystems are already mounted below this mountpoint.": [
  null,
  "Os sistemas de arquivos já estão montados abaixo deste ponto de montagem."
 ],
 "Firmware version": [
  null,
  "Versão do firmware"
 ],
 "Fix NBDE support": [
  null,
  "Corrigir suporte NBDE"
 ],
 "Format": [
  null,
  "Formatar"
 ],
 "Format $0": [
  null,
  "Formatar $0"
 ],
 "Format and mount": [
  null,
  "Formatar e montar"
 ],
 "Format and start": [
  null,
  "Formatar e iniciar"
 ],
 "Format only": [
  null,
  "Apenas formatar"
 ],
 "Formatting erases all data on a storage device.": [
  null,
  "A formatação apaga todos os dados em um dispositivo de armazenamento."
 ],
 "Free space": [
  null,
  "Espaço Livre"
 ],
 "Go to now": [
  null,
  "Ir para agora"
 ],
 "Grow": [
  null,
  "Aumentar"
 ],
 "Grow content": [
  null,
  "Aumentar o conteúdo"
 ],
 "Grow logical size of $0": [
  null,
  "Aumentar o tamanho lógico de $0"
 ],
 "Grow logical volume": [
  null,
  "Aumentar o Volume Lógico"
 ],
 "Grow partition": [
  null,
  "Aumentar a partição"
 ],
 "Grow the pool to take all space": [
  null,
  "Aumentar o pool de armazenamento para tomar todo o espaço"
 ],
 "Grow to take all space": [
  null,
  "Aumentar o tamanho para tomar todo o espaço"
 ],
 "Handheld": [
  null,
  "Dispositivo portátil"
 ],
 "Hard Disk Drive": [
  null,
  "Unidade de disco rígido"
 ],
 "Hide confirmation password": [
  null,
  "Ocultar confirmação da senha"
 ],
 "Hide password": [
  null,
  "Ocultar senha"
 ],
 "Host key is incorrect": [
  null,
  "Chave de Host incorreta"
 ],
 "How to check": [
  null,
  "Como verificar"
 ],
 "I confirm I want to lose this data forever": [
  null,
  "Confirmo que desejo perder esses dados para sempre"
 ],
 "ID": [
  null,
  "ID"
 ],
 "INTERNAL ERROR - This logical volume is marked as active and should have an associated block device. However, no such block device could be found.": [
  null,
  "ERRO INTERNO - Este volume lógico está marcado como ativo e deve ter um dispositivo de bloco associado. No entanto, nenhum dispositivo de bloco desse tipo pôde ser encontrado."
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Se a impressão digital corresponder, clique em \"Confiar e adicionar host\". Caso contrário, não se conecte e entre em contato com o administrador."
 ],
 "Important data might be deleted:": [
  null,
  "Dados importantes poderão ser excluídos:"
 ],
 "In a terminal, run: ": [
  null,
  "Em um terminal, execute: "
 ],
 "In progress": [
  null,
  "Em andamento"
 ],
 "In sync": [
  null,
  "Em Sincronização"
 ],
 "Inactive logical volume": [
  null,
  "Volume lógico inativo"
 ],
 "Inconsistent filesystem mount": [
  null,
  "Montagem inconsistente do sistema de arquivos"
 ],
 "Index memory": [
  null,
  "Memória de índice"
 ],
 "Initialize": [
  null,
  "Inicializar"
 ],
 "Initialize disk $0": [
  null,
  "Inicializando disco $0"
 ],
 "Initializing erases all data on a disk.": [
  null,
  "A inicialização apagará todos os dados do disco."
 ],
 "Install": [
  null,
  "Instalar"
 ],
 "Install NFS support": [
  null,
  "Instalar o suporte ao NFS"
 ],
 "Install Stratis support": [
  null,
  "Instalar suporte ao Stratis"
 ],
 "Install software": [
  null,
  "Instalar o software"
 ],
 "Installing $0": [
  null,
  "Instalando $0"
 ],
 "Installing $0 would remove $1.": [
  null,
  "A instalação de $0 removeria $1."
 ],
 "Installing packages": [
  null,
  "Instalando pacotes"
 ],
 "Internal error": [
  null,
  "Erro interno"
 ],
 "Interrupted": [
  null,
  "Interrompido"
 ],
 "Invalid date format": [
  null,
  "Formato de data inválido"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Formato de data inválido e formato de tempo inválido"
 ],
 "Invalid file permissions": [
  null,
  "Permissão de arquivos inválida"
 ],
 "Invalid time format": [
  null,
  "Formato de tempo inválido"
 ],
 "Invalid timezone": [
  null,
  "Fuso horário inválido"
 ],
 "Invalid username or password": [
  null,
  "Nome de usuário ou senha inválidos"
 ],
 "IoT gateway": [
  null,
  "Gateway IoT"
 ],
 "Jobs": [
  null,
  "Trabalhos"
 ],
 "Kernel dump": [
  null,
  "Dump do kernel"
 ],
 "Key password": [
  null,
  "Nova senha"
 ],
 "Key slots with unknown types can not be edited here": [
  null,
  "Slots chave com tipos desconhecidos não podem ser editados aqui"
 ],
 "Key source": [
  null,
  "Fonte chave"
 ],
 "Keys": [
  null,
  "Chaves"
 ],
 "Keyserver": [
  null,
  "Servidor de chaves"
 ],
 "Keyserver address": [
  null,
  "Endereço do servidor de chaves"
 ],
 "Keyserver removal may prevent unlocking $0.": [
  null,
  "A remoção do Keyserver pode impedir o desbloqueio de $0."
 ],
 "LVM2 VDO pool": [
  null,
  "Pool LVM2 VDO"
 ],
 "LVM2 logical volume": [
  null,
  "Volume Lógico LVM2"
 ],
 "LVM2 logical volumes": [
  null,
  "Volumes lógicos LVM2"
 ],
 "LVM2 physical volume": [
  null,
  "Volume físico LVM2"
 ],
 "LVM2 physical volumes": [
  null,
  "Volumes físicos LVM2"
 ],
 "LVM2 volume group": [
  null,
  "Grupo de Volumes LVM2"
 ],
 "LVM2 volume group $0": [
  null,
  "Grupo de volume LVM2 $0"
 ],
 "Label": [
  null,
  "Rótulo"
 ],
 "Laptop": [
  null,
  "Laptop"
 ],
 "Last cannot be removed": [
  null,
  "O último não pode ser removido"
 ],
 "Last disk can not be removed": [
  null,
  "O último disco não pode ser removido"
 ],
 "Last modified: $0": [
  null,
  "Última modificação: $0"
 ],
 "Layout": [
  null,
  "Disposição"
 ],
 "Learn more": [
  null,
  "Saiba mais"
 ],
 "Limit size": [
  null,
  "Limitar tamanho"
 ],
 "Limit virtual filesystem size": [
  null,
  "Limitar o tamanho do sistema de arquivos virtual"
 ],
 "Linear": [
  null,
  "Linear"
 ],
 "Linux filesystem data": [
  null,
  "Dados do sistema de arquivos Linux"
 ],
 "Linux swap space": [
  null,
  "Espaço swap Linux"
 ],
 "Loading system modifications...": [
  null,
  "Carregando modificações do sistema..."
 ],
 "Loading...": [
  null,
  "Carregando..."
 ],
 "Local mount point": [
  null,
  "Ponto de montagem local"
 ],
 "Local storage": [
  null,
  "Armazenamento local"
 ],
 "Location": [
  null,
  "Local"
 ],
 "Lock": [
  null,
  "Travar"
 ],
 "Lock $0?": [
  null,
  "Travar $0?"
 ],
 "Locked data": [
  null,
  "Dados bloqueados"
 ],
 "Locked encrypted device might contain data": [
  null,
  "O dispositivo criptografado bloqueado pode conter dados"
 ],
 "Locking $target": [
  null,
  "Bloqueando $target"
 ],
 "Log in": [
  null,
  "Entrar"
 ],
 "Log in to $0": [
  null,
  "Iniciar sessão para $0"
 ],
 "Log messages": [
  null,
  "Mensagens de Log"
 ],
 "Logical": [
  null,
  "Lógico"
 ],
 "Logical Volume Manager partition": [
  null,
  "Partição de Logical Volume Manager"
 ],
 "Logical size": [
  null,
  "Tamanho Lógico"
 ],
 "Logical volume": [
  null,
  "Volume Lógico"
 ],
 "Logical volume (snapshot)": [
  null,
  "Volume Lógico (Snapshot)"
 ],
 "Logical volume of $0": [
  null,
  "Volume Lógico de $0"
 ],
 "Login failed": [
  null,
  "Falha ao logar"
 ],
 "Low profile desktop": [
  null,
  "Desktop de baixo perfil"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "MDRAID device": [
  null,
  "Dispositivo MDRAID"
 ],
 "MDRAID device $0": [
  null,
  "Dispositivo MDRAID $0"
 ],
 "MDRAID device is recovering": [
  null,
  "O dispositivo MDRAID está se recuperando"
 ],
 "MDRAID device must be running": [
  null,
  "O dispositivo MDRAID deve estar em execução"
 ],
 "MDRAID disk": [
  null,
  "Disco MDRAID"
 ],
 "MDRAID disks": [
  null,
  "Discos MDRAID"
 ],
 "Main server chassis": [
  null,
  "Chassi do Servidor Principal"
 ],
 "Manage storage": [
  null,
  "Gerenciar armazenamento"
 ],
 "Manually": [
  null,
  "Manualmente"
 ],
 "Marking $target as faulty": [
  null,
  "Marcando $target como defeituoso"
 ],
 "Media drive": [
  null,
  "Unidade de mídia"
 ],
 "Message to logged in users": [
  null,
  "Mensagem para usuários logados"
 ],
 "Metadata used": [
  null,
  "Metadados usados"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini torre"
 ],
 "Mirrored (RAID 1)": [
  null,
  "Espelhado (RAID 1)"
 ],
 "Model": [
  null,
  "Modelo"
 ],
 "Modifying $target": [
  null,
  "Modificando $target"
 ],
 "Mount": [
  null,
  "Montar"
 ],
 "Mount Point": [
  null,
  "Ponto de montagem"
 ],
 "Mount after network becomes available, ignore failure": [
  null,
  "Monte depois que a rede se tornar disponível, ignore a falha"
 ],
 "Mount also automatically on boot": [
  null,
  "Monte também automaticamente na inicialização"
 ],
 "Mount at boot": [
  null,
  "Monte na Inicialização"
 ],
 "Mount automatically on $0 on boot": [
  null,
  "Monte automaticamente no $0 na inicialização"
 ],
 "Mount before services start": [
  null,
  "Monte antes do início dos serviços"
 ],
 "Mount configuration": [
  null,
  "Configuração de montagem"
 ],
 "Mount filesystem": [
  null,
  "Montar sistema de arquivos"
 ],
 "Mount now": [
  null,
  "Monte agora"
 ],
 "Mount on $0 now": [
  null,
  "Monte no $0 agora"
 ],
 "Mount options": [
  null,
  "Opções de Montagem"
 ],
 "Mount point": [
  null,
  "Ponto de Montagem"
 ],
 "Mount point cannot be empty": [
  null,
  "O ponto de montagem não pode estar vazio"
 ],
 "Mount point cannot be empty.": [
  null,
  "O ponto de montagem não pode estar vazio."
 ],
 "Mount point is already used for $0": [
  null,
  "Ponto de montagem já está sendo usado para $0"
 ],
 "Mount point must start with \"/\".": [
  null,
  "O ponto de montagem deve começar com \"/\"."
 ],
 "Mount read only": [
  null,
  "Monte só de leitura"
 ],
 "Mount without waiting, ignore failure": [
  null,
  "Monte sem esperar, ignore a falha"
 ],
 "Mounting $target": [
  null,
  "Montando $target"
 ],
 "Mounts before services start": [
  null,
  "Monta antes do início dos serviços"
 ],
 "Mounts in parallel with services": [
  null,
  "Monta em paralelo com os serviços"
 ],
 "Mounts in parallel with services, but after network is available": [
  null,
  "Monta em paralelo com os serviços, mas depois que a rede está disponível"
 ],
 "Multi-system chassis": [
  null,
  "Chassi Multi-sistema"
 ],
 "Multipathed devices": [
  null,
  "Dispositivos do vários caminhos (multipath)"
 ],
 "NFS mount": [
  null,
  "Montagem NFS"
 ],
 "NTP server": [
  null,
  "Servidor NTP"
 ],
 "Name": [
  null,
  "Nome"
 ],
 "Name can not be empty.": [
  null,
  "O nome não pode estar vazio."
 ],
 "Name cannot be empty.": [
  null,
  "O nome não pode estar vazio."
 ],
 "Name cannot be longer than $0 bytes": [
  null,
  "O nome não pode ser maior que $0 bytes"
 ],
 "Name cannot be longer than $0 characters": [
  null,
  "O nome não pode ser maior do que $0 caracteres"
 ],
 "Name cannot be longer than 127 characters.": [
  null,
  "O nome não pode ser maior do que 127 caracteres."
 ],
 "Name cannot be longer than 255 characters.": [
  null,
  "O nome não pode ser maior do que 255 caracteres."
 ],
 "Name cannot contain the character '$0'.": [
  null,
  "O nome não pode conter o caractere '$0'."
 ],
 "Name cannot contain the character '/'.": [
  null,
  "O nome não pode conter o caractere '/'."
 ],
 "Name cannot contain whitespace.": [
  null,
  "Nome não pode conter espaço em branco."
 ],
 "Need a spare disk": [
  null,
  "Precisa de um disco sobressalente"
 ],
 "Need at least one NTP server": [
  null,
  "Precisa de pelo menos um servidor NTP"
 ],
 "Networked storage": [
  null,
  "Armazenamento em rede"
 ],
 "Networking": [
  null,
  "Rede"
 ],
 "New NFS mount": [
  null,
  "Nova montagem de volume NFS"
 ],
 "New passphrase": [
  null,
  "Nova senha"
 ],
 "New password was not accepted": [
  null,
  "Nova senha não foi aceita"
 ],
 "Next": [
  null,
  "Próximo"
 ],
 "No available slots": [
  null,
  "Sem slots disponíveis"
 ],
 "No block devices are available.": [
  null,
  "Nenhum dispositivo de bloco está disponível."
 ],
 "No block devices found": [
  null,
  "Nenhum dispositivo de bloco encontrado"
 ],
 "No delay": [
  null,
  "Sem Atraso"
 ],
 "No devices found": [
  null,
  "Nenhum dispositivos encontrado"
 ],
 "No disks are available.": [
  null,
  "Sem discos disponíveis."
 ],
 "No disks found": [
  null,
  "Nenhum discos encontrados"
 ],
 "No drives found": [
  null,
  "Nenhum discos encontrados"
 ],
 "No encryption": [
  null,
  "Sem criptografia"
 ],
 "No filesystem": [
  null,
  "Nenhum sistema de arquivos"
 ],
 "No filesystems": [
  null,
  "Nenhum sistema de arquivos"
 ],
 "No free key slots": [
  null,
  "Nenhum slot de chave livre"
 ],
 "No free space": [
  null,
  "Não há espaço livre"
 ],
 "No free space after this partition": [
  null,
  "Não há espaço livre após esta partição"
 ],
 "No keys added": [
  null,
  "Nenhuma chave adicionada"
 ],
 "No logical volumes": [
  null,
  "Nenhum Volume Lógico"
 ],
 "No media inserted": [
  null,
  "Nenhuma mídia inserida"
 ],
 "No partitioning": [
  null,
  "Sem particionamento"
 ],
 "No partitions found": [
  null,
  "Nenhuma partição encontrada"
 ],
 "No physical volumes found": [
  null,
  "Nenhum volume físico encontrado"
 ],
 "No results found": [
  null,
  "Nenhum resultado encontrado"
 ],
 "No snapshots found": [
  null,
  "Nenhum snapshot encontrado"
 ],
 "No storage found": [
  null,
  "Nenhum armazenamento encontrado"
 ],
 "No subvolumes": [
  null,
  "Nenhum subvolume"
 ],
 "No such file or directory": [
  null,
  "Diretório ou arquivo não encontrado"
 ],
 "No system modifications": [
  null,
  "Nenhuma modificações no sistema"
 ],
 "Not a valid private key": [
  null,
  "Chave privada não válida"
 ],
 "Not enough free space": [
  null,
  "Não há espaço livre suficiente"
 ],
 "Not enough space": [
  null,
  "Não há espaço suficiente"
 ],
 "Not enough space to grow": [
  null,
  "Não há espaço suficiente para aumentar de tamanho"
 ],
 "Not found": [
  null,
  "Não encontrado"
 ],
 "Not permitted to perform this action.": [
  null,
  "Não é permitido executar esta ação."
 ],
 "Not running": [
  null,
  "Não está em execução"
 ],
 "Not synchronized": [
  null,
  "Não sincronizado"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Number of bad sectors": [
  null,
  "Número de setores ruins"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Old passphrase": [
  null,
  "Senha antiga"
 ],
 "Old password not accepted": [
  null,
  "Senha antiga não aceita"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Uma vez instalado o Cockpit, habilite-o com \"systemctl enable --now cockpit.socket\"."
 ],
 "Only $0 of $1 are used.": [
  null,
  "Somente $0 de $1 está em uso."
 ],
 "Operation '$operation' on $target": [
  null,
  "Operação '$operation' em $target"
 ],
 "Options": [
  null,
  "Opções"
 ],
 "Other": [
  null,
  "De outros"
 ],
 "Overprovisioning": [
  null,
  "Superprovisionamento"
 ],
 "Overwrite": [
  null,
  "Sobrescrever"
 ],
 "Overwrite existing data with zeros (slower)": [
  null,
  "Sobrescrever dados existentes com zeros (mais lento)"
 ],
 "PID": [
  null,
  "PID"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit caiu"
 ],
 "Partition": [
  null,
  "Partição"
 ],
 "Partition of $0": [
  null,
  "Partição de $0"
 ],
 "Partition size is $0. Content size is $1.": [
  null,
  "O tamanho da partição é $0. O tamanho do conteúdo é $1."
 ],
 "Partitioning": [
  null,
  "Particionamento"
 ],
 "Partitions": [
  null,
  "Partições"
 ],
 "Partitions are not supported on this block device. If it is used as a disk for a virtual machine, the partitions must be managed by the operating system inside the virtual machine.": [
  null,
  ""
 ],
 "Passphrase": [
  null,
  "Frase-senha"
 ],
 "Passphrase can not be empty": [
  null,
  "A senha não pode ser vazia"
 ],
 "Passphrase cannot be empty": [
  null,
  "A senha não pode ser vazia"
 ],
 "Passphrase from any other key slot": [
  null,
  "Senha de qualquer outro slot de chave"
 ],
 "Passphrase removal may prevent unlocking $0.": [
  null,
  "A remoção da senha pode impedir o desbloqueio de $0."
 ],
 "Passphrases do not match": [
  null,
  "As senhas não correspondem"
 ],
 "Password": [
  null,
  "Senha"
 ],
 "Password is not acceptable": [
  null,
  "Senha não é aceitavél"
 ],
 "Password is too weak": [
  null,
  "Senha é muito fraca"
 ],
 "Password not accepted": [
  null,
  "Senha não aceita"
 ],
 "Paste": [
  null,
  "Colar"
 ],
 "Path on server": [
  null,
  "Caminho no servidor"
 ],
 "Path on server cannot be empty.": [
  null,
  "Caminho no servidor não pode estar vazio."
 ],
 "Path on server must start with \"/\".": [
  null,
  "Caminho no servidor deve começar com \"/\"."
 ],
 "Path to file": [
  null,
  "Caminho para o arquivo"
 ],
 "Peripheral chassis": [
  null,
  "Chassi Periférico"
 ],
 "Permanently delete $0?": [
  null,
  "Excluir $0 permanentemente?"
 ],
 "Permanently delete logical volume $0/$1?": [
  null,
  "Deletar permanentemente o volume lógico $0/$1?"
 ],
 "Permanently delete subvolume $0?": [
  null,
  "Excluir o subvolume $0 permanentemente?"
 ],
 "Persistent memory has become read-only": [
  null,
  "A memória persistente tornou-se somente leitura"
 ],
 "Physical": [
  null,
  "Fisica"
 ],
 "Physical Volumes": [
  null,
  "Volumes Físicos"
 ],
 "Physical volumes": [
  null,
  "Volumes Físicos"
 ],
 "Physical volumes can not be resized here": [
  null,
  "Volumes físicos não podem ser redimensionados aqui"
 ],
 "Pick date": [
  null,
  ""
 ],
 "Pizza box": [
  null,
  "Servidor compacto"
 ],
 "Please unmount them first.": [
  null,
  "Desmonte-os primeiro."
 ],
 "Pool for thin logical volumes": [
  null,
  "Pool de armazenamento para Thin Logical Volumes"
 ],
 "Pool for thinly provisioned LVM2 logical volumes": [
  null,
  "Pool de armazenamento para volumes finamente provisionados"
 ],
 "Pool for thinly provisioned volumes": [
  null,
  "Pool de armazenamento para volumes finamente provisionados"
 ],
 "Pool passphrase": [
  null,
  "Senha do pool de armazenamento"
 ],
 "Port": [
  null,
  "Porta"
 ],
 "Portable": [
  null,
  "Portatil"
 ],
 "Power on hours": [
  null,
  "Horas ligado"
 ],
 "PowerPC PReP boot partition": [
  null,
  "Partição de inicialização PowerPC PReP"
 ],
 "Present": [
  null,
  "Presente"
 ],
 "Processes using the location": [
  null,
  "Processos usando a localização"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "A solicitação via ssh-add expirou"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Solicitação via ssh-keygen expirou"
 ],
 "Provide the passphrase for the pool on these block devices:": [
  null,
  "Forneça a senha para o pool nestes dispositivos de bloco:"
 ],
 "Purpose": [
  null,
  "Propósito"
 ],
 "RAID ($0)": [
  null,
  "RAID ($0)"
 ],
 "RAID 0": [
  null,
  "RAID 0"
 ],
 "RAID 0 (stripe)": [
  null,
  "RAID 0 (Distribuição)"
 ],
 "RAID 1": [
  null,
  "RAID 1"
 ],
 "RAID 1 (mirror)": [
  null,
  "RAID 1 (Espelhamento)"
 ],
 "RAID 10": [
  null,
  "RAID 10"
 ],
 "RAID 10 (stripe of mirrors)": [
  null,
  "RAID 10 (Distribuição de Espelhos)"
 ],
 "RAID 4": [
  null,
  "RAID 4"
 ],
 "RAID 4 (dedicated parity)": [
  null,
  "RAID 4 (Paridade Dedicada)"
 ],
 "RAID 5": [
  null,
  "RAID 5"
 ],
 "RAID 5 (distributed parity)": [
  null,
  "RAID 5 (Paridade Distribuída)"
 ],
 "RAID 6": [
  null,
  "RAID 6"
 ],
 "RAID 6 (double distributed parity)": [
  null,
  "RAID 6 (Paridade Duplamente Distribuída)"
 ],
 "RAID chassis": [
  null,
  "Chassis do RAID"
 ],
 "RAID level": [
  null,
  "Nível de RAID"
 ],
 "RAID10 needs an even number of physical volumes": [
  null,
  "RAID10 precisa de um número par de volumes físicos"
 ],
 "Rack mount chassis": [
  null,
  "Chassis de montagem do Rack"
 ],
 "Reading": [
  null,
  "Lendo"
 ],
 "Reboot": [
  null,
  "Reiniciar"
 ],
 "Recovering": [
  null,
  "Recuperação"
 ],
 "Recovering MDRAID device $target": [
  null,
  "Recuperando Dispositivo MDRAID $target"
 ],
 "Regenerating initrd": [
  null,
  "Regenerando initrd"
 ],
 "Related processes and services will be forcefully stopped.": [
  null,
  "Processos e serviços relacionados serão interrompidos à força."
 ],
 "Related processes will be forcefully stopped.": [
  null,
  "Processos relacionados serão interrompidos à força."
 ],
 "Related services will be forcefully stopped.": [
  null,
  "Os serviços relacionados serão interrompidos à força."
 ],
 "Removals:": [
  null,
  "Remoções:"
 ],
 "Remove": [
  null,
  "Remover"
 ],
 "Remove $0?": [
  null,
  "Remover $0?"
 ],
 "Remove Tang keyserver?": [
  null,
  "Remover o servidor de chaves Tang?"
 ],
 "Remove device": [
  null,
  "Remover dispositivo"
 ],
 "Remove missing physical volumes?": [
  null,
  "Remover volumes físicos ausentes?"
 ],
 "Remove passphrase in key slot $0?": [
  null,
  "Remover frase secreta no slot de chave $0?"
 ],
 "Remove passphrase?": [
  null,
  "Remover senha?"
 ],
 "Removing $0": [
  null,
  "Removendo $0"
 ],
 "Removing $target from MDRAID device": [
  null,
  "Removendo $target de Dispositivo MDRAID"
 ],
 "Removing a passphrase without confirmation of another passphrase may prevent unlocking or key management, if other passphrases are forgotten or lost.": [
  null,
  "Remover uma frase secreta sem a confirmação de outra frase pode impedir o desbloqueio ou o gerenciamento de chaves, caso outras frases secretas sejam esquecidas ou perdidas."
 ],
 "Removing physical volume from $target": [
  null,
  "Removendo volume físico de $target"
 ],
 "Rename": [
  null,
  "Renomear"
 ],
 "Rename Stratis pool": [
  null,
  "Renomear pool Stratis"
 ],
 "Rename filesystem": [
  null,
  "Renomear sistema de arquivos"
 ],
 "Rename logical volume": [
  null,
  "Renomear Volume Lógico"
 ],
 "Rename volume group": [
  null,
  "Renomear Grupo de Volume"
 ],
 "Renaming $target": [
  null,
  "Renomeando $target"
 ],
 "Repair": [
  null,
  "Reparar"
 ],
 "Repair logical volume $0": [
  null,
  "Reparar volume lógico $0"
 ],
 "Repairing $target": [
  null,
  "Reparando $target"
 ],
 "Repeat passphrase": [
  null,
  "Repita a frase secreta"
 ],
 "Resizing $target": [
  null,
  "Redimensionando $target"
 ],
 "Resizing an encrypted filesystem requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Redimensionar um sistema de arquivos criptografado requer desbloquear o disco. Forneça uma senha de disco atual."
 ],
 "Reuse existing encryption": [
  null,
  "Reusar criptografia existente"
 ],
 "Reuse existing encryption ($0)": [
  null,
  "Recusar criptografia existente ($0)"
 ],
 "Run extended test": [
  null,
  "Executar teste estendido"
 ],
 "Run short test": [
  null,
  "Executar teste curto"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  ""
 ],
 "Running": [
  null,
  "Em execução"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SHA-1": [
  null,
  "SHA-1"
 ],
 "SHA-256": [
  null,
  "SHA-256"
 ],
 "SMART self-test of $target": [
  null,
  "SMART auto-teste de $target"
 ],
 "SSH key": [
  null,
  "Chave SSH"
 ],
 "Save": [
  null,
  "Salvar"
 ],
 "Save space by compressing individual blocks with LZ4": [
  null,
  "Economizar espaço comprimindo blocos individuais com LZ4"
 ],
 "Save space by storing identical data blocks just once": [
  null,
  "Economizar espaço armazenando blocos de dados idênticos uma só vez"
 ],
 "Saving a new passphrase requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Salvar uma nova senha requer o desbloqueio do disco. Por favor, forneça uma senha de disco atual."
 ],
 "Sealed-case PC": [
  null,
  "PC com caixa vedada"
 ],
 "Securely erasing $target": [
  null,
  "Apagando com segurança $target"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  ""
 ],
 "Select the physical volumes that should be used to repair the logical volume. At least $0 are needed.": [
  null,
  "Selecionar os volumes físicos que devem ser usados para reparar o volume lógico. Pelo menos $0 são necessários."
 ],
 "Self-test status": [
  null,
  "Estado do auto-teste"
 ],
 "Serial number": [
  null,
  "Número de série"
 ],
 "Server": [
  null,
  "Servidor"
 ],
 "Server address": [
  null,
  "Endereço do Servidor"
 ],
 "Server address cannot be empty.": [
  null,
  "O endereço do servidor não pode estar vazio."
 ],
 "Server cannot be empty.": [
  null,
  "O servidor não pode estar vazio."
 ],
 "Server has closed the connection.": [
  null,
  "O servidor encerrou a conexão."
 ],
 "Service": [
  null,
  "Serviço"
 ],
 "Services using the location": [
  null,
  "Serviços usando a localização"
 ],
 "Set": [
  null,
  "Definir"
 ],
 "Set initial size": [
  null,
  "Definir tamanho inicial"
 ],
 "Set limit of virtual filesystem size": [
  null,
  "Definir limite do tamanho do sistema de arquivos virtual"
 ],
 "Set partition type of $0": [
  null,
  "Definir tipo de partição de $0"
 ],
 "Set time": [
  null,
  "Definir Tempo"
 ],
 "Setting up loop device $target": [
  null,
  "Configurando o dispositivo de loop $target"
 ],
 "Shell script": [
  null,
  "Shell script"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show all $0 rows": [
  null,
  "Exibir todas as $0 linhas"
 ],
 "Show password": [
  null,
  "Exibir senha"
 ],
 "Shrink": [
  null,
  "Compactar"
 ],
 "Shrink logical volume": [
  null,
  "Compactar Logical Volume"
 ],
 "Shrink partition": [
  null,
  "Diminuir partição"
 ],
 "Shrink volume": [
  null,
  "Diminuir volume"
 ],
 "Shut down": [
  null,
  "Encerrar"
 ],
 "Single rank": [
  null,
  ""
 ],
 "Size": [
  null,
  "Tamanho"
 ],
 "Size cannot be negative": [
  null,
  "O tamanho não pode ser negativo"
 ],
 "Size cannot be zero": [
  null,
  "O tamanho não pode ser zero"
 ],
 "Size is too large": [
  null,
  "O tamanho é muito extenso"
 ],
 "Size must be a number": [
  null,
  "O tamanho deve ser um número"
 ],
 "Size must be at least $0": [
  null,
  "O tamanho deve ser pelo menos $0"
 ],
 "Slot $0": [
  null,
  "Slot $0"
 ],
 "Snapshot": [
  null,
  "Snapshot"
 ],
 "Snapshot origin": [
  null,
  "Origem do snapshot"
 ],
 "Snapshots": [
  null,
  "Snapshots"
 ],
 "Solid State Drive": [
  null,
  "Unidade de estado sólido"
 ],
 "Some block devices of this pool have grown in size after the pool was created. The pool can be safely grown to use the newly available space.": [
  null,
  "Alguns dispositivos de bloco deste pool aumentaram em tamanho depois que o pool foi criado. O pool pode ser aumentado com segurança para usar o novo espaço disponível."
 ],
 "Sorry": [
  null,
  "Desculpe"
 ],
 "Space-saving computer": [
  null,
  "Computador com economia de espaço"
 ],
 "Spare": [
  null,
  "Reposição"
 ],
 "Spare capacity is below the threshold": [
  null,
  "A capacidade excedente está abaixo do limite"
 ],
 "Specific time": [
  null,
  "Tempo Específico"
 ],
 "Start": [
  null,
  "Iniciar"
 ],
 "Start multipath": [
  null,
  "Iniciar Multipath"
 ],
 "Started": [
  null,
  "Iniciado"
 ],
 "Starting MDRAID device $target": [
  null,
  "Iniciando o Dispositivo MDRAID $target"
 ],
 "Starting swapspace $target": [
  null,
  "Iniciando swapspace $target"
 ],
 "State": [
  null,
  "Estado"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "Stop": [
  null,
  "Pare"
 ],
 "Stop and remove": [
  null,
  "Pare e remova"
 ],
 "Stop and unmount": [
  null,
  "Parar e desmontar"
 ],
 "Stop device": [
  null,
  "Parar dispositivo"
 ],
 "Stopping MDRAID device $target": [
  null,
  "Parando o Dispositivo MDRAID $target"
 ],
 "Stopping swapspace $target": [
  null,
  "Parando swapspace $target"
 ],
 "Storage": [
  null,
  "Armazenamento"
 ],
 "Storage can not be managed on this system.": [
  null,
  "O armazenamento não pode ser gerenciado neste sistema."
 ],
 "Storage logs": [
  null,
  "Logs de armazenamento"
 ],
 "Store passphrase": [
  null,
  "Armazene a senha"
 ],
 "Stored passphrase": [
  null,
  "Senha armazenada"
 ],
 "Stratis block device": [
  null,
  "Dispositivo de bloco Stratis"
 ],
 "Stratis block devices": [
  null,
  "Dispositivos de bloco Stratis"
 ],
 "Stratis blockdevs can not be made smaller": [
  null,
  "Dispositivos de blocos Stratis não podem ser menores"
 ],
 "Stratis filesystem": [
  null,
  "Sistema de arquivos Stratis"
 ],
 "Stratis filesystems": [
  null,
  "Sistemas de arquivos Stratis"
 ],
 "Stratis filesystems pool": [
  null,
  "Pool de sistemas de arquivos Stratis"
 ],
 "Stratis pool": [
  null,
  "Pool de Stratis"
 ],
 "Striped (RAID 0)": [
  null,
  "Distribuído (RAID 0)"
 ],
 "Striped and mirrored (RAID 10)": [
  null,
  "Distribuído e espelhado (RAID 10)"
 ],
 "Stripes": [
  null,
  "Listrados"
 ],
 "Sub-Chassis": [
  null,
  "Sub chassis"
 ],
 "Sub-Notebook": [
  null,
  "Sub notebook"
 ],
 "Successful": [
  null,
  "Realizado com sucesso"
 ],
 "Successfully copied to clipboard!": [
  null,
  "Copiado com sucesso para a área de transferência!"
 ],
 "Swap": [
  null,
  "Swap"
 ],
 "Swap can not be resized here": [
  null,
  "Swap não pode ser redimensionado aqui"
 ],
 "Synchronized": [
  null,
  "Sincronizado"
 ],
 "Synchronized with $0": [
  null,
  "Sincronizado com $0"
 ],
 "Synchronizing": [
  null,
  "Sincronizando"
 ],
 "Synchronizing MDRAID device $target": [
  null,
  "Sincronizando Dispositivo MDRAID $target"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Tang keyserver": [
  null,
  "Servidor de chaves Tang"
 ],
 "Target": [
  null,
  "Alvo"
 ],
 "Temperature outside of recommended thresholds": [
  null,
  "Temperatura fora do limiar recomendado"
 ],
 "The $0 package is not available from any repository.": [
  null,
  "O pacote $0 não está disponível em nenhum repositório."
 ],
 "The $0 package must be installed to create Stratis pools.": [
  null,
  "O pacote $0 deve ser instalado para criar pools Stratis."
 ],
 "The $0 package must be installed.": [
  null,
  "O pacote $0 deve estar instalado."
 ],
 "The $0 package will be installed to create VDO devices.": [
  null,
  "O pacote $0 será instalado para criar dispositivos VDO."
 ],
 "The MDRAID device is in a degraded state": [
  null,
  "O dispositivo MDRAID está em um estado degradado"
 ],
 "The MDRAID device must be running": [
  null,
  "O dispositivo MDRAID deve estar em execução"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  ""
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  ""
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  ""
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  ""
 ],
 "The creation of this VDO device did not finish and the device can't be used.": [
  null,
  "A criação deste dispositivo VDO não foi concluída e o dispositivo não pode ser usado."
 ],
 "The currently logged in user is not permitted to see information about keys.": [
  null,
  "O usuário atualmente conectado não tem permissão para ver informações sobre chaves."
 ],
 "The filesystem has no assigned mount point.": [
  null,
  "O sistema de arquivos não tem ponto de montagem atribuído."
 ],
 "The filesystem has no permanent mount point.": [
  null,
  "O sistema de arquivos não tem ponto de montagem permanente."
 ],
 "The filesystem is configured to be automatically mounted on boot but its encryption container will not be unlocked at that time.": [
  null,
  "O sistema de arquivos está configurado para ser montado automaticamente na inicialização, mas seu contêiner de criptografia não será desbloqueado naquele momento."
 ],
 "The filesystem is currently mounted but will not be mounted after the next boot.": [
  null,
  "O sistema de arquivos está atualmente montado, mas não será montado após a próxima inicialização."
 ],
 "The filesystem is currently mounted on $0 but will be mounted on $1 on the next boot.": [
  null,
  "O sistema de arquivos está atualmente montado em $0, mas será montado em $1 na próxima inicialização."
 ],
 "The filesystem is currently mounted on $0 but will not be mounted after the next boot.": [
  null,
  "O sistema de arquivos está atualmente montado em $0, mas não será montado na próxima inicialização."
 ],
 "The filesystem is currently not mounted but will be mounted on the next boot.": [
  null,
  "O sistema de arquivos não está montado no momento, mas será montado na próxima inicialização."
 ],
 "The filesystem is not mounted.": [
  null,
  "O sistema de arquivos não está montado."
 ],
 "The filesystem will be unlocked and mounted on the next boot. This might require inputting a passphrase.": [
  null,
  "O sistema de arquivos será desbloqueado e montado na próxima inicialização. Isso pode exigir a inserção de uma frase-senha."
 ],
 "The fingerprint should match:": [
  null,
  "A impressão digital deve corresponder a:"
 ],
 "The initrd must be regenerated.": [
  null,
  "O initrd deve ser regenerado."
 ],
 "The key password can not be empty": [
  null,
  "A senha da chave não pode estar vazia"
 ],
 "The key passwords do not match": [
  null,
  "As senhas da chave não coincidem"
 ],
 "The last key slot can not be removed": [
  null,
  "O último slot chave não pode ser removido"
 ],
 "The last mounted subvolume can not be deleted": [
  null,
  "O último subvolume montado não pode ser excluído"
 ],
 "The listed processes and services will be forcefully stopped.": [
  null,
  "Os processos e serviços listados serão interrompidos à força."
 ],
 "The listed processes will be forcefully stopped.": [
  null,
  "Os processos listados serão interrompidos à força."
 ],
 "The listed services will be forcefully stopped.": [
  null,
  "Os serviços listados serão interrompidos à força."
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  ""
 ],
 "The mount point $0 is in use by these processes:": [
  null,
  "O ponto de montagem $0 está em uso por estes processos:"
 ],
 "The mount point $0 is in use by these services:": [
  null,
  "O ponto de montagem $0 está em uso por estes serviços:"
 ],
 "The password can not be empty": [
  null,
  "A senha não pode estar vazia"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "A impressão digital resultante pode ser compartilhada por métodos públicos, incluindo e-mail."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "A impressão digital resultante pode ser compartilhada por métodos públicos, incluindo e-mail. Se você estiver pedindo para outra pessoa fazer a verificação para você, ela pode enviar os resultados usando qualquer método."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "O servidor se recusou a autenticar usando quaisquer métodos suportados."
 ],
 "The system does not currently support unlocking a filesystem with a Tang keyserver during boot.": [
  null,
  "Atualmente, o sistema não oferece suporte ao desbloqueio de um sistema de arquivos com um servidor de chaves Tang durante a inicialização."
 ],
 "The system does not currently support unlocking the root filesystem with a Tang keyserver.": [
  null,
  "Atualmente, o sistema não oferece suporte ao desbloqueio do sistema de arquivos raiz com um servidor de chaves Tang."
 ],
 "There are devices with multiple paths on the system, but the multipath service is not running.": [
  null,
  "Há dispositivos com vários caminhos no sistema, mas o serviço de multicaminho não está em execução."
 ],
 "There is not enough space available that could be used for a repair. At least $0 are needed on physical volumes that are not already used for this logical volume.": [
  null,
  "Não há espaço suficiente disponível que possa ser usado para um reparo. Pelo menos $0 são necessários em volumes físicos que ainda não estão sendo usados para este volume lógico."
 ],
 "These additional steps are necessary:": [
  null,
  "Estes passos adicionais são necessários:"
 ],
 "These changes will be made:": [
  null,
  "Essas mudanças serão realizadas:"
 ],
 "Thin logical volume": [
  null,
  "Volume lógico Thin"
 ],
 "Thinly provisioned LVM2 logical volumes": [
  null,
  "Volumes lógicos LVM2 provisionados finamente"
 ],
 "This MDRAID device has no write-intent bitmap. Such a bitmap can reduce synchronization times significantly.": [
  null,
  "Este dispositivo MDRAID não tem bitmap de intenção de gravação. Tal bitmap pode reduzir significativamente os tempos de sincronização."
 ],
 "This NFS mount is in use and only its options can be changed.": [
  null,
  "Esta montagem NFS está em uso e somente suas opções podem ser alteradas."
 ],
 "This VDO device does not use all of its backing device.": [
  null,
  "Este dispositivo VDO não usa todo o seu dispositivo de apoio."
 ],
 "This device can not be used for the installation target.": [
  null,
  "Este dispositivo não pode ser usado para o alvo de instalação."
 ],
 "This device is currently in use.": [
  null,
  "Este dispositivo está atualmente em uso."
 ],
 "This keyserver is the only way to unlock the pool and can not be removed.": [
  null,
  "Este servidor de chaves é a única maneira de desbloquear o pool de armazenamento e não pode ser removido."
 ],
 "This logical volume has lost some of its physical volumes and can no longer be used. You need to delete it and create a new one to take its place.": [
  null,
  "Este volume lógico perdeu alguns de seus volumes físicos e não pode mais ser usado. Você precisa excluí-lo e criar um novo para tomar o seu lugar."
 ],
 "This logical volume has lost some of its physical volumes but has not lost any data yet. You should repair it to restore its original redundancy.": [
  null,
  "Este volume lógico perdeu alguns de seus volumes físicos, mas ainda não perdeu nenhum dado. Você deve repará-lo para restaurar sua redundância original."
 ],
 "This logical volume has lost some of its physical volumes but might not have lost any data yet. You might be able to repair it.": [
  null,
  "Este volume lógico perdeu alguns de seus volumes físicos, mas pode não ter perdido nenhum dado ainda. Você pode ser capaz de repará-lo."
 ],
 "This logical volume is not completely used by its content.": [
  null,
  "Este volume lógico não é completamente utilizado pelo seu conteúdo."
 ],
 "This partition is not completely used by its content.": [
  null,
  "Esta partição não é completamente utilizada pelo seu conteúdo."
 ],
 "This passphrase is the only way to unlock the pool and can not be removed.": [
  null,
  "Esta senha é a única maneira de desbloquear o pool de armazenamento e não pode ser removida."
 ],
 "This pool does not use all the space on its block devices.": [
  null,
  "Este pool de armazenamento não utiliza todo o espaço em seus dispositivos de bloco."
 ],
 "This pool is in a degraded state.": [
  null,
  "Este pool de armazenamento está em estado degradado."
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Esta ferramenta configura a política do SELinux e pode ajudar a entender e resolver violações de política."
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Esta ferramenta configura o sistema para escrever kernel crash dumps. Ela suporta os alvos de dump \"local\" (disco), \"ssh\" e \"nfs\"."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Esta ferramenta gera um arquivo de informações de configuração e diagnóstico do sistema em execução. O arquivo pode ser armazenado localmente ou centralmente para fins de registro ou rastreamento ou pode ser enviado a representantes de suporte técnico, desenvolvedores ou administradores de sistema para auxiliar na detecção de falhas técnicas e depuração."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Esta ferramenta gerencia armazenamento local, como sistemas de arquivos, grupos de volumes LVM2 e montagens NFS."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Esta ferramenta gerencia redes como vínculos, pontes, times, VLANs e firewalls usando NetworkManager e Firewalld. O NetworkManager é incompatível com o systemd-networkd padrão do Ubuntu e os scripts ifupdown do Debian."
 ],
 "This volume group contains the root filesystem. Renaming it might require further changes to the bootloader configuration or kernel command line.": [
  null,
  ""
 ],
 "This volume group is missing some physical volumes.": [
  null,
  "Este grupo de volumes está sem alguns volumes físicos."
 ],
 "Tier": [
  null,
  "Tier"
 ],
 "Time zone": [
  null,
  "Fuso Horário"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Para garantir que sua conexão não seja interceptada por terceiros mal-intencionados, verifique a impressão digital da chave do host:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Para verificar uma impressão digital, execute o seguinte em $0 enquanto estiver fisicamente sentado na máquina ou por meio de uma rede confiável:"
 ],
 "Toggle date picker": [
  null,
  ""
 ],
 "Too much data": [
  null,
  "Muitos dados"
 ],
 "Total size: $0": [
  null,
  "Tamanho total: $0"
 ],
 "Tower": [
  null,
  "Torre"
 ],
 "Trust and add host": [
  null,
  "Confiar e adicionar host"
 ],
 "Trust key": [
  null,
  "Chave de confiança"
 ],
 "Trying to synchronize with $0": [
  null,
  "Tentando sincronizar com $0"
 ],
 "Type": [
  null,
  "Tipo"
 ],
 "Type can only contain the characters 0 to 9, A to F, and \"-\".": [
  null,
  "O tipo pode conter apenas os caracteres de 0 a 9, de A a F e \"-\"."
 ],
 "Type must be of the form NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN.": [
  null,
  "O tipo deve estar no formato NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN."
 ],
 "Type must contain exactly two hexadecimal characters (0 to 9, A to F).": [
  null,
  "O tipo deve conter exatamente dois caracteres hexadecimais (0 a 9, A a F)."
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  ""
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  ""
 ],
 "Unable to reach server": [
  null,
  "Não é possível acessar o servidor"
 ],
 "Unable to remove mount": [
  null,
  "Não é possível remover a unidade montade"
 ],
 "Unable to repair logical volume $0": [
  null,
  "Não foi possível corrigir o volume lógico $0"
 ],
 "Unable to unmount filesystem": [
  null,
  "Não é possível desmontar o sistema de arquivos"
 ],
 "Unexpected PackageKit error during installation of $0: $1": [
  null,
  "Erro inesperado do PackageKit durante a instalação de $0: $1"
 ],
 "Unformatted data": [
  null,
  "Dados não formatados"
 ],
 "Unknown": [
  null,
  "Desconhecido"
 ],
 "Unknown ($0)": [
  null,
  "Desconhecido ($0)"
 ],
 "Unknown host name": [
  null,
  "Nome de host desconhecido"
 ],
 "Unknown host: $0": [
  null,
  "Host desconhecido: $0"
 ],
 "Unknown type": [
  null,
  "Tipo desconhecido"
 ],
 "Unlock": [
  null,
  "Destravar"
 ],
 "Unlock automatically on boot": [
  null,
  "Desbloquear automaticamente na inicialização"
 ],
 "Unlock before resizing": [
  null,
  "Desbloquear antes de redimensionar"
 ],
 "Unlock encrypted Stratis pool": [
  null,
  "Desbloquear pool Stratis criptografado"
 ],
 "Unlocking $target": [
  null,
  "Desbloqueando $target"
 ],
 "Unlocking disk": [
  null,
  "Desbloqueando o disco"
 ],
 "Unmount": [
  null,
  "Desmontar"
 ],
 "Unmount filesystem $0": [
  null,
  "Desmontar o sistema de arquivos $0"
 ],
 "Unmount now": [
  null,
  "Desmontar agora"
 ],
 "Unmounting $target": [
  null,
  "Desmontando $target"
 ],
 "Unrecognized data": [
  null,
  "Dados não reconhecidos"
 ],
 "Unrecognized data can not be made smaller here": [
  null,
  "Dados não reconhecidos não podem ser reduzidos aqui"
 ],
 "Unrecognized data can not be made smaller here.": [
  null,
  "Dados não reconhecidos não podem ser reduzidos aqui."
 ],
 "Unsupported logical volume": [
  null,
  "Volume lógico não suportado"
 ],
 "Untrusted host": [
  null,
  "Host não confiável"
 ],
 "Usage": [
  null,
  "Uso"
 ],
 "Usage of $0": [
  null,
  "Uso de $0"
 ],
 "Use": [
  null,
  "Utilizar"
 ],
 "Use $0": [
  null,
  "Usar $0"
 ],
 "Use compression": [
  null,
  "Usar compressão"
 ],
 "Use deduplication": [
  null,
  "Usar desduplicação"
 ],
 "Used": [
  null,
  "Usado"
 ],
 "Useful for mounts that are optional or need interaction (such as passphrases)": [
  null,
  "Útil para montagens que são opcionais ou precisam de interação (como senhas)"
 ],
 "User": [
  null,
  "Usuário"
 ],
 "Username": [
  null,
  "Nome de usuário"
 ],
 "VDO backing devices can not be made smaller": [
  null,
  "Dispositivos de suporte VDO não podem ser menores"
 ],
 "VDO device $0": [
  null,
  "Dispositivo VDO $0"
 ],
 "VDO filesystem volume (compression/deduplication)": [
  null,
  "Volume do sistema de arquivos VDO (compressão/desduplicação)"
 ],
 "Vendor": [
  null,
  "Fabricante"
 ],
 "Verify fingerprint": [
  null,
  "Verificar digital"
 ],
 "Verify key": [
  null,
  "Verificar chave"
 ],
 "Very securely erasing $target": [
  null,
  "Apagando com muita segurança $target"
 ],
 "View all logs": [
  null,
  "Ver todos os logs"
 ],
 "View automation script": [
  null,
  ""
 ],
 "View logs": [
  null,
  "Ver logs"
 ],
 "Virtual filesystem sizes are larger than the pool. Overprovisioning can not be disabled.": [
  null,
  "Os tamanhos do sistema de arquivos virtual são maiores que o pool. O superprovisionamento não pode ser desabilitado."
 ],
 "Virtual size": [
  null,
  "Tamanho virtual"
 ],
 "Virtual size limit": [
  null,
  "Limite do tamanho virtual"
 ],
 "Volatile memory backup failed": [
  null,
  "Backup de memória volátil falhou"
 ],
 "Volume group": [
  null,
  "Grupo de volumes"
 ],
 "Volume group is missing physical volumes": [
  null,
  "O grupo de volumes não possui volumes físicos"
 ],
 "Volume size is $0. Content size is $1.": [
  null,
  "Tamanho do volume é $0. Tamanho de conteúdo é $1."
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Aguardando que outras operações de gerenciamento de software terminem"
 ],
 "Web Console for Linux servers": [
  null,
  "Console da Web para servidores Linux"
 ],
 "World wide name": [
  null,
  "Nome mundial"
 ],
 "Write-mostly": [
  null,
  "Maioria-Escrita"
 ],
 "Writing": [
  null,
  "Escrevendo"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  ""
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  ""
 ],
 "Your session has been terminated.": [
  null,
  "Sua sessão foi encerrada."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Sua sessão expirou. Por favor, faça o login novamente."
 ],
 "Zone": [
  null,
  "Zona"
 ],
 "[binary data]": [
  null,
  "[dados binários]"
 ],
 "[no data]": [
  null,
  "[sem dados]"
 ],
 "after network": [
  null,
  "após rede"
 ],
 "backing device for VDO device": [
  null,
  "dispositivo backup para dispositivo VDO"
 ],
 "btrfs device": [
  null,
  "Dispositivo btrfs"
 ],
 "btrfs devices": [
  null,
  "Dispositivos btrfs"
 ],
 "btrfs filesystem": [
  null,
  "Sistema de arquivos btrfs"
 ],
 "btrfs subvolume": [
  null,
  "Subvolume btrfs"
 ],
 "btrfs subvolume $0 of $1": [
  null,
  "Subvolume btrfs $0 de $1"
 ],
 "btrfs subvolumes": [
  null,
  "Subvolumes btrfs"
 ],
 "btrfs volume": [
  null,
  "Volume btrfs"
 ],
 "cache": [
  null,
  "cache"
 ],
 "data": [
  null,
  "dados"
 ],
 "deactivate": [
  null,
  "desativar"
 ],
 "delete": [
  null,
  "excluir"
 ],
 "device of btrfs volume": [
  null,
  "dispositivo do volume btrfs"
 ],
 "edit": [
  null,
  "editar"
 ],
 "encrypted": [
  null,
  "cryptografado"
 ],
 "format": [
  null,
  "formatar"
 ],
 "grow": [
  null,
  "incrementar"
 ],
 "iSCSI Drive": [
  null,
  "Drive iSCSI"
 ],
 "iSCSI drives": [
  null,
  "Drive iSCSI"
 ],
 "iSCSI portal": [
  null,
  "Portal iSCSI"
 ],
 "ignore failure": [
  null,
  "ignorar falhas"
 ],
 "in less than a minute": [
  null,
  "em menos de um minuto"
 ],
 "initialize": [
  null,
  "inicializar"
 ],
 "less than a minute ago": [
  null,
  "menos de um minuto atrás"
 ],
 "lock": [
  null,
  "trancar"
 ],
 "member of MDRAID device": [
  null,
  "membro do Dispositivo MDRAID"
 ],
 "member of Stratis pool": [
  null,
  "membro do pool Stratis"
 ],
 "mount": [
  null,
  "montar"
 ],
 "never mount at boot": [
  null,
  "nunca montar na inicialização"
 ],
 "none": [
  null,
  "nenhum"
 ],
 "password quality": [
  null,
  "qualidade da senha"
 ],
 "physical volume of LVM2 volume group": [
  null,
  "volume físico do grupo de volumes LVM2"
 ],
 "read only": [
  null,
  "somente leitura"
 ],
 "remove from LVM2": [
  null,
  "remover do LVM2"
 ],
 "remove from MDRAID": [
  null,
  "remover do MDRAID"
 ],
 "remove from btrfs volume": [
  null,
  "remover do volume btrfs"
 ],
 "show less": [
  null,
  "mostrar menos"
 ],
 "show more": [
  null,
  "mostrar mais"
 ],
 "shrink": [
  null,
  "compactar"
 ],
 "snapshot": [
  null,
  "snapshot"
 ],
 "stop": [
  null,
  "parar"
 ],
 "stop boot on failure": [
  null,
  "parar a inicialização em caso de falha"
 ],
 "stopped": [
  null,
  "parado"
 ],
 "unknown target": [
  null,
  "alvo desconhecido"
 ],
 "unmount": [
  null,
  "desmontar"
 ],
 "unpartitioned space on $0": [
  null,
  "espaço não particionado em $0"
 ],
 "using key description $0": [
  null,
  "usando descrição da chave $0"
 ],
 "yes": [
  null,
  "sim"
 ],
 "format-bytes\u0004bytes": [
  null,
  "bytes"
 ]
});
