cockpit.locale({
 "": {
  "plural-forms": (n) => (n != 1),
  "language": "pt_BR",
  "language-direction": "ltr"
 },
 "Diagnostic reports": [
  null,
  "Relatório de diagnostico"
 ],
 "Kernel dump": [
  null,
  "Dump do kernel"
 ],
 "Managing LVMs": [
  null,
  "Gerenciando LVMs"
 ],
 "Managing NFS mounts": [
  null,
  "Gerenciando montagens NFS"
 ],
 "Managing RAIDs": [
  null,
  "Gerenciando RAIDs"
 ],
 "Managing VDOs": [
  null,
  "Gerenciando VDOs"
 ],
 "Managing partitions": [
  null,
  "Gestão de partições"
 ],
 "Managing physical drives": [
  null,
  "Gerenciando discos físicos"
 ],
 "Networking": [
  null,
  "Rede"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Storage": [
  null,
  "Armazenamento"
 ],
 "Using LUKS encryption": [
  null,
  "Usando criptografia LUKS"
 ],
 "Using Tang server": [
  null,
  "Usando servidor Tang"
 ],
 "disk": [
  null,
  "disco"
 ],
 "drive": [
  null,
  "unidade"
 ],
 "encryption": [
  null,
  "criptografia"
 ],
 "filesystem": [
  null,
  "sistema de arquivos"
 ],
 "format": [
  null,
  "formatar"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "luks": [
  null,
  "luks"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "mount": [
  null,
  "montar"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "partition": [
  null,
  "partição"
 ],
 "raid": [
  null,
  "raid"
 ],
 "tang": [
  null,
  "tang"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "unmount": [
  null,
  "desmontar"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "volume": [
  null,
  "volume"
 ]
});
