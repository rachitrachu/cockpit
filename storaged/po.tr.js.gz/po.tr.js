cockpit.locale({
 "": {
  "plural-forms": (n) => (n>1),
  "language": "tr",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 can not be made larger": [
  null,
  "$0 daha büyütülemez"
 ],
 "$0 can not be made smaller": [
  null,
  "$0 daha küçültülemez"
 ],
 "$0 can not be resized": [
  null,
  "$0 yeniden boyutlandırılamaz"
 ],
 "$0 can not be resized here": [
  null,
  "$0 burada yeniden boyutlandırılamaz"
 ],
 "$0 chunk size": [
  null,
  "$0 parça boyutu"
 ],
 "$0 data + $1 overhead used of $2 ($3)": [
  null,
  "$0 veri + $1 ek yük kullanıldı, toplam $2 ($3)"
 ],
 "$0 day": [
  null,
  "$0 gün",
  "$0 gün"
 ],
 "$0 disk is missing": [
  null,
  "$0 disk eksik",
  "$0 disk eksik"
 ],
 "$0 disks": [
  null,
  "$0 disk"
 ],
 "$0 exited with code $1": [
  null,
  "$0, $1 koduyla çıkış yaptı"
 ],
 "$0 failed": [
  null,
  "$0 başarısız oldu"
 ],
 "$0 filesystem": [
  null,
  "$0 dosya sistemi"
 ],
 "$0 hour": [
  null,
  "$0 saat",
  "$0 saat"
 ],
 "$0 hours": [
  null,
  "$0 saat"
 ],
 "$0 is in use": [
  null,
  "$0 kullanımda"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0, hiçbir depoda yok."
 ],
 "$0 key changed": [
  null,
  "$0 anahtarı değişti"
 ],
 "$0 killed with signal $1": [
  null,
  "$0, $1 sinyali ile sonlandırıldı"
 ],
 "$0 minute": [
  null,
  "$0 dakika",
  "$0 dakika"
 ],
 "$0 month": [
  null,
  "$0 ay",
  "$0 ay"
 ],
 "$0 partitions": [
  null,
  "$0 bölümleri"
 ],
 "$0 slot remains": [
  null,
  "$0 yuva kaldı",
  "$0 yuva kaldı"
 ],
 "$0 synchronized": [
  null,
  "$0 eşitlendi"
 ],
 "$0 used of $1 ($2 saved)": [
  null,
  "$0 kullanıldı, toplam $1 ($2 tasarruf edildi)"
 ],
 "$0 used, $1 total": [
  null,
  "$0 kullanılan, $1 toplam"
 ],
 "$0 week": [
  null,
  "$0 hafta",
  "$0 hafta"
 ],
 "$0 will be installed.": [
  null,
  "$0 kurulacak."
 ],
 "$0 year": [
  null,
  "$0 yıl",
  "$0 yıl"
 ],
 "$name (from $host)": [
  null,
  "$name ($host cihazından)"
 ],
 "(Not part of target)": [
  null,
  "(Hedefin bir parçası değil)"
 ],
 "(no assigned mount point)": [
  null,
  "(atanmış bağlama noktası yok)"
 ],
 "(not mounted)": [
  null,
  "(bağlanmadı)"
 ],
 "(recommended)": [
  null,
  "(önerilir)"
 ],
 "1 MiB": [
  null,
  "1 MiB"
 ],
 "1 day": [
  null,
  "1 gün"
 ],
 "1 hour": [
  null,
  "1 saat"
 ],
 "1 minute": [
  null,
  "1 dakika"
 ],
 "1 week": [
  null,
  "1 hafta"
 ],
 "128 KiB": [
  null,
  "128 KiB"
 ],
 "16 KiB": [
  null,
  "16 KiB"
 ],
 "2 MiB": [
  null,
  "2 MiB"
 ],
 "20 minutes": [
  null,
  "20 dakika"
 ],
 "32 KiB": [
  null,
  "32 KiB"
 ],
 "4 KiB": [
  null,
  "4 KiB"
 ],
 "40 minutes": [
  null,
  "40 dakika"
 ],
 "5 minutes": [
  null,
  "5 dakika"
 ],
 "512 KiB": [
  null,
  "512 KiB"
 ],
 "6 hours": [
  null,
  "6 saat"
 ],
 "60 minutes": [
  null,
  "60 dakika"
 ],
 "64 KiB": [
  null,
  "64 KiB"
 ],
 "8 KiB": [
  null,
  "8 KiB"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "$0 üzerinde uyumlu bir Cockpit sürümü kurulu değil."
 ],
 "A fatal error occurred during the self-test operation": [
  null,
  "Kendi kendine deneme işlemi sırasında önemli bir hata meydana geldi"
 ],
 "A filesystem with this name exists already in this pool.": [
  null,
  "Bu havuzda bu adda bir dosya sistemi zaten var."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "$2 üzerinde $1 için $0 konumunda yeni bir SSH anahtarı oluşturulacak ve $5 üzerindeki $4 kullanıcısının $3 dosyasına eklenecektir."
 ],
 "A pool with this name exists already.": [
  null,
  "Bu adda bir havuz zaten var."
 ],
 "A volume group with missing physical volumes can not be renamed.": [
  null,
  "Eksik fiziksel birimlere sahip bir birim grubu yeniden adlandırılamaz."
 ],
 "Abort test": [
  null,
  "Denemeyi iptal et"
 ],
 "Aborted": [
  null,
  "İptal edildi"
 ],
 "Aborted by a Controller Level Reset": [
  null,
  "Bir Denetleyici Seviyesi Sıfırlama ile iptal edildi"
 ],
 "Aborted due to a removal of a namespace from the namespace inventory": [
  null,
  "Ad alanı envanterinden bir ad alanının kaldırılmasından dolayı iptal edildi"
 ],
 "Aborted due to a sanitize operation": [
  null,
  "Bir sterilize işleminden dolayı iptal edildi"
 ],
 "Aborted due to the processing of a Format NVM command": [
  null,
  "Bir NVM Biçimlendirme komutunun işlenmesinden dolayı iptal edildi"
 ],
 "Aborted for unknown reason": [
  null,
  "Bilinmeyen bir nedenden dolayı iptal edildi"
 ],
 "Absent": [
  null,
  "Yok"
 ],
 "Acceptable password": [
  null,
  "Kabul edilebilir parola"
 ],
 "Action": [
  null,
  "Eylem"
 ],
 "Actions": [
  null,
  "Eylemler"
 ],
 "Activate": [
  null,
  "Etkinleştir"
 ],
 "Activate before resizing": [
  null,
  "Yeniden boyutlandırmadan önce etkinleştir"
 ],
 "Activating $target": [
  null,
  "$target etkinleştiriliyor"
 ],
 "Add": [
  null,
  "Ekle"
 ],
 "Add $0": [
  null,
  "$0 ekle"
 ],
 "Add Network Bound Disk Encryption": [
  null,
  "Ağa Bağlı Disk Şifrelemesi ekle"
 ],
 "Add Tang keyserver": [
  null,
  "Tang anahtar sunucusu ekle"
 ],
 "Add a bitmap": [
  null,
  "Bit eşlem ekle"
 ],
 "Add block devices": [
  null,
  "Blok aygıtlarını ekle"
 ],
 "Add disk": [
  null,
  "Disk ekle"
 ],
 "Add disks": [
  null,
  "Diskleri ekle"
 ],
 "Add iSCSI portal": [
  null,
  "iSCSI portalı ekle"
 ],
 "Add key": [
  null,
  "Anahtar ekle"
 ],
 "Add keyserver": [
  null,
  "Anahtar sunucusu ekle"
 ],
 "Add passphrase": [
  null,
  "Parola ekle"
 ],
 "Add physical volume": [
  null,
  "Fiziksel birim ekle"
 ],
 "Adding \"$0\" to encryption options": [
  null,
  "Şifreleme seçeneklerine \"$0\" ekleniyor"
 ],
 "Adding \"$0\" to filesystem options": [
  null,
  "Dosya sistemi seçeneklerine \"$0\" ekleniyor"
 ],
 "Adding a keyserver requires unlocking the pool. Please provide the existing pool passphrase.": [
  null,
  "Bir anahtar sunucusu eklemek, havuzun kilidinin açılmasını gerektirir. Lütfen varolan havuz parolasını girin."
 ],
 "Adding key": [
  null,
  "Anahtar ekleniyor"
 ],
 "Adding physical volume to $target": [
  null,
  "$target aygıtına fiziksel birim ekleniyor"
 ],
 "Adding rd.neednet=1 to kernel command line": [
  null,
  "Çekirdek komut satırına rd.neednet=1 ekleniyor"
 ],
 "Additional packages:": [
  null,
  "Ek paketler:"
 ],
 "Address": [
  null,
  "Adres"
 ],
 "Address cannot be empty": [
  null,
  "Adres boş olamaz"
 ],
 "Address is not a valid URL": [
  null,
  "Adres geçerli bir URL değil"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Cockpit Web Konsolu ile Yönetim"
 ],
 "Advanced TCA": [
  null,
  "Gelişmiş TCA"
 ],
 "All $0 selected physical volumes are needed for the chosen layout.": [
  null,
  "Seçilen düzen için seçilen tüm $0 fiziksel birim gereklidir."
 ],
 "All media is in read-only mode": [
  null,
  "Tüm ortam salt okunur modda"
 ],
 "All-in-one": [
  null,
  "Hepsi-bir-arada"
 ],
 "Allocated": [
  null,
  "Ayrıldı"
 ],
 "Allow overprovisioning": [
  null,
  "Aşırı sağlamaya izin ver"
 ],
 "An additional $0 must be selected": [
  null,
  "Bir ek $0 seçilmek zorundadır"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Ansible rolleri belgeleri"
 ],
 "Appropriate for critical mounts, such as /var": [
  null,
  "/var gibi önemli bağlamalar için uygun"
 ],
 "Assessment": [
  null,
  "Değerlendirme"
 ],
 "At boot": [
  null,
  "Önyüklemede"
 ],
 "At least $0 disk is needed.": [
  null,
  "En az $0 disk gerekli.",
  "En az $0 disk gerekli."
 ],
 "At least one block device is needed.": [
  null,
  "En az bir blok aygıtı gerekli."
 ],
 "At least one disk is needed.": [
  null,
  "En az bir disk gerekli."
 ],
 "At least one subvolume needs to be mounted": [
  null,
  "En az bir alt birimin bağlanması gerekir"
 ],
 "Attributes failing": [
  null,
  "Öznitelikler hatası"
 ],
 "Authentication": [
  null,
  "Kimlik doğrulama"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Cockpit Web Konsolu ile yetkili görevleri gerçekleştirmek için kimlik doğrulaması gerekir"
 ],
 "Authentication required": [
  null,
  "Kimlik doğrulaması gerekli"
 ],
 "Authorize SSH key": [
  null,
  "SSH anahtarını yetkilendir"
 ],
 "Automatically using NTP": [
  null,
  "Otomatik olarak NTP kullanarak"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Otomatik olarak ek NTP sunucularını kullanarak"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Otomatik olarak belirli NTP sunucularını kullanarak"
 ],
 "Automation script": [
  null,
  "Otomatikleştirme betiği"
 ],
 "Available targets on $0": [
  null,
  "$0 üzerindeki kullanılabilir hedefler"
 ],
 "BIOS boot partition": [
  null,
  "BIOS önyükleme bölümü"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Blade kasası"
 ],
 "Block device": [
  null,
  "Blok aygıt"
 ],
 "Block device for filesystems": [
  null,
  "Dosya sistemleri için blok aygıtı"
 ],
 "Block devices": [
  null,
  "Blok aygıtlar"
 ],
 "Blocked": [
  null,
  "Engellendi"
 ],
 "Boot fails if filesystem does not mount, preventing remote access": [
  null,
  "Dosya sistemi bağlanmazsa önyükleme başarısız olur ve uzaktan erişim önlenir"
 ],
 "Boot still succeeds when filesystem does not mount": [
  null,
  "Dosya sistemi bağlanmadığında önyükleme hala başarılı olur"
 ],
 "Bus expansion chassis": [
  null,
  "Veri yolu genişletme kasası"
 ],
 "Cache": [
  null,
  "Önbellek"
 ],
 "Cancel": [
  null,
  "İptal"
 ],
 "Cannot forward login credentials": [
  null,
  "Oturum açma kimlik bilgileri yönlendirilemiyor"
 ],
 "Cannot schedule event in the past": [
  null,
  "Geçmişteki olay zamanlanamıyor"
 ],
 "Capacity": [
  null,
  "Kapasite"
 ],
 "Category": [
  null,
  "Kategori"
 ],
 "Change": [
  null,
  "Değiştir"
 ],
 "Change iSCSI initiator name": [
  null,
  "iSCSI başlatıcı adını değiştir"
 ],
 "Change label": [
  null,
  "Etiketi değiştir"
 ],
 "Change passphrase": [
  null,
  "Parolayı değiştir"
 ],
 "Change system time": [
  null,
  "Sistem saatini değiştir"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Değiştirilen anahtarlar genellikle bir işletim sisteminin yeniden kurulması sonucudur. Ancak, beklenmeyen bir değişiklik, üçüncü tarafın bağlantınıza müdahale etme girişimini gösterebilir."
 ],
 "Changing partition types might prevent the system from booting.": [
  null,
  "Bölüm türlerinin değiştirilmesi sistemin önyüklemesini engelleyebilir."
 ],
 "Check that the SHA-256 or SHA-1 hash from the command matches this dialog.": [
  null,
  "Komuttan SHA-256 veya SHA-1 adreslemesinin bu ileti öğesiyle eşleştiğini denetleyin."
 ],
 "Check the key hash with the Tang server.": [
  null,
  "Anahtar adreslemesini Tang sunucusuyla denetleyin."
 ],
 "Checking $target": [
  null,
  "$target denetleniyor"
 ],
 "Checking MDRAID device $target": [
  null,
  "MDRAID aygıtı $target denetleniyor"
 ],
 "Checking and repairing MDRAID device $target": [
  null,
  "MDRAID aygıtı $target denetleniyor ve onarılıyor"
 ],
 "Checking filesystem usage": [
  null,
  "Dosya sistemi kullanımı denetleniyor"
 ],
 "Checking for $0 package": [
  null,
  "$0 paketi denetleniyor"
 ],
 "Checking for NBDE support in the initrd": [
  null,
  "initrd'de NBDE desteği denetleniyor"
 ],
 "Checking installed software": [
  null,
  "Kurulu yazılımlar denetleniyor"
 ],
 "Chunk size": [
  null,
  "Öbek boyutu"
 ],
 "Cleaning up for $target": [
  null,
  "$target temizleniyor"
 ],
 "Clear input value": [
  null,
  "Giriş değerini temizle"
 ],
 "Cleartext device": [
  null,
  "Metin temizleme aygıtı"
 ],
 "Close": [
  null,
  "Kapat"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "NetworkManager ve Firewalld'un Cockpit yapılandırması"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit, verilen anamakineyle iletişim kuramadı."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit, Linux sunucularınızı bir web tarayıcısı aracılığıyla yönetmenizi kolaylaştıran bir sunucu yöneticisidir. Terminal ve web aracı arasında geçiş yapmak sorun değildir. Cockpit aracılığıyla başlatılan bir hizmet terminal aracılığıyla durdurulabilir. Aynı şekilde, terminalde bir hata meydana gelirse, Cockpit günlüğü arayüzünde görülebilir."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit, sistemdeki yazılımla uyumlu değil."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit kurulu değil"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit sistemde kurulu değil."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit yeni sistem yöneticileri için mükemmeldir; depolama yönetimi, günlükleri inceleme, hizmetleri başlatma ve durdurma gibi basit görevleri kolayca gerçekleştirmelerine olanak tanır. Aynı anda birkaç sunucuyu izleyebilir ve yönetebilirsiniz. Bunları tek bir tıklama ile ekleyin ve makineleriniz arkadaşlarıyla ilgilensin."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Tanılama ve destek verilerini topla ve paketle"
 ],
 "Collect kernel crash dumps": [
  null,
  "Çekirdek çökme dökümlerini topla"
 ],
 "Command": [
  null,
  "Komut"
 ],
 "Compact PCI": [
  null,
  "Compact PCI"
 ],
 "Compatible with all systems and devices (MBR)": [
  null,
  "Tüm sistem ve aygıtlarla uyumlu (MBR)"
 ],
 "Compatible with modern system and hard disks > 2TB (GPT)": [
  null,
  "Modern sistem ve 2TB'tan büyük sabit disklerle uyumlu (GPT)"
 ],
 "Completed with a segment that failed and the segment that failed is not known": [
  null,
  "Başarısız olan bir bölüm ile tamamlandı ve başarısız olan bölüm bilinmiyor"
 ],
 "Completed with one or more failed segments": [
  null,
  "Bir veya daha fazla başarısız olan bölümle tamamlandı"
 ],
 "Compression": [
  null,
  "Sıkıştırma"
 ],
 "Confirm": [
  null,
  "Onayla"
 ],
 "Confirm deletion of $0": [
  null,
  "$0 aygıtının silinmesini onayla"
 ],
 "Confirm key password": [
  null,
  "Anahtar parolasını onayla"
 ],
 "Confirm removal with an alternate passphrase": [
  null,
  "Kaldırmayı alternatif bir parola ile onayla"
 ],
 "Confirm stopping of $0": [
  null,
  "$0 aygıtının durdurulmasını onaylayın"
 ],
 "Connection has timed out.": [
  null,
  "Bağlantı zaman aşımına uğradı."
 ],
 "Convertible": [
  null,
  "Dönüştürülebilir"
 ],
 "Copied": [
  null,
  "Kopyalandı"
 ],
 "Copy": [
  null,
  "Kopyala"
 ],
 "Copy to clipboard": [
  null,
  "Panoya kopyala"
 ],
 "Create": [
  null,
  "Oluştur"
 ],
 "Create $0": [
  null,
  "$0 oluştur"
 ],
 "Create LVM2 volume group": [
  null,
  "LVM2 birim grubu oluştur"
 ],
 "Create MDRAID device": [
  null,
  "MDRAID aygıtı oluştur"
 ],
 "Create RAID device": [
  null,
  "RAID aygıtı oluştur"
 ],
 "Create Stratis pool": [
  null,
  "Stratis havuzu oluştur"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Yeni bir SSH anahtarı oluştur ve yetkilendir"
 ],
 "Create a snapshot of filesystem $0": [
  null,
  "$0 dosya sistemi için anlık görüntü oluştur"
 ],
 "Create and mount": [
  null,
  "Oluştur ve bağla"
 ],
 "Create and start": [
  null,
  "Oluştur ve başlat"
 ],
 "Create filesystem": [
  null,
  "Dosya sistemi oluştur"
 ],
 "Create logical volume": [
  null,
  "Mantıksal birim oluştur"
 ],
 "Create new filesystem": [
  null,
  "Yeni dosya sistemi oluştur"
 ],
 "Create new logical volume": [
  null,
  "Yeni mantıksal birim oluştur"
 ],
 "Create new task file with this content.": [
  null,
  "Bu içerikle yeni görev dosyası oluştur."
 ],
 "Create new thinly provisioned logical volume": [
  null,
  "Yeni ölçülü kaynak sağlanan mantıksal birim oluştur"
 ],
 "Create only": [
  null,
  "Sadece oluştur"
 ],
 "Create partition": [
  null,
  "Bölüm oluştur"
 ],
 "Create partition on $0": [
  null,
  "$0 üzerinde bölüm oluştur"
 ],
 "Create partition table": [
  null,
  "Bölüm tablosu oluştur"
 ],
 "Create snapshot": [
  null,
  "Anlık görüntü oluştur"
 ],
 "Create snapshot and mount": [
  null,
  "Anlık görüntü oluştur ve bağla"
 ],
 "Create snapshot only": [
  null,
  "Sadece anlık görüntü oluştur"
 ],
 "Create storage device": [
  null,
  "Depolama aygıtı oluştur"
 ],
 "Create subvolume": [
  null,
  "Alt birim oluştur"
 ],
 "Create thin volume": [
  null,
  "İnce birim oluştur"
 ],
 "Create volume group": [
  null,
  "Birim grubu oluştur"
 ],
 "Creating LVM2 volume group $target": [
  null,
  "$target LVM2 birim grubu oluşturuluyor"
 ],
 "Creating MDRAID device $target": [
  null,
  "MDRAID aygıtı $target oluşturuluyor"
 ],
 "Creating VDO device": [
  null,
  "VDO aygıtı oluşturuluyor"
 ],
 "Creating filesystem on $target": [
  null,
  "$target üzerinde dosya sistemi oluşturuluyor"
 ],
 "Creating logical volume $target": [
  null,
  "$target mantıksal birimi oluşturuluyor"
 ],
 "Creating partition $target": [
  null,
  "$target bölümü oluşturuluyor"
 ],
 "Creating snapshot of $target": [
  null,
  "$target için anlık görüntü oluşturuluyor"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Currently in use": [
  null,
  "Şu an kullanımda"
 ],
 "Custom": [
  null,
  "Özel"
 ],
 "Custom mount options": [
  null,
  "Özel bağlama seçenekleri"
 ],
 "Custom type": [
  null,
  "Özel tür"
 ],
 "Data": [
  null,
  "Veri"
 ],
 "Data used": [
  null,
  "Kullanılan veri"
 ],
 "Data will be stored as two copies and also in an alternating fashion on the selected physical volumes, to improve both reliability and performance. At least four volumes need to be selected.": [
  null,
  "Veriler, hem güvenilirliği hem de performansı artırmak için seçilen fiziksel birimlerde iki kopya halinde ve ayrıca dönüşümlü olarak depolanacaktır. En az dört birimin seçilmesi gerekir."
 ],
 "Data will be stored as two or more copies on the selected physical volumes, to improve reliability. At least two volumes need to be selected.": [
  null,
  "Veriler, güvenilirliği artırmak için seçilen fiziksel birimlerde iki veya daha fazla kopya halinde depolanacaktır. En az iki birimin seçilmesi gerekir."
 ],
 "Data will be stored on the selected physical volumes in an alternating fashion to improve performance. At least two volumes need to be selected.": [
  null,
  "Veriler, performansı artırmak için seçilen fiziksel birimlerde dönüşümlü olarak depolanacaktır. En az iki birim seçilmesi gerekir."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. At least three volumes need to be selected.": [
  null,
  "Veriler, seçilen fiziksel birimlerde depolanacak ve böylece veriler etkilenmeden bunlardan biri kaybedilebilecektir. En az üç birim seçilmesi gerekir."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. Data is also stored in an alternating fashion to improve performance. At least three volumes need to be selected.": [
  null,
  "Veriler, seçilen fiziksel birimlerde depolanacak ve böylece veriler etkilenmeden bunlardan biri kaybedilebilecektir. Performansı artırmak için veriler ayrıca dönüşümlü olarak depolanır. En az üç birim seçilmesi gerekir."
 ],
 "Data will be stored on the selected physical volumes so that up to two of them can be lost at the same time without affecting the data. Data is also stored in an alternating fashion to improve performance. At least five volumes need to be selected.": [
  null,
  "Veriler, seçilen fiziksel birimlerde depolanacak, böylece veriler etkilenmeden aynı anda en fazla iki tanesi kaybedilebilecektir. Performansı artırmak için veriler ayrıca dönüşümlü olarak depolanır. En az beş birim seçilmesi gerekir."
 ],
 "Data will be stored on the selected physical volumes without any additional redundancy or performance improvements.": [
  null,
  "Veriler, herhangi bir ek yedeklilik veya performans iyileştirmesi olmaksızın seçilen fiziksel birimlerde depolanacaktır."
 ],
 "Deactivate": [
  null,
  "Devre dışı bırak"
 ],
 "Deactivate logical volume $0/$1?": [
  null,
  "Mantıksal birim $0/$1 devre dışı bırakılsın mı?"
 ],
 "Deactivating $target": [
  null,
  "$target devre dışı bırakılıyor"
 ],
 "Dedicated parity (RAID 4)": [
  null,
  "Adanmış eşlik (RAID 4)"
 ],
 "Deduplication": [
  null,
  "Tekilleştirme"
 ],
 "Degraded": [
  null,
  "Bozulmuş"
 ],
 "Delay": [
  null,
  "Gecikme"
 ],
 "Delete": [
  null,
  "Sil"
 ],
 "Delete filesystem": [
  null,
  "Dosya sistemini sil"
 ],
 "Delete group": [
  null,
  "Grubu sil"
 ],
 "Delete pool": [
  null,
  "Havuzu sil"
 ],
 "Deleting $target": [
  null,
  "$target siliniyor"
 ],
 "Deleting LVM2 volume group $target": [
  null,
  "$target LVM2 birim grubu siliniyor"
 ],
 "Deleting a Stratis pool will erase all data it contains.": [
  null,
  "Bir Stratis havuzunu silmek içerdiği tüm verileri silecek."
 ],
 "Deleting a filesystem will delete all data in it.": [
  null,
  "Bir dosya sistemini silmek, içindeki tüm verileri silecek."
 ],
 "Deleting a logical volume will delete all data in it.": [
  null,
  "Mantıksal bir birimi silmek, içindeki tüm verileri silecektir."
 ],
 "Deleting a partition will delete all data in it.": [
  null,
  "Bir bölümü silmek, içindeki tüm verileri silecektir."
 ],
 "Deleting erases all data on a MDRAID device.": [
  null,
  "Silme, bir MDRAID aygıtı üzerindeki tüm verileri siler."
 ],
 "Deleting erases all data on a VDO device.": [
  null,
  "Silme, bir VDO aygıtı üzerindeki tüm verileri siler."
 ],
 "Deleting erases all data on a btrfs volume.": [
  null,
  "Silme, bir btrfs birimi üzerindeki tüm verileri siler."
 ],
 "Deleting erases all data on a volume group.": [
  null,
  "Silme, bir birim grubu üzerindeki tüm verileri siler."
 ],
 "Deleting erases all data on this subvolume and all its children.": [
  null,
  "Silme, bu alt birimdeki tüm verileri ve alt birimlerinin tümünü siler."
 ],
 "Description": [
  null,
  "Açıklama"
 ],
 "Desktop": [
  null,
  "Masaüstü"
 ],
 "Detachable": [
  null,
  "Ayrılabilir"
 ],
 "Device": [
  null,
  "Aygıt"
 ],
 "Device contains unrecognized data": [
  null,
  "Cihaz tanınmayan veriler içeriyor"
 ],
 "Device file": [
  null,
  "Aygıt dosyası"
 ],
 "Device health (SMART)": [
  null,
  "Aygıt sağlığı (SMART)"
 ],
 "Device is read-only": [
  null,
  "Aygıt salt-okunur"
 ],
 "Device number": [
  null,
  "Aygıt numarası"
 ],
 "Diagnostic reports": [
  null,
  "Tanılama raporları"
 ],
 "Did not complete": [
  null,
  "Tamamlanmadı"
 ],
 "Disconnect": [
  null,
  "Bağlantıyı kes"
 ],
 "Disk is OK": [
  null,
  "Disk TAMAM"
 ],
 "Disk is failing": [
  null,
  "Disk bozuluyor"
 ],
 "Disk passphrase": [
  null,
  "Disk parolası"
 ],
 "Disks": [
  null,
  "Diskler"
 ],
 "Dismiss": [
  null,
  "Yoksay"
 ],
 "Distributed parity (RAID 5)": [
  null,
  "Adanmış eşlik (RAID 5)"
 ],
 "Do not mount": [
  null,
  "Bağlama"
 ],
 "Do not mount automatically on boot": [
  null,
  "Önyüklemede otomatik olarak bağlama"
 ],
 "Docking station": [
  null,
  "Kenetleme istasyonu"
 ],
 "Does not mount during boot": [
  null,
  "Önyükleme sırasında bağlamaz"
 ],
 "Double distributed parity (RAID 6)": [
  null,
  "Çift dağıtılmış eşlik (RAID 6)"
 ],
 "Downloading $0": [
  null,
  "$0 indiriliyor"
 ],
 "Drive": [
  null,
  "Sürücü"
 ],
 "Dual rank": [
  null,
  "Çift sıra"
 ],
 "EFI system partition": [
  null,
  "EFI sistem bölümü"
 ],
 "Edit": [
  null,
  "Düzenle"
 ],
 "Edit Tang keyserver": [
  null,
  "Tang anahtar sunucusunu düzenle"
 ],
 "Edit mount point": [
  null,
  "Bağlama noktasını düzenle"
 ],
 "Editing a key requires a free slot": [
  null,
  "Bir anahtarı düzenlemek, boş bir yuva gerektirir"
 ],
 "Ejecting $target": [
  null,
  "$target çıkarılıyor"
 ],
 "Embedded PC": [
  null,
  "Gömülü PC"
 ],
 "Emptying $target": [
  null,
  "$target boşaltılıyor"
 ],
 "Enabling $0": [
  null,
  "$0 etkinleştiriliyor"
 ],
 "Encrypt data with a Tang keyserver": [
  null,
  "Verileri Tang anahtar sunucusuyla şifrele"
 ],
 "Encrypt data with a passphrase": [
  null,
  "Verileri bir parolayla şifrele"
 ],
 "Encrypted $0": [
  null,
  "Şifrelenmiş $0"
 ],
 "Encrypted Stratis pool": [
  null,
  "Şifrelenmiş Stratis havuzu"
 ],
 "Encrypted logical volume of $0": [
  null,
  "$0 aygıtının şifrelenmiş mantıksal birimi"
 ],
 "Encrypted partition of $0": [
  null,
  "$0 aygıtının şifrelenmiş bölümü"
 ],
 "Encryption": [
  null,
  "Şifreleme"
 ],
 "Encryption options": [
  null,
  "Şifreleme seçenekleri"
 ],
 "Encryption type": [
  null,
  "Şifreleme türü"
 ],
 "Erasing $target": [
  null,
  "$target siliniyor"
 ],
 "Error": [
  null,
  "Hata"
 ],
 "Error installing $0: PackageKit is not installed": [
  null,
  "$0 kurulurken hata oldu: PackageKit kurulu değil"
 ],
 "Exactly $0 physical volumes must be selected": [
  null,
  "Tam olarak $0 fiziksel birim seçilmek zorundadır"
 ],
 "Exactly $0 physical volumes need to be selected, one for each stripe of the logical volume.": [
  null,
  "Mantıksal birimin her şeritlemesi için bir tane olmak üzere tam olarak $0 fiziksel birimin seçilmesi gerekir."
 ],
 "Excellent password": [
  null,
  "Mükemmel parola"
 ],
 "Expansion chassis": [
  null,
  "Genişletme kasası"
 ],
 "Extended partition": [
  null,
  "Genişletilmiş bölüm"
 ],
 "Failed": [
  null,
  "Başarısız oldu"
 ],
 "Failed (Damaged)": [
  null,
  "Başarısız oldu (Hasarlı)"
 ],
 "Failed (Electrical)": [
  null,
  "Başarısız oldu (Elektriksel)"
 ],
 "Failed (Read)": [
  null,
  "Başarısız oldu (Okuma)"
 ],
 "Failed (Servo)": [
  null,
  "Başarısız oldu (Servo)"
 ],
 "Failed (Unknown)": [
  null,
  "Başarısız oldu (Bilinmiyor)"
 ],
 "Failed to change password": [
  null,
  "Parolayı değiştirme başarısız oldu"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "firewalld içinde $0 etkinleştirme başarısız oldu"
 ],
 "Filesystem": [
  null,
  "Dosya sistemi"
 ],
 "Filesystem is locked": [
  null,
  "Dosya sistemi kilitli"
 ],
 "Filesystem is mounted read-only": [
  null,
  "Dosya sistemi salt okunur olarak bağlanmış"
 ],
 "Filesystem name": [
  null,
  "Dosya sistemi adı"
 ],
 "Filesystem outside the target": [
  null,
  "Hedefin dışındaki dosya sistemi"
 ],
 "Filesystems are already mounted below this mountpoint.": [
  null,
  "Dosya sistemi zaten bu bağlama noktasının altına bağlanmış."
 ],
 "Firmware version": [
  null,
  "Donanım yazılımı sürümü"
 ],
 "Fix NBDE support": [
  null,
  "NBDE desteğini düzelt"
 ],
 "Format": [
  null,
  "Biçimlendir"
 ],
 "Format $0": [
  null,
  "$0 biçimlendir"
 ],
 "Format and mount": [
  null,
  "Biçimlendir ve bağla"
 ],
 "Format and start": [
  null,
  "Biçimlendir ve başlat"
 ],
 "Format only": [
  null,
  "Sadece biçimlendir"
 ],
 "Formatting erases all data on a storage device.": [
  null,
  "Biçimlendirme, depolama aygıtı üzerindeki tüm verileri siler."
 ],
 "Free space": [
  null,
  "Boş alan"
 ],
 "Go to now": [
  null,
  "Şimdiye git"
 ],
 "Grow": [
  null,
  "Büyüt"
 ],
 "Grow content": [
  null,
  "İçeriği büyüt"
 ],
 "Grow logical size of $0": [
  null,
  "$0'ın mantıksal boyutunu büyüt"
 ],
 "Grow logical volume": [
  null,
  "Mantıksal birimi büyüt"
 ],
 "Grow partition": [
  null,
  "Bölümü büyüt"
 ],
 "Grow the pool to take all space": [
  null,
  "Tüm alanı kaplayacak şekilde havuzu büyüt"
 ],
 "Grow to take all space": [
  null,
  "Tüm alanı kaplayacak şekilde büyüt"
 ],
 "Handheld": [
  null,
  "Elde taşınan"
 ],
 "Hard Disk Drive": [
  null,
  "Sabit Disk Sürücüsü"
 ],
 "Hide confirmation password": [
  null,
  "Onay parolasını gizle"
 ],
 "Hide password": [
  null,
  "Parolayı gizle"
 ],
 "Host key is incorrect": [
  null,
  "Anamakine anahtarı yanlış"
 ],
 "How to check": [
  null,
  "Nasıl denetlenir"
 ],
 "I confirm I want to lose this data forever": [
  null,
  "Bu verileri sonsuza kadar kaybetmek istediğimi onaylıyorum"
 ],
 "ID": [
  null,
  "Kimlik"
 ],
 "INTERNAL ERROR - This logical volume is marked as active and should have an associated block device. However, no such block device could be found.": [
  null,
  "DAHİLİ HATA - Bu mantıksal birim etkin olarak işaretlendi ve ilişkilendirilmiş bir blok aygıta sahip olmalıdır. Ancak böyle bir blok aygıt bulunamadı."
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Eğer parmak izi eşleşirse, 'Anamakineye güven ve ekle'ye tıklayın. Aksi takdirde, bağlanmayın ve yöneticinize başvurun."
 ],
 "Important data might be deleted:": [
  null,
  "Önemli veriler silinebilir:"
 ],
 "In a terminal, run: ": [
  null,
  "Bir terminalde şunu çalıştırın: "
 ],
 "In progress": [
  null,
  "Sürüyor"
 ],
 "In sync": [
  null,
  "Eşitleme durumunda"
 ],
 "Inactive logical volume": [
  null,
  "Etkin olmayan mantıksal birim"
 ],
 "Inconsistent filesystem mount": [
  null,
  "Tutarsız dosya sistemi bağlama"
 ],
 "Index memory": [
  null,
  "İndeks belleği"
 ],
 "Initialize": [
  null,
  "Başlat"
 ],
 "Initialize disk $0": [
  null,
  "$0 diskini başlat"
 ],
 "Initializing erases all data on a disk.": [
  null,
  "Başlatma, disk üzerindeki tüm verileri siler."
 ],
 "Install": [
  null,
  "Kur"
 ],
 "Install NFS support": [
  null,
  "NFS desteğini kur"
 ],
 "Install Stratis support": [
  null,
  "Stratis desteğini kur"
 ],
 "Install software": [
  null,
  "Yazılım kur"
 ],
 "Installing $0": [
  null,
  "$0 kuruluyor"
 ],
 "Installing $0 would remove $1.": [
  null,
  "$0 paketini kurmak $1 paketini kaldırır."
 ],
 "Installing packages": [
  null,
  "Paketler kuruluyor"
 ],
 "Internal error": [
  null,
  "İç hata"
 ],
 "Interrupted": [
  null,
  "Kesilmiş"
 ],
 "Invalid date format": [
  null,
  "Geçersiz tarih biçimi"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Geçersiz tarih ve saat biçimi"
 ],
 "Invalid file permissions": [
  null,
  "Geçersiz dosya izinleri"
 ],
 "Invalid time format": [
  null,
  "Geçersiz saat biçimi"
 ],
 "Invalid timezone": [
  null,
  "Geçersiz saat dilimi"
 ],
 "Invalid username or password": [
  null,
  "Geçersiz kullanıcı adı veya parola"
 ],
 "IoT gateway": [
  null,
  "IoT ağ geçidi"
 ],
 "Jobs": [
  null,
  "İşler"
 ],
 "Kernel dump": [
  null,
  "Çekirdek dökümü"
 ],
 "Key password": [
  null,
  "Anahtar parolası"
 ],
 "Key slots with unknown types can not be edited here": [
  null,
  "Bilinmeyen türlere sahip anahtar yuvaları burada düzenlenemez"
 ],
 "Key source": [
  null,
  "Anahtar kaynağı"
 ],
 "Keys": [
  null,
  "Anahtarlar"
 ],
 "Keyserver": [
  null,
  "Anahtar sunucusu"
 ],
 "Keyserver address": [
  null,
  "Anahtar sunucusu adresi"
 ],
 "Keyserver removal may prevent unlocking $0.": [
  null,
  "Anahtar sunucusu kaldırma, $0 kilidini açmayı engelleyebilir."
 ],
 "LVM2 VDO pool": [
  null,
  "LVM2 VDO havuzu"
 ],
 "LVM2 logical volume": [
  null,
  "LVM2 mantıksal birimi"
 ],
 "LVM2 logical volumes": [
  null,
  "LVM2 mantıksal birimleri"
 ],
 "LVM2 physical volume": [
  null,
  "LVM2 fiziksel birimi"
 ],
 "LVM2 physical volumes": [
  null,
  "LVM2 fiziksel birimleri"
 ],
 "LVM2 volume group": [
  null,
  "LVM2 birim grubu"
 ],
 "LVM2 volume group $0": [
  null,
  "$0 LVM2 birim grubu"
 ],
 "Label": [
  null,
  "Etiket"
 ],
 "Laptop": [
  null,
  "Dizüstü"
 ],
 "Last cannot be removed": [
  null,
  "Sonuncusu kaldırılamaz"
 ],
 "Last disk can not be removed": [
  null,
  "Son disk kaldırılamaz"
 ],
 "Last modified: $0": [
  null,
  "Son değiştirilme: $0"
 ],
 "Layout": [
  null,
  "Düzen"
 ],
 "Learn more": [
  null,
  "Daha fazla bilgi edinin"
 ],
 "Limit size": [
  null,
  "Boyutu sınırla"
 ],
 "Limit virtual filesystem size": [
  null,
  "Sanal dosya sistemi boyutunu sınırla"
 ],
 "Linear": [
  null,
  "Doğrusal"
 ],
 "Linux filesystem data": [
  null,
  "Linux dosya sistemi verileri"
 ],
 "Linux swap space": [
  null,
  "Linux takas alanı"
 ],
 "Loading system modifications...": [
  null,
  "Sistem değişiklikleri yükleniyor..."
 ],
 "Loading...": [
  null,
  "Yükleniyor..."
 ],
 "Local mount point": [
  null,
  "Yerel bağlama noktası"
 ],
 "Local storage": [
  null,
  "Yerel depolama"
 ],
 "Location": [
  null,
  "Konum"
 ],
 "Lock": [
  null,
  "Kilitle"
 ],
 "Lock $0?": [
  null,
  "$0 kilitlensin mi?"
 ],
 "Locked data": [
  null,
  "Kilitli veriler"
 ],
 "Locked encrypted device might contain data": [
  null,
  "Kilitli şifreli cihaz veri içerebilir"
 ],
 "Locking $target": [
  null,
  "$target kilitleniyor"
 ],
 "Log in": [
  null,
  "Oturum aç"
 ],
 "Log in to $0": [
  null,
  "$0 üzerinde oturum aç"
 ],
 "Log messages": [
  null,
  "Günlük iletileri"
 ],
 "Logical": [
  null,
  "Mantıksal"
 ],
 "Logical Volume Manager partition": [
  null,
  "Mantıksal Birim Yöneticisi bölümü"
 ],
 "Logical size": [
  null,
  "Mantıksal boyut"
 ],
 "Logical volume": [
  null,
  "Mantıksal birim"
 ],
 "Logical volume (snapshot)": [
  null,
  "Mantıksal birim (anlık görüntü)"
 ],
 "Logical volume of $0": [
  null,
  "$0 bölümünün mantıksal birimi"
 ],
 "Login failed": [
  null,
  "Oturum açma başarısız oldu"
 ],
 "Low profile desktop": [
  null,
  "Düşük profilli masaüstü"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "MDRAID device": [
  null,
  "MDRAID aygıtı"
 ],
 "MDRAID device $0": [
  null,
  "MDRAID aygıtı $0"
 ],
 "MDRAID device is recovering": [
  null,
  "MDRAID aygıtı kurtarılıyor"
 ],
 "MDRAID device must be running": [
  null,
  "MDRAID aygıtı çalışıyor olmak zorundadır"
 ],
 "MDRAID disk": [
  null,
  "MDRAID diski"
 ],
 "MDRAID disks": [
  null,
  "MDRAID diskleri"
 ],
 "Main server chassis": [
  null,
  "Ana sunucu kasası"
 ],
 "Manage storage": [
  null,
  "Depolamayı yönet"
 ],
 "Manually": [
  null,
  "El ile"
 ],
 "Marking $target as faulty": [
  null,
  "$target hatalı olarak işaretleniyor"
 ],
 "Media drive": [
  null,
  "Ortam sürücüsü"
 ],
 "Message to logged in users": [
  null,
  "Oturum açmış kullanıcılar için ileti"
 ],
 "Metadata used": [
  null,
  "Kullanılan üst veri"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini tower"
 ],
 "Mirrored (RAID 1)": [
  null,
  "Yansıtılmış (RAID 1)"
 ],
 "Model": [
  null,
  "Model"
 ],
 "Modifying $target": [
  null,
  "$target değiştiriliyor"
 ],
 "Mount": [
  null,
  "Bağla"
 ],
 "Mount Point": [
  null,
  "Bağlama Noktası"
 ],
 "Mount after network becomes available, ignore failure": [
  null,
  "Ağ kullanılabilir hale geldikten sonra bağla, hatayı yoksay"
 ],
 "Mount also automatically on boot": [
  null,
  "Önyüklemede de otomatik olarak bağla"
 ],
 "Mount at boot": [
  null,
  "Önyüklemede bağla"
 ],
 "Mount automatically on $0 on boot": [
  null,
  "Önyüklemede $0 noktasına otomatik olarak bağla"
 ],
 "Mount before services start": [
  null,
  "Hizmetler başlamadan önce bağla"
 ],
 "Mount configuration": [
  null,
  "Bağlama yapılandırması"
 ],
 "Mount filesystem": [
  null,
  "Dosya sistemini bağla"
 ],
 "Mount now": [
  null,
  "Şimdi bağla"
 ],
 "Mount on $0 now": [
  null,
  "Şimdi $0 noktasına bağla"
 ],
 "Mount options": [
  null,
  "Bağlama seçenekleri"
 ],
 "Mount point": [
  null,
  "Bağlama noktası"
 ],
 "Mount point cannot be empty": [
  null,
  "Bağlama noktası boş olamaz"
 ],
 "Mount point cannot be empty.": [
  null,
  "Bağlama noktası boş olamaz."
 ],
 "Mount point is already used for $0": [
  null,
  "Bağlama noktası zaten $0 için kullanılıyor"
 ],
 "Mount point must start with \"/\".": [
  null,
  "Bağlama noktası \"/\" ile başlamak zorundadır."
 ],
 "Mount read only": [
  null,
  "Salt okunur bağla"
 ],
 "Mount without waiting, ignore failure": [
  null,
  "Beklemeden bağla, hatayı yoksay"
 ],
 "Mounting $target": [
  null,
  "$target bağlanıyor"
 ],
 "Mounts before services start": [
  null,
  "Hizmetler başlamadan önce bağlar"
 ],
 "Mounts in parallel with services": [
  null,
  "Hizmetlerle paralel olarak bağlar"
 ],
 "Mounts in parallel with services, but after network is available": [
  null,
  "Hizmetlerle paralel olarak bağlar, ancak ağ kullanılabilir olduktan sonra"
 ],
 "Multi-system chassis": [
  null,
  "Çok sistemli kasa"
 ],
 "Multipathed devices": [
  null,
  "Çok yollu aygıtlar"
 ],
 "NFS mount": [
  null,
  "NFS bağlama noktası"
 ],
 "NTP server": [
  null,
  "NTP sunucusu"
 ],
 "Name": [
  null,
  "Ad"
 ],
 "Name can not be empty.": [
  null,
  "Ad boş olamaz."
 ],
 "Name cannot be empty.": [
  null,
  "Ad boş olamaz."
 ],
 "Name cannot be longer than $0 bytes": [
  null,
  "Ad $0 bayt'tan uzun olamaz"
 ],
 "Name cannot be longer than $0 characters": [
  null,
  "Ad $0 karakterden uzun olamaz"
 ],
 "Name cannot be longer than 127 characters.": [
  null,
  "Ad 127 karakterden uzun olamaz."
 ],
 "Name cannot be longer than 255 characters.": [
  null,
  "Ad 255 karakterden uzun olamaz."
 ],
 "Name cannot contain the character '$0'.": [
  null,
  "Ad '$0' karakterini içeremez."
 ],
 "Name cannot contain the character '/'.": [
  null,
  "Ad '/' karakterini içeremez."
 ],
 "Name cannot contain whitespace.": [
  null,
  "Ad boşluk karakterleri içeremez."
 ],
 "Need a spare disk": [
  null,
  "Yedek diske ihtiyaç var"
 ],
 "Need at least one NTP server": [
  null,
  "En az bir NTP sunucusu gerekli"
 ],
 "Networked storage": [
  null,
  "Ağa bağlı depolama"
 ],
 "Networking": [
  null,
  "Ağ"
 ],
 "New NFS mount": [
  null,
  "Yeni NFS bağlama noktası"
 ],
 "New passphrase": [
  null,
  "Yeni parola"
 ],
 "New password was not accepted": [
  null,
  "Yeni parola kabul edilmedi"
 ],
 "Next": [
  null,
  "Sonraki"
 ],
 "No available slots": [
  null,
  "Kullanılabilir yuvalar yok"
 ],
 "No block devices are available.": [
  null,
  "Kullanılabilir blok aygıtlar yok."
 ],
 "No block devices found": [
  null,
  "Bulunan blok aygıtlar yok"
 ],
 "No delay": [
  null,
  "Gecikme yok"
 ],
 "No devices found": [
  null,
  "Bulunan aygıtlar yok"
 ],
 "No disks are available.": [
  null,
  "Kullanılabilir diskler yok."
 ],
 "No disks found": [
  null,
  "Bulunan diskler yok"
 ],
 "No drives found": [
  null,
  "Bulunan sürücüler yok"
 ],
 "No encryption": [
  null,
  "Şifreleme yok"
 ],
 "No filesystem": [
  null,
  "Dosya sistemi yok"
 ],
 "No filesystems": [
  null,
  "Dosya sistemleri yok"
 ],
 "No free key slots": [
  null,
  "Boş anahtar yuvaları yok"
 ],
 "No free space": [
  null,
  "Boş alan yok"
 ],
 "No free space after this partition": [
  null,
  "Bu bölümden sonra boş alan yok"
 ],
 "No keys added": [
  null,
  "Eklenen anahtarlar yok"
 ],
 "No logical volumes": [
  null,
  "Mantıksal birimler yok"
 ],
 "No media inserted": [
  null,
  "Takılı ortam yok"
 ],
 "No partitioning": [
  null,
  "Bölümlendirme yok"
 ],
 "No partitions found": [
  null,
  "Bulunan bölümler yok"
 ],
 "No physical volumes found": [
  null,
  "Bulunan fiziksel birimler yok"
 ],
 "No results found": [
  null,
  "Bulunan sonuçlar yok"
 ],
 "No snapshots found": [
  null,
  "Bulunan anlık görüntüler yok"
 ],
 "No storage found": [
  null,
  "Bulunan depolama yok"
 ],
 "No subvolumes": [
  null,
  "Alt birimler yok"
 ],
 "No such file or directory": [
  null,
  "Böyle bir dosya ya da dizin yok"
 ],
 "No system modifications": [
  null,
  "Sistem değişiklikleri yok"
 ],
 "Not a valid private key": [
  null,
  "Geçerli bir özel anahtar değil"
 ],
 "Not enough free space": [
  null,
  "Yeterli boş alan yok"
 ],
 "Not enough space": [
  null,
  "Yeterli alan yok"
 ],
 "Not enough space to grow": [
  null,
  "Büyütmek için yeterli alan yok"
 ],
 "Not found": [
  null,
  "Bulunamadı"
 ],
 "Not permitted to perform this action.": [
  null,
  "Bu eylemi gerçekleştirmeye izinli değil."
 ],
 "Not running": [
  null,
  "Çalışmıyor"
 ],
 "Not synchronized": [
  null,
  "Eşitlenmedi"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Number of bad sectors": [
  null,
  "Kötü sektör sayısı"
 ],
 "Occurrences": [
  null,
  "Oluşumlar"
 ],
 "Ok": [
  null,
  "Tamam"
 ],
 "Old passphrase": [
  null,
  "Eski parola"
 ],
 "Old password not accepted": [
  null,
  "Eski parola kabul edilmedi"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Cockpit kurulduktan sonra, \"systemctl enable --now cockpit.socket\" komutuyla etkinleştirin."
 ],
 "Only $0 of $1 are used.": [
  null,
  "Sadece $0 / $1 kullanılıyor."
 ],
 "Operation '$operation' on $target": [
  null,
  "$target üzerinde '$operation' işlemi"
 ],
 "Options": [
  null,
  "Seçenekler"
 ],
 "Other": [
  null,
  "Diğer"
 ],
 "Overprovisioning": [
  null,
  "Aşırı sağlama"
 ],
 "Overwrite": [
  null,
  "Üzerine yaz"
 ],
 "Overwrite existing data with zeros (slower)": [
  null,
  "Varolan verilerin üzerine sıfırlarla yaz (daha yavaş)"
 ],
 "PID": [
  null,
  "PID"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit çöktü"
 ],
 "Partition": [
  null,
  "Bölüm"
 ],
 "Partition of $0": [
  null,
  "$0'ın bölümü"
 ],
 "Partition size is $0. Content size is $1.": [
  null,
  "Bölüm boyutu $0. İçerik boyutu $1."
 ],
 "Partitioning": [
  null,
  "Bölümlendirme"
 ],
 "Partitions": [
  null,
  "Bölümler"
 ],
 "Partitions are not supported on this block device. If it is used as a disk for a virtual machine, the partitions must be managed by the operating system inside the virtual machine.": [
  null,
  "Bu blok cihazda bölümler desteklenmiyor. Eğer sanal bir makine için bir disk olarak kullanılıyorsa, bölümler sanal makinenin içindeki işletim sistemi tarafından yönetilmek zorundadır."
 ],
 "Passphrase": [
  null,
  "Parola"
 ],
 "Passphrase can not be empty": [
  null,
  "Parola boş olamaz"
 ],
 "Passphrase cannot be empty": [
  null,
  "Parola boş olamaz"
 ],
 "Passphrase from any other key slot": [
  null,
  "Başka bir anahtar yuvasından gelen parola"
 ],
 "Passphrase removal may prevent unlocking $0.": [
  null,
  "Parolayı kaldırma, $0 kilidini açmayı engelleyebilir."
 ],
 "Passphrases do not match": [
  null,
  "Parolalar eşleşmiyor"
 ],
 "Password": [
  null,
  "Parola"
 ],
 "Password is not acceptable": [
  null,
  "Parola kabul edilebilir değil"
 ],
 "Password is too weak": [
  null,
  "Parola çok zayıf"
 ],
 "Password not accepted": [
  null,
  "Parola kabul edilmedi"
 ],
 "Paste": [
  null,
  "Yapıştır"
 ],
 "Paste error": [
  null,
  "Yapıştırma hatası"
 ],
 "Path on server": [
  null,
  "Sunucu üzerindeki yol"
 ],
 "Path on server cannot be empty.": [
  null,
  "Sunucu üzerindeki yol boş olamaz."
 ],
 "Path on server must start with \"/\".": [
  null,
  "Sunucu üzerindeki yol \"/\" ile başlamak zorundadır."
 ],
 "Path to file": [
  null,
  "Dosyanın yolu"
 ],
 "Peripheral chassis": [
  null,
  "Çevresel donanım kasası"
 ],
 "Permanently delete $0?": [
  null,
  "$0 aygıtı kalıcı olarak silinsin mi?"
 ],
 "Permanently delete logical volume $0/$1?": [
  null,
  "Mantıksal birim $0/$1 kalıcı olarak silinsin mi?"
 ],
 "Permanently delete subvolume $0?": [
  null,
  "$0 alt birimi kalıcı olarak silinsin mi?"
 ],
 "Persistent memory has become read-only": [
  null,
  "Kalıcı bellek salt okunur hale geldi"
 ],
 "Physical": [
  null,
  "Fiziksel"
 ],
 "Physical Volumes": [
  null,
  "Fiziksel Birimler"
 ],
 "Physical volumes": [
  null,
  "Fiziksel birimler"
 ],
 "Physical volumes can not be resized here": [
  null,
  "Fiziksel birimler burada yeniden boyutlandırılamaz"
 ],
 "Pick date": [
  null,
  "Tarih seçin"
 ],
 "Pizza box": [
  null,
  "Pizza box"
 ],
 "Please unmount them first.": [
  null,
  "Lütfen önce bunların bağlantısını kaldırın."
 ],
 "Pool for thin logical volumes": [
  null,
  "İnce mantıksal birimler için havuz"
 ],
 "Pool for thinly provisioned LVM2 logical volumes": [
  null,
  "Ölçülü kaynak sağlanan LVM2 mantıksal birimleri için havuz"
 ],
 "Pool for thinly provisioned volumes": [
  null,
  "Ölçülü kaynak sağlanan birimler için havuz"
 ],
 "Pool passphrase": [
  null,
  "Havuz parolası"
 ],
 "Port": [
  null,
  "Bağlantı noktası"
 ],
 "Portable": [
  null,
  "Taşınabilir"
 ],
 "Power on hours": [
  null,
  "Saatlerde güç"
 ],
 "PowerPC PReP boot partition": [
  null,
  "PowerPC PReP önyükleme bölümü"
 ],
 "Present": [
  null,
  "Mevcut"
 ],
 "Processes using the location": [
  null,
  "Konumu kullanan işlemler"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "ssh-add aracılığıyla sorma zaman aşımına uğradı"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "ssh-keygen aracılığıyla sorma zaman aşımına uğradı"
 ],
 "Provide the passphrase for the pool on these block devices:": [
  null,
  "Şu blok aygıtlarda havuz için parolayı sağlayın:"
 ],
 "Purpose": [
  null,
  "Amaç"
 ],
 "RAID ($0)": [
  null,
  "RAID ($0)"
 ],
 "RAID 0": [
  null,
  "RAID 0"
 ],
 "RAID 0 (stripe)": [
  null,
  "RAID 0 (şeritleme)"
 ],
 "RAID 1": [
  null,
  "RAID 1"
 ],
 "RAID 1 (mirror)": [
  null,
  "RAID 1 (yansıtma)"
 ],
 "RAID 10": [
  null,
  "RAID 10"
 ],
 "RAID 10 (stripe of mirrors)": [
  null,
  "RAID 10 (yansıtmaları şeritleme)"
 ],
 "RAID 4": [
  null,
  "RAID 4"
 ],
 "RAID 4 (dedicated parity)": [
  null,
  "RAID 4 (adanmış eşlik)"
 ],
 "RAID 5": [
  null,
  "RAID 5"
 ],
 "RAID 5 (distributed parity)": [
  null,
  "RAID 5 (dağıtılmış eşlik)"
 ],
 "RAID 6": [
  null,
  "RAID 6"
 ],
 "RAID 6 (double distributed parity)": [
  null,
  "RAID 6 (çift dağıtılmış eşlik)"
 ],
 "RAID chassis": [
  null,
  "RAID kasası"
 ],
 "RAID level": [
  null,
  "RAID seviyesi"
 ],
 "RAID10 needs an even number of physical volumes": [
  null,
  "RAID10 çift sayıda fiziksel birime ihtiyaç duyar"
 ],
 "Rack mount chassis": [
  null,
  "Raf montajlı kasa"
 ],
 "Reading": [
  null,
  "Okunuyor"
 ],
 "Reboot": [
  null,
  "Yeniden başlat"
 ],
 "Recovering": [
  null,
  "Kurtarılıyor"
 ],
 "Recovering MDRAID device $target": [
  null,
  "MDRAID aygıtı $target kurtarılıyor"
 ],
 "Regenerating initrd": [
  null,
  "initrd yeniden oluşturuluyor"
 ],
 "Related processes and services will be forcefully stopped.": [
  null,
  "İlgili işlemler ve hizmetler zorla durdurulacaktır."
 ],
 "Related processes will be forcefully stopped.": [
  null,
  "İlgili işlemler zorla durdurulacaktır."
 ],
 "Related services will be forcefully stopped.": [
  null,
  "İlgili hizmetler zorla durdurulacaktır."
 ],
 "Removals:": [
  null,
  "Kaldırılanlar:"
 ],
 "Remove": [
  null,
  "Kaldır"
 ],
 "Remove $0?": [
  null,
  "$0 kaldırılsın mı?"
 ],
 "Remove Tang keyserver?": [
  null,
  "Tang anahtar sunucusu kaldırılsın mı?"
 ],
 "Remove device": [
  null,
  "Aygıtı kaldır"
 ],
 "Remove missing physical volumes?": [
  null,
  "Eksik fiziksel birimler kaldırılsın mı?"
 ],
 "Remove passphrase in key slot $0?": [
  null,
  "$0 anahtar yuvası içindeki parola kaldırılsın mı?"
 ],
 "Remove passphrase?": [
  null,
  "Parola kaldırılsın mı?"
 ],
 "Removing $0": [
  null,
  "$0 kaldırılıyor"
 ],
 "Removing $target from MDRAID device": [
  null,
  "MDRAID aygıtından $target kaldırılıyor"
 ],
 "Removing a passphrase without confirmation of another passphrase may prevent unlocking or key management, if other passphrases are forgotten or lost.": [
  null,
  "Başka bir parolayı onaylamadan bir parolayı kaldırmak, diğer parolalar unutulur veya kaybolursa, kilit açma veya anahtar yönetimini önleyebilir."
 ],
 "Removing physical volume from $target": [
  null,
  "$target aygıtından fiziksel birim kaldırılıyor"
 ],
 "Rename": [
  null,
  "Yeniden adlandır"
 ],
 "Rename Stratis pool": [
  null,
  "Stratis havuzunu yeniden adlandır"
 ],
 "Rename filesystem": [
  null,
  "Dosya sistemini yeniden adlandır"
 ],
 "Rename logical volume": [
  null,
  "Mantıksal birimi yeniden adlandır"
 ],
 "Rename volume group": [
  null,
  "Birim grubunu yeniden adlandır"
 ],
 "Renaming $target": [
  null,
  "$target yeniden adlandırılıyor"
 ],
 "Repair": [
  null,
  "Onar"
 ],
 "Repair logical volume $0": [
  null,
  "$0 mantıksal birimini onar"
 ],
 "Repairing $target": [
  null,
  "$target onarılıyor"
 ],
 "Repeat passphrase": [
  null,
  "Parolayı tekrarla"
 ],
 "Resizing $target": [
  null,
  "$target yeniden boyutlandırılıyor"
 ],
 "Resizing an encrypted filesystem requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Şifrelenmiş bir dosya sistemini yeniden boyutlandırmak, diskin kilidinin açılmasını gerektirir. Lütfen şu anki bir disk parolasını girin."
 ],
 "Reuse existing encryption": [
  null,
  "Varolan şifrelemeyi yeniden kullan"
 ],
 "Reuse existing encryption ($0)": [
  null,
  "Varolan şifrelemeyi yeniden kullan ($0)"
 ],
 "Row expansion": [
  null,
  "Satır genişletme"
 ],
 "Row select": [
  null,
  "Satır seçimi"
 ],
 "Run extended test": [
  null,
  "Genişletilmiş deneme çalıştır"
 ],
 "Run short test": [
  null,
  "Kısa deneme çalıştır"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Bu komutu güvenilir bir ağ üzerinden veya fiziksel olarak uzaktaki makinede çalıştırın:"
 ],
 "Running": [
  null,
  "Çalışıyor"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SHA-1": [
  null,
  "SHA-1"
 ],
 "SHA-256": [
  null,
  "SHA-256"
 ],
 "SMART self-test of $target": [
  null,
  "$target aygıtının SMART kendi kendini denemesi"
 ],
 "SSH key": [
  null,
  "SSH anahtarı"
 ],
 "SSH key login": [
  null,
  "SSH anahtarı oturum açma"
 ],
 "Save": [
  null,
  "Kaydet"
 ],
 "Save space by compressing individual blocks with LZ4": [
  null,
  "LZ4 ile ayrı blokları sıkıştırarak alandan tasarruf edin"
 ],
 "Save space by storing identical data blocks just once": [
  null,
  "Aynı veri bloklarını sadece bir kez depolayarak alandan tasarruf edin"
 ],
 "Saving a new passphrase requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Yeni bir parola kaydetmek, diskin kilidinin açılmasını gerektirir. Lütfen şu anki bir disk parolasını girin."
 ],
 "Sealed-case PC": [
  null,
  "Mühürlü Kasa PC"
 ],
 "Securely erasing $target": [
  null,
  "$target güvenli bir şekilde siliniyor"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Güvenlik Gelişmiş Linux yapılandırması ve sorun giderme"
 ],
 "Select an option": [
  null,
  "Bir seçenek seçin"
 ],
 "Select the physical volumes that should be used to repair the logical volume. At least $0 are needed.": [
  null,
  "Mantıksal birimi onarmak için kullanılması gereken fiziksel birimleri seçin. En az $0 ihtiyaç vardır."
 ],
 "Self-test status": [
  null,
  "Kendi kendine deneme durumu"
 ],
 "Serial number": [
  null,
  "Seri numarası"
 ],
 "Server": [
  null,
  "Sunucu"
 ],
 "Server address": [
  null,
  "Sunucu adresi"
 ],
 "Server address cannot be empty.": [
  null,
  "Sunucu adresi boş olamaz."
 ],
 "Server cannot be empty.": [
  null,
  "Sunucu boş olamaz."
 ],
 "Server has closed the connection.": [
  null,
  "Sunucu bağlantıyı kapattı."
 ],
 "Service": [
  null,
  "Hizmet"
 ],
 "Services using the location": [
  null,
  "Konumu kullanan hizmetler"
 ],
 "Set": [
  null,
  "Ayarla"
 ],
 "Set initial size": [
  null,
  "Başlangıç boyutunu ayarla"
 ],
 "Set limit of virtual filesystem size": [
  null,
  "Sanal dosya sistemi boyutunun sınırını ayarla"
 ],
 "Set partition type of $0": [
  null,
  "Bölüm türünü $0 olarak ayarla"
 ],
 "Set time": [
  null,
  "Saati ayarla"
 ],
 "Setting up loop device $target": [
  null,
  "Döngü aygıtı $target ayarlanıyor"
 ],
 "Shell script": [
  null,
  "Kabuk betiği"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show all $0 rows": [
  null,
  "Tüm $0 satırı göster"
 ],
 "Show confirmation password": [
  null,
  "Onay parolasını göster"
 ],
 "Show password": [
  null,
  "Parolayı göster"
 ],
 "Shrink": [
  null,
  "Küçült"
 ],
 "Shrink logical volume": [
  null,
  "Mantıksal birimi küçült"
 ],
 "Shrink partition": [
  null,
  "Bölümü küçült"
 ],
 "Shrink volume": [
  null,
  "Birimi küçült"
 ],
 "Shut down": [
  null,
  "Kapat"
 ],
 "Single rank": [
  null,
  "Tek sıra"
 ],
 "Size": [
  null,
  "Boyut"
 ],
 "Size cannot be negative": [
  null,
  "Boyut sıfırdan küçük olamaz"
 ],
 "Size cannot be zero": [
  null,
  "Boyut sıfır olamaz"
 ],
 "Size is too large": [
  null,
  "Boyut çok büyük"
 ],
 "Size must be a number": [
  null,
  "Boyut bir sayı olmak zorundadır"
 ],
 "Size must be at least $0": [
  null,
  "Boyut en az $0 olmak zorundadır"
 ],
 "Slot $0": [
  null,
  "Yuva $0"
 ],
 "Snapshot": [
  null,
  "Anlık görüntü"
 ],
 "Snapshot origin": [
  null,
  "Anlık görüntü kaynağı"
 ],
 "Snapshots": [
  null,
  "Anlık görüntüler"
 ],
 "Solid State Drive": [
  null,
  "Katı Hal Sürücüsü"
 ],
 "Some block devices of this pool have grown in size after the pool was created. The pool can be safely grown to use the newly available space.": [
  null,
  "Bu havuzun bazı blok aygıtları, havuz oluşturulduktan sonra boyut olarak büyüdü. Havuz, yeni mevcut alanı kullanmak üzere güvenli bir şekilde büyütülebilir."
 ],
 "Sorry": [
  null,
  "Üzgünüz"
 ],
 "Space-saving computer": [
  null,
  "Yerden kazandıran bilgisayar"
 ],
 "Spare": [
  null,
  "Yedek"
 ],
 "Spare capacity is below the threshold": [
  null,
  "Yedek kapasite eşiğin altında"
 ],
 "Specific time": [
  null,
  "Belirli bir zaman"
 ],
 "Start": [
  null,
  "Başlat"
 ],
 "Start multipath": [
  null,
  "Multipath hizmetini başlat"
 ],
 "Started": [
  null,
  "Başlatıldı"
 ],
 "Starting MDRAID device $target": [
  null,
  "MDRAID aygıtı $target başlatılıyor"
 ],
 "Starting swapspace $target": [
  null,
  "Takas alanı $target başlatılıyor"
 ],
 "State": [
  null,
  "Durum"
 ],
 "Stick PC": [
  null,
  "Çubuk PC"
 ],
 "Stop": [
  null,
  "Durdur"
 ],
 "Stop and remove": [
  null,
  "Durdur ve kaldır"
 ],
 "Stop and unmount": [
  null,
  "Durdur ve bağlantısını kaldır"
 ],
 "Stop device": [
  null,
  "Aygıtı durdur"
 ],
 "Stopping MDRAID device $target": [
  null,
  "MDRAID aygıtı $target durduruluyor"
 ],
 "Stopping swapspace $target": [
  null,
  "Takas alanı $target durduruluyor"
 ],
 "Storage": [
  null,
  "Depolama"
 ],
 "Storage can not be managed on this system.": [
  null,
  "Bu sistemde depolama yönetilemez."
 ],
 "Storage logs": [
  null,
  "Depolama günlükleri"
 ],
 "Store passphrase": [
  null,
  "Parolayı sakla"
 ],
 "Stored passphrase": [
  null,
  "Saklanmış parola"
 ],
 "Stratis block device": [
  null,
  "Stratis blok aygıtı"
 ],
 "Stratis block devices": [
  null,
  "Stratis blok aygıtları"
 ],
 "Stratis blockdevs can not be made smaller": [
  null,
  "Stratis blockdev'leri küçültülemez"
 ],
 "Stratis filesystem": [
  null,
  "Stratis dosya sistemi"
 ],
 "Stratis filesystems": [
  null,
  "Stratis dosya sistemleri"
 ],
 "Stratis filesystems pool": [
  null,
  "Stratis dosya sistemleri havuzu"
 ],
 "Stratis pool": [
  null,
  "Stratis havuzu"
 ],
 "Striped (RAID 0)": [
  null,
  "Şeritlenmiş (RAID 0)"
 ],
 "Striped and mirrored (RAID 10)": [
  null,
  "Şeritlenmiş ve yansıtılmış (RAID 10)"
 ],
 "Stripes": [
  null,
  "Şeritlemeler"
 ],
 "Strong password": [
  null,
  "Güçlü parola"
 ],
 "Sub-Chassis": [
  null,
  "Alt Kasa"
 ],
 "Sub-Notebook": [
  null,
  "Alt Dizüstü"
 ],
 "Successful": [
  null,
  "Başarılı"
 ],
 "Successfully copied to clipboard!": [
  null,
  "Başarılı olarak panoya kopyalandı!"
 ],
 "Swap": [
  null,
  "Takas"
 ],
 "Swap can not be resized here": [
  null,
  "Takas burada yeniden boyutlandırılamaz"
 ],
 "Synchronized": [
  null,
  "Eşitlendi"
 ],
 "Synchronized with $0": [
  null,
  "$0 ile eşitlendi"
 ],
 "Synchronizing": [
  null,
  "Eşitleniyor"
 ],
 "Synchronizing MDRAID device $target": [
  null,
  "MDRAID aygıtı $target eşitleniyor"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Tang keyserver": [
  null,
  "Tang anahtar sunucusu"
 ],
 "Target": [
  null,
  "Hedef"
 ],
 "Temperature outside of recommended thresholds": [
  null,
  "Önerilen eşiklerin dışındaki sıcaklık"
 ],
 "The $0 package is not available from any repository.": [
  null,
  "$0 paketi hiçbir depoda yok."
 ],
 "The $0 package must be installed to create Stratis pools.": [
  null,
  "Stratis havuzları oluşturmak için $0 paketi kurulmak zorundadır."
 ],
 "The $0 package must be installed.": [
  null,
  "$0 paketi kurulmak zorundadır."
 ],
 "The $0 package will be installed to create VDO devices.": [
  null,
  "VDO aygıtları oluşturmak için $0 paketi kurulacak."
 ],
 "The MDRAID device is in a degraded state": [
  null,
  "MDRAID aygıtı bozulmuş bir durumda"
 ],
 "The MDRAID device must be running": [
  null,
  "MDRAID aygıtı çalışıyor olmak zorundadır"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "$2 üzerindeki $1 kullanıcısının $0 SSH anahtarı, $5 üzerindeki $4 kullanıcısının $3 dosyasına eklenecektir."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "$0 SSH anahtarı, oturumun geri kalanı için kullanılabilir olacak ve diğer anamakinelerde oturum açmak için de kullanılabilecektir."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "$0 üzerinde oturum açmak için kullanılan SSH anahtarı korumalı ve anamakine bir parola ile oturum açmaya izin vermiyor. Lütfen $1 konumundaki anahtarın parolasını sağlayın."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "$0 üzerinde oturum açmak için kullanılan SSH anahtarı korumalı. Oturum açma parolanızla veya $1 konumundaki anahtarın parolasını sağlayarak oturum açabilirsiniz."
 ],
 "The creation of this VDO device did not finish and the device can't be used.": [
  null,
  "Bu VDO aygıtının oluşturulması tamamlanmadı ve aygıt kullanılamaz."
 ],
 "The currently logged in user is not permitted to see information about keys.": [
  null,
  "Şu anda oturum açmış olan kullanıcının anahtarlar hakkındaki bilgileri görmesine izin verilmiyor."
 ],
 "The disk needs to be unlocked before formatting. Please provide an existing passphrase.": [
  null,
  "Biçimlendirmeden önce diskin kilidinin açılması gerekir. Lütfen varolan bir parola verin."
 ],
 "The filesystem has no assigned mount point.": [
  null,
  "Dosya sisteminin atanmış bir bağlama noktası yok."
 ],
 "The filesystem has no permanent mount point.": [
  null,
  "Dosya sisteminin kalıcı bir bağlama noktası yok."
 ],
 "The filesystem is configured to be automatically mounted on boot but its encryption container will not be unlocked at that time.": [
  null,
  "Dosya sistemi önyüklemede otomatik olarak bağlanacak şekilde yapılandırıldı ancak şifreleme kapsayıcısının kilidi o anda açılmayacaktır."
 ],
 "The filesystem is currently mounted but will not be mounted after the next boot.": [
  null,
  "Dosya sistemi şu anda bağlanmış durumda ancak bir sonraki önyüklemeden sonra bağlanmayacak."
 ],
 "The filesystem is currently mounted on $0 but will be mounted on $1 on the next boot.": [
  null,
  "Dosya sistemi şu anda $0 noktasında bağlanmış durumda ancak bir sonraki önyüklemede $1 noktasında bağlanacak."
 ],
 "The filesystem is currently mounted on $0 but will not be mounted after the next boot.": [
  null,
  "Dosya sistemi şu anda $0 noktasında bağlanmış durumda ancak bir sonraki önyüklemeden sonra bağlanmayacak."
 ],
 "The filesystem is currently not mounted but will be mounted on the next boot.": [
  null,
  "Dosya sistemi şu anda bağlanmış değil ancak bir sonraki önyüklemede bağlanacak."
 ],
 "The filesystem is not mounted.": [
  null,
  "Dosya sistemi bağlanmadı."
 ],
 "The filesystem will be unlocked and mounted on the next boot. This might require inputting a passphrase.": [
  null,
  "Dosya sisteminin kilidi açılacak ve bir sonraki önyüklemeye bağlanacaktır. Bu bir parola girmeyi gerektirebilir."
 ],
 "The fingerprint should match:": [
  null,
  "Parmak izi eşleşmeli:"
 ],
 "The initrd must be regenerated.": [
  null,
  "initrd yeniden oluşturulmak zorundadır."
 ],
 "The key password can not be empty": [
  null,
  "Anahtar parolası boş olamaz"
 ],
 "The key passwords do not match": [
  null,
  "Anahtar parolaları eşleşmiyor"
 ],
 "The last key slot can not be removed": [
  null,
  "Son anahtar yuvası kaldırılamaz"
 ],
 "The last mounted subvolume can not be deleted": [
  null,
  "Son bağlanan alt birim silinemez"
 ],
 "The listed processes and services will be forcefully stopped.": [
  null,
  "Listelenen işlemler ve hizmetler zorla durdurulacaktır."
 ],
 "The listed processes will be forcefully stopped.": [
  null,
  "Listelenen işlemler zorla durdurulacaktır."
 ],
 "The listed services will be forcefully stopped.": [
  null,
  "Listelenen hizmetler zorla durdurulacaktır."
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Oturum açmış kullanıcının sistem değişikliklerini görüntülemesine izin verilmiyor"
 ],
 "The mount point $0 is in use by these processes:": [
  null,
  "$0 bağlama noktası şu işlemler tarafından kullanılmakta:"
 ],
 "The mount point $0 is in use by these services:": [
  null,
  "$0 bağlama noktası şu hizmetler tarafından kullanılmakta:"
 ],
 "The password can not be empty": [
  null,
  "Parola boş olamaz"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Ortaya çıkan parmak izinin, e-posta dahil olmak üzere herkese açık yöntemlerle paylaşılması uygundur."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Ortaya çıkan parmak izi, e-posta dahil ortak yöntemler aracılığıyla paylaşılabilir. Eğer başka birinden doğrulamayı sizin için yapmasını istiyorsanız, sonuçları herhangi bir yöntemi kullanarak gönderebilirler."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Sunucu, desteklenen herhangi bir yöntemi kullanarak kimlik doğrulamayı reddetti."
 ],
 "The system does not currently support unlocking a filesystem with a Tang keyserver during boot.": [
  null,
  "Sistem şu anda önyükleme sırasında bir dosya sisteminin bir Tang anahtar sunucusuyla kilidinin açılmasını desteklemiyor."
 ],
 "The system does not currently support unlocking the root filesystem with a Tang keyserver.": [
  null,
  "Sistem şu anda bir Tang anahtar sunucusuyla kök dosya sisteminin kilidini açmayı desteklemiyor."
 ],
 "There are devices with multiple paths on the system, but the multipath service is not running.": [
  null,
  "Sistemde birden çok yola sahip aygıtlar var, ancak multipath hizmeti çalışmıyor."
 ],
 "There is not enough space available that could be used for a repair. At least $0 are needed on physical volumes that are not already used for this logical volume.": [
  null,
  "Onarım için kullanılabilecek yeterli alan yok. Bu mantıksal birim için zaten kullanılmayan fiziksel birimlerde en az $0 gereklidir."
 ],
 "These additional steps are necessary:": [
  null,
  "Şu ek adımlar gereklidir:"
 ],
 "These changes will be made:": [
  null,
  "Şu değişiklikler yapılacaktır:"
 ],
 "Thin logical volume": [
  null,
  "İnce mantıksal birim"
 ],
 "Thinly provisioned LVM2 logical volumes": [
  null,
  "Ölçülü kaynak sağlanan LVM2 mantıksal birimleri"
 ],
 "This MDRAID device has no write-intent bitmap. Such a bitmap can reduce synchronization times significantly.": [
  null,
  "Bu MDRAID aygıtının yazma amaçlı bit eşlemi yoktur. Böyle bir bit eşlem, eşitleme sürelerini önemli ölçüde azaltabilir."
 ],
 "This NFS mount is in use and only its options can be changed.": [
  null,
  "Bu NFS bağlama noktası kullanımda ve sadece seçenekleri değiştirilebilir."
 ],
 "This VDO device does not use all of its backing device.": [
  null,
  "Bu VDO aygıtı, yedek aygıtlarının tümünü kullanmıyor."
 ],
 "This device can not be used for the installation target.": [
  null,
  "Bu aygıt kurulum hedefi için kullanılamaz."
 ],
 "This device is currently in use.": [
  null,
  "Bu aygıt şu anda kullanımda."
 ],
 "This keyserver is the only way to unlock the pool and can not be removed.": [
  null,
  "Bu anahtar sunucusu, havuzun kilidini açmanın tek yoludur ve kaldırılamaz."
 ],
 "This logical volume has lost some of its physical volumes and can no longer be used. You need to delete it and create a new one to take its place.": [
  null,
  "Bu mantıksal birim, fiziksel birimlerinin bir kısmını kaybetmiş ve artık kullanılamaz. Bunu silip yerine yenisini oluşturmanız gerekiyor."
 ],
 "This logical volume has lost some of its physical volumes but has not lost any data yet. You should repair it to restore its original redundancy.": [
  null,
  "Bu mantıksal birim, fiziksel birimlerinin bir kısmını kaybetmiş ancak henüz herhangi bir veri kaybetmemiş. Orijinal yedekliliğini geri yüklemek için onarmalısınız."
 ],
 "This logical volume has lost some of its physical volumes but might not have lost any data yet. You might be able to repair it.": [
  null,
  "Bu mantıksal birim, fiziksel birimlerinin bir kısmını kaybetmiş ancak henüz herhangi bir veri kaybetmemiş olabilir. Belki onarabilirsiniz."
 ],
 "This logical volume is not completely used by its content.": [
  null,
  "Bu mantıksal birim, içeriği tarafından tamamen kullanılmıyor."
 ],
 "This partition is not completely used by its content.": [
  null,
  "Bu bölüm, içeriği tarafından tamamen kullanılmıyor."
 ],
 "This passphrase is the only way to unlock the pool and can not be removed.": [
  null,
  "Bu parola, havuzun kilidini açmanın tek yoludur ve kaldırılamaz."
 ],
 "This pool does not use all the space on its block devices.": [
  null,
  "Bu havuz, blok aygıtlardaki alanın tümünü kullanmaz."
 ],
 "This pool is in a degraded state.": [
  null,
  "Bu havuz bozulmuş bir durumda."
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "Bu araç, SELinux ilkesini yapılandırır ve ilke ihlallerinin anlaşılmasına ve çözülmesine yardımcı olabilir."
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "Bu araç, sistemi çekirdek çökme dökümlerini yazmak için yapılandırır. \"Yerel\" (disk), \"ssh\" ve \"nfs\" döküm hedeflerini destekler."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "Bu araç, çalışan sistemden bir yapılandırma ve tanılama bilgileri arşivi oluşturur. Arşiv, kayıt veya izleme amacıyla yerel veya merkezi olarak depolanabilir veya teknik hata bulma ve hata ayıklamaya yardımcı olması için teknik destek temsilcilerine, geliştiricilere veya sistem yöneticilerine gönderilebilir."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "Bu araç, dosya sistemleri, LVM2 birim grupları ve NFS bağlamaları gibi yerel depolamayı yönetir."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "Bu araç, NetworkManager ve Firewalld kullanarak birleştirmeler, köprüler, takımlar, VLAN'lar ve güvenlik duvarları gibi ağları yönetir. NetworkManager, Ubuntu'nun varsayılan systemd-networkd ve Debian'ın ifupdown betikleriyle uyumsuzdur."
 ],
 "This volume group contains the root filesystem. Renaming it might require further changes to the bootloader configuration or kernel command line.": [
  null,
  "Bu birim grubu kök dosya sistemini içerir. Yeniden adlandırma bootloader yapılandırmasında veya çekirdek komut satırında daha fazla değişiklik gerektirebilir."
 ],
 "This volume group is missing some physical volumes.": [
  null,
  "Bu birim grubunda bazı fiziksel birimler eksik."
 ],
 "Tier": [
  null,
  "Katman"
 ],
 "Time zone": [
  null,
  "Saat dilimi"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Bağlantınızın kötü niyetli bir üçüncü tarafça engellenmediğinden emin olmak için lütfen anamakine anahtar parmak izini doğrulayın:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Bir parmak izini doğrulamak için makinede fiziksel olarak bulunurken veya güvenilir bir ağ aracılığıyla $0 üzerinde aşağıdakileri çalıştırın:"
 ],
 "Toggle date picker": [
  null,
  "Tarihi seçiciyi aç/kapat"
 ],
 "Too much data": [
  null,
  "Çok fazla veri"
 ],
 "Total size: $0": [
  null,
  "Toplam boyut: $0"
 ],
 "Tower": [
  null,
  "Tower"
 ],
 "Trust and add host": [
  null,
  "Anamakineye güven ve ekle"
 ],
 "Trust key": [
  null,
  "Güvenilen anahtar"
 ],
 "Trying to synchronize with $0": [
  null,
  "$0 ile eşitlemeye çalışılıyor"
 ],
 "Type": [
  null,
  "Tür"
 ],
 "Type can only contain the characters 0 to 9, A to F, and \"-\".": [
  null,
  "Tür yalnızca 0 - 9, A - F ve \"-\" karakterlerini içerebilir."
 ],
 "Type must be of the form NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN.": [
  null,
  "Tür NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN biçiminde olmak zorundadır."
 ],
 "Type must contain exactly two hexadecimal characters (0 to 9, A to F).": [
  null,
  "Tür tam olarak iki onaltılık karakter içermek zorundadır (0 - 9, A - F)."
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "SSH anahtar kimlik doğrulaması kullanılarak $0 için oturum açılamıyor. Lütfen parolayı girin."
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "$0 üzerinde oturum açılamıyor. Anamakine, parola ile oturum açmayı veya SSH anahtarlarınızdan hiçbirini kabul etmiyor."
 ],
 "Unable to reach server": [
  null,
  "Sunucuya ulaşılamıyor"
 ],
 "Unable to remove mount": [
  null,
  "Bağlama noktası kaldırılamıyor"
 ],
 "Unable to repair logical volume $0": [
  null,
  "$0 mantıksal birimi onarılamıyor"
 ],
 "Unable to unmount filesystem": [
  null,
  "Dosya sisteminin bağlantısı kaldırılamıyor"
 ],
 "Unexpected PackageKit error during installation of $0: $1": [
  null,
  "$0 kurulumu sırasında beklenmeyen PackageKit hatası: $1"
 ],
 "Unexpected partitions": [
  null,
  "Beklenmedik bölümler"
 ],
 "Unformatted data": [
  null,
  "Biçimlendirilmemiş veriler"
 ],
 "Unknown": [
  null,
  "Bilinmiyor"
 ],
 "Unknown ($0)": [
  null,
  "Bilinmeyen ($0)"
 ],
 "Unknown host name": [
  null,
  "Bilinmeyen anamakine adı"
 ],
 "Unknown host: $0": [
  null,
  "Bilinmeyen anamakine: $0"
 ],
 "Unknown type": [
  null,
  "Bilinmeyen tür"
 ],
 "Unlock": [
  null,
  "Kilidi aç"
 ],
 "Unlock automatically on boot": [
  null,
  "Önyüklemede kilidi otomatik olarak aç"
 ],
 "Unlock before resizing": [
  null,
  "Yeniden boyutlandırmadan önce kilidini aç"
 ],
 "Unlock encrypted Stratis pool": [
  null,
  "Şifrelenmiş Stratis havuzu kilidini aç"
 ],
 "Unlocking $target": [
  null,
  "$target kilidi açılıyor"
 ],
 "Unlocking disk": [
  null,
  "Disk kilidi açılıyor"
 ],
 "Unmount": [
  null,
  "Bağlantıyı kaldır"
 ],
 "Unmount filesystem $0": [
  null,
  "$0 dosya sistemi bağlantısını kaldır"
 ],
 "Unmount now": [
  null,
  "Şimdi bağlantıyı kaldır"
 ],
 "Unmounting $target": [
  null,
  "$target bağlantısı kaldırılıyor"
 ],
 "Unrecognized data": [
  null,
  "Tanınmayan veri"
 ],
 "Unrecognized data can not be made smaller here": [
  null,
  "Tanınmayan veriler burada küçültülemez"
 ],
 "Unrecognized data can not be made smaller here.": [
  null,
  "Tanınmayan veriler burada küçültülemez."
 ],
 "Unsupported logical volume": [
  null,
  "Desteklenmeyen mantıksal birim"
 ],
 "Untrusted host": [
  null,
  "Güvenilmeyen anamakine"
 ],
 "Usage": [
  null,
  "Kullanım"
 ],
 "Usage of $0": [
  null,
  "$0 kullanımı"
 ],
 "Use": [
  null,
  "Kullan"
 ],
 "Use $0": [
  null,
  "$0 kullan"
 ],
 "Use compression": [
  null,
  "Sıkıştırma kullan"
 ],
 "Use deduplication": [
  null,
  "Tekilleştirme kullan"
 ],
 "Used": [
  null,
  "Kullanılan"
 ],
 "Useful for mounts that are optional or need interaction (such as passphrases)": [
  null,
  "İsteğe bağlı olan veya etkileşim gerektiren bağlamalar için kullanışlıdır (parolalar gibi)"
 ],
 "User": [
  null,
  "Kullanıcı"
 ],
 "Username": [
  null,
  "Kullanıcı adı"
 ],
 "VDO backing devices can not be made smaller": [
  null,
  "VDO yedek aygıtları küçültülemez"
 ],
 "VDO device $0": [
  null,
  "VDO aygıtı $0"
 ],
 "VDO filesystem volume (compression/deduplication)": [
  null,
  "VDO dosya sistemi birimi (sıkıştırma/kopyaları kaldırma)"
 ],
 "Vendor": [
  null,
  "Satıcı"
 ],
 "Verify fingerprint": [
  null,
  "Parmak izini doğrula"
 ],
 "Verify key": [
  null,
  "Anahtarı doğrula"
 ],
 "Very securely erasing $target": [
  null,
  "$target çok güvenli bir şekilde siliniyor"
 ],
 "View all logs": [
  null,
  "Tüm günlükleri görüntüle"
 ],
 "View automation script": [
  null,
  "Otomatikleştirme betiğini görüntüle"
 ],
 "View logs": [
  null,
  "Günlükleri görüntüle"
 ],
 "Virtual filesystem sizes are larger than the pool. Overprovisioning can not be disabled.": [
  null,
  "Sanal dosya sistemi boyutları havuzdan daha büyük. Aşırı sağlama etkisizleştirildi."
 ],
 "Virtual size": [
  null,
  "Sanal boyut"
 ],
 "Virtual size limit": [
  null,
  "Sanal boyut sınırı"
 ],
 "Visit firewall": [
  null,
  "Güvenlik duvarını ziyaret et"
 ],
 "Volatile memory backup failed": [
  null,
  "Değişken belleği yedekleme başarısız oldu"
 ],
 "Volume group": [
  null,
  "Birim grubu"
 ],
 "Volume group is missing physical volumes": [
  null,
  "Birim grubunda fiziksel birimler eksik"
 ],
 "Volume size is $0. Content size is $1.": [
  null,
  "Birim boyutu $0. İçerik boyutu $1."
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Diğer yazılım yönetimi işlemlerinin bitmesi bekleniyor"
 ],
 "Weak password": [
  null,
  "Zayıf parola"
 ],
 "Web Console for Linux servers": [
  null,
  "Linux sunucuları için Web Konsolu"
 ],
 "World wide name": [
  null,
  "Dünya çapında ad"
 ],
 "Write-mostly": [
  null,
  "Çoğunlukla yazma"
 ],
 "Writing": [
  null,
  "Yazma"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "İlk kez $0 için bağlanıyorsunuz."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Tarayıcınız, bağlam menüsünden yapıştırmaya izin vermiyor. Shift+Insert kullanabilirsiniz."
 ],
 "Your session has been terminated.": [
  null,
  "Oturumunuz sonlandırıldı."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Oturumunuzun süresi doldu. Lütfen tekrar oturum açın."
 ],
 "Zone": [
  null,
  "Bölge"
 ],
 "[binary data]": [
  null,
  "[ikili veri]"
 ],
 "[no data]": [
  null,
  "[veri yok]"
 ],
 "after network": [
  null,
  "ağdan sonra"
 ],
 "backing device for VDO device": [
  null,
  "VDO aygıtı için aygıt yedekleniyor"
 ],
 "btrfs device": [
  null,
  "btrfs aygıtı"
 ],
 "btrfs devices": [
  null,
  "btrfs aygıtı"
 ],
 "btrfs filesystem": [
  null,
  "btrfs dosya sistemi"
 ],
 "btrfs subvolume": [
  null,
  "btrfs alt birimi"
 ],
 "btrfs subvolume $0 of $1": [
  null,
  "$0 / $1 btrfs alt birimi"
 ],
 "btrfs subvolumes": [
  null,
  "btrfs alt birimi"
 ],
 "btrfs volume": [
  null,
  "btrfs birimi"
 ],
 "cache": [
  null,
  "önbellek"
 ],
 "data": [
  null,
  "veri"
 ],
 "deactivate": [
  null,
  "devre dışı bırak"
 ],
 "delete": [
  null,
  "sil"
 ],
 "device of btrfs volume": [
  null,
  "btrfs birimi aygıtı"
 ],
 "edit": [
  null,
  "düzenle"
 ],
 "encrypted": [
  null,
  "şifrelenmiş"
 ],
 "format": [
  null,
  "biçim"
 ],
 "grow": [
  null,
  "büyüt"
 ],
 "iSCSI Drive": [
  null,
  "iSCSI Sürücüsü"
 ],
 "iSCSI drives": [
  null,
  "iSCSI sürücüleri"
 ],
 "iSCSI portal": [
  null,
  "iSCSI portalı"
 ],
 "ignore failure": [
  null,
  "hatayı yoksay"
 ],
 "in less than a minute": [
  null,
  "bir dakikadan az süre"
 ],
 "initialize": [
  null,
  "başlat"
 ],
 "less than a minute ago": [
  null,
  "bir dakikadan az bir süre önce"
 ],
 "lock": [
  null,
  "kilitle"
 ],
 "member of MDRAID device": [
  null,
  "MDRAID aygıtı üyesi"
 ],
 "member of Stratis pool": [
  null,
  "Stratis havuzu üyesi"
 ],
 "mount": [
  null,
  "bağla"
 ],
 "never mount at boot": [
  null,
  "önyüklemede asla bağlama"
 ],
 "none": [
  null,
  "yok"
 ],
 "password quality": [
  null,
  "parola kalitesi"
 ],
 "physical volume of LVM2 volume group": [
  null,
  "LVM2 birim grubunun fiziksel birimi"
 ],
 "read only": [
  null,
  "salt okunur"
 ],
 "remove from LVM2": [
  null,
  "LVM2'den kaldır"
 ],
 "remove from MDRAID": [
  null,
  "MDRAID'den kaldır"
 ],
 "remove from btrfs volume": [
  null,
  "btrfs biriminden kaldır"
 ],
 "show less": [
  null,
  "daha az göster"
 ],
 "show more": [
  null,
  "daha fazla göster"
 ],
 "shrink": [
  null,
  "küçült"
 ],
 "snapshot": [
  null,
  "anlık görüntü"
 ],
 "stop": [
  null,
  "durdur"
 ],
 "stop boot on failure": [
  null,
  "hatada önyüklemeyi durdur"
 ],
 "stopped": [
  null,
  "durduruldu"
 ],
 "unknown target": [
  null,
  "bilinmeyen hedef"
 ],
 "unmount": [
  null,
  "bağlantıyı kaldır"
 ],
 "unpartitioned space on $0": [
  null,
  "$0 üzerinde bölümlendirilmemiş alan"
 ],
 "using key description $0": [
  null,
  "kullanılan anahtar açıklaması $0"
 ],
 "yes": [
  null,
  "evet"
 ],
 "format-bytes\u0004bytes": [
  null,
  "bayt"
 ]
});
