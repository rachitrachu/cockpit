cockpit.locale({
 "": {
  "plural-forms": (n) => n==0 ? 0 : n==1 ? 1 : n==2 ? 2 : n%100>=3 && n%100<=10 ? 3 : n%100>=11 ? 4 : 5,
  "language": "ar",
  "language-direction": "rtl"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 can not be made larger": [
  null,
  "$0 لا يمكن تكبيره"
 ],
 "$0 can not be made smaller": [
  null,
  "$0 لا يمكن تصغيره"
 ],
 "$0 can not be resized": [
  null,
  "$0 لا يمكن تغيير حجمه"
 ],
 "$0 can not be resized here": [
  null,
  "$0 لا يمكن تغيير حجمه هنا"
 ],
 "$0 chunk size": [
  null,
  "$0 حجم الكتلة"
 ],
 "$0 data + $1 overhead used of $2 ($3)": [
  null,
  "تم استخدام ‎$0 بيانات + ‎$1 كتكلفة إضافية من أصل ‎$2 (‎$3)"
 ],
 "$0 day": [
  null,
  "$0 ولا يوم",
  "$0 يوم واحد",
  "$0 يومان",
  "$0 أيام",
  "$0 يوما",
  "$0 يوم"
 ],
 "$0 disk is missing": [
  null,
  "$0 لا أقراص مفقودة",
  "$0 قرص واحد مفقود",
  "$0 قرصين مفقودين",
  "$0 أقراص مفقودة",
  "$0 قرصا مفقودا",
  "$0 قرص مفقود"
 ],
 "$0 disks": [
  null,
  "$0 أقراص"
 ],
 "$0 exited with code $1": [
  null,
  "$0 خرج مع الرمز $1"
 ],
 "$0 failed": [
  null,
  "$0 فشل"
 ],
 "$0 filesystem": [
  null,
  "$0 نظام ملفات"
 ],
 "$0 hour": [
  null,
  "$0 ولا ساعة",
  "$0 ساعة واحدة",
  "$0 ساعتان",
  "$0 ساعات",
  "$0 ساعة",
  "$0 ساعة"
 ],
 "$0 hours": [
  null,
  "$0 ساعات"
 ],
 "$0 is in use": [
  null,
  "$0 قيد الاستخدام"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 غير متوفر في أي مستودع."
 ],
 "$0 key changed": [
  null,
  "$0 مفتاح قد تغير"
 ],
 "$0 killed with signal $1": [
  null,
  "تم إيقاف $0 بالإشارة $1"
 ],
 "$0 minute": [
  null,
  "0 دقيقة",
  "دقيقة واحدة",
  "دقيقتان",
  "$0 دقائق",
  "$0 دقيقة",
  "$0 دقيقة"
 ],
 "$0 month": [
  null,
  "$0 شهر",
  "شهر واحد",
  "شهران",
  "$0 أشهر",
  "$0 شهراً",
  "$0 شهراً"
 ],
 "$0 partitions": [
  null,
  "$0 قسم"
 ],
 "$0 slot remains": [
  null,
  "لا فتحة متبقية",
  "فتحة واحدة متبقية",
  "فتحتان متبقيتان",
  "$0 فتحة متبقية",
  "$0 فتحة متبقية",
  "$0 فتحة متبقية"
 ],
 "$0 synchronized": [
  null,
  "$0 متزامن"
 ],
 "$0 used of $1 ($2 saved)": [
  null,
  "$0 مستخدمة من $1 (تم حفظ $2)"
 ],
 "$0 used, $1 total": [
  null,
  "$0 مستخدمة من أصل $1"
 ],
 "$0 week": [
  null,
  "$0 لا أسابيع",
  "$0 اسبوع واحد",
  "$0 اسبوعان",
  "$0 اسابيع",
  "$0 اسبوعا",
  "$0 اسبوع"
 ],
 "$0 will be installed.": [
  null,
  "$0 سيُثبت."
 ],
 "$0 year": [
  null,
  "$0 ولا سنة",
  "$0 سنة واحدة",
  "$0 سنتان",
  "$0 سنوات",
  "$0 سنة",
  "$0 سنة"
 ],
 "$name (from $host)": [
  null,
  "$name (من $host)"
 ],
 "(Not part of target)": [
  null,
  "(ليس جزءًا من الهدف)"
 ],
 "(no assigned mount point)": [
  null,
  "(لا توجد نقطة تركيب معينة)"
 ],
 "(not mounted)": [
  null,
  "(لم يتم تركيبه)"
 ],
 "(recommended)": [
  null,
  "(مُستحسَن)"
 ],
 "1 MiB": [
  null,
  "1 MiB"
 ],
 "1 day": [
  null,
  "يوم واحد"
 ],
 "1 hour": [
  null,
  "ساعة واحدة"
 ],
 "1 minute": [
  null,
  "دقيقة واحدة"
 ],
 "1 week": [
  null,
  "أسبوع واحد"
 ],
 "128 KiB": [
  null,
  "128 KiB"
 ],
 "16 KiB": [
  null,
  "16 KiB"
 ],
 "2 MiB": [
  null,
  "2 MiB"
 ],
 "20 minutes": [
  null,
  "٢٠ دقيقة"
 ],
 "32 KiB": [
  null,
  "32 KiB"
 ],
 "4 KiB": [
  null,
  "4 KiB"
 ],
 "40 minutes": [
  null,
  "٤٠ دقيقة"
 ],
 "5 minutes": [
  null,
  "٥ دقائق"
 ],
 "512 KiB": [
  null,
  "512 KiB"
 ],
 "6 hours": [
  null,
  "٦ ساعات"
 ],
 "60 minutes": [
  null,
  "٦٠ دقيقة"
 ],
 "64 KiB": [
  null,
  "64 KiB"
 ],
 "8 KiB": [
  null,
  "8 KiB"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "لم يتم تثبيت إصدار متوافق من Cockpit على $0."
 ],
 "A fatal error occurred during the self-test operation": [
  null,
  "حدث خطأ كارثي أثناء عملية الفحص الذاتي"
 ],
 "A filesystem with this name exists already in this pool.": [
  null,
  "نظام ملفات بهذا الاسم موجود بالفعل في هذا المخزن."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "سيتم إنشاء مفتاح SSH جديد في $0 لـ $1 بتاريخ $2 ، وإضافته إلى الملف $3 الخاص بـ $4 على $5."
 ],
 "A pool with this name exists already.": [
  null,
  "يوجد بالفعل مجموعة تخزين بهذا الاسم."
 ],
 "A volume group with missing physical volumes can not be renamed.": [
  null,
  "لا يمكن إعادة تسمية مجموعة وحدات التخزين التي تحوي على أقراص مادية مفقودة."
 ],
 "Abort test": [
  null,
  "إلغاء الاختبار"
 ],
 "Aborted": [
  null,
  "ملغي"
 ],
 "Aborted by a Controller Level Reset": [
  null,
  "أُلغي بسبب إعادة ضبط على مستوى المتحكم"
 ],
 "Aborted due to a removal of a namespace from the namespace inventory": [
  null,
  "تم إلغاء العملية لأن مساحة الأسماء حُذفت من النظام"
 ],
 "Aborted due to a sanitize operation": [
  null,
  "أُلغيَت العملية بسبب تنفيذ عملية تعقيم"
 ],
 "Aborted due to the processing of a Format NVM command": [
  null,
  "أُلغيَت العملية بسبب معالجة أمر تهيئة NVM"
 ],
 "Aborted for unknown reason": [
  null,
  "أُلغيَت العملية لسبب غير معروف"
 ],
 "Absent": [
  null,
  "غائب"
 ],
 "Acceptable password": [
  null,
  "كلمة السر صالحة"
 ],
 "Action": [
  null,
  "نشاط"
 ],
 "Actions": [
  null,
  "إجراءات"
 ],
 "Activate": [
  null,
  "التنشيط"
 ],
 "Activate before resizing": [
  null,
  "التنشيط قبل تغيير الحجم"
 ],
 "Activating $target": [
  null,
  "جاري تفعيل $target"
 ],
 "Add": [
  null,
  "إضافة"
 ],
 "Add $0": [
  null,
  "أضف $0"
 ],
 "Add Network Bound Disk Encryption": [
  null,
  "إضافة تشفير القرص المربوط بالشبكة"
 ],
 "Add Tang keyserver": [
  null,
  "إضافة خادم مفاتيح Tang"
 ],
 "Add a bitmap": [
  null,
  "إضافة صورة نقطية"
 ],
 "Add block devices": [
  null,
  "إضافة أجهزة كتلية"
 ],
 "Add disk": [
  null,
  "إضافة قرص"
 ],
 "Add disks": [
  null,
  "إضافة أقراص"
 ],
 "Add iSCSI portal": [
  null,
  "إضافة مدخل iSCSI"
 ],
 "Add key": [
  null,
  "إضافة مفتاح"
 ],
 "Add keyserver": [
  null,
  "إضافة مفتاح خادم"
 ],
 "Add passphrase": [
  null,
  "إضافة عبارة مرور"
 ],
 "Add physical volume": [
  null,
  "إضافة قرص فيزيائي"
 ],
 "Adding \"$0\" to encryption options": [
  null,
  "إضافة \"$0\" لخيارات التشفير"
 ],
 "Adding \"$0\" to filesystem options": [
  null,
  "إضافة \"$0\" لخيارات نظام الملفات"
 ],
 "Adding a keyserver requires unlocking the pool. Please provide the existing pool passphrase.": [
  null,
  "إضافة خادم مفاتيح تتطلب فك قفل مجموعة التخزين. يُرجى إدخال عبارة المرور الحالية للمجموعة."
 ],
 "Adding key": [
  null,
  "جاري إضافة مفتاح"
 ],
 "Adding physical volume to $target": [
  null,
  "إضافة قرص فيزيائي إلى $target"
 ],
 "Adding rd.neednet=1 to kernel command line": [
  null,
  "إضافة rd.neednet=1 إلى سطر أوامر نواة النظام"
 ],
 "Additional packages:": [
  null,
  "حزم إضافية:"
 ],
 "Address": [
  null,
  "العنوان"
 ],
 "Address cannot be empty": [
  null,
  "لا يمكن ترك العنوان فارغاً"
 ],
 "Address is not a valid URL": [
  null,
  "العنوان ليس رابط URL سليم"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "الإدارة عبر وحدة تحكم الويب Cockpit"
 ],
 "Advanced TCA": [
  null,
  "TCA متقدم"
 ],
 "All $0 selected physical volumes are needed for the chosen layout.": [
  null,
  "جميع وحدات التخزين الفيزيائية المحددة ($0) ضرورية للمخطط المختار."
 ],
 "All media is in read-only mode": [
  null,
  "كل الوسائط ففي وضعية القراءة فقط"
 ],
 "All-in-one": [
  null,
  "الكل في واحد"
 ],
 "Allocated": [
  null,
  "محجوز"
 ],
 "Allow overprovisioning": [
  null,
  "تمكين التخصيص الزائد للموارد"
 ],
 "An additional $0 must be selected": [
  null,
  "يجب تحديد $0 إضافي"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "توثيق الأدوار في Ansible"
 ],
 "Appropriate for critical mounts, such as /var": [
  null,
  "مناسب لنقاط التركيب الحرجة ، مثل ‎/var"
 ],
 "Assessment": [
  null,
  "التقييم"
 ],
 "At boot": [
  null,
  "عند بدء التشغيل"
 ],
 "At least $0 disk is needed.": [
  null,
  "لا يحتاج لأي قرص.",
  "يحتاج إلى قرص واحد على الأقل.",
  "يحتاج إلى قرصين على الأقل.",
  "يحتاج إلى $0 أقراص على الأقل.",
  "يحتاج إلى $0 قرصاً على الأقل.",
  "يحتاج إلى $0 قرصاً على الأقل."
 ],
 "At least one block device is needed.": [
  null,
  "يحتاج إلى جهاز تخزين واحد على الأقل."
 ],
 "At least one disk is needed.": [
  null,
  "يحتاج إلى قرص صلب واحد على الأقل."
 ],
 "At least one subvolume needs to be mounted": [
  null,
  "\"يجب تركيب وحدة فرعية واحدة على الأقل"
 ],
 "Attributes failing": [
  null,
  "سمات معطوبة"
 ],
 "Authentication": [
  null,
  "المصادقة"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "المصادقة مطلوبة لأداء المهام المميّزة في وحدة تحكم Cockpit على الويب"
 ],
 "Authentication required": [
  null,
  "المصادقة مطلوبة"
 ],
 "Authorize SSH key": [
  null,
  "اعتماد مفاتيح SSH"
 ],
 "Automatically using NTP": [
  null,
  "استخدام NTP بشكل تلقائي"
 ],
 "Automatically using additional NTP servers": [
  null,
  "استخدام خادم NTP إضافي بشكل تلقائي"
 ],
 "Automatically using specific NTP servers": [
  null,
  "استخدام خادم NTP محدد بشكل تلقائي"
 ],
 "Automation script": [
  null,
  "البرنامج النصي للتشغيل الآلي"
 ],
 "Available targets on $0": [
  null,
  "توجد أهداف متاحة على $0"
 ],
 "BIOS boot partition": [
  null,
  "قسم إقلاع الـ BIOS"
 ],
 "Blade": [
  null,
  "شفرة"
 ],
 "Blade enclosure": [
  null,
  "حاوية الشفرة"
 ],
 "Block device": [
  null,
  "حجب الجحاز"
 ],
 "Block device for filesystems": [
  null,
  "جهاز الحظر لأنظمة الملفات"
 ],
 "Block devices": [
  null,
  "أجهزة الحظر"
 ],
 "Blocked": [
  null,
  "محظور"
 ],
 "Boot fails if filesystem does not mount, preventing remote access": [
  null,
  "سيفشل التمهيد إذا لم يتم تحميل نظام الملفات، مما يمنع التحكم عن بُعد"
 ],
 "Boot still succeeds when filesystem does not mount": [
  null,
  "يظل التمهيد ناجحاً عندما لا يتم تحميل نظام الملفات"
 ],
 "Bus expansion chassis": [
  null,
  "هيكل توسيع الناقل"
 ],
 "Cache": [
  null,
  "ذاكرة التخزين المؤقت"
 ],
 "Cancel": [
  null,
  "إلغاء"
 ],
 "Cannot forward login credentials": [
  null,
  "لا يمكن إعادة توجيه بيانات اعتماد تسجيل الدخول"
 ],
 "Cannot schedule event in the past": [
  null,
  "لا يمكن جدولة الحدث في الماضي"
 ],
 "Capacity": [
  null,
  "السعة"
 ],
 "Category": [
  null,
  "الفئة"
 ],
 "Change": [
  null,
  "تغيير"
 ],
 "Change iSCSI initiator name": [
  null,
  "تغيير اسم المُبادر iSCSI"
 ],
 "Change label": [
  null,
  "تغيير التسمية"
 ],
 "Change passphrase": [
  null,
  "تغيير عبارة المرور"
 ],
 "Change system time": [
  null,
  "تغيير توقيت النظام"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "غالباً تكون المفاتيح المتغيرة نتيجة إعادة تثبيت نظام التشغيل. رغم ذلك، قد يشير التغيير غير المتوقع إلى محاولة طرف ثالث اعتراض اتصالك."
 ],
 "Changing partition types might prevent the system from booting.": [
  null,
  "قد يؤدي تغيير أنواع الأقسام إلى منع النظام من الإقلاع."
 ],
 "Check that the SHA-256 or SHA-1 hash from the command matches this dialog.": [
  null,
  "تحقق من تطابق تجزئة SHA-256 أو SHA-1 من الأمر مع مربع الحوار هذا."
 ],
 "Check the key hash with the Tang server.": [
  null,
  "تحقق من تجزئة المفتاح مع خادم Tang."
 ],
 "Checking $target": [
  null,
  "فحص $target"
 ],
 "Checking MDRAID device $target": [
  null,
  "التحقق من جهاز MDRAID $target"
 ],
 "Checking and repairing MDRAID device $target": [
  null,
  "فحص وإصلاح جهاز MDRAID $target"
 ],
 "Checking filesystem usage": [
  null,
  "التحقق من استخدام نظام الملفات"
 ],
 "Checking for $0 package": [
  null,
  "التحقق من وجود حزمة $0"
 ],
 "Checking for NBDE support in the initrd": [
  null,
  "التحقق من وجود دعم NBDE في نظام التشغيل initrd"
 ],
 "Checking installed software": [
  null,
  "التحقق من البرامج المثبتة"
 ],
 "Chunk size": [
  null,
  "حجم القطعة"
 ],
 "Cleaning up for $target": [
  null,
  "جارٍ المسح لـ $target"
 ],
 "Clear input value": [
  null,
  "مسح قيمة المدخلات"
 ],
 "Cleartext device": [
  null,
  "جهاز Cleartext"
 ],
 "Close": [
  null,
  "أغلق"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "تكوين Cockpit الخاص بـ NetworkManager وFirewalld"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "لم يتمكن Cockpit بالاتصال بالمضيف المحدد."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit هو أداة لإدارة الخوادم تُسهّل عليك الإشراف على خوادم Linux عبر متصفّح الويب. التنقّل بين الطرفية (الترمينال) والأداة على الويب سلس تمامًا؛ فمثلاً يمكنك إيقاف خدمة تمّ تشغيلها عبر Cockpit من داخل الطرفية، وبالمثل إذا ظهر خطأ في الطرفية ستجده معروضًا في واجهة سجلات Journal الخاصة بـ Cockpit."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit غير متوافق مع البرنامج على النظام."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit غير مثبت"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit غير مثبت على النظام."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "تُعد Cockpit مثالية لمديري النظام الجدد، حيث تتيح لهم أداء مهام بسيطة بسهولة مثل إدارة التخزين وفحص السجلات وبدء تشغيل الخدمات وإيقافها. يمكنك مراقبة وإدارة عدة خوادم في نفس الوقت. ما عليك سوى إضافتها بنقرة واحدة وستعتني أجهزتك بالباقي."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "جمع بيانات التشخيص والدعم وتجميعها"
 ],
 "Collect kernel crash dumps": [
  null,
  "جمع تفريغات أعطال نواة النظام"
 ],
 "Command": [
  null,
  "أمر"
 ],
 "Compact PCI": [
  null,
  "PCI مدمج"
 ],
 "Compatible with all systems and devices (MBR)": [
  null,
  "متوافق مع جميع الأنظمة والأجهزة (MBR)"
 ],
 "Compatible with modern system and hard disks > 2TB (GPT)": [
  null,
  "**متوافق مع الأنظمة الحديثة والأقراص الصلبة الأكبر من 2 تيرابايت (GPT)*"
 ],
 "Completed with a segment that failed and the segment that failed is not known": [
  null,
  "مكتمل مع فشل جزء غير معروف"
 ],
 "Completed with one or more failed segments": [
  null,
  "اكتمل مع وجود جزء أو أكثر من الأجزاء فاشلة"
 ],
 "Compression": [
  null,
  "الضغط"
 ],
 "Confirm": [
  null,
  "أكِّد"
 ],
 "Confirm deletion of $0": [
  null,
  "تأكيد حذف $0"
 ],
 "Confirm key password": [
  null,
  "تأكيد مفتاح كلمة السر"
 ],
 "Confirm removal with an alternate passphrase": [
  null,
  "تأكيد الإزالة مع عبارة مرور بديلة"
 ],
 "Confirm stopping of $0": [
  null,
  "تأكيد إيقاف $0"
 ],
 "Connection has timed out.": [
  null,
  "انتهت مدة الاتصال."
 ],
 "Convertible": [
  null,
  "قابل للتحويل"
 ],
 "Copied": [
  null,
  "نُسخ"
 ],
 "Copy": [
  null,
  "نسخ"
 ],
 "Copy to clipboard": [
  null,
  "نسخ للحافظة"
 ],
 "Create": [
  null,
  "إنشاء"
 ],
 "Create $0": [
  null,
  "أنشئ $0"
 ],
 "Create LVM2 volume group": [
  null,
  "إنشاء مجموعة أقراص LVM2"
 ],
 "Create MDRAID device": [
  null,
  "إنشاء جهاز MDRAID"
 ],
 "Create RAID device": [
  null,
  "نشاء جهاز RAID"
 ],
 "Create Stratis pool": [
  null,
  "إنشاء مجموعة Stratis"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "إنشاء مفتاح SSH جديد وتفويضه"
 ],
 "Create a snapshot of filesystem $0": [
  null,
  "إنشاء لقطة لنظام الملفات$0"
 ],
 "Create and mount": [
  null,
  "إنشاء ثم تركيب"
 ],
 "Create and start": [
  null,
  "إنشاء وبدء"
 ],
 "Create filesystem": [
  null,
  "إنشاء نظام ملفات"
 ],
 "Create logical volume": [
  null,
  "إنشاء قرص منطقي"
 ],
 "Create new filesystem": [
  null,
  "إنشاء نظام ملفات جديد"
 ],
 "Create new logical volume": [
  null,
  "إنشاء قرص منطقي جديد"
 ],
 "Create new task file with this content.": [
  null,
  "إنشاء ملف مهمة جديدة بهذا المحتوى."
 ],
 "Create new thinly provisioned logical volume": [
  null,
  "إنشاء وحدة تخزين منطقية مخصصة رقيقة"
 ],
 "Create only": [
  null,
  "أنشئ فقط"
 ],
 "Create partition": [
  null,
  "إنشاء قسم"
 ],
 "Create partition on $0": [
  null,
  "إنشاء قسم على $0"
 ],
 "Create partition table": [
  null,
  "إنشاء جدول تقسيم"
 ],
 "Create snapshot": [
  null,
  "إنشاء لقطة"
 ],
 "Create snapshot and mount": [
  null,
  "إنشاء لقطة وتركيبها"
 ],
 "Create snapshot only": [
  null,
  "إنشاء اللقطة فقط"
 ],
 "Create storage device": [
  null,
  "إنشاء جهاز تحزين"
 ],
 "Create subvolume": [
  null,
  "إنشاء وحدة تخزين فرعية"
 ],
 "Create thin volume": [
  null,
  "إنشاء وحدة تخزين رفيعة"
 ],
 "Create volume group": [
  null,
  "إنشاء مجموعة أقراص"
 ],
 "Creating LVM2 volume group $target": [
  null,
  "إنشاء مجموعة وحدات تخزين LVM2 $target"
 ],
 "Creating MDRAID device $target": [
  null,
  "إنشاء جهاز MDRAID $target"
 ],
 "Creating VDO device": [
  null,
  "إنشاء جهاز VDO"
 ],
 "Creating filesystem on $target": [
  null,
  "إنشاء نظام ملفات على $target"
 ],
 "Creating logical volume $target": [
  null,
  "إنشاء وحدة تخزين منطقية $target"
 ],
 "Creating partition $target": [
  null,
  "إنشاء قسم $target"
 ],
 "Creating snapshot of $target": [
  null,
  "إنشاء لقطة لـ $target"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Currently in use": [
  null,
  "قيد الاستخدام"
 ],
 "Custom": [
  null,
  "مخصّص"
 ],
 "Custom mount options": [
  null,
  "خيارات تركيب مخصصة"
 ],
 "Custom type": [
  null,
  "نوع مخصص"
 ],
 "Data": [
  null,
  "البيانات"
 ],
 "Data used": [
  null,
  "البيانات المستخدمة"
 ],
 "Data will be stored as two copies and also in an alternating fashion on the selected physical volumes, to improve both reliability and performance. At least four volumes need to be selected.": [
  null,
  "سيتم تخزين البيانات كنسختين، وكذلك بالتناوب، على وحدات التخزين المادية المحددة، لتحسين الموثوقية والأداء. يجب اختيار أربعة وحدات تخزين على الأقل."
 ],
 "Data will be stored as two or more copies on the selected physical volumes, to improve reliability. At least two volumes need to be selected.": [
  null,
  "سيتم تخزين البيانات كنسختين أو أكثر على وحدات التخزين المادية المحددة، لتحسين الموثوقية. يجب تحديد وحدتي تخزين على الأقل."
 ],
 "Data will be stored on the selected physical volumes in an alternating fashion to improve performance. At least two volumes need to be selected.": [
  null,
  "سيتم تخزين البيانات على وحدات التخزين المادية المحددة بطريقة متناوبة لتحسين الأداء. يجب تحديد وحدتي تخزين على الأقل."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. At least three volumes need to be selected.": [
  null,
  "سيتم تخزين البيانات على وحدات التخزين المادية المحددة بحيث يمكن فقدان أحدها دون التأثير على البيانات. يجب تحديد ثلاث وحدات على الأقل."
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. Data is also stored in an alternating fashion to improve performance. At least three volumes need to be selected.": [
  null,
  "سيتم تخزين البيانات على وحدات التخزين المادية المحددة بحيث يمكن فقدان أحدها دون التأثير على البيانات. يتم تخزين البيانات أيضاً بطريقة متناوبة لتحسين الأداء. يجب تحديد ثلاث وحدات على الأقل."
 ],
 "Data will be stored on the selected physical volumes so that up to two of them can be lost at the same time without affecting the data. Data is also stored in an alternating fashion to improve performance. At least five volumes need to be selected.": [
  null,
  "سيتم تخزين البيانات على وحدات التخزين المادية المحددة بحيث يمكن فقدان ما يصل إلى اثنين منها في نفس الوقت دون التأثير على البيانات. يتم تخزين البيانات أيضاً بطريقة متناوبة لتحسين الأداء. يجب تحديد خمسة وحدات على الأقل."
 ],
 "Data will be stored on the selected physical volumes without any additional redundancy or performance improvements.": [
  null,
  "سيتم تخزين البيانات على وحدات التخزين المادية المحددة دون أي تكرار إضافي أو تحسينات في الأداء."
 ],
 "Deactivate": [
  null,
  "إلغاء التنشيط"
 ],
 "Deactivate logical volume $0/$1?": [
  null,
  "إلغاء تنشيط وحدة التخزين المنطقية $0/$1؟"
 ],
 "Deactivating $target": [
  null,
  "إلغاء تنشيط $target"
 ],
 "Dedicated parity (RAID 4)": [
  null,
  "التكافؤ المخصص (RAID 4)"
 ],
 "Deduplication": [
  null,
  "النسخ المكرر"
 ],
 "Degraded": [
  null,
  "متدهور"
 ],
 "Delay": [
  null,
  "التأخير"
 ],
 "Delete": [
  null,
  "حذف"
 ],
 "Delete filesystem": [
  null,
  "حذف نظام ملفات"
 ],
 "Delete group": [
  null,
  "حذف المجموعة"
 ],
 "Delete pool": [
  null,
  "حذف المجمع"
 ],
 "Deleting $target": [
  null,
  "جاري حذف $target"
 ],
 "Deleting LVM2 volume group $target": [
  null,
  "جار حذف مجموعة وحدة تحزين LVM2 $target"
 ],
 "Deleting a Stratis pool will erase all data it contains.": [
  null,
  "سيؤدي حذف مجمع Stratis إلى مسح جميع البيانات التي يحتوي عليها."
 ],
 "Deleting a filesystem will delete all data in it.": [
  null,
  "سيؤدي حذف نظام الملفات إلى حذف جميع البيانات الموجودة فيه."
 ],
 "Deleting a logical volume will delete all data in it.": [
  null,
  "سيؤدي حذف وحدة التخزين المنطقية إلى حذف جميع البيانات الموجودة فيه."
 ],
 "Deleting a partition will delete all data in it.": [
  null,
  "سيؤدي حذف قسم إلى حذف كل البيانات الموجودة فيه."
 ],
 "Deleting erases all data on a MDRAID device.": [
  null,
  "يؤدي الحذف إلى مسح كافة البيانات الموجودة على جهاز MDRAID."
 ],
 "Deleting erases all data on a VDO device.": [
  null,
  "يؤدي الحذف إلى مسح جميع البيانات الموجودة على جهاز VDO."
 ],
 "Deleting erases all data on a btrfs volume.": [
  null,
  "يؤدي الحذف إلى مسح جميع البيانات الموجودة على وحدة تخزين btrfs."
 ],
 "Deleting erases all data on a volume group.": [
  null,
  "يؤدي الحذف إلى مسح جميع البيانات الموجودة على مجموعة وحدات التخزين."
 ],
 "Deleting erases all data on this subvolume and all its children.": [
  null,
  "يؤدي الحذف إلى محو جميع البيانات الموجودة على هذا الحجم الفرعي وجميع البيانات التابعة له."
 ],
 "Description": [
  null,
  "الوصف"
 ],
 "Desktop": [
  null,
  "سطح المكتب"
 ],
 "Detachable": [
  null,
  "قابل للفصل"
 ],
 "Device": [
  null,
  "جهاز"
 ],
 "Device contains unrecognized data": [
  null,
  "يحوي الجهاز على بيانات غير معترف بها"
 ],
 "Device file": [
  null,
  "ملف الجهاز"
 ],
 "Device health (SMART)": [
  null,
  "صحة الجهاز (SMART)"
 ],
 "Device is read-only": [
  null,
  "الجهاز للقراءة فقط"
 ],
 "Device number": [
  null,
  "رقم الجهاز"
 ],
 "Diagnostic reports": [
  null,
  "تقارير التشخيص"
 ],
 "Did not complete": [
  null,
  "غير مكتمل"
 ],
 "Disconnect": [
  null,
  "قطع الاتصال"
 ],
 "Disk is OK": [
  null,
  "القرص سليم"
 ],
 "Disk is failing": [
  null,
  "القرص معطل"
 ],
 "Disk passphrase": [
  null,
  "عبارة مرور القرص"
 ],
 "Disks": [
  null,
  "الأقراص"
 ],
 "Dismiss": [
  null,
  "استبعاد"
 ],
 "Distributed parity (RAID 5)": [
  null,
  "التكافؤ الموزع (RAID 5)"
 ],
 "Do not mount": [
  null,
  "لا تركِّب"
 ],
 "Do not mount automatically on boot": [
  null,
  "لا تقم بالتركيب تلقائياً عند الإقلاع"
 ],
 "Docking station": [
  null,
  "محطة إرساء"
 ],
 "Does not mount during boot": [
  null,
  "لا يتم تركيبه أثناء الإقلاع"
 ],
 "Double distributed parity (RAID 6)": [
  null,
  "التكافؤ الموزع المزدوج (RAID 6)"
 ],
 "Downloading $0": [
  null,
  "جاري تنزيل $0"
 ],
 "Drive": [
  null,
  "محرك أقراص"
 ],
 "Dual rank": [
  null,
  "رتبة مزدوجة"
 ],
 "EFI system partition": [
  null,
  "قسم نظام EFI"
 ],
 "Edit": [
  null,
  "عدِّل"
 ],
 "Edit Tang keyserver": [
  null,
  "تعديل مفتاح خادم Tang"
 ],
 "Edit mount point": [
  null,
  "تعديل نقطة تركيب"
 ],
 "Editing a key requires a free slot": [
  null,
  "تعديب مفتاح يتطلب فتحة فارغة"
 ],
 "Ejecting $target": [
  null,
  "إخراج $target"
 ],
 "Embedded PC": [
  null,
  "حاسوب مدمج"
 ],
 "Emptying $target": [
  null,
  "تفريغ $target"
 ],
 "Enabling $0": [
  null,
  "تفعيل $0"
 ],
 "Encrypt data with a Tang keyserver": [
  null,
  "تشفير الببانات مع مفتاح خادم Tang"
 ],
 "Encrypt data with a passphrase": [
  null,
  "شفر البيانات مع عبارة مرور"
 ],
 "Encrypted $0": [
  null,
  "$0 مشفَّر"
 ],
 "Encrypted Stratis pool": [
  null,
  "مجمع Stratis المشفر"
 ],
 "Encrypted logical volume of $0": [
  null,
  "وحدة تخزين منطقية مشفرة من $0"
 ],
 "Encrypted partition of $0": [
  null,
  "قسم مشفر $0"
 ],
 "Encryption": [
  null,
  "تشفير"
 ],
 "Encryption options": [
  null,
  "إعدادات التشفير"
 ],
 "Encryption type": [
  null,
  "تشفير النوع"
 ],
 "Erasing $target": [
  null,
  "مسح $target"
 ],
 "Error": [
  null,
  "خطأ"
 ],
 "Error installing $0: PackageKit is not installed": [
  null,
  "خطأ في تثبيت $0: PackageKit غير مثبَّت"
 ],
 "Exactly $0 physical volumes must be selected": [
  null,
  "يجب تحديد $0 من الأحجام الفيزائية بالضبط"
 ],
 "Exactly $0 physical volumes need to be selected, one for each stripe of the logical volume.": [
  null,
  "يجب تحديد $0 وحدات تخزين فيزيائية بالضبط، واحد لكل شريط من وحدة التخزين المنطقية."
 ],
 "Excellent password": [
  null,
  "كلمة سر ممتازة"
 ],
 "Expansion chassis": [
  null,
  "هيكل التوسعة"
 ],
 "Extended partition": [
  null,
  "قسم موسع"
 ],
 "Failed": [
  null,
  "فشل"
 ],
 "Failed (Damaged)": [
  null,
  "فشل (تلف)"
 ],
 "Failed (Electrical)": [
  null,
  "فشل (كهربائي)"
 ],
 "Failed (Read)": [
  null,
  "فشل (قراءة)"
 ],
 "Failed (Servo)": [
  null,
  "فشل (نظام التحكم Servo)"
 ],
 "Failed (Unknown)": [
  null,
  "فشل (مجهول السبب)"
 ],
 "Failed to change password": [
  null,
  "فشل في تغيير كلمة السر"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "فشل بتمكين $0 في الجدار الناري"
 ],
 "Filesystem": [
  null,
  "نظام الملفات"
 ],
 "Filesystem is locked": [
  null,
  "نظام الملفات مقفل"
 ],
 "Filesystem is mounted read-only": [
  null,
  "تم تركيب نظام الملفات للقراءة فقط"
 ],
 "Filesystem name": [
  null,
  "اسم نظام الملفات"
 ],
 "Filesystem outside the target": [
  null,
  "نظام الملفات خارج نطاق الهدف"
 ],
 "Filesystems are already mounted below this mountpoint.": [
  null,
  "أنظمة الملفات تم تركيبها بالفعل أسفل نقطة التركيب هذه."
 ],
 "Firmware version": [
  null,
  "إصدار التعريف"
 ],
 "Fix NBDE support": [
  null,
  "إصلاح دعم NBDE"
 ],
 "Format": [
  null,
  "تهيئة"
 ],
 "Format $0": [
  null,
  "تهيئة $0"
 ],
 "Format and mount": [
  null,
  "اهيئة وتركيب"
 ],
 "Format and start": [
  null,
  "تهيئة وبدء"
 ],
 "Format only": [
  null,
  "التهيئة فقط"
 ],
 "Formatting erases all data on a storage device.": [
  null,
  "التهئية ستمسح كل البيانات من جهاز التخزين."
 ],
 "Free space": [
  null,
  "المساحة الحرّة"
 ],
 "Go to now": [
  null,
  "انتقل الآن"
 ],
 "Grow": [
  null,
  "النمو"
 ],
 "Grow content": [
  null,
  "نمو المحتوى"
 ],
 "Grow logical size of $0": [
  null,
  "زيادة الحجم المنطقي لـ $0"
 ],
 "Grow logical volume": [
  null,
  "نمو وحدة التخزين المنطقية"
 ],
 "Grow partition": [
  null,
  "نمو القسم"
 ],
 "Grow the pool to take all space": [
  null,
  "قم بتنمية التجمع ليأخذ كل المساحة"
 ],
 "Grow to take all space": [
  null,
  "النمو لأخذ كل المساحة"
 ],
 "Handheld": [
  null,
  "محمول باليد"
 ],
 "Hard Disk Drive": [
  null,
  "القرص الصلب"
 ],
 "Hide confirmation password": [
  null,
  "أخفِ تأكيد كلمة السر"
 ],
 "Hide password": [
  null,
  "أخفِ كلمة السر"
 ],
 "Host key is incorrect": [
  null,
  "مفتاح الاستضافة غير صحيح"
 ],
 "How to check": [
  null,
  "كيفية التحقق"
 ],
 "I confirm I want to lose this data forever": [
  null,
  "أؤكد أنني أريد التخلص من هذه البيانات إلى الأبد"
 ],
 "ID": [
  null,
  "المعرّف"
 ],
 "INTERNAL ERROR - This logical volume is marked as active and should have an associated block device. However, no such block device could be found.": [
  null,
  "خطأ داخلي - تم وضع علامة على وحدة التخزين المنطقية هذه على أنها نشطة ويجب أن يكون لها جهاز كتلة مقترن. رغم ذلك، لا جهاز كتلة تم العثور عليه."
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "إذا كانت البصمة متطابقة، انقر فوق ”توثيق وإضافة مضيف“. وإلا فلا تتصل ، وتواصل مع مسؤول النظام."
 ],
 "Important data might be deleted:": [
  null,
  "قد يتم حذف بيانات مهمة:"
 ],
 "In a terminal, run: ": [
  null,
  "في الطرفية، قم بتنفيذ: "
 ],
 "In progress": [
  null,
  "قيد المعالجة"
 ],
 "In sync": [
  null,
  "قيد المزامنة"
 ],
 "Inactive logical volume": [
  null,
  "وحدة تخزين منطقية غير مفعلة"
 ],
 "Inconsistent filesystem mount": [
  null,
  "تركيب نظام ملفات غير متوافق"
 ],
 "Index memory": [
  null,
  "ذاكرة الفهرسة"
 ],
 "Initialize": [
  null,
  "تمهيد"
 ],
 "Initialize disk $0": [
  null,
  "تمهيد القرص $0"
 ],
 "Initializing erases all data on a disk.": [
  null,
  "التمهيد سيحذف كل البيانات من القرص."
 ],
 "Install": [
  null,
  "تثبيت"
 ],
 "Install NFS support": [
  null,
  "تثبيت خدمة NFS"
 ],
 "Install Stratis support": [
  null,
  "تثبيت دعم Stratis"
 ],
 "Install software": [
  null,
  "ثبت التطبيق"
 ],
 "Installing $0": [
  null,
  "يثبت $0"
 ],
 "Installing $0 would remove $1.": [
  null,
  "سيؤدي تثبيت $0 لإزالة $1."
 ],
 "Installing packages": [
  null,
  "تثبيت الحزم"
 ],
 "Internal error": [
  null,
  "خطأ داخلي"
 ],
 "Interrupted": [
  null,
  "مُقاطَع"
 ],
 "Invalid date format": [
  null,
  "تنسيق التاريخ خاطئ"
 ],
 "Invalid date format and invalid time format": [
  null,
  "صيغة البيانات والوقت غير صالحتان"
 ],
 "Invalid file permissions": [
  null,
  "صلاحيات ملف غير صالحة"
 ],
 "Invalid time format": [
  null,
  "تنسيق الوقت خاطئ"
 ],
 "Invalid timezone": [
  null,
  "منطقة زمنية غير صالحة"
 ],
 "Invalid username or password": [
  null,
  "اسم المستخدم او كلمة السر غير صالحتان"
 ],
 "IoT gateway": [
  null,
  "بوابة IoT"
 ],
 "Jobs": [
  null,
  "الوظائف"
 ],
 "Kernel dump": [
  null,
  "عطب نواة النظام"
 ],
 "Key password": [
  null,
  "مفتاح كلمة السر"
 ],
 "Key slots with unknown types can not be edited here": [
  null,
  "لا يمكن تعديل فتحات المفاتيح ذات الأنواع غير المعروفة هنا"
 ],
 "Key source": [
  null,
  "مصدر المفتاح"
 ],
 "Keys": [
  null,
  "المفاتيح"
 ],
 "Keyserver": [
  null,
  "خادم المفاتيح"
 ],
 "Keyserver address": [
  null,
  "عنوان خادم المفاتيح"
 ],
 "Keyserver removal may prevent unlocking $0.": [
  null,
  "قد تؤدي إزالة خادم المفاتيح إلى منع فتح قفل $0."
 ],
 "LVM2 VDO pool": [
  null,
  "مجمع LVM2 VDO"
 ],
 "LVM2 logical volume": [
  null,
  "وحدة تحزين LVM2 منطقية"
 ],
 "LVM2 logical volumes": [
  null,
  "وحدات تخزين LVM2 منطقية"
 ],
 "LVM2 physical volume": [
  null,
  "وحدة تخزين LVM2 فيزيائية"
 ],
 "LVM2 physical volumes": [
  null,
  "وحدات تخزين LVM2 فيزيائية"
 ],
 "LVM2 volume group": [
  null,
  "مجموعة وحظات تخزين LVM2"
 ],
 "LVM2 volume group $0": [
  null,
  "مجموعة وحدات تخزين LVM2 $0"
 ],
 "Label": [
  null,
  "العنوان"
 ],
 "Laptop": [
  null,
  "لابتوب"
 ],
 "Last cannot be removed": [
  null,
  "لا يمكن إزالة الأخير"
 ],
 "Last disk can not be removed": [
  null,
  "لا بمكن إزالة القرص الأخير"
 ],
 "Last modified: $0": [
  null,
  "آخر تعديل: $0"
 ],
 "Layout": [
  null,
  "التخطيط"
 ],
 "Learn more": [
  null,
  "اعرف المزيد"
 ],
 "Limit size": [
  null,
  "حجم القيد"
 ],
 "Limit virtual filesystem size": [
  null,
  "تقييد حجم نظام الملفات الافتراضي"
 ],
 "Linear": [
  null,
  "خطي"
 ],
 "Linux filesystem data": [
  null,
  "بيانات نظام ملفات Linux"
 ],
 "Linux swap space": [
  null,
  "سعة Linux swap"
 ],
 "Loading system modifications...": [
  null,
  "تحميل تعديلات النظام..."
 ],
 "Loading...": [
  null,
  "قيد التحميل..."
 ],
 "Local mount point": [
  null,
  "نقطة تركيب محلية"
 ],
 "Local storage": [
  null,
  "التخزين المحلي"
 ],
 "Location": [
  null,
  "الموقع"
 ],
 "Lock": [
  null,
  "قفل"
 ],
 "Lock $0?": [
  null,
  "قفل $0؟"
 ],
 "Locked data": [
  null,
  "بيانات مقفلة"
 ],
 "Locked encrypted device might contain data": [
  null,
  "قد يحتوي الجهاز المشفّر المقفل على بيانات"
 ],
 "Locking $target": [
  null,
  "قفل $target"
 ],
 "Log in": [
  null,
  "تسجيل الدخول"
 ],
 "Log in to $0": [
  null,
  "تسجيل الدخول إلى $0"
 ],
 "Log messages": [
  null,
  "رسالة طويلة"
 ],
 "Logical": [
  null,
  "منطقي"
 ],
 "Logical Volume Manager partition": [
  null,
  "مدير أقسام وحدات التقسيم المنطقية"
 ],
 "Logical size": [
  null,
  "الحجم المنطقي"
 ],
 "Logical volume": [
  null,
  "وحدة تخزين منطقية"
 ],
 "Logical volume (snapshot)": [
  null,
  "وحدة تخزين منطقية (ملتقطة)"
 ],
 "Logical volume of $0": [
  null,
  "وحدة تخزين منطقية من $0"
 ],
 "Login failed": [
  null,
  "فشل تسجيل الدخول"
 ],
 "Low profile desktop": [
  null,
  "ملف سطح مكتب منخفض"
 ],
 "Lunch box": [
  null,
  "صندوق التشغيل"
 ],
 "MDRAID device": [
  null,
  "جهاز MDRAID"
 ],
 "MDRAID device $0": [
  null,
  "جهاز MDRAID $0"
 ],
 "MDRAID device is recovering": [
  null,
  "جهاز MDRAID قيد الاسترداد"
 ],
 "MDRAID device must be running": [
  null,
  "جهاز MDRAID يجب أن يعمل"
 ],
 "MDRAID disk": [
  null,
  "قرص MDRAID"
 ],
 "MDRAID disks": [
  null,
  "أقراص MDRAID"
 ],
 "Main server chassis": [
  null,
  "هيكل الخادم الرئيسي"
 ],
 "Manage storage": [
  null,
  "إدارة التخزين"
 ],
 "Manually": [
  null,
  "يدوياً"
 ],
 "Marking $target as faulty": [
  null,
  "تصنيف $target كعنصر معطوب"
 ],
 "Media drive": [
  null,
  "قرص وسائط"
 ],
 "Message to logged in users": [
  null,
  "رسالة للمستخدمين النشطين"
 ],
 "Metadata used": [
  null,
  "البيانات الوصفية المستخدمة"
 ],
 "Mini PC": [
  null,
  "حاسب آلي صغير"
 ],
 "Mini tower": [
  null,
  "برج صغير"
 ],
 "Mirrored (RAID 1)": [
  null,
  "النسخ المتطابق (RAID 1)"
 ],
 "Model": [
  null,
  "النموذج"
 ],
 "Modifying $target": [
  null,
  "تعديل $target"
 ],
 "Mount": [
  null,
  "اوصل"
 ],
 "Mount Point": [
  null,
  "نقطة الوصل"
 ],
 "Mount after network becomes available, ignore failure": [
  null,
  "التركيب بعد عودة الشبكة، تجاهل الفشل"
 ],
 "Mount also automatically on boot": [
  null,
  "التركيب أيضًا يتم تلقائياً عند الإقلاع"
 ],
 "Mount at boot": [
  null,
  "التركيب عند الإقلاع"
 ],
 "Mount automatically on $0 on boot": [
  null,
  "التركيب تلقائياً على $0 عند الإقلاع"
 ],
 "Mount before services start": [
  null,
  "التركيب قبل بدء الخدمات"
 ],
 "Mount configuration": [
  null,
  "تهيئة التركيب"
 ],
 "Mount filesystem": [
  null,
  "تركيبز نظام الملفات"
 ],
 "Mount now": [
  null,
  "التركيب الآن"
 ],
 "Mount on $0 now": [
  null,
  "التركيب على $0 الآن"
 ],
 "Mount options": [
  null,
  "خيارات الوصل"
 ],
 "Mount point": [
  null,
  "نقطة وصل"
 ],
 "Mount point cannot be empty": [
  null,
  "نقطة التركيب لا يمكن تركها فارغة"
 ],
 "Mount point cannot be empty.": [
  null,
  "نقطة التركيب لا يمكن تركها فارغة."
 ],
 "Mount point is already used for $0": [
  null,
  "نقطة التركيب مستخدمة بالفعل من $0"
 ],
 "Mount point must start with \"/\".": [
  null,
  "نقطة التركيب يجب أن تبدأ مع \"/\"."
 ],
 "Mount read only": [
  null,
  "تركيب للقراءة فقط"
 ],
 "Mount without waiting, ignore failure": [
  null,
  "التركيب دون انتظار، تجاهل الفشل"
 ],
 "Mounting $target": [
  null,
  "تركيب $target"
 ],
 "Mounts before services start": [
  null,
  "التركيبات قبل بدء الخدمات"
 ],
 "Mounts in parallel with services": [
  null,
  "‏‎التركيبات بالتوازي مع الخدمات"
 ],
 "Mounts in parallel with services, but after network is available": [
  null,
  "التركيبات تبدأ بالتوازي مع الخدمات، لكن بعد توفر الشبكة"
 ],
 "Multi-system chassis": [
  null,
  "هيكل متعدد الأنظمة"
 ],
 "Multipathed devices": [
  null,
  "الأجهزة متعددة الشرائح"
 ],
 "NFS mount": [
  null,
  "تركيب NFS"
 ],
 "NTP server": [
  null,
  "خادم NTP"
 ],
 "Name": [
  null,
  "الاسم"
 ],
 "Name can not be empty.": [
  null,
  "الاسم لا يمكن أن يكون فارغاً."
 ],
 "Name cannot be empty.": [
  null,
  "لا يمكن ترك الاسم فارغاً."
 ],
 "Name cannot be longer than $0 bytes": [
  null,
  "لا يمكن أن يكون الاسم أطول من $0 بايت"
 ],
 "Name cannot be longer than $0 characters": [
  null,
  "لا يمكن أن يكون الاسم أطول من $0 حرف"
 ],
 "Name cannot be longer than 127 characters.": [
  null,
  "لا يمكن أن يكون الاسم أطول من 127 حرف."
 ],
 "Name cannot be longer than 255 characters.": [
  null,
  "الاسم لا يمكن أن يكون أطول من ٢٥٥ حرفاً."
 ],
 "Name cannot contain the character '$0'.": [
  null,
  "لا يمكن أن يتضمن الإسم المحرف \"$0\"."
 ],
 "Name cannot contain the character '/'.": [
  null,
  "الاسم لا يمكن أن يحتوي على '/'."
 ],
 "Name cannot contain whitespace.": [
  null,
  "لا يمكن أن يتضمن الاسم."
 ],
 "Need a spare disk": [
  null,
  "بحاجة إلى قرص احتياطي"
 ],
 "Need at least one NTP server": [
  null,
  "يحتاج خادم NTP واحداً على الأقل"
 ],
 "Networked storage": [
  null,
  "الشبكات المخزنة"
 ],
 "Networking": [
  null,
  "التشبيك"
 ],
 "New NFS mount": [
  null,
  "تركيب NFS جديد"
 ],
 "New passphrase": [
  null,
  "عبارة المرور الجديدة"
 ],
 "New password was not accepted": [
  null,
  "كلمة السر الجديدة لم تقبل"
 ],
 "Next": [
  null,
  "التالي"
 ],
 "No available slots": [
  null,
  "لا فُتحات متاحة"
 ],
 "No block devices are available.": [
  null,
  "لا أجهزة كتلة متوفرة."
 ],
 "No block devices found": [
  null,
  "لم يتم إيجاد أجهزة كتلة"
 ],
 "No delay": [
  null,
  "لا تأخير"
 ],
 "No devices found": [
  null,
  "لم يتم إيجاد أجهزة"
 ],
 "No disks are available.": [
  null,
  "لا يوجد أقراص متاحة."
 ],
 "No disks found": [
  null,
  "لا يوجد أقراص"
 ],
 "No drives found": [
  null,
  "لا يوجد أجهزة"
 ],
 "No encryption": [
  null,
  "‪لا تشفير"
 ],
 "No filesystem": [
  null,
  "لا نظام ملفات"
 ],
 "No filesystems": [
  null,
  "لا أنظمة ملفات"
 ],
 "No free key slots": [
  null,
  "لا توجد فتحات مفاتيح متاحة"
 ],
 "No free space": [
  null,
  "لا مساحة حرة"
 ],
 "No free space after this partition": [
  null,
  "لا مساحة حرة بعد هذا القسم"
 ],
 "No keys added": [
  null,
  "لا مفاتيح مضافة"
 ],
 "No logical volumes": [
  null,
  "لا وحدات تخزين منطقية"
 ],
 "No media inserted": [
  null,
  "لا وسائط مدرجة"
 ],
 "No partitioning": [
  null,
  "لا تقسيم"
 ],
 "No partitions found": [
  null,
  "لم يتم العثور على أي أقسام"
 ],
 "No physical volumes found": [
  null,
  "لا يوجد وحدة تخزين فيزيائية"
 ],
 "No results found": [
  null,
  "لم يعثر على نتائج"
 ],
 "No snapshots found": [
  null,
  "لا يوجد لقطات"
 ],
 "No storage found": [
  null,
  "لا بوجد تخزين"
 ],
 "No subvolumes": [
  null,
  "لا وحظات تخزين فرعية"
 ],
 "No such file or directory": [
  null,
  "لا ملف أو مجلد من هذا النوع"
 ],
 "No system modifications": [
  null,
  "لا يوجد تعديلات على النظام"
 ],
 "Not a valid private key": [
  null,
  "مفتاح خاص غير صالح"
 ],
 "Not enough free space": [
  null,
  "لا مساحة تخزين كافية"
 ],
 "Not enough space": [
  null,
  "لا مساحة كافية"
 ],
 "Not enough space to grow": [
  null,
  "لا يوجد مساحة كافية للزيادة"
 ],
 "Not found": [
  null,
  "غير موجود"
 ],
 "Not permitted to perform this action.": [
  null,
  "غير مصرح لك بهذا الإجراء."
 ],
 "Not running": [
  null,
  "لا يعمل"
 ],
 "Not synchronized": [
  null,
  "غير مزامن"
 ],
 "Notebook": [
  null,
  "محرر النصوص"
 ],
 "Number of bad sectors": [
  null,
  "عدد القطاعات التالفة"
 ],
 "Occurrences": [
  null,
  "الحوادث"
 ],
 "Ok": [
  null,
  "موافق"
 ],
 "Old passphrase": [
  null,
  "عبارة المرور القديمة"
 ],
 "Old password not accepted": [
  null,
  "كلمة السر القديمة غير مطابقة"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "بمجرد تثبيت Cockpit، قم بتمكينه باستخدام ”systemctl enable --now cockpit.socket“."
 ],
 "Only $0 of $1 are used.": [
  null,
  "فقط $0 من $1 مستخدم."
 ],
 "Operation '$operation' on $target": [
  null,
  "العملية '$operation' على '$target'"
 ],
 "Options": [
  null,
  "الخيارات"
 ],
 "Other": [
  null,
  "أُخرى"
 ],
 "Overprovisioning": [
  null,
  "التوفير الزائد"
 ],
 "Overwrite": [
  null,
  "الكتابة فوق"
 ],
 "Overwrite existing data with zeros (slower)": [
  null,
  "الكتابة فوق البيانات الموجودة بأصفار (أبطأ)"
 ],
 "PID": [
  null,
  "PID"
 ],
 "PackageKit crashed": [
  null,
  "تعطيل PackageKit"
 ],
 "Partition": [
  null,
  "قسم"
 ],
 "Partition of $0": [
  null,
  "قسم $0"
 ],
 "Partition size is $0. Content size is $1.": [
  null,
  "حجم القسم $0. حجم المحتوى $1."
 ],
 "Partitioning": [
  null,
  "التقسم"
 ],
 "Partitions": [
  null,
  "الأقسام"
 ],
 "Partitions are not supported on this block device. If it is used as a disk for a virtual machine, the partitions must be managed by the operating system inside the virtual machine.": [
  null,
  "الأقسام غير مدعومة على جهاز الكتلة هذا. إذا تم استخدامه كقرص لجهاز افتراضي، يجب إدارة الأقسام عبر نظام التشغيل داخل الجهاز الافتراضي."
 ],
 "Passphrase": [
  null,
  "عبارة المرور"
 ],
 "Passphrase can not be empty": [
  null,
  "عبارة المرور لا يمكن أن تكون فارغة"
 ],
 "Passphrase cannot be empty": [
  null,
  "عبارة المرور لا يمكن تركها فارغة"
 ],
 "Passphrase from any other key slot": [
  null,
  "عبارة المرور من أي فتحة مفتاح آخر"
 ],
 "Passphrase removal may prevent unlocking $0.": [
  null,
  "قد تؤدي إزالة عبارة المرور إلى منع إلغاء قفل $0."
 ],
 "Passphrases do not match": [
  null,
  "عبارتا المرور غير متطابقتين"
 ],
 "Password": [
  null,
  "كلمة السر"
 ],
 "Password is not acceptable": [
  null,
  "كلمة السر غير مقبولة"
 ],
 "Password is too weak": [
  null,
  "كلمة السر ضعيفة جداً"
 ],
 "Password not accepted": [
  null,
  "كلمة السر مرفوضة"
 ],
 "Paste": [
  null,
  "لصق"
 ],
 "Paste error": [
  null,
  "خطأ في اللصق"
 ],
 "Path on server": [
  null,
  "المسار على الخادم"
 ],
 "Path on server cannot be empty.": [
  null,
  "المسار على الخادم لا يمكن أن يكون فارغاً."
 ],
 "Path on server must start with \"/\".": [
  null,
  "المسار على الخادم يجب أن يبدأ مع \"/\"."
 ],
 "Path to file": [
  null,
  "المسار إلى الملف"
 ],
 "Peripheral chassis": [
  null,
  "هيكل الأجهزة الطرفية"
 ],
 "Permanently delete $0?": [
  null,
  "متأكد من حذف $0؟"
 ],
 "Permanently delete logical volume $0/$1?": [
  null,
  "متأكد من حذف وحدة التخزين المنطقية $0/$1؟"
 ],
 "Permanently delete subvolume $0?": [
  null,
  "متأكد من حذف وحدة التخزين الفرعية $0؟"
 ],
 "Persistent memory has become read-only": [
  null,
  "أصبحت الذاكرة الدائمة في وضع القراءة فقط"
 ],
 "Physical": [
  null,
  "مادي"
 ],
 "Physical Volumes": [
  null,
  "وحدات التخزين المادية"
 ],
 "Physical volumes": [
  null,
  "وحدات التخزين المادية"
 ],
 "Physical volumes can not be resized here": [
  null,
  "وحدات التخزين المادة لا يمكن إعادة تحجيمها هنا"
 ],
 "Pick date": [
  null,
  "اختيار التاريخ والوقت"
 ],
 "Pizza box": [
  null,
  "صندوق البيتزا"
 ],
 "Please unmount them first.": [
  null,
  "الرجاء إلغاء تركيبهم أولاً."
 ],
 "Pool for thin logical volumes": [
  null,
  "مجموعة وحدات تخزين منطقية رقيقة"
 ],
 "Pool for thinly provisioned LVM2 logical volumes": [
  null,
  "مجمع تخزين لوحدات التخزين المنطقية رقيقة التخصيص (LVM2)"
 ],
 "Pool for thinly provisioned volumes": [
  null,
  "مجموعة تخزين لوحدات التخزين المنطقية رقيقة التخصيص"
 ],
 "Pool passphrase": [
  null,
  "مجمع عبارات المرور"
 ],
 "Port": [
  null,
  "منفذ"
 ],
 "Portable": [
  null,
  "متنقل"
 ],
 "Power on hours": [
  null,
  "ساعات التشغيل"
 ],
 "PowerPC PReP boot partition": [
  null,
  "قسم إقلاع PowerPC PReP"
 ],
 "Present": [
  null,
  "موجود"
 ],
 "Processes using the location": [
  null,
  "عمليات تستخدم الموقع"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "انتهت مهلة الطلب عبر ssh-add"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "انتهت مهلة الطلب عبر ssh-keygen"
 ],
 "Provide the passphrase for the pool on these block devices:": [
  null,
  "قدّم عبارة المرور لمجمع التخزين على أجهزة الكتل هذه:"
 ],
 "Purpose": [
  null,
  "الغرض"
 ],
 "RAID ($0)": [
  null,
  "RAID ($0)"
 ],
 "RAID 0": [
  null,
  "RAID 0"
 ],
 "RAID 0 (stripe)": [
  null,
  "RAID 0 (تجزيء)"
 ],
 "RAID 1": [
  null,
  "RAID 1"
 ],
 "RAID 1 (mirror)": [
  null,
  "RAID 1 (مرآة)"
 ],
 "RAID 10": [
  null,
  "RAID 10"
 ],
 "RAID 10 (stripe of mirrors)": [
  null,
  "RAID 10 (تجزيء المرايا)"
 ],
 "RAID 4": [
  null,
  "RAID 4"
 ],
 "RAID 4 (dedicated parity)": [
  null,
  "RAID 4 (تعادل مخصص)"
 ],
 "RAID 5": [
  null,
  "RAID 5"
 ],
 "RAID 5 (distributed parity)": [
  null,
  "RAID 5 (تعادل مخصص)"
 ],
 "RAID 6": [
  null,
  "RAID 6"
 ],
 "RAID 6 (double distributed parity)": [
  null,
  "RAID 6 (تعادل مزدوج موزع)"
 ],
 "RAID chassis": [
  null,
  "هيكل RAID"
 ],
 "RAID level": [
  null,
  "مستوى RAID"
 ],
 "RAID10 needs an even number of physical volumes": [
  null,
  "يتطلب RAID 10 عددًا زوجيًا من الأقراص الفعلية"
 ],
 "Rack mount chassis": [
  null,
  "هيكل مثبت على حامل"
 ],
 "Reading": [
  null,
  "القرآءة"
 ],
 "Reboot": [
  null,
  "إعادة تشغيل"
 ],
 "Recovering": [
  null,
  "الاسترداد"
 ],
 "Recovering MDRAID device $target": [
  null,
  "استعادة جهاز MDRAID $target"
 ],
 "Regenerating initrd": [
  null,
  "إعادة توليد initrd"
 ],
 "Related processes and services will be forcefully stopped.": [
  null,
  "سيتم إيقاف العمليات والخدمات ذات الصلة بالقوة."
 ],
 "Related processes will be forcefully stopped.": [
  null,
  "سيتم إيقاف العمليات ذات الصلة بالقوة."
 ],
 "Related services will be forcefully stopped.": [
  null,
  "سيتم إيقاف الخدمات ذات الصلة بالقوة."
 ],
 "Removals:": [
  null,
  "عمليات الإزالة:"
 ],
 "Remove": [
  null,
  "إزالة"
 ],
 "Remove $0?": [
  null,
  "إزالة $0؟"
 ],
 "Remove Tang keyserver?": [
  null,
  "إزالة خادم مفاتيح Tang؟"
 ],
 "Remove device": [
  null,
  "إزالة الجهاز"
 ],
 "Remove missing physical volumes?": [
  null,
  "إزالة الأقراص المادية المفقودة؟"
 ],
 "Remove passphrase in key slot $0?": [
  null,
  "إزالة عبارة المرور في مفتاح فتحة $0؟"
 ],
 "Remove passphrase?": [
  null,
  "إزالة عبارة المرور؟"
 ],
 "Removing $0": [
  null,
  "قيد إزالة $0"
 ],
 "Removing $target from MDRAID device": [
  null,
  "إزالة $target من جهاز MDRAID"
 ],
 "Removing a passphrase without confirmation of another passphrase may prevent unlocking or key management, if other passphrases are forgotten or lost.": [
  null,
  "قد تؤدي إزالة عبارة المرور دون تأكيد عبارة مرور أخرى إلى منع فتح القفل أو إدارة المفاتيح، في حالة نسيان أو فقدان غيرها."
 ],
 "Removing physical volume from $target": [
  null,
  "إزالة وحدة التخزين المادية من $target"
 ],
 "Rename": [
  null,
  "أعد التسمية"
 ],
 "Rename Stratis pool": [
  null,
  "إعادة تسمية مجمع Stratis"
 ],
 "Rename filesystem": [
  null,
  "إعادة تسمية نظام الملفات"
 ],
 "Rename logical volume": [
  null,
  "إعادة تسمية وحدة التخزين المنطقية"
 ],
 "Rename volume group": [
  null,
  "إعادة تسمية مجموعة وحدات تخزين"
 ],
 "Renaming $target": [
  null,
  "إعادة تسمية $target"
 ],
 "Repair": [
  null,
  "الإصلاح"
 ],
 "Repair logical volume $0": [
  null,
  "إصلاح وحدة التخزين المنطقية $0"
 ],
 "Repairing $target": [
  null,
  "إصلاح $target"
 ],
 "Repeat passphrase": [
  null,
  "تكرار عبارة المرور"
 ],
 "Resizing $target": [
  null,
  "إعادة تحجيم $target"
 ],
 "Resizing an encrypted filesystem requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "يتطلب تغيير حجم نظام الملفات المشفر إلغاء تأمين القرص. يرجى تقديم عبارة مرور القرص الحالية."
 ],
 "Reuse existing encryption": [
  null,
  "إعادة استخدام التشفير الموجود"
 ],
 "Reuse existing encryption ($0)": [
  null,
  "إعادة استخدام التشفير الموجود ($0)"
 ],
 "Row expansion": [
  null,
  "توسعة الصف"
 ],
 "Row select": [
  null,
  "حدد الصف"
 ],
 "Run extended test": [
  null,
  "إجراء اختبار موسع"
 ],
 "Run short test": [
  null,
  "إجراء اختبار قصير"
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "قم بتشغيل هذا الأمر عبر شبكة موثوقة أوا مادياً على الجهاز البعيد:"
 ],
 "Running": [
  null,
  "التشغيل"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SHA-1": [
  null,
  "SHA-1"
 ],
 "SHA-256": [
  null,
  "SHA-256"
 ],
 "SMART self-test of $target": [
  null,
  "اختبار ذاتي SMART لـ $target"
 ],
 "SSH key": [
  null,
  "مفتاح SSH"
 ],
 "SSH key login": [
  null,
  "تسجيل دخول عبر مفتاح SSH"
 ],
 "Save": [
  null,
  "حفظ"
 ],
 "Save space by compressing individual blocks with LZ4": [
  null,
  "توفير المساحة عن طريق ضغط الكتل الفردية عبر LZ4"
 ],
 "Save space by storing identical data blocks just once": [
  null,
  "توفير المساحة عن طريق تخزين كتل بيانات متطابقة لمرة واحدة فقط"
 ],
 "Saving a new passphrase requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "يتطلب حفظ عبارة مرور جديدة إلغاء قفل القرص. يرجى تقديم عبارة مرور القرص الحالية."
 ],
 "Sealed-case PC": [
  null,
  "حاسوب شخصي مغلق"
 ],
 "Securely erasing $target": [
  null,
  "جاري المسح الآمن لـ $target"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "إعداد نظام Linux المحسّن للأمان واستكشاف الأخطاء وإصلاحها"
 ],
 "Select an option": [
  null,
  "تحديد خيار"
 ],
 "Select the physical volumes that should be used to repair the logical volume. At least $0 are needed.": [
  null,
  "حدد وحدات التخزين المادبة التي يجب استخدامها لإصلاح وحدة التخزين المنطقية. مطلوب $0 على الأقل."
 ],
 "Self-test status": [
  null,
  "حالة الفحص الذاتي"
 ],
 "Serial number": [
  null,
  "الرقم التسلسلي"
 ],
 "Server": [
  null,
  "خادم"
 ],
 "Server address": [
  null,
  "عنوان خادم"
 ],
 "Server address cannot be empty.": [
  null,
  "عنوان الخادم لا يممن أن يكون فارغاً."
 ],
 "Server cannot be empty.": [
  null,
  "الخادم لا يممن أن يكون فارغاً."
 ],
 "Server has closed the connection.": [
  null,
  "قام الخادم بإغلاق الاتصال."
 ],
 "Service": [
  null,
  "خدمة"
 ],
 "Services using the location": [
  null,
  "خدمات تستخدم الموقع"
 ],
 "Set": [
  null,
  "تعيين"
 ],
 "Set initial size": [
  null,
  "تعيين حجم مبدئي"
 ],
 "Set limit of virtual filesystem size": [
  null,
  "تعيين الحد لحجم نظام الملفات الافتراضي"
 ],
 "Set partition type of $0": [
  null,
  "تعيين نوع القسم لـ $0"
 ],
 "Set time": [
  null,
  "تعيين الوقت"
 ],
 "Setting up loop device $target": [
  null,
  "جاري إعداد جهاز الحلقة $target"
 ],
 "Shell script": [
  null,
  "سكريبت شِل"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show all $0 rows": [
  null,
  "إظهار كل الصفوف الـ $0"
 ],
 "Show confirmation password": [
  null,
  "إظهار تأكيد كلمة السر"
 ],
 "Show password": [
  null,
  "أظهر كلمة السر"
 ],
 "Shrink": [
  null,
  "قلّص"
 ],
 "Shrink logical volume": [
  null,
  "قلّص وحدة التخزين المنطقية"
 ],
 "Shrink partition": [
  null,
  "قلِّص القسم"
 ],
 "Shrink volume": [
  null,
  "قلِّص وحدة التخزين"
 ],
 "Shut down": [
  null,
  "أوقف التشغيل"
 ],
 "Single rank": [
  null,
  "رتبة واحدة"
 ],
 "Size": [
  null,
  "الحجم"
 ],
 "Size cannot be negative": [
  null,
  "الحجم لا يمكن أن يكون عدداً سالباً"
 ],
 "Size cannot be zero": [
  null,
  "الحجم لا يمكن أن يكون صفراً"
 ],
 "Size is too large": [
  null,
  "الحجم كبير جداً"
 ],
 "Size must be a number": [
  null,
  "الحجم يجب أن يكون عدداً"
 ],
 "Size must be at least $0": [
  null,
  "يجب ألا يقل الحجم عن $0"
 ],
 "Slot $0": [
  null,
  "الفتحة $0"
 ],
 "Snapshot": [
  null,
  "لقطة نظام"
 ],
 "Snapshot origin": [
  null,
  "مصدر اللقطة"
 ],
 "Snapshots": [
  null,
  "اللقطات"
 ],
 "Solid State Drive": [
  null,
  "قرص الحالة الصلبة"
 ],
 "Some block devices of this pool have grown in size after the pool was created. The pool can be safely grown to use the newly available space.": [
  null,
  "بعض أجهزة الكتل في مجمّع التخزين هذا قد زاد حجمها بعد إنشائه.. يمكن توسيع المجمع بأمان لاستخدام المساحة المتاحة الجديدة."
 ],
 "Sorry": [
  null,
  "عذراً"
 ],
 "Space-saving computer": [
  null,
  "حاسوب موفر للمساحة"
 ],
 "Spare": [
  null,
  "احتياطي"
 ],
 "Spare capacity is below the threshold": [
  null,
  "السعة الاحتياطية أقل من الحد الأدنى"
 ],
 "Specific time": [
  null,
  "الوقت المحدد"
 ],
 "Start": [
  null,
  "بدء"
 ],
 "Start multipath": [
  null,
  "بدء التشغيل متعدد المسارات"
 ],
 "Started": [
  null,
  "بدأ"
 ],
 "Starting MDRAID device $target": [
  null,
  "بدء جهاز MDRAID $target"
 ],
 "Starting swapspace $target": [
  null,
  "تشغيل مساحة swap $target"
 ],
 "State": [
  null,
  "حالة"
 ],
 "Stick PC": [
  null,
  "حاسوب عصا"
 ],
 "Stop": [
  null,
  "إيقاف"
 ],
 "Stop and remove": [
  null,
  "إيقاف ثم إزالة"
 ],
 "Stop and unmount": [
  null,
  "إيقاف ثم إزالة تركيب"
 ],
 "Stop device": [
  null,
  "إيقاف الجهاز"
 ],
 "Stopping MDRAID device $target": [
  null,
  "إيقاف جهاز MDRAID$target"
 ],
 "Stopping swapspace $target": [
  null,
  "إيقاف مساحة swap $target"
 ],
 "Storage": [
  null,
  "التخزين"
 ],
 "Storage can not be managed on this system.": [
  null,
  "لا يمكن إدارة التخزين على هذا النظام."
 ],
 "Storage logs": [
  null,
  "سجلات التخزين"
 ],
 "Store passphrase": [
  null,
  "تخزين عبارة المرور"
 ],
 "Stored passphrase": [
  null,
  "عبارة المرور مخزنة"
 ],
 "Stratis block device": [
  null,
  "جهاز كتلة ثابت"
 ],
 "Stratis block devices": [
  null,
  "أجهزة كتلة ثابتة"
 ],
 "Stratis blockdevs can not be made smaller": [
  null,
  "لا يمكن تقليص حجم أجهزة الكتل (blockdevs) في نظام Stratis"
 ],
 "Stratis filesystem": [
  null,
  "نظام ملفات Stratis"
 ],
 "Stratis filesystems": [
  null,
  "أنظمة ملفات Stratis"
 ],
 "Stratis filesystems pool": [
  null,
  "مجمع أنظمة ملفات Stratis"
 ],
 "Stratis pool": [
  null,
  "مجمع Stratis"
 ],
 "Striped (RAID 0)": [
  null,
  "مخطط (RAID 0)"
 ],
 "Striped and mirrored (RAID 10)": [
  null,
  "مخطط ومرآة (RAID 10)‎"
 ],
 "Stripes": [
  null,
  "stripes"
 ],
 "Strong password": [
  null,
  "كلمة سر قوية"
 ],
 "Sub-Chassis": [
  null,
  "الهيكل الفرعي"
 ],
 "Sub-Notebook": [
  null,
  "دفتر ملاحظات فرعي"
 ],
 "Successful": [
  null,
  "ناجح"
 ],
 "Successfully copied to clipboard!": [
  null,
  "تم النسخ بنجاح إلى الحافظة!"
 ],
 "Swap": [
  null,
  "Swap"
 ],
 "Swap can not be resized here": [
  null,
  "لا يمكن إعادة تحجيم Swap هنا"
 ],
 "Synchronized": [
  null,
  "متزامن"
 ],
 "Synchronized with $0": [
  null,
  "متزامن مع $0"
 ],
 "Synchronizing": [
  null,
  "جار المزامنة"
 ],
 "Synchronizing MDRAID device $target": [
  null,
  "مزامنة جهاز MDRAID $target"
 ],
 "Tablet": [
  null,
  "جهاز لوحي"
 ],
 "Tang keyserver": [
  null,
  "خادم مفتاح Tang"
 ],
 "Target": [
  null,
  "الهدف"
 ],
 "Temperature outside of recommended thresholds": [
  null,
  "درجة الحرارة خارج الحدود الموصى بها"
 ],
 "The $0 package is not available from any repository.": [
  null,
  "الحزمة $0 غير متاحة على أي مستودع."
 ],
 "The $0 package must be installed to create Stratis pools.": [
  null,
  "يجب أن تكزن الحزمة $0 مثبتة لإنشاء مجاميع Stratis."
 ],
 "The $0 package must be installed.": [
  null,
  "الحزمة $0 يجب أن تكون مثبتة."
 ],
 "The $0 package will be installed to create VDO devices.": [
  null,
  "سيتم تثبيت الحزمة $0 لإنشاء أجهزة VDO."
 ],
 "The MDRAID device is in a degraded state": [
  null,
  "جهاز MDRAID في حالة متدهورة"
 ],
 "The MDRAID device must be running": [
  null,
  "يجب أن يكون جهاز MDRAID قيد العمل"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "سيتم إضافة مفتاح SSH $0 الخاص بـ $1 على $2 إلى ملف $3 الخاص بـ $4 على $5."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "سيكون مفتاح SSH $0 متاحًا لبقية الجلسة وسيكون متاحًا لتسجيل الدخول إلى مضيفين آخرين أيضًا."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "مفتاح SSH لتسجيل الدخول إلى $0 محمي بكلمة سر، ولا يسمح المضيف بتسجيل الدخول بكلمة سر. يرجى تقديم كلمة سر المفتاح في $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "مفتاح SSH لتسجيل الدخول إلى $0 محمي. يمكنك تسجيل الدخول إما باستخدام كلمة سر تسجيل الدخول الخاصة بك أو عن طريق توفير كلمة سر المفتاح في $1."
 ],
 "The creation of this VDO device did not finish and the device can't be used.": [
  null,
  "لم يتم الانتهاء من إنشاء جهاز VDO هذا ولا يمكن استخدام الجهاز."
 ],
 "The currently logged in user is not permitted to see information about keys.": [
  null,
  "لا يُسمح للمستخدم الذي قام بتسجيل الدخول حالياً بالاطلاع على معلومات تخص المفاتيح."
 ],
 "The disk needs to be unlocked before formatting. Please provide an existing passphrase.": [
  null,
  "يجب إلغاء قفل القرص قبل التهيئة. يرجى تقديم عبارة مرور موجودة."
 ],
 "The filesystem has no assigned mount point.": [
  null,
  "لا يحوي نظام الملفات على نقطة تحميل معيّنة."
 ],
 "The filesystem has no permanent mount point.": [
  null,
  "لا يحوي نظام الملفات على نقطة تحميل دائمة."
 ],
 "The filesystem is configured to be automatically mounted on boot but its encryption container will not be unlocked at that time.": [
  null,
  "تم إعداد نظام الملفات ليتم تركيبه تلقائيًاً عند الإقلاع ، لكن لن يتم إلغاء قفل حاوية التشفير الخاصة به في ذلك الوقت."
 ],
 "The filesystem is currently mounted but will not be mounted after the next boot.": [
  null,
  "نظام الملفات مركَّب حاليًا لكن لن يتم تركيبه بعد الإقلاع التالي."
 ],
 "The filesystem is currently mounted on $0 but will be mounted on $1 on the next boot.": [
  null,
  "نظام الملفات مركَّب حاليًا على $0 ولكن سيتم تثبيته على $1 عند الإقلاع التالي."
 ],
 "The filesystem is currently mounted on $0 but will not be mounted after the next boot.": [
  null,
  "نظام الملفات مثبت حاليًا على $0 لكن لن يتم تثبيته بعد الإقلاع التالي."
 ],
 "The filesystem is currently not mounted but will be mounted on the next boot.": [
  null,
  "نظام الملفات غير مركّب حالياً لكن سيتم تركيبه عند الإقلاع التالي."
 ],
 "The filesystem is not mounted.": [
  null,
  "نظام الملفات غير مركَّب."
 ],
 "The filesystem will be unlocked and mounted on the next boot. This might require inputting a passphrase.": [
  null,
  "سيتم فتح نظام الملفات وتركيبه عند الإقلاع التالي. قد يتطلب ذلك إدخال عبارة مرور."
 ],
 "The fingerprint should match:": [
  null,
  "ينبغي أن تتطابق البصمة:"
 ],
 "The initrd must be regenerated.": [
  null,
  "يجب إعادة توليظ initrd."
 ],
 "The key password can not be empty": [
  null,
  "مفتاح كلمة السر لا يمكن أن يكون فارغاً"
 ],
 "The key passwords do not match": [
  null,
  "كلمات المرور الرئيسية غير متطابقة"
 ],
 "The last key slot can not be removed": [
  null,
  "لا يمكن إزالة فتحة المفتاح الأخير"
 ],
 "The last mounted subvolume can not be deleted": [
  null,
  "لا يمكن حذف آخر وحدة تخزين فرعية مركَّبة"
 ],
 "The listed processes and services will be forcefully stopped.": [
  null,
  "سيتم إيقاف العمليات والخدمات المدرجة بالقوة."
 ],
 "The listed processes will be forcefully stopped.": [
  null,
  "سيتم إيقاف العمليات المدرجة بالقوة."
 ],
 "The listed services will be forcefully stopped.": [
  null,
  "سيتم إيقاف الخدمات المدرجة بالقوة."
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "لا يُسمح للمستخدم الذي قام بتسجيل الدخول بعرض تعديلات النظام"
 ],
 "The mount point $0 is in use by these processes:": [
  null,
  "نقطة التركيب $0 مستخدمة من قبل هذه العمليات:"
 ],
 "The mount point $0 is in use by these services:": [
  null,
  "نقطة التركيب $0 مستخدمة من قبل هذه الخدمات:"
 ],
 "The password can not be empty": [
  null,
  "كلمة السر لا بمكن أن تكون فارغة"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "لا بأس بمشاركة البصمة الناتجة عبر الطرق العامة، بما في ذلك البريد الإلكتروني."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "بصمة المفتاح الناتجة آمنة للمشاركة عبر قنوات عامة، بما في ذلك البريد الإلكتروني."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "رفض الخادم المصادقة بأي طريقة مدعومة."
 ],
 "The system does not currently support unlocking a filesystem with a Tang keyserver during boot.": [
  null,
  "النظام لا يدعم حاليًا فتح نظام ملفات مشفر باستخدام خادم مفاتيح Tang أثناء الإقلاع."
 ],
 "The system does not currently support unlocking the root filesystem with a Tang keyserver.": [
  null,
  "النظام لا يدعم حاليًا فك تشفير نظام الملفات الجذر باستخدام خادم مفاتيح Tang."
 ],
 "There are devices with multiple paths on the system, but the multipath service is not running.": [
  null,
  "توجد أجهزة ذات مسارات متعددة على النظام، إلا أن خدمة تعدد المسارات لا تعمل."
 ],
 "There is not enough space available that could be used for a repair. At least $0 are needed on physical volumes that are not already used for this logical volume.": [
  null,
  "لا توجد مساحة كافية متاحة يمكن استخدامها للإصلاح. يلزم وجود مساحة لا تقل عن $0 على الأقراص المادية غير المستخدمة بالفعل لهذه الوحدة المنطقية."
 ],
 "These additional steps are necessary:": [
  null,
  "هذه الخطوات الإضافية ضرورية:"
 ],
 "These changes will be made:": [
  null,
  "سيتم إجراء هذه التغييرات:"
 ],
 "Thin logical volume": [
  null,
  "وحدة تخزين منطقية رقيقة"
 ],
 "Thinly provisioned LVM2 logical volumes": [
  null,
  "وحدات التخزين المنطقية LVM2 ذات التزويد الرقيق"
 ],
 "This MDRAID device has no write-intent bitmap. Such a bitmap can reduce synchronization times significantly.": [
  null,
  "جهاز MDRAID هذا لا يحتوي على خريطة نوايا الكتابة (write-intent bitmap). وجود مثل هذه الخريطة يمكن أن يقلل أوقات المزامنة بشكل كبير."
 ],
 "This NFS mount is in use and only its options can be changed.": [
  null,
  "نقطة تركيب NFS هذه قيد الاستخدام، ويمكن فقط تعديل خياراتها."
 ],
 "This VDO device does not use all of its backing device.": [
  null,
  "جهاز VDO هذا لا يستخدم كامل مساحة الجهاز الداعم له."
 ],
 "This device can not be used for the installation target.": [
  null,
  "لا يمكن استخدام هذا الجهاز كهدف للتثبيت."
 ],
 "This device is currently in use.": [
  null,
  "هذا الجهاز حالياً قيد الاستخدام."
 ],
 "This keyserver is the only way to unlock the pool and can not be removed.": [
  null,
  "خادم المفاتيح هذا هو الطريقة الوحيدة لإلغاء قفل المجمع ولا يمكن إزالته."
 ],
 "This logical volume has lost some of its physical volumes and can no longer be used. You need to delete it and create a new one to take its place.": [
  null,
  "فقدت وحدة التخزين المنطقية بعض أقراصها المادية ولم تعد صالحة للاستخدام. يجب حذفها وإنشاء وحدة جديدة لتحل محلها."
 ],
 "This logical volume has lost some of its physical volumes but has not lost any data yet. You should repair it to restore its original redundancy.": [
  null,
  "فقدت وحدة التخزين المنطقية بعض أقراصها المادية لكنها لم تفقد أي بيانات بعد. يجب إصلاحها لاستعادة التكرارية الأصلية."
 ],
 "This logical volume has lost some of its physical volumes but might not have lost any data yet. You might be able to repair it.": [
  null,
  "فقدت وحدة التخزين المنطقية بعض أقراصها المادية ، لكن ربما لم تفقد أي بيانات بعد. قد تتمكن من إصلاحها."
 ],
 "This logical volume is not completely used by its content.": [
  null,
  "وحدة التخزين المنطقية هذه غير مستخدمة بالكامل من قبل محتواها."
 ],
 "This partition is not completely used by its content.": [
  null,
  "هذا القسم غير مستخدم بالكامل من قبل محتواه."
 ],
 "This passphrase is the only way to unlock the pool and can not be removed.": [
  null,
  "عبارة المرور هذه هي الطريقة الوحيدة لإلغاء قفل المجمع ولا يمكن إزالتها."
 ],
 "This pool does not use all the space on its block devices.": [
  null,
  "لا يستخدم هذا المجمع كل المساحة الموجودة على أجهزة الكتل الخاصة به."
 ],
 "This pool is in a degraded state.": [
  null,
  "هذا المجمع في حالة متدهورة."
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "تقوم هذه الأداة بتكوين سياسة SELinux ويمكن أن تساعد في فهم انتهاكاتها وحلها."
 ],
 "This tool configures the system to write kernel crash dumps. It supports the \"local\" (disk), \"ssh\", and \"nfs\" dump targets.": [
  null,
  "تُهيئ هذه الأداة النظام لكتابة تفريغ أعطاب نواة النظام. وهي تدعم أهداف التفريغ التالية: \"محلي\" (على القرص)، و\"ssh\"، و\"nfs\"."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "تقوم هذه الأداة بإنشاء أرشيف يحتوي على معلومات الإعدادات والتشخيص من نظام التشغيل الذي يكون قيد العمل. قد يتم تخزين الأرشيف محليًا أو مركزيًا لأغراض التسجيل أو التتبع، أو إرساله إلى ممثلي الدعم الفني أو المطورين أو مسؤولي النظام اعدة في تحديد الأعطال ‌الفنية ، وتصحيح الأخطاء."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "تُدير هذه الأداة التخزين المحلي، بما في ذلك أنظمة الملفات، ومجموعات وحدات التخزين LVM2، ونقاط تركيب NFS."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "تُدير هذه الأداة الشبكات بما في ذلك الوصلات المجمعة (Bonds)، والجسور (Bridges)، وفرق الشبكات (Teams)، وشبكات VLAN، والجدران النارية، باستخدام NetworkManager وFirewalld. يُذكر أن NetworkManager غير متوافق مع نظام systemd-networkd الافتراضي في أوبونتو ونصوص ifupdown في دبيان."
 ],
 "This volume group contains the root filesystem. Renaming it might require further changes to the bootloader configuration or kernel command line.": [
  null,
  "تحوي مجموعة وحدات التخزين هذه على نظام الملفات الجذر. قد تتطلب إعادة تسميته تغييرات أخرى على تهيئة مُحمّل الإقلاع أو سطر أوامر نواة النظام."
 ],
 "This volume group is missing some physical volumes.": [
  null,
  "مجموعة التخزين هذه تفتقد بعض الأقراص المادية."
 ],
 "Tier": [
  null,
  "فئة"
 ],
 "Time zone": [
  null,
  "المنطقة الزمنية"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "لضمان عدم اعتراض اتصالك من قِبَل طرف ثالث ضار، يُرجى التحقق من بَصمة مفتاح الخادم:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "للتحقق من البصمة ، قم بتشغيل ما يلي على $0 أثناء تشغيل الجهاز أو من خلال شبكة موثوقة:"
 ],
 "Toggle date picker": [
  null,
  "إخفاء منتقي التاريخ و الوقت"
 ],
 "Too much data": [
  null,
  "الكثير من البيانات"
 ],
 "Total size: $0": [
  null,
  "الحجم الإجمالي: $0"
 ],
 "Tower": [
  null,
  "برج"
 ],
 "Trust and add host": [
  null,
  "الثقة بالمضيف وإضافته"
 ],
 "Trust key": [
  null,
  "مفتاح موثوق"
 ],
 "Trying to synchronize with $0": [
  null,
  "محاولة المزامنة مع $0"
 ],
 "Type": [
  null,
  "النوع"
 ],
 "Type can only contain the characters 0 to 9, A to F, and \"-\".": [
  null,
  "يمكن أن يحتوي النوع على الأرقام من 0 إلى 9 والحروف من A إلى F ورمز \"-\" فقط."
 ],
 "Type must be of the form NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN.": [
  null,
  "يجب أن يكون النوع بالشكل التالي: NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN."
 ],
 "Type must contain exactly two hexadecimal characters (0 to 9, A to F).": [
  null,
  "يجب أن يتألف النوع من محرفين ستة عشرية بالضبط (من 0 إلى 9، ومن A إلى F)."
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password.": [
  null,
  "تعذّر تسجيل الدخول إلى $0 باستخدام مصادقة مفتاح SSH. يرجى إدخال كلمة السر."
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "تعذّر تسجيل الدهول إلى $0. لا يقبل المضيف تسجيل الدخول بكلمة سر ، أو أي من مفاتيح SSH الخاصة بك."
 ],
 "Unable to reach server": [
  null,
  "تعذر الوصول إلى الخادم"
 ],
 "Unable to remove mount": [
  null,
  "تعذرت إزالة التركيب"
 ],
 "Unable to repair logical volume $0": [
  null,
  "تعذر إصلاح وحدة التخزين المنطقية $0"
 ],
 "Unable to unmount filesystem": [
  null,
  "تعذر فك تركيب نظام الملفات"
 ],
 "Unexpected PackageKit error during installation of $0: $1": [
  null,
  "حدث خطأ غير متوقّع في PackageKit أثناء تثبيت $0:$1"
 ],
 "Unexpected partitions": [
  null,
  "أقسام غير متوقعة"
 ],
 "Unformatted data": [
  null,
  "بيانات غير منسقة"
 ],
 "Unknown": [
  null,
  "غير معروف"
 ],
 "Unknown ($0)": [
  null,
  "($0) غير معروف"
 ],
 "Unknown host name": [
  null,
  "اسم مضيف غير معروف"
 ],
 "Unknown host: $0": [
  null,
  "مضيف غير معروف: $0"
 ],
 "Unknown type": [
  null,
  "نوع غير معروف"
 ],
 "Unlock": [
  null,
  "ألغِ القفل"
 ],
 "Unlock automatically on boot": [
  null,
  "إلغِ القفل تلقائياً عند الإقلاع"
 ],
 "Unlock before resizing": [
  null,
  "إلغِ القفل قبل إعادة التحجيم"
 ],
 "Unlock encrypted Stratis pool": [
  null,
  "فتح مجمع Stratis المشفر"
 ],
 "Unlocking $target": [
  null,
  "إلغاء قفل $target"
 ],
 "Unlocking disk": [
  null,
  "إلغاء قفل القرص"
 ],
 "Unmount": [
  null,
  "فك تركيب"
 ],
 "Unmount filesystem $0": [
  null,
  "فك تركيب نظام الملفات $0"
 ],
 "Unmount now": [
  null,
  "فك التركيب الآن"
 ],
 "Unmounting $target": [
  null,
  "جاري فك تركيب $target"
 ],
 "Unrecognized data": [
  null,
  "بيانات غير معروفة"
 ],
 "Unrecognized data can not be made smaller here": [
  null,
  "لا يمكن تصغير البيانات غير المعروفة هنا"
 ],
 "Unrecognized data can not be made smaller here.": [
  null,
  "لا يمكن تصغير البيانات غير المعروفة هنا."
 ],
 "Unsupported logical volume": [
  null,
  "وحدة ت=تخزين منطقية غير مدعومة"
 ],
 "Untrusted host": [
  null,
  "مضيف غير موثوق به"
 ],
 "Usage": [
  null,
  "الاستخدام"
 ],
 "Usage of $0": [
  null,
  "استخدام $0"
 ],
 "Use": [
  null,
  "استخدم"
 ],
 "Use $0": [
  null,
  "اشتخدم $0"
 ],
 "Use compression": [
  null,
  "‎استخدام الضغط"
 ],
 "Use deduplication": [
  null,
  "استخدام الاستنساخ المكرر"
 ],
 "Used": [
  null,
  "تم استخدامه"
 ],
 "Useful for mounts that are optional or need interaction (such as passphrases)": [
  null,
  "مفيد للتركيبات الإضافية أو التي تحتاج إلى تفاعل (مثل عبارات المرور)"
 ],
 "User": [
  null,
  "المستخدم"
 ],
 "Username": [
  null,
  "اسم المستخدم"
 ],
 "VDO backing devices can not be made smaller": [
  null,
  "لا يمكن تصغير أجهزة دعم VDO"
 ],
 "VDO device $0": [
  null,
  "جهاز VDO $0"
 ],
 "VDO filesystem volume (compression/deduplication)": [
  null,
  "وحدة تخزين نظام الملفات باستخدام VDO (ميزات الضغط وإزالة النسخ المكرَّر)"
 ],
 "Vendor": [
  null,
  "المُنتِج"
 ],
 "Verify fingerprint": [
  null,
  "أكّد البصمة"
 ],
 "Verify key": [
  null,
  "مفتاح التحقق"
 ],
 "Very securely erasing $target": [
  null,
  "مسح $target بأمان شديد"
 ],
 "View all logs": [
  null,
  "عرض جميع السجلات"
 ],
 "View automation script": [
  null,
  "عرض سكربت الأتمتة"
 ],
 "View logs": [
  null,
  "عرض السجلات"
 ],
 "Virtual filesystem sizes are larger than the pool. Overprovisioning can not be disabled.": [
  null,
  "أحجام أنظمة الملفات الافتراضية أكبر من المخزن. لا يمكن تعطيل التوفير الزائد."
 ],
 "Virtual size": [
  null,
  "الحجم الافتراضي"
 ],
 "Virtual size limit": [
  null,
  "حد الحجم الافتراضي"
 ],
 "Visit firewall": [
  null,
  "زر الجدار الناري"
 ],
 "Volatile memory backup failed": [
  null,
  "فشل النسخ الاحتياطي للذاكرة المتطايرة"
 ],
 "Volume group": [
  null,
  "مجموعة وحدة تحزين"
 ],
 "Volume group is missing physical volumes": [
  null,
  "مجموعة التخزين تفتقد إلى وحدات التخزين المادية"
 ],
 "Volume size is $0. Content size is $1.": [
  null,
  "حجم وحدة التحزين $0. حجم المحتوى $1."
 ],
 "Waiting for other software management operations to finish": [
  null,
  "ينتظر انتهاء عمليات مدير البرامج الآخر"
 ],
 "Weak password": [
  null,
  "كلمة سر ضعيفة"
 ],
 "Web Console for Linux servers": [
  null,
  "وحدة تحكم الويب لخوادم Linux"
 ],
 "World wide name": [
  null,
  "الاسم العالمي"
 ],
 "Write-mostly": [
  null,
  "وضع الكتابة الغالبة"
 ],
 "Writing": [
  null,
  "الكتابة"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "انت تتصل بـ $0 لأول مرة."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "لا يسمح متصفحك باللصق من قائمة السياق. يمكنك استخدام Shift+Insert."
 ],
 "Your session has been terminated.": [
  null,
  "تم إنهاء جلستك."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "انتهت صلاحية جلستك , يرجى تسجيل الدخول مرة أخرى."
 ],
 "Zone": [
  null,
  "المنطقة"
 ],
 "[binary data]": [
  null,
  "[بيانات ثنائية]"
 ],
 "[no data]": [
  null,
  "[لا بيانات]"
 ],
 "after network": [
  null,
  "بعد إعداد الشبكة"
 ],
 "backing device for VDO device": [
  null,
  "جهاز التخزين الأساسي لجهاز VDO"
 ],
 "btrfs device": [
  null,
  "جهاز btrfs"
 ],
 "btrfs devices": [
  null,
  "أجهزة btrfs"
 ],
 "btrfs filesystem": [
  null,
  "نظام ملفات btrfs"
 ],
 "btrfs subvolume": [
  null,
  "وحدة تخزين btrfs فرعية"
 ],
 "btrfs subvolume $0 of $1": [
  null,
  "وحدة تحزين btrfs فرعية $0 لـ $1"
 ],
 "btrfs subvolumes": [
  null,
  "وحدات تخزين btrfs الفرعية"
 ],
 "btrfs volume": [
  null,
  "وحدة تحزيم btrfs"
 ],
 "cache": [
  null,
  "ذاكرة التخزين المؤقت"
 ],
 "data": [
  null,
  "بيانات"
 ],
 "deactivate": [
  null,
  "إِلغاء التنشيط"
 ],
 "delete": [
  null,
  "حذف"
 ],
 "device of btrfs volume": [
  null,
  "جهاز وحدة تخزين btrfs"
 ],
 "edit": [
  null,
  "عدِّل"
 ],
 "encrypted": [
  null,
  "مشفّر"
 ],
 "format": [
  null,
  "تَهيئة"
 ],
 "grow": [
  null,
  "النمو"
 ],
 "iSCSI Drive": [
  null,
  "محرك أقراص iSCSI"
 ],
 "iSCSI drives": [
  null,
  "محركات أقراص iSCSI"
 ],
 "iSCSI portal": [
  null,
  "بوابة iSCSI"
 ],
 "ignore failure": [
  null,
  "تجاهل الفشل"
 ],
 "in less than a minute": [
  null,
  "في أقل من دقيقة"
 ],
 "initialize": [
  null,
  "تمهيد"
 ],
 "less than a minute ago": [
  null,
  "منذ أقل من دقيقة"
 ],
 "lock": [
  null,
  "قفل"
 ],
 "member of MDRAID device": [
  null,
  "عضو في جهاز MDRAID"
 ],
 "member of Stratis pool": [
  null,
  "عضو في مجمع Stratis"
 ],
 "mount": [
  null,
  "ركِّب"
 ],
 "never mount at boot": [
  null,
  "لا تركب أبدًا عند الإقلاع"
 ],
 "none": [
  null,
  "لا شيء"
 ],
 "password quality": [
  null,
  "جودة كلمة السر"
 ],
 "physical volume of LVM2 volume group": [
  null,
  "القرص المادي الخاص بمجموعة وحدة التخزين من نوع LVM2"
 ],
 "read only": [
  null,
  "القراءة فقط"
 ],
 "remove from LVM2": [
  null,
  "إزالة من LVM2"
 ],
 "remove from MDRAID": [
  null,
  "إزالة من MDRAID"
 ],
 "remove from btrfs volume": [
  null,
  "إزالة من وحدة تخزين btrfs"
 ],
 "show less": [
  null,
  "عرض أقل"
 ],
 "show more": [
  null,
  "عرض أكثر"
 ],
 "shrink": [
  null,
  "قلِّص"
 ],
 "snapshot": [
  null,
  "لقطة نظام"
 ],
 "stop": [
  null,
  "توقف"
 ],
 "stop boot on failure": [
  null,
  "إيقاف التشغيل عند الإخفاق"
 ],
 "stopped": [
  null,
  "متوقف"
 ],
 "unknown target": [
  null,
  "هدف غير معروف"
 ],
 "unmount": [
  null,
  "إلغاء التركيب"
 ],
 "unpartitioned space on $0": [
  null,
  "مساحة غير مقسمة على $0"
 ],
 "using key description $0": [
  null,
  "استخدام وصف المفتاح $0"
 ],
 "yes": [
  null,
  "نعم"
 ],
 "format-bytes\u0004bytes": [
  null,
  "بايتات"
 ]
});
