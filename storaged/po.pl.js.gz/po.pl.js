cockpit.locale({
 "": {
  "plural-forms": (n) => n==1 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "pl",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 chunk size": [
  null,
  "Rozmiar bloku: $0"
 ],
 "$0 data + $1 overhead used of $2 ($3)": [
  null,
  "$0 danych + $1 nadwyżki użyto z $2 ($3)"
 ],
 "$0 day": [
  null,
  "$0 dzień",
  "$0 dni",
  "$0 dni"
 ],
 "$0 disk is missing": [
  null,
  "Brak $0 dysku",
  "Brak $0 dysków",
  "Brak $0 dysków"
 ],
 "$0 disks": [
  null,
  "Dyski: $0"
 ],
 "$0 exited with code $1": [
  null,
  "$0 zakończyło działanie z kodem $1"
 ],
 "$0 failed": [
  null,
  "$0 się nie powiodło"
 ],
 "$0 hour": [
  null,
  "$0 godzina",
  "$0 godziny",
  "$0 godzin"
 ],
 "$0 is in use": [
  null,
  "$0 jest używane"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 nie jest dostępne w żadnym repozytorium."
 ],
 "$0 key changed": [
  null,
  "Zmieniono klucz $0"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 zostało zakończone z sygnałem $1"
 ],
 "$0 minute": [
  null,
  "$0 minuta",
  "$0 minuty",
  "$0 minut"
 ],
 "$0 month": [
  null,
  "$0 miesiąc",
  "$0 miesiące",
  "$0 miesięcy"
 ],
 "$0 slot remains": [
  null,
  "$0 pozostałe gniazdo",
  "$0 pozostałe gniazda",
  "$0 pozostałych gniazd"
 ],
 "$0 used of $1 ($2 saved)": [
  null,
  "$0 używanych z $1 ($2 zapisano)"
 ],
 "$0 week": [
  null,
  "$0 tydzień",
  "$0 tygodnie",
  "$0 tygodni"
 ],
 "$0 will be installed.": [
  null,
  "$0 zostanie zainstalowane."
 ],
 "$0 year": [
  null,
  "$0 rok",
  "$0 lata",
  "$0 lat"
 ],
 "$name (from $host)": [
  null,
  "$name (z $host)"
 ],
 "(recommended)": [
  null,
  "(zalecane)"
 ],
 "1 MiB": [
  null,
  "1 MiB"
 ],
 "1 day": [
  null,
  "1 dzień"
 ],
 "1 hour": [
  null,
  "1 godzina"
 ],
 "1 minute": [
  null,
  "1 minuta"
 ],
 "1 week": [
  null,
  "1 tydzień"
 ],
 "128 KiB": [
  null,
  "128 KiB"
 ],
 "16 KiB": [
  null,
  "16 KiB"
 ],
 "2 MiB": [
  null,
  "2 MiB"
 ],
 "20 minutes": [
  null,
  "20 minut"
 ],
 "32 KiB": [
  null,
  "32 KiB"
 ],
 "4 KiB": [
  null,
  "4 KiB"
 ],
 "40 minutes": [
  null,
  "40 minut"
 ],
 "5 minutes": [
  null,
  "5 minut"
 ],
 "512 KiB": [
  null,
  "512 KiB"
 ],
 "6 hours": [
  null,
  "6 godzin"
 ],
 "60 minutes": [
  null,
  "Godzina"
 ],
 "64 KiB": [
  null,
  "64 KiB"
 ],
 "8 KiB": [
  null,
  "8 KiB"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Na $0 nie zainstalowano zgodnej wersji Cockpit."
 ],
 "A fatal error occurred during the self-test operation": [
  null,
  ""
 ],
 "A filesystem with this name exists already in this pool.": [
  null,
  "System plików o tej nazwie już istnieje w tej puli."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Nowy klucz SSH w $0 zostanie utworzony dla użytkownika $1 na komputerze $2 i zostanie dodany do pliku $3 użytkownika $4 na komputerze $5."
 ],
 "A pool with this name exists already.": [
  null,
  "Pula o tej nazwie już istnieje."
 ],
 "Abort test": [
  null,
  ""
 ],
 "Aborted": [
  null,
  ""
 ],
 "Aborted by a Controller Level Reset": [
  null,
  ""
 ],
 "Aborted due to a removal of a namespace from the namespace inventory": [
  null,
  ""
 ],
 "Aborted due to a sanitize operation": [
  null,
  ""
 ],
 "Aborted due to the processing of a Format NVM command": [
  null,
  ""
 ],
 "Aborted for unknown reason": [
  null,
  ""
 ],
 "Absent": [
  null,
  "Nieobecne"
 ],
 "Action": [
  null,
  "Działanie"
 ],
 "Actions": [
  null,
  "Działania"
 ],
 "Activate": [
  null,
  "Aktywuj"
 ],
 "Activate before resizing": [
  null,
  "Aktywuj przed zmianą rozmiaru"
 ],
 "Activating $target": [
  null,
  "Aktywowanie $target"
 ],
 "Add": [
  null,
  "Dodaj"
 ],
 "Add $0": [
  null,
  "Dodaj $0"
 ],
 "Add Network Bound Disk Encryption": [
  null,
  "Dodaj szyfrowanie dysku dowiązanego sieciowo"
 ],
 "Add Tang keyserver": [
  null,
  "Dodaj serwer kluczy Tang"
 ],
 "Add a bitmap": [
  null,
  "Dodaj mapę bitową"
 ],
 "Add block devices": [
  null,
  "Dodaj urządzenia blokowe"
 ],
 "Add disk": [
  null,
  "Dodaj dysk"
 ],
 "Add disks": [
  null,
  "Dodaj dyski"
 ],
 "Add iSCSI portal": [
  null,
  "Dodaj portal iSCSI"
 ],
 "Add key": [
  null,
  "Dodaj klucz"
 ],
 "Add keyserver": [
  null,
  "Dodaj serwer kluczy"
 ],
 "Add passphrase": [
  null,
  "Dodaj hasło"
 ],
 "Adding \"$0\" to encryption options": [
  null,
  "Dodawanie „$0” do opcji szyfrowania"
 ],
 "Adding \"$0\" to filesystem options": [
  null,
  "Dodawanie „$0” do opcji systemów plików"
 ],
 "Adding a keyserver requires unlocking the pool. Please provide the existing pool passphrase.": [
  null,
  "Dodanie serwera kluczy wymaga odblokowania puli. Proszę podać hasło istniejącej puli."
 ],
 "Adding key": [
  null,
  "Dodawanie klucza"
 ],
 "Adding physical volume to $target": [
  null,
  "Dodawanie woluminu fizycznego do $target"
 ],
 "Adding rd.neednet=1 to kernel command line": [
  null,
  "Dodawanie rd.neednet=1 do wiersza poleceń jądra"
 ],
 "Additional packages:": [
  null,
  "Dodatkowe pakiety:"
 ],
 "Address": [
  null,
  "Adres"
 ],
 "Address cannot be empty": [
  null,
  "Adres nie może być pusty"
 ],
 "Address is not a valid URL": [
  null,
  "Adres nie jest prawidłowym adresem URL"
 ],
 "Administration with Cockpit Web Console": [
  null,
  "Administracja za pomocą konsoli internetowej Cockpit"
 ],
 "Advanced TCA": [
  null,
  "Zaawansowane TCA"
 ],
 "All-in-one": [
  null,
  "Wszystko w jednym"
 ],
 "Allow overprovisioning": [
  null,
  ""
 ],
 "An additional $0 must be selected": [
  null,
  "Dodatkowe $0 musi zostać wybrane"
 ],
 "Ansible": [
  null,
  "Ansible"
 ],
 "Ansible roles documentation": [
  null,
  "Dokumentacja ról Ansible"
 ],
 "Appropriate for critical mounts, such as /var": [
  null,
  "Odpowiednie dla krytycznych punktów montowania, takich jak /var"
 ],
 "At boot": [
  null,
  "Podczas uruchamiania"
 ],
 "At least $0 disk is needed.": [
  null,
  "Wymagany jest co najmniej $0 dysk.",
  "Wymagane są co najmniej $0 dyski.",
  "Wymaganych jest co najmniej $0 dysków."
 ],
 "At least one block device is needed.": [
  null,
  "Wymagane jest co najmniej jedno urządzenie blokowe."
 ],
 "At least one disk is needed.": [
  null,
  "Wymagany jest co najmniej jeden dysk."
 ],
 "Authentication": [
  null,
  "Uwierzytelnienie"
 ],
 "Authentication is required to perform privileged tasks with the Cockpit Web Console": [
  null,
  "Wymagane jest uwierzytelnienie, aby wykonać zadania wymagające uprawnień za pomocą konsoli internetowej Cockpit"
 ],
 "Authentication required": [
  null,
  "Wymagane jest uwierzytelnienie"
 ],
 "Authorize SSH key": [
  null,
  "Upoważnij klucz SSH"
 ],
 "Automatically using NTP": [
  null,
  "Automatycznie za pomocą NTP"
 ],
 "Automatically using additional NTP servers": [
  null,
  "Automatycznie za pomocą dodatkowych serwerów NTP"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automatycznie za pomocą podanych serwerów NTP"
 ],
 "Automation script": [
  null,
  "Skrypt automatyzacji"
 ],
 "Available targets on $0": [
  null,
  "Dostępne cele w $0"
 ],
 "Blade": [
  null,
  "Kasetowy"
 ],
 "Blade enclosure": [
  null,
  "Obudowa kasetowa"
 ],
 "Block device": [
  null,
  "Urządzenie blokowe"
 ],
 "Block device for filesystems": [
  null,
  "Urządzenie blokowe dla systemów plików"
 ],
 "Block devices": [
  null,
  "Urządzenia blokowe"
 ],
 "Blocked": [
  null,
  "Zablokowane"
 ],
 "Boot fails if filesystem does not mount, preventing remote access": [
  null,
  "Uruchomienie się nie powiedzie, jeśli system plików nie jest montowany, uniemożliwiając zdalny dostęp"
 ],
 "Boot still succeeds when filesystem does not mount": [
  null,
  "Uruchomienie nadal się powiedzie, kiedy system plików nie jest montowany"
 ],
 "Bus expansion chassis": [
  null,
  "Obudowa rozszerzenia magistrali"
 ],
 "Cache": [
  null,
  "Pamięć podręczna"
 ],
 "Cancel": [
  null,
  "Anuluj"
 ],
 "Cannot forward login credentials": [
  null,
  "Nie można przekazać danych uwierzytelniania logowania"
 ],
 "Cannot schedule event in the past": [
  null,
  "Nie można planować zdarzeń w przeszłości"
 ],
 "Capacity": [
  null,
  "Pojemność"
 ],
 "Category": [
  null,
  "Kategoria"
 ],
 "Change": [
  null,
  "Zmień"
 ],
 "Change iSCSI initiator name": [
  null,
  "Zmień nazwę inicjatora iSCSI"
 ],
 "Change passphrase": [
  null,
  "Zmień hasło"
 ],
 "Change system time": [
  null,
  "Zmień czas systemu"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Zmienione klucze są często wynikiem przeinstalowania systemu operacyjnego. Nieoczekiwana zmiana może jednak wskazywać na próbę przechwycenia połączenia przez stronę trzecią."
 ],
 "Changing partition types might prevent the system from booting.": [
  null,
  "Zmiana typu partycji może nie pozwolić systemowi się uruchomić."
 ],
 "Check that the SHA-256 or SHA-1 hash from the command matches this dialog.": [
  null,
  "Proszę sprawdzić, czy suma SHA-256 lub SHA-1 z wiersza poleceń zgadza się z tą w tym oknie."
 ],
 "Check the key hash with the Tang server.": [
  null,
  "Proszę sprawdzić sumę klucza z serwerem Tang."
 ],
 "Checking $target": [
  null,
  "Sprawdzanie $target"
 ],
 "Checking for $0 package": [
  null,
  "Wyszukiwanie pakietu $0"
 ],
 "Checking for NBDE support in the initrd": [
  null,
  "Wyszukiwanie obsługi NBDE w obrazie initrd"
 ],
 "Checking installed software": [
  null,
  "Sprawdzanie zainstalowanego oprogramowania"
 ],
 "Chunk size": [
  null,
  "Rozmiar bloku"
 ],
 "Cleaning up for $target": [
  null,
  "Czyszczenie dla $target"
 ],
 "Cleartext device": [
  null,
  "Urządzenie tekstowe"
 ],
 "Close": [
  null,
  "Zamknij"
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit configuration of NetworkManager and Firewalld": [
  null,
  "Konfiguracja usług NetworkManager i firewalld w programie Cockpit"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit nie może skontaktować się z podanym komputerem."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit to menedżer serwerów ułatwiający administrowanie serwerów Linux przez przeglądarkę WWW. Można z łatwością przechodzić między terminalem a narzędziami WWW. Usługa uruchomiona za pomocą Cockpit może zostać zatrzymana za pomocą terminala. Jeśli błąd wystąpi w terminalu, to można go zobaczyć w interfejsie dziennika Cockpit."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit nie jest zgodny z oprogramowaniem w systemie."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit nie jest zainstalowany"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit nie jest zainstalowany w systemie."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit jest idealny dla nowych administratorów, umożliwiając łatwe wykonywanie prostych zadań, takich jak administracja urządzeniami do przechowywania danych, badanie dzienników oraz uruchamianie i zatrzymywanie usług. Można monitorować i administrować wiele serwerów w tym samym czasie. Wystarczy dodać je pojedynczym kliknięciem."
 ],
 "Collect and package diagnostic and support data": [
  null,
  "Zbieranie i pakowanie danych diagnostycznych i wsparcia"
 ],
 "Collect kernel crash dumps": [
  null,
  "Zbieranie zrzutów awarii jądra"
 ],
 "Command": [
  null,
  "Polecenie"
 ],
 "Compact PCI": [
  null,
  "Kompaktowe PCI"
 ],
 "Compatible with all systems and devices (MBR)": [
  null,
  "Zgodne ze wszystkimi systemami i urządzeniami (MBR)"
 ],
 "Compatible with modern system and hard disks > 2TB (GPT)": [
  null,
  "Zgodne z nowoczesnymi systemami i dyskami twardymi > 2 TB (GPT)"
 ],
 "Completed with a segment that failed and the segment that failed is not known": [
  null,
  ""
 ],
 "Completed with one or more failed segments": [
  null,
  ""
 ],
 "Compression": [
  null,
  "Kompresja"
 ],
 "Confirm": [
  null,
  "Potwierdź"
 ],
 "Confirm deletion of $0": [
  null,
  "Potwierdź usunięcie $0"
 ],
 "Confirm key password": [
  null,
  "Potwierdź hasło klucza"
 ],
 "Confirm removal with an alternate passphrase": [
  null,
  "Potwierdź usunięcie alternatywnym hasłem"
 ],
 "Confirm stopping of $0": [
  null,
  "Potwierdź zatrzymanie $0"
 ],
 "Connection has timed out.": [
  null,
  "Połączenie przekroczyło czas oczekiwania."
 ],
 "Convertible": [
  null,
  "2 w jednym"
 ],
 "Copied": [
  null,
  "Skopiowano"
 ],
 "Copy": [
  null,
  "Skopiuj"
 ],
 "Copy to clipboard": [
  null,
  "Skopiuj do schowka"
 ],
 "Create": [
  null,
  "Utwórz"
 ],
 "Create LVM2 volume group": [
  null,
  "Utwórz grupę woluminów LVM2"
 ],
 "Create RAID device": [
  null,
  "Utwórz urządzenie RAID"
 ],
 "Create Stratis pool": [
  null,
  "Utwórz pulę Stratis"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Utwórz nowy klucz SSH i go upoważnij"
 ],
 "Create a snapshot of filesystem $0": [
  null,
  "Utwórz migawkę systemu plików $0"
 ],
 "Create and mount": [
  null,
  "Utwórz i zamontuj"
 ],
 "Create filesystem": [
  null,
  "Utwórz system plików"
 ],
 "Create logical volume": [
  null,
  "Utwórz wolumin logiczny"
 ],
 "Create new filesystem": [
  null,
  "Utwórz nowy system plików"
 ],
 "Create new logical volume": [
  null,
  "Utwórz nowy wolumin logiczny"
 ],
 "Create new task file with this content.": [
  null,
  "Utwórz nowy plik zadania o tej treści."
 ],
 "Create only": [
  null,
  "Tylko utwórz"
 ],
 "Create partition": [
  null,
  "Utwórz partycję"
 ],
 "Create partition on $0": [
  null,
  "Utwórz partycję na $0"
 ],
 "Create partition table": [
  null,
  "Utwórz tablicę partycji"
 ],
 "Create snapshot": [
  null,
  "Utwórz migawkę"
 ],
 "Create snapshot and mount": [
  null,
  "Utwórz migawkę i zamontuj"
 ],
 "Create snapshot only": [
  null,
  "Tylko utwórz migawkę"
 ],
 "Create thin volume": [
  null,
  "Utwórz cienki wolumin"
 ],
 "Create volume group": [
  null,
  "Utwórz grupę woluminów"
 ],
 "Creating LVM2 volume group $target": [
  null,
  "Tworzenie grupy woluminów LVM2 $target"
 ],
 "Creating VDO device": [
  null,
  "Tworzenie urządzenia VDO"
 ],
 "Creating filesystem on $target": [
  null,
  "Tworzenie systemu plików w $target"
 ],
 "Creating logical volume $target": [
  null,
  "Tworzenie woluminu logicznego $target"
 ],
 "Creating partition $target": [
  null,
  "Tworzenie partycji $target"
 ],
 "Creating snapshot of $target": [
  null,
  "Tworzenie migawki $target"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Currently in use": [
  null,
  "Obecnie używane"
 ],
 "Custom mount options": [
  null,
  "Niestandardowe opcje montowania"
 ],
 "Data": [
  null,
  "Dane"
 ],
 "Data used": [
  null,
  "Użyte dane"
 ],
 "Data will be stored as two copies and also in an alternating fashion on the selected physical volumes, to improve both reliability and performance. At least four volumes need to be selected.": [
  null,
  ""
 ],
 "Data will be stored as two or more copies on the selected physical volumes, to improve reliability. At least two volumes need to be selected.": [
  null,
  ""
 ],
 "Data will be stored on the selected physical volumes in an alternating fashion to improve performance. At least two volumes need to be selected.": [
  null,
  ""
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. At least three volumes need to be selected.": [
  null,
  ""
 ],
 "Data will be stored on the selected physical volumes so that one of them can be lost without affecting the data. Data is also stored in an alternating fashion to improve performance. At least three volumes need to be selected.": [
  null,
  ""
 ],
 "Data will be stored on the selected physical volumes so that up to two of them can be lost at the same time without affecting the data. Data is also stored in an alternating fashion to improve performance. At least five volumes need to be selected.": [
  null,
  ""
 ],
 "Data will be stored on the selected physical volumes without any additional redundancy or performance improvements.": [
  null,
  ""
 ],
 "Deactivate": [
  null,
  "Dezaktywuj"
 ],
 "Deactivating $target": [
  null,
  "Dezaktywowanie $target"
 ],
 "Deduplication": [
  null,
  "Deduplikacja"
 ],
 "Degraded": [
  null,
  ""
 ],
 "Delay": [
  null,
  "Opóźnienie"
 ],
 "Delete": [
  null,
  "Usuń"
 ],
 "Delete group": [
  null,
  "Usuń grupę"
 ],
 "Deleting $target": [
  null,
  "Usuwanie $target"
 ],
 "Deleting LVM2 volume group $target": [
  null,
  "Usuwanie grupy woluminów LVM2 $target"
 ],
 "Deleting a Stratis pool will erase all data it contains.": [
  null,
  "Usunięcie puli Stratis usunie wszystkie zawarte w niej dane."
 ],
 "Deleting a filesystem will delete all data in it.": [
  null,
  "Usunięcie systemu plików usunie wszystkie znajdujące się w nim dane."
 ],
 "Deleting a logical volume will delete all data in it.": [
  null,
  "Usunięcie woluminu logicznego usunie wszystkie znajdujące się na nim dane."
 ],
 "Deleting a partition will delete all data in it.": [
  null,
  "Usunięcie partycji usunie wszystkie znajdujące się na niej dane."
 ],
 "Deleting erases all data on a VDO device.": [
  null,
  "Usunięcie usuwa wszystkie dane na urządzeniu VDO."
 ],
 "Deleting erases all data on a volume group.": [
  null,
  "Usunięcie usuwa wszystkie dane w grupie woluminów."
 ],
 "Description": [
  null,
  "Opis"
 ],
 "Desktop": [
  null,
  "Komputer stacjonarny"
 ],
 "Detachable": [
  null,
  "Odłączalny"
 ],
 "Device": [
  null,
  "Urządzenie"
 ],
 "Device file": [
  null,
  "Plik urządzenia"
 ],
 "Device health (SMART)": [
  null,
  ""
 ],
 "Device is read-only": [
  null,
  "Urządzenie jest tylko do odczytu"
 ],
 "Diagnostic reports": [
  null,
  "Raporty diagnostyczne"
 ],
 "Did not complete": [
  null,
  ""
 ],
 "Disconnect": [
  null,
  "Rozłącz"
 ],
 "Disk is OK": [
  null,
  "Dysk jest OK"
 ],
 "Disk is failing": [
  null,
  "Na dysku występują błędy"
 ],
 "Disk passphrase": [
  null,
  "Hasło dysku"
 ],
 "Disks": [
  null,
  "Dyski"
 ],
 "Do not mount": [
  null,
  "Bez montowania"
 ],
 "Do not mount automatically on boot": [
  null,
  "Bez automatycznego montowania podczas uruchamiania"
 ],
 "Docking station": [
  null,
  "Stacja dokująca"
 ],
 "Does not mount during boot": [
  null,
  "Bez montowania podczas uruchamiania"
 ],
 "Downloading $0": [
  null,
  "Pobieranie $0"
 ],
 "Drive": [
  null,
  "Napęd"
 ],
 "Dual rank": [
  null,
  "Podwójny stopień"
 ],
 "Edit": [
  null,
  "Modyfikuj"
 ],
 "Edit Tang keyserver": [
  null,
  "Modyfikuj serwer kluczy Tang"
 ],
 "Editing a key requires a free slot": [
  null,
  "Modyfikacja klucza wymaga wolnego gniazda"
 ],
 "Ejecting $target": [
  null,
  "Wysuwanie $target"
 ],
 "Embedded PC": [
  null,
  "Komputer osadzony"
 ],
 "Emptying $target": [
  null,
  "Opróżnianie $target"
 ],
 "Enabling $0": [
  null,
  "Włączanie $0"
 ],
 "Encrypt data with a Tang keyserver": [
  null,
  "Zaszyfruj dane za pomocą serwera kluczy Tang"
 ],
 "Encrypt data with a passphrase": [
  null,
  "Zaszyfruj dane za pomocą hasła"
 ],
 "Encrypted $0": [
  null,
  "Zaszyfrowane $0"
 ],
 "Encrypted logical volume of $0": [
  null,
  "Zaszyfrowany wolumin logiczny $0"
 ],
 "Encrypted partition of $0": [
  null,
  "Zaszyfrowana partycja $0"
 ],
 "Encryption": [
  null,
  "Szyfrowanie"
 ],
 "Encryption options": [
  null,
  "Opcje szyfrowania"
 ],
 "Encryption type": [
  null,
  "Typ szyfrowania"
 ],
 "Erasing $target": [
  null,
  "Czyszczenie $target"
 ],
 "Error": [
  null,
  "Błąd"
 ],
 "Error installing $0: PackageKit is not installed": [
  null,
  "Błąd podczas instalowania $0: usługa PackageKit nie jest zainstalowana"
 ],
 "Exactly $0 physical volumes must be selected": [
  null,
  "Dokładnie $0 fizycznych wolumenów musi zostać wybranych"
 ],
 "Exactly $0 physical volumes need to be selected, one for each stripe of the logical volume.": [
  null,
  ""
 ],
 "Excellent password": [
  null,
  "Doskonałe hasło"
 ],
 "Expansion chassis": [
  null,
  "Obudowa rozszerzenia"
 ],
 "Extended partition": [
  null,
  "Rozszerzona partycja"
 ],
 "Failed": [
  null,
  "Niepowodzenie"
 ],
 "Failed (Damaged)": [
  null,
  ""
 ],
 "Failed (Electrical)": [
  null,
  ""
 ],
 "Failed to change password": [
  null,
  "Zmiana hasła się nie powiodła"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Włączenie $0 w usłudze firewalld się nie powiodło"
 ],
 "Filesystem": [
  null,
  "System plików"
 ],
 "Filesystem is locked": [
  null,
  "System plików jest zablokowany"
 ],
 "Filesystem name": [
  null,
  "Nazwa systemu plików"
 ],
 "Filesystems are already mounted below this mountpoint.": [
  null,
  "Pod tym punktem montowania są już zamontowane systemy plików."
 ],
 "Fix NBDE support": [
  null,
  "Napraw obsługę NBDE"
 ],
 "Format": [
  null,
  "Sformatuj"
 ],
 "Format $0": [
  null,
  "Sformatuj $0"
 ],
 "Format and mount": [
  null,
  "Sformatuj i zamontuj"
 ],
 "Format only": [
  null,
  "Tylko sformatuj"
 ],
 "Formatting erases all data on a storage device.": [
  null,
  "Sformatowanie usuwa wszystkie dane na urządzeniu do przechowywania danych."
 ],
 "Free space": [
  null,
  "Wolne miejsce"
 ],
 "Go to now": [
  null,
  "Przejdź teraz"
 ],
 "Grow": [
  null,
  "Powiększ"
 ],
 "Grow content": [
  null,
  "Powiększ zawartość"
 ],
 "Grow logical size of $0": [
  null,
  "Powiększ rozmiar logiczny $0"
 ],
 "Grow logical volume": [
  null,
  "Powiększ wolumin logiczny"
 ],
 "Grow partition": [
  null,
  "Powiększ partycję"
 ],
 "Grow the pool to take all space": [
  null,
  "Powiększ pulę do użycia całego miejsca"
 ],
 "Grow to take all space": [
  null,
  "Powiększ do użycia całego miejsca"
 ],
 "Handheld": [
  null,
  "Przenośny"
 ],
 "Host key is incorrect": [
  null,
  "Klucz komputera jest niepoprawny"
 ],
 "How to check": [
  null,
  "Jak sprawdzić"
 ],
 "I confirm I want to lose this data forever": [
  null,
  "Potwierdzam że chce stracić te dane na zawsze"
 ],
 "ID": [
  null,
  "Identyfikator"
 ],
 "INTERNAL ERROR - This logical volume is marked as active and should have an associated block device. However, no such block device could be found.": [
  null,
  "WEWNĘTRZNY BŁĄD - Ten wolumen logiczny jest zaznaczony jako aktywny i powinien mieć powiązane urządzenie blokowe. Ale, takie urządzenie nie zostało znalezione."
 ],
 "If the fingerprint matches, click 'Trust and add host'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Jeśli odcisk się zgadza, należy kliknąć „Zaufaj i dodaj komputer”. W przeciwnym przypadku nie należy się łączyć i należy skontaktować się z administratorem."
 ],
 "Important data might be deleted:": [
  null,
  "Ważne dane mogą zostać usunięte:"
 ],
 "In a terminal, run: ": [
  null,
  "W terminalu należy wykonać: "
 ],
 "In sync": [
  null,
  "Zsynchronizowane"
 ],
 "Inconsistent filesystem mount": [
  null,
  "Niespójny punkt montowania systemu plików"
 ],
 "Index memory": [
  null,
  "Pamięć indeksu"
 ],
 "Initialize": [
  null,
  "Zainicjuj"
 ],
 "Initialize disk $0": [
  null,
  "Zainicjuj dysk $0"
 ],
 "Initializing erases all data on a disk.": [
  null,
  "Zainicjowanie usuwa wszystkie dane na dysku."
 ],
 "Install": [
  null,
  "Zainstaluj"
 ],
 "Install NFS support": [
  null,
  "Zainstaluj obsługę NFS"
 ],
 "Install Stratis support": [
  null,
  "Zainstaluj obsługę Stratis"
 ],
 "Install software": [
  null,
  "Zainstaluj oprogramowanie"
 ],
 "Installing $0": [
  null,
  "Instalowanie $0"
 ],
 "Installing $0 would remove $1.": [
  null,
  "Zainstalowanie $0 usunęłoby $1."
 ],
 "Installing packages": [
  null,
  "Instalowanie pakietów"
 ],
 "Internal error": [
  null,
  "Wewnętrzny błąd"
 ],
 "Invalid date format": [
  null,
  "Nieprawidłowy format daty"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Nieprawidłowy format daty i nieprawidłowy format czasu"
 ],
 "Invalid file permissions": [
  null,
  "Nieprawidłowe uprawnienia pliku"
 ],
 "Invalid time format": [
  null,
  "Nieprawidłowy format czasu"
 ],
 "Invalid timezone": [
  null,
  "Nieprawidłowa strefa czasowa"
 ],
 "Invalid username or password": [
  null,
  "Nieprawidłowa nazwa użytkownika lub hasło"
 ],
 "IoT gateway": [
  null,
  "Brama IoT"
 ],
 "Jobs": [
  null,
  "Zadania"
 ],
 "Kernel dump": [
  null,
  "Zrzut jądra"
 ],
 "Key password": [
  null,
  "Hasło klucza"
 ],
 "Key slots with unknown types can not be edited here": [
  null,
  "Nie można modyfikować gniazd na klucze o nieznanym typie w tym miejscu"
 ],
 "Key source": [
  null,
  "Źródło kluczy"
 ],
 "Keys": [
  null,
  "Klucze"
 ],
 "Keyserver": [
  null,
  "Serwer kluczy"
 ],
 "Keyserver address": [
  null,
  "Adres serwera kluczy"
 ],
 "Keyserver removal may prevent unlocking $0.": [
  null,
  "Usunięcie serwera kluczy może uniemożliwić odblokowanie $0."
 ],
 "LVM2 physical volume": [
  null,
  "Wolumin fizyczny LVM2"
 ],
 "LVM2 volume group": [
  null,
  "Grupa woluminów LVM2"
 ],
 "LVM2 volume group $0": [
  null,
  "Grupa woluminów LVM2 $0"
 ],
 "Label": [
  null,
  "Etykieta"
 ],
 "Laptop": [
  null,
  "Laptop"
 ],
 "Last modified: $0": [
  null,
  "Ostatnia modyfikacja: $0"
 ],
 "Layout": [
  null,
  "Układ"
 ],
 "Learn more": [
  null,
  "Więcej informacji"
 ],
 "Linear": [
  null,
  "Liniowy"
 ],
 "Loading system modifications...": [
  null,
  "Wczytywanie modyfikacji systemu…"
 ],
 "Loading...": [
  null,
  "Wczytywanie…"
 ],
 "Local mount point": [
  null,
  "Lokalny punkt montowania"
 ],
 "Location": [
  null,
  "Położenie"
 ],
 "Lock": [
  null,
  "Zablokuj"
 ],
 "Locking $target": [
  null,
  "Blokowanie $target"
 ],
 "Log in": [
  null,
  "Zaloguj"
 ],
 "Log in to $0": [
  null,
  "Zaloguj się na $0"
 ],
 "Log messages": [
  null,
  "Komunikaty dziennika"
 ],
 "Logical": [
  null,
  "Logiczny"
 ],
 "Logical size": [
  null,
  "Rozmiar logiczny"
 ],
 "Logical volume": [
  null,
  "Wolumin logiczny"
 ],
 "Logical volume (snapshot)": [
  null,
  "Wolumin logiczny (migawka)"
 ],
 "Logical volume of $0": [
  null,
  "Wolumin logiczny $0"
 ],
 "Login failed": [
  null,
  "Logowanie się nie powiodło"
 ],
 "Low profile desktop": [
  null,
  "Komputer stacjonarny o mniejszym rozmiarze"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "Main server chassis": [
  null,
  "Główna obudowa serwera"
 ],
 "Manage storage": [
  null,
  "Zarządzanie urządzeniami do przechowywania danych"
 ],
 "Manually": [
  null,
  "Ręcznie"
 ],
 "Marking $target as faulty": [
  null,
  "Oznaczanie $target jako wadliwe"
 ],
 "Message to logged in users": [
  null,
  "Wiadomość do zalogowanych użytkowników"
 ],
 "Metadata used": [
  null,
  "Użyte metadane"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini tower"
 ],
 "Mirrored (RAID 1)": [
  null,
  "Lustrzany (RAID 1)"
 ],
 "Model": [
  null,
  "Model"
 ],
 "Modifying $target": [
  null,
  "Modyfikowanie $target"
 ],
 "Mount": [
  null,
  "Zamontuj"
 ],
 "Mount Point": [
  null,
  "Punkt montowania"
 ],
 "Mount after network becomes available, ignore failure": [
  null,
  "Montowanie po włączeniu sieci, ignorowanie niepowodzenia"
 ],
 "Mount also automatically on boot": [
  null,
  "Montowanie także automatycznie podczas uruchamiania"
 ],
 "Mount at boot": [
  null,
  "Montowanie podczas uruchamiania"
 ],
 "Mount automatically on $0 on boot": [
  null,
  "Montowanie automatycznie na $0 podczas uruchamiania"
 ],
 "Mount before services start": [
  null,
  "Montowanie przed uruchomieniem usług"
 ],
 "Mount configuration": [
  null,
  "Konfiguracja montowania"
 ],
 "Mount filesystem": [
  null,
  "Zamontuj system plików"
 ],
 "Mount now": [
  null,
  "Zamontuj teraz"
 ],
 "Mount on $0 now": [
  null,
  "Zamontuj na $0 teraz"
 ],
 "Mount options": [
  null,
  "Opcje montowania"
 ],
 "Mount point": [
  null,
  "Punkt montowania"
 ],
 "Mount point cannot be empty": [
  null,
  "Punkt montowania nie może być pusty"
 ],
 "Mount point cannot be empty.": [
  null,
  "Punkt montowania nie może być pusty."
 ],
 "Mount point is already used for $0": [
  null,
  "Punkt montowania jest już używany dla $0"
 ],
 "Mount point must start with \"/\".": [
  null,
  "Punkt montowania musi zaczynać się od „/”."
 ],
 "Mount read only": [
  null,
  "Montowanie tylko do odczytu"
 ],
 "Mount without waiting, ignore failure": [
  null,
  "Montowanie bez czekania, ignorowanie niepowodzenia"
 ],
 "Mounting $target": [
  null,
  "Montowanie $target"
 ],
 "Mounts before services start": [
  null,
  "Montuje przed uruchomieniem usług"
 ],
 "Mounts in parallel with services": [
  null,
  "Montuje równolegle z usługami"
 ],
 "Mounts in parallel with services, but after network is available": [
  null,
  "Montuje równolegle z usługami, ale po włączeniu sieci"
 ],
 "Multi-system chassis": [
  null,
  "Obudowa dla wielu komputerów"
 ],
 "NFS mount": [
  null,
  "Punkt montowania NFS"
 ],
 "NTP server": [
  null,
  "Serwer NTP"
 ],
 "Name": [
  null,
  "Nazwa"
 ],
 "Name can not be empty.": [
  null,
  "Nazwa nie może być pusta."
 ],
 "Name cannot be empty.": [
  null,
  "Nazwa nie może być pusta."
 ],
 "Name cannot be longer than $0 bytes": [
  null,
  "Nazwa nie może być dłuższa niż $0 B"
 ],
 "Name cannot be longer than $0 characters": [
  null,
  "Nazwa nie może być dłuższa niż $0 znaków"
 ],
 "Name cannot be longer than 127 characters.": [
  null,
  "Nazwa nie może być dłuższa niż 127 znaków."
 ],
 "Name cannot contain the character '$0'.": [
  null,
  "Nazwa nie może zawierać znaku „$0”."
 ],
 "Name cannot contain whitespace.": [
  null,
  "Nazwa nie może zawierać spacji."
 ],
 "Need a spare disk": [
  null,
  "Potrzeba wolnego dysku"
 ],
 "Need at least one NTP server": [
  null,
  "Wymagany jest co najmniej jeden serwer NTP"
 ],
 "Networking": [
  null,
  "Sieć"
 ],
 "New NFS mount": [
  null,
  "Nowy punkt montowania NFS"
 ],
 "New passphrase": [
  null,
  "Nowe hasło"
 ],
 "New password was not accepted": [
  null,
  "Nie przyjęto nowego hasła"
 ],
 "Next": [
  null,
  "Dalej"
 ],
 "No available slots": [
  null,
  "Brak dostępnych gniazd"
 ],
 "No block devices are available.": [
  null,
  "Brak dostępnych urządzeń blokowych."
 ],
 "No delay": [
  null,
  "Brak opóźnienia"
 ],
 "No disks are available.": [
  null,
  "Brak dostępnych dysków."
 ],
 "No encryption": [
  null,
  "Bez szyfrowania"
 ],
 "No filesystem": [
  null,
  "Brak systemu plików"
 ],
 "No filesystems": [
  null,
  "Brak systemów plików"
 ],
 "No free key slots": [
  null,
  "Brak wolnych gniazd na klucze"
 ],
 "No free space": [
  null,
  "Brak wolnego miejsca"
 ],
 "No free space after this partition": [
  null,
  "Brak wolnego miejsca po tej partycji"
 ],
 "No keys added": [
  null,
  "Nie dodano kluczy"
 ],
 "No logical volumes": [
  null,
  "Brak woluminów logicznych"
 ],
 "No media inserted": [
  null,
  "Nie włożono żadnego nośnika"
 ],
 "No partitioning": [
  null,
  "Brak partycjonowania"
 ],
 "No results found": [
  null,
  "Brak wyników"
 ],
 "No such file or directory": [
  null,
  "Nie ma takiego pliku lub katalogu"
 ],
 "No system modifications": [
  null,
  "Brak modyfikacji systemu"
 ],
 "Not a valid private key": [
  null,
  "Nieprawidłowy klucz prywatny"
 ],
 "Not enough space": [
  null,
  "Za mało miejsca"
 ],
 "Not found": [
  null,
  "Nie odnaleziono"
 ],
 "Not permitted to perform this action.": [
  null,
  "Brak uprawnień do wykonania tego działania."
 ],
 "Not running": [
  null,
  "Niedziałające"
 ],
 "Not synchronized": [
  null,
  "Niesynchronizowane"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Number of bad sectors": [
  null,
  ""
 ],
 "Occurrences": [
  null,
  "Wystąpienia"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Old passphrase": [
  null,
  "Poprzednie hasło"
 ],
 "Old password not accepted": [
  null,
  "Nie przyjęto poprzedniego hasła"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Po zainstalowaniu programu Cockpit należy go włączyć za pomocą polecenia „systemctl enable --now cockpit.socket”."
 ],
 "Only $0 of $1 are used.": [
  null,
  "Tylko $0 z $1 jest używane."
 ],
 "Operation '$operation' on $target": [
  null,
  "Działanie „$operation” na $target"
 ],
 "Options": [
  null,
  "Opcje"
 ],
 "Other": [
  null,
  "Inne"
 ],
 "Overwrite": [
  null,
  "Zastąp"
 ],
 "Overwrite existing data with zeros (slower)": [
  null,
  "Zastąp istniejące dane zerami (wolniejsze)"
 ],
 "PID": [
  null,
  "PID"
 ],
 "PackageKit crashed": [
  null,
  "Usługa PackageKit uległa awarii"
 ],
 "Partition": [
  null,
  "Partycja"
 ],
 "Partition of $0": [
  null,
  "Partycja $0"
 ],
 "Partition size is $0. Content size is $1.": [
  null,
  "Rozmiar partycji to $0. Rozmiar zawartości to $1."
 ],
 "Partitioning": [
  null,
  "Partycjonowanie"
 ],
 "Partitions": [
  null,
  "Partycje"
 ],
 "Partitions are not supported on this block device. If it is used as a disk for a virtual machine, the partitions must be managed by the operating system inside the virtual machine.": [
  null,
  ""
 ],
 "Passphrase": [
  null,
  "Hasło"
 ],
 "Passphrase can not be empty": [
  null,
  "Hasło nie może być puste"
 ],
 "Passphrase cannot be empty": [
  null,
  "Hasło nie może być puste"
 ],
 "Passphrase from any other key slot": [
  null,
  "Hasło z jakiegoś innego gniazda na klucze"
 ],
 "Passphrase removal may prevent unlocking $0.": [
  null,
  "Usunięcie hasła może uniemożliwić odblokowanie $0."
 ],
 "Passphrases do not match": [
  null,
  "Hasła się nie zgadzają"
 ],
 "Password": [
  null,
  "Hasło"
 ],
 "Password is not acceptable": [
  null,
  "Hasło jest do przyjęcia"
 ],
 "Password is too weak": [
  null,
  "Hasło jest za słabe"
 ],
 "Password not accepted": [
  null,
  "Nie przyjęto hasła"
 ],
 "Paste": [
  null,
  "Wklej"
 ],
 "Paste error": [
  null,
  "Błąd wklejania"
 ],
 "Path on server": [
  null,
  "Ścieżka na serwerze"
 ],
 "Path on server cannot be empty.": [
  null,
  "Ścieżka na serwerze nie może być pusta."
 ],
 "Path on server must start with \"/\".": [
  null,
  "Ścieżka na serwerze musi zaczynać się od „/”."
 ],
 "Path to file": [
  null,
  "Ścieżka do pliku"
 ],
 "Peripheral chassis": [
  null,
  "Obudowa peryferyjna"
 ],
 "Permanently delete $0?": [
  null,
  "Trwale usunąć $0?"
 ],
 "Physical": [
  null,
  "Fizyczny"
 ],
 "Physical volumes": [
  null,
  "Woluminy fizyczne"
 ],
 "Pick date": [
  null,
  "Wybierz datę"
 ],
 "Pizza box": [
  null,
  "Pizza box"
 ],
 "Please unmount them first.": [
  null,
  "Proszę je najpierw odmontować."
 ],
 "Pool for thin logical volumes": [
  null,
  "Pula dla cienkich woluminów logicznych"
 ],
 "Pool for thinly provisioned volumes": [
  null,
  "Pula dla cienko nadzorowanych woluminów"
 ],
 "Pool passphrase": [
  null,
  "Hasło puli"
 ],
 "Port": [
  null,
  "Port"
 ],
 "Portable": [
  null,
  "Przenośne"
 ],
 "Power on hours": [
  null,
  ""
 ],
 "Present": [
  null,
  "Obecne"
 ],
 "Processes using the location": [
  null,
  "Procesy używające położenia"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Pytanie przez ssh-add przekroczyło czas oczekiwania"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Pytanie przez ssh-keygen przekroczyło czas oczekiwania"
 ],
 "Provide the passphrase for the pool on these block devices:": [
  null,
  "Proszę podać hasło puli na tych urządzeniach blokowych:"
 ],
 "Purpose": [
  null,
  "Zastosowanie"
 ],
 "RAID ($0)": [
  null,
  "RAID ($0)"
 ],
 "RAID 0": [
  null,
  "RAID 0"
 ],
 "RAID 0 (stripe)": [
  null,
  "RAID 0 (Striping)"
 ],
 "RAID 1": [
  null,
  "RAID 1"
 ],
 "RAID 1 (mirror)": [
  null,
  "RAID 1 (Lustrzany)"
 ],
 "RAID 10": [
  null,
  "RAID 10"
 ],
 "RAID 10 (stripe of mirrors)": [
  null,
  "RID 10 (Striping lustrzany)"
 ],
 "RAID 4": [
  null,
  "RAID 4"
 ],
 "RAID 4 (dedicated parity)": [
  null,
  "RAID 4 (Dedykowana parzystość)"
 ],
 "RAID 5": [
  null,
  "RAID 5"
 ],
 "RAID 5 (distributed parity)": [
  null,
  "RAID 5 (Rozproszona parzystość)"
 ],
 "RAID 6": [
  null,
  "RAID 6"
 ],
 "RAID 6 (double distributed parity)": [
  null,
  "RAID 6 (Podwójna rozproszona parzystość)"
 ],
 "RAID chassis": [
  null,
  "Obudowa RAID"
 ],
 "RAID level": [
  null,
  "Poziom macierzy RAID"
 ],
 "RAID10 needs an even number of physical volumes": [
  null,
  "RAID10 wymaga parzystej liczby fizycznych wolumenów"
 ],
 "Rack mount chassis": [
  null,
  "Obudowa do montowania w szafie"
 ],
 "Reading": [
  null,
  "Odczytywanie"
 ],
 "Reboot": [
  null,
  "Uruchom ponownie"
 ],
 "Recovering": [
  null,
  "Odzyskiwanie"
 ],
 "Regenerating initrd": [
  null,
  "Ponowne tworzenie obrazu initrd"
 ],
 "Related processes and services will be forcefully stopped.": [
  null,
  "Powiązane procesy i usługi zostaną siłowo zatrzymane."
 ],
 "Related processes will be forcefully stopped.": [
  null,
  "Powiązane procesy zostaną siłowo zatrzymane."
 ],
 "Related services will be forcefully stopped.": [
  null,
  "Powiązane usługi zostaną siłowo zatrzymane."
 ],
 "Removals:": [
  null,
  "Usuwane:"
 ],
 "Remove": [
  null,
  "Usuń"
 ],
 "Remove $0?": [
  null,
  "Usunąć $0?"
 ],
 "Remove Tang keyserver?": [
  null,
  "Usunąć serwer kluczy Tang?"
 ],
 "Remove device": [
  null,
  "Usuń urządzenie"
 ],
 "Remove passphrase in key slot $0?": [
  null,
  "Usunąć hasło w gnieździe na klucze $0?"
 ],
 "Remove passphrase?": [
  null,
  "Usunąć hasło?"
 ],
 "Removing $0": [
  null,
  "Usuwanie $0"
 ],
 "Removing a passphrase without confirmation of another passphrase may prevent unlocking or key management, if other passphrases are forgotten or lost.": [
  null,
  "Usunięcie hasła bez potwierdzenia innym hasłem może uniemożliwić odblokowywanie lub zarządzanie kluczami, jeśli inne hasła zostaną zapomniane lub utracone."
 ],
 "Removing physical volume from $target": [
  null,
  "Usuwanie woluminu fizycznego z $target"
 ],
 "Rename": [
  null,
  "Zmień nazwę"
 ],
 "Rename Stratis pool": [
  null,
  "Zmień nazwę puli Stratis"
 ],
 "Rename filesystem": [
  null,
  "Zmień nazwę systemu plików"
 ],
 "Rename logical volume": [
  null,
  "Zmiana nazwy woluminu logicznego"
 ],
 "Rename volume group": [
  null,
  "Zmień nazwę grupy woluminów"
 ],
 "Renaming $target": [
  null,
  "Zmienianie nazwy $target"
 ],
 "Repair": [
  null,
  "Napraw"
 ],
 "Repairing $target": [
  null,
  "Naprawianie $target"
 ],
 "Repeat passphrase": [
  null,
  "Powtórzenie hasła"
 ],
 "Resizing $target": [
  null,
  "Zmienianie rozmiaru $target"
 ],
 "Resizing an encrypted filesystem requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Zmiana rozmiaru zaszyfrowanego systemu plików wymaga odblokowania dysku. Proszę podać obecne hasło dysku."
 ],
 "Reuse existing encryption": [
  null,
  "Ponowne użycie istniejącego szyfrowania"
 ],
 "Reuse existing encryption ($0)": [
  null,
  "Ponowne użycie istniejącego szyfrowania ($0)"
 ],
 "Run extended test": [
  null,
  ""
 ],
 "Run this command over a trusted network or physically on the remote machine:": [
  null,
  "Należy wykonać to polecenie przez zaufaną sieć lub fizycznie na zdalnym komputerze:"
 ],
 "Running": [
  null,
  "Działające"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SHA-1": [
  null,
  "SHA-1"
 ],
 "SHA-256": [
  null,
  "SHA-256"
 ],
 "SMART self-test of $target": [
  null,
  "Test SMART $target"
 ],
 "SSH key": [
  null,
  "Klucz SSH"
 ],
 "Save": [
  null,
  "Zapisz"
 ],
 "Save space by compressing individual blocks with LZ4": [
  null,
  "Oszczędź miejsce kompresując poszczególne bloki za pomocą L4"
 ],
 "Save space by storing identical data blocks just once": [
  null,
  "Oszczędź miejsce przez przechowywanie identycznych bloków danych tylko raz"
 ],
 "Saving a new passphrase requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Zapisanie nowego hasła wymaga odblokowania dysku. Proszę podać obecne hasło dysku."
 ],
 "Sealed-case PC": [
  null,
  "Sealed-case PC"
 ],
 "Securely erasing $target": [
  null,
  "Bezpieczne usuwanie zawartości $target"
 ],
 "Security Enhanced Linux configuration and troubleshooting": [
  null,
  "Konfiguracja i rozwiązywanie błędów z SELinuksem"
 ],
 "Server": [
  null,
  "Serwer"
 ],
 "Server address": [
  null,
  "Adres serwera"
 ],
 "Server address cannot be empty.": [
  null,
  "Adres serwera nie może być pusty."
 ],
 "Server cannot be empty.": [
  null,
  "Serwer nie może być pusty."
 ],
 "Server has closed the connection.": [
  null,
  "Serwer zamknął połączenie."
 ],
 "Service": [
  null,
  "Usługa"
 ],
 "Services using the location": [
  null,
  "Usługi używające położenia"
 ],
 "Set": [
  null,
  "Ustaw"
 ],
 "Set limit of virtual filesystem size": [
  null,
  ""
 ],
 "Set time": [
  null,
  "Ustaw czas"
 ],
 "Setting up loop device $target": [
  null,
  "Ustawianie urządzenia zwrotnego $target"
 ],
 "Shell script": [
  null,
  "Skrypt powłoki"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Shrink": [
  null,
  "Zmniejsz"
 ],
 "Shrink logical volume": [
  null,
  "Zmniejsz wolumin logiczny"
 ],
 "Shrink partition": [
  null,
  "Zmniejsz partycję"
 ],
 "Shrink volume": [
  null,
  "Zmniejsz wolumin"
 ],
 "Shut down": [
  null,
  "Wyłącz"
 ],
 "Single rank": [
  null,
  "Pojedynczy stopień"
 ],
 "Size": [
  null,
  "Rozmiar"
 ],
 "Size cannot be negative": [
  null,
  "Rozmiar nie może być ujemny"
 ],
 "Size cannot be zero": [
  null,
  "Rozmiar nie może wynosić zero"
 ],
 "Size is too large": [
  null,
  "Rozmiar jest za duży"
 ],
 "Size must be a number": [
  null,
  "Rozmiar musi być liczbą"
 ],
 "Size must be at least $0": [
  null,
  "Rozmiar musi wynosić co najmniej $0"
 ],
 "Slot $0": [
  null,
  "Gniazdo $0"
 ],
 "Snapshot": [
  null,
  "Migawka"
 ],
 "Some block devices of this pool have grown in size after the pool was created. The pool can be safely grown to use the newly available space.": [
  null,
  "Część urządzeń blokowych tej puli powiększyło się po utworzeniu puli. Można bezpiecznie powiększyć pulę, aby wykorzystać nowo dostępne miejsce."
 ],
 "Sorry": [
  null,
  "Przepraszam"
 ],
 "Space-saving computer": [
  null,
  "Komputer oszczędzający miejsce"
 ],
 "Spare": [
  null,
  "Zapasowe"
 ],
 "Spare capacity is below the threshold": [
  null,
  ""
 ],
 "Specific time": [
  null,
  "Podany czas"
 ],
 "Start": [
  null,
  "Rozpocznij"
 ],
 "Start multipath": [
  null,
  "Uruchom urządzenie wielościeżkowe"
 ],
 "Started": [
  null,
  "Rozpoczęto"
 ],
 "Starting swapspace $target": [
  null,
  "Uruchamianie przestrzeni wymiany $target"
 ],
 "State": [
  null,
  "Stan"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "Stop": [
  null,
  "Zatrzymaj"
 ],
 "Stop and remove": [
  null,
  "Zatrzymaj i usuń"
 ],
 "Stop and unmount": [
  null,
  "Zatrzymaj i odmontuj"
 ],
 "Stop device": [
  null,
  "Zatrzymaj urządzenie"
 ],
 "Stopping swapspace $target": [
  null,
  "Zatrzymywanie przestrzeni wymiany $target"
 ],
 "Storage": [
  null,
  "Przechowywanie danych"
 ],
 "Storage can not be managed on this system.": [
  null,
  "Urządzenia do przechowywania danych nie mogą być zarządzane na tym systemie."
 ],
 "Storage logs": [
  null,
  "Dzienniki urządzeń do przechowywania danych"
 ],
 "Store passphrase": [
  null,
  "Przechowaj hasło"
 ],
 "Stored passphrase": [
  null,
  "Zachowane hasło"
 ],
 "Stratis blockdevs can not be made smaller": [
  null,
  "Urządzenia blokowe Stratis nie mogą być zmniejszane"
 ],
 "Stratis pool": [
  null,
  "Pula Stratis"
 ],
 "Striped (RAID 0)": [
  null,
  ""
 ],
 "Striped and mirrored (RAID 10)": [
  null,
  ""
 ],
 "Stripes": [
  null,
  ""
 ],
 "Sub-Chassis": [
  null,
  "Obudowa podrzędna"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Successfully copied to clipboard!": [
  null,
  "Pomyślnie skopiowano do schowka."
 ],
 "Swap": [
  null,
  "Partycja wymiany"
 ],
 "Synchronized": [
  null,
  "Synchronizowane"
 ],
 "Synchronized with $0": [
  null,
  "Synchronizowane z $0"
 ],
 "Synchronizing": [
  null,
  "Synchronizowanie"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Tang keyserver": [
  null,
  "Serwer kluczy Tang"
 ],
 "Target": [
  null,
  "Cel"
 ],
 "Temperature outside of recommended thresholds": [
  null,
  ""
 ],
 "The $0 package is not available from any repository.": [
  null,
  "Pakiet $0 nie jest dostępny w żadnym repozytorium."
 ],
 "The $0 package must be installed to create Stratis pools.": [
  null,
  "Pakiet $0 musi być zainstalowany, aby tworzyć pule Stratis."
 ],
 "The $0 package must be installed.": [
  null,
  "Pakiet $0 musi być zainstalowany."
 ],
 "The $0 package will be installed to create VDO devices.": [
  null,
  "Pakiet $0 zostanie zainstalowany, aby utworzyć urządzenia VDO."
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "Klucz SSH $0 użytkownika $1 na komputerze $2 zostanie dodany do pliku $3 użytkownika $4 na komputerze $5."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "Klucz SSH $0 stanie się dostępny przez pozostały czas sesji i będzie dostępny do logowania także na innych komputerach."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "Klucz SSH do logowania w $0 jest chroniony hasłem, ale komputer nie zezwala na logowanie za pomocą hasła. Proszę podać hasło klucza w $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "Klucz SSH do logowania w $0 jest chroniony. Można zalogować się za pomocą hasła logowania lub podając hasło klucza w $1."
 ],
 "The creation of this VDO device did not finish and the device can't be used.": [
  null,
  "Utworzenie tego urządzenia VDO nie zostało ukończone, więc nie można go używać."
 ],
 "The currently logged in user is not permitted to see information about keys.": [
  null,
  "Obecnie zalogowany użytkownik nie ma zezwolenia na wyświetlanie informacji o kluczach."
 ],
 "The filesystem has no permanent mount point.": [
  null,
  "System plików nie ma trwałego punktu montowania."
 ],
 "The filesystem is configured to be automatically mounted on boot but its encryption container will not be unlocked at that time.": [
  null,
  "System plików jest skonfigurowany do automatycznego montowania podczas uruchamiania, ale jego kontener szyfrowania nie będzie wtedy odblokowywany."
 ],
 "The filesystem is currently mounted but will not be mounted after the next boot.": [
  null,
  "System plików jest obecnie zamontowany, ale nie będzie zamontowany po następnym uruchomieniu."
 ],
 "The filesystem is currently mounted on $0 but will be mounted on $1 on the next boot.": [
  null,
  "System plików jest obecnie zamontowany na $0, ale będzie zamontowany na $1 podczas następnego uruchomienia."
 ],
 "The filesystem is currently mounted on $0 but will not be mounted after the next boot.": [
  null,
  "System plików jest obecnie zamontowany na $0, ale nie będzie zamontowany po następnym uruchomieniu."
 ],
 "The filesystem is currently not mounted but will be mounted on the next boot.": [
  null,
  "System plików nie jest obecnie zamontowany, ale będzie zamontowany podczas następnego uruchomienia."
 ],
 "The filesystem is not mounted.": [
  null,
  "System plików nie jest zamontowany."
 ],
 "The filesystem will be unlocked and mounted on the next boot. This might require inputting a passphrase.": [
  null,
  "System plików zostanie odblokowany i zamontowany podczas następnego uruchomienia. Może to wymagać wpisania hasła."
 ],
 "The fingerprint should match:": [
  null,
  "Odcisk powinien się zgadzać:"
 ],
 "The initrd must be regenerated.": [
  null,
  "Obraz initrd musi zostać ponownie utworzony."
 ],
 "The key password can not be empty": [
  null,
  "Hasło klucza nie może być puste"
 ],
 "The key passwords do not match": [
  null,
  "Hasła klucza się nie zgadzają"
 ],
 "The last key slot can not be removed": [
  null,
  "Nie można usunąć ostatniego gniazda na klucz"
 ],
 "The listed processes and services will be forcefully stopped.": [
  null,
  "Wymienione procesy i usługi zostaną siłowo zatrzymane."
 ],
 "The listed processes will be forcefully stopped.": [
  null,
  "Wymienione procesy zostaną siłowo zatrzymane."
 ],
 "The listed services will be forcefully stopped.": [
  null,
  "Wymienione usługi zostaną siłowo zatrzymane."
 ],
 "The logged in user is not permitted to view system modifications": [
  null,
  "Zalogowany użytkownik nie ma zezwolenia na wyświetlanie modyfikacji systemu"
 ],
 "The mount point $0 is in use by these processes:": [
  null,
  "Punkt montowania $0 jest używany przez te procesy:"
 ],
 "The mount point $0 is in use by these services:": [
  null,
  "Punkt montowania $0 jest używany przez te usługi:"
 ],
 "The password can not be empty": [
  null,
  "Hasło nie może być puste"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Powstały odcisk można udostępniać publicznie, na przykład przez e-mail."
 ],
 "The resulting fingerprint is fine to share via public methods, including email. If you are asking someone else to do the verification for you, they can send the results using any method.": [
  null,
  "Powstały odcisk można udostępniać publicznie, na przykład przez e-mail. Jeśli weryfikacja jest wykonywana za użytkownika przez kogoś innego, to ta osoba może wysłać wyniki na dowolny sposób."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Serwer odmówił uwierzytelnienia za pomocą wszystkich obsługiwanych metod."
 ],
 "The system does not currently support unlocking a filesystem with a Tang keyserver during boot.": [
  null,
  "Komputer obecnie nie obsługuje odblokowywania systemu plików za pomocą serwera kluczy Tang podczas uruchamiania."
 ],
 "The system does not currently support unlocking the root filesystem with a Tang keyserver.": [
  null,
  "Komputer obecnie nie obsługuje odblokowywania głównego systemu plików za pomocą serwera kluczy Tang."
 ],
 "There are devices with multiple paths on the system, but the multipath service is not running.": [
  null,
  "W systemie obecne są urządzenia z wieloma ścieżkami, ale usługa urządzeń wielościeżkowych nie jest uruchomiona."
 ],
 "There is not enough space available that could be used for a repair. At least $0 are needed on physical volumes that are not already used for this logical volume.": [
  null,
  "Nie ma wystarczająco wolnego miejsca które mogło by zostać użyte do naprawy. Przynajmniej $0 które nie jest wykorzystywane przez ten wolumen logiczny jest potrzebne na fizycznych wolumenach."
 ],
 "These additional steps are necessary:": [
  null,
  "Potrzebne jest wykonanie tych dodatkowych kroków:"
 ],
 "These changes will be made:": [
  null,
  "Te zmiany zostaną wprowadzone:"
 ],
 "Thin logical volume": [
  null,
  "Cienki wolumin logiczny"
 ],
 "This NFS mount is in use and only its options can be changed.": [
  null,
  "Ten punkt montowania NFS jest używany. Można zmieniać tylko jego opcje."
 ],
 "This VDO device does not use all of its backing device.": [
  null,
  "To urządzenie VDO nie używa całości swojego urządzenia podstawowego."
 ],
 "This device is currently in use.": [
  null,
  "To urządzenie jest obecnie używane."
 ],
 "This keyserver is the only way to unlock the pool and can not be removed.": [
  null,
  "Ten serwer kluczy jest jedynym sposobem na odblokowanie puli i nie może zostać usunięty."
 ],
 "This logical volume has lost some of its physical volumes and can no longer be used. You need to delete it and create a new one to take its place.": [
  null,
  "Ten wolumen logiczny stracił trochę swoich wolumenów fizycznych i nie może być dłużej używany. Musisz go usunąć i stworzyć nowy który zajmie jego miejsce."
 ],
 "This logical volume has lost some of its physical volumes but has not lost any data yet. You should repair it to restore its original redundancy.": [
  null,
  "Ten logiczny wolumen stracił część swoich fizycznych wolumenów ale nie stracił jeszcze żadnych danych. Powinieneś go naprawić aby odzyskał swoją oryginalną redundancje."
 ],
 "This logical volume has lost some of its physical volumes but might not have lost any data yet. You might be able to repair it.": [
  null,
  "Ten logiczny wolumen stracił część swoich fizycznych wolumenów ale nie stracił jeszcze żadnych danych. Powinieneś być w stanie go naprawić."
 ],
 "This logical volume is not completely used by its content.": [
  null,
  "Ten wolumin logiczny nie jest całkowicie używany przez swoją zawartość."
 ],
 "This partition is not completely used by its content.": [
  null,
  "Ta partycja nie jest całkowicie używana przez swoją zawartość."
 ],
 "This passphrase is the only way to unlock the pool and can not be removed.": [
  null,
  "To hasło jest jedynym sposobem na odblokowanie puli i nie może zostać usunięte."
 ],
 "This pool does not use all the space on its block devices.": [
  null,
  "Ta pula nie używa całego miejsca na swoich urządzeniach blokowych."
 ],
 "This pool is in a degraded state.": [
  null,
  "Ta pula jest w stanie zdegradowanym."
 ],
 "This tool configures the SELinux policy and can help with understanding and resolving policy violations.": [
  null,
  "To narzędzie konfiguruje zasady SELinuksa i może pomóc w zrozumieniu i rozwiązywaniu naruszeń zasad."
 ],
 "This tool generates an archive of configuration and diagnostic information from the running system. The archive may be stored locally or centrally for recording or tracking purposes or may be sent to technical support representatives, developers or system administrators to assist with technical fault-finding and debugging.": [
  null,
  "To narzędzie tworzy archiwum konfiguracji i informacji diagnostycznych z działającego komputera. Archiwum może być przechowywane lokalnie lub centralnie do celów nagrywania i śledzenia, albo może być wysyłane do przedstawicieli pomocy technicznej, programistów lub administratorów komputera w celu wspomagania znajdowania źródła problemu i debugowania."
 ],
 "This tool manages local storage, such as filesystems, LVM2 volume groups, and NFS mounts.": [
  null,
  "To narzędzie zarządza lokalnymi urządzeniami do przechowywania danych, takimi jak systemy plików, grupy woluminów LVM2 czy punkty montowania NFS."
 ],
 "This tool manages networking such as bonds, bridges, teams, VLANs and firewalls using NetworkManager and Firewalld. NetworkManager is incompatible with Ubuntu's default systemd-networkd and Debian's ifupdown scripts.": [
  null,
  "To narzędzie zarządza sieciami, takimi jak wiązania, mostki, zespoły, VLAN i zapory sieciowe za pomocą usług NetworkManager i firewalld. Usługa NetworkManager jest niezgodna z domyślnymi skryptami systemd-networkd systemu Ubuntu i ifupdown systemu Debian."
 ],
 "This volume group contains the root filesystem. Renaming it might require further changes to the bootloader configuration or kernel command line.": [
  null,
  ""
 ],
 "This volume group is missing some physical volumes.": [
  null,
  "Tej grupie wolumenów brakuje wolumenów fizycznych."
 ],
 "Tier": [
  null,
  "Warstwa"
 ],
 "Time zone": [
  null,
  "Strefa czasowa"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Aby upewnić się, że połączenie nie jest przechwytywane przez szkodliwą stronę trzecią, proszę zweryfikować odcisk klucza komputera:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Aby zweryfikować odcisk klucza, należy wykonać poniższe polecenie na $0 fizycznie siedząc przy komputerze lub przez zaufaną sieć:"
 ],
 "Toggle date picker": [
  null,
  "Przełącz wybór daty"
 ],
 "Too much data": [
  null,
  "Za dużo danych"
 ],
 "Total size: $0": [
  null,
  "Całkowity rozmiar: $0"
 ],
 "Tower": [
  null,
  "Tower"
 ],
 "Trust and add host": [
  null,
  "Zaufaj i dodaj komputer"
 ],
 "Trust key": [
  null,
  "Zaufaj kluczowi"
 ],
 "Trying to synchronize with $0": [
  null,
  "Próbowanie synchronizacji z $0"
 ],
 "Type": [
  null,
  "Typ"
 ],
 "Type must be of the form NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN.": [
  null,
  "Typ musi być w formie NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN."
 ],
 "Type must contain exactly two hexadecimal characters (0 to 9, A to F).": [
  null,
  "Typ musi zawierać dokładnie dwa heksadecymalne znaki (od 0 do 9, A do F)."
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Nie można zalogować się w $0. Komputer nie przyjmuje logowania hasłem ani żadnego z kluczy SSH użytkownika."
 ],
 "Unable to reach server": [
  null,
  "Nie można połączyć się z serwerem"
 ],
 "Unable to remove mount": [
  null,
  "Nie można usunąć punktu montowania"
 ],
 "Unable to unmount filesystem": [
  null,
  "Nie można odmontować systemu plików"
 ],
 "Unexpected PackageKit error during installation of $0: $1": [
  null,
  "Nieoczekiwany błąd usługi PackageKit podczas instalacji $0: $1"
 ],
 "Unknown": [
  null,
  "Nieznane"
 ],
 "Unknown ($0)": [
  null,
  "Nieznane ($0)"
 ],
 "Unknown host name": [
  null,
  "Nieznana nazwa komputera"
 ],
 "Unknown type": [
  null,
  "Nieznany typ"
 ],
 "Unlock": [
  null,
  "Odblokuj"
 ],
 "Unlock automatically on boot": [
  null,
  "Automatyczne odblokowywanie podczas uruchamiania"
 ],
 "Unlock before resizing": [
  null,
  "Odblokuj przed zmianą rozmiaru"
 ],
 "Unlock encrypted Stratis pool": [
  null,
  "Odblokuj zaszyfrowaną pulę Stratis"
 ],
 "Unlocking $target": [
  null,
  "Odblokowywanie $target"
 ],
 "Unlocking disk": [
  null,
  "Odblokowywanie dysku"
 ],
 "Unmount": [
  null,
  "Odmontuj"
 ],
 "Unmount filesystem $0": [
  null,
  "Odmontuj system plików $0"
 ],
 "Unmount now": [
  null,
  "Odmontuj teraz"
 ],
 "Unmounting $target": [
  null,
  "Odmontowywanie $target"
 ],
 "Unrecognized data": [
  null,
  "Nierozpoznane dane"
 ],
 "Unrecognized data can not be made smaller here.": [
  null,
  "Nie można tutaj zmniejszać nieznanych danych."
 ],
 "Untrusted host": [
  null,
  "Niezaufany komputer"
 ],
 "Usage": [
  null,
  "Użycie"
 ],
 "Usage of $0": [
  null,
  "Użycie $0"
 ],
 "Use": [
  null,
  "Użyj"
 ],
 "Use compression": [
  null,
  "Kompresja"
 ],
 "Use deduplication": [
  null,
  "Deduplikacja"
 ],
 "Used": [
  null,
  "Używane"
 ],
 "Useful for mounts that are optional or need interaction (such as passphrases)": [
  null,
  "Przydatne dla punktów montowania, które są opcjonalne lub potrzebują działania użytkownika (np. hasła)"
 ],
 "User": [
  null,
  "Użytkownik"
 ],
 "Username": [
  null,
  "Nazwa użytkownika"
 ],
 "VDO backing devices can not be made smaller": [
  null,
  "Urządzenia podstawowe VDO nie mogą być zmniejszane"
 ],
 "VDO device $0": [
  null,
  "Urządzenie VDO $0"
 ],
 "VDO filesystem volume (compression/deduplication)": [
  null,
  "Wolumin systemu plików VDO (kompresja/deduplikacja)"
 ],
 "Vendor": [
  null,
  "Producent"
 ],
 "Verify fingerprint": [
  null,
  "Zweryfikuj odcisk"
 ],
 "Verify key": [
  null,
  "Zweryfikuj klucz"
 ],
 "Very securely erasing $target": [
  null,
  "Bardzo bezpieczne usuwanie zawartości $target"
 ],
 "View all logs": [
  null,
  "Wszystkie dzienniki"
 ],
 "View automation script": [
  null,
  "Wyświetl skrypt automatyzacji"
 ],
 "View logs": [
  null,
  "Wyświetl dzienniki"
 ],
 "Virtual filesystem sizes are larger than the pool. Overprovisioning can not be disabled.": [
  null,
  ""
 ],
 "Visit firewall": [
  null,
  "Otwórz zaporę sieciową"
 ],
 "Volatile memory backup failed": [
  null,
  ""
 ],
 "Volume group": [
  null,
  "Grupa woluminów"
 ],
 "Volume size is $0. Content size is $1.": [
  null,
  "Rozmiar woluminu to $0. Rozmiar zawartości to $1."
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Oczekiwanie na ukończenie pozostałych działań zarządzania oprogramowaniem"
 ],
 "Web Console for Linux servers": [
  null,
  "Konsola internetowa dla serwerów systemu Linux"
 ],
 "Write-mostly": [
  null,
  "Głównie zapisywane"
 ],
 "Writing": [
  null,
  "Zapisywanie"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Łączenie z $0 po raz pierwszy."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Używana przeglądarka nie zezwala na wklejanie z menu kontekstowego. Można użyć klawiszy Shift+Insert."
 ],
 "Your session has been terminated.": [
  null,
  "Sesja została zakończona."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Sesja wygasła. Proszę zalogować się ponownie."
 ],
 "Zone": [
  null,
  "Strefa"
 ],
 "[binary data]": [
  null,
  "[dane binarne]"
 ],
 "[no data]": [
  null,
  "[brak danych]"
 ],
 "after network": [
  null,
  "po sieci"
 ],
 "backing device for VDO device": [
  null,
  "urządzenie podstawowe urządzenia VDO"
 ],
 "btrfs subvolume $0 of $1": [
  null,
  "subwolumen btrfs $0 wolumenu $1"
 ],
 "delete": [
  null,
  "usuń"
 ],
 "device of btrfs volume": [
  null,
  "urządzenie wolumenu btrfs"
 ],
 "edit": [
  null,
  "modyfikuj"
 ],
 "format": [
  null,
  "format"
 ],
 "grow": [
  null,
  "powiększ"
 ],
 "ignore failure": [
  null,
  "ignorowanie niepowodzenia"
 ],
 "in less than a minute": [
  null,
  ""
 ],
 "initialize": [
  null,
  "zainicjuj"
 ],
 "less than a minute ago": [
  null,
  ""
 ],
 "member of Stratis pool": [
  null,
  "element puli Stratis"
 ],
 "mount": [
  null,
  "montowanie"
 ],
 "never mount at boot": [
  null,
  "bez montowania podczas uruchamiania"
 ],
 "none": [
  null,
  "brak"
 ],
 "password quality": [
  null,
  "jakość hasła"
 ],
 "physical volume of LVM2 volume group": [
  null,
  "wolumin fizyczny grupy woluminów LVM2"
 ],
 "read only": [
  null,
  "tylko do odczytu"
 ],
 "remove from LVM2": [
  null,
  "usuń z LVM2"
 ],
 "show less": [
  null,
  "wyświetl mniej"
 ],
 "show more": [
  null,
  "wyświetl więcej"
 ],
 "shrink": [
  null,
  "zmniejsz"
 ],
 "stop": [
  null,
  "zatrzymaj"
 ],
 "stop boot on failure": [
  null,
  "zatrzymanie uruchamiania po niepowodzeniu"
 ],
 "unknown target": [
  null,
  "nieznany cel"
 ],
 "unmount": [
  null,
  "odmontowanie"
 ],
 "unpartitioned space on $0": [
  null,
  "nieprzydzielone miejsce na $0"
 ],
 "using key description $0": [
  null,
  "używanie opisu klucza $0"
 ],
 "yes": [
  null,
  "tak"
 ],
 "format-bytes\u0004bytes": [
  null,
  "B"
 ]
});
